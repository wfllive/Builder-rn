# expo-liquid-glass

Свой native-модуль Twitblit. Не `react-native-android-liquid-glass`.

- **Android**: снимок области под view → software box-blur, тонкая вуаль (без `Paint.setRenderEffect`).
- **iOS**: `UIVisualEffectView` (systemUltraThinMaterial).
- **Expo Go**: модуль не слинкован — JS рисует scrim.

После добавления в проект:

```bash
npx expo prebuild --clean
npx expo run:android
```
