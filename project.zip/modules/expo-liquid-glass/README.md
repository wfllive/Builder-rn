# expo-liquid-glass

Свой native-модуль Twitblit. Не `react-native-android-liquid-glass`.

- **Android 12+**: снимок области под view → `RenderEffect` blur → вуаль.
- **iOS**: `UIVisualEffectView` (systemUltraThinMaterial).
- **Expo Go**: модуль не слинкован — JS рисует scrim.

После добавления в проект:

```bash
npx expo prebuild --clean
npx expo run:android
```
