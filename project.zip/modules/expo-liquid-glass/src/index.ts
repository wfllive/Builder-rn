/**
 * JS-обёртка native Liquid Glass.
 *
 * Android: наш модуль снимает фон под view и блюрит (software box-blur).
 * iOS: UIVisualEffectView.
 * Expo Go: requireNativeViewManager упадёт — GlassBar ловит и рисует scrim.
 */
import { requireNativeViewManager } from "expo-modules-core";
import React from "react";
import { ViewProps } from "react-native";

export type LiquidGlassViewProps = ViewProps & {
  /** Радиус блюра, 8–28. Больше — молочнее, меньше — резче фон. */
  intensity?: number;
  /** dark | light — цвет вуали поверх блюра. */
  tint?: "dark" | "light";
};

const NativeView = requireNativeViewManager("LiquidGlass") as React.ComponentType<LiquidGlassViewProps>;

export function LiquidGlassView(props: LiquidGlassViewProps) {
  return React.createElement(NativeView, props);
}
