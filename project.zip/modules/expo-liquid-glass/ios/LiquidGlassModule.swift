import ExpoModulesCore

/**
 * iOS: UIVisualEffectView — системное стекло.
 * iOS 26: пробуем UIGlassEffect, если класс есть в SDK.
 */
public class LiquidGlassModule: Module {
  public func definition() -> ModuleDefinition {
    Name("LiquidGlass")

    View(LiquidGlassView.self) {
      Prop("intensity") { (view: LiquidGlassView, value: Double) in
        view.intensity = value
      }
      Prop("tint") { (view: LiquidGlassView, value: String) in
        view.tintName = value
      }
    }
  }
}
