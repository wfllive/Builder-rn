import ExpoModulesCore
import UIKit

/**
 * Нативное стекло iOS.
 * UltraThin material — живой backdrop, не скриншот.
 */
public class LiquidGlassView: ExpoView {
  private let blurView = UIVisualEffectView()

  public required init(appContext: AppContext? = nil) {
    super.init(appContext: appContext)
    clipsToBounds = true
    backgroundColor = .clear
    blurView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    insertSubview(blurView, at: 0)
    applyEffect()
  }

  public var intensity: Double = 20 {
    didSet { applyEffect() }
  }

  public var tintName: String = "dark" {
    didSet { applyEffect() }
  }

  public override func layoutSubviews() {
    super.layoutSubviews()
    blurView.frame = bounds
  }

  private func applyEffect() {
    let style: UIBlurEffect.Style =
      tintName == "light" ? .systemUltraThinMaterialLight : .systemUltraThinMaterialDark
    blurView.effect = UIBlurEffect(style: style)
  }
}
