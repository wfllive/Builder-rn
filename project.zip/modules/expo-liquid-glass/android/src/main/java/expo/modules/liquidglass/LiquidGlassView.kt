package expo.modules.liquidglass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

/**
 * Backdrop Liquid Glass для Android.
 *
 * Не блюрит себя (эффект на this даёт пустоту).
 * Прячет себя, рисует root в маленький bitmap, блюрит софтом, кладёт как фон.
 *
 * Paint.setRenderEffect в android.jar части сборок нет (Unresolved reference)
 * и на software Canvas всё равно не работает — только hardware.
 * Поэтому Gaussian через 2 прохода box-blur по пикселям.
 */
class LiquidGlassView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private var intensity = 18f
  private var tintColor = Color.argb(90, 12, 10, 16)
  private var cached: Bitmap? = null
  private var updatePosted = false
  private var capturing = false
  private val mainHandler = Handler(Looper.getMainLooper())
  private val dest = Rect()
  private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

  init {
    setWillNotDraw(false)
    setBackgroundColor(Color.TRANSPARENT)
  }

  fun setIntensity(value: Float) {
    intensity = value.coerceIn(4f, 28f)
    scheduleUpdate()
  }

  fun setTintName(name: String) {
    tintColor = if (name == "light") {
      Color.argb(88, 250, 250, 252)
    } else {
      Color.argb(90, 12, 10, 16)
    }
    invalidate()
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    scheduleUpdate()
  }

  override fun onDetachedFromWindow() {
    super.onDetachedFromWindow()
    mainHandler.removeCallbacksAndMessages(null)
    updatePosted = false
    cached?.recycle()
    cached = null
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    cached?.recycle()
    cached = null
    scheduleUpdate()
  }

  override fun dispatchDraw(canvas: Canvas) {
    val bmp = cached
    if (bmp != null && !bmp.isRecycled) {
      dest.set(0, 0, width, height)
      canvas.drawBitmap(bmp, null, dest, paint)
    }
    canvas.drawColor(tintColor)
    super.dispatchDraw(canvas)
    scheduleUpdate()
  }

  private fun scheduleUpdate() {
    if (updatePosted || !isAttachedToWindow) return
    updatePosted = true
    mainHandler.postDelayed({
      updatePosted = false
      if (isAttachedToWindow && width > 0 && height > 0) {
        refreshBackdrop()
        invalidate()
      }
    }, 90L)
  }

  private fun refreshBackdrop() {
    if (capturing) return
    val root = rootView ?: return
    val w = width
    val h = height
    if (w <= 0 || h <= 0) return

    val scale = 0.28f
    val sw = (w * scale).toInt().coerceAtLeast(2)
    val sh = (h * scale).toInt().coerceAtLeast(2)

    val loc = IntArray(2)
    val rootLoc = IntArray(2)
    getLocationOnScreen(loc)
    root.getLocationOnScreen(rootLoc)
    val dx = (loc[0] - rootLoc[0]).toFloat()
    val dy = (loc[1] - rootLoc[1]).toFloat()

    val raw = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    val c = Canvas(raw)
    c.scale(scale, scale)
    c.translate(-dx, -dy)

    capturing = true
    val previous = visibility
    visibility = INVISIBLE
    try {
      root.draw(c)
    } catch (_: Throwable) {
      raw.recycle()
      visibility = previous
      capturing = false
      return
    } finally {
      visibility = previous
      capturing = false
    }

    val radius = (intensity * scale).toInt().coerceIn(2, 14)
    val blurred = blurBitmap(raw, radius)
    if (raw != blurred) raw.recycle()
    cached?.recycle()
    cached = blurred
  }

  /**
   * Два прохода box-blur ≈ Gaussian. Без RenderEffect / setRenderEffect.
   */
  private fun blurBitmap(src: Bitmap, radius: Int): Bitmap {
    return try {
      val w = src.width
      val h = src.height
      val a = IntArray(w * h)
      val b = IntArray(w * h)
      src.getPixels(a, 0, w, 0, 0, w, h)
      boxBlurH(a, b, w, h, radius)
      boxBlurV(b, a, w, h, radius)
      boxBlurH(a, b, w, h, radius)
      boxBlurV(b, a, w, h, radius)
      val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
      out.setPixels(a, 0, w, 0, 0, w, h)
      out
    } catch (_: Throwable) {
      src
    }
  }

  private fun boxBlurH(src: IntArray, dst: IntArray, w: Int, h: Int, radius: Int) {
    val div = radius * 2 + 1
    var y = 0
    while (y < h) {
      val row = y * w
      var ar = 0
      var ag = 0
      var ab = 0
      var i = -radius
      while (i <= radius) {
        val p = src[row + i.coerceIn(0, w - 1)]
        ar += (p ushr 16) and 0xFF
        ag += (p ushr 8) and 0xFF
        ab += p and 0xFF
        i++
      }
      var x = 0
      while (x < w) {
        dst[row + x] = (0xFF shl 24) or ((ar / div) shl 16) or ((ag / div) shl 8) or (ab / div)
        val incoming = src[row + (x + radius + 1).coerceIn(0, w - 1)]
        val outgoing = src[row + (x - radius).coerceIn(0, w - 1)]
        ar += ((incoming ushr 16) and 0xFF) - ((outgoing ushr 16) and 0xFF)
        ag += ((incoming ushr 8) and 0xFF) - ((outgoing ushr 8) and 0xFF)
        ab += (incoming and 0xFF) - (outgoing and 0xFF)
        x++
      }
      y++
    }
  }

  private fun boxBlurV(src: IntArray, dst: IntArray, w: Int, h: Int, radius: Int) {
    val div = radius * 2 + 1
    var x = 0
    while (x < w) {
      var ar = 0
      var ag = 0
      var ab = 0
      var i = -radius
      while (i <= radius) {
        val p = src[i.coerceIn(0, h - 1) * w + x]
        ar += (p ushr 16) and 0xFF
        ag += (p ushr 8) and 0xFF
        ab += p and 0xFF
        i++
      }
      var y = 0
      while (y < h) {
        dst[y * w + x] = (0xFF shl 24) or ((ar / div) shl 16) or ((ag / div) shl 8) or (ab / div)
        val incoming = src[(y + radius + 1).coerceIn(0, h - 1) * w + x]
        val outgoing = src[(y - radius).coerceIn(0, h - 1) * w + x]
        ar += ((incoming ushr 16) and 0xFF) - ((outgoing ushr 16) and 0xFF)
        ag += ((incoming ushr 8) and 0xFF) - ((outgoing ushr 8) and 0xFF)
        ab += (incoming and 0xFF) - (outgoing and 0xFF)
        y++
      }
      x++
    }
  }
}