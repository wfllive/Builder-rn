package expo.modules.liquidglass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

/**
 * Backdrop Liquid Glass для Android.
 *
 * Не блюрит себя (RenderEffect на this даёт пустоту).
 * Прячет себя, рисует root в маленький bitmap, блюрит, кладёт как фон.
 * Обновление ~12 fps — без лага enableDynamicBackground сторонней либы.
 */
class LiquidGlassView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private var intensity = 18f
  private var tintColor = Color.argb(90, 12, 10, 16)
  private var cached: Bitmap? = null
  private var updatePosted = false
  private var capturing = false
  private val mainHandler = Handler(Looper.getMainLooper())
  private val dest = Rect()
  private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

  init {
    setWillNotDraw(false)
    setBackgroundColor(Color.TRANSPARENT)
  }

  fun setIntensity(value: Float) {
    intensity = value.coerceIn(4f, 28f)
    scheduleUpdate()
  }

  fun setTintName(name: String) {
    tintColor = if (name == "light") {
      Color.argb(88, 250, 250, 252)
    } else {
      Color.argb(90, 12, 10, 16)
    }
    invalidate()
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    scheduleUpdate()
  }

  override fun onDetachedFromWindow() {
    super.onDetachedFromWindow()
    mainHandler.removeCallbacksAndMessages(null)
    updatePosted = false
    cached?.recycle()
    cached = null
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    cached?.recycle()
    cached = null
    scheduleUpdate()
  }

  override fun dispatchDraw(canvas: Canvas) {
    val bmp = cached
    if (bmp != null && !bmp.isRecycled) {
      dest.set(0, 0, width, height)
      canvas.drawBitmap(bmp, null, dest, paint)
    }
    canvas.drawColor(tintColor)
    super.dispatchDraw(canvas)
    scheduleUpdate()
  }

  private fun scheduleUpdate() {
    if (updatePosted || !isAttachedToWindow) return
    updatePosted = true
    mainHandler.postDelayed({
      updatePosted = false
      if (isAttachedToWindow && width > 0 && height > 0) {
        refreshBackdrop()
        invalidate()
      }
    }, 90L)
  }

  private fun refreshBackdrop() {
    if (capturing) return
    val root = rootView ?: return
    val w = width
    val h = height
    if (w <= 0 || h <= 0) return

    val scale = 0.28f
    val sw = (w * scale).toInt().coerceAtLeast(2)
    val sh = (h * scale).toInt().coerceAtLeast(2)

    val loc = IntArray(2)
    val rootLoc = IntArray(2)
    getLocationOnScreen(loc)
    root.getLocationOnScreen(rootLoc)
    val dx = (loc[0] - rootLoc[0]).toFloat()
    val dy = (loc[1] - rootLoc[1]).toFloat()

    val raw = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    val c = Canvas(raw)
    c.scale(scale, scale)
    c.translate(-dx, -dy)

    capturing = true
    val previous = visibility
    visibility = INVISIBLE
    try {
      root.draw(c)
    } catch (_: Throwable) {
      raw.recycle()
      visibility = previous
      capturing = false
      return
    } finally {
      visibility = previous
      capturing = false
    }

    val blurred = blurBitmap(raw, intensity * scale)
    if (raw != blurred) raw.recycle()
    cached?.recycle()
    cached = blurred
  }

  private fun blurBitmap(src: Bitmap, radius: Float): Bitmap {
    val r = radius.coerceIn(1f, 25f)
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
      return src
    }
    return try {
      val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
      val canvas = Canvas(out)
      val p = Paint(Paint.FILTER_BITMAP_FLAG)
      p.setRenderEffect(
        RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP)
      )
      canvas.drawBitmap(src, 0f, 0f, p)
      out
    } catch (_: Throwable) {
      src
    }
  }
}
