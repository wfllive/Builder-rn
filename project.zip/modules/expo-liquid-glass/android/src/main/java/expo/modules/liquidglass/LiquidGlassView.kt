package expo.modules.liquidglass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView

/**
 * Backdrop Liquid Glass для Android.
 *
 * Прячет себя на время снимка (флаг skipDraw, без View.visibility — тот
 * дёргает layout и даёт лаги). Рисует root в маленький bitmap, один
 * box-blur, лёгкая вуаль. Буферы переиспользуются.
 *
 * Не Paint.setRenderEffect: в CI нет метода, на software Canvas не работает.
 */
class LiquidGlassView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private var intensity = 14f
  private var tintColor = Color.argb(36, 16, 14, 22)
  private var raw: Bitmap? = null
  private var blurred: Bitmap? = null
  private var pixA: IntArray? = null
  private var pixB: IntArray? = null
  private var loopPosted = false
  private val mainHandler = Handler(Looper.getMainLooper())
  private val dest = Rect()
  private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

  init {
    setWillNotDraw(false)
    setBackgroundColor(Color.TRANSPARENT)
  }

  fun setIntensity(value: Float) {
    intensity = value.coerceIn(4f, 28f)
  }

  fun setTintName(name: String) {
    // Вуаль тонкая: «затемнение на весь бар» было из-за alpha ~90.
    tintColor = if (name == "light") {
      Color.argb(40, 252, 252, 255)
    } else {
      Color.argb(36, 16, 14, 22)
    }
    invalidate()
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    startLoop()
  }

  override fun onDetachedFromWindow() {
    super.onDetachedFromWindow()
    mainHandler.removeCallbacks(tick)
    loopPosted = false
    raw?.recycle()
    blurred?.recycle()
    raw = null
    blurred = null
    pixA = null
    pixB = null
  }

  override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
    super.onSizeChanged(w, h, oldw, oldh)
    raw?.recycle()
    blurred?.recycle()
    raw = null
    blurred = null
    pixA = null
    pixB = null
  }

  override fun dispatchDraw(canvas: Canvas) {
    if (skipDraw > 0) {
      // Прозрачно: root.draw увидит ленту под баром, не сам бар.
      return
    }
    val bmp = blurred
    if (bmp != null && !bmp.isRecycled) {
      dest.set(0, 0, width, height)
      canvas.drawBitmap(bmp, null, dest, paint)
    }
    canvas.drawColor(tintColor)
    super.dispatchDraw(canvas)
  }

  private val tick = Runnable {
    loopPosted = false
    if (!isAttachedToWindow) return@Runnable
    if (width > 0 && height > 0) {
      refreshBackdrop()
      invalidate()
    }
    startLoop()
  }

  private fun startLoop() {
    if (loopPosted || !isAttachedToWindow) return
    loopPosted = true
    mainHandler.postDelayed(tick, FRAME_MS)
  }

  private fun refreshBackdrop() {
    if (capturingRoot) return
    val root = rootView ?: return
    val w = width
    val h = height
    if (w <= 0 || h <= 0) return

    val scale = 0.2f
    val sw = (w * scale).toInt().coerceAtLeast(2)
    val sh = (h * scale).toInt().coerceAtLeast(2)
    ensureBuffers(sw, sh)
    val src = raw ?: return
    val dst = blurred ?: return

    val loc = IntArray(2)
    val rootLoc = IntArray(2)
    getLocationOnScreen(loc)
    root.getLocationOnScreen(rootLoc)
    val dx = (loc[0] - rootLoc[0]).toFloat()
    val dy = (loc[1] - rootLoc[1]).toFloat()

    src.eraseColor(Color.TRANSPARENT)
    val c = Canvas(src)
    c.scale(scale, scale)
    c.translate(-dx, -dy)

    capturingRoot = true
    skipDraw++
    try {
      root.draw(c)
    } catch (_: Throwable) {
      return
    } finally {
      skipDraw--
      capturingRoot = false
    }

    val radius = (intensity * scale).toInt().coerceIn(2, 8)
    blurInto(src, dst, radius)
  }

  private fun ensureBuffers(sw: Int, sh: Int) {
    val cur = raw
    if (cur != null && !cur.isRecycled && cur.width == sw && cur.height == sh) return
    raw?.recycle()
    blurred?.recycle()
    raw = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    blurred = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    val n = sw * sh
    pixA = IntArray(n)
    pixB = IntArray(n)
  }

  private fun blurInto(src: Bitmap, dst: Bitmap, radius: Int) {
    val w = src.width
    val h = src.height
    val a = pixA ?: return
    val b = pixB ?: return
    src.getPixels(a, 0, w, 0, 0, w, h)
    boxBlurH(a, b, w, h, radius)
    boxBlurV(b, a, w, h, radius)
    dst.setPixels(a, 0, w, 0, 0, w, h)
  }

  private fun boxBlurH(src: IntArray, dst: IntArray, w: Int, h: Int, radius: Int) {
    val div = radius * 2 + 1
    var y = 0
    while (y < h) {
      val row = y * w
      var ar = 0
      var ag = 0
      var ab = 0
      var i = -radius
      while (i <= radius) {
        val p = src[row + i.coerceIn(0, w - 1)]
        ar += (p ushr 16) and 0xFF
        ag += (p ushr 8) and 0xFF
        ab += p and 0xFF
        i++
      }
      var x = 0
      while (x < w) {
        dst[row + x] = (0xFF shl 24) or ((ar / div) shl 16) or ((ag / div) shl 8) or (ab / div)
        val incoming = src[row + (x + radius + 1).coerceIn(0, w - 1)]
        val outgoing = src[row + (x - radius).coerceIn(0, w - 1)]
        ar += ((incoming ushr 16) and 0xFF) - ((outgoing ushr 16) and 0xFF)
        ag += ((incoming ushr 8) and 0xFF) - ((outgoing ushr 8) and 0xFF)
        ab += (incoming and 0xFF) - (outgoing and 0xFF)
        x++
      }
      y++
    }
  }

  private fun boxBlurV(src: IntArray, dst: IntArray, w: Int, h: Int, radius: Int) {
    val div = radius * 2 + 1
    var x = 0
    while (x < w) {
      var ar = 0
      var ag = 0
      var ab = 0
      var i = -radius
      while (i <= radius) {
        val p = src[i.coerceIn(0, h - 1) * w + x]
        ar += (p ushr 16) and 0xFF
        ag += (p ushr 8) and 0xFF
        ab += p and 0xFF
        i++
      }
      var y = 0
      while (y < h) {
        dst[y * w + x] = (0xFF shl 24) or ((ar / div) shl 16) or ((ag / div) shl 8) or (ab / div)
        val incoming = src[(y + radius + 1).coerceIn(0, h - 1) * w + x]
        val outgoing = src[(y - radius).coerceIn(0, h - 1) * w + x]
        ar += ((incoming ushr 16) and 0xFF) - ((outgoing ushr 16) and 0xFF)
        ag += ((incoming ushr 8) and 0xFF) - ((outgoing ushr 8) and 0xFF)
        ab += (incoming and 0xFF) - (outgoing and 0xFF)
        y++
      }
      x++
    }
  }

  companion object {
    private const val FRAME_MS = 160L
    @Volatile private var capturingRoot = false
    @Volatile private var skipDraw = 0
  }
}
