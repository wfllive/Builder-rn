package expo.modules.liquidglass

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/**
 * Expo-модуль Liquid Glass.
 * View: LiquidGlassView — блюр того, что под шапкой/таббаром.
 */
class LiquidGlassModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("LiquidGlass")

    View(LiquidGlassView::class) {
      Prop("intensity") { view: LiquidGlassView, value: Double ->
        view.setIntensity(value.toFloat())
      }
      Prop("tint") { view: LiquidGlassView, value: String ->
        view.setTintName(value)
      }
    }
  }
}
