package expo.modules.aptmanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Foreground service that keeps the app process alive while a long operation
 * runs in the background (rootfs download, RAI environment setup, Gradle build).
 *
 * The actual work runs in the normal app process (proot child processes started
 * from JS via TermuxTerminalModule). A foreground service marks this process as
 * "foreground" for the system, so Android does not kill it when the user leaves
 * the app, locks the screen, or the device is low on memory. A partial wakelock
 * additionally keeps the CPU awake so downloads/builds are not paused by Doze.
 *
 * Controlled from JS via AptManagerModule:
 *   startBackgroundService(text) / updateBackgroundService(text) / stopBackgroundService()
 */
class BackgroundWorkService : Service() {

    companion object {
        const val CHANNEL_ID = "compose-studio-background-work"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "expo.modules.aptmanager.action.START_WORK"
        const val ACTION_UPDATE = "expo.modules.aptmanager.action.UPDATE_WORK"
        const val ACTION_STOP = "expo.modules.aptmanager.action.STOP_WORK"
        const val EXTRA_TEXT = "extra_text"

        @Volatile
        var currentText: String = "Фоновая задача выполняется"

        private var wakeLock: PowerManager.WakeLock? = null

        fun start(context: Context, text: String) {
            currentText = text
            val intent = Intent(context, BackgroundWorkService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_TEXT, text)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun update(context: Context, text: String) {
            currentText = text
            try {
                val intent = Intent(context, BackgroundWorkService::class.java)
                    .setAction(ACTION_UPDATE)
                    .putExtra(EXTRA_TEXT, text)
                context.startService(intent)
            } catch (_: Exception) {
                // Service not running yet or being stopped — nothing to update.
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, BackgroundWorkService::class.java)
                    .setAction(ACTION_STOP)
                context.startService(intent)
            } catch (_: Exception) {
                releaseWakeLock()
            }
        }

        private fun releaseWakeLock() {
            try {
                wakeLock?.let { if (it.isHeld) it.release() }
            } catch (_: Exception) {
            }
            wakeLock = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        acquireWakeLock()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: currentText
        currentText = text
        startForegroundCompat(text)

        when (intent?.action) {
            ACTION_UPDATE -> Unit // notification already refreshed above
            ACTION_STOP -> {
                stopForegroundCompat()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Фоновые задачи (установка/сборка)",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Держит установку и сборку работающими в фоне"
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "compose-studio:background-work")
            lock.setReferenceCounted(false)
            lock.acquire(8 * 60 * 60 * 1000L) // hard cap 8h, безопасный предел
            Companion.wakeLock = lock
        } catch (_: Exception) {
        }
    }

    private fun startForegroundCompat(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopForegroundCompat() {
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentIntent = if (openIntent != null) {
            PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setPriority(Notification.PRIORITY_LOW)
        }

        builder
            .setSmallIcon(android.R.drawable.stat_sys_download) // системная иконка — не требует ресурса приложения
            .setContentTitle("Compose Studio")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_PROGRESS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)

        if (contentIntent != null) builder.setContentIntent(contentIntent)
        return builder.build()
    }
}
