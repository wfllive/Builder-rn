package expo.modules.aptmanager

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tukaani.xz.XZInputStream
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

class AptManagerModule : Module() {

    companion object {
        const val BOOTSTRAP_URL = "https://github.com/termux/termux-packages/releases/download/bootstrap-2025.12.14-r1%2Bapt.android-7/bootstrap-aarch64.zip"
    }

    private fun getPrefix(): String {
        val appCtx = appContext.reactContext!!
        return File(appCtx.filesDir, "usr").absolutePath
    }

    private fun getHome(): String {
        val appCtx = appContext.reactContext!!
        return File(appCtx.filesDir, "home").absolutePath
    }

    private fun isBootstrapInstalled(): Boolean {
        val prefix = getPrefix()
        val bash = File(prefix, "bin/bash")
        val apt = File(prefix, "bin/apt")
        val dpkg = File(prefix, "bin/dpkg")
        val sourcesList = File(prefix, "etc/apt/sources.list")
        return bash.exists() && apt.exists() && dpkg.exists() && sourcesList.exists()
    }

    /** Скопировать бинарники в exec-capable директорию */
    private fun ensurePermissions() {
        val appCtx = appContext.reactContext!!
        val prefix = getPrefix()
        val execDir = appCtx.getDir("exec", android.content.Context.MODE_PRIVATE)
        val execBin = File(execDir, "bin")
        execBin.mkdirs()

        // Логируем пути
        android.util.Log.d("AptManager", "prefix: $prefix")
        android.util.Log.d("AptManager", "execDir: ${execDir.absolutePath}")
        android.util.Log.d("AptManager", "execBin: ${execBin.absolutePath}")

        // Копируем все бинарники из prefix/bin в execBin
        val srcBin = File(prefix, "bin")
        android.util.Log.d("AptManager", "srcBin exists: ${srcBin.exists()}")
        if (srcBin.exists()) {
            val files = srcBin.listFiles()
            android.util.Log.d("AptManager", "srcBin files count: ${files?.size ?: 0}")
            files?.forEach { file ->
                val dest = File(execBin, file.name)
                if (!dest.exists() || file.lastModified() > dest.lastModified()) {
                    try {
                        file.copyTo(dest, overwrite = true)
                        dest.setExecutable(true, false)
                        try { android.system.Os.chmod(dest.absolutePath, 0b111101101) } catch (e: Exception) {
                            android.util.Log.e("AptManager", "chmod failed for ${file.name}: ${e.message}")
                        }
                        android.util.Log.d("AptManager", "Copied ${file.name} -> ${dest.absolutePath}, canExecute=${dest.canExecute()}")
                    } catch (e: Exception) {
                        android.util.Log.e("AptManager", "Copy failed for ${file.name}: ${e.message}")
                    }
                }
            }
        }

        // Также копируем lib (для shared libraries)
        val execLib = File(execDir, "lib")
        execLib.mkdirs()
        val srcLib = File(prefix, "lib")
        if (srcLib.exists()) {
            srcLib.listFiles()?.filter { it.isFile }?.forEach { file ->
                val dest = File(execLib, file.name)
                if (!dest.exists() || file.lastModified() > dest.lastModified()) {
                    try {
                        file.copyTo(dest, overwrite = true)
                        dest.setExecutable(true, false)
                    } catch (_: Exception) {}
                }
            }
        }

        android.util.Log.d("AptManager", "ensurePermissions complete")
    }

    private fun downloadFile(urlStr: String, dest: File): Boolean {
        return try {
            var url = URL(urlStr)
            var conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 120000
            conn.instanceFollowRedirects = true
            var redirects = 0
            while (redirects < 10) {
                val code = conn.responseCode
                if (code in listOf(301, 302, 307, 308)) {
                    val loc = conn.getHeaderField("Location") ?: break
                    url = URL(url, loc)
                    conn = url.openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 15000
                    conn.readTimeout = 120000
                    redirects++
                } else break
            }
            if (conn.responseCode != 200) return false
            conn.inputStream.use { input ->
                FileOutputStream(dest).use { output -> input.copyTo(output, 8192) }
            }
            dest.length() > 0
        } catch (_: Exception) { false }
    }

    private fun installBootstrap(log: StringBuilder): Boolean {
        val appCtx = appContext.reactContext!!
        val prefix = File(getPrefix())
        val home = File(getHome())
        val tmpDir = File(prefix, "tmp")
        val cacheDir = File(appCtx.cacheDir, "apt-cache")
        cacheDir.mkdirs(); prefix.mkdirs(); home.mkdirs(); tmpDir.mkdirs()

        val zipFile = File(cacheDir, "bootstrap-aarch64.zip")
        log.appendLine("Downloading Termux bootstrap...")

        if (!downloadFile(BOOTSTRAP_URL, zipFile)) {
            log.appendLine("Download failed"); return false
        }
        log.appendLine("Downloaded: ${zipFile.length() / 1024 / 1024}MB")
        log.appendLine("Extracting to ${prefix.absolutePath}/...")

        var extractedCount = 0
        val symlinks = mutableListOf<Pair<String, String>>()

        try {
            ZipInputStream(FileInputStream(zipFile)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name == "SYMLINKS.txt") {
                        val text = zip.bufferedReader().readText()
                        text.lines().filter { it.contains("\u2190") }.forEach { line ->
                            val parts = line.split("\u2190")
                            if (parts.size == 2) {
                                symlinks.add(Pair(parts[1].trim().removePrefix("./"), parts[0].trim()))
                            }
                        }
                        entry = zip.nextEntry; continue
                    }
                    if (name.isEmpty() || name == "./" || name == ".") { entry = zip.nextEntry; continue }

                    val destFile = File(prefix, name)
                    if (entry.isDirectory) {
                        destFile.mkdirs()
                    } else {
                        destFile.parentFile?.mkdirs()
                        try {
                            FileOutputStream(destFile).use { fos -> zip.copyTo(fos) }
                            extractedCount++
                            if (name.startsWith("bin/") || name.startsWith("lib/apt/")) {
                                destFile.setExecutable(true, false)
                                try { android.system.Os.chmod(destFile.absolutePath, 0b111101101) } catch (_: Exception) {}
                            }
                        } catch (_: Exception) {}
                    }
                    entry = zip.nextEntry
                }
            }

            log.appendLine("Extracted $extractedCount files")

            // Symlinks
            var linksCreated = 0
            for ((linkPath, target) in symlinks) {
                val linkFile = File(prefix, linkPath)
                linkFile.parentFile?.mkdirs()
                if (linkFile.exists()) linkFile.delete()
                try {
                    ProcessBuilder("ln", "-sf", target, linkFile.absolutePath).redirectErrorStream(true).start().waitFor()
                    linksCreated++
                } catch (_: Exception) {}
            }
            log.appendLine("Created $linksCreated symlinks")

            zipFile.delete()

            // chmod — через Java Os.chmod для каждого файла (надёжнее чем shell chmod)
            var chmodCount = 0
            val binDir = File(prefix, "bin")
            if (binDir.exists()) {
                binDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111101101) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            val libDir = File(prefix, "lib")
            if (libDir.exists()) {
                libDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111101101) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            val libexecDir = File(prefix, "libexec")
            if (libexecDir.exists()) {
                libexecDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111101101) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            log.appendLine("chmod: $chmodCount files made executable")

            val bash = File(prefix, "bin/bash")
            val apt = File(prefix, "bin/apt")
            log.appendLine("bash: exists=${bash.exists()} canExec=${bash.canExecute()}")
            log.appendLine("apt: exists=${apt.exists()} canExec=${apt.canExecute()}")
            log.appendLine("sources.list: ${File(prefix, "etc/apt/sources.list").exists()}")

            return bash.exists() && bash.canExecute()
        } catch (e: Exception) {
            log.appendLine("Error: ${e.message}")
            return false
        }
    }

    private fun runShellCmd(cmd: String): Map<String, Any> {
        val prefix = getPrefix()
        val home = getHome()
        val tmpDir = "$prefix/tmp"
        val fullCmd = "export PREFIX=\"$prefix\" && export HOME=\"$home\" && export TMPDIR=\"$tmpDir\" && " +
            "export PATH=\"$prefix/bin:\$PATH\" && export LD_LIBRARY_PATH=\"$prefix/lib:\$LD_LIBRARY_PATH\" && " +
            "export TERM=xterm-256color && $cmd 2>&1"
        return try {
            val process = ProcessBuilder("sh", "-c", fullCmd).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            mapOf("success" to (exitCode == 0), "exitCode" to exitCode, "output" to output)
        } catch (e: Exception) {
            mapOf("success" to false, "exitCode" to -1, "output" to ("Error: " + e.message))
        }
    }

    private fun loadInstalled(): MutableMap<String, String> {
        val db = File(appContext.reactContext!!.filesDir, ".apt_installed.json")
        if (!db.exists()) return mutableMapOf()
        try {
            val map = mutableMapOf<String, String>()
            """"(\S+)"\s*:\s*"([^"]*)"""".toRegex().findAll(db.readText()).forEach { map[it.groupValues[1]] = it.groupValues[2] }
            return map
        } catch (_: Exception) { return mutableMapOf() }
    }

    private fun saveInstalled(installed: Map<String, String>) {
        val json = "{\n" + installed.entries.joinToString(",\n") { "  \"${it.key}\": \"${it.value}\"" } + "\n}"
        File(appContext.reactContext!!.filesDir, ".apt_installed.json").writeText(json)
    }

    override fun definition() = ModuleDefinition {
        Name("AptManager")

        AsyncFunction("isBootstrapInstalled") Coroutine { ->
            withContext(Dispatchers.IO) { isBootstrapInstalled() }
        }

        AsyncFunction("ensurePermissions") Coroutine { ->
            withContext(Dispatchers.IO) {
                ensurePermissions()
                mapOf("success" to true)
            }
        }

        AsyncFunction("getExecBinDir") Coroutine { ->
            withContext(Dispatchers.IO) {
                val appCtx = appContext.reactContext!!
                val execDir = appCtx.getDir("exec", android.content.Context.MODE_PRIVATE)
                val execBin = File(execDir, "bin")
                mapOf("path" to execBin.absolutePath)
            }
        }

        AsyncFunction("installBootstrap") Coroutine { ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()
                val ok = installBootstrap(log)
                mapOf("success" to ok, "output" to log.toString())
            }
        }

        AsyncFunction("install") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()

                if (!isBootstrapInstalled()) {
                    val bootstrapOk = installBootstrap(log)
                    if (!bootstrapOk) {
                        mapOf("success" to false, "output" to log.toString())
                    } else {
                        log.appendLine("")
                        log.appendLine("Installing $packageName...")
                        val result = runShellCmd("pkg install -y $packageName")
                        log.append(result["output"] as? String ?: "")
                        if (result["success"] == true) {
                            val installed = loadInstalled()
                            installed[packageName] = "installed"
                            saveInstalled(installed)
                            log.appendLine("✓ $packageName installed")
                        }
                        mapOf("success" to result["success"], "output" to log.toString())
                    }
                } else {
                    // Bootstrap уже установлен — убедиться что permissions правильные
                    ensurePermissions()
                    log.appendLine("Bootstrap already installed, permissions verified.")
                    log.appendLine("Installing $packageName...")
                    val result = runShellCmd("pkg install -y $packageName")
                    log.append(result["output"] as? String ?: "")
                    if (result["success"] == true) {
                        val installed = loadInstalled()
                        installed[packageName] = "installed"
                        saveInstalled(installed)
                        log.appendLine("✓ $packageName installed")
                    }
                    mapOf("success" to result["success"], "output" to log.toString())
                }
            }
        }

        AsyncFunction("remove") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                val result = runShellCmd("pkg uninstall -y $packageName")
                if (result["success"] == true) {
                    val installed = loadInstalled()
                    installed.remove(packageName)
                    saveInstalled(installed)
                }
                result
            }
        }

        AsyncFunction("search") Coroutine { query: String ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed. Open Terminal to install.")
                } else {
                    runShellCmd("apt search $query")
                }
            }
        }

        AsyncFunction("info") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed.")
                } else {
                    runShellCmd("apt show $packageName")
                }
            }
        }

        AsyncFunction("update") Coroutine { ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed.")
                } else {
                    runShellCmd("apt update")
                }
            }
        }

        AsyncFunction("listInstalled") Coroutine { ->
            withContext(Dispatchers.IO) {
                val installed = loadInstalled()
                installed.entries.map { mapOf("name" to it.key, "version" to it.value) }
            }
        }

        AsyncFunction("getPrefix") Coroutine { ->
            withContext(Dispatchers.IO) { mapOf("prefix" to getPrefix()) }
        }

        AsyncFunction("getHome") Coroutine { ->
            withContext(Dispatchers.IO) { mapOf("home" to getHome()) }
        }

        AsyncFunction("whichCommand") Coroutine { command: String ->
            withContext(Dispatchers.IO) {
                val prefix = getPrefix()
                val binPath = File(prefix, "bin/$command")
                if (binPath.exists() && binPath.canExecute()) {
                    mapOf("exists" to true, "path" to binPath.absolutePath)
                } else {
                    try {
                        val p = ProcessBuilder("sh", "-c", "PATH=\"$prefix/bin:\$PATH\" which $command 2>/dev/null")
                            .redirectErrorStream(true).start()
                        val path = p.inputStream.bufferedReader().readText().trim()
                        p.waitFor()
                        mapOf("exists" to (p.exitValue() == 0 && path.isNotEmpty()), "path" to path)
                    } catch (_: Exception) {
                        mapOf("exists" to false, "path" to "")
                    }
                }
            }
        }
    }
}
