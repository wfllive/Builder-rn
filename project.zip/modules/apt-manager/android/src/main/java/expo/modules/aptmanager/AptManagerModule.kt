package expo.modules.aptmanager

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tukaani.xz.XZInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

class AptManagerModule : Module() {

    companion object {
        const val BOOTSTRAP_URL = "https://github.com/termux/termux-packages/releases/download/bootstrap-2025.12.14-r1%2Bapt.android-7/bootstrap-aarch64.zip"
        // Default proot Linux rootfs (Ubuntu base, arm64, has apt). Override via installProotRootfs(url).
        // If this URL 404s, pick a current arm64 rootfs tar.gz, e.g.:
        //   Ubuntu base : https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04-base-arm64.tar.gz
        //   Alpine (apk): https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.0-aarch64.tar.gz
        const val DEFAULT_ROOTFS_URL = "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04-base-arm64.tar.gz"
    }

    private fun getPrefix(): String {
        val appCtx = appContext.reactContext!!
        return File(appCtx.filesDir, "usr").absolutePath
    }

    private fun getHome(): String {
        val appCtx = appContext.reactContext!!
        return File(appCtx.filesDir, "home").absolutePath
    }

    // ---------------------------------------------------------------------
    // proot Linux rootfs (gives a real Linux with apt, bypassing noexec)
    // ---------------------------------------------------------------------

    private fun getProotRootfsDir(): File {
        val appCtx = appContext.reactContext!!
        return File(appCtx.filesDir, "proot/rootfs")
    }

    private fun isProotRootfsInstalled(): Boolean =
        File(getProotRootfsDir(), "bin").isDirectory

    /** Download a .tar.gz rootfs and extract it into files/proot/rootfs. */
    /** Which guest architecture to fetch a rootfs for, based on the device's primary ABI. */
    private fun deviceArchLabel(): String {
        val abi = try {
            android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        } catch (e: Exception) {
            "arm64-v8a"
        }
        return when {
            abi.contains("arm64") || abi.contains("aarch64") -> "aarch64"
            abi.contains("x86_64") -> "x86_64"
            abi.contains("x86") -> "i386"
            else -> "armhf" // armeabi-v7a and friends
        }
    }

    /**
     * Prioritized rootfs tarballs for the current architecture. apt-based images first (the user
     * wants apt); Alpine (apk) as a small reliable fallback. URLs can rot, so several are tried in
     * order; an explicit URL always wins.
     */
    private fun candidateRootfsUrls(): List<String> {
        return when (deviceArchLabel()) {
            "aarch64" -> listOf(
                "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04-base-arm64.tar.gz",
                "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04-base-arm64.tar.gz",
                DEFAULT_ROOTFS_URL,
                "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.0-aarch64.tar.gz"
            )
            "armhf" -> listOf(
                "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04-base-armhf.tar.gz",
                "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/armhf/alpine-minirootfs-3.20.0-armhf.tar.gz"
            )
            "x86_64" -> listOf(
                "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86_64/alpine-minirootfs-3.20.0-x86_64.tar.gz"
            )
            else -> listOf(
                "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86/alpine-minirootfs-3.20.0-x86.tar.gz"
            )
        }
    }

    /** Install a rootfs. If [url] is blank, try [candidateRootfsUrls] in order until one works. */
    private fun installProotRootfs(url: String?, log: StringBuilder): Boolean {
        val urls = if (url.isNullOrBlank()) candidateRootfsUrls() else listOf(url)
        log.appendLine("Device arch: ${deviceArchLabel()}")
        for (candidate in urls) {
            log.appendLine("Trying: $candidate")
            if (downloadAndExtractRootfs(candidate, log)) return true
            log.appendLine("(failed, trying next if any)")
        }
        log.appendLine("All rootfs sources failed. Pass a working rootfs .tar.gz URL explicitly.")
        return false
    }

    private fun downloadAndExtractRootfs(url: String, log: StringBuilder): Boolean {
        val appCtx = appContext.reactContext!!
        val rootfs = getProotRootfsDir()
        val cache = File(appCtx.cacheDir, "proot-rootfs.tar.gz")
        rootfs.mkdirs()

        log.appendLine("Downloading rootfs...")
        log.appendLine(url)
        if (!downloadFile(url, cache)) {
            log.appendLine("Download failed"); return false
        }
        log.appendLine("Downloaded: ${cache.length() / 1024 / 1024}MB")
        log.appendLine("Extracting to ${rootfs.absolutePath}/...")

        var count = 0
        try {
            TarArchiveInputStream(GzipCompressorInputStream(BufferedInputStream(FileInputStream(cache)))).use { tar ->
                var entry = tar.nextTarEntry
                val rootCanonical = rootfs.canonicalPath
                while (entry != null) {
                    val name = entry.name.removePrefix("./")
                    if (name.isEmpty()) { entry = tar.nextTarEntry; continue }
                    val out = File(rootfs, name)
                    // Guard against zip-slip / path traversal.
                    if (!out.canonicalPath.startsWith(rootCanonical)) {
                        entry = tar.nextTarEntry; continue
                    }
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        try {
                            FileOutputStream(out).use { fos -> tar.copyTo(fos) }
                            count++
                            // Preserve executable bit from the archive (binaries in /bin, /usr/bin, ...).
                            val mode = entry.mode
                            if (mode and 0b001001001 != 0) {
                                out.setExecutable(true, false)
                            }
                        } catch (_: Exception) {}
                    }
                    entry = tar.nextTarEntry
                }
            }
            cache.delete()
            log.appendLine("Extracted $count files")
            val ok = File(rootfs, "bin").isDirectory
            log.appendLine(if (ok) "✓ rootfs ready" else "✗ rootfs incomplete")
            return ok
        } catch (e: Exception) {
            log.appendLine("Error: ${e.message}")
            return false
        }
    }

    private fun isBootstrapInstalled(): Boolean {
        val prefix = getPrefix()
        val bash = File(prefix, "bin/bash")
        val apt = File(prefix, "bin/apt")
        val dpkg = File(prefix, "bin/dpkg")
        val sourcesList = File(prefix, "etc/apt/sources.list")
        return bash.exists() && apt.exists() && dpkg.exists() && sourcesList.exists()
    }

    /** Скопировать бинарники в exec-capable директорию */
    private fun ensurePermissions() {
        val appCtx = appContext.reactContext!!
        val prefix = getPrefix()
        val execDir = appCtx.getDir("exec", android.content.Context.MODE_PRIVATE)
        val execBin = File(execDir, "bin")
        execBin.mkdirs()

        // Логируем пути
        android.util.Log.d("AptManager", "prefix: $prefix")
        android.util.Log.d("AptManager", "execDir: ${execDir.absolutePath}")
        android.util.Log.d("AptManager", "execBin: ${execBin.absolutePath}")

        // Копируем все бинарники из prefix/bin в execBin
        val srcBin = File(prefix, "bin")
        android.util.Log.d("AptManager", "srcBin exists: ${srcBin.exists()}")
        if (srcBin.exists()) {
            val files = srcBin.listFiles()
            android.util.Log.d("AptManager", "srcBin files count: ${files?.size ?: 0}")
            files?.forEach { file ->
                val dest = File(execBin, file.name)
                if (!dest.exists() || file.lastModified() > dest.lastModified()) {
                        try {
                        file.copyTo(dest, overwrite = true)
                        dest.setExecutable(true, false)
                        try { android.system.Os.chmod(dest.absolutePath, 0b111000000) } catch (e: Exception) {
                            android.util.Log.e("AptManager", "chmod 0700 failed for ${file.name}: ${e.message}")
                        }
                        android.util.Log.d("AptManager", "Copied ${file.name} -> ${dest.absolutePath}, canExecute=${dest.canExecute()}")
                    } catch (e: Exception) {
                        android.util.Log.e("AptManager", "Copy failed for ${file.name}: ${e.message}")
                    }
                }
            }
        }

        // Также копируем lib (для shared libraries)
        val execLib = File(execDir, "lib")
        execLib.mkdirs()
        val srcLib = File(prefix, "lib")
        if (srcLib.exists()) {
            srcLib.listFiles()?.filter { it.isFile }?.forEach { file ->
                val dest = File(execLib, file.name)
                if (!dest.exists() || file.lastModified() > dest.lastModified()) {
                    try {
                        file.copyTo(dest, overwrite = true)
                        dest.setExecutable(true, false)
                        try { android.system.Os.chmod(dest.absolutePath, 0b111000000) } catch (_: Exception) {}
                    } catch (_: Exception) {}
                }
            }
        }

        android.util.Log.d("AptManager", "ensurePermissions complete")
    }

    private fun downloadFile(urlStr: String, dest: File): Boolean {
        return try {
            var url = URL(urlStr)
            var conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 120000
            conn.instanceFollowRedirects = true
            var redirects = 0
            while (redirects < 10) {
                val code = conn.responseCode
                if (code in listOf(301, 302, 307, 308)) {
                    val loc = conn.getHeaderField("Location") ?: break
                    url = URL(url, loc)
                    conn = url.openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 15000
                    conn.readTimeout = 120000
                    redirects++
                } else break
            }
            if (conn.responseCode != 200) return false
            conn.inputStream.use { input ->
                FileOutputStream(dest).use { output -> input.copyTo(output, 8192) }
            }
            dest.length() > 0
        } catch (_: Exception) { false }
    }

    private fun installBootstrap(log: StringBuilder): Boolean {
        val appCtx = appContext.reactContext!!
        val prefix = File(getPrefix())
        val home = File(getHome())
        val tmpDir = File(prefix, "tmp")
        val cacheDir = File(appCtx.cacheDir, "apt-cache")
        cacheDir.mkdirs(); prefix.mkdirs(); home.mkdirs(); tmpDir.mkdirs()

        val zipFile = File(cacheDir, "bootstrap-aarch64.zip")
        log.appendLine("Downloading Termux bootstrap...")

        if (!downloadFile(BOOTSTRAP_URL, zipFile)) {
            log.appendLine("Download failed"); return false
        }
        log.appendLine("Downloaded: ${zipFile.length() / 1024 / 1024}MB")
        log.appendLine("Extracting to ${prefix.absolutePath}/...")

        var extractedCount = 0
        val symlinks = mutableListOf<Pair<String, String>>()

        try {
            ZipInputStream(FileInputStream(zipFile)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name == "SYMLINKS.txt") {
                        val text = zip.bufferedReader().readText()
                        text.lines().filter { it.contains("\u2190") }.forEach { line ->
                            val parts = line.split("\u2190")
                            if (parts.size == 2) {
                                symlinks.add(Pair(parts[1].trim().removePrefix("./"), parts[0].trim()))
                            }
                        }
                        entry = zip.nextEntry; continue
                    }
                    if (name.isEmpty() || name == "./" || name == ".") { entry = zip.nextEntry; continue }

                    val destFile = File(prefix, name)
                    if (entry.isDirectory) {
                        destFile.mkdirs()
                    } else {
                        destFile.parentFile?.mkdirs()
                        try {
                            FileOutputStream(destFile).use { fos -> zip.copyTo(fos) }
                            extractedCount++
                            if (name.startsWith("bin/") || name.startsWith("lib/apt/")) {
                                destFile.setExecutable(true, false)
                                try { android.system.Os.chmod(destFile.absolutePath, 0b111000000) } catch (_: Exception) {}
                            }
                        } catch (_: Exception) {}
                    }
                    entry = zip.nextEntry
                }
            }

            log.appendLine("Extracted $extractedCount files")

            // Symlinks
            var linksCreated = 0
            for ((linkPath, target) in symlinks) {
                val linkFile = File(prefix, linkPath)
                linkFile.parentFile?.mkdirs()
                if (linkFile.exists()) linkFile.delete()
                try {
                    ProcessBuilder("ln", "-sf", target, linkFile.absolutePath).redirectErrorStream(true).start().waitFor()
                    linksCreated++
                } catch (_: Exception) {}
            }
            log.appendLine("Created $linksCreated symlinks")

            zipFile.delete()

            // chmod — через Java Os.chmod для каждого файла (надёжнее чем shell chmod)
            var chmodCount = 0
            val binDir = File(prefix, "bin")
            if (binDir.exists()) {
                binDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111000000) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            val libDir = File(prefix, "lib")
            if (libDir.exists()) {
                libDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111000000) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            val libexecDir = File(prefix, "libexec")
            if (libexecDir.exists()) {
                libexecDir.walkTopDown().filter { it.isFile }.forEach { file ->
                    file.setExecutable(true, false)
                    try { android.system.Os.chmod(file.absolutePath, 0b111000000) } catch (_: Exception) {}
                    chmodCount++
                }
            }
            log.appendLine("chmod: $chmodCount files made executable")

            val bash = File(prefix, "bin/bash")
            val apt = File(prefix, "bin/apt")
            log.appendLine("bash: exists=${bash.exists()} canExec=${bash.canExecute()}")
            log.appendLine("apt: exists=${apt.exists()} canExec=${apt.canExecute()}")
            log.appendLine("sources.list: ${File(prefix, "etc/apt/sources.list").exists()}")

            return bash.exists() && bash.canExecute()
        } catch (e: Exception) {
            log.appendLine("Error: ${e.message}")
            return false
        }
    }

    private fun runShellCmd(cmd: String): Map<String, Any> {
        val prefix = getPrefix()
        val home = getHome()
        val tmpDir = "$prefix/tmp"
        val fullCmd = "export PREFIX=\"$prefix\" && export HOME=\"$home\" && export TMPDIR=\"$tmpDir\" && " +
            "export PATH=\"$prefix/bin:\$PATH\" && export LD_LIBRARY_PATH=\"$prefix/lib:\$LD_LIBRARY_PATH\" && " +
            "export TERM=xterm-256color && $cmd 2>&1"
        return try {
            val process = ProcessBuilder("sh", "-c", fullCmd).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            mapOf("success" to (exitCode == 0), "exitCode" to exitCode, "output" to output)
        } catch (e: Exception) {
            mapOf("success" to false, "exitCode" to -1, "output" to ("Error: " + e.message))
        }
    }

    private fun loadInstalled(): MutableMap<String, String> {
        val db = File(appContext.reactContext!!.filesDir, ".apt_installed.json")
        if (!db.exists()) return mutableMapOf()
        try {
            val map = mutableMapOf<String, String>()
            """"(\S+)"\s*:\s*"([^"]*)"""".toRegex().findAll(db.readText()).forEach { map[it.groupValues[1]] = it.groupValues[2] }
            return map
        } catch (_: Exception) { return mutableMapOf() }
    }

    private fun saveInstalled(installed: Map<String, String>) {
        val json = "{\n" + installed.entries.joinToString(",\n") { "  \"${it.key}\": \"${it.value}\"" } + "\n}"
        File(appContext.reactContext!!.filesDir, ".apt_installed.json").writeText(json)
    }

    override fun definition() = ModuleDefinition {
        Name("AptManager")

        AsyncFunction("isBootstrapInstalled") Coroutine { ->
            withContext(Dispatchers.IO) { isBootstrapInstalled() }
        }

        AsyncFunction("ensurePermissions") Coroutine { ->
            withContext(Dispatchers.IO) {
                ensurePermissions()
                mapOf("success" to true)
            }
        }

        AsyncFunction("getExecBinDir") Coroutine { ->
            withContext(Dispatchers.IO) {
                val appCtx = appContext.reactContext!!
                val execDir = appCtx.getDir("exec", android.content.Context.MODE_PRIVATE)
                val execBin = File(execDir, "bin")
                mapOf("path" to execBin.absolutePath)
            }
        }

        AsyncFunction("installBootstrap") Coroutine { ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()
                val ok = installBootstrap(log)
                mapOf("success" to ok, "output" to log.toString())
            }
        }

        AsyncFunction("install") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()

                if (!isBootstrapInstalled()) {
                    val bootstrapOk = installBootstrap(log)
                    if (!bootstrapOk) {
                        mapOf("success" to false, "output" to log.toString())
                    } else {
                        log.appendLine("")
                        log.appendLine("Installing $packageName...")
                        val result = runShellCmd("pkg install -y $packageName")
                        log.append(result["output"] as? String ?: "")
                        if (result["success"] == true) {
                            val installed = loadInstalled()
                            installed[packageName] = "installed"
                            saveInstalled(installed)
                            log.appendLine("✓ $packageName installed")
                        }
                        mapOf("success" to result["success"], "output" to log.toString())
                    }
                } else {
                    // Bootstrap уже установлен — убедиться что permissions правильные
                    ensurePermissions()
                    log.appendLine("Bootstrap already installed, permissions verified.")
                    log.appendLine("Installing $packageName...")
                    val result = runShellCmd("pkg install -y $packageName")
                    log.append(result["output"] as? String ?: "")
                    if (result["success"] == true) {
                        val installed = loadInstalled()
                        installed[packageName] = "installed"
                        saveInstalled(installed)
                        log.appendLine("✓ $packageName installed")
                    }
                    mapOf("success" to result["success"], "output" to log.toString())
                }
            }
        }

        AsyncFunction("remove") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                val result = runShellCmd("pkg uninstall -y $packageName")
                if (result["success"] == true) {
                    val installed = loadInstalled()
                    installed.remove(packageName)
                    saveInstalled(installed)
                }
                result
            }
        }

        AsyncFunction("search") Coroutine { query: String ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed. Open Terminal to install.")
                } else {
                    runShellCmd("apt search $query")
                }
            }
        }

        AsyncFunction("info") Coroutine { packageName: String ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed.")
                } else {
                    runShellCmd("apt show $packageName")
                }
            }
        }

        AsyncFunction("update") Coroutine { ->
            withContext(Dispatchers.IO) {
                if (!isBootstrapInstalled()) {
                    mapOf("success" to false, "output" to "Bootstrap not installed.")
                } else {
                    runShellCmd("apt update")
                }
            }
        }

        AsyncFunction("listInstalled") Coroutine { ->
            withContext(Dispatchers.IO) {
                val installed = loadInstalled()
                installed.entries.map { mapOf("name" to it.key, "version" to it.value) }
            }
        }

        AsyncFunction("getPrefix") Coroutine { ->
            withContext(Dispatchers.IO) { mapOf("prefix" to getPrefix()) }
        }

        AsyncFunction("getHome") Coroutine { ->
            withContext(Dispatchers.IO) { mapOf("home" to getHome()) }
        }

        // proot rootfs management
        AsyncFunction("isProotRootfsInstalled") Coroutine { ->
            withContext(Dispatchers.IO) { isProotRootfsInstalled() }
        }

        AsyncFunction("getProotRootfsDir") Coroutine { ->
            withContext(Dispatchers.IO) { mapOf("path" to getProotRootfsDir().absolutePath) }
        }

        AsyncFunction("installProotRootfs") Coroutine { url: String? ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()
                val ok = installProotRootfs(url, log)
                mapOf("success" to ok, "output" to log.toString())
            }
        }

        AsyncFunction("whichCommand") Coroutine { command: String ->
            withContext(Dispatchers.IO) {
                val prefix = getPrefix()
                val binPath = File(prefix, "bin/$command")
                if (binPath.exists() && binPath.canExecute()) {
                    mapOf("exists" to true, "path" to binPath.absolutePath)
                } else {
                    try {
                        val p = ProcessBuilder("sh", "-c", "PATH=\"$prefix/bin:\$PATH\" which $command 2>/dev/null")
                            .redirectErrorStream(true).start()
                        val path = p.inputStream.bufferedReader().readText().trim()
                        p.waitFor()
                        mapOf("exists" to (p.exitValue() == 0 && path.isNotEmpty()), "path" to path)
                    } catch (_: Exception) {
                        mapOf("exists" to false, "path" to "")
                    }
                }
            }
        }
    }
}
