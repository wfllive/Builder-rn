package expo.modules.aptmanager

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.font.FontStyle
import android.webkit.WebView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Real Jetpack Compose renderer used by the IDE preview.
 *
 * It does not translate components to Android Views.  The same Material 3
 * composables that the generator emits are composed in an off-screen
 * ComposeView and then captured.  The visual model is deliberately the input:
 * compiling arbitrary Kotlin text safely inside an editor is a separate build
 * operation, while this gives design edits immediate, genuine Compose output.
 */
object ComposeRuntimePreview {
    fun render(activity: Activity, treeJson: String, widthPx: Int, heightPx: Int, dark: Boolean): String {
        val root = JSONObject(treeJson)
        val view = ComposeView(activity)
        if (activity is ComponentActivity) {
            view.setViewTreeLifecycleOwner(activity)
            // A snapshot has no ViewModel state: it only needs lifecycle and
            // saved-state owners to host the off-screen Compose composition.
            view.setViewTreeSavedStateRegistryOwner(activity)
        }
        view.setContent {
            MaterialTheme(colorScheme = if (dark) androidx.compose.material3.darkColorScheme() else androidx.compose.material3.lightColorScheme()) {
                ComposeNode(root)
            }
        }
        // ComposeView needs an attached window to create its composition. Add
        // it briefly to the IDE activity's content host, then capture it
        // directly to a bitmap and remove it again. The host position remains
        // off-screen, so this never flashes over the editor UI.
        val host = activity.findViewById<ViewGroup>(android.R.id.content)
            ?: error("Preview host is unavailable")
        view.translationX = -10000f
        host.addView(view, ViewGroup.LayoutParams(1, 1))
        try {
            view.measure(
                View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.AT_MOST),
            )
            view.layout(0, 0, view.measuredWidth, view.measuredHeight)
            val bitmap = Bitmap.createBitmap(view.measuredWidth.coerceAtLeast(1), view.measuredHeight.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            bitmap.recycle()
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            host.removeView(view)
            view.disposeComposition()
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable private fun ComposeNode(node: JSONObject) {
        val props = node.optJSONObject("props") ?: JSONObject()
        val type = when (node.optString("type")) { "Scafold" -> "Scaffold"; else -> node.optString("type", "Column") }
        val children = node.optJSONArray("children") ?: JSONArray()
        val modifier = modifier(props)
        when (type) {
            "Column" -> Column(modifier, verticalArrangement = Arrangement.spacedBy(num(props, "spacing", 0f).dp)) { Children(children) }
            "LazyColumn" -> LazyColumn(modifier, verticalArrangement = Arrangement.spacedBy(num(props, "spacing", 0f).dp)) { items(children.length()) { index -> ComposeNode(children.getJSONObject(index)) } }
            "Row" -> Row(modifier, horizontalArrangement = Arrangement.spacedBy(num(props, "spacing", 0f).dp), verticalAlignment = Alignment.CenterVertically) { Children(children) }
            "Box" -> Box(modifier) { Children(children) }
            "Card" -> {
                val bgProp = props.optString("backgroundColor", "")
                val container = if (bgProp.isNotBlank() && bgProp != "transparent") color(props, "backgroundColor", MaterialTheme.colorScheme.surface) else MaterialTheme.colorScheme.surface
                Card(modifier, shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp), colors = CardDefaults.cardColors(containerColor = container)) { Column(Modifier.padding(num(props, "padding", 0f).dp)) { Children(children) } }
            }
            "ElevatedCard" -> {
                val bgProp = props.optString("backgroundColor", "")
                val container = if (bgProp.isNotBlank() && bgProp != "transparent") color(props, "backgroundColor", MaterialTheme.colorScheme.surface) else MaterialTheme.colorScheme.surface
                ElevatedCard(modifier, shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp), colors = CardDefaults.elevatedCardColors(containerColor = container)) { Column(Modifier.padding(num(props, "padding", 0f).dp)) { Children(children) } }
            }
            "Scaffold" -> Scaffold(modifier = modifier, topBar = { props.optJSONObject("topBar")?.let { ComposeNode(it) } }) { padding -> Column(Modifier.padding(padding)) { Children(children) } }
            "TopAppBar" -> {
                val titleText = props.optString("title", "MyApp")
                val container = color(props, "backgroundColor", MaterialTheme.colorScheme.primary)
                val titleColor = color(props, "textColor", MaterialTheme.colorScheme.onPrimary)
                TopAppBar(title = { Text(titleText, fontSize = num(props, "textSize", 20f).sp, fontWeight = FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = container, titleContentColor = titleColor))
            }
            "Text" -> {
                val textValue = props.optString("text", "")
                val styleProp = props.optString("textStyle", "")
                val size = num(props, "textSize", 16f)
                val weight = when (styleProp) { "bold" -> FontWeight.Bold; "medium" -> FontWeight.Medium; else -> FontWeight.Normal }
                val style = when (styleProp) { "headline" -> MaterialTheme.typography.headlineSmall; "title" -> MaterialTheme.typography.titleMedium; "label" -> MaterialTheme.typography.labelLarge; else -> MaterialTheme.typography.bodyMedium }
                val align = when (props.optString("textAlign")) { "center" -> TextAlign.Center; "end" -> TextAlign.End; else -> TextAlign.Start }
                Text(textValue, modifier = modifier, color = color(props, "textColor", MaterialTheme.colorScheme.onSurface), fontSize = size.sp, fontWeight = weight, fontStyle = if (props.optString("textStyle") == "italic") FontStyle.Italic else FontStyle.Normal, textAlign = align, style = if (styleProp == "headline" || styleProp == "title" || styleProp == "label") style else MaterialTheme.typography.bodyMedium)
            }
            "Button" -> {
                val text = props.optString("text", "").ifBlank { 
                    val childText = (0 until children.length()).map { children.getJSONObject(it) }.filter { it.optString("type") == "Text" }.firstOrNull()?.optString("text", "") ?: ""
                    childText.ifBlank { "Кнопка" }
                }
                val bg = props.optString("backgroundColor", "")
                val txtColor = props.optString("textColor", "")
                val container = if (bg.isNotBlank() && bg != "transparent") color(props, "backgroundColor", MaterialTheme.colorScheme.primary) else MaterialTheme.colorScheme.primary
                val content = if (txtColor.isNotBlank()) color(props, "textColor", MaterialTheme.colorScheme.onPrimary) else MaterialTheme.colorScheme.onPrimary
                Button(onClick = {}, modifier = modifier, shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp), colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)) { Text(text, fontSize = num(props, "textSize", 15f).sp) }
            }
            "OutlinedButton" -> {
                val text = props.optString("text", "").ifBlank { 
                    val childText = (0 until children.length()).map { children.getJSONObject(it) }.filter { it.optString("type") == "Text" }.firstOrNull()?.optString("text", "") ?: ""
                    childText.ifBlank { "Кнопка" }
                }
                val txtColor = props.optString("textColor", "")
                val content = if (txtColor.isNotBlank()) color(props, "textColor", MaterialTheme.colorScheme.primary) else MaterialTheme.colorScheme.primary
                OutlinedButton(onClick = {}, modifier = modifier, shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp)) { Text(text, color = content, fontSize = num(props, "textSize", 15f).sp) }
            }
            "OutlinedTextField" -> OutlinedTextField(value = props.optString("text", ""), onValueChange = {}, modifier = modifier, label = { Text(props.optString("label", "")) }, placeholder = { Text(props.optString("hint", "")) }, singleLine = props.optBoolean("singleLine", true))
            "Image" -> Box(modifier.background(color(props, "backgroundColor", Color(0xFFE5E7EB))), contentAlignment = Alignment.Center) { Text(props.optString("contentDescription", "Image"), color = Color(0xFF64748B)) }
            "Checkbox" -> Row(modifier, verticalAlignment = Alignment.CenterVertically) { Checkbox(props.optBoolean("checked", false), {}); Text(props.optString("text", ""), color = color(props, "textColor", MaterialTheme.colorScheme.onSurface)) }
            "Switch" -> Row(modifier, horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(props.optString("text", "")); Switch(props.optBoolean("checked", false), {}) }
            "LinearProgressIndicator" -> LinearProgressIndicator(progress = { num(props, "progress", .5f) }, modifier = modifier.height(num(props, "height", 8f).dp), color = color(props, "color", MaterialTheme.colorScheme.primary), trackColor = color(props, "trackColor", MaterialTheme.colorScheme.surfaceVariant))
            "CircularProgressIndicator" -> CircularProgressIndicator(modifier = modifier.size(num(props, "width", 48f).dp), color = color(props, "color", MaterialTheme.colorScheme.primary))
            "HorizontalDivider" -> Divider(modifier = modifier.height(num(props, "height", 1f).dp), color = color(props, "color", MaterialTheme.colorScheme.outlineVariant))
            "Spacer" -> Spacer(modifier.height(num(props, "height", 16f).dp))
            "Icon" -> Icon(Icons.Filled.Star, contentDescription = props.optString("contentDescription", null), modifier = modifier.size(num(props, "size", 28f).dp), tint = color(props, "tint", MaterialTheme.colorScheme.primary))
            "WebView" -> AndroidView(factory = { WebView(it).apply { settings.javaScriptEnabled = false; loadUrl(props.optString("url", "https://example.com")) } }, modifier = modifier)
            else -> Box(modifier) { Children(children) } // no fake Unsupported node in a real preview
        }
    }

    @Composable private fun Children(children: JSONArray) { for (i in 0 until children.length()) ComposeNode(children.getJSONObject(i)) }
    private fun num(p: JSONObject, key: String, fallback: Float): Float = p.optDouble(key, fallback.toDouble()).toFloat()
    private fun color(p: JSONObject, key: String, fallback: Color): Color = try { Color(AndroidColor.parseColor(p.optString(key))) } catch (_: Exception) { fallback }
    private fun modifier(p: JSONObject): Modifier {
        var m: Modifier = Modifier
        when (p.opt("width")) { "match_parent" -> m = m.fillMaxWidth(); is Number -> m = m.width((p.opt("width") as Number).toFloat().dp) }
        when (p.opt("height")) { "match_parent" -> m = m.fillMaxHeight(); is Number -> m = m.height((p.opt("height") as Number).toFloat().dp) }
        val padding = num(p, "padding", 0f); if (padding > 0) m = m.padding(padding.dp)
        val bg = p.optString("backgroundColor", ""); if (bg.isNotBlank() && bg != "transparent") m = m.background(color(p, "backgroundColor", Color.Transparent))
        return m
    }
}
