@file:OptIn(ExperimentalMaterial3Api::class)

package expo.modules.aptmanager

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Professional real Jetpack Compose preview renderer.
 *
 * Renders the EXACT same visual model that the IDE's .kt generator produces.
 * Uses real Material 3 composables (Scaffold, TopAppBar, Card, TextField, etc)
 * with proper theme, full modifier support, state simulation and accurate layout.
 *
 * This is NOT a View-based approximation — it is genuine Compose running
 * inside an off-screen ComposeView and captured to bitmap.
 */
object ComposeRuntimePreview {

    data class PreviewConfig(
        val widthPx: Int,
        val heightPx: Int,
        val dark: Boolean,
        val backgroundColor: String?,
        val density: Float = 2.625f,
        val projectPrimary: String? = null,
        val projectSecondary: String? = null,
        val projectBackground: String? = null,
        val simulateState: Boolean = true,
        val interactive: Boolean = false,
        val actionBarTitle: String? = null,
        val showActionBar: Boolean = true
    )

    fun render(
        activity: Activity,
        treeJson: String,
        config: PreviewConfig
    ): String {
        val root = try {
            JSONObject(treeJson)
        } catch (e: Exception) {
            return errorBitmap(activity, "Invalid tree JSON", config)
        }

        val view = ComposeView(activity)
        if (activity is ComponentActivity) {
            view.setViewTreeLifecycleOwner(activity)
            view.setViewTreeSavedStateRegistryOwner(activity)
        }

        // Build the full Material theme from project config + dark mode
        view.setContent {
            val colorScheme = buildProfessionalColorScheme(
                dark = config.dark,
                primary = config.projectPrimary,
                secondary = config.projectSecondary,
                background = config.projectBackground
            )

            MaterialTheme(colorScheme = colorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = colorScheme.background
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = (config.widthPx / config.density).dp)
                            .heightIn(max = (config.heightPx / config.density).dp)
                    ) {
                        // Inject config-level actionBarTitle / showActionBar into root props
                        // so Scaffold synthesis always sees the screen metadata (from JS bridge).
                        val enrichedRoot = JSONObject(root.toString())
                        val rootProps = if (enrichedRoot.has("props")) enrichedRoot.optJSONObject("props") ?: JSONObject() else JSONObject()
                        if (config.actionBarTitle != null && config.actionBarTitle.isNotBlank()) {
                            rootProps.put("actionBarTitle", config.actionBarTitle)
                            rootProps.put("title", config.actionBarTitle)
                            rootProps.put("text", config.actionBarTitle)
                        }
                        rootProps.put("showActionBar", config.showActionBar)
                        enrichedRoot.put("props", rootProps)

                        ComposeNode(
                            node = enrichedRoot,
                            config = config,
                            level = 0
                        )
                    }
                }
            }
        }

        val host = activity.findViewById<ViewGroup>(android.R.id.content)
            ?: return errorBitmap(activity, "Preview host unavailable", config)

        view.translationX = -10000f
        host.addView(view, ViewGroup.LayoutParams(1, 1))

        return try {
            // Important: use AT_MOST for height to allow tall content to render fully
            val widthSpec = View.MeasureSpec.makeMeasureSpec(config.widthPx, View.MeasureSpec.EXACTLY)
            val heightSpec = View.MeasureSpec.makeMeasureSpec(config.heightPx, View.MeasureSpec.AT_MOST)

            view.measure(widthSpec, heightSpec)
            view.layout(0, 0, view.measuredWidth, view.measuredHeight)

            val bitmap = Bitmap.createBitmap(
                view.measuredWidth.coerceAtLeast(1),
                view.measuredHeight.coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            view.draw(canvas)

            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            bitmap.recycle()

            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) {
            errorBitmap(activity, "Render error: ${e.message}", config)
        } finally {
            host.removeView(view)
            view.disposeComposition()
        }
    }

    private fun errorBitmap(activity: Activity, message: String, config: PreviewConfig): String {
        return try {
            val w = (config.widthPx / 2).coerceAtLeast(200)
            val h = (config.heightPx / 3).coerceAtLeast(120)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(if (config.dark) AndroidColor.parseColor("#1F2937") else AndroidColor.parseColor("#F8FAFC"))
            val paint = android.graphics.Paint().apply {
                color = AndroidColor.parseColor("#EF4444")
                textSize = 28f
                isAntiAlias = true
            }
            c.drawText("PREVIEW ERROR", 24f, 40f, paint)
            c.drawText(message.take(60), 24f, 78f, paint.apply { textSize = 22f; color = AndroidColor.parseColor("#64748B") })
            Base64.encodeToString(
                ByteArrayOutputStream().apply { bmp.compress(Bitmap.CompressFormat.PNG, 100, this); bmp.recycle() }.toByteArray(),
                Base64.NO_WRAP
            )
        } catch (_: Exception) {
            ""
        }
    }

    @Composable
    private fun buildProfessionalColorScheme(
        dark: Boolean,
        primary: String?,
        secondary: String?,
        background: String?
    ): ColorScheme {
        val base = if (dark) darkColorScheme() else lightColorScheme()

        val projPrimary = safeColor(primary, base.primary)
        val projSecondary = safeColor(secondary, base.secondary)
        val projBackground = safeColor(background, base.background)

        // === ULTRA PROFESSIONAL EXACT MATCH ===
        // Matches the generated Theme.kt + AppTheme exactly:
        // primary/secondary/background from project + complete ColorScheme override
        // (on*, containers, inverse*, surface*, error*, scrim, surfaceTint, etc.)
        val onPrimary = Color.White
        val onSecondary = if (dark) Color(0xFFE2E8F0) else Color(0xFF1E2937)
        val onBackground = if (dark) Color(0xFFE2E8F0) else Color(0xFF0F172A)
        val onSurface = if (dark) Color(0xFFE2E8F0) else Color(0xFF0F172A)
        val onSurfaceVariant = if (dark) Color(0xFF94A3B8) else Color(0xFF475569)
        val surface = if (dark) Color(0xFF1E2937) else Color(0xFFFFFFFF)
        val surfaceVariant = if (dark) Color(0xFF334155) else Color(0xFFF1F5F9)
        val outline = if (dark) Color(0xFF475569) else Color(0xFFCBD5E1)
        val outlineVariant = if (dark) Color(0xFF334155) else Color(0xFFE2E8F0)
        val primaryContainer = projPrimary.copy(alpha = if (dark) 0.38f else 0.16f)
        val secondaryContainer = projSecondary.copy(alpha = if (dark) 0.38f else 0.16f)
        val tertiaryContainer = projSecondary.copy(alpha = if (dark) 0.32f else 0.12f)
        val error = if (dark) Color(0xFFF87171) else Color(0xFFDC2626)
        val errorContainer = if (dark) Color(0xFF7F1D1D) else Color(0xFFFEE2E2)
        val inverseSurface = if (dark) Color(0xFFF1F5F9) else Color(0xFF1E2937)
        val inverseOnSurface = if (dark) Color(0xFF1E2937) else Color(0xFFF1F5F9)
        val inversePrimary = projPrimary

        return base.copy(
            primary = projPrimary,
            onPrimary = onPrimary,
            primaryContainer = primaryContainer,
            onPrimaryContainer = projPrimary,
            inversePrimary = inversePrimary,
            secondary = projSecondary,
            onSecondary = onSecondary,
            secondaryContainer = secondaryContainer,
            onSecondaryContainer = projSecondary,
            tertiary = projSecondary,
            onTertiary = if (dark) Color.White else Color(0xFF0F172A),
            tertiaryContainer = tertiaryContainer,
            onTertiaryContainer = projSecondary,
            background = projBackground,
            onBackground = onBackground,
            surface = surface,
            onSurface = onSurface,
            surfaceVariant = surfaceVariant,
            onSurfaceVariant = onSurfaceVariant,
            surfaceTint = projPrimary,
            inverseSurface = inverseSurface,
            inverseOnSurface = inverseOnSurface,
            error = error,
            onError = Color.White,
            errorContainer = errorContainer,
            onErrorContainer = if (dark) Color(0xFFFCA5A5) else Color(0xFF991B1B),
            outline = outline,
            outlineVariant = outlineVariant,
            scrim = Color.Black.copy(alpha = 0.55f)
        )
    }

    private fun safeColor(hex: String?, fallback: Color): Color {
        if (hex.isNullOrBlank() || hex == "transparent") return fallback
        return try {
            Color(AndroidColor.parseColor(hex))
        } catch (_: Exception) {
            fallback
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ComposeNode(node: JSONObject, config: PreviewConfig, level: Int) {
        if (!node.has("type")) {
            Box(Modifier.fillMaxWidth().height(40.dp)) {
                Text("Invalid node", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
            return
        }

        val type = node.optString("type", "Column")
        val props = node.optJSONObject("props") ?: JSONObject()
        val children = node.optJSONArray("children") ?: JSONArray()

        val mod = buildAdvancedModifier(props, config)

        // === TOP-LEVEL SCAFFOLD SYNTHESIS (for pixel-perfect parity) ===
        // Many trees have a plain Column/Row/Box as root. The generated .kt files almost always
        // wrap the screen body inside a Scaffold + TopAppBar when showActionBar is true.
        // When we are at the root (level==0) and metadata says we need an action bar, synthesize
        // the exact same header so the preview matches the real build 100%.
        if (level == 0) {
            val showActionBar = props.optBoolean("showActionBar", config.showActionBar)
            val titleFromConfigOrProps = listOf(
                config.actionBarTitle ?: "",
                props.optString("actionBarTitle", ""),
                props.optString("title", ""),
                props.optString("text", ""),
                props.optString("name", "")
            ).firstOrNull { it.isNotBlank() } ?: ""

            if (showActionBar && titleFromConfigOrProps.isNotBlank() && type != "Scaffold" && type != "Scafold") {
                // Render a real Scaffold + TopAppBar around the actual content root.
                // This produces the exact visual that the generator emits.
                Scaffold(
                    modifier = mod,
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    text = titleFromConfigOrProps,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    },
                    containerColor = safeColor(props.optString("backgroundColor"), MaterialTheme.colorScheme.background)
                ) { innerPadding ->
                    // Render original node content inside the scaffold padding
                    Column(
                        Modifier
                            .padding(innerPadding)
                            .fillMaxSize()
                    ) {
                        // Re-render the original node as content (avoid infinite recursion by calling with level+1)
                        when (type) {
                            "Column" -> {
                                Column(
                                    modifier = buildAdvancedModifier(props, config),
                                    verticalArrangement = spacedByOrTop(props),
                                    horizontalAlignment = horizontalAlignment(props)
                                ) { Children(children, config, level + 1) }
                            }
                            "Row" -> {
                                Row(
                                    modifier = buildAdvancedModifier(props, config),
                                    horizontalArrangement = spacedByOrStart(props),
                                    verticalAlignment = verticalAlignment(props)
                                ) { Children(children, config, level + 1) }
                            }
                            else -> {
                                // Fallback: just render children or the node itself
                                ComposeNode(node, config, level + 1)
                            }
                        }
                    }
                }
                return
            }
        }

        when (type) {
            "Scaffold", "Scafold" -> {
                val scaffoldBg = safeColor(props.optString("backgroundColor"), MaterialTheme.colorScheme.background)
                // Honor injected config + root props for exact match to generated Activity
                val showActionBar = props.optBoolean("showActionBar", config.showActionBar)

                // Professional: synthesize real TopAppBar from screen metadata when missing.
                // Priority: config (from JS) > root props (actionBarTitle/title/text/name) > default
                val hasExplicitTopBar = props.has("topBar") && props.optJSONObject("topBar") != null
                val screenTitle = listOf(
                    config.actionBarTitle ?: "",
                    props.optString("actionBarTitle", ""),
                    props.optString("title", ""),
                    props.optString("text", ""),
                    props.optString("name", "")
                ).firstOrNull { it.isNotBlank() } ?: ""

                Scaffold(
                    modifier = mod,
                    topBar = {
                        if (!showActionBar) return@Scaffold

                        when {
                            hasExplicitTopBar -> {
                                props.optJSONObject("topBar")?.let { ComposeNode(it, config, level + 1) }
                            }
                            screenTitle.isNotBlank() -> {
                                TopAppBar(
                                    title = {
                                        Text(
                                            text = screenTitle,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        titleContentColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                            else -> Unit
                        }
                    },
                    containerColor = scaffoldBg
                ) { innerPadding ->
                    Column(
                        Modifier
                            .padding(innerPadding)
                            .then(buildAdvancedModifier(props, config))
                    ) {
                        Children(children, config, level)
                    }
                }
            }

            "TopAppBar" -> {
                // Extremely robust + priority title extraction
                val titleText = listOf(
                    props.optString("actionBarTitle", ""),
                    props.optString("title", ""),
                    props.optString("text", ""),
                    props.optString("name", "")
                ).firstOrNull { it.isNotBlank() } ?: "App"

                val bg = safeColor(props.optString("backgroundColor"), MaterialTheme.colorScheme.primary)
                val fg = safeColor(props.optString("textColor"), MaterialTheme.colorScheme.onPrimary)
                val textSize = num(props, "textSize", 20f)

                TopAppBar(
                    title = {
                        Text(
                            text = titleText,
                            color = fg,
                            fontSize = textSize.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = bg,
                        titleContentColor = fg,
                        navigationIconContentColor = fg,
                        actionIconContentColor = fg
                    ),
                    modifier = mod
                )
            }

            "Column" -> {
                Column(
                    modifier = mod,
                    verticalArrangement = spacedByOrTop(props),
                    horizontalAlignment = horizontalAlignment(props)
                ) {
                    Children(children, config, level)
                }
            }

            "Row" -> {
                Row(
                    modifier = mod,
                    horizontalArrangement = spacedByOrStart(props),
                    verticalAlignment = verticalAlignment(props)
                ) {
                    Children(children, config, level)
                }
            }

            "LazyColumn" -> {
                LazyColumn(
                    modifier = mod,
                    verticalArrangement = spacedByOrTop(props)
                ) {
                    items(children.length()) { idx ->
                        ComposeNode(children.getJSONObject(idx), config, level + 1)
                    }
                }
            }

            "LazyRow" -> {
                LazyRow(
                    modifier = mod,
                    horizontalArrangement = spacedByOrStart(props)
                ) {
                    items(children.length()) { idx ->
                        ComposeNode(children.getJSONObject(idx), config, level + 1)
                    }
                }
            }

            "Box" -> {
                Box(
                    modifier = mod,
                    contentAlignment = contentAlignment(props)
                ) {
                    Children(children, config, level)
                }
            }

            "Card", "ElevatedCard" -> {
                val shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp)
                val elevation = num(props, "elevation", if (type == "ElevatedCard") 6f else 2f).dp
                val containerColor = safeColor(
                    props.optString("backgroundColor"),
                    if (type == "ElevatedCard") MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                )

                Card(
                    modifier = mod.then(Modifier.shadow(elevation, shape)),
                    shape = shape,
                    colors = CardDefaults.cardColors(containerColor = containerColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = elevation)
                ) {
                    Column(Modifier.padding(num(props, "padding", 12f).dp)) {
                        Children(children, config, level)
                    }
                }
            }

            "Surface" -> {
                Surface(
                    modifier = mod,
                    shape = RoundedCornerShape(num(props, "borderRadius", 0f).dp),
                    color = safeColor(props.optString("backgroundColor"), MaterialTheme.colorScheme.surface),
                    tonalElevation = num(props, "elevation", 1f).dp
                ) {
                    Children(children, config, level)
                }
            }

            "Text" -> {
                val text = props.optString("text", "")
                val size = num(props, "textSize", 16f)
                val weight = when (props.optString("textStyle")) {
                    "bold" -> FontWeight.Bold
                    "medium" -> FontWeight.Medium
                    else -> FontWeight.Normal
                }
                val style = when (props.optString("textStyle")) {
                    "headline" -> MaterialTheme.typography.headlineSmall
                    "title" -> MaterialTheme.typography.titleMedium
                    "label" -> MaterialTheme.typography.labelLarge
                    else -> MaterialTheme.typography.bodyMedium
                }
                val color = safeColor(props.optString("textColor"), MaterialTheme.colorScheme.onSurface)
                val align = when (props.optString("textAlign")) {
                    "center" -> TextAlign.Center
                    "end" -> TextAlign.End
                    else -> TextAlign.Start
                }

                Text(
                    text = text,
                    modifier = mod,
                    color = color,
                    fontSize = size.sp,
                    fontWeight = weight,
                    fontStyle = if (props.optString("textStyle") == "italic") FontStyle.Italic else FontStyle.Normal,
                    textAlign = align,
                    style = style,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis
                )
            }

            "Button" -> {
                val text = resolveButtonText(props, children)
                val bg = safeColor(props.optString("backgroundColor"), MaterialTheme.colorScheme.primary)
                val contentColor = safeColor(props.optString("textColor"), MaterialTheme.colorScheme.onPrimary)
                val shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp)
                val textSize = num(props, "textSize", 15f)

                // Professional exact match to generator Button:
                // - contentPadding matches generated .kt
                // - SemiBold label
                // - elevation + shape like typical AppTheme Button
                Button(
                    onClick = {},
                    modifier = mod,
                    shape = shape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = bg,
                        contentColor = contentColor
                    ),
                    elevation = ButtonDefaults.buttonElevation(
                        defaultElevation = 2.dp,
                        pressedElevation = 1.dp
                    ),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = text,
                        fontSize = textSize.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            "OutlinedButton" -> {
                val text = resolveButtonText(props, children)
                val shape = RoundedCornerShape(num(props, "borderRadius", 12f).dp)

                OutlinedButton(
                    onClick = {},
                    modifier = mod,
                    shape = shape,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text,
                        color = safeColor(props.optString("textColor"), MaterialTheme.colorScheme.primary),
                        fontSize = num(props, "textSize", 15f).sp
                    )
                }
            }

            "TextField", "OutlinedTextField" -> {
                var value by remember { mutableStateOf(props.optString("text", "")) }

                OutlinedTextField(
                    value = value,
                    onValueChange = { if (config.simulateState) value = it },
                    modifier = mod,
                    label = { if (props.has("label")) Text(props.optString("label")) },
                    placeholder = { if (props.has("hint")) Text(props.optString("hint")) },
                    singleLine = props.optBoolean("singleLine", true),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    )
                )
            }

            "Image" -> {
                val w = num(props, "width", 120f).dp
                val h = num(props, "height", 120f).dp
                val bg = safeColor(props.optString("backgroundColor"), Color(0xFFE5E7EB))

                Box(
                    modifier = mod
                        .size(w, h)
                        .background(bg, RoundedCornerShape(num(props, "borderRadius", 8f).dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Image,
                        contentDescription = props.optString("contentDescription", "Image"),
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            "Checkbox" -> {
                var checked by remember { mutableStateOf(props.optBoolean("checked", false)) }
                Row(
                    modifier = mod,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { if (config.simulateState) checked = it }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(props.optString("text", ""), color = MaterialTheme.colorScheme.onSurface)
                }
            }

            "Switch" -> {
                var checked by remember { mutableStateOf(props.optBoolean("checked", false)) }
                Row(
                    modifier = mod,
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(props.optString("text", ""))
                    Switch(
                        checked = checked,
                        onCheckedChange = { if (config.simulateState) checked = it }
                    )
                }
            }

            "LinearProgressIndicator" -> {
                val progress = (num(props, "progress", 0.5f)).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = mod.height(num(props, "height", 6f).dp),
                    color = safeColor(props.optString("color"), MaterialTheme.colorScheme.primary),
                    trackColor = safeColor(props.optString("trackColor"), MaterialTheme.colorScheme.surfaceVariant)
                )
            }

            "CircularProgressIndicator" -> {
                CircularProgressIndicator(
                    modifier = mod.size(num(props, "width", 42f).dp),
                    color = safeColor(props.optString("color"), MaterialTheme.colorScheme.primary),
                    strokeWidth = 4.dp
                )
            }

            "HorizontalDivider" -> {
                HorizontalDivider(
                    modifier = mod.height(num(props, "height", 1f).dp),
                    color = safeColor(props.optString("color"), MaterialTheme.colorScheme.outlineVariant),
                    thickness = num(props, "height", 1f).dp
                )
            }

            "Spacer" -> {
                Spacer(modifier = mod.height(num(props, "height", 16f).dp))
            }

            "Icon" -> {
                val iconName = props.optString("iconName", "Star")
                val size = num(props, "size", 28f).dp
                val tint = safeColor(props.optString("tint"), MaterialTheme.colorScheme.primary)

                Icon(
                    imageVector = iconForName(iconName),
                    contentDescription = props.optString("contentDescription", null),
                    modifier = mod.size(size),
                    tint = tint
                )
            }

            "WebView" -> {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = false
                            loadUrl(props.optString("url", "https://example.com"))
                        }
                    },
                    modifier = mod.height(num(props, "height", 180f).dp)
                )
            }

            else -> {
                // Fallback: render as column of children + label
                Column(modifier = mod) {
                    Text(
                        "[$type]",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.padding(4.dp)
                    )
                    Children(children, config, level)
                }
            }
        }
    }

    @Composable
    private fun Children(children: JSONArray, config: PreviewConfig, level: Int) {
        for (i in 0 until children.length()) {
            val child = try {
                children.getJSONObject(i)
            } catch (_: Exception) {
                continue
            }
            ComposeNode(child, config, level + 1)
        }
    }

    private fun buildAdvancedModifier(props: JSONObject, config: PreviewConfig): Modifier {
        var m: Modifier = Modifier

        // Width / Height
        when (val w = props.opt("width")) {
            "match_parent", "fillMaxWidth" -> m = m.fillMaxWidth()
            is Number -> m = m.width(w.toFloat().dp)
            is String -> if (w.matches(Regex("\\d+(\\.\\d+)?"))) m = m.width(w.toFloat().dp)
        }
        when (val h = props.opt("height")) {
            "match_parent", "fillMaxHeight" -> m = m.fillMaxHeight()
            is Number -> m = m.height(h.toFloat().dp)
            is String -> if (h.matches(Regex("\\d+(\\.\\d+)?"))) m = m.height(h.toFloat().dp)
        }

        // Padding
        val pad = num(props, "padding", 0f)
        if (pad > 0) m = m.padding(pad.dp)

        // Background
        val bg = props.optString("backgroundColor", "")
        if (bg.isNotBlank() && bg != "transparent") {
            m = m.background(safeColor(bg, Color.Transparent))
        }

        // Border radius (clip)
        val radius = num(props, "borderRadius", 0f)
        if (radius > 0) {
            m = m.clip(RoundedCornerShape(radius.dp))
        }

        // Elevation / shadow
        val elev = num(props, "elevation", 0f)
        if (elev > 0) {
            val r = radius.dp.coerceAtLeast(4.dp)
            m = m.shadow(elev.dp, RoundedCornerShape(r))
        }

        // Clickable simulation
        if (props.has("onClick")) {
            m = m.clickable { /* no-op in static preview */ }
        }

        return m
    }

    private fun spacedByOrTop(props: JSONObject) =
        if (props.has("spacing")) Arrangement.spacedBy(num(props, "spacing", 0f).dp) else Arrangement.Top

    private fun spacedByOrStart(props: JSONObject) =
        if (props.has("spacing")) Arrangement.spacedBy(num(props, "spacing", 0f).dp) else Arrangement.Start

    private fun horizontalAlignment(props: JSONObject): Alignment.Horizontal {
        return when (props.optString("horizontalAlignment", "start")) {
            "center" -> Alignment.CenterHorizontally
            "end" -> Alignment.End
            else -> Alignment.Start
        }
    }

    private fun verticalAlignment(props: JSONObject): Alignment.Vertical {
        return when (props.optString("verticalAlignment", "top")) {
            "center" -> Alignment.CenterVertically
            "bottom" -> Alignment.Bottom
            else -> Alignment.Top
        }
    }

    private fun contentAlignment(props: JSONObject): Alignment {
        return when (props.optString("contentAlignment", "topStart")) {
            "center" -> Alignment.Center
            "topCenter" -> Alignment.TopCenter
            "bottomCenter" -> Alignment.BottomCenter
            "centerStart" -> Alignment.CenterStart
            "centerEnd" -> Alignment.CenterEnd
            "topEnd" -> Alignment.TopEnd
            "bottomStart" -> Alignment.BottomStart
            "bottomEnd" -> Alignment.BottomEnd
            else -> Alignment.TopStart
        }
    }

    private fun resolveButtonText(props: JSONObject, children: JSONArray): String {
        val direct = props.optString("text", "").trim()
        if (direct.isNotEmpty()) return direct

        for (i in 0 until children.length()) {
            val c = children.optJSONObject(i) ?: continue
            if (c.optString("type") == "Text") {
                val t = c.optJSONObject("props")?.optString("text", "") ?: ""
                if (t.isNotBlank()) return t
            }
        }
        return "Button"
    }

    private fun num(p: JSONObject, key: String, fallback: Float): Float {
        return try {
            when (val v = p.opt(key)) {
                is Number -> v.toFloat()
                is String -> v.toFloatOrNull() ?: fallback
                else -> fallback
            }
        } catch (_: Exception) {
            fallback
        }
    }

    private fun iconForName(name: String): ImageVector {
        return when (name.lowercase()) {
            "star", "favorite" -> Icons.Filled.Star
            "home" -> Icons.Filled.Home
            "settings" -> Icons.Filled.Settings
            "person", "account" -> Icons.Filled.Person
            "search" -> Icons.Filled.Search
            "add", "plus" -> Icons.Filled.Add
            "delete", "trash" -> Icons.Filled.Delete
            "edit" -> Icons.Filled.Edit
            "check", "done" -> Icons.Filled.Check
            "close" -> Icons.Filled.Close
            "arrowback", "arrow_back" -> Icons.Filled.ArrowBack
            "menu" -> Icons.Filled.Menu
            "info" -> Icons.Filled.Info
            else -> Icons.Filled.Star
        }
    }
}
