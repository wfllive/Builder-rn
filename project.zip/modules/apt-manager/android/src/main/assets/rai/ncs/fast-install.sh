#!/usr/bin/env bash
# =============================================================================
#  NCS Fast Install — минимальная быстрая установка окружения
#  Устанавливает ТОЛЬКО необходимое:
#   - openjdk-17-jdk-headless (без Recommends/Suggests)
#   - базовые утилиты curl/unzip/zip
#   - Android SDK cmdline-tools + build-tools 35.0.0 + platform android-35
#   - CLI ncs в ~/.ncs/bin
#
#  Правки для proot/Ubuntu 24.04 (noble):
#   - не дублируем apt sources (deb822 vs classic sources.list)
#   - чиним locks / half-configured dpkg перед установкой
#   - отключаем apt sandbox, не падаем на warnings
# =============================================================================
set -euo pipefail

if [ -t 1 ]; then
  B='\033[1;36m'; G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; NC='\033[0m'
else
  B=''; G=''; Y=''; R=''; NC=''
fi
log()  { echo -e "${B}[fast]${NC} $*"; }
ok()   { echo -e "  ${G}✓${NC} $*"; }
warn() { echo -e "  ${Y}⚠${NC} $*"; }
die()  { echo -e "  ${R}✗${NC} $*"; exit 1; }

NCS_HOME="${NCS_HOME:-$HOME/.ncs}"
SDK_DIR="$NCS_HOME/sdk"
CACHE_DIR="$NCS_HOME/cache"
TMP_DIR="$NCS_HOME/tmp"

mkdir -p "$NCS_HOME" "$SDK_DIR" "$CACHE_DIR" "$TMP_DIR"

export DEBIAN_FRONTEND=noninteractive

# ------------------------------------------------------------------ 0. Предварительная починка dpkg/apt
# В proot часто остаются lock-файлы или half-configured пакеты после неудачных попыток.
log "Проверка и починка dpkg/apt..."
for lf in /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock /var/lib/apt/lists/lock; do
  [ -f "$lf" ] && rm -f "$lf" 2>/dev/null || true
done
(dpkg --configure -a 2>/dev/null || true)
(apt-get install -f -y 2>/dev/null || true)
ok "dpkg/apt в согласованном состоянии"

# ------------------------------------------------------------------ 1. Настройка apt
log "Настройка apt..."

# Конфиг без Recommends/Suggests; отключаем sandbox (в proot нет пользователя _apt);
# не используем Pty (зависает на некоторых устройствах)
cat > /etc/apt/apt.conf.d/99ncs-fast <<EOF
APT::Install-Recommends "false";
APT::Install-Suggests "false";
APT::Get::Assume-Yes "true";
APT::Get::allow-unauthenticated "false";
Acquire::Retries "3";
Acquire::http::Pipeline-Depth "5";
Acquire::http::No-Cache "false";
Acquire::Queue-Mode "access";
Dpkg::Use-Pty "0";
APT::Sandbox::User "";
Dir::Cache::pkgcache "";
Dir::Cache::srcpkgcache "";
EOF
ok "apt.conf настроен"

# /tmp права
for d in /tmp /var/tmp; do
  mkdir -p "$d" 2>/dev/null
  chmod 1777 "$d" 2>/dev/null || true
done

# DNS
if ! grep -q "^nameserver" /etc/resolv.conf 2>/dev/null; then
  printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\nnameserver 8.8.4.4\n' > /etc/resolv.conf
  ok "DNS настроен"
fi

# ARM зеркало. Ubuntu 24.04 (noble) в proot часто использует deb822 формат
# /etc/apt/sources.list.d/ubuntu.sources; не перезаписываем sources.list чтобы не плодить дубли.
ARCH="$(dpkg --print-architecture 2>/dev/null || echo arm64)"
if [ "$ARCH" = "arm64" ]; then
  CODENAME="$(. /etc/os-release 2>/dev/null && echo "${VERSION_CODENAME:-noble}")"
  HAVE_PORTS=0
  # Ищем ports.ubuntu.com в любом из sources файлов (deb822 или классический)
  if grep -rsh '^URIs\?:.*ports.ubuntu.com\|^deb .*ports.ubuntu.com' /etc/apt/sources.list /etc/apt/sources.list.d/*.sources /etc/apt/sources.list.d/*.list 2>/dev/null | grep -q .; then
    HAVE_PORTS=1
  fi
  if [ "$HAVE_PORTS" = "0" ]; then
    # Ничего не настроено для ARM — пишем минимальный sources.list
    cat > /etc/apt/sources.list <<EOF
deb http://ports.ubuntu.com/ubuntu-ports $CODENAME main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-security main restricted universe multiverse
EOF
    ok "добавлено зеркало ports.ubuntu.com для $CODENAME"
  else
    # Важно: если есть ubuntu.sources (deb822) и пустой/старый sources.list —
    # очистим sources.list чтобы не дублировать
    if [ -f /etc/apt/sources.list.d/ubuntu.sources ] && \
       grep -q 'ports.ubuntu.com' /etc/apt/sources.list.d/ubuntu.sources 2>/dev/null; then
      # Оставляем sources.list пустым, комментируем старые записи если есть
      [ -s /etc/apt/sources.list ] && {
        sed -i '/^[[:space:]]*deb /s/^/# /' /etc/apt/sources.list 2>/dev/null || true
      }
    fi
    ok "apt sources уже настроены (ports.ubuntu.com найден)"
  fi
fi

# ------------------------------------------------------------------ 2. Обновление списков + минимальные пакеты
log "Обновление списков пакетов..."
apt-get update -qq 2>&1 | { grep -v '^W: ' || true; } | tail -5

log "Установка минимального набора инструментов..."
PKGS=(openjdk-17-jdk-headless ca-certificates curl wget unzip zip xz-utils procps)
apt-get install -y --no-install-recommends "${PKGS[@]}" 2>&1 \
  | { grep -vE '^Progress|^Setting up|^Selecting|^Preparing|^Unpacking|^Configuring|^Adding|^Created|^Processing|^Use ' || true; } \
  | tail -30

# JAVA_HOME
JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(which javac)")")")"
echo "$JAVA_HOME" > "$NCS_HOME/JAVA_HOME"
ok "JDK 17 установлен: $JAVA_HOME"

# Патч от зависаний JVM на /dev/random в proot
for SEC in "$JAVA_HOME/conf/security/java.security" "$JAVA_HOME/lib/security/java.security"; do
  [ -f "$SEC" ] || continue
  sed -i 's|^securerandom.source=.*|securerandom.source=file:/dev/./urandom|' "$SEC" 2>/dev/null || true
done
ok "Java пропатчена от зависаний на /dev/random"

# ------------------------------------------------------------------ 3. Android SDK
log "Настройка Android SDK..."
mkdir -p "$SDK_DIR/cmdline-tools" "$SDK_DIR/build-tools" "$SDK_DIR/platforms" "$SDK_DIR/platform-tools"

CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
CMDLINE_TOOLS_ZIP="$CACHE_DIR/cmdline-tools.zip"

if [ ! -d "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  log "Скачивание command-line tools..."
  curl -fL --retry 3 -o "$CMDLINE_TOOLS_ZIP" "$CMDLINE_TOOLS_URL"
  unzip -qo "$CMDLINE_TOOLS_ZIP" -d "$SDK_DIR/cmdline-tools/"
  mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
  rm -f "$CMDLINE_TOOLS_ZIP"
  ok "command-line tools установлены"
else
  ok "command-line tools уже есть"
fi

export PATH="$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools:$PATH"
export ANDROID_SDK_ROOT="$SDK_DIR"

(yes 2>/dev/null | sdkmanager --licenses >/dev/null 2>&1 || true)

BT_VER="${NCS_BUILD_TOOLS:-35.0.0}"
PLAT_VER="${NCS_PLATFORM:-android-35}"

if [ ! -f "$SDK_DIR/build-tools/$BT_VER/aapt2" ]; then
  log "Скачивание build-tools $BT_VER..."
  sdkmanager --install "build-tools;$BT_VER" 2>&1 | tail -3
  ok "build-tools $BT_VER установлен"
else
  ok "build-tools $BT_VER уже есть"
fi

if [ ! -f "$SDK_DIR/platforms/$PLAT_VER/android.jar" ]; then
  log "Скачивание platform $PLAT_VER..."
  sdkmanager --install "platforms;$PLAT_VER" 2>&1 | tail -3
  ok "platform $PLAT_VER установлен"
else
  ok "platform $PLAT_VER уже есть"
fi

# ------------------------------------------------------------------ 4. Устанавливаем CLI ncs
log "Установка ncs CLI..."
cat > "$NCS_HOME/bin/ncs" <<NCSEOF
#!/usr/bin/env bash
export JAVA_HOME="\$(cat "\$HOME/.ncs/JAVA_HOME" 2>/dev/null || echo "$JAVA_HOME")"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="\$JAVA_HOME/bin:$SDK_DIR/build-tools/$BT_VER:$SDK_DIR/platform-tools:$NCS_HOME/bin:\$PATH"
export JAVA_TOOL_OPTIONS="-Djava.security.egd=file:/dev/./urandom"
exec bash "\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)/ncs-build.sh" "\$@"
NCSEOF
chmod +x "$NCS_HOME/bin/ncs"

MARK="# >>> ncs-fast >>>"
for F in "$HOME/.bashrc" "$HOME/.profile"; do
  touch "$F"
  grep -q "$MARK" "$F" 2>/dev/null && sed -i "/$MARK/,/# <<< ncs-fast <<</d" "$F"
  cat >> "$F" <<EOF

$MARK
export NCS_HOME="$NCS_HOME"
export JAVA_HOME="\$(cat "$NCS_HOME/JAVA_HOME" 2>/dev/null)"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="\$NCS_HOME/bin:\$JAVA_HOME/bin:\$PATH"
export JAVA_TOOL_OPTIONS="-Djava.security.egd=file:/dev/./urandom"
export LANG=C.UTF-8
# <<< ncs-fast <<<
EOF
done
ok "ncs добавлен в PATH (.bashrc/.profile)"

# Копируем соседние скрипты туда же (ncs-build.sh, new-project.sh)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in ncs-build.sh new-project.sh; do
  [ -f "$SCRIPT_DIR/$f" ] && cp "$SCRIPT_DIR/$f" "$NCS_HOME/bin/$f"
done
chmod +x "$NCS_HOME/bin/"*.sh 2>/dev/null || true
mkdir -p "$HOME/projects"

echo
echo -e "${G}════════════ УСТАНОВКА ЗАВЕРШЕНА ════════════${NC}"
echo
echo "  JAVA_HOME     : $JAVA_HOME"
echo "  ANDROID_HOME  : $SDK_DIR"
echo "  ncs           : $NCS_HOME/bin/ncs"
echo "  Размер        : $(du -sh "$NCS_HOME" 2>/dev/null | cut -f1)"
echo
echo "  Использование:"
echo "    source ~/.bashrc"
echo "    ncs new MyApp com.example.myapp"
echo "    ncs build debug"
echo
