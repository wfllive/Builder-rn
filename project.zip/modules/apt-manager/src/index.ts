/**
 * AptManager — нативный модуль управления пакетами, proot-окружением,
 * фоновыми службами и разрешениями для NovaCompose Studio.
 */
import { requireNativeModule } from 'expo-modules-core';

let native: any = null;
try { native = requireNativeModule('AptManager'); } catch (e) {}

export const isAvailable = () => !!native;
export const isBootstrapInstalled = async () => native?.isBootstrapInstalled?.() || false;
export const ensurePermissions = async () => native?.ensurePermissions?.() || { success: false };
export const getExecBinDir = async () => native?.getExecBinDir?.() || { path: '' };
export const testExec = async () => native?.testExec?.() || { success: false };
export const installBootstrap = async () => native?.installBootstrap?.() || { success: false, output: 'Not available' };
export const install = async (pkg: string) => native?.install?.(pkg) || { success: false, output: 'Not available' };
export const remove = async (pkg: string) => native?.remove?.(pkg) || { success: false, output: 'Not available' };
export const search = async (q: string) => native?.search?.(q) || { success: false, output: 'Not available' };
export const info = async (pkg: string) => native?.info?.(pkg) || { success: false, output: 'Not available' };
export const update = async () => native?.update?.() || { success: false, output: 'Not available' };
export const listInstalled = async () => native?.listInstalled?.() || [];
export const whichCommand = async (cmd: string) => native?.whichCommand?.(cmd) || { exists: false, path: '' };
export const getPrefix = async () => native?.getPrefix?.() || { prefix: '' };
export const getHome = async () => native?.getHome?.() || { home: '' };
export const isProotRootfsInstalled = async () => native?.isProotRootfsInstalled?.() || false;
export const getProotRootfsDir = async () => native?.getProotRootfsDir?.() || { path: '' };
export const installProotRootfs = async (url?: string) =>
  native?.installProotRootfs?.(url || null) || { success: false, output: 'Not available' };
export const deleteRootfs = async () =>
  native?.deleteRootfs?.() || { success: false, deleted: false };
export const getRootfsProgress = async () =>
  native?.getRootfsProgress?.() || { stage: 'idle', url: '', downloadedBytes: 0, totalBytes: 0, message: '' };
export const seedRaiBundle = async () =>
  native?.seedRaiBundle?.() || { success: false, output: 'Not available' };
export const canInstallApks = async () => native?.canInstallApks?.() || false;
export const installApk = async (path: string) => native?.installApk?.(path) || { success: false, output: 'Native APK installer is unavailable' };
export const launchPackage = async (packageName: string) => native?.launchPackage?.(packageName) || { success: false, output: 'Native package launcher is unavailable' };

// Общий доступ к хранилищу («память») — All files access (API 30+) / диалог разрешений
export const hasAllFilesAccess = async () => native?.hasAllFilesAccess?.() || false;
export const openAllFilesAccessSettings = async () =>
  native?.openAllFilesAccessSettings?.() || { success: false, output: 'Not available' };
export const requestStoragePermissions = async () =>
  native?.requestStoragePermissions?.() || { success: false, output: 'Not available' };

// Уведомления (Android 13+ — разрешение во время выполнения для индикатора фоновой работы)
export const hasNotificationsPermission = async () =>
  native?.hasNotificationsPermission?.() || { granted: true };
export const requestNotificationsPermission = async () =>
  native?.requestNotificationsPermission?.() || { success: false, output: 'Not available' };

// Фоновая служба — поддерживает работу установки/сборки при сворачивании или блокировке экрана
export const startBackgroundService = async (text: string) =>
  native?.startBackgroundService?.(text) || { success: false, output: 'Not available' };
export const updateBackgroundService = async (text: string) =>
  native?.updateBackgroundService?.(text) || { success: false, output: 'Not available' };
export const stopBackgroundService = async () =>
  native?.stopBackgroundService?.() || { success: false, output: 'Not available' };

/**
 * Отрисовка визуального компонента проекта через настоящий Android View
 * (Compose/M3) и получение PNG в base64. Используется для нативного предпросмотра.
 */
export const renderComposePreview = async (payload) => {
  if (!native?.renderComposePreview) return { success: false, output: 'Native preview renderer is unavailable' };
  return await native.renderComposePreview(payload);
};

export default {
  isAvailable, isBootstrapInstalled, ensurePermissions, getExecBinDir, testExec, installBootstrap,
  install, remove, search, info, update,
  listInstalled, whichCommand, getPrefix, getHome,
  isProotRootfsInstalled, getProotRootfsDir, installProotRootfs, getRootfsProgress, deleteRootfs,
  seedRaiBundle,
  canInstallApks, installApk, launchPackage, renderComposePreview,
  hasAllFilesAccess, openAllFilesAccessSettings, requestStoragePermissions,
  hasNotificationsPermission, requestNotificationsPermission,
  startBackgroundService, updateBackgroundService, stopBackgroundService
};
