import { requireNativeModule } from 'expo-modules-core';

let native: any = null;
try { native = requireNativeModule('AptManager'); } catch (e) {}

export const isAvailable = () => !!native;
export const isBootstrapInstalled = async () => native?.isBootstrapInstalled?.() || false;
export const ensurePermissions = async () => native?.ensurePermissions?.() || { success: false };
export const getExecBinDir = async () => native?.getExecBinDir?.() || { path: '' };
export const installBootstrap = async () => native?.installBootstrap?.() || { success: false, output: 'Not available' };
export const install = async (pkg: string) => native?.install?.(pkg) || { success: false, output: 'Not available' };
export const remove = async (pkg: string) => native?.remove?.(pkg) || { success: false, output: 'Not available' };
export const search = async (q: string) => native?.search?.(q) || { success: false, output: 'Not available' };
export const info = async (pkg: string) => native?.info?.(pkg) || { success: false, output: 'Not available' };
export const update = async () => native?.update?.() || { success: false, output: 'Not available' };
export const listInstalled = async () => native?.listInstalled?.() || [];
export const whichCommand = async (cmd: string) => native?.whichCommand?.(cmd) || { exists: false, path: '' };
export const getPrefix = async () => native?.getPrefix?.() || { prefix: '' };
export const getHome = async () => native?.getHome?.() || { home: '' };

export default {
  isAvailable, isBootstrapInstalled, ensurePermissions, getExecBinDir, installBootstrap,
  install, remove, search, info, update,
  listInstalled, whichCommand, getPrefix, getHome
};
