import { requireNativeModule, requireNativeViewManager } from 'expo-modules-core';
import { View, StyleSheet } from 'react-native';
import React, { useRef, forwardRef, useImperativeHandle } from 'react';

let nativeModule: any = null;
try {
  nativeModule = requireNativeModule('TermuxTerminal');
} catch (e) {}

export const isAvailable = () => !!nativeModule;

export const execute = async (command: string, workDir?: string) => {
  if (!nativeModule) return { success: false, exitCode: -1, output: 'TermuxTerminal not available' };
  return await nativeModule.execute(command, workDir || null);
};

export const checkCommand = async (command: string) => {
  if (!nativeModule) return { exists: false, path: '' };
  return await nativeModule.checkCommand(command);
};

export const getNodeVersion = async () => {
  if (!nativeModule) return { version: null, path: '' };
  return await nativeModule.getNodeVersion();
};

export const installNode = async () => {
  if (!nativeModule) return { success: false, output: 'Not available', version: null };
  return await nativeModule.installNode();
};

export interface ProotStatus {
  prootBinary: boolean;
  rootfsInstalled: boolean;
  ready: boolean;
  nativeLibDir: string;
  rootfsDir: string;
}

export const getProotStatus = async (): Promise<ProotStatus> => {
  if (!nativeModule) {
    return { prootBinary: false, rootfsInstalled: false, ready: false, nativeLibDir: '', rootfsDir: '' };
  }
  return await nativeModule.getProotStatus();
};

export interface ProotDiagnosis {
  ok: boolean;
  output: string;
  arch: string;
  prootExists: boolean;
  loaderExists: boolean;
  rootfsInstalled: boolean;
}

export const diagnoseProot = async (): Promise<ProotDiagnosis> => {
  if (!nativeModule) {
    return { ok: false, output: 'TermuxTerminal not available', arch: '', prootExists: false, loaderExists: false, rootfsInstalled: false };
  }
  return await nativeModule.diagnoseProot();
};

export const copyToClipboard = async (text: string): Promise<void> => {
  if (!nativeModule) return;
  try {
    await nativeModule.copyToClipboard(text);
  } catch (e) {}
};

// Native Terminal View (Termux TerminalView + ExtraKeys bar)
let NativeTerminalView: any = null;
try {
  NativeTerminalView = requireNativeViewManager('TermuxTerminal');
} catch (e) {}

export type TerminalEvent =
  | { type: 'started'; shell: string; cwd: string; pid: number; bootstrap: boolean }
  | { type: 'title'; title: string }
  | { type: 'exit'; exitCode: number };

export interface TerminalViewRef {
  /** Write raw text to the shell (no trailing newline). */
  writeText: (text: string) => void;
  /** Run a command (adds a trailing newline). */
  run: (command: string) => void;
  /** Simulate an extra key press, e.g. "ENTER", "ESC", "TAB", "UP". */
  sendKey: (key: string) => void;
  /** Restart the shell session. */
  restart: () => void;
  /** Toggle the soft keyboard. */
  toggleKeyboard: () => void;
}

interface TerminalViewProps {
  style?: any;
  /** Terminal font size in points (6..64). */
  fontSize?: number;
  /** Working directory for the shell. */
  workingDirectory?: string;
  /** Command executed once the shell is ready. */
  initialCommand?: string;
  /** Custom extra-keys layout (Termux JSON format). */
  extraKeys?: string;
  /** Terminal lifecycle events. */
  onTerminalEvent?: (event: { nativeEvent: TerminalEvent }) => void;
}

export const TerminalView = forwardRef<TerminalViewRef, TerminalViewProps>(
  ({ style, fontSize, workingDirectory, initialCommand, extraKeys, onTerminalEvent }, ref) => {
    const nativeRef = useRef<any>(null);

    useImperativeHandle(ref, () => ({
      writeText: (text: string) => nativeRef.current?.writeText?.(text),
      run: (command: string) => nativeRef.current?.writeText?.(command + '\n'),
      sendKey: (key: string) => nativeRef.current?.sendKey?.(key),
      restart: () => nativeRef.current?.restart?.(),
      toggleKeyboard: () => nativeRef.current?.toggleKeyboard?.(),
    }));

    if (!NativeTerminalView) {
      return (
        <View style={[styles.fallback, style]}>
          <View style={{ flex: 1, backgroundColor: '#0D1117', padding: 10 }} />
        </View>
      );
    }

    return (
      <NativeTerminalView
        ref={nativeRef}
        style={[styles.terminal, style]}
        fontSize={fontSize ?? 13}
        workingDirectory={workingDirectory}
        initialCommand={initialCommand}
        extraKeys={extraKeys}
        onTerminalEvent={onTerminalEvent}
      />
    );
  }
);

const styles = StyleSheet.create({
  terminal: { flex: 1 },
  fallback: { flex: 1, backgroundColor: '#0D1117' },
});

export default {
  isAvailable,
  execute,
  checkCommand,
  getNodeVersion,
  installNode,
  getProotStatus,
  TerminalView,
};
