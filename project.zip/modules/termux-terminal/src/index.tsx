/**
 * Termux Terminal — нативный модуль терминала (proot).
 * Обеспечивает выполнение команд в реальном Linux-окружении,
 * отображение интерактивного терминала и управление сессией.
 */
import { EventEmitter, requireNativeModule, requireNativeViewManager } from 'expo-modules-core';
import { View } from 'react-native';
import React, { useRef, forwardRef, useImperativeHandle } from 'react';

let nativeModule: any = null;
try {
  nativeModule = requireNativeModule('TermuxTerminal');
} catch (e) {}

export const isAvailable = () => !!nativeModule;
export const commandEvents = nativeModule ? new EventEmitter(nativeModule) : null;

export const execute = async (command: string, workDir?: string) => {
  if (!nativeModule) return { success: false, exitCode: -1, output: 'TermuxTerminal not available' };
  return await nativeModule.execute(command, workDir || null);
};

export const checkCommand = async (command: string) => {
  if (!nativeModule) return { exists: false, path: '' };
  return await nativeModule.checkCommand(command);
};

export const getNodeVersion = async () => {
  if (!nativeModule) return { version: null, path: '' };
  return await nativeModule.getNodeVersion();
};

export const installNode = async () => {
  if (!nativeModule) return { success: false, output: 'Not available', version: null };
  return await nativeModule.installNode();
};

/** Статус proot-окружения: бинарник, установленная rootfs, готовность. */
export interface ProotStatus {
  prootBinary: boolean;       // наличие бинарника proot
  rootfsInstalled: boolean;    // установлен корневой образ
  ready: boolean;              // среда готова к работе
  nativeLibDir: string;        // путь к нативным библиотекам
  rootfsDir: string;           // путь к корневому образу
}

export const getProotStatus = async (): Promise<ProotStatus> => {
  if (!nativeModule) {
    return { prootBinary: false, rootfsInstalled: false, ready: false, nativeLibDir: '', rootfsDir: '' };
  }
  return await nativeModule.getProotStatus();
};

/** Результат подготовки proot-окружения (самовосстановление apt/dpkg). */
export interface PrepareProotResult {
  success: boolean;    // успешность операции
  exitCode: number;    // код завершения
  output: string;      // полный вывод команды
}

/**
 * Запуск шага самовосстановления apt/dpkg внутри proot-корневого образа:
 * исправляет права доступа, записывает конфигурацию apt для proot,
 * выполняет `dpkg --configure -a` и `apt-get -f install -y`.
 * При `force=true` запускается повторно даже при готовом состоянии.
 */
export const prepareProot = async (force = false): Promise<PrepareProotResult> => {
  if (!nativeModule) {
    return { success: false, exitCode: -1, output: 'TermuxTerminal not available' };
  }
  return await nativeModule.prepareProot(Boolean(force));
};

/** Диагностика proot: общая готовность, архитектура, наличие файлов. */
export interface ProotDiagnosis {
  ok: boolean;                 // всё в порядке
  output: string;              // вывод диагностики
  arch: string;                // архитектура (arm64 / armhf)
  prootExists: boolean;        // бинарник proot найден
  loaderExists: boolean;       // загрузчик найден
  rootfsInstalled: boolean;    // корневой образ установлен
}

export const diagnoseProot = async (): Promise<ProotDiagnosis> => {
  if (!nativeModule) {
    return { ok: false, output: 'TermuxTerminal not available', arch: '', prootExists: false, loaderExists: false, rootfsInstalled: false };
  }
  return await nativeModule.diagnoseProot();
};

export const copyToClipboard = async (text: string): Promise<void> => {
  if (!nativeModule) return;
  try {
    await nativeModule.copyToClipboard(text);
  } catch (e) {}
};

// Native Terminal View (Termux TerminalView + ExtraKeys bar)
let NativeTerminalView: any = null;
try {
  NativeTerminalView = requireNativeViewManager('TermuxTerminal');
} catch (e) {}

/** События жизненного цикла терминала. */
export type TerminalEvent =
  | { type: 'started'; shell: string; cwd: string; pid: number; bootstrap: boolean }  // сессия запущена
  | { type: 'title'; title: string }                                             // заголовок изменился
  | { type: 'exit'; exitCode: number };                                           // сессия завершена

export interface TerminalViewRef {
  /** Записать текст в оболочку (без автоматического перевода строки). */
  writeText: (text: string) => void;
  /** Выполнить команду (добавляет перевод строки в конце). */
  run: (command: string) => void;
  /** Симулировать нажатие спецклавиши, например "ENTER", "ESC", "TAB", "UP". */
  sendKey: (key: string) => void;
  /** Перезапустить сессию оболочки. */
  restart: () => void;
  /** Переключить экранную клавиатуру. */
  toggleKeyboard: () => void;
  /** Вставить содержимое буфера обмена Android в терминал. Возвращает true при успехе. */
  pasteFromClipboard: () => Promise<boolean> | void;
  /** Скопировать весь транскрипт терминала в буфер обмена Android. Возвращает true при успехе. */
  copyTranscriptToClipboard: () => Promise<boolean> | void;
  /** Получить полный транскрипт терминала (включая прокрутку). Возвращает текст или null. */
  getTranscriptText: () => Promise<string | null> | void;
}

interface TerminalViewProps {
  style?: any;                                   // стили компонента
  /** Размер шрифта терминала в пунктах (от 6 до 64). */
  fontSize?: number;
  /** Рабочая директория для оболочки. */
  workingDirectory?: string;
  /** Команда, выполняемая при готовности оболочки. */
  initialCommand?: string;
  /** Пользовательская раскладка спецклавиш (формат JSON Termux). */
  extraKeys?: string;
  /** Режим «только просмотр»: скрывает панель спецклавиш и блокирует клавиатуру/ввод,
   * терминал показывает только вывод, все действия запускаются кнопками приложения. */
  readOnly?: boolean;
  /** События жизненного цикла терминала. */
  onTerminalEvent?: (event: { nativeEvent: TerminalEvent }) => void;
}

export const TerminalView = forwardRef<TerminalViewRef, TerminalViewProps>(
  ({ style, fontSize, workingDirectory, initialCommand, extraKeys, readOnly, onTerminalEvent }, ref) => {
    const nativeRef = useRef<any>(null);

    useImperativeHandle(ref, () => ({
      writeText: (text: string) => nativeRef.current?.writeText?.(text),
      run: (command: string) => nativeRef.current?.writeText?.(command + '\n'),
      sendKey: (key: string) => nativeRef.current?.sendKey?.(key),
      restart: () => nativeRef.current?.restart?.(),
      toggleKeyboard: () => nativeRef.current?.toggleKeyboard?.(),
      pasteFromClipboard: () => nativeRef.current?.pasteFromClipboard?.(),
      copyTranscriptToClipboard: () => nativeRef.current?.copyTranscriptToClipboard?.(),
      getTranscriptText: () => nativeRef.current?.getTranscriptText?.(),
    }));

    if (!NativeTerminalView) {
      return (
        <View style={[styles.fallback, style]}>
          <View style={{ flex: 1, backgroundColor: '#0D1117', padding: 10 }} />
        </View>
      );
    }

    return (
      <NativeTerminalView
        ref={nativeRef}
        style={[styles.terminal, style]}
        fontSize={fontSize ?? 13}
        workingDirectory={workingDirectory}
        initialCommand={initialCommand}
        extraKeys={extraKeys}
        readOnly={readOnly ?? false}
        onTerminalEvent={onTerminalEvent}
      />
    );
  }
);

const styles = {/* converted to Tailwind */};

export default {
  isAvailable,
  execute,
  checkCommand,
  getNodeVersion,
  installNode,
  getProotStatus,
  TerminalView,
};
