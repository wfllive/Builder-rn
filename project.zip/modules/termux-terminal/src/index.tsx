import { requireNativeModule, requireNativeViewManager } from 'expo-modules-core';
import { View, StyleSheet } from 'react-native';
import React, { useRef, forwardRef, useImperativeHandle } from 'react';

let nativeModule: any = null;
try {
  nativeModule = requireNativeModule('TermuxTerminal');
} catch (e) {}

export const isAvailable = () => !!nativeModule;

export const execute = async (command: string, workDir?: string) => {
  if (!nativeModule) return { success: false, exitCode: -1, output: 'TermuxTerminal not available' };
  return await nativeModule.execute(command, workDir || null);
};

export const checkCommand = async (command: string) => {
  if (!nativeModule) return { exists: false, path: '' };
  return await nativeModule.checkCommand(command);
};

export const getNodeVersion = async () => {
  if (!nativeModule) return { version: null, path: '' };
  return await nativeModule.getNodeVersion();
};

export const installNode = async () => {
  if (!nativeModule) return { success: false, output: 'Not available', version: null };
  return await nativeModule.installNode();
};

// Native Terminal View (Termux TerminalView)
let NativeTerminalView: any = null;
try {
  NativeTerminalView = requireNativeViewManager('TermuxTerminal');
} catch (e) {}

export interface TerminalViewRef {
  executeCommand: (cmd: string) => void;
}

interface TerminalViewProps {
  style?: any;
  onData?: (data: { type: string; data: string }) => void;
}

export const TerminalView = forwardRef<TerminalViewRef, TerminalViewProps>(({ style, onData }, ref) => {
  const nativeRef = useRef<any>(null);

  useImperativeHandle(ref, () => ({
    executeCommand: (cmd: string) => {
      // Send command to native view
      if (nativeRef.current?.setNativeProps) {
        nativeRef.current.setNativeProps({ command: cmd });
      }
    }
  }));

  if (!NativeTerminalView) {
    // Fallback: simple text view
    return (
      <View style={[styles.fallback, style]}>
        <View style={{ flex: 1, backgroundColor: '#0D1117', padding: 10 }} />
      </View>
    );
  }

  return (
    <NativeTerminalView
      ref={nativeRef}
      style={[styles.terminal, style]}
      onData={onData}
    />
  );
});

const styles = StyleSheet.create({
  terminal: { flex: 1 },
  fallback: { flex: 1, backgroundColor: '#0D1117' }
});

export default {
  isAvailable,
  execute,
  checkCommand,
  getNodeVersion,
  installNode,
  TerminalView
};
