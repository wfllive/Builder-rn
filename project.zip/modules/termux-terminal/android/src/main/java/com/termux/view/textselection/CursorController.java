package com.termux.view.textselection;
// Dummy interface
public interface CursorController {}
