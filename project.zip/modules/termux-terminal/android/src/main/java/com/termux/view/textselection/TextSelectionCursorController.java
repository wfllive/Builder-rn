package com.termux.view.textselection;

import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ViewTreeObserver;
import com.termux.view.TerminalView;

/**
 * Dummy TextSelectionCursorController.
 * Text selection is disabled — all methods are no-ops.
 */
public class TextSelectionCursorController implements ViewTreeObserver.OnTouchModeChangeListener {
    private TerminalView terminalView;

    public TextSelectionCursorController(TerminalView terminalView) {
        this.terminalView = terminalView;
    }

    public void getSelectors(int[] sel) {
        // No-op
    }

    public void show(MotionEvent event) {
        // No-op
    }

    public boolean hide() {
        return false;
    }

    public void render() {
        // No-op
    }

    public boolean isActive() {
        return false;
    }

    public ActionMode getActionMode() {
        return null;
    }

    public void decrementYTextSelectionCursors(int decrement) {
        // No-op
    }

    public void incrementYTextSelectionCursors(int increment) {
        // No-op
    }

    public void onDetached() {
        // No-op
    }

    @Override
    public void onTouchModeChanged(boolean isInTouchMode) {
        // No-op
    }
}
