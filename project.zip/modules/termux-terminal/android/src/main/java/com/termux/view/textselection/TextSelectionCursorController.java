package com.termux.view.textselection;

import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import com.termux.view.TerminalView;

public class TextSelectionCursorController implements ActionMode.Callback {
    private TerminalView terminalView;
    private boolean isActive = false;

    public TextSelectionCursorController(TerminalView terminalView) {
        this.terminalView = terminalView;
    }

    public void initializeSelection(int x, int y) {}
    public void setSelectionGesture(int x, int y) {}
    public void stopTextSelectionMode() { isActive = false; }
    public boolean isActive() { return isActive; }
    public void decrementYTextSelectionCursors(int decrement) {}
    public void incrementYTextSelectionCursors(int increment) {}
    public void onTouchEvent(MotionEvent event) {}
    public void onDetach() {}

    @Override public boolean onCreateActionMode(ActionMode mode, Menu menu) { return false; }
    @Override public boolean onPrepareActionMode(ActionMode mode, Menu menu) { return false; }
    @Override public boolean onActionItemClicked(ActionMode mode, MenuItem item) { return false; }
    @Override public void onDestroyActionMode(ActionMode mode) {}
}
