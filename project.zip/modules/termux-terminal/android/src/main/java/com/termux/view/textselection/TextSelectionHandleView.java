package com.termux.view.textselection;

import android.content.Context;
import android.view.View;

public class TextSelectionHandleView {
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    
    public TextSelectionHandleView(Context context, int handleType, View parent) {}
    public void setOrientation(int orientation) {}
    public void changeOrientation(int orientation) {}
    public boolean isShowing() { return false; }
    public void show() {}
    public void hide() {}
    public void setPosition(int x, int y) {}
    public void updatePosition(int x, int y) {}
    public int getHotspotX() { return 0; }
    public int getHotspotY() { return 0; }
    public boolean isPositionOnTopOfStartHandle(int x, int y) { return false; }
    public boolean isPositionOnTopOfEndHandle(int x, int y) { return false; }
}
