package expo.modules.termuxterminal

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class TermuxTerminalModule : Module() {

    private fun buildPath(): String {
        val appCtx = appContext.reactContext
        val paths = mutableListOf<String>()
        if (appCtx != null) {
            val prefix = File(appCtx.codeCacheDir, "usr").absolutePath
            paths.add("$prefix/bin")
        }
        paths.add("/data/data/com.termux/files/usr/bin")
        paths.add("/system/bin")
        return paths.joinToString(":")
    }

    private fun runShell(cmd: String, workDir: String? = null): Map<String, Any> {
        return try {
            val appCtx = appContext.reactContext
            val filesDir = appCtx?.filesDir?.absolutePath ?: ""
            val codeCacheDir = appCtx?.codeCacheDir?.absolutePath ?: ""
            val prefix = "$codeCacheDir/usr"
            val home = "$filesDir/home"
            val tmpDir = "$prefix/tmp"
            val dir = if (!workDir.isNullOrEmpty()) File(workDir) else File(home)
            val path = buildPath()

            val fullCmd = "export PREFIX=\"$prefix\" && " +
                "export HOME=\"$home\" && " +
                "export TMPDIR=\"$tmpDir\" && " +
                "export PATH=\"$path:\$PATH\" && " +
                "export LD_LIBRARY_PATH=\"$prefix/lib:\$LD_LIBRARY_PATH\" && " +
                "export TERM=xterm-256color && " +
                "cd \"$home\" 2>/dev/null && " +
                "$cmd"

            val pb = ProcessBuilder("sh", "-c", fullCmd).redirectErrorStream(true)
            if (dir.exists()) pb.directory(dir)
            val process = pb.start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            mapOf("success" to (exitCode == 0), "exitCode" to exitCode, "output" to output)
        } catch (e: Exception) {
            mapOf("success" to false, "exitCode" to -1, "output" to ("Error: " + (e.message ?: "unknown")))
        }
    }

    override fun definition() = ModuleDefinition {
        Name("TermuxTerminal")

        // Нативный Termux Terminal View
        View(TermuxTerminalView::class) {
            // No props needed
        }

        // Shell commands
        AsyncFunction("execute") Coroutine { command: String, workDir: String? ->
            withContext(Dispatchers.IO) { runShell(command, workDir) }
        }

        AsyncFunction("checkCommand") Coroutine { command: String ->
            withContext(Dispatchers.IO) {
                try {
                    val path = buildPath()
                    val p = ProcessBuilder("sh", "-c", "PATH=\"$path:\$PATH\" which $command 2>/dev/null")
                        .redirectErrorStream(true).start()
                    val output = p.inputStream.bufferedReader().readText().trim()
                    p.waitFor()
                    mapOf("exists" to (p.exitValue() == 0 && output.isNotEmpty()), "path" to output)
                } catch (_: Exception) {
                    mapOf("exists" to false, "path" to "")
                }
            }
        }

        AsyncFunction("getNodeVersion") Coroutine { ->
            withContext(Dispatchers.IO) {
                var result: Map<String, Any?> = mapOf("version" to null, "path" to "")
                val candidates = mutableListOf<String>()
                val appCtx = appContext.reactContext
                if (appCtx != null) {
                    candidates.add(File(appCtx.codeCacheDir, "usr/bin/node").absolutePath)
                }
                candidates.add("/data/data/com.termux/files/usr/bin/node")
                candidates.add("/usr/bin/node")

                for (nodePath in candidates) {
                    if (File(nodePath).exists()) {
                        try {
                            val p = ProcessBuilder("sh", "-c", "'$nodePath' --version 2>&1")
                                .redirectErrorStream(true).start()
                            val ver = p.inputStream.bufferedReader().readText().trim()
                            p.waitFor()
                            if (p.exitValue() == 0 && ver.startsWith("v")) {
                                result = mapOf("version" to ver, "path" to nodePath)
                                break
                            }
                        } catch (_: Exception) {}
                    }
                }
                result
            }
        }

        AsyncFunction("installNode") Coroutine { ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()
                var success = false
                var version: String? = null

                try {
                    log.appendLine("[1/3] Checking pkg...")
                    val pkgP = ProcessBuilder("sh", "-c", "which pkg 2>/dev/null").redirectErrorStream(true).start()
                    val pkgPath = pkgP.inputStream.bufferedReader().readText().trim()
                    pkgP.waitFor()

                    if (pkgPath.isNotEmpty()) {
                        log.appendLine("  Found: $pkgPath")
                        val inst = ProcessBuilder("sh", "-c", "$pkgPath install -y nodejs 2>&1").redirectErrorStream(true).start()
                        log.appendLine(inst.inputStream.bufferedReader().readText())
                        inst.waitFor()
                    } else {
                        log.appendLine("  Not found, trying apt...")
                        val aptP = ProcessBuilder("sh", "-c", "which apt-get 2>/dev/null").redirectErrorStream(true).start()
                        val aptPath = aptP.inputStream.bufferedReader().readText().trim()
                        aptP.waitFor()
                        if (aptPath.isNotEmpty()) {
                            val inst = ProcessBuilder("sh", "-c", "$aptPath install -y nodejs npm 2>&1").redirectErrorStream(true).start()
                            log.appendLine(inst.inputStream.bufferedReader().readText())
                            inst.waitFor()
                        }
                    }

                    val check = runShell("node --version 2>/dev/null")
                    if (check["success"] == true) {
                        version = (check["output"] as String).trim()
                        log.appendLine("[3/3] SUCCESS: $version")
                        success = true
                    } else {
                        log.appendLine("[3/3] FAILED")
                    }
                } catch (e: Exception) {
                    log.appendLine("Error: ${e.message}")
                }
                mapOf("success" to success, "output" to log.toString(), "version" to version)
            }
        }
    }
}
