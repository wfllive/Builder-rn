package expo.modules.termuxterminal

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.functions.Coroutine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class TermuxTerminalModule : Module() {

    private fun buildPath(): String {
        val appCtx = appContext.reactContext
        val paths = mutableListOf<String>()
        if (appCtx != null) {
            val prefix = File(appCtx.filesDir, "usr").absolutePath
            paths.add("$prefix/bin")
        }
        paths.add("/data/data/com.termux/files/usr/bin")
        paths.add("/system/bin")
        return paths.joinToString(":")
    }

    private fun runShell(cmd: String, workDir: String? = null): Map<String, Any> {
        return try {
            val appCtx = appContext.reactContext
            val filesDir = appCtx?.filesDir?.absolutePath ?: ""
            val prefix = "$filesDir/usr"
            val home = "$filesDir/home"
            val tmpDir = "$prefix/tmp"
            val dir = if (!workDir.isNullOrEmpty()) File(workDir) else File(home)
            val path = buildPath()

            val fullCmd = "export PREFIX=\"$prefix\" && " +
                "export HOME=\"$home\" && " +
                "export TMPDIR=\"$tmpDir\" && " +
                "export PATH=\"$path:\$PATH\" && " +
                "export LD_LIBRARY_PATH=\"$prefix/lib:\$LD_LIBRARY_PATH\" && " +
                "export TERM=xterm-256color && " +
                "cd \"$home\" 2>/dev/null && " +
                "$cmd"

            val pb = ProcessBuilder("sh", "-c", fullCmd).redirectErrorStream(true)
            if (dir.exists()) pb.directory(dir)
            val process = pb.start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            mapOf("success" to (exitCode == 0), "exitCode" to exitCode, "output" to output)
        } catch (e: Exception) {
            mapOf("success" to false, "exitCode" to -1, "output" to ("Error: " + (e.message ?: "unknown")))
        }
    }

    override fun definition() = ModuleDefinition {
        Name("TermuxTerminal")

        // Native Termux terminal view (TerminalView + ExtraKeys bar)
        View(TermuxTerminalView::class) {
            Events("onTerminalEvent")

            Prop("fontSize") { view: TermuxTerminalView, value: Int? ->
                if (value != null) view.setFontSizeProp(value)
            }
            Prop("workingDirectory") { view: TermuxTerminalView, value: String? ->
                view.setWorkingDirectory(value)
            }
            Prop("initialCommand") { view: TermuxTerminalView, value: String? ->
                view.setInitialCommand(value)
            }
            Prop("extraKeys") { view: TermuxTerminalView, value: String? ->
                view.setExtraKeys(value)
            }

            AsyncFunction("writeText") { view: TermuxTerminalView, text: String ->
                view.writeText(text)
            }
            AsyncFunction("sendKey") { view: TermuxTerminalView, key: String ->
                view.sendKey(key)
            }
            AsyncFunction("restart") { view: TermuxTerminalView ->
                view.restart()
            }
            AsyncFunction("toggleKeyboard") { view: TermuxTerminalView ->
                view.toggleKeyboard()
            }
        }

        // proot / Linux rootfs status
        AsyncFunction("getProotStatus") Coroutine { ->
            withContext(Dispatchers.IO) {
                val ctx = appContext.reactContext
                if (ctx == null) {
                    mapOf(
                        "prootBinary" to false,
                        "rootfsInstalled" to false,
                        "ready" to false,
                        "nativeLibDir" to "",
                        "rootfsDir" to ""
                    )
                } else {
                    mapOf(
                        "prootBinary" to ProotEnvironment.isProotBinaryAvailable(ctx),
                        "rootfsInstalled" to ProotEnvironment.isRootfsInstalled(ctx),
                        "ready" to ProotEnvironment.isReady(ctx),
                        "nativeLibDir" to ProotEnvironment.nativeLibDir(ctx),
                        "rootfsDir" to ProotEnvironment.rootfsDir(ctx).absolutePath
                    )
                }
            }
        }

        // Run `proot --version` to verify the bundled proot binary actually executes on this
        // device (arch / seccomp / noexec-of-nativeLib are the main risks). Very useful for debug.
        AsyncFunction("diagnoseProot") Coroutine { ->
            withContext(Dispatchers.IO) {
                val ctx = appContext.reactContext
                if (ctx == null) {
                    return@withContext mapOf(
                        "ok" to false,
                        "output" to "no react context",
                        "arch" to "",
                        "prootExists" to false,
                        "loaderExists" to false,
                        "rootfsInstalled" to false
                    )
                }
                val proot = ProotEnvironment.prootBinary(ctx)
                val loader = ProotEnvironment.loaderBinary(ctx)
                val arch = try { android.os.Build.SUPPORTED_ABIS.joinToString(",") } catch (e: Exception) { "?" }
                val sb = StringBuilder()
                sb.appendLine("ABI: $arch")
                sb.appendLine("nativeLibDir: ${ProotEnvironment.nativeLibDir(ctx)}")
                sb.appendLine("proot: ${if (proot.exists()) proot.absolutePath else "NOT FOUND"}")
                sb.appendLine("loader: ${if (loader.exists()) loader.absolutePath else "NOT FOUND"}")
                sb.appendLine("rootfs installed: ${ProotEnvironment.isRootfsInstalled(ctx)}")
                var ok = false
                if (proot.exists()) {
                    try {
                        val p = ProcessBuilder(proot.absolutePath, "--version").redirectErrorStream(true).start()
                        val out = p.inputStream.bufferedReader().readText().trim()
                        p.waitFor()
                        val code = try { p.exitValue() } catch (e: Exception) { -1 }
                        ok = code == 0
                        sb.appendLine("proot --version exit=$code")
                        if (out.isNotEmpty()) sb.appendLine(out)
                    } catch (e: Exception) {
                        sb.appendLine("proot exec FAILED: ${e.message}")
                    }
                } else {
                    sb.appendLine("Run `npm run proot` and rebuild to bundle proot.")
                }
                sb.appendLine("")
                sb.appendLine("=== proot smoke test (real session, same flags/env) ===")
                sb.append(ProotEnvironment.runSmokeTest(ctx))
                mapOf(
                    "ok" to ok,
                    "output" to sb.toString(),
                    "arch" to arch,
                    "prootExists" to proot.exists(),
                    "loaderExists" to loader.exists(),
                    "rootfsInstalled" to ProotEnvironment.isRootfsInstalled(ctx)
                )
            }
        }

        // Copy arbitrary text to the system clipboard (used by the diagnostics "Copy" button).
        AsyncFunction("copyToClipboard") { text: String ->
            val ctx = appContext.reactContext
            if (ctx != null) {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("terminal", text))
            }
        }

        // Shell commands
        AsyncFunction("execute") Coroutine { command: String, workDir: String? ->
            withContext(Dispatchers.IO) { runShell(command, workDir) }
        }

        AsyncFunction("checkCommand") Coroutine { command: String ->
            withContext(Dispatchers.IO) {
                try {
                    val path = buildPath()
                    val p = ProcessBuilder("sh", "-c", "PATH=\"$path:\$PATH\" which $command 2>/dev/null")
                        .redirectErrorStream(true).start()
                    val output = p.inputStream.bufferedReader().readText().trim()
                    p.waitFor()
                    mapOf("exists" to (p.exitValue() == 0 && output.isNotEmpty()), "path" to output)
                } catch (_: Exception) {
                    mapOf("exists" to false, "path" to "")
                }
            }
        }

        AsyncFunction("getNodeVersion") Coroutine { ->
            withContext(Dispatchers.IO) {
                var result: Map<String, Any?> = mapOf("version" to null, "path" to "")
                val candidates = mutableListOf<String>()
                val appCtx = appContext.reactContext
                if (appCtx != null) {
                    candidates.add(File(appCtx.filesDir, "usr/bin/node").absolutePath)
                }
                candidates.add("/data/data/com.termux/files/usr/bin/node")
                candidates.add("/usr/bin/node")

                for (nodePath in candidates) {
                    if (File(nodePath).exists()) {
                        try {
                            val p = ProcessBuilder("sh", "-c", "'$nodePath' --version 2>&1")
                                .redirectErrorStream(true).start()
                            val ver = p.inputStream.bufferedReader().readText().trim()
                            p.waitFor()
                            if (p.exitValue() == 0 && ver.startsWith("v")) {
                                result = mapOf("version" to ver, "path" to nodePath)
                                break
                            }
                        } catch (_: Exception) {}
                    }
                }
                result
            }
        }

        AsyncFunction("installNode") Coroutine { ->
            withContext(Dispatchers.IO) {
                val log = StringBuilder()
                var success = false
                var version: String? = null

                try {
                    log.appendLine("[1/3] Checking pkg...")
                    val pkgP = ProcessBuilder("sh", "-c", "which pkg 2>/dev/null").redirectErrorStream(true).start()
                    val pkgPath = pkgP.inputStream.bufferedReader().readText().trim()
                    pkgP.waitFor()

                    if (pkgPath.isNotEmpty()) {
                        log.appendLine("  Found: $pkgPath")
                        val inst = ProcessBuilder("sh", "-c", "$pkgPath install -y nodejs 2>&1").redirectErrorStream(true).start()
                        log.appendLine(inst.inputStream.bufferedReader().readText())
                        inst.waitFor()
                    } else {
                        log.appendLine("  Not found, trying apt...")
                        val aptP = ProcessBuilder("sh", "-c", "which apt-get 2>/dev/null").redirectErrorStream(true).start()
                        val aptPath = aptP.inputStream.bufferedReader().readText().trim()
                        aptP.waitFor()
                        if (aptPath.isNotEmpty()) {
                            val inst = ProcessBuilder("sh", "-c", "$aptPath install -y nodejs npm 2>&1").redirectErrorStream(true).start()
                            log.appendLine(inst.inputStream.bufferedReader().readText())
                            inst.waitFor()
                        }
                    }

                    val check = runShell("node --version 2>/dev/null")
                    if (check["success"] == true) {
                        version = (check["output"] as String).trim()
                        log.appendLine("[3/3] SUCCESS: $version")
                        success = true
                    } else {
                        log.appendLine("[3/3] FAILED")
                    }
                } catch (e: Exception) {
                    log.appendLine("Error: ${e.message}")
                }
                mapOf("success" to success, "output" to log.toString(), "version" to version)
            }
        }
    }
}
