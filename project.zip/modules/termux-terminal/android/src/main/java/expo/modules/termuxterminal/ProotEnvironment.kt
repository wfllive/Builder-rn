package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import java.io.File

/**
 * proot-based Linux environment.
 *
 * Why proot: on Android 10+ the app's data partition is noexec, so binaries extracted into
 * files/usr/bin cannot be executed. proot works around this: the proot host binary itself is
 * shipped as a native library (libproot.so in nativeLibraryDir, which IS executable), and it
 * then loads the guest rootfs binaries via its ptrace "loader" mechanism, which does not rely on
 * the kernel execve of those files - so a full Linux rootfs (with apt) runs from app data.
 *
 * Layout:
 *  - proot host binary : <nativeLibraryDir>/libproot.so   (from jniLibs, executable)
 *  - proot loader      : <nativeLibraryDir>/libloader.so  (read by proot via PROOT_LOADER)
 *  - rootfs            : <filesDir>/proot/rootfs/          (downloaded at runtime)
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libloader.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    /** A minimal marker that the rootfs has been extracted (has a /bin directory). */
    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) && isRootfsInstalled(context)

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    /**
     * Build the proot invocation that logs into the rootfs.
     *
     * NOTE on argv: TerminalSession passes args straight to execvp as argv, and proot (getopt)
     * skips argv[0]. So argv[0] must be the program name ("proot") and the real options start
     * at argv[1].
     */
    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        val rootfs = rootfsDir(appCtx).absolutePath
        val proot = prootBinary(appCtx).absolutePath
        val loader = loaderBinary(appCtx)
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"

        val opts = mutableListOf("proot") // argv[0] placeholder (skipped by getopt)
        opts += listOf("-r", rootfs)
        // Default system binds so the guest sees a usable /dev, /proc, /sys and shared storage.
        opts += listOf("-b", "/dev")
        opts += listOf("-b", "/proc")
        opts += listOf("-b", "/sys")
        opts += listOf("-b", "$sdcard:/sdcard")
        // Translate hard links to symlinks - required for dpkg/apt on Android filesystems.
        // Only supported by Termux-patched proot; disable if your proot build errors on it.
        if (link2Symlink) opts += "--link2symlink"
        // Pretend to be root so package managers (apt/dpkg) work.
        opts += "-0"
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        // The command run inside the rootfs:
        opts += listOf("/bin/bash", "--login")

        val env = mutableListOf(
            "TERM=xterm-256color",
            "COLORTERM=truecolor",
            "HOME=/root",
            "USER=root",
            "SHELL=/bin/bash",
            "TMPDIR=/tmp",
            "LANG=C.UTF-8",
            "LC_ALL=C.UTF-8",
            // Avoid proot seccomp issues on some Android kernels.
            "PROOT_NO_SECCOMP=1",
            // Standard Linux PATH; the login shell's /etc/profile will refine it.
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        if (loader.exists()) {
            env.add("PROOT_LOADER=${loader.absolutePath}")
        } else {
            Log.w(TAG, "proot loader not found at ${loader.absolutePath}; guest exec may fail")
        }
        System.getenv("ANDROID_ROOT")?.let { env.add("ANDROID_ROOT=$it") }
        System.getenv("ANDROID_DATA")?.let { env.add("ANDROID_DATA=$it") }

        Log.i(TAG, "proot ready: $proot ; rootfs=$rootfs ; args=${opts.joinToString(" ")}")

        // Host cwd proot starts in (any readable dir); guest cwd is set by -w.
        val cwd = appCtx.filesDir.absolutePath

        return ProotConfig(proot, opts.toTypedArray(), env.toTypedArray(), cwd)
    }
}
