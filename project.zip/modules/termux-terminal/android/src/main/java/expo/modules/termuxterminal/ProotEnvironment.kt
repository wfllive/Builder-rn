package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import java.io.File

/**
 * proot-based Linux environment.
 *
 * Why proot: on Android 10+ the app's data partition is noexec, so binaries extracted into
 * files/usr/bin cannot be executed. proot works around this: the proot host binary itself is
 * shipped as a native library (libproot.so in nativeLibraryDir, which IS executable), and it
 * then loads the guest rootfs binaries via its ptrace "loader" mechanism, which does not rely on
 * the kernel execve of those files - so a full Linux rootfs (with apt) runs from app data.
 *
 * Layout:
 *  - proot host binary : <nativeLibraryDir>/libproot.so   (from jniLibs, executable)
 *  - proot loader      : <nativeLibraryDir>/libloader.so  (read by proot via PROOT_LOADER)
 *  - rootfs            : <filesDir>/proot/rootfs/          (downloaded at runtime)
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libloader.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    /** ELF class of the bundled proot (32/64) or null. */
    fun prootArch(context: Context): Int? = elfBits(prootBinary(context))

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) && isRootfsInstalled(context)

    /** ELF class of a binary (32 / 64) or null if not a readable ELF. */
    private fun elfBits(f: File): Int? {
        return try {
            val b = ByteArray(5)
            java.io.FileInputStream(f).use { it.read(b) }
            if (b[0] == 0x7f.toByte() && b[1] == 'E'.code.toByte() && b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte())
                if (b[4] == 2.toByte()) 64 else if (b[4] == 1.toByte()) 32 else null
            else null
        } catch (e: Exception) { null }
    }

    /** Best-effort guest arch of an installed rootfs (32/64) by inspecting a known binary
     *  (symlinks are followed, which is what we want: /bin/ls -> usr/bin/ls -> real ELF). */
    fun rootfsArch(context: Context): Int? {
        val rootfs = rootfsDir(context)
        return listOf("usr/bin/ls", "bin/ls", "usr/bin/sh", "bin/sh", "usr/bin/coreutils")
            .firstNotNullOfOrNull { val f = File(rootfs, it); if (f.exists()) elfBits(f) else null }
    }

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    private fun tmpDir(context: Context): File =
        // proot extracts its (embedded) loader into PROOT_TMP_DIR and execve()s it. The regular
        // data dir is noexec on Android 10+/Huawei; code_cache is the one writable+exec location
        // Android allows an app (WebView/ART JIT). If even that is blocked, an external loader
        // (PROOT_LOADER from nativeLibraryDir) must be provided instead.
        File(context.applicationContext.codeCacheDir, "proot").also { it.mkdirs() }

    private fun prootFlags(appCtx: Context, workDir: String?, link2Symlink: Boolean): List<String> {
        val rootfs = rootfsDir(appCtx).absolutePath
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"
        val opts = mutableListOf<String>()
        opts += listOf("-r", rootfs)
        opts += listOf("-b", "/dev", "-b", "/proc", "-b", "/sys", "-b", "$sdcard:/sdcard")
        // Translate hard links to symlinks - helps dpkg/apt on Android filesystems (Termux patch;
        // vanilla proot also accepts it in 5.3.0). Disable if a build rejects the option.
        if (link2Symlink) opts += "--link2symlink"
        opts += "-0" // pretend root so apt/dpkg work
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        return opts
    }

    private fun buildEnv(appCtx: Context, loader: File): List<String> {
        val t = tmpDir(appCtx)
        val env = mutableListOf(
            "TERM=xterm-256color", "COLORTERM=truecolor", "HOME=/root", "USER=root", "SHELL=/bin/bash",
            "LANG=C.UTF-8", "LC_ALL=C.UTF-8",
            "PROOT_NO_SECCOMP=1",
            "PROOT_TMP_DIR=${t.absolutePath}", "TMPDIR=${t.absolutePath}",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        if (loader.exists()) {
            env.add("PROOT_LOADER=${loader.absolutePath}")
        } else {
            Log.i(TAG, "no external loader; proot will use its embedded loader (extracted to PROOT_TMP_DIR)")
        }
        System.getenv("ANDROID_ROOT")?.let { env.add("ANDROID_ROOT=$it") }
        System.getenv("ANDROID_DATA")?.let { env.add("ANDROID_DATA=$it") }
        return env
    }

    /**
     * Build the proot invocation that logs into the rootfs.
     * NOTE: TerminalSession passes args straight to execvp as argv; proot (getopt) skips argv[0],
     * so argv[0] must be the program name ("proot") and the real options start at argv[1].
     */
    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val loader = loaderBinary(appCtx)
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val opts = (listOf("proot") + flags + listOf("/bin/bash", "--login")).toTypedArray()
        val env = buildEnv(appCtx, loader).toTypedArray()
        Log.i(TAG, "proot ready: $proot ; rootfs=${rootfsDir(appCtx)} ; args=${opts.joinToString(" ")}")
        return ProotConfig(proot, opts, env, appCtx.filesDir.absolutePath)
    }

    /**
     * Run a one-shot proot smoke test (same flags/env as the real session) and return its combined
     * stdout+stderr. Used by the in-app Diagnostics button so the exact proot error is visible and
     * copyable, instead of guessing from a bare exit code.
     */
    fun runSmokeTest(context: Context): String {
        val appCtx = context.applicationContext
        val sb = StringBuilder()
        val proot = prootBinary(appCtx)
        val loader = loaderBinary(appCtx)
        val rootfs = rootfsDir(appCtx)
        sb.appendLine("proot  : ${proot.absolutePath} exists=${proot.exists()}")
        sb.appendLine("loader : ${loader.absolutePath} exists=${loader.exists()}")
        sb.appendLine("rootfs : ${rootfs.absolutePath} installed=${isRootfsInstalled(appCtx)}")
        val rArch = rootfsArch(appCtx)
        val rArchStr = when (rArch) { 64 -> "64-bit (aarch64)"; 32 -> "32-bit (armhf)"; else -> "?" }
        sb.appendLine("rootfs arch: $rArchStr")
        // The aarch64 static proot we ship has NO 32-bit loader, so a 32-bit rootfs can't run under it.
        if (rArch == 32) {
            sb.appendLine("!! MISMATCH: proot is 64-bit-only but rootfs is 32-bit -> press 'Установить Linux' to fetch the arm64 rootfs")
        }
        if (!proot.exists()) return sb.appendLine("=> proot binary missing").toString()

        val baseEnvMap = mutableMapOf<String, String>()
        buildEnv(appCtx, loader).forEach {
            val i = it.indexOf('='); if (i > 0) baseEnvMap[it.substring(0, i)] = it.substring(i + 1)
        }
        val flagsFull = prootFlags(appCtx, null, true)
        val flagsNoL2S = prootFlags(appCtx, null, false)

        fun runProbe(label: String, flags: List<String>, guest: List<String>, verbose: Boolean): String {
            val envMap = HashMap(baseEnvMap)
            if (verbose) envMap["PROOT_VERBOSE"] = "9"
            val argv = mutableListOf(proot.absolutePath).apply { addAll(flags); addAll(guest) }
            val out = StringBuilder()
            val code = try {
                val pb = ProcessBuilder(argv).redirectErrorStream(true)
                pb.environment().clear(); pb.environment().putAll(envMap)
                pb.directory(appCtx.filesDir)
                val p = pb.start()
                val reader = Thread {
                    try { p.inputStream.bufferedReader().forEachLine { l -> out.appendLine(l) } } catch (_: Exception) {}
                }
                reader.start()
                val deadline = System.currentTimeMillis() + 7000
                var c = -1
                while (System.currentTimeMillis() < deadline) {
                    try { c = p.exitValue(); break } catch (_: IllegalThreadStateException) { Thread.sleep(80) }
                }
                if (c == -1) { p.destroy(); out.appendLine("(timeout 7s)") }
                reader.join(1500)
                c
            } catch (e: Exception) { out.appendLine("exception: ${e.message}"); -1 }
            val text = out.toString()
            val tail = if (text.length > 1600) "…[head truncated]…\n" + text.substring(text.length - 1600) else text
            return "### $label  (exit=$code)\n$tail\n"
        }

        sb.appendLine("=== proot probes (PROOT_VERBOSE=9; tail shown) ===")
        sb.append(runProbe("A full-flags + /bin/true", flagsFull, listOf("/bin/true"), true))
        sb.append(runProbe("B full-flags + /bin/sh echo", flagsFull, listOf("/bin/sh", "-c", "echo OK"), true))
        sb.append(runProbe("C NO link2symlink + /bin/true", flagsNoL2S, listOf("/bin/true"), true))
        return sb.toString()
    }
}
