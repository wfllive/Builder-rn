package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import java.io.File

/**
 * proot-based Linux environment.
 *
 * Why proot: on Android 10+ the app's data partition is noexec, so binaries extracted into
 * files/usr/bin cannot be executed. proot works around this: the proot host binary itself is
 * shipped as a native library (libproot.so in nativeLibraryDir, which IS executable), and it
 * then loads the guest rootfs binaries via its ptrace "loader" mechanism, which does not rely on
 * the kernel execve of those files - so a full Linux rootfs (with apt) runs from app data.
 *
 * Layout:
 *  - proot host binary : <nativeLibraryDir>/libproot.so   (from jniLibs, executable)
 *  - proot loader      : <nativeLibraryDir>/libloader.so  (read by proot via PROOT_LOADER)
 *  - rootfs            : <filesDir>/proot/rootfs/          (downloaded at runtime)
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libloader.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) && isRootfsInstalled(context)

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    private fun tmpDir(context: Context): File =
        // proot extracts its (embedded) loader into PROOT_TMP_DIR and execve()s it. The regular
        // data dir is noexec on Android 10+/Huawei; code_cache is the one writable+exec location
        // Android allows an app (WebView/ART JIT). If even that is blocked, an external loader
        // (PROOT_LOADER from nativeLibraryDir) must be provided instead.
        File(context.applicationContext.codeCacheDir, "proot").also { it.mkdirs() }

    private fun prootFlags(appCtx: Context, workDir: String?, link2Symlink: Boolean): List<String> {
        val rootfs = rootfsDir(appCtx).absolutePath
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"
        val opts = mutableListOf<String>()
        opts += listOf("-r", rootfs)
        opts += listOf("-b", "/dev", "-b", "/proc", "-b", "/sys", "-b", "$sdcard:/sdcard")
        // Translate hard links to symlinks - helps dpkg/apt on Android filesystems (Termux patch;
        // vanilla proot also accepts it in 5.3.0). Disable if a build rejects the option.
        if (link2Symlink) opts += "--link2symlink"
        opts += "-0" // pretend root so apt/dpkg work
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        return opts
    }

    private fun buildEnv(appCtx: Context, loader: File): List<String> {
        val t = tmpDir(appCtx)
        val env = mutableListOf(
            "TERM=xterm-256color", "COLORTERM=truecolor", "HOME=/root", "USER=root", "SHELL=/bin/bash",
            "LANG=C.UTF-8", "LC_ALL=C.UTF-8",
            "PROOT_NO_SECCOMP=1",
            "PROOT_TMP_DIR=${t.absolutePath}", "TMPDIR=${t.absolutePath}",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )
        if (loader.exists()) {
            env.add("PROOT_LOADER=${loader.absolutePath}")
        } else {
            Log.i(TAG, "no external loader; proot will use its embedded loader (extracted to PROOT_TMP_DIR)")
        }
        System.getenv("ANDROID_ROOT")?.let { env.add("ANDROID_ROOT=$it") }
        System.getenv("ANDROID_DATA")?.let { env.add("ANDROID_DATA=$it") }
        return env
    }

    /**
     * Build the proot invocation that logs into the rootfs.
     * NOTE: TerminalSession passes args straight to execvp as argv; proot (getopt) skips argv[0],
     * so argv[0] must be the program name ("proot") and the real options start at argv[1].
     */
    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val loader = loaderBinary(appCtx)
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val opts = (listOf("proot") + flags + listOf("/bin/bash", "--login")).toTypedArray()
        val env = buildEnv(appCtx, loader).toTypedArray()
        Log.i(TAG, "proot ready: $proot ; rootfs=${rootfsDir(appCtx)} ; args=${opts.joinToString(" ")}")
        return ProotConfig(proot, opts, env, appCtx.filesDir.absolutePath)
    }

    /**
     * Run a one-shot proot smoke test (same flags/env as the real session) and return its combined
     * stdout+stderr. Used by the in-app Diagnostics button so the exact proot error is visible and
     * copyable, instead of guessing from a bare exit code.
     */
    fun runSmokeTest(context: Context): String {
        val appCtx = context.applicationContext
        val sb = StringBuilder()
        val proot = prootBinary(appCtx)
        val loader = loaderBinary(appCtx)
        val rootfs = rootfsDir(appCtx)
        sb.appendLine("proot  : ${proot.absolutePath} exists=${proot.exists()}")
        sb.appendLine("loader : ${loader.absolutePath} exists=${loader.exists()}")
        sb.appendLine("rootfs : ${rootfs.absolutePath} installed=${isRootfsInstalled(appCtx)}")
        if (!proot.exists()) return sb.appendLine("=> proot binary missing").toString()

        val flags = prootFlags(appCtx, null, true)
        val guestCmd = listOf("/bin/sh", "-c", "echo PROOT_OK; head -n1 /etc/os-release 2>/dev/null; id -un")
        val argv = (listOf("proot") + flags + guestCmd)
        sb.appendLine("cmd    : ${argv.joinToString(" ")}")
        val envList = buildEnv(appCtx, loader)

        return try {
            val pb = ProcessBuilder(argv).redirectErrorStream(true)
            pb.environment().clear()
            envList.forEach {
                val i = it.indexOf('=')
                if (i > 0) pb.environment()[it.substring(0, i)] = it.substring(i + 1)
            }
            pb.directory(appCtx.filesDir)
            val p = pb.start()
            val out = StringBuilder()
            val reader = Thread {
                try { p.inputStream.bufferedReader().forEachLine { l -> out.appendLine(l) } } catch (_: Exception) {}
            }
            reader.start()
            val deadline = System.currentTimeMillis() + 10000
            var code = -1
            while (System.currentTimeMillis() < deadline) {
                try { code = p.exitValue(); break } catch (_: IllegalThreadStateException) { Thread.sleep(100) }
            }
            if (code == -1) { p.destroy(); sb.appendLine("(timed out after 10s)") }
            reader.join(2000)
            sb.appendLine("exit   : $code")
            sb.appendLine("--- proot output ---")
            sb.append(out.toString())
            sb.toString()
        } catch (e: Exception) {
            sb.appendLine("exception: ${e.message}").toString()
        }
    }
}
