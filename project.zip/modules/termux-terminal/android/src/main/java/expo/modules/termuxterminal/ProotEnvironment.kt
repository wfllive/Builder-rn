package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import java.io.File

/**
 * proot-based Linux environment.
 *
 * Layout:
 *  - proot host binary : <nativeLibraryDir>/libproot.so
 *  - proot loader      : <nativeLibraryDir>/libloader.so
 *  - proot deps        : <nativeLibraryDir>/libtalloc.so, libandroid-shmem.so
 *  - rootfs            : <filesDir>/proot/rootfs/
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libloader.so")

    fun tallocBinary(context: Context): File =
        File(nativeLibDir(context), "libtalloc.so")

    fun shmemBinary(context: Context): File =
        File(nativeLibDir(context), "libandroid-shmem.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    fun areRequiredLibrariesAvailable(context: Context): Boolean =
        tallocBinary(context).exists() && shmemBinary(context).exists()

    /** ELF class of the bundled proot (32/64) or null. */
    fun prootArch(context: Context): Int? = elfBits(prootBinary(context))

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) &&
            areRequiredLibrariesAvailable(context) &&
            isRootfsInstalled(context)

    /** ELF class of a binary (32 / 64) or null if not a readable ELF. */
    private fun elfBits(f: File): Int? {
        return try {
            val b = ByteArray(5)
            java.io.FileInputStream(f).use {
                val n = it.read(b)
                if (n < 5) return null
            }
            if (
                b[0] == 0x7f.toByte() &&
                b[1] == 'E'.code.toByte() &&
                b[2] == 'L'.code.toByte() &&
                b[3] == 'F'.code.toByte()
            ) {
                when (b[4]) {
                    2.toByte() -> 64
                    1.toByte() -> 32
                    else -> null
                }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    /** Best-effort guest arch of an installed rootfs (32/64). */
    fun rootfsArch(context: Context): Int? {
        val rootfs = rootfsDir(context)
        return listOf("usr/bin/ls", "bin/ls", "usr/bin/sh", "bin/sh", "usr/bin/coreutils")
            .firstNotNullOfOrNull {
                val f = File(rootfs, it)
                if (f.exists()) elfBits(f) else null
            }
    }

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    data class ProcessConfig(
        val program: String,
        val argv: List<String>,
        val env: Map<String, String>,
        val cwd: String
    )

    private fun tmpDir(context: Context): File =
        File(context.applicationContext.codeCacheDir, "proot").also { it.mkdirs() }

    private fun guestLoginCommand(appCtx: Context): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "--login")
        } else {
            Log.w(TAG, "bash not found in rootfs, falling back to /bin/sh")
            listOf("/bin/sh")
        }
    }

    private fun guestCommand(appCtx: Context, command: String): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "-lc", command)
        } else {
            listOf("/bin/sh", "-c", command)
        }
    }

    private fun prootFlags(appCtx: Context, workDir: String?, link2Symlink: Boolean): List<String> {
        val rootfs = rootfsDir(appCtx).absolutePath
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"
        val opts = mutableListOf<String>()
        opts += listOf("-r", rootfs)
        opts += listOf("-b", "/dev", "-b", "/proc", "-b", "/sys", "-b", "$sdcard:/sdcard")
        if (link2Symlink) opts += "--link2symlink"
        opts += "-0"
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        return opts
    }

    /**
     * Runtime env REQUIRED by the current arm64 Termux-derived proot bundle.
     */
    fun runtimeEnv(context: Context): Map<String, String> {
        val appCtx = context.applicationContext
        val t = tmpDir(appCtx)
        val libDir = nativeLibDir(appCtx)
        val loader = loaderBinary(appCtx)

        val env = linkedMapOf(
            "TERM" to "xterm-256color",
            "COLORTERM" to "truecolor",
            "HOME" to "/root",
            "USER" to "root",
            "SHELL" to "/bin/bash",
            "LANG" to "C.UTF-8",
            "LC_ALL" to "C.UTF-8",
            "PROOT_NO_SECCOMP" to "1",
            "PROOT_TMP_DIR" to t.absolutePath,
            "TMPDIR" to t.absolutePath,
            "LD_LIBRARY_PATH" to libDir,
            "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )

        if (loader.exists()) {
            env["PROOT_LOADER"] = loader.absolutePath
        } else {
            Log.i(TAG, "no external loader; proot will use its embedded loader")
        }

        System.getenv("ANDROID_ROOT")?.let { env["ANDROID_ROOT"] = it }
        System.getenv("ANDROID_DATA")?.let { env["ANDROID_DATA"] = it }
        System.getenv("EXTERNAL_STORAGE")?.let { env["EXTERNAL_STORAGE"] = it }

        return env
    }

    private fun runtimeEnvArray(context: Context): Array<String> =
        runtimeEnv(context).map { "${it.key}=${it.value}" }.toTypedArray()

    /**
     * Interactive terminal session config for TerminalSession.
     *
     * NOTE: TerminalSession passes args as argv; proot/getopt expects argv[0] to be the program
     * name, so we keep a fake argv0 "proot" in args[0].
     */
    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestLoginCommand(appCtx)
        val opts = (listOf("proot") + flags + guest).toTypedArray()
        val env = runtimeEnvArray(appCtx)
        Log.i(TAG, "proot ready: $proot ; rootfs=${rootfsDir(appCtx)} ; args=${opts.joinToString(" ")}")
        return ProotConfig(proot, opts, env, appCtx.filesDir.absolutePath)
    }

    /**
     * One-shot process config for background command execution.
     * Unlike [build], argv here must NOT contain the fake argv0.
     */
    fun buildCommandProcess(
        context: Context,
        command: String,
        workDir: String? = null,
        link2Symlink: Boolean = true
    ): ProcessConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestCommand(appCtx, command)
        return ProcessConfig(
            program = proot,
            argv = flags + guest,
            env = runtimeEnv(appCtx),
            cwd = appCtx.filesDir.absolutePath
        )
    }

    /**
     * Run a one-shot proot smoke test (same flags/env as the real session) and return combined
     * stdout+stderr.
     */
    fun runSmokeTest(context: Context): String {
        val appCtx = context.applicationContext
        val sb = StringBuilder()
        val proot = prootBinary(appCtx)
        val loader = loaderBinary(appCtx)
        val talloc = tallocBinary(appCtx)
        val shmem = shmemBinary(appCtx)
        val rootfs = rootfsDir(appCtx)

        sb.appendLine("proot  : ${proot.absolutePath} exists=${proot.exists()}")
        sb.appendLine("loader : ${loader.absolutePath} exists=${loader.exists()}")
        sb.appendLine("talloc : ${talloc.absolutePath} exists=${talloc.exists()}")
        sb.appendLine("shmem  : ${shmem.absolutePath} exists=${shmem.exists()}")
        sb.appendLine("rootfs : ${rootfs.absolutePath} installed=${isRootfsInstalled(appCtx)}")

        val pArch = prootArch(appCtx)
        val pArchStr = when (pArch) { 64 -> "64-bit"; 32 -> "32-bit"; else -> "?" }
        val rArch = rootfsArch(appCtx)
        val rArchStr = when (rArch) { 64 -> "64-bit (aarch64)"; 32 -> "32-bit (armhf)"; else -> "?" }

        sb.appendLine("proot arch : $pArchStr")
        sb.appendLine("rootfs arch: $rArchStr")

        if (!areRequiredLibrariesAvailable(appCtx)) {
            sb.appendLine("!! MISSING bundled proot deps in nativeLibraryDir")
        }

        if (pArch == 64 && rArch == 32) {
            sb.appendLine("!! MISMATCH: proot is 64-bit but rootfs is 32-bit -> install ARM64 rootfs")
        } else if (pArch == 32 && rArch == 64) {
            sb.appendLine("!! MISMATCH: proot is 32-bit but rootfs is 64-bit -> install ARMHF rootfs")
        }

        if (!proot.exists()) return sb.appendLine("=> proot binary missing").toString()

        val baseEnvMap = runtimeEnv(appCtx).toMutableMap()
        val flagsFull = prootFlags(appCtx, null, true)
        val flagsNoL2S = prootFlags(appCtx, null, false)

        fun runProbe(label: String, flags: List<String>, guest: List<String>, verbose: Boolean): String {
            val envMap = HashMap(baseEnvMap)
            if (verbose) envMap["PROOT_VERBOSE"] = "9"
            val argv = mutableListOf(proot.absolutePath).apply {
                addAll(flags)
                addAll(guest)
            }

            val out = StringBuilder()
            val code = try {
                val pb = ProcessBuilder(argv).redirectErrorStream(true)
                pb.environment().clear()
                pb.environment().putAll(envMap)
                pb.directory(appCtx.filesDir)
                val p = pb.start()
                val reader = Thread {
                    try {
                        p.inputStream.bufferedReader().forEachLine { l -> out.appendLine(l) }
                    } catch (_: Exception) {}
                }
                reader.start()

                val deadline = System.currentTimeMillis() + 8000
                var c = -1
                while (System.currentTimeMillis() < deadline) {
                    try {
                        c = p.exitValue()
                        break
                    } catch (_: IllegalThreadStateException) {
                        Thread.sleep(80)
                    }
                }
                if (c == -1) {
                    p.destroy()
                    out.appendLine("(timeout 8s)")
                }
                reader.join(1500)
                c
            } catch (e: Exception) {
                out.appendLine("exception: ${e.message}")
                -1
            }

            val text = out.toString()
            val tail = if (text.length > 1600) {
                "…[head truncated]…\n" + text.substring(text.length - 1600)
            } else {
                text
            }
            return "### $label  (exit=$code)\n$tail\n"
        }

        sb.appendLine("=== proot probes (PROOT_VERBOSE=9; tail shown) ===")
        sb.append(runProbe("A full-flags + /bin/true", flagsFull, listOf("/bin/true"), true))
        sb.append(runProbe("B full-flags + /bin/sh echo", flagsFull, listOf("/bin/sh", "-c", "echo OK"), true))
        sb.append(runProbe("C NO link2symlink + /bin/true", flagsNoL2S, listOf("/bin/true"), true))
        return sb.toString()
    }
}