package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import kotlin.jvm.Volatile
import java.io.File
import java.io.FileInputStream

/**
 * proot environment with EXTERNAL loader in nativeLibraryDir.
 *
 * Layout:
 *  - proot main binary : <nativeLibraryDir>/libproot.so         (dynamic, bionic-only)
 *  - proot loader ELF  : <nativeLibraryDir>/libproot-loader.so  (static aarch64 ELF)
 *  - rootfs            : <filesDir>/proot/rootfs/
 *
 * Why external loader:
 *   On strict Android SELinux policies (Huawei/EMUI), proot's default behaviour of
 *   extracting an embedded loader ELF into PROOT_TMP_DIR and execve()-ing it fails
 *   with "Permission denied" (SELinux blocks exec of newly-written ELFs from app
 *   data). nativeLibraryDir is the ONE place where the SELinux policy for untrusted
 *   apps allows execute_no_trans on ELF files. So we ship the loader there and set
 *   PROOT_LOADER to point at it.
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libproot-loader.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory ||
            File(rootfsDir(context), "usr/bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    fun isLoaderAvailable(context: Context): Boolean =
        loaderBinary(context).exists()

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) && isRootfsInstalled(context)

    private fun elfBits(f: File): Int? {
        return try {
            val b = ByteArray(5)
            val n = FileInputStream(f).use { it.read(b) }
            if (n < 5) return null
            if (
                b[0] == 0x7f.toByte() &&
                b[1] == 'E'.code.toByte() &&
                b[2] == 'L'.code.toByte() &&
                b[3] == 'F'.code.toByte()
            ) {
                when (b[4]) {
                    2.toByte() -> 64
                    1.toByte() -> 32
                    else -> null
                }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    fun prootArch(context: Context): Int? = elfBits(prootBinary(context))

    fun rootfsArch(context: Context): Int? {
        val rootfs = rootfsDir(context)
        return listOf(
            "usr/bin/ls", "bin/ls",
            "usr/bin/sh", "bin/sh",
            "usr/bin/bash", "bin/bash",
            "usr/bin/coreutils"
        ).firstNotNullOfOrNull { rel ->
            val f = File(rootfs, rel)
            if (f.exists()) elfBits(f) else null
        }
    }

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    data class ProcessConfig(
        val program: String,
        val argv: List<String>,
        val env: Map<String, String>,
        val cwd: String
    )

    /**
     * Find a writable+exec directory. Even with external PROOT_LOADER, proot still
     * needs a tmp dir for other files (glue rootfs paths etc).
     */
    fun findExecTmpDir(context: Context): File {
        val appCtx = context.applicationContext
        val candidates = listOf(
            File(appCtx.filesDir, "proot-tmp"),
            File(rootfsDir(appCtx), "tmp"),
            File(appCtx.cacheDir, "proot"),
            File(appCtx.codeCacheDir, "proot")
        )

        for (dir in candidates) {
            try {
                dir.mkdirs()
                if (!dir.isDirectory) continue

                val probe = File(dir, ".exec-probe.sh")
                probe.writeText("#!/system/bin/sh\nexit 42\n")
                if (!probe.setExecutable(true, false)) {
                    probe.delete()
                    continue
                }

                val pb = ProcessBuilder("/system/bin/sh", probe.absolutePath)
                    .redirectErrorStream(true)
                val p = pb.start()
                val ok = p.waitFor() == 42
                probe.delete()

                if (ok) {
                    Log.i(TAG, "PROOT_TMP_DIR chosen: ${dir.absolutePath}")
                    return dir
                }
            } catch (e: Exception) {
                Log.w(TAG, "PROOT_TMP_DIR candidate failed ${dir.absolutePath}: ${e.message}")
            }
        }

        val fallback = File(rootfsDir(appCtx), "tmp").also { it.mkdirs() }
        Log.w(TAG, "No exec-capable tmp found, using fallback: ${fallback.absolutePath}")
        return fallback
    }

    private fun tmpDir(context: Context): File {
        val dir = findExecTmpDir(context)
        try {
            dir.setReadable(true, true)
            dir.setWritable(true, true)
            dir.setExecutable(true, true)
        } catch (_: Exception) {}
        return dir
    }

    fun ensureRootfsExecutable(context: Context): String {
        val rootfs = rootfsDir(context)
        if (!rootfs.isDirectory) return "rootfs not installed"

        val log = StringBuilder()
        val binDirs = listOf(
            "bin", "sbin",
            "usr/bin", "usr/sbin",
            "usr/local/bin", "usr/local/sbin",
            "lib", "lib64", "usr/lib", "usr/lib64",
            "usr/libexec"
        )

        var totalFixed = 0
        for (rel in binDirs) {
            val dir = File(rootfs, rel)
            if (!dir.isDirectory) continue
            val files = dir.listFiles() ?: continue
            var fixedHere = 0
            for (f in files) {
                if (f.isFile && !f.canExecute()) {
                    try {
                        if (f.setExecutable(true, false)) {
                            fixedHere++
                            totalFixed++
                        }
                    } catch (_: Exception) {}
                }
            }
            log.appendLine("  $rel: found=${files.size}, fixed=$fixedHere")
        }
        log.appendLine("Total fixed: $totalFixed")
        return log.toString()
    }

    private fun guestLoginCommand(appCtx: Context): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "--login")
        } else {
            Log.w(TAG, "bash not found in rootfs, falling back to /bin/sh")
            listOf("/bin/sh")
        }
    }

    private fun guestCommand(appCtx: Context, command: String): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "-lc", command)
        } else {
            listOf("/bin/sh", "-c", command)
        }
    }

    private fun prootFlags(appCtx: Context, workDir: String?, link2Symlink: Boolean): List<String> {
        val rootfs = rootfsDir(appCtx).absolutePath
        val opts = mutableListOf<String>()

        opts += listOf("-r", rootfs)
        opts += listOf("-b", "/dev")
        opts += listOf("-b", "/proc")
        opts += listOf("-b", "/sys")

        // /sdcard bind is optional: on scoped-storage Android (10+) the app process may not be
        // able to see EXTERNAL_STORAGE at all. Binding a non-existent source makes proot refuse
        // to start entirely, so only add the bind when the source actually exists.
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"
        if (File(sdcard).isDirectory) {
            opts += listOf("-b", "$sdcard:/sdcard")
        } else {
            Log.w(TAG, "sdcard '$sdcard' not visible to the app, skipping /sdcard bind")
        }

        if (link2Symlink) opts += "--link2symlink"

        // -0 makes every process look like uid 0 (root). dpkg/apt need this: without it the
        // rootfs files owned by the app uid make dpkg fail with "Permission denied" when it
        // chowns/creates /var/lib/dpkg files as the guest root user.
        opts += "-0"
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        return opts
    }

    fun runtimeEnv(context: Context): Map<String, String> {
        val appCtx = context.applicationContext
        val t = tmpDir(appCtx)
        val loader = loaderBinary(appCtx)

        val env = linkedMapOf(
            "TERM" to "xterm-256color",
            "COLORTERM" to "truecolor",
            "HOME" to "/root",
            "USER" to "root",
            "SHELL" to "/bin/bash",
            "LANG" to "C.UTF-8",
            "LC_ALL" to "C.UTF-8",
            // apt/dpkg must not block on debconf prompts inside the guest.
            "DEBIAN_FRONTEND" to "noninteractive",
            "PROOT_NO_SECCOMP" to "1",
            "PROOT_TMP_DIR" to t.absolutePath,
            // Guest TMPDIR must point INSIDE the rootfs. A host path (e.g. the app files dir)
            // is translated by proot into "<rootfs>/<host-path>" which does not exist, so
            // programs that honour TMPDIR (dpkg-deb, mktemp, postinst scripts, ...) would fail
            // with "cannot create temp file" — a very common cause of dpkg errors in proot.
            "TMPDIR" to "/tmp",
            "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )

        // KEY: use the external loader shipped in nativeLibraryDir. This is the ONE
        // place on Android where SELinux reliably permits exec of ELFs.
        if (loader.exists()) {
            env["PROOT_LOADER"] = loader.absolutePath
            Log.i(TAG, "Using external PROOT_LOADER: ${loader.absolutePath}")
        } else {
            Log.w(TAG, "libproot-loader.so NOT FOUND in nativeLibraryDir; proot will try embedded loader (may fail on strict Android)")
        }

        System.getenv("ANDROID_ROOT")?.let { env["ANDROID_ROOT"] = it }
        System.getenv("ANDROID_DATA")?.let { env["ANDROID_DATA"] = it }
        System.getenv("EXTERNAL_STORAGE")?.let { env["EXTERNAL_STORAGE"] = it }
        System.getenv("BOOTCLASSPATH")?.let { env["BOOTCLASSPATH"] = it }

        return env
    }

    private fun runtimeEnvArray(context: Context): Array<String> =
        runtimeEnv(context).map { "${it.key}=${it.value}" }.toTypedArray()

    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        ensureRootfsExecutable(appCtx)
        maybePrepareInBackground(appCtx)

        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestLoginCommand(appCtx)

        val opts = (listOf("proot") + flags + guest).toTypedArray()
        val env = runtimeEnvArray(appCtx)

        Log.i(TAG, "proot ready: $proot ; args=${opts.joinToString(" ")}")

        return ProotConfig(
            prootPath = proot,
            args = opts,
            env = env,
            cwd = appCtx.filesDir.absolutePath
        )
    }

    fun buildCommandProcess(
        context: Context,
        command: String,
        workDir: String? = null,
        link2Symlink: Boolean = true
    ): ProcessConfig {
        val appCtx = context.applicationContext
        ensureRootfsExecutable(appCtx)
        // Heal a half-finished dpkg transaction before running any apt/dpkg command, so that
        // "apt upgrade" no longer dies with "E: Sub-process /usr/bin/dpkg returned an error".
        ensurePrepared(appCtx)
        return buildCommandProcessRaw(appCtx, command, workDir, link2Symlink)
    }

    private fun buildCommandProcessRaw(
        appCtx: Context,
        command: String,
        workDir: String? = null,
        link2Symlink: Boolean = true
    ): ProcessConfig {
        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestCommand(appCtx, command)

        return ProcessConfig(
            program = proot,
            argv = flags + guest,
            env = runtimeEnv(appCtx),
            cwd = appCtx.filesDir.absolutePath
        )
    }

    // ---------------------------------------------------------------------------
    // apt/dpkg self-healing preparation
    //
    // A stock Ubuntu rootfs extracted from a tarball is missing several things that
    // dpkg/apt need in a proot container, and an interrupted `apt upgrade` leaves the
    // dpkg database in a half-configured state that makes every later install fail.
    // prepareRootfs() fixes all of that inside the guest (idempotent), mirrors what
    // Termux's proot-distro does for its Ubuntu images.
    // ---------------------------------------------------------------------------

    private val prepareMutex = Any()
    @Volatile
    private var prepareRunning = false

    private fun prepareMarker(appCtx: Context): File =
        File(appCtx.filesDir, "proot/.prepared-v2")

    fun isPrepared(context: Context): Boolean = prepareMarker(context.applicationContext).exists()

    private val PREPARE_SCRIPT = """
        set +e
        export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
        export DEBIAN_FRONTEND=noninteractive
        umask 022

        FAIL=0

        # 1) Essential directories - dpkg/apt explode without these
        mkdir -p /var/lib/dpkg/updates /var/lib/dpkg/info \
                 /var/lib/apt/lists/partial /var/cache/apt/archives/partial \
                 /var/log/apt /run /run/lock /dev/shm /tmp /var/tmp 2>/dev/null

        # 2) Ownership/permissions. Under proot -0 every process looks like root, but the
        #    files underneath are owned by the app uid; guest-visible ownership must be root.
        chown -R root:root /var/lib/dpkg /var/lib/apt /var/cache/apt /run /tmp /var/tmp 2>/dev/null
        chmod 755 /var/lib/dpkg /var/lib/apt /var/cache/apt /run 2>/dev/null
        chmod 755 /var/lib/dpkg/updates /var/lib/dpkg/info /var/lib/apt/lists/partial \
                  /var/cache/apt/archives/partial /var/log/apt /run/lock 2>/dev/null
        chmod 1777 /tmp /var/tmp /dev/shm 2>/dev/null

        # 3) proot-friendly apt configuration (sandbox user, no config prompts, no pipeline hangs)
        mkdir -p /etc/apt/apt.conf.d
        cat > /etc/apt/apt.conf.d/00proot <<'EOF'
        APT::Sandbox::User "root";
        DPkg::Options { "--force-confdef"; "--force-confold"; };
        Acquire::http::Pipeline-Depth "0";
        Acquire::Retries "3";
        EOF

        # 4) Never start systemd services from maintainer scripts inside the container
        if [ ! -x /usr/sbin/policy-rc.d ]; then
          printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d
          chmod 755 /usr/sbin/policy-rc.d
        fi

        # 5) DNS fallback for apt/wget/curl/git
        if [ ! -s /etc/resolv.conf ]; then
          printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
        fi

        # 6) Remove stale lock files left by a force-stopped apt/dpkg (fcntl locks die with the
        #    process, so deleting the files is only safe when nothing is running - check /proc).
        APT_RUNNING=0
        for pid in /proc/[0-9]*; do
          comm=${'$'}(cat "${'$'}pid/comm" 2>/dev/null)
          case "${'$'}comm" in
            apt|apt-get|dpkg|dpkg-deb|unattended-upgr) APT_RUNNING=1; break ;;
          esac
        done
        if [ "${'$'}APT_RUNNING" = "0" ]; then
          rm -f /var/lib/dpkg/lock /var/lib/dpkg/lock-frontend \
                /var/lib/apt/lists/lock /var/cache/apt/archives/lock 2>/dev/null
        fi

        # 7) Heal a half-finished dpkg transaction (the "apt upgrade -> dpkg error" case)
        if command -v dpkg >/dev/null 2>&1; then
          echo "==> dpkg --configure -a (repair interrupted packages)"
          dpkg --configure -a --force-confold --force-confdef || FAIL=1
        fi
        if command -v apt-get >/dev/null 2>&1; then
          echo "==> apt-get -f install -y (fix broken dependencies)"
          apt-get -f install -y || FAIL=1
        fi

        echo "==> prepare finished"
        exit ${'$'}FAIL
    """.trimIndent()

    private fun runPrepareScript(appCtx: Context, timeoutMs: Long): Pair<Int, String> {
        val pc = buildCommandProcessRaw(appCtx, PREPARE_SCRIPT)
        return runProbeProcess(appCtx, pc.program, pc.argv, pc.env, timeoutMs)
    }

    /**
     * Run the apt/dpkg self-healing script inside the rootfs. Idempotent; the marker is
     * written after a completed attempt so it normally runs only once. Returns (exitCode, output).
     */
    fun prepareRootfs(context: Context, force: Boolean = false, timeoutMs: Long = 300_000L): Pair<Int, String> {
        val appCtx = context.applicationContext
        if (!isReady(appCtx)) return (-1) to "proot/rootfs not ready"
        if (!force && prepareMarker(appCtx).exists()) return 0 to "(already prepared)"

        ensureRootfsExecutable(appCtx)

        synchronized(prepareMutex) {
            prepareRunning = true
            return try {
                val result = runPrepareScript(appCtx, timeoutMs)
                if (result.first != -1) {
                    try { prepareMarker(appCtx).writeText("ok") } catch (_: Exception) {}
                }
                result
            } catch (e: Exception) {
                (-1) to ("prepare error: ${e.message}\n")
            } finally {
                prepareRunning = false
            }
        }
    }

    private fun ensurePrepared(appCtx: Context) {
        if (prepareMarker(appCtx).exists() || prepareRunning) return
        synchronized(prepareMutex) {
            if (prepareMarker(appCtx).exists() || prepareRunning) return
            prepareRunning = true
            try {
                val (code, out) = runPrepareScript(appCtx, 90_000L)
                Log.i(TAG, "auto-prepare exit=$code")
                if (out.isNotBlank()) Log.i(TAG, out.takeLast(4000))
                if (code != -1) {
                    try { prepareMarker(appCtx).writeText("ok") } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                Log.w(TAG, "auto-prepare error: ${e.message}")
            } finally {
                prepareRunning = false
            }
        }
    }

    private fun maybePrepareInBackground(appCtx: Context) {
        if (prepareMarker(appCtx).exists() || prepareRunning) return
        Thread {
            ensurePrepared(appCtx)
        }.apply {
            name = "proot-auto-prepare"
            start()
        }
    }

    private fun runProbeProcess(
        appCtx: Context,
        program: String,
        argv: List<String>,
        envMap: Map<String, String>,
        timeoutMs: Long = 8000L
    ): Pair<Int, String> {
        val out = StringBuilder()
        return try {
            val pb = ProcessBuilder(listOf(program) + argv).redirectErrorStream(true)
            val childEnv = pb.environment()
            for ((k, v) in envMap) {
                childEnv[k] = v
            }
            pb.directory(appCtx.filesDir)

            val p = pb.start()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        out.appendLine(line)
                    }
                } catch (_: Exception) {
                }
            }
            reader.start()

            val deadline = System.currentTimeMillis() + timeoutMs
            var code = -1
            while (System.currentTimeMillis() < deadline) {
                try {
                    code = p.exitValue()
                    break
                } catch (_: IllegalThreadStateException) {
                    Thread.sleep(80)
                }
            }
            if (code == -1) {
                p.destroy()
                out.appendLine("(timeout ${timeoutMs}ms)")
            }
            reader.join(1500)
            code to out.toString()
        } catch (e: Exception) {
            (-1) to ("exception: ${e.message}\n")
        }
    }

    fun inspectRootfs(context: Context): String {
        val rootfs = rootfsDir(context)
        val sb = StringBuilder()
        sb.appendLine("rootfs: ${rootfs.absolutePath}")
        sb.appendLine("exists: ${rootfs.exists()}")
        sb.appendLine("bin/ dir: ${File(rootfs, "bin").isDirectory}")
        sb.appendLine("usr/bin/ dir: ${File(rootfs, "usr/bin").isDirectory}")

        val toCheck = listOf(
            "bin/bash", "usr/bin/bash",
            "bin/sh", "usr/bin/sh",
            "bin/ls", "usr/bin/ls",
            "lib64/ld-linux-aarch64.so.1",
            "lib/ld-linux-aarch64.so.1",
            "lib/aarch64-linux-gnu/ld-linux-aarch64.so.1"
        )
        sb.appendLine("--- key files ---")
        for (rel in toCheck) {
            val f = File(rootfs, rel)
            if (f.exists()) {
                sb.appendLine("$rel  size=${f.length()}  x=${f.canExecute()}  elf=${elfBits(f)}")
            } else {
                sb.appendLine("$rel  MISSING")
            }
        }
        return sb.toString()
    }

    fun runSmokeTest(context: Context): String {
        val appCtx = context.applicationContext
        val sb = StringBuilder()

        val proot = prootBinary(appCtx)
        val loader = loaderBinary(appCtx)
        val rootfs = rootfsDir(appCtx)

        sb.appendLine("proot  : ${proot.absolutePath} exists=${proot.exists()}")
        sb.appendLine("loader : ${loader.absolutePath} exists=${loader.exists()}")
        sb.appendLine("rootfs : ${rootfs.absolutePath} installed=${isRootfsInstalled(appCtx)}")

        val pArch = prootArch(appCtx)
        val rArch = rootfsArch(appCtx)
        sb.appendLine("proot arch : ${when (pArch) { 64 -> "64-bit"; 32 -> "32-bit"; else -> "?" }}")
        sb.appendLine("rootfs arch: ${when (rArch) { 64 -> "64-bit (aarch64)"; 32 -> "32-bit (armhf)"; else -> "?" }}")

        if (!proot.exists()) {
            return sb.appendLine("=> proot binary missing").toString()
        }

        sb.appendLine()
        sb.appendLine("=== rootfs snapshot ===")
        sb.append(inspectRootfs(appCtx))

        sb.appendLine()
        sb.appendLine("=== rootfs chmod +x pass ===")
        sb.append(ensureRootfsExecutable(appCtx))

        val env = runtimeEnv(appCtx)
        sb.appendLine()
        sb.appendLine("=== chosen PROOT_TMP_DIR: ${env["PROOT_TMP_DIR"]} ===")
        sb.appendLine("=== PROOT_LOADER: ${env["PROOT_LOADER"] ?: "<embedded>"} ===")

        sb.appendLine()
        sb.appendLine("=== proot --version ===")
        run {
            val (code, out) = runProbeProcess(
                appCtx,
                proot.absolutePath,
                listOf("--version"),
                env,
                4000L
            )
            sb.appendLine("exit=$code")
            if (out.isNotBlank()) sb.appendLine(out.trim())
        }

        val flagsFull = prootFlags(appCtx, null, true)
        val flagsNoL2S = prootFlags(appCtx, null, false)

        fun runProbe(label: String, flags: List<String>, guest: List<String>, verbose: Boolean) {
            val envMap = HashMap(env)
            if (verbose) envMap["PROOT_VERBOSE"] = "1"

            val argv = flags + guest
            val (code, text) = runProbeProcess(appCtx, proot.absolutePath, argv, envMap, 8000L)
            val tail = if (text.length > 1800) {
                "…[head truncated]…\n" + text.takeLast(1800)
            } else {
                text
            }
            sb.appendLine("### $label (exit=$code)")
            sb.appendLine(tail)
        }

        sb.appendLine()
        sb.appendLine("=== proot probes ===")
        runProbe("A full-flags + /bin/true",       flagsFull,  listOf("/bin/true"),                       true)
        runProbe("B full-flags + /bin/sh echo",    flagsFull,  listOf("/bin/sh", "-c", "echo OK"),        true)
        runProbe("C NO link2symlink + /bin/true",  flagsNoL2S, listOf("/bin/true"),                       true)

        return sb.toString()
    }
}