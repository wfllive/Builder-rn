package expo.modules.termuxterminal

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileInputStream

/**
 * proot-based Linux environment.
 *
 * Layout:
 *  - proot host binary : <nativeLibraryDir>/libproot.so
 *  - proot loader      : <nativeLibraryDir>/libloader.so
 *  - proot deps        : <nativeLibraryDir>/libtalloc.so, libandroid-shmem.so
 *  - rootfs            : <filesDir>/proot/rootfs/
 */
object ProotEnvironment {

    private const val TAG = "TermuxProot"

    fun nativeLibDir(context: Context): String =
        context.applicationContext.applicationInfo.nativeLibraryDir

    fun prootBinary(context: Context): File =
        File(nativeLibDir(context), "libproot.so")

    fun loaderBinary(context: Context): File =
        File(nativeLibDir(context), "libloader.so")

    fun tallocBinary(context: Context): File =
        File(nativeLibDir(context), "libtalloc.so")

    fun shmemBinary(context: Context): File =
        File(nativeLibDir(context), "libandroid-shmem.so")

    fun rootfsDir(context: Context): File =
        File(context.applicationContext.filesDir, "proot/rootfs")

    fun isRootfsInstalled(context: Context): Boolean =
        File(rootfsDir(context), "bin").isDirectory ||
            File(rootfsDir(context), "usr/bin").isDirectory

    fun isProotBinaryAvailable(context: Context): Boolean =
        prootBinary(context).exists()

    fun areRequiredLibrariesAvailable(context: Context): Boolean =
        tallocBinary(context).exists() && shmemBinary(context).exists()

    fun isReady(context: Context): Boolean =
        isProotBinaryAvailable(context) &&
            areRequiredLibrariesAvailable(context) &&
            isRootfsInstalled(context)

    /** ELF class of a file (32 / 64) or null if unreadable/not ELF. */
    private fun elfBits(f: File): Int? {
        return try {
            val b = ByteArray(5)
            val n = FileInputStream(f).use { it.read(b) }
            if (n < 5) return null
            if (
                b[0] == 0x7f.toByte() &&
                b[1] == 'E'.code.toByte() &&
                b[2] == 'L'.code.toByte() &&
                b[3] == 'F'.code.toByte()
            ) {
                when (b[4]) {
                    2.toByte() -> 64
                    1.toByte() -> 32
                    else -> null
                }
            } else null
        } catch (_: Exception) {
            null
        }
    }

    /** ELF class of bundled proot (32 / 64) or null. */
    fun prootArch(context: Context): Int? = elfBits(prootBinary(context))

    /** Best-effort guest arch of the installed rootfs (32 / 64). */
    fun rootfsArch(context: Context): Int? {
        val rootfs = rootfsDir(context)
        return listOf(
            "usr/bin/ls",
            "bin/ls",
            "usr/bin/sh",
            "bin/sh",
            "usr/bin/bash",
            "bin/bash",
            "usr/bin/coreutils"
        ).firstNotNullOfOrNull { rel ->
            val f = File(rootfs, rel)
            if (f.exists()) elfBits(f) else null
        }
    }

    data class ProotConfig(
        val prootPath: String,
        val args: Array<String>,
        val env: Array<String>,
        val cwd: String
    )

    data class ProcessConfig(
        val program: String,
        val argv: List<String>,
        val env: Map<String, String>,
        val cwd: String
    )

    private fun tmpDir(context: Context): File =
        File(context.applicationContext.codeCacheDir, "proot").also { it.mkdirs() }

    private fun guestLoginCommand(appCtx: Context): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "--login")
        } else {
            Log.w(TAG, "bash not found in rootfs, falling back to /bin/sh")
            listOf("/bin/sh")
        }
    }

    private fun guestCommand(appCtx: Context, command: String): List<String> {
        val rootfs = rootfsDir(appCtx)
        val bashCandidates = listOf(
            File(rootfs, "bin/bash"),
            File(rootfs, "usr/bin/bash")
        )
        return if (bashCandidates.any { it.exists() }) {
            listOf("/bin/bash", "-lc", command)
        } else {
            listOf("/bin/sh", "-c", command)
        }
    }

    private fun prootFlags(appCtx: Context, workDir: String?, link2Symlink: Boolean): List<String> {
        val rootfs = rootfsDir(appCtx).absolutePath
        val sdcard = System.getenv("EXTERNAL_STORAGE") ?: "/sdcard"
        val opts = mutableListOf<String>()

        opts += listOf("-r", rootfs)
        opts += listOf("-b", "/dev")
        opts += listOf("-b", "/proc")
        opts += listOf("-b", "/sys")
        opts += listOf("-b", "$sdcard:/sdcard")

        if (link2Symlink) opts += "--link2symlink"

        opts += "-0"
        opts += listOf("-w", if (!workDir.isNullOrEmpty()) workDir else "/root")
        return opts
    }

    /**
     * Runtime env REQUIRED by current arm64 Termux-derived proot bundle.
     *
     * includeLoader=false is useful for diagnostics to check whether libloader.so itself
     * causes an early crash.
     */
    fun runtimeEnv(context: Context, includeLoader: Boolean = true): Map<String, String> {
        val appCtx = context.applicationContext
        val t = tmpDir(appCtx)
        val libDir = nativeLibDir(appCtx)
        val loader = loaderBinary(appCtx)

        val inheritedLd = System.getenv("LD_LIBRARY_PATH")
        val joinedLd = listOf(libDir, inheritedLd)
            .filterNotNull()
            .filter { it.isNotBlank() }
            .joinToString(":")

        val env = linkedMapOf(
            "TERM" to "xterm-256color",
            "COLORTERM" to "truecolor",
            "HOME" to "/root",
            "USER" to "root",
            "SHELL" to "/bin/bash",
            "LANG" to "C.UTF-8",
            "LC_ALL" to "C.UTF-8",
            "PROOT_NO_SECCOMP" to "1",
            "PROOT_TMP_DIR" to t.absolutePath,
            "TMPDIR" to t.absolutePath,
            "LD_LIBRARY_PATH" to joinedLd,
            "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        )

        if (includeLoader && loader.exists()) {
            env["PROOT_LOADER"] = loader.absolutePath
        } else if (includeLoader) {
            Log.i(TAG, "no external loader; proot will use its embedded loader")
        }

        System.getenv("ANDROID_ROOT")?.let { env["ANDROID_ROOT"] = it }
        System.getenv("ANDROID_DATA")?.let { env["ANDROID_DATA"] = it }
        System.getenv("EXTERNAL_STORAGE")?.let { env["EXTERNAL_STORAGE"] = it }
        System.getenv("BOOTCLASSPATH")?.let { env["BOOTCLASSPATH"] = it }

        return env
    }

    private fun runtimeEnvArray(context: Context): Array<String> =
        runtimeEnv(context, includeLoader = true)
            .map { "${it.key}=${it.value}" }
            .toTypedArray()

    /**
     * Interactive terminal session config for TerminalSession.
     *
     * NOTE: TerminalSession passes args directly as argv; proot/getopt expects argv[0]
     * to be the program name, so args[0] is a fake "proot".
     */
    fun build(context: Context, workDir: String? = null, link2Symlink: Boolean = true): ProotConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestLoginCommand(appCtx)
        val opts = (listOf("proot") + flags + guest).toTypedArray()
        val env = runtimeEnvArray(appCtx)

        Log.i(
            TAG,
            "proot ready: $proot ; rootfs=${rootfsDir(appCtx)} ; args=${opts.joinToString(" ")}"
        )

        return ProotConfig(
            prootPath = proot,
            args = opts,
            env = env,
            cwd = appCtx.filesDir.absolutePath
        )
    }

    /**
     * One-shot background process config.
     *
     * Unlike [build], argv here must NOT contain the fake argv0.
     */
    fun buildCommandProcess(
        context: Context,
        command: String,
        workDir: String? = null,
        link2Symlink: Boolean = true
    ): ProcessConfig {
        val appCtx = context.applicationContext
        val proot = prootBinary(appCtx).absolutePath
        val flags = prootFlags(appCtx, workDir, link2Symlink)
        val guest = guestCommand(appCtx, command)

        return ProcessConfig(
            program = proot,
            argv = flags + guest,
            env = runtimeEnv(appCtx, includeLoader = true),
            cwd = appCtx.filesDir.absolutePath
        )
    }

    private fun runProbeProcess(
        appCtx: Context,
        argv: List<String>,
        envMap: Map<String, String>,
        timeoutMs: Long = 8000L
    ): Pair<Int, String> {
        val out = StringBuilder()
        return try {
            val pb = ProcessBuilder(argv).redirectErrorStream(true)
            val childEnv = pb.environment()
            for ((k, v) in envMap) {
                childEnv[k] = v
            }
            pb.directory(appCtx.filesDir)

            val p = pb.start()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        out.appendLine(line)
                    }
                } catch (_: Exception) {
                }
            }
            reader.start()

            val deadline = System.currentTimeMillis() + timeoutMs
            var code = -1
            while (System.currentTimeMillis() < deadline) {
                try {
                    code = p.exitValue()
                    break
                } catch (_: IllegalThreadStateException) {
                    Thread.sleep(80)
                }
            }
            if (code == -1) {
                p.destroy()
                out.appendLine("(timeout ${timeoutMs}ms)")
            }
            reader.join(1500)
            code to out.toString()
        } catch (e: Exception) {
            (-1) to ("exception: ${e.message}\n")
        }
    }

    /**
     * Run a one-shot proot smoke test and return combined stdout+stderr.
     */
    fun runSmokeTest(context: Context): String {
        val appCtx = context.applicationContext
        val sb = StringBuilder()

        val proot = prootBinary(appCtx)
        val loader = loaderBinary(appCtx)
        val talloc = tallocBinary(appCtx)
        val shmem = shmemBinary(appCtx)
        val rootfs = rootfsDir(appCtx)

        sb.appendLine("proot  : ${proot.absolutePath} exists=${proot.exists()}")
        sb.appendLine("loader : ${loader.absolutePath} exists=${loader.exists()}")
        sb.appendLine("talloc : ${talloc.absolutePath} exists=${talloc.exists()}")
        sb.appendLine("shmem  : ${shmem.absolutePath} exists=${shmem.exists()}")
        sb.appendLine("rootfs : ${rootfs.absolutePath} installed=${isRootfsInstalled(appCtx)}")

        val pArch = prootArch(appCtx)
        val rArch = rootfsArch(appCtx)

        sb.appendLine("proot arch : ${when (pArch) { 64 -> "64-bit"; 32 -> "32-bit"; else -> "?" }}")
        sb.appendLine("rootfs arch: ${when (rArch) { 64 -> "64-bit (aarch64)"; 32 -> "32-bit (armhf)"; else -> "?" }}")

        if (!areRequiredLibrariesAvailable(appCtx)) {
            sb.appendLine("!! MISSING bundled proot deps in nativeLibraryDir")
        }

        if (pArch == 64 && rArch == 32) {
            sb.appendLine("!! MISMATCH: proot is 64-bit but rootfs is 32-bit -> install ARM64 rootfs")
        } else if (pArch == 32 && rArch == 64) {
            sb.appendLine("!! MISMATCH: proot is 32-bit but rootfs is 64-bit -> install ARMHF rootfs")
        }

        if (!proot.exists()) {
            return sb.appendLine("=> proot binary missing").toString()
        }

        val flagsFull = prootFlags(appCtx, null, true)
        val flagsNoL2S = prootFlags(appCtx, null, false)

        fun runProbe(
            label: String,
            flags: List<String>,
            guest: List<String>,
            includeLoader: Boolean,
            verbose: Boolean
        ): String {
            val envMap = HashMap(runtimeEnv(appCtx, includeLoader = includeLoader))
            if (verbose) envMap["PROOT_VERBOSE"] = "9"

            val argv = mutableListOf(proot.absolutePath).apply {
                addAll(flags)
                addAll(guest)
            }

            val (code, text) = runProbeProcess(appCtx, argv, envMap, timeoutMs = 8000L)
            val tail = if (text.length > 1800) {
                "…[head truncated]…\n" + text.takeLast(1800)
            } else {
                text
            }
            return "### $label (loader=${if (includeLoader) "on" else "off"}, exit=$code)\n$tail\n"
        }

        sb.appendLine("=== direct proot --version ===")
        run {
            val (codeOn, outOn) = runProbeProcess(
                appCtx,
                listOf(proot.absolutePath, "--version"),
                runtimeEnv(appCtx, includeLoader = true),
                timeoutMs = 4000L
            )
            sb.appendLine("with loader: exit=$codeOn")
            if (outOn.isNotBlank()) sb.appendLine(outOn.trim())
        }
        run {
            val (codeOff, outOff) = runProbeProcess(
                appCtx,
                listOf(proot.absolutePath, "--version"),
                runtimeEnv(appCtx, includeLoader = false),
                timeoutMs = 4000L
            )
            sb.appendLine("without loader: exit=$codeOff")
            if (outOff.isNotBlank()) sb.appendLine(outOff.trim())
        }

        sb.appendLine("=== proot probes (PROOT_VERBOSE=9; tail shown) ===")
        sb.append(runProbe("A full-flags + /bin/true", flagsFull, listOf("/bin/true"), includeLoader = true, verbose = true))
        sb.append(runProbe("B full-flags + /bin/sh echo", flagsFull, listOf("/bin/sh", "-c", "echo OK"), includeLoader = true, verbose = true))
        sb.append(runProbe("C NO link2symlink + /bin/true", flagsNoL2S, listOf("/bin/true"), includeLoader = true, verbose = true))
        sb.append(runProbe("D full-flags + /bin/true", flagsFull, listOf("/bin/true"), includeLoader = false, verbose = true))

        return sb.toString()
    }
}