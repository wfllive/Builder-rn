package expo.modules.termuxterminal

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Builds the shell command / environment used to start a terminal session, mirroring how
 * Termux / AndroidIDE bootstrap their login shell.
 *
 * Resolution order for the shell binary:
 *  1. `<filesDir>/usr/bin/bash`   (bootstrap installed by the app / apt-manager)
 *  2. `<filesDir>/usr/bin/sh`
 *  3. `/data/data/com.termux/files/usr/bin/bash` (an installed Termux, if present)
 *  4. `/system/bin/sh`            (always available fallback)
 */
object TerminalEnvironment {

    data class ShellConfig(
        val shellPath: String,
        val args: Array<String>,
        val cwd: String,
        val env: Array<String>,
        val isBootstrap: Boolean
    )

    fun prefix(context: Context): String = File(context.filesDir, "usr").absolutePath
    fun home(context: Context): String = File(context.filesDir, "home").absolutePath

    fun build(context: Context, workingDir: String? = null): ShellConfig {
        val appCtx = context.applicationContext
        val prefix = prefix(appCtx)
        val home = home(appCtx)
        val tmp = "$prefix/tmp"

        File(home).mkdirs()
        File(tmp).mkdirs()

        val execDir = appCtx.getDir("exec", Context.MODE_PRIVATE).absolutePath
        val execBin = "$execDir/bin"
        File(execBin).mkdirs()

        val termuxPrefix = "/data/data/com.termux/files/usr"

        val bootstrapBash = File("$prefix/bin/bash")
        val bootstrapSh = File("$prefix/bin/sh")
        val termuxBash = File("$termuxPrefix/bin/bash")

        val shellPath: String
        val isBootstrap: Boolean
        val libPaths = mutableListOf<String>()

        when {
            bootstrapBash.exists() -> { shellPath = bootstrapBash.absolutePath; isBootstrap = true; libPaths.add("$prefix/lib") }
            bootstrapSh.exists() -> { shellPath = bootstrapSh.absolutePath; isBootstrap = true; libPaths.add("$prefix/lib") }
            termuxBash.exists() -> { shellPath = termuxBash.absolutePath; isBootstrap = false; libPaths.add("$termuxPrefix/lib") }
            else -> { shellPath = "/system/bin/sh"; isBootstrap = false }
        }

        val binDirs = listOfNotNull(
            execBin,
            "$prefix/bin",
            "$termuxPrefix/bin",
            "/system/bin",
            "/system/xbin",
            "/vendor/bin"
        )

        val activePrefix = if (File("$prefix/bin").exists()) prefix else termuxPrefix

        val env = mutableListOf(
            "TERM=xterm-256color",
            "COLORTERM=truecolor",
            "HOME=$home",
            "PREFIX=$activePrefix",
            "TMPDIR=$tmp",
            "PATH=${binDirs.joinToString(":")}",
            "LANG=en_US.UTF-8",
            "LC_ALL=en_US.UTF-8",
            "ANDROID_ROOT=${System.getenv("ANDROID_ROOT") ?: "/system"}",
            "ANDROID_DATA=${System.getenv("ANDROID_DATA") ?: "/data"}",
            "BOOTCLASSPATH=${System.getenv("BOOTCLASSPATH") ?: ""}"
        )
        if (libPaths.isNotEmpty()) {
            env.add("LD_LIBRARY_PATH=${libPaths.joinToString(":")}")
        }
        System.getenv("EXTERNAL_STORAGE")?.let { env.add("EXTERNAL_STORAGE=$it") }

        // Login shell for a real interactive environment (reads /etc/profile, ~/.bashrc ...).
        val args = if (shellPath.endsWith("bash")) arrayOf("--login") else arrayOf("-")

        val cwd = when {
            !workingDir.isNullOrEmpty() && File(workingDir).isDirectory -> workingDir
            File(home).isDirectory -> home
            else -> appCtx.filesDir.absolutePath
        }

        return ShellConfig(shellPath, args, cwd, env.toTypedArray(), isBootstrap)
    }
}
