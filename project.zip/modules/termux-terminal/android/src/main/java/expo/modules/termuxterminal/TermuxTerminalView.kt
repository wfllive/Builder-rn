package expo.modules.termuxterminal

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import com.termux.terminal.TerminalSession
import com.termux.terminal.TerminalSessionClient
import com.termux.view.TerminalView
import com.termux.view.TerminalViewClient
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.views.ExpoView
import java.io.File

class TermuxTerminalView(context: Context, appContext: AppContext) :
    ExpoView(context, appContext), TerminalSessionClient, TerminalViewClient {

    private var terminalView: TerminalView? = null
    private var session: TerminalSession? = null

    init {
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
        setupTerminal()
    }

    private fun setupTerminal() {
        terminalView = TerminalView(context, null).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0D1117"))
            setTextSize(20)
            setTypeface(Typeface.MONOSPACE)
            keepScreenOn = true
            isFocusable = true
            isFocusableInTouchMode = true
        }
        addView(terminalView)

        val appCtx = context.applicationContext
        val filesDir = appCtx?.filesDir?.absolutePath ?: "/data/data/com.sketchwarepro.app/files"
        val codeCacheDir = appCtx?.codeCacheDir?.absolutePath ?: "/data/data/com.sketchwarepro.app/code_cache"
        val prefix = "$codeCacheDir/usr"
        val home = "$filesDir/home"
        val tmpDir = "$prefix/tmp"

        File(home).mkdirs()
        File(tmpDir).mkdirs()

        val bashPath = "$prefix/bin/bash"
        val actualShell = if (File(bashPath).exists() && File(bashPath).canExecute()) bashPath else "/system/bin/sh"

        val env = arrayOf(
            "TERM=xterm-256color",
            "HOME=$home",
            "PREFIX=$prefix",
            "TMPDIR=$tmpDir",
            "PATH=$prefix/bin:/system/bin:/usr/bin",
            "LD_LIBRARY_PATH=$prefix/lib",
            "LANG=en_US.UTF-8",
            "COLORTERM=truecolor"
        )

        session = TerminalSession(actualShell, home, emptyArray(), env, null, this)
        terminalView?.attachSession(session!!)
        terminalView?.setTerminalViewClient(this)

        postDelayed({
            terminalView?.requestFocus()
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
        }, 300)
    }

    // ═══ TerminalSessionClient ═══
    override fun onTextChanged(changedSession: TerminalSession?) { terminalView?.onScreenUpdated() }
    override fun onTitleChanged(changedSession: TerminalSession?) {}
    override fun onSessionFinished(finishedSession: TerminalSession?) {}
    override fun onCopyTextToClipboard(session: TerminalSession?, text: String?) {}
    override fun onPasteTextFromClipboard(session: TerminalSession?) {}
    override fun onBell(session: TerminalSession?) {}
    override fun onColorsChanged(session: TerminalSession?) {}
    override fun onTerminalCursorStateChange(state: Boolean) {}
    override fun getTerminalCursorStyle(): Int? = null
    override fun logError(tag: String?, message: String?) {}
    override fun logWarn(tag: String?, message: String?) {}
    override fun logInfo(tag: String?, message: String?) {}
    override fun logDebug(tag: String?, message: String?) {}
    override fun logVerbose(tag: String?, message: String?) {}
    override fun logStackTraceWithMessage(tag: String?, message: String?, e: Exception?) {}
    override fun logStackTrace(tag: String?, e: Exception?) {}

    // ═══ TerminalViewClient ═══
    override fun onScale(scale: Float): Float = scale
    override fun onSingleTapUp(e: MotionEvent?) {
        terminalView?.requestFocus()
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(terminalView, InputMethodManager.SHOW_IMPLICIT)
    }
    override fun shouldBackButtonBeMappedToEscape(): Boolean = false
    override fun shouldEnforceCharBasedInput(): Boolean = true
    override fun shouldUseCtrlSpaceWorkaround(): Boolean = false
    override fun isTerminalViewSelected(): Boolean = true
    override fun copyModeChanged(copyMode: Boolean) {}
    override fun onKeyDown(keyCode: Int, e: KeyEvent?, session: TerminalSession?): Boolean = false
    override fun onKeyUp(keyCode: Int, e: KeyEvent?): Boolean = false
    override fun onLongPress(event: MotionEvent?): Boolean = false
    override fun readControlKey(): Boolean = false
    override fun readAltKey(): Boolean = false
    override fun readShiftKey(): Boolean = false
    override fun readFnKey(): Boolean = false
    override fun onCodePoint(codePoint: Int, ctrlDown: Boolean, session: TerminalSession?): Boolean = false
    override fun onEmulatorSet() {}

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        session?.finishIfRunning()
    }
}
