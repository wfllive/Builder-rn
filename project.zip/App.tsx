import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  AppState,
  Modal,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  type GestureResponderEvent,
} from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Camera, useCameraDevice, useCameraFormat, type VideoFile, type VideoStabilizationMode } from 'react-native-vision-camera';
import Slider from '@react-native-community/slider';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as MediaLibrary from 'expo-media-library';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { VideoView, useVideoPlayer } from 'expo-video';

const FPS = 60;
type Resolution = 'FHD' | 'UHD';
type Position = 'back' | 'front';

const resolutionPixels: Record<Resolution, { width: number; height: number }> = {
  FHD: { width: 1920, height: 1080 },
  UHD: { width: 3840, height: 2160 },
};

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const rest = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${rest}`;
}

function ReviewModal({ uri, visible, onClose }: { uri?: string; visible: boolean; onClose: () => void }) {
  const player = useVideoPlayer(uri ?? null, (instance) => {
    instance.loop = true;
  });

  useEffect(() => {
    if (visible && uri) player.play();
    else player.pause();
  }, [visible, uri, player]);

  return (
    <Modal visible={visible} animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.reviewRoot}>
        {uri ? <VideoView player={player} style={StyleSheet.absoluteFill} nativeControls contentFit="contain" /> : null}
        <TouchableOpacity style={styles.reviewClose} onPress={onClose} accessibilityLabel="Закрыть просмотр">
          <Ionicons name="close" size={28} color="#fff" />
        </TouchableOpacity>
      </View>
    </Modal>
  );
}

function CameraScreen() {
  const insets = useSafeAreaInsets();
  const camera = useRef<Camera>(null);
  const focusScale = useRef(new Animated.Value(0)).current;
  const [position, setPosition] = useState<Position>('back');
  const [resolution, setResolution] = useState<Resolution>('FHD');
  const [stabilizationEnabled, setStabilizationEnabled] = useState(true);
  const [torch, setTorch] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [cameraReady, setCameraReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [lastVideo, setLastVideo] = useState<string>();
  const [reviewOpen, setReviewOpen] = useState(false);
  const [focusPoint, setFocusPoint] = useState({ x: 0, y: 0 });
  const [appActive, setAppActive] = useState(AppState.currentState === 'active');
  const [cameraPermission, setCameraPermission] = useState(false);
  const [micPermission, setMicPermission] = useState(false);

  const device = useCameraDevice(position);
  const target = resolutionPixels[resolution];
  const format = useCameraFormat(device, [
    { videoResolution: target },
    { fps: FPS },
  ]);

  const supports60 = Boolean(format && format.minFps <= FPS && format.maxFps >= FPS);
  const resolutionMatches = Boolean(
    format && format.videoWidth >= target.width && format.videoHeight >= target.height,
  );
  const profileAvailable = supports60 && resolutionMatches;

  const stabilizationMode = useMemo<VideoStabilizationMode>(() => {
    if (!stabilizationEnabled || !format) return 'off';
    const modes = format.videoStabilizationModes;
    if (modes.includes('auto')) return 'auto';
    if (modes.includes('cinematic')) return 'cinematic';
    if (modes.includes('standard')) return 'standard';
    return 'off';
  }, [format, stabilizationEnabled]);

  const stabilizationAvailable = stabilizationMode !== 'off' || !stabilizationEnabled;
  const minZoom = device?.minZoom ?? 1;
  const maxZoom = Math.min(device?.maxZoom ?? 10, 10);
  const neutralZoom = device?.neutralZoom ?? 1;

  useEffect(() => {
    (async () => {
      const cameraStatus = await Camera.getCameraPermissionStatus();
      const micStatus = await Camera.getMicrophonePermissionStatus();
      setCameraPermission(cameraStatus === 'granted');
      setMicPermission(micStatus === 'granted');
    })();
  }, []);

  useEffect(() => {
    const sub = AppState.addEventListener('change', state => setAppActive(state === 'active'));
    return () => sub.remove();
  }, []);

  useEffect(() => {
    setZoom(Math.max(minZoom, neutralZoom));
    setTorch(false);
  }, [position, minZoom, neutralZoom]);

  useEffect(() => {
    if (!recording) return;
    const id = setInterval(() => setElapsed(value => value + 1), 1000);
    return () => clearInterval(id);
  }, [recording]);

  const requestPermissions = useCallback(async () => {
    const cameraResult = await Camera.requestCameraPermission();
    const micResult = await Camera.requestMicrophonePermission();
    setCameraPermission(cameraResult === 'granted');
    setMicPermission(micResult === 'granted');
  }, []);

  const saveVideo = useCallback(async (video: VideoFile) => {
    const uri = video.path.startsWith('file://') ? video.path : `file://${video.path}`;
    try {
      const permission = await MediaLibrary.requestPermissionsAsync();
      if (!permission.granted) throw new Error('Нет доступа к медиатеке');
      await MediaLibrary.createAssetAsync(uri);
      setLastVideo(uri);
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      setLastVideo(uri);
      Alert.alert('Видео записано', 'Файл сохранён во временной папке, но приложению не удалось добавить его в Галерею.');
    }
  }, []);

  const stopRecording = useCallback(async () => {
    try {
      await camera.current?.stopRecording();
    } catch {
      setRecording(false);
    }
  }, []);

  const startRecording = useCallback(async () => {
    if (!camera.current || !cameraReady || recording) return;
    if (!profileAvailable) {
      Alert.alert('60 fps недоступно', `${resolution} 60 fps не предоставляется камерой через Android Camera API. Выберите FHD или другую камеру.`);
      return;
    }
    if (stabilizationEnabled && !stabilizationAvailable) {
      Alert.alert('Стабилизация недоступна', 'Текущий профиль камеры не поддерживает стабилизацию.');
      return;
    }

    setElapsed(0);
    setRecording(true);
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    camera.current.startRecording({
      fileType: 'mp4',
      videoCodec: 'h265',
      flash: torch ? 'on' : 'off',
      onRecordingFinished: async video => {
        setRecording(false);
        await saveVideo(video);
      },
      onRecordingError: error => {
        setRecording(false);
        Alert.alert('Ошибка записи', error.message);
      },
    });
  }, [cameraReady, profileAvailable, recording, resolution, saveVideo, stabilizationAvailable, stabilizationEnabled, torch]);

  const toggleRecording = () => recording ? stopRecording() : startRecording();

  const focus = useCallback(async (event: GestureResponderEvent) => {
    if (!device?.supportsFocus || recording) return;
    const { locationX: x, locationY: y } = event.nativeEvent;
    setFocusPoint({ x, y });
    focusScale.setValue(1.35);
    Animated.spring(focusScale, { toValue: 1, useNativeDriver: true, friction: 5 }).start(() => {
      Animated.timing(focusScale, { toValue: 0, duration: 300, delay: 700, useNativeDriver: true }).start();
    });
    try { await camera.current?.focus({ x, y }); } catch { /* Camera may be switching. */ }
  }, [device?.supportsFocus, focusScale, recording]);

  const setZoomPreset = (value: number) => {
    const next = Math.min(maxZoom, Math.max(minZoom, value));
    setZoom(next);
    Haptics.selectionAsync();
  };

  if (!cameraPermission || !micPermission) {
    return (
      <View style={styles.permissionRoot}>
        <View style={styles.permissionIcon}><Ionicons name="videocam" size={34} color="#111" /></View>
        <Text style={styles.permissionTitle}>Доступ к камере</Text>
        <Text style={styles.permissionText}>Для видео 60 fps приложению нужны камера и микрофон. Записи сохраняются только на вашем устройстве.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={requestPermissions}>
          <Text style={styles.primaryButtonText}>Разрешить доступ</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!device) {
    return <View style={styles.loading}><ActivityIndicator color="#fff" size="large" /><Text style={styles.loadingText}>Поиск камеры…</Text></View>;
  }

  const zoomPresets = position === 'back' ? [0.6, 1, 2, 5] : [1, 2];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <Pressable style={styles.preview} onPress={focus}>
        <Camera
          ref={camera}
          style={StyleSheet.absoluteFill}
          device={device}
          isActive={appActive && !settingsOpen && !reviewOpen}
          video
          audio
          format={format}
          fps={profileAvailable ? FPS : undefined}
          zoom={zoom}
          torch={torch && position === 'back' ? 'on' : 'off'}
          videoStabilizationMode={stabilizationMode}
          videoBitRate="high"
          lowLightBoost={false}
          onInitialized={() => setCameraReady(true)}
          onError={error => Alert.alert('Камера', error.message)}
        />

        <LinearGradient colors={['rgba(0,0,0,.66)', 'transparent']} style={[styles.topShade, { height: insets.top + 120 }]} pointerEvents="none" />
        <LinearGradient colors={['transparent', 'rgba(0,0,0,.88)']} style={styles.bottomShade} pointerEvents="none" />

        <Animated.View pointerEvents="none" style={[styles.focusRing, {
          left: focusPoint.x - 30,
          top: focusPoint.y - 30,
          opacity: focusScale,
          transform: [{ scale: focusScale }],
        }]} />

        <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
          <TouchableOpacity style={styles.circleButton} onPress={() => setTorch(value => !value)} disabled={position === 'front' || recording}>
            <Ionicons name={torch ? 'flash' : 'flash-off'} size={21} color={torch ? '#ffd74a' : '#fff'} />
          </TouchableOpacity>

          {recording ? (
            <View style={styles.recordingTimer}><View style={styles.redDot} /><Text style={styles.timerText}>{formatTime(elapsed)}</Text></View>
          ) : (
            <View style={styles.profileBadge}><Text style={styles.profileText}>{resolution} · {FPS}</Text></View>
          )}

          <TouchableOpacity style={styles.circleButton} onPress={() => setSettingsOpen(true)} disabled={recording}>
            <Ionicons name="settings-outline" size={22} color="#fff" />
          </TouchableOpacity>
        </View>

        <View style={styles.statusRow} pointerEvents="none">
          <View style={[styles.statusPill, stabilizationEnabled && stabilizationAvailable ? styles.statusPillActive : null]}>
            <MaterialCommunityIcons name="hand-back-right-outline" size={14} color="#fff" />
            <Text style={styles.statusText}>{stabilizationEnabled ? 'STABLE' : 'OFF'}</Text>
          </View>
          {!profileAvailable && <View style={styles.warningPill}><Ionicons name="warning" size={13} color="#111" /><Text style={styles.warningText}>60 FPS НЕДОСТУПНО</Text></View>}
        </View>

        <View style={[styles.controls, { paddingBottom: Math.max(insets.bottom, 16) }]}>
          <View style={styles.zoomPills}>
            {zoomPresets.map(value => (
              <TouchableOpacity key={value} style={[styles.zoomPill, Math.abs(zoom - value) < 0.1 && styles.zoomPillSelected]} onPress={() => setZoomPreset(value)}>
                <Text style={[styles.zoomText, Math.abs(zoom - value) < 0.1 && styles.zoomTextSelected]}>{value}×</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Slider
            style={styles.zoomSlider}
            minimumValue={minZoom}
            maximumValue={maxZoom}
            value={zoom}
            onValueChange={setZoom}
            minimumTrackTintColor="#fff"
            maximumTrackTintColor="rgba(255,255,255,.35)"
            thumbTintColor="#fff"
          />

          <View style={styles.captureRow}>
            <TouchableOpacity style={styles.galleryButton} onPress={() => lastVideo && setReviewOpen(true)} disabled={!lastVideo || recording}>
              {lastVideo ? <View style={styles.galleryReady}><Ionicons name="play" size={20} color="#fff" /></View> : <Ionicons name="images-outline" size={25} color="rgba(255,255,255,.65)" />}
            </TouchableOpacity>

            <TouchableOpacity style={[styles.recordOuter, recording && styles.recordOuterActive]} onPress={toggleRecording} disabled={!cameraReady} accessibilityLabel={recording ? 'Остановить запись' : 'Начать запись'}>
              <View style={[styles.recordInner, recording && styles.recordInnerActive]} />
            </TouchableOpacity>

            <TouchableOpacity style={styles.galleryButton} onPress={() => setPosition(value => value === 'back' ? 'front' : 'back')} disabled={recording}>
              <Ionicons name="camera-reverse-outline" size={29} color="#fff" />
            </TouchableOpacity>
          </View>
          <Text style={styles.modeTitle}>ВИДЕО PRO</Text>
        </View>
      </Pressable>

      <Modal visible={settingsOpen} transparent animationType="slide" onRequestClose={() => setSettingsOpen(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setSettingsOpen(false)} />
        <View style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 20) }]}>
          <View style={styles.sheetHandle} />
          <View style={styles.sheetHeader}><Text style={styles.sheetTitle}>Параметры видео</Text><TouchableOpacity onPress={() => setSettingsOpen(false)}><Ionicons name="close" size={26} color="#111" /></TouchableOpacity></View>
          <Text style={styles.settingLabel}>КАЧЕСТВО · ВСЕГДА 60 FPS</Text>
          <View style={styles.segmented}>
            {(['FHD', 'UHD'] as Resolution[]).map(item => (
              <TouchableOpacity key={item} style={[styles.segment, resolution === item && styles.segmentActive]} onPress={() => setResolution(item)}>
                <Text style={[styles.segmentTitle, resolution === item && styles.segmentTitleActive]}>{item}</Text>
                <Text style={[styles.segmentMeta, resolution === item && styles.segmentTitleActive]}>{item === 'FHD' ? '1080p' : '4K'} · 60</Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.settingRow}>
            <View style={styles.settingIcon}><MaterialCommunityIcons name="hand-back-right-outline" size={21} color="#111" /></View>
            <View style={styles.settingCopy}><Text style={styles.settingTitle}>Стабилизация</Text><Text style={styles.settingDescription}>Оптическая + электронная, если доступны</Text></View>
            <TouchableOpacity style={[styles.switch, stabilizationEnabled && styles.switchOn]} onPress={() => setStabilizationEnabled(value => !value)}><View style={[styles.switchKnob, stabilizationEnabled && styles.switchKnobOn]} /></TouchableOpacity>
          </View>
          <View style={styles.infoBox}><Ionicons name="information-circle-outline" size={20} color="#4b5563" /><Text style={styles.infoText}>Запись запускается только при подтверждённой поддержке 60 fps. Huawei может ограничивать отдельные режимы для сторонних приложений.</Text></View>
        </View>
      </Modal>

      <ReviewModal uri={lastVideo} visible={reviewOpen} onClose={() => setReviewOpen(false)} />
    </View>
  );
}

export default function App() {
  return <SafeAreaProvider><CameraScreen /></SafeAreaProvider>;
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  preview: { flex: 1, backgroundColor: '#060606' },
  topShade: { position: 'absolute', left: 0, right: 0, top: 0 },
  bottomShade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 300 },
  topBar: { position: 'absolute', top: 0, left: 18, right: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  circleButton: { width: 42, height: 42, borderRadius: 22, backgroundColor: 'rgba(18,18,18,.48)', alignItems: 'center', justifyContent: 'center', borderWidth: StyleSheet.hairlineWidth, borderColor: 'rgba(255,255,255,.25)' },
  profileBadge: { backgroundColor: 'rgba(18,18,18,.58)', borderRadius: 18, paddingHorizontal: 15, paddingVertical: 9, borderWidth: StyleSheet.hairlineWidth, borderColor: 'rgba(255,255,255,.28)' },
  profileText: { color: '#fff', fontSize: 13, fontWeight: '800', letterSpacing: .8 },
  recordingTimer: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(18,18,18,.68)', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 9, gap: 7 },
  redDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#ff3b30' },
  timerText: { color: '#fff', fontVariant: ['tabular-nums'], fontSize: 14, fontWeight: '700' },
  statusRow: { position: 'absolute', top: 102, alignSelf: 'center', flexDirection: 'row', gap: 8 },
  statusPill: { height: 27, borderRadius: 14, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(20,20,20,.52)', borderWidth: StyleSheet.hairlineWidth, borderColor: 'rgba(255,255,255,.24)' },
  statusPillActive: { backgroundColor: 'rgba(30,98,61,.6)', borderColor: 'rgba(115,255,166,.45)' },
  statusText: { color: '#fff', fontSize: 10, fontWeight: '800', letterSpacing: .7 },
  warningPill: { height: 27, borderRadius: 14, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#ffd84d' },
  warningText: { color: '#111', fontSize: 9, fontWeight: '900' },
  focusRing: { position: 'absolute', width: 60, height: 60, borderWidth: 1.5, borderColor: '#ffe05f', borderRadius: 3 },
  controls: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' },
  zoomPills: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 2 },
  zoomPill: { width: 38, height: 38, borderRadius: 20, backgroundColor: 'rgba(15,15,15,.55)', alignItems: 'center', justifyContent: 'center', borderWidth: StyleSheet.hairlineWidth, borderColor: 'rgba(255,255,255,.18)' },
  zoomPillSelected: { backgroundColor: '#fff', width: 43, height: 43, borderRadius: 23 },
  zoomText: { color: '#fff', fontSize: 12, fontWeight: '700' },
  zoomTextSelected: { color: '#111', fontSize: 13, fontWeight: '900' },
  zoomSlider: { width: '62%', height: 30, marginBottom: 5 },
  captureRow: { width: '100%', paddingHorizontal: 36, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  galleryButton: { width: 52, height: 52, borderRadius: 26, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(25,25,25,.52)' },
  galleryReady: { width: 45, height: 45, borderRadius: 12, backgroundColor: '#343a40', borderWidth: 2, borderColor: 'rgba(255,255,255,.7)', alignItems: 'center', justifyContent: 'center' },
  recordOuter: { width: 82, height: 82, borderRadius: 42, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  recordOuterActive: { borderColor: '#fff' },
  recordInner: { width: 66, height: 66, borderRadius: 34, backgroundColor: '#f33' },
  recordInnerActive: { width: 31, height: 31, borderRadius: 6, backgroundColor: '#f33' },
  modeTitle: { color: '#fff', marginTop: 10, fontSize: 12, fontWeight: '900', letterSpacing: 1.8 },
  permissionRoot: { flex: 1, backgroundColor: '#f6f6f4', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 34 },
  permissionIcon: { width: 72, height: 72, borderRadius: 24, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 22, shadowColor: '#000', shadowOpacity: .08, shadowRadius: 18, elevation: 2 },
  permissionTitle: { fontSize: 25, fontWeight: '800', color: '#111', marginBottom: 10 },
  permissionText: { fontSize: 15, lineHeight: 22, color: '#646464', textAlign: 'center', marginBottom: 28 },
  primaryButton: { backgroundColor: '#111', height: 52, borderRadius: 18, paddingHorizontal: 28, alignItems: 'center', justifyContent: 'center' },
  primaryButtonText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  loading: { flex: 1, backgroundColor: '#090909', alignItems: 'center', justifyContent: 'center', gap: 14 },
  loadingText: { color: '#fff', fontSize: 15 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,.48)' },
  sheet: { backgroundColor: '#f7f7f5', paddingHorizontal: 22, paddingTop: 10, borderTopLeftRadius: 30, borderTopRightRadius: 30 },
  sheetHandle: { width: 38, height: 4, backgroundColor: '#c7c7c4', borderRadius: 2, alignSelf: 'center', marginBottom: 13 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 },
  sheetTitle: { color: '#111', fontSize: 22, fontWeight: '800' },
  settingLabel: { fontSize: 11, fontWeight: '800', color: '#777', letterSpacing: 1, marginBottom: 9 },
  segmented: { flexDirection: 'row', backgroundColor: '#e9e9e6', borderRadius: 18, padding: 4, marginBottom: 18 },
  segment: { flex: 1, borderRadius: 15, paddingVertical: 12, alignItems: 'center' },
  segmentActive: { backgroundColor: '#111' },
  segmentTitle: { color: '#222', fontWeight: '900', fontSize: 14 },
  segmentMeta: { color: '#6c6c6c', fontWeight: '600', fontSize: 11, marginTop: 2 },
  segmentTitleActive: { color: '#fff' },
  settingRow: { backgroundColor: '#fff', borderRadius: 20, padding: 15, flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  settingIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#f0f0ed', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  settingCopy: { flex: 1 },
  settingTitle: { color: '#111', fontSize: 15, fontWeight: '800' },
  settingDescription: { color: '#777', fontSize: 12, marginTop: 3 },
  switch: { width: 50, height: 29, borderRadius: 16, padding: 3, backgroundColor: '#d4d4d1' },
  switchOn: { backgroundColor: '#1c1c1c' },
  switchKnob: { width: 23, height: 23, borderRadius: 12, backgroundColor: '#fff' },
  switchKnobOn: { transform: [{ translateX: 21 }] },
  infoBox: { flexDirection: 'row', gap: 10, paddingHorizontal: 4, marginBottom: 4 },
  infoText: { flex: 1, color: '#666', lineHeight: 18, fontSize: 12 },
  reviewRoot: { flex: 1, backgroundColor: '#000' },
  reviewClose: { position: 'absolute', top: Platform.OS === 'android' ? 28 : 52, right: 20, width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0,0,0,.55)', alignItems: 'center', justifyContent: 'center' },
});
