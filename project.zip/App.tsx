import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, AppState, Modal, Platform, Pressable,
  StatusBar, StyleSheet, Text, TouchableOpacity, View, type GestureResponderEvent,
} from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Camera, useCameraDevices, useVideoOutput, useCameraPermission, useMicrophonePermission,
  type CameraDevice, type CameraRef, type CameraSessionConfig, type Constraint, type Recorder,
} from 'react-native-vision-camera';
import Slider from '@react-native-community/slider';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as MediaLibrary from 'expo-media-library';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { VideoView, useVideoPlayer } from 'expo-video';

const SETTINGS_KEY = '@pura-pro-video/settings-v2';
const FPS = 60;
type Resolution = 'FHD' | 'UHD';
type Lens = 'ultra' | 'main' | 'tele' | 'front';
type ProParam = 'ISO' | 'S' | 'EV' | 'MF';

type SavedSettings = {
  resolution: Resolution;
  stabilization: boolean;
  lens: Lens;
  iso: number;
  shutter: number;
  evIndex: number;
  focus: number;
  manualExposure: boolean;
  manualFocus: boolean;
  remember: boolean;
};

const DEFAULTS: SavedSettings = {
  resolution: 'FHD', stabilization: true, lens: 'main', iso: 100, shutter: 120,
  evIndex: 0, focus: 1, manualExposure: false, manualFocus: false, remember: true,
};
const SHUTTERS = [60, 100, 120, 240, 500, 1000, 2000, 4000, 8000];
const ISO_VALUES = [50, 100, 200, 400, 800, 1600, 3200, 6400];

function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, value)); }
function formatTime(s: number) { return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`; }

function ReviewModal({ uri, visible, onClose }: { uri?: string; visible: boolean; onClose: () => void }) {
  const player = useVideoPlayer(uri ?? null, p => { p.loop = true; });
  useEffect(() => { visible && uri ? player.play() : player.pause(); }, [visible, uri, player]);
  return <Modal visible={visible} animationType="fade" statusBarTranslucent onRequestClose={onClose}>
    <View style={styles.reviewRoot}>
      {uri && <VideoView player={player} style={StyleSheet.absoluteFill} nativeControls contentFit="contain" />}
      <TouchableOpacity style={styles.reviewClose} onPress={onClose}><Ionicons name="close" size={28} color="#fff" /></TouchableOpacity>
    </View>
  </Modal>;
}

function selectDevice(devices: CameraDevice[], lens: Lens): CameraDevice | undefined {
  const position = lens === 'front' ? 'front' : 'back';
  const candidates = devices.filter(d => d.position === position);
  if (!candidates.length) return undefined;
  if (lens === 'front') return candidates.find(d => d.id === '1') ?? candidates[0];
  // Exact Pura 80 Pro Camera2 IDs from the supplied hardware report.
  const puraId = lens === 'ultra' ? '4' : lens === 'tele' ? '5' : '0';
  const exact = candidates.find(d => d.id === puraId);
  if (exact) return exact;
  const physical = candidates.filter(d => !d.isVirtualDevice && d.focalLength != null)
    .sort((a, b) => (a.focalLength ?? 0) - (b.focalLength ?? 0));
  if (!physical.length) return candidates[0];
  if (lens === 'ultra') return physical[0];
  if (lens === 'tele') return physical[physical.length - 1];
  return physical[Math.floor((physical.length - 1) / 2)];
}

function CameraScreen() {
  const insets = useSafeAreaInsets();
  const camera = useRef<CameraRef>(null);
  const recorder = useRef<Recorder | null>(null);
  const focusAnim = useRef(new Animated.Value(0)).current;
  const devices = useCameraDevices();
  const cameraPermission = useCameraPermission();
  const microphonePermission = useMicrophonePermission();
  const [settings, setSettings] = useState<SavedSettings>(DEFAULTS);
  const [loaded, setLoaded] = useState(false);
  const [activeParam, setActiveParam] = useState<ProParam>('ISO');
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [ready, setReady] = useState(false);
  const [selectedFps, setSelectedFps] = useState<number>();
  const [selectedStabilization, setSelectedStabilization] = useState<string>();
  const [focusLocked, setFocusLocked] = useState(false);
  const [focusPoint, setFocusPoint] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [torch, setTorch] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [lastVideo, setLastVideo] = useState<string>();
  const [reviewOpen, setReviewOpen] = useState(false);
  const [appActive, setAppActive] = useState(AppState.currentState === 'active');

  const device = useMemo(() => selectDevice(devices, settings.lens), [devices, settings.lens]);
  // VisionCamera 5.2.2 declares CommonResolutions in its types, but the package's
  // CommonJS runtime can return it as undefined under Metro/Expo. Literal portrait
  // sizes avoid that package export bug and are accepted by useVideoOutput.
  const targetResolution = useMemo(() => settings.resolution === 'UHD'
    ? { width: 2160, height: 3840 }
    : { width: 1080, height: 1920 }, [settings.resolution]);
  const videoOutput = useVideoOutput({ targetResolution, targetBitRate: settings.resolution === 'UHD' ? 72_000_000 : 32_000_000, enableAudio: true, fileType: 'mp4' });
  const constraints = useMemo<Constraint[]>(() => [
    { fps: FPS },
    { resolutionBias: videoOutput },
    { videoStabilizationMode: settings.stabilization ? 'auto' : 'off' },
  ], [settings.stabilization, videoOutput]);

  const supports60ByReport = settings.lens !== 'ultra' && settings.lens !== 'front';
  const profileAvailable = selectedFps === FPS && supports60ByReport;
  const controller = camera.current?.controller;
  const minZoom = controller?.minZoom ?? device?.minZoom ?? 1;
  const maxZoom = Math.min(controller?.maxZoom ?? device?.maxZoom ?? 10, 10);
  const evMin = device?.minExposureBias ?? -4;
  const evMax = device?.maxExposureBias ?? 4;

  useEffect(() => {
    AsyncStorage.getItem(SETTINGS_KEY).then(raw => {
      if (raw) {
        try { const saved = { ...DEFAULTS, ...JSON.parse(raw) }; setSettings(saved.remember ? saved : DEFAULTS); } catch { /* defaults */ }
      }
      setLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (!loaded || !settings.remember) return;
    const id = setTimeout(() => AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)), 200);
    return () => clearTimeout(id);
  }, [loaded, settings]);

  useEffect(() => { const sub = AppState.addEventListener('change', s => setAppActive(s === 'active')); return () => sub.remove(); }, []);
  useEffect(() => { if (!recording) return; const id = setInterval(() => setElapsed(v => v + 1), 1000); return () => clearInterval(id); }, [recording]);
  useEffect(() => { setReady(false); setSelectedFps(undefined); setFocusLocked(false); setTorch(false); setZoom(1); }, [device?.id]);

  const update = <K extends keyof SavedSettings>(key: K, value: SavedSettings[K]) => setSettings(s => ({ ...s, [key]: value }));

  const applyProSettings = useCallback(async () => {
    const c = camera.current?.controller;
    if (!c) return;
    try {
      if (settings.manualExposure) {
        await c.setExposureLocked(1 / settings.shutter, settings.iso);
      } else {
        // Clear Camera2 manual capture options before returning AE to automatic EV compensation.
        await c.resetFocus();
        await c.setExposureBias(clamp(settings.evIndex, evMin, evMax));
      }
      if (settings.manualFocus) await c.setFocusLocked(settings.focus);
    } catch (e) {
      Alert.alert('Ручное управление', e instanceof Error ? e.message : 'Параметр не поддерживается камерой');
    }
  }, [evMax, evMin, settings.evIndex, settings.focus, settings.iso, settings.manualExposure, settings.manualFocus, settings.shutter]);

  useEffect(() => {
    if (!ready) return;
    const id = setTimeout(applyProSettings, 120);
    return () => clearTimeout(id);
  }, [applyProSettings, ready]);

  const resetAuto = async () => {
    update('manualExposure', false); update('manualFocus', false); update('evIndex', 0);
    setFocusLocked(false);
    try { await camera.current?.controller?.resetFocus(); } catch { /* switching */ }
  };

  const onSession = (config: CameraSessionConfig) => {
    setSelectedFps(config.selectedFPS);
    setSelectedStabilization(config.selectedVideoStabilizationMode);
  };

  const requestPermissions = async () => {
    await Promise.all([cameraPermission.requestPermission(), microphonePermission.requestPermission()]);
  };

  const saveVideo = async (path: string) => {
    const uri = path.startsWith('file://') ? path : `file://${path}`;
    setLastVideo(uri);
    try { const p = await MediaLibrary.requestPermissionsAsync(); if (p.granted) await MediaLibrary.createAssetAsync(uri); } catch { /* temporary file remains */ }
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const startRecording = async () => {
    if (!ready || recording || !profileAvailable) {
      if (!profileAvailable) Alert.alert('60 fps недоступно', settings.lens === 'ultra' ? 'Сверхширокоугольная камера ID 4 предоставляет максимум 30 fps. Для обязательных 60 fps выберите 1× или 2.6×.' : 'Камера не подтвердила профиль 60 fps.');
      return;
    }
    try {
      const r = await videoOutput.createRecorder({}); recorder.current = r;
      setElapsed(0); setRecording(true);
      await r.startRecording(async path => { setRecording(false); await saveVideo(path); }, error => { setRecording(false); Alert.alert('Ошибка записи', error.message); });
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    } catch (e) { setRecording(false); Alert.alert('Запись', e instanceof Error ? e.message : 'Не удалось начать запись'); }
  };
  const stopRecording = async () => { try { await recorder.current?.stopRecording(); } catch { setRecording(false); } };

  const focusAt = async (event: GestureResponderEvent) => {
    if (recording || focusLocked || settings.manualFocus) return;
    const { locationX: x, locationY: y } = event.nativeEvent;
    setFocusPoint({ x, y }); focusAnim.setValue(1.35);
    Animated.spring(focusAnim, { toValue: 1, useNativeDriver: true, friction: 5 }).start();
    try {
      await camera.current?.focusTo({ x, y }, { responsiveness: 'steady', adaptiveness: 'locked', autoResetAfter: null, modes: settings.manualExposure ? ['AF'] : undefined });
      setFocusLocked(true);
    } catch { /* unsupported metering */ }
  };

  const unlockFocus = async () => { setFocusLocked(false); focusAnim.setValue(0); try { await camera.current?.controller?.resetFocus(); } catch {} };

  const setIso = (value: number) => { update('iso', value); update('manualExposure', true); };
  const setShutter = (value: number) => { update('shutter', value); update('manualExposure', true); };
  const setManualFocus = (value: number) => { update('focus', value); update('manualFocus', true); setFocusLocked(true); };
  const setEv = (value: number) => { update('evIndex', Math.round(value)); update('manualExposure', false); };

  if (!cameraPermission.hasPermission || !microphonePermission.hasPermission) return <View style={styles.permissionRoot}>
    <View style={styles.permissionIcon}><Ionicons name="videocam" size={34} color="#111" /></View>
    <Text style={styles.permissionTitle}>Pura Pro Video</Text><Text style={styles.permissionText}>Разрешите доступ к камере и микрофону для профессиональной записи 60 fps.</Text>
    <TouchableOpacity style={styles.primaryButton} onPress={requestPermissions}><Text style={styles.primaryButtonText}>Разрешить доступ</Text></TouchableOpacity>
  </View>;
  if (!device || !loaded) return <View style={styles.loading}><ActivityIndicator color="#fff" size="large" /><Text style={styles.loadingText}>Чтение камер Huawei…</Text></View>;

  const lensButtons: { id: Lens; label: string }[] = [{ id: 'ultra', label: '.65' }, { id: 'main', label: '1' }, { id: 'tele', label: '2.6' }];
  const proValue = activeParam === 'ISO' ? (settings.manualExposure ? `${settings.iso}` : 'AUTO') : activeParam === 'S' ? (settings.manualExposure ? `1/${settings.shutter}` : 'AUTO') : activeParam === 'EV' ? `${settings.evIndex >= 0 ? '+' : ''}${(settings.evIndex * .5).toFixed(1)}` : (settings.manualFocus ? `${Math.round(settings.focus * 100)}%` : 'AUTO');

  return <View style={styles.root}>
    <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
    <Pressable style={styles.preview} onPress={focusAt}>
      <Camera ref={camera} style={StyleSheet.absoluteFill} device={device} isActive={appActive && !settingsOpen && !reviewOpen}
        outputs={[videoOutput]} constraints={constraints} zoom={clamp(zoom, minZoom, maxZoom)} exposure={settings.manualExposure ? undefined : settings.evIndex}
        torchMode={torch ? 'on' : 'off'} onSessionConfigSelected={onSession} onStarted={() => { setReady(true); setTimeout(applyProSettings, 100); }}
        onError={e => Alert.alert('Камера', e.message)} resizeMode="cover" />
      <LinearGradient colors={['rgba(0,0,0,.72)', 'transparent']} style={[styles.topShade, { height: insets.top + 130 }]} pointerEvents="none" />
      <LinearGradient colors={['transparent', 'rgba(0,0,0,.94)']} style={styles.bottomShade} pointerEvents="none" />
      <Animated.View pointerEvents="none" style={[styles.focusRing, { left: focusPoint.x - 31, top: focusPoint.y - 31, opacity: focusAnim, transform: [{ scale: focusAnim }] }]}>
        {focusLocked && <Ionicons name="lock-closed" size={13} color="#ffe05f" style={styles.focusLockIcon} />}
      </Animated.View>

      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity style={styles.circleButton} onPress={() => setTorch(v => !v)} disabled={settings.lens === 'front' || recording}><Ionicons name={torch ? 'flash' : 'flash-off'} size={21} color={torch ? '#ffd74a' : '#fff'} /></TouchableOpacity>
        {recording ? <View style={styles.recordingTimer}><View style={styles.redDot} /><Text style={styles.timerText}>{formatTime(elapsed)}</Text></View> : <View style={styles.profileBadge}><Text style={styles.profileText}>{settings.resolution} · {selectedFps ?? '—'} FPS</Text></View>}
        <TouchableOpacity style={styles.circleButton} onPress={() => setSettingsOpen(true)} disabled={recording}><Ionicons name="settings-outline" size={22} color="#fff" /></TouchableOpacity>
      </View>

      <View style={styles.statusRow} pointerEvents="none">
        <View style={[styles.statusPill, settings.stabilization && styles.statusPillActive]}><MaterialCommunityIcons name="hand-back-right-outline" size={14} color="#fff" /><Text style={styles.statusText}>{selectedStabilization ? 'STABLE' : 'OFF'}</Text></View>
        {focusLocked && <View style={styles.lockPill}><Ionicons name="lock-closed" size={12} color="#ffe05f" /><Text style={styles.lockText}>AF/AE LOCK</Text></View>}
        {!profileAvailable && <View style={styles.warningPill}><Text style={styles.warningText}>60 FPS НЕДОСТУПНО</Text></View>}
      </View>

      <View style={[styles.controls, { paddingBottom: Math.max(insets.bottom, 10) }]}>
        <View style={styles.lensRow}>{lensButtons.map(item => <TouchableOpacity key={item.id} style={[styles.lensPill, settings.lens === item.id && styles.lensSelected]} onPress={() => update('lens', item.id)} disabled={recording}><Text style={[styles.lensText, settings.lens === item.id && styles.lensTextSelected]}>{item.label}×</Text>{item.id === 'ultra' && <Text style={styles.lensFps}>30</Text>}</TouchableOpacity>)}</View>

        <View style={styles.proPanel}>
          <View style={styles.proTabs}>
            {(['ISO', 'S', 'EV', 'MF'] as ProParam[]).map(p => <TouchableOpacity key={p} style={[styles.proTab, activeParam === p && styles.proTabActive]} onPress={() => setActiveParam(p)}><Text style={styles.proLabel}>{p}</Text><Text style={[styles.proTabValue, activeParam === p && styles.proTabValueActive]}>{p === 'ISO' ? (settings.manualExposure ? settings.iso : 'A') : p === 'S' ? (settings.manualExposure ? `1/${settings.shutter}` : 'A') : p === 'EV' ? `${settings.evIndex * .5}` : (settings.manualFocus ? `${Math.round(settings.focus * 100)}` : 'A')}</Text></TouchableOpacity>)}
            <TouchableOpacity style={styles.autoButton} onPress={resetAuto}><Text style={styles.autoText}>AUTO</Text></TouchableOpacity>
          </View>
          <View style={styles.activeControl}>
            <Text style={styles.activeValue}>{proValue}</Text>
            {activeParam === 'ISO' && <Slider style={styles.proSlider} minimumValue={0} maximumValue={ISO_VALUES.length - 1} step={1} value={Math.max(0, ISO_VALUES.indexOf(settings.iso))} onValueChange={i => setIso(ISO_VALUES[i])} minimumTrackTintColor="#ffd84d" maximumTrackTintColor="#555" thumbTintColor="#ffd84d" />}
            {activeParam === 'S' && <Slider style={styles.proSlider} minimumValue={0} maximumValue={SHUTTERS.length - 1} step={1} value={Math.max(0, SHUTTERS.indexOf(settings.shutter))} onValueChange={i => setShutter(SHUTTERS[i])} minimumTrackTintColor="#ffd84d" maximumTrackTintColor="#555" thumbTintColor="#ffd84d" />}
            {activeParam === 'EV' && <Slider style={styles.proSlider} minimumValue={evMin} maximumValue={evMax} step={1} value={settings.evIndex} onValueChange={setEv} minimumTrackTintColor="#ffd84d" maximumTrackTintColor="#555" thumbTintColor="#ffd84d" />}
            {activeParam === 'MF' && <Slider style={styles.proSlider} minimumValue={0} maximumValue={1} step={.01} value={settings.focus} onValueChange={setManualFocus} minimumTrackTintColor="#ffd84d" maximumTrackTintColor="#555" thumbTintColor="#ffd84d" />}
          </View>
        </View>

        <View style={styles.captureRow}>
          <TouchableOpacity style={styles.galleryButton} onPress={() => lastVideo && setReviewOpen(true)} disabled={!lastVideo || recording}>{lastVideo ? <Ionicons name="play" size={22} color="#fff" /> : <Ionicons name="images-outline" size={25} color="#aaa" />}</TouchableOpacity>
          <TouchableOpacity style={styles.recordOuter} onPress={recording ? stopRecording : startRecording} disabled={!ready}><View style={[styles.recordInner, recording && styles.recordInnerActive]} /></TouchableOpacity>
          <TouchableOpacity style={styles.galleryButton} onPress={focusLocked ? unlockFocus : () => update('lens', settings.lens === 'front' ? 'main' : 'front')} disabled={recording}><Ionicons name={focusLocked ? 'lock-open-outline' : 'camera-reverse-outline'} size={27} color="#fff" /></TouchableOpacity>
        </View>
        <Text style={styles.modeTitle}>ВИДЕО PRO · 60 FPS</Text>
      </View>
    </Pressable>

    <Modal visible={settingsOpen} transparent animationType="slide" onRequestClose={() => setSettingsOpen(false)}>
      <Pressable style={styles.modalBackdrop} onPress={() => setSettingsOpen(false)} />
      <View style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 20) }]}>
        <View style={styles.sheetHandle} /><View style={styles.sheetHeader}><Text style={styles.sheetTitle}>Параметры Pro Video</Text><TouchableOpacity onPress={() => setSettingsOpen(false)}><Ionicons name="close" size={26} color="#111" /></TouchableOpacity></View>
        <Text style={styles.settingLabel}>КАЧЕСТВО · 60 FPS</Text>
        <View style={styles.segmented}>{(['FHD', 'UHD'] as Resolution[]).map(r => <TouchableOpacity key={r} style={[styles.segment, settings.resolution === r && styles.segmentActive]} onPress={() => update('resolution', r)}><Text style={[styles.segmentTitle, settings.resolution === r && styles.segmentTitleActive]}>{r}</Text><Text style={[styles.segmentMeta, settings.resolution === r && styles.segmentTitleActive]}>{r === 'FHD' ? '1080p' : '4K'} · 60</Text></TouchableOpacity>)}</View>
        <SettingSwitch icon="hand-back-right-outline" title="Стабилизация" description="OIS + EIS, если профиль совместим" value={settings.stabilization} onPress={() => update('stabilization', !settings.stabilization)} />
        <SettingSwitch icon="content-save-outline" title="Сохранять настройки" description="ISO, выдержка, EV, фокус, объектив" value={settings.remember} onPress={async () => { const next = !settings.remember; update('remember', next); if (!next) await AsyncStorage.removeItem(SETTINGS_KEY); }} />
        <View style={styles.infoBox}><Ionicons name="information-circle-outline" size={20} color="#4b5563" /><Text style={styles.infoText}>По отчёту устройства: основная ID 0 — 31 мм, ISO 50–6400, OIS, 60 fps; широкая ID 4 — 20 мм/0.65×, но максимум 30 fps; телевик ID 5 — 80 мм/2.57×, OIS и 60 fps.</Text></View>
      </View>
    </Modal>
    <ReviewModal uri={lastVideo} visible={reviewOpen} onClose={() => setReviewOpen(false)} />
  </View>;
}

function SettingSwitch({ icon, title, description, value, onPress }: { icon: any; title: string; description: string; value: boolean; onPress: () => void }) {
  return <View style={styles.settingRow}><View style={styles.settingIcon}><MaterialCommunityIcons name={icon} size={21} color="#111" /></View><View style={styles.settingCopy}><Text style={styles.settingTitle}>{title}</Text><Text style={styles.settingDescription}>{description}</Text></View><TouchableOpacity style={[styles.switch, value && styles.switchOn]} onPress={onPress}><View style={[styles.switchKnob, value && styles.switchKnobOn]} /></TouchableOpacity></View>;
}

export default function App() { return <SafeAreaProvider><CameraScreen /></SafeAreaProvider>; }

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' }, preview: { flex: 1, backgroundColor: '#050505' },
  topShade: { position: 'absolute', left: 0, right: 0, top: 0 }, bottomShade: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 420 },
  topBar: { position: 'absolute', top: 0, left: 18, right: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  circleButton: { width: 42, height: 42, borderRadius: 22, backgroundColor: 'rgba(18,18,18,.5)', alignItems: 'center', justifyContent: 'center', borderWidth: StyleSheet.hairlineWidth, borderColor: '#666' },
  profileBadge: { backgroundColor: 'rgba(18,18,18,.65)', borderRadius: 18, paddingHorizontal: 15, paddingVertical: 9, borderWidth: StyleSheet.hairlineWidth, borderColor: '#666' },
  profileText: { color: '#fff', fontSize: 13, fontWeight: '800', letterSpacing: .8 }, recordingTimer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#222b', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 9, gap: 7 },
  redDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#ff3b30' }, timerText: { color: '#fff', fontVariant: ['tabular-nums'], fontWeight: '700' },
  statusRow: { position: 'absolute', top: 102, alignSelf: 'center', flexDirection: 'row', gap: 6 }, statusPill: { height: 27, borderRadius: 14, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#222a' },
  statusPillActive: { backgroundColor: '#1e623daa' }, statusText: { color: '#fff', fontSize: 9, fontWeight: '900' }, lockPill: { height: 27, borderRadius: 14, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#222c' }, lockText: { color: '#ffe05f', fontSize: 9, fontWeight: '900' },
  warningPill: { height: 27, borderRadius: 14, paddingHorizontal: 9, justifyContent: 'center', backgroundColor: '#ffd84d' }, warningText: { color: '#111', fontSize: 9, fontWeight: '900' },
  focusRing: { position: 'absolute', width: 62, height: 62, borderWidth: 1.5, borderColor: '#ffe05f' }, focusLockIcon: { position: 'absolute', right: -7, top: -8, backgroundColor: '#222', padding: 2, borderRadius: 5 },
  controls: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' }, lensRow: { flexDirection: 'row', gap: 9, marginBottom: 10 },
  lensPill: { width: 43, height: 43, borderRadius: 23, backgroundColor: '#181818bb', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#555' }, lensSelected: { backgroundColor: '#fff' }, lensText: { color: '#fff', fontSize: 12, fontWeight: '800' }, lensTextSelected: { color: '#111' }, lensFps: { position: 'absolute', bottom: -5, color: '#ffd84d', fontSize: 7, fontWeight: '900' },
  proPanel: { width: '94%', backgroundColor: '#111e', borderRadius: 18, padding: 7, marginBottom: 9, borderWidth: StyleSheet.hairlineWidth, borderColor: '#555' }, proTabs: { flexDirection: 'row', gap: 4 },
  proTab: { flex: 1, alignItems: 'center', paddingVertical: 5, borderRadius: 10 }, proTabActive: { backgroundColor: '#2e2e2e' }, proLabel: { color: '#aaa', fontSize: 9, fontWeight: '800' }, proTabValue: { color: '#eee', fontSize: 10, fontWeight: '800', marginTop: 2 }, proTabValueActive: { color: '#ffd84d' }, autoButton: { paddingHorizontal: 10, justifyContent: 'center' }, autoText: { color: '#ffd84d', fontSize: 10, fontWeight: '900' },
  activeControl: { height: 37, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8 }, activeValue: { color: '#fff', width: 58, fontSize: 12, fontWeight: '900' }, proSlider: { flex: 1, height: 35 },
  captureRow: { width: '100%', paddingHorizontal: 38, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, galleryButton: { width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center', backgroundColor: '#222b' },
  recordOuter: { width: 76, height: 76, borderRadius: 39, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center' }, recordInner: { width: 61, height: 61, borderRadius: 31, backgroundColor: '#f33' }, recordInnerActive: { width: 29, height: 29, borderRadius: 6 }, modeTitle: { color: '#fff', marginTop: 7, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  permissionRoot: { flex: 1, backgroundColor: '#f6f6f4', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 34 }, permissionIcon: { width: 72, height: 72, borderRadius: 24, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 22 }, permissionTitle: { fontSize: 25, fontWeight: '800', color: '#111', marginBottom: 10 }, permissionText: { fontSize: 15, lineHeight: 22, color: '#646464', textAlign: 'center', marginBottom: 28 }, primaryButton: { backgroundColor: '#111', height: 52, borderRadius: 18, paddingHorizontal: 28, alignItems: 'center', justifyContent: 'center' }, primaryButtonText: { color: '#fff', fontSize: 15, fontWeight: '800' }, loading: { flex: 1, backgroundColor: '#090909', alignItems: 'center', justifyContent: 'center', gap: 14 }, loadingText: { color: '#fff' },
  modalBackdrop: { flex: 1, backgroundColor: '#0008' }, sheet: { backgroundColor: '#f7f7f5', paddingHorizontal: 22, paddingTop: 10, borderTopLeftRadius: 30, borderTopRightRadius: 30 }, sheetHandle: { width: 38, height: 4, backgroundColor: '#c7c7c4', borderRadius: 2, alignSelf: 'center', marginBottom: 13 }, sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }, sheetTitle: { color: '#111', fontSize: 21, fontWeight: '800' }, settingLabel: { fontSize: 11, fontWeight: '800', color: '#777', letterSpacing: 1, marginBottom: 9 },
  segmented: { flexDirection: 'row', backgroundColor: '#e9e9e6', borderRadius: 18, padding: 4, marginBottom: 14 }, segment: { flex: 1, borderRadius: 15, paddingVertical: 10, alignItems: 'center' }, segmentActive: { backgroundColor: '#111' }, segmentTitle: { color: '#222', fontWeight: '900' }, segmentMeta: { color: '#6c6c6c', fontSize: 11, marginTop: 2 }, segmentTitleActive: { color: '#fff' },
  settingRow: { backgroundColor: '#fff', borderRadius: 18, padding: 13, flexDirection: 'row', alignItems: 'center', marginBottom: 10 }, settingIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#f0f0ed', alignItems: 'center', justifyContent: 'center', marginRight: 11 }, settingCopy: { flex: 1 }, settingTitle: { color: '#111', fontSize: 14, fontWeight: '800' }, settingDescription: { color: '#777', fontSize: 11, marginTop: 3 }, switch: { width: 48, height: 28, borderRadius: 15, padding: 3, backgroundColor: '#d4d4d1' }, switchOn: { backgroundColor: '#111' }, switchKnob: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff' }, switchKnobOn: { transform: [{ translateX: 20 }] }, infoBox: { flexDirection: 'row', gap: 9, padding: 4 }, infoText: { flex: 1, color: '#666', lineHeight: 17, fontSize: 11 },
  reviewRoot: { flex: 1, backgroundColor: '#000' }, reviewClose: { position: 'absolute', top: Platform.OS === 'android' ? 28 : 52, right: 20, width: 44, height: 44, borderRadius: 22, backgroundColor: '#0009', alignItems: 'center', justifyContent: 'center' },
});
