/**
 * with-splash-screen.js — внедряет финализированный splash-экран
 * в android/app/src/main/res/drawable/ и android/app/src/main/res/values/
 * при каждом `expo prebuild` (включая --clean), чтобы изменения
 * не терялись после регенерации папки android/.
 */
const { withDangerousMod } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

function withSplashScreen(config) {
  return withDangerousMod(config, ['android', async (config) => {
    const projectRoot = config.modRequest.projectRoot;
    const androidRes = path.join(projectRoot, 'android', 'app', 'src', 'main', 'res');

    // 1) Splash drawable XML (слой с фоном и изображением)
    const splashDrawables = [
      'drawable/splash_screen.xml',
      'drawable/ic_splash.xml',
    ];
    splashDrawables.forEach((rel) => {
      const srcPath = path.join(projectRoot, rel);
      const destPath = path.join(androidRes, rel);
      if (fs.existsSync(srcPath)) {
        fs.mkdirSync(path.dirname(destPath), { recursive: true });
        fs.copyFileSync(srcPath, destPath);
      }
    });

    // 2) Обновляем styles.xml: добавляем splash-атрибуты в Theme.App.SplashScreen
    const stylesPath = path.join(androidRes, 'values', 'styles.xml');
    if (fs.existsSync(stylesPath)) {
      let stylesXml = fs.readFileSync(stylesPath, 'utf8');
      // Добавляем modern splash-атрибуты, если их ещё нет
      const additions = [
        ['android:windowSplashScreenBackground', '@android:color/white'],
        ['android:windowSplashScreenAnimatedIcon', '@drawable/ic_splash'],
        ['android:windowSplashScreenAnimationDuration', '300'],
        ['android:windowSplashScreenIconBackgroundColor', '@color/colorPrimary'],
        ['android:windowSplashScreenBrandingImage', '@drawable/splashscreen_logo'],
      ];
      // Убеждаемся, что Theme.App.SplashScreen использует splash_screen как фон
      if (!stylesXml.includes('Theme.App.SplashScreen')) {
        // Если стиля нет — ничего не ломаем, просто пропускаем
      } else {
        // Обновляем parent, если это всё ещё AppTheme без NoActionBar
        if (stylesXml.includes('parent="AppTheme"')) {
          // Оставляем как есть — AppTheme подходит для splash
        }
        // Добавляем каждый атрибут, если его нет
        additions.forEach(([attr, value]) => {
          const regex = new RegExp(`<item name="${attr}"[^>]*>[^<]*<\\/item>`);
          if (!stylesXml.includes(`name="${attr}"`)) {
            // Вставляем перед закрывающим тегом Theme.App.SplashScreen
            const insertPoint = stylesXml.indexOf('</style>', stylesXml.indexOf('Theme.App.SplashScreen'));
            if (insertPoint > 0) {
              const item = `    <item name="${attr}">${value}</item>\n`;
              stylesXml = stylesXml.slice(0, insertPoint) + item + stylesXml.slice(insertPoint);
            }
          }
        });
      }
      fs.writeFileSync(stylesPath, stylesXml, 'utf8');
    }

    return config;
  }]);
}

module.exports = withSplashScreen;
