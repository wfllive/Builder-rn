/**
 * with-build-config.js — гарантированно добавляет в android/app/build.gradle
 * ПОСЛЕ КАЖДОГО `expo prebuild --clean`:
 *
 *   1. buildFeatures { buildConfig true }          (AGP 8+ не генерит BuildConfig по умолчанию)
 *   2. Загрузку релизного ключа из keystore.properties / env / gradle props
 *      - findKeystoreFile() хелпер
 *      - чтение keystore.properties
 *      - expectedSha256 резолв
 *   3. signingConfigs { release { ... } }          (V1/V2/V3 подпись)
 *      - debug-конфиг НЕ трогаем (он у Expo всегда есть, не дублируем)
 *   4. buildConfigField EXPECTED_SIGNATURE_SHA256  (берётся из keystore.properties / env)
 *   5. versionCode / versionName из app.json       (Expo затирает версию своим значением)
 *   6. В buildTypes.release:
 *      - signingConfig signingConfigs.release
 *      - проверка hasReleaseKey с GradleException, если ключ не найден
 *      - shrinkResources / minifyEnabled / crunchPngs
 *
 * Плагин идемпотентен: повторный запуск НЕ дублирует строки и НЕ ломает файл,
 * даже если prebuild уже сгенерировал шаблон заново.
 */
const { withAppBuildGradle, WarningAggregator } = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

// ---------- мини-парсер блоков { ... } с учётом строк и комментариев ----------
function findBlockRange(lines, startIdx) {
  let depth = 0;
  let inString = null; // null | '"' | "'" | '//' | '/*'
  for (let i = startIdx; i < lines.length; i++) {
    const line = lines[i];
    for (let j = 0; j < line.length; j++) {
      const ch = line[j];
      const nx = line[j + 1];
      if (inString === '/*') {
        if (ch === '*' && nx === '/') { inString = null; j++; }
        continue;
      }
      if (inString === '"' || inString === "'") {
        if (ch === '\\') { j++; continue; }
        if (ch === inString) inString = null;
        continue;
      }
      if (ch === '/' && nx === '/') break;
      if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
      if (ch === '"' || ch === "'") { inString = ch; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) return [startIdx, i];
      }
    }
  }
  return [startIdx, lines.length - 1];
}

// Ищет блок `name { ... }` в диапазоне [from, to] (на одном уровне вложенности)
function findDirectBlock(lines, from, to, nameRe) {
  let depth = 0;
  let inString = null;
  for (let i = from; i <= to; i++) {
    const line = lines[i];
    for (let j = 0; j < line.length; j++) {
      const ch = line[j];
      const nx = line[j + 1];
      if (depth !== 0) {
        if (inString === '/*') { if (ch === '*' && nx === '/') inString = null; j++; continue; }
        if (inString === '"' || inString === "'") { if (ch === '\\') { j++; continue; } if (ch === inString) inString = null; continue; }
        if (inString) { inString = null; }
        if (ch === '/' && nx === '/') break;
        if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
        if (ch === '"' || ch === "'") { inString = ch; continue; }
        if (ch === '{') depth++;
        else if (ch === '}') depth--;
        continue;
      }
      // depth === 0 ищем начало блока
      if (inString === '/*') { if (ch === '*' && nx === '/') inString = null; j++; continue; }
      if (inString === '"' || inString === "'") { if (ch === '\\') { j++; continue; } if (ch === inString) inString = null; continue; }
      if (ch === '/' && nx === '/') break;
      if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
      if (ch === '"' || ch === "'") { inString = ch; continue; }
      if (ch === '{') depth++;
    }
    if (depth === 1 && nameRe.test(line.trim())) {
      const [s, e] = findBlockRange(lines, i);
      return [s, e];
    }
  }
  return [-1, -1];
}

// ---------- основной фикс build.gradle ----------
function editBuildGradle(contents, ctx) {
  let lines = contents.split(/\r?\n/);

  const { expectedSha256, versionCode, versionName } = ctx;
  const shaForGradle = String(expectedSha256 || '')
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"');
  const fieldLine =
    '        buildConfigField "String", "EXPECTED_SIGNATURE_SHA256", ' +
    `"\\\\\"${shaForGradle}\\\\\""`;

  // 1. Найти блок android { ... }
  const androidIdx = lines.findIndex((l) => /^\s*android\s*\{/.test(l));
  if (androidIdx < 0) return contents;
  const [, aEnd] = findBlockRange(lines, androidIdx);

  // 2. Найти namespace
  let nsIdx = -1;
  for (let i = androidIdx + 1; i < aEnd; i++) {
    if (/^\s*namespace\s+['"]/.test(lines[i])) { nsIdx = i; break; }
  }

  // 3. buildFeatures { buildConfig true } — вставляем после namespace, если нет
  let hasBuildFeaturesBlock = false;
  let hasBuildConfigTrue = false;
  const bfRange = findDirectBlock(lines, androidIdx + 1, aEnd, /^buildFeatures\s*\{/);
  if (bfRange[0] >= 0) {
    hasBuildFeaturesBlock = true;
    for (let k = bfRange[0]; k <= bfRange[1]; k++) {
      if (/^\s*buildConfig\s+true\s*$/.test(lines[k])) { hasBuildConfigTrue = true; break; }
    }
  }
  if (!hasBuildConfigTrue) {
    if (hasBuildFeaturesBlock) {
      // вставить buildConfig true внутрь существующего buildFeatures { ... }
      const [bs] = bfRange;
      lines.splice(bs + 1, 0, '        buildConfig true');
      return editBuildGradle(lines.join('\n'), ctx);
    }
    if (nsIdx >= 0) {
      const ind = lines[nsIdx].match(/^(\s*)/)?.[1] || '    ';
      let insertAt = nsIdx + 1;
      if (insertAt < lines.length && lines[insertAt].trim() === '') insertAt++;
      lines.splice(insertAt, 0,
        `${ind}buildFeatures {`,
        `${ind}    buildConfig true`,
        `${ind}}`,
        '',
      );
      return editBuildGradle(lines.join('\n'), ctx);
    }
  }

  // 4. Вставить/обновить блок с keystore-хелперами ПОСЛЕ namespace/после buildFeatures,
  //    но ПЕРЕД defaultConfig. Маркерные комментарии помечают наши вставки,
  //    чтобы при повтором запуске заменить их целиком (идемпотентно).
  const keystoreHelpersStart = lines.findIndex((l, i) =>
    i > androidIdx && i < aEnd && /^\s*\/\/\s*NCS-KEYSTORE-START\s*$/.test(l));
  const keystoreHelpersEnd = lines.findIndex((l, i) =>
    i > androidIdx && i < aEnd && /^\s*\/\/\s*NCS-KEYSTORE-END\s*$/.test(l));

  const helpersBlock = [
    '    // NCS-KEYSTORE-START',
    '    // Load release signing configuration from keystore.properties if present',
    '    def findKeystoreFile = { String name ->',
    '        if (!name) return new File(projectRoot, "ncs.keystore")',
    '        def f1 = new File(projectRoot, name)',
    '        if (f1.exists()) return f1',
    '        def f2 = rootProject.file(name)',
    '        if (f2.exists()) return f2',
    '        def f3 = file(name)',
    '        if (f3.exists()) return f3',
    '        return f1',
    '    }',
    '',
    '    def keystorePropsFile = findKeystoreFile("keystore.properties")',
    '    def keystoreProps = new Properties()',
    '    if (keystorePropsFile.exists()) {',
    '        keystoreProps.load(new FileInputStream(keystorePropsFile))',
    '    }',
    '    def expectedSha256 = keystoreProps.getProperty(\'expectedSha256\', System.getenv("EXPECTED_SIGNATURE_SHA256") ?: "")',
    '    // NCS-KEYSTORE-END',
  ];

  if (keystoreHelpersStart >= 0 && keystoreHelpersEnd >= 0) {
    // заменить существующий блок
    lines.splice(keystoreHelpersStart, keystoreHelpersEnd - keystoreHelpersStart + 1, ...helpersBlock);
  } else {
    // вставить перед defaultConfig (или после buildFeatures / namespace)
    const dcRange = findDirectBlock(lines, androidIdx + 1, aEnd, /^defaultConfig\s*\{/);
    const insertAt = dcRange[0] >= 0 ? dcRange[0] : aEnd;
    lines.splice(insertAt, 0, ...helpersBlock, '');
  }
  // после вставки пересчитаем индексы через рекурсивный проход
  return finalizeBuildGradle(lines.join('\n'), ctx);
}

// Шаг 2: работа с defaultConfig / signingConfigs / buildTypes
function finalizeBuildGradle(contents, ctx) {
  let lines = contents.split(/\r?\n/);
  const { expectedSha256, versionCode, versionName } = ctx;
  const shaForGradle = String(expectedSha256 || '')
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"');
  const fieldLine =
    '        buildConfigField "String", "EXPECTED_SIGNATURE_SHA256", ' +
    `"\\\\\"${shaForGradle}\\\\\""`;

  const androidIdx = lines.findIndex((l) => /^\s*android\s*\{/.test(l));
  if (androidIdx < 0) return contents;
  const [, aEnd] = findBlockRange(lines, androidIdx);

  // defaultConfig { ... }
  const dcRange = findDirectBlock(lines, androidIdx + 1, aEnd, /^defaultConfig\s*\{/);
  if (dcRange[0] < 0) {
    WarningAggregator.addWarningAndroid(
      'with-build-config',
      'Блок defaultConfig не найден — buildConfigField не добавлен.',
    );
    return lines.join('\n');
  }
  const [dcStart, dcEnd] = dcRange;

  // 5. versionCode / versionName
  let hasVc = false, hasVn = false;
  for (let i = dcStart + 1; i < dcEnd; i++) {
    if (/^\s*versionCode\s+\d+/.test(lines[i])) { hasVc = true; lines[i] = `        versionCode ${versionCode}`; }
    if (/^\s*versionName\s+["']/.test(lines[i])) { hasVn = true; lines[i] = `        versionName "${versionName}"`; }
  }
  if (!hasVc) lines.splice(dcEnd, 0, `        versionCode ${versionCode}`);
  if (!hasVn) lines.splice(dcEnd, 0, `        versionName "${versionName}"`);

  // 6. buildConfigField EXPECTED_SIGNATURE_SHA256
  let fieldIdx = -1;
  for (let i = dcStart + 1; i < dcEnd; i++) {
    if (/buildConfigField\s+"String"\s*,\s*"EXPECTED_SIGNATURE_SHA256"/.test(lines[i])) { fieldIdx = i; break; }
  }
  if (fieldIdx >= 0) lines[fieldIdx] = fieldLine;
  else lines.splice(dcEnd, 0, fieldLine);

  // 7. signingConfigs { release { ... } }
  let scRange = findDirectBlock(lines, androidIdx + 1, aEnd, /^signingConfigs\s*\{/);
  if (scRange[0] < 0) {
    // вставить signingConfigs {} блок после defaultConfig
    const insertAt = dcEnd + 1;
    const emptySc = [
      '',
      '    signingConfigs {',
      '    }',
    ];
    lines.splice(insertAt, 0, ...emptySc);
    scRange = findDirectBlock(lines, androidIdx + 1, aEnd + emptySc.length, /^signingConfigs\s*\{/);
  }
  const [scStart, scEnd] = scRange;

  // Проверяем наличие release-конфига (маркер NCS-RELEASE-SIGNING)
  const hasReleaseMark = lines.some((l, i) => i > scStart && i < scEnd && /^\s*\/\/\s*NCS-RELEASE-SIGNING-START/.test(l));
  if (!hasReleaseMark) {
    const releaseBlock = [
      '        // NCS-RELEASE-SIGNING-START',
      '        release {',
      '            if (keystorePropsFile.exists()) {',
      '                def sfPath = keystoreProps[\'storeFile\'] ?: "ncs"',
      '                storeFile findKeystoreFile(sfPath)',
      '                storePassword keystoreProps[\'storePassword\']',
      '                keyAlias keystoreProps[\'keyAlias\']',
      '                keyPassword keystoreProps[\'keyPassword\']',
      '                enableV1Signing true',
      '                enableV2Signing true',
      '                enableV3Signing true',
      '            } else if (System.getenv("KEYSTORE_FILE") != null) {',
      '                storeFile file(System.getenv("KEYSTORE_FILE"))',
      '                storePassword System.getenv("KEYSTORE_PASSWORD")',
      '                keyAlias System.getenv("KEY_ALIAS")',
      '                keyPassword System.getenv("KEY_PASSWORD")',
      '                enableV1Signing true',
      '                enableV2Signing true',
      '                enableV3Signing true',
      '            } else if (findProperty(\'MYAPP_RELEASE_STORE_FILE\') != null) {',
      '                storeFile file(findProperty(\'MYAPP_RELEASE_STORE_FILE\'))',
      '                storePassword findProperty(\'MYAPP_RELEASE_STORE_PASSWORD\')',
      '                keyAlias findProperty(\'MYAPP_RELEASE_KEY_ALIAS\')',
      '                keyPassword findProperty(\'MYAPP_RELEASE_KEY_PASSWORD\')',
      '                enableV1Signing true',
      '                enableV2Signing true',
      '                enableV3Signing true',
      '            }',
      '        }',
      '        // NCS-RELEASE-SIGNING-END',
    ];
    // вставить release после открывающей скобки signingConfigs {
    lines.splice(scStart + 1, 0, ...releaseBlock);
  }

  // 8. buildTypes.release — проверить signingConfig и hasReleaseKey check
  const btRange = findDirectBlock(lines, androidIdx + 1, lines.length - 1, /^buildTypes\s*\{/);
  if (btRange[0] >= 0) {
    const [btStart, btEnd] = btRange;
    const relRange = findDirectBlock(lines, btStart + 1, btEnd, /^release\s*\{/);
    if (relRange[0] >= 0) {
      const [relS, relE] = relRange;
      // Проверяем/вставляем: hasReleaseKey check + signingConfig release
      let hasCheck = false, hasSigningRelease = false;
      for (let i = relS + 1; i < relE; i++) {
        if (/hasReleaseKey/.test(lines[i])) hasCheck = true;
        if (/signingConfig\s+signingConfigs\.release/.test(lines[i])) hasSigningRelease = true;
      }
      // Удалить дефолтный signingConfig signingConfigs.debug из релиза, если есть
      // (удаляем строки в обратном порядке, чтобы индексы не съехали)
      for (let i = relE - 1; i > relS; i--) {
        if (/^\s*signingConfig\s+signingConfigs\.debug\s*$/.test(lines[i])) {
          lines.splice(i, 1);
        }
      }
      if (!hasCheck) {
        const checkBlock = [
          '            // NCS-RELEASE-CHECK-START',
          '            def hasReleaseKey = keystorePropsFile.exists() || System.getenv("KEYSTORE_FILE") != null || findProperty("MYAPP_RELEASE_STORE_FILE") != null',
          '            if (!hasReleaseKey) {',
          '                throw new GradleException("ОШИБКА ПОДПИСИ РЕЛИЗА: Не найден файл keystore.properties или ключ подписи! Перед сборкой релиза запустите \'npm run key\' в корне проекта.")',
          '            }',
          '            signingConfig signingConfigs.release',
          '            // NCS-RELEASE-CHECK-END',
        ];
        lines.splice(relS + 1, 0, ...checkBlock);
      } else if (!hasSigningRelease) {
        lines.splice(relS + 1, 0, '            signingConfig signingConfigs.release');
      }
    }
  }

  return lines.join('\n');
}

// ---------- чтение контекста (keystore, версия) ----------
function readExpectedSha(projectRoot) {
  let sha = process.env.EXPECTED_SIGNATURE_SHA256 || '';
  if (sha) return sha;
  const candidates = [
    path.join(projectRoot, 'keystore.properties'),
    path.join(projectRoot, 'android', 'keystore.properties'),
  ];
  for (const ks of candidates) {
    if (!fs.existsSync(ks)) continue;
    try {
      const text = fs.readFileSync(ks, 'utf8');
      const m = text.match(/^\s*expectedSha256\s*=\s*(\S+)/m);
      if (m && m[1]) return m[1];
    } catch { /* ignore */ }
  }
  return '';
}

function readAppVersion(projectRoot) {
  try {
    const appJsonPath = path.join(projectRoot, 'app.json');
    if (fs.existsSync(appJsonPath)) {
      const aj = JSON.parse(fs.readFileSync(appJsonPath, 'utf8'));
      const v = aj.expo && aj.expo.version;
      const vc = aj.expo && aj.expo.android && aj.expo.android.versionCode;
      return {
        versionName: v || '1.0.1',
        versionCode: vc || 2,
      };
    }
  } catch { /* ignore */ }
  return { versionName: '1.0.1', versionCode: 2 };
}

function withBuildConfig(config) {
  return withAppBuildGradle(config, (config) => {
    const projectRoot = config.modRequest.projectRoot;
    const expectedSha256 = readExpectedSha(projectRoot);
    const { versionCode, versionName } = readAppVersion(projectRoot);
    config.modResults.contents = editBuildGradle(config.modResults.contents, {
      expectedSha256,
      versionCode,
      versionName,
    });
    return config;
  });
}

module.exports = withBuildConfig;
