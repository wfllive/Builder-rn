const { withProjectBuildGradle } = require('@expo/config-plugins');

/**
 * Expo's generated Android project exposes the Kotlin Android plugin on its
 * buildscript classpath, but not Kotlin's Compose compiler plugin. Kotlin 2.x
 * requires the latter whenever a native module enables Compose.
 *
 * Add it to the root project classpath rather than assigning a made-up version
 * in apt-manager. The generated root supplies `kotlinVersion`, so both plugins
 * always use exactly the same Kotlin release.
 */
module.exports = function withComposeCompiler(config) {
  return withProjectBuildGradle(config, (mod) => {
    const marker = 'compose-compiler-gradle-plugin';
    if (mod.modResults.contents.includes(marker)) return mod;

    const dependency = '        classpath("org.jetbrains.kotlin:compose-compiler-gradle-plugin:${kotlinVersion}")';
    const kotlinPlugin = /([ \t]*classpath\(["']org\.jetbrains\.kotlin:kotlin-gradle-plugin[^\n]*\))/;
    if (kotlinPlugin.test(mod.modResults.contents)) {
      mod.modResults.contents = mod.modResults.contents.replace(kotlinPlugin, `$1\n${dependency}`);
      return mod;
    }

    // Current Expo templates always contain buildscript.dependencies. This
    // fallback remains valid if the Kotlin dependency moves in a future SDK.
    mod.modResults.contents = mod.modResults.contents.replace(
      /(buildscript\s*\{[\s\S]*?dependencies\s*\{)/,
      `$1\n${dependency}`,
    );
    return mod;
  });
};