/**
 * prootshell-config-plugin
 *
 * Expo config plugin для ProotShell.
 *
 * ВАЖНО: в Expo SDK 57 `withMainApplication` ПАДАЕТ, если файла нет.
 * Поэтому сначала создаём MainApplication.kt через dangerous mod,
 * и только потом работаем с ним.
 *
 * Также все нативные файлы (MainApplication.kt + ProotPackage.java + ...)
 * должны быть на месте ДО того, как kotlinc начнёт компилировать.
 */
const {
  withMainApplication,
  withAppBuildGradle,
  withAndroidManifest,
  withDangerousMod,
  createRunOncePlugin,
} = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const PLUGIN_NAME = 'prootshell';
const PLUGIN_VERSION = '1.0.0';
const PACKAGE_NAME = 'com.prootshell.app';

function copyDir(srcDir, destDir) {
  if (!fs.existsSync(srcDir)) return;
  if (fs.existsSync(destDir)) {
    fs.rmSync(destDir, { recursive: true, force: true });
  }
  fs.mkdirSync(destDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDir(s, d);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}

/**
 * Шаблон MainApplication.kt
 *
 * Скопирован из официального expo-template-bare-minimum@sdk-57.
 * Модифицирован: добавлен import ProotPackage и add(ProotPackage()).
 */
const MAIN_APPLICATION_KT = `package ${PACKAGE_NAME}

import android.app.Application
import android.content.res.Configuration

import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactNativeApplicationEntryPoint.loadReactNative
import com.facebook.react.ReactPackage
import com.facebook.react.ReactHost
import com.facebook.react.common.ReleaseLevel
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint

import expo.modules.ApplicationLifecycleDispatcher
import expo.modules.ExpoReactHostFactory

import com.prootshell.app.ProotPackage

class MainApplication : Application(), ReactApplication {

  override val reactHost: ReactHost by lazy {
    ExpoReactHostFactory.getDefaultReactHost(
      context = applicationContext,
      packageList =
        PackageList(this).packages.apply {
          // Packages that cannot be autolinked yet can be added manually here, for example:
          add(ProotPackage())
        }
    )
  }

  override fun onCreate() {
    super.onCreate()
    DefaultNewArchitectureEntryPoint.releaseLevel = try {
      ReleaseLevel.valueOf(BuildConfig.REACT_NATIVE_RELEASE_LEVEL.uppercase())
    } catch (e: IllegalArgumentException) {
      ReleaseLevel.STABLE
    }
    loadReactNative(this)
    ApplicationLifecycleDispatcher.onApplicationCreate(this)
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    ApplicationLifecycleDispatcher.onConfigurationChanged(this, newConfig)
  }
}
`;

/**
 * Шаблон MainActivity.kt
 *
 * Скопирован из expo-template-bare-minimum@sdk-57.
 * getMainComponentName() возвращает "main" — это имя JS-компонента,
 * который регистрируется в index.ts через AppRegistry.registerComponent.
 */
const MAIN_ACTIVITY_KT = `package ${PACKAGE_NAME}

import android.os.Build
import android.os.Bundle

import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

import expo.modules.ReactActivityDelegateWrapper

class MainActivity : ReactActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Set the theme to AppTheme BEFORE onCreate to support
    // coloring the background, status bar, and navigation bar.
    // This is required for expo-splash-screen.
    setTheme(R.style.AppTheme);
    super.onCreate(null)
  }

  override fun getMainComponentName(): String = "main"

  override fun createReactActivityDelegate(): ReactActivityDelegate {
    return ReactActivityDelegateWrapper(
          this,
          BuildConfig.IS_NEW_ARCHITECTURE_ENABLED,
          object : DefaultReactActivityDelegate(
              this,
              mainComponentName,
              fabricEnabled
          ){})
  }

  override fun invokeDefaultOnBackPressed() {
      if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
          if (!moveTaskToBack(false)) {
              super.invokeDefaultOnBackPressed()
          }
          return
      }
      super.invokeDefaultOnBackPressed()
  }
}
`;

// ───────── Плагин функции ─────────

/**
 * ШАГ 1: Создаёт ВСЕ нативные файлы через dangerous mod.
 * Это ПЕРВЫЙ mod, который должен отработать.
 * Здесь: MainApplication.kt, MainActivity.kt, ProotPackage.java, JNI, assets.
 */
function withAllNativeFiles(config) {
  return withDangerousMod(config, [
    'android',
    (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const pluginDir = __dirname;
      const srcRoot = path.join(pluginDir, 'android');
      const androidDir = path.join(projectRoot, 'android');

      if (!fs.existsSync(androidDir)) {
        console.log('[prootshell] android/ not found yet, will be patched on next prebuild');
        return config;
      }

      // 1. MainApplication.kt + MainActivity.kt (если нет)
      const javaDir = path.join(androidDir, 'app/src/main/java/com/prootshell/app');
      if (!fs.existsSync(javaDir)) fs.mkdirSync(javaDir, { recursive: true });
      const mainApp = path.join(javaDir, 'MainApplication.kt');
      const mainAct = path.join(javaDir, 'MainActivity.kt');
      if (!fs.existsSync(mainApp)) {
        fs.writeFileSync(mainApp, MAIN_APPLICATION_KT);
        console.log('[prootshell] Created MainApplication.kt');
      }
      if (!fs.existsSync(mainAct)) {
        fs.writeFileSync(mainAct, MAIN_ACTIVITY_KT);
        console.log('[prootshell] Created MainActivity.kt');
      }

      // 2. Java sources (ProotPackage.java, ProotSession.java, etc)
      console.log('[prootshell] Copying native sources...');
      copyDir(
        path.join(srcRoot, 'java'),
        path.join(androidDir, 'app/src/main/java')
      );

      // 3. JNI / CMake
      copyDir(
        path.join(srcRoot, 'cpp'),
        path.join(androidDir, 'app/src/main/cpp')
      );

      // 4. proot-бинарники
      const srcAssets = path.join(srcRoot, 'assets', 'proot');
      const destAssets = path.join(androidDir, 'app/src/main/assets/proot');
      if (fs.existsSync(srcAssets)) {
        if (fs.existsSync(destAssets)) {
          fs.rmSync(destAssets, { recursive: true, force: true });
        }
        fs.mkdirSync(destAssets, { recursive: true });
        for (const entry of fs.readdirSync(srcAssets, { withFileTypes: true })) {
          if (entry.isFile()) {
            const s = path.join(srcAssets, entry.name);
            const d = path.join(destAssets, entry.name);
            fs.copyFileSync(s, d);
            fs.chmodSync(d, 0o755);
          }
        }
      }

      return config;
    },
  ]);
}

/**
 * ШАГ 2: Дополнительная модификация MainApplication.kt
 * (если нужно — например, добавить extra imports)
 */
function withProotPackage(config) {
  return withMainApplication(config, (cfg) => {
    let code = cfg.modResults.contents;

    // Добавляем import (на случай если шаблон выше не отработал)
    if (!code.includes('com.prootshell.app.ProotPackage')) {
      code = code.replace(
        /(import com\.facebook\.react\.PackageList)/,
        `import com.prootshell.app.ProotPackage\n$1`
      );
    }

    // Регистрируем пакет
    if (!code.includes('add(ProotPackage())')) {
      code = code.replace(
        /(\/\/ Packages that cannot be autolinked[\s\S]*?)\n(\s*)\}\)/,
        `$1\n          add(ProotPackage())\n$2}))`
      );
    }

    cfg.modResults.contents = code;
    return cfg;
  });
}

/**
 * ШАГ 3: build.gradle — CMake в правильных блоках
 */
function withProotBuildGradle(config) {
  return withAppBuildGradle(config, (cfg) => {
    let gradle = cfg.modResults.contents;

    if (!gradle.includes('prootshell-pty.c')) {
      // android { externalNativeBuild { cmake { path, version } } }
      if (!gradle.includes('src/main/cpp/CMakeLists.txt')) {
        const androidSnippet = `
    // === ProotShell native module (CMake) ===
    externalNativeBuild {
        cmake {
            path "src/main/cpp/CMakeLists.txt"
            version "3.22.1"
        }
    }
`;
        gradle = gradle.replace(
          /(namespace ['"]com\.prootshell\.app['"])/,
          `$1${androidSnippet}`
        );
      }

      // defaultConfig { ndk + cFlags }
      if (!gradle.includes('=== ProotShell native module config ===')) {
        const defaultConfigSnippet = `
        // === ProotShell native module config ===
        ndk {
            abiFilters "arm64-v8a", "armeabi-v7a", "x86_64", "x86"
        }
        externalNativeBuild {
            cmake {
                cFlags "-std=c11"
                arguments "-DANDROID_STL=c++_static"
            }
        }
`;
        gradle = gradle.replace(
          /(versionName "[^"]*")/,
          `$1${defaultConfigSnippet}`
        );
      }
    }

    cfg.modResults.contents = gradle;
    return cfg;
  });
}

/**
 * ШАГ 4: AndroidManifest.xml — <uses-permission> (с дефисом!)
 */
function withProotPermissions(config) {
  return withAndroidManifest(config, (cfg) => {
    const required = [
      'android.permission.WAKE_LOCK',
      'android.permission.POST_NOTIFICATIONS',
      'android.permission.VIBRATE',
    ];
    const manifest = cfg.modResults.manifest;
    const perms = manifest['uses-permission'] || manifest.usesPermission || [];
    for (const r of required) {
      const has = perms.some((p) => p && p.$ && p.$['android:name'] === r);
      if (!has) perms.push({ $: { 'android:name': r } });
    }
    manifest['uses-permission'] = perms;
    delete manifest.usesPermission;
    return cfg;
  });
}

/**
 * Главная функция
 */
function withProotShell(config) {
  // ШАГ 1 (dangerous mod): создаём ВСЕ нативные файлы
  config = withAllNativeFiles(config);
  // ШАГ 2: модифицируем MainApplication.kt (ProotPackage import)
  config = withProotPackage(config);
  // ШАГ 3: build.gradle
  config = withProotBuildGradle(config);
  // ШАГ 4: permissions
  config = withProotPermissions(config);

  console.log('[prootshell] ✓ Native module installed');
  return config;
}

module.exports = createRunOncePlugin(withProotShell, PLUGIN_NAME, PLUGIN_VERSION);
