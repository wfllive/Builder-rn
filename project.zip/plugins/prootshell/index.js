/**
 * prootshell-config-plugin
 *
 * Expo config plugin для ProotShell.
 *
 * ВАЖНО: начиная с Expo SDK 57 плагины сами генерируют MainApplication.kt
 * и MainActivity.kt (через withAndroidDangerousMod). Если плагин
 * ссылается на withMainApplication, эти файлы ОБЯЗАНЫ существовать.
 *
 * Наш плагин:
 *  1. Генерирует MainApplication.kt и MainActivity.kt (если их нет)
 *  2. Регистрирует ProotPackage в getPackages()
 *  3. Копирует нативные Java-файлы (ProotSession, ProotExecutor, etc)
 *  4. Копирует JNI/CMake файлы
 *  5. Копирует proot-бинарники
 *  6. Модифицирует app/build.gradle для подключения CMake
 *  7. Добавляет permissions
 *
 * Использование в app.json:
 *   "plugins": ["./plugins/prootshell"]
 */
const {
  withMainApplication,
  withAppBuildGradle,
  withAndroidManifest,
  withDangerousMod,
  createRunOncePlugin,
} = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

const PLUGIN_NAME = 'prootshell';
const PLUGIN_VERSION = '1.0.0';

const PACKAGE_NAME = 'com.prootshell.app';

/**
 * Рекурсивное копирование с очисткой
 */
function copyDir(srcDir, destDir) {
  if (!fs.existsSync(srcDir)) return;
  if (fs.existsSync(destDir)) {
    fs.rmSync(destDir, { recursive: true, force: true });
  }
  fs.mkdirSync(destDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      copyDir(s, d);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}

/**
 * Копирует один файл
 */
function copyFile(src, dest) {
  if (!fs.existsSync(src)) return;
  if (fs.existsSync(dest)) fs.unlinkSync(dest);
  fs.copyFileSync(src, dest);
}

/**
 * Шаблон MainApplication.kt (Expo SDK 57 формат)
 *
 * ВАЖНО: SoLoader.init() больше НЕ нужен вручную в Expo SDK 57 —
 *        React Native инициализирует его автоматически.
 */
const MAIN_APPLICATION_KT = `package ${PACKAGE_NAME}

import android.app.Application
import android.content.res.Configuration

import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactPackage
import com.facebook.react.ReactHost
import com.facebook.react.common.ReleaseLevel
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint

import expo.modules.ApplicationLifecycleDispatcher
import expo.modules.ExpoReactHostFactory

import com.prootshell.app.ProotPackage

class MainApplication : Application(), ReactApplication {

  override val reactHost: ReactHost by lazy {
    ExpoReactHostFactory.getDefaultReactHost(
      context = applicationContext,
      packageList =
        PackageList(this).packages.apply {
          // Packages that cannot be autolinked yet can be added manually here, for example:
          add(ProotPackage())
        }
    )
  }

  override fun onCreate() {
    super.onCreate()
  }
}
`;

/**
 * Шаблон MainActivity.kt
 */
const MAIN_ACTIVITY_KT = `package ${PACKAGE_NAME}

import android.os.Build
import android.os.Bundle

import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

class MainActivity : ReactActivity() {

  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  override fun getMainComponentName(): String = "ProotShell"

  /**
   * Returns the instance of the [ReactActivityDelegate]. Here we use a util class
   * [DefaultReactActivityDelegate] which allows you to enable New Architecture with a single boolean flag [fabricEnabled].
   */
  override fun createReactActivityDelegate(): ReactActivityDelegate =
    DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled)

  /**
   * Align the back button behavior with Android S
   * where moving root activities to background instead of finishing activities.
   * @see <a href="https://developer.android.com/reference/android/app/Activity#onBackPressed()">onBackPressed</a>
   */
  override fun invokeDefaultOnBackPressed() {
    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
      @Suppress("DEPRECATION")
      super.invokeDefaultOnBackPressed()
      return
    }
    super.invokeDefaultOnBackPressed()
  }
}
`;

/**
 * Создаёт MainApplication.kt и MainActivity.kt если их нет
 * (Expo SDK 57 больше не генерирует их автоматически)
 */
function withMainAppFiles(config) {
  return withDangerousMod(config, [
    'android',
    (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const javaDir = path.join(projectRoot, 'android/app/src/main/java/com/prootshell/app');

      if (!fs.existsSync(javaDir)) {
        fs.mkdirSync(javaDir, { recursive: true });
      }

      const mainApp = path.join(javaDir, 'MainApplication.kt');
      const mainAct = path.join(javaDir, 'MainActivity.kt');

      if (!fs.existsSync(mainApp)) {
        fs.writeFileSync(mainApp, MAIN_APPLICATION_KT);
        console.log('[prootshell] Created MainApplication.kt');
      }
      if (!fs.existsSync(mainAct)) {
        fs.writeFileSync(mainAct, MAIN_ACTIVITY_KT);
        console.log('[prootshell] Created MainActivity.kt');
      }
      return config;
    },
  ]);
}

/**
 * Регистрирует ProotPackage в MainApplication.kt
 */
function withProotPackage(config) {
  return withMainApplication(config, (cfg) => {
    let code = cfg.modResults.contents;

    if (!code.includes('com.prootshell.app.ProotPackage')) {
      code = code.replace(
        /(import com\.facebook\.react\.PackageList)/,
        `import com.prootshell.app.ProotPackage\n$1`
      );
    }

    if (!code.includes('add(ProotPackage())')) {
      code = code.replace(
        /(\/\/ Packages that cannot be autolinked[\s\S]*?)\n(\s*)\}\)/,
        `$1\n          add(ProotPackage())\n$2}))`
      );
    }

    cfg.modResults.contents = code;
    return cfg;
  });
}

/**
 * Подключает CMake в app/build.gradle
 *
 * В AGP 8+ (Expo SDK 57) синтаксис такой:
 *  android {
 *    externalNativeBuild {
 *      cmake {
 *        path "src/main/cpp/CMakeLists.txt"
 *        version "3.22.1"
 *      }
 *    }
 *    defaultConfig {
 *      ndk { abiFilters "..." }
 *      // В defaultConfig.externalNativeBuild.cmake можно:
 *      //   - cppFlags
 *      //   - cFlags
 *      //   - arguments
 *      // НО НЕ path!
 *    }
 *  }
 */
function withProotBuildGradle(config) {
  return withAppBuildGradle(config, (cfg) => {
    let gradle = cfg.modResults.contents;

    if (!gradle.includes('prootshell-pty.c')) {
      // 1. externalNativeBuild { cmake { path, version } } — на уровне android
      //    Идемпотентно: если уже есть — не добавляем
      if (!gradle.includes('src/main/cpp/CMakeLists.txt')) {
        const androidSnippet = `
    // === ProotShell native module (CMake) ===
    externalNativeBuild {
        cmake {
            path "src/main/cpp/CMakeLists.txt"
            version "3.22.1"
        }
    }
`;
        gradle = gradle.replace(
          /(namespace ['"]com\.prootshell\.app['"])/,
          `$1${androidSnippet}`
        );
      }

      // 2. ndk.abiFilters + cFlags в defaultConfig
      if (!gradle.includes('=== ProotShell native module config ===')) {
        const defaultConfigSnippet = `
        // === ProotShell native module config ===
        ndk {
            abiFilters "arm64-v8a", "armeabi-v7a", "x86_64", "x86"
        }
        externalNativeBuild {
            cmake {
                cFlags "-std=c11"
                arguments "-DANDROID_STL=c++_static"
            }
        }
`;
        gradle = gradle.replace(
          /(versionName "[^"]*")/,
          `$1${defaultConfigSnippet}`
        );
      }
    }

    cfg.modResults.contents = gradle;
    return cfg;
  });
}

/**
 * Добавляет permissions в AndroidManifest.xml
 *
 * ВАЖНО: AndroidManifest использует <uses-permission> (с дефисом),
 * НЕ <usesPermission>. AAPT2 строг к регистру.
 */
function withProotPermissions(config) {
  return withAndroidManifest(config, (cfg) => {
    const required = [
      'android.permission.WAKE_LOCK',
      // Не добавляем STORAGE — Android 13+ требует scoped storage,
      // а READ/WRITE уже есть от Expo для старых API
      'android.permission.POST_NOTIFICATIONS',
      'android.permission.VIBRATE',
    ];
    const manifest = cfg.modResults.manifest;
    const perms = manifest['uses-permission'] || manifest.usesPermission || [];
    for (const r of required) {
      const has = perms.some(
        (p) => p && p.$ && p.$['android:name'] === r
      );
      if (!has) {
        perms.push({ $: { 'android:name': r } });
      }
    }
    // Используем uses-permission (с дефисом) — корректный XML тег
    manifest['uses-permission'] = perms;
    delete manifest.usesPermission;
    return cfg;
  });
}

/**
 * Копирует нативные файлы (Java/C/assets)
 */
function withProotNativeFiles(config) {
  return withDangerousMod(config, [
    'android',
    (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const pluginDir = __dirname;
      const srcRoot = path.join(pluginDir, 'android');
      const androidDir = path.join(projectRoot, 'android');

      if (!fs.existsSync(androidDir)) {
        console.log('[prootshell] android/ not found, skip copying natives');
        return config;
      }

      console.log('[prootshell] Copying native sources...');
      copyDir(
        path.join(srcRoot, 'java'),
        path.join(androidDir, 'app/src/main/java')
      );
      copyDir(
        path.join(srcRoot, 'cpp'),
        path.join(androidDir, 'app/src/main/cpp')
      );
      // assets: копируем СОДЕРЖИМОЕ папки assets/proot/* в android/app/src/main/assets/proot/
      // (а не саму папку, чтобы не было assets/proot/proot/)
      const srcAssets = path.join(srcRoot, 'assets', 'proot');
      const destAssets = path.join(androidDir, 'app/src/main/assets/proot');
      if (fs.existsSync(srcAssets)) {
        if (fs.existsSync(destAssets)) {
          fs.rmSync(destAssets, { recursive: true, force: true });
        }
        fs.mkdirSync(destAssets, { recursive: true });
        for (const entry of fs.readdirSync(srcAssets, { withFileTypes: true })) {
          const s = path.join(srcAssets, entry.name);
          const d = path.join(destAssets, entry.name);
          if (entry.isFile()) {
            fs.copyFileSync(s, d);
            fs.chmodSync(d, 0o755);
          }
        }
      }
      return config;
    },
  ]);
}

/**
 * Главная функция плагина
 */
function withProotShell(config) {
  // Порядок важен:
  // 1. Сначала создаём MainApplication.kt/MainActivity.kt
  // 2. Потом регистрируем ProotPackage
  // 3. Потом копируем нативные файлы
  // 4. Потом правим gradle и permissions
  config = withMainAppFiles(config);
  config = withProotPackage(config);
  config = withProotNativeFiles(config);
  config = withProotBuildGradle(config);
  config = withProotPermissions(config);

  console.log('[prootshell] ✓ Native module installed');
  return config;
}

module.exports = createRunOncePlugin(withProotShell, PLUGIN_NAME, PLUGIN_VERSION);
