/**
 * with-security-guard.js — Expo Config Plugin.
 *
 * При КАЖДОМ `expo prebuild --clean` восстанавливает в android/app/build.gradle:
 *   - хелпер findKeystoreFile + чтение keystore.properties + expectedSha256
 *   - signingConfigs.release с V1/V2/V3 (keystore.properties / ENV / MYAPP_RELEASE_*)
 *   - buildTypes.release: signingConfig signingConfigs.release +
 *     проверка hasReleaseKey → GradleException если ключа нет
 *   - buildConfigField "String", "EXPECTED_SIGNATURE_SHA256", "\"${expectedSha256}\""
 *
 * Плюс: копирует src/native/security/*.kt в android/.../security/,
 * регистрирует SecurityPackage в MainApplication.kt, добавляет proguard -keep.
 *
 * Плагин идемпотентен: повторный запуск не дублирует блоки и не накапливает
 * пустые строки.
 */
const {
  withAppBuildGradle,
  withMainApplication,
  withDangerousMod,
} = require('@expo/config-plugins');
const fs = require('fs');
const path = require('path');

// =========================================================================
// Низкоуровневые утилиты для разбора Gradle-файла
// =========================================================================

// Пропускает строку в кавычках, начиная с позиции j (где стоит открывающая кавычка).
// Возвращает индекс ПОСЛЕ закрывающей кавычки. Корректно обрабатывает escape-\".
function skipQuoted(line, j) {
  const q = line[j];
  j++;
  while (j < line.length) {
    if (line[j] === '\\') { j += 2; continue; }
    if (line[j] === q) return j + 1;
    j++;
  }
  return j;
}

/**
 * matchCloseBrace: находит закрывающую '}' для открывающей '{' на (startLine, startCol).
 * Игнорирует скобки внутри строк (одинарных/двойных кавычек) и комментариев (// и /* ... * /).
 * Возвращает { line, col } закрывающей '}' при глубине targetDepth
 * (0 = своя закрывающая для startCol).
 *
 * Обход строк — через while с ручным i++, чтобы после многострочного блок-комментария
 * не перескочить на строку дальше нужного (внутренний цикл по символам тоже ручной).
 */
function matchCloseBrace(lines, startLine, startCol, targetDepth) {
  let depth = 0, started = false;
  let i = startLine, j = startCol;
  while (i < lines.length) {
    const line = lines[i];
    while (j < line.length) {
      const ch = line[j], nx = line[j + 1];
      if (ch === '"' || ch === "'") { j = skipQuoted(line, j); continue; }
      if (ch === '/' && nx === '/') break; // line comment — skip rest of line
      if (ch === '/' && nx === '*') {
        // block comment — advance until */, staying on current i
        j += 2;
        let done = false;
        while (i < lines.length) {
          const l = lines[i];
          while (j < l.length) {
            if (l[j] === '*' && l[j + 1] === '/') { j += 2; done = true; break; }
            j++;
          }
          if (done) break;
          i++; j = 0;
        }
        continue;
      }
      if (ch === '{') { depth++; started = true; }
      else if (ch === '}') {
        if (started) depth--;
        if (started && depth === targetDepth) return { line: i, col: j };
      }
      j++;
    }
    i++; j = 0;
  }
  return null;
}

// Находит блок `android { ... }` верхнего уровня.
function findAndroidBlock(lines) {
  for (let i = 0; i < lines.length; i++) {
    const m = /^(\s*)android\s*\{/.exec(lines[i]);
    if (m) {
      const oc = lines[i].indexOf('{');
      const cl = matchCloseBrace(lines, i, oc, 0);
      if (cl) return { line: i, openCol: oc, closeLine: cl.line, closeCol: cl.col, indent: m[1] };
    }
  }
  return null;
}

/**
 * Находит прямой блок-потомок внутри parent: блок, начинающийся с `<name> {`
 * на глубине 1 относительно открывающей parent. kwRegex тестируется по
 * trim() текста от начала строки до '{'.
 */
function findChild(lines, parent, kwRegex) {
  // depth — текущий уровень вложенности относительно открывающей '{' родителя.
  // Сразу после входа в родительский блок (обработав его '{') depth = 1,
  // поэтому прямые потомки — это блоки, чья '{' встречается при depth === 1.
  // Стартуем с открывающей '{' родителя на (parent.line, parent.openCol), чтобы
  // корректно обрабатывать и однострочные родительские блоки.
  let i = parent.line;
  let j = parent.openCol;
  let depth = 0;
  while (i <= parent.closeLine) {
    const line = lines[i];
    while (j < line.length) {
      const ch = line[j], nx = line[j + 1];
      if (ch === '"' || ch === "'") { j = skipQuoted(line, j); continue; }
      if (ch === '/' && nx === '/') break;
      if (ch === '/' && nx === '*') {
        j += 2;
        let done = false;
        while (i <= parent.closeLine + 1) {
          const l = lines[i];
          while (j < l.length) {
            if (l[j] === '*' && l[j + 1] === '/') { j += 2; done = true; break; }
            j++;
          }
          if (done) break;
          i++; j = 0;
        }
        continue;
      }
      if (ch === '{') {
        if (depth === 1) {
          // Берём подстроку от предыдущего разделителя ({ ; или начала строки)
          // до текущей позиции — это «голое» имя блока без окружающего контекста
          // (актуально для однострочных родителей вида `signingConfigs { debug { ... } }`).
          const beforeFull = line.slice(0, j);
          const prevSep = Math.max(
            beforeFull.lastIndexOf('{'),
            beforeFull.lastIndexOf(';'),
            -1
          );
          const name = beforeFull.slice(prevSep + 1).trim();
          if (kwRegex.test(name)) {
            const cl = matchCloseBrace(lines, i, j, 0);
            if (cl) return { line: i, openCol: j, closeLine: cl.line, closeCol: cl.col };
          }
        }
        depth++;
      } else if (ch === '}') {
        depth--;
        if (depth <= 0 && (i > parent.line || j > parent.openCol)) {
          // Достигли закрывающей '}' родителя — дальше не его содержимое
          return null;
        }
      }
      j++;
    }
    i++;
    j = 0;
  }
  return null;
}

// Раскрывает однострочный блок на строке idx (`foo { a; b; c }`) в многострочный.
function ensureMultiline(lines, idx) {
  const line = lines[idx];
  const open = line.indexOf('{');
  if (open < 0) return;
  const cl = matchCloseBrace(lines, idx, open, 0);
  if (!cl) return;
  if (cl.line !== idx) return; // уже многострочный
  const indent = (line.match(/^(\s*)/) || ['', ''])[1];
  const innerRaw = line.slice(open + 1, cl.col).trim();
  const innerIndent = indent + '    ';
  const after = line.slice(cl.col + 1);
  const parts = innerRaw
    ? innerRaw.split(/;\s*/).map(s => s.trim()).filter(Boolean).map(s => innerIndent + s)
    : [];
  const replacement = [line.slice(0, open + 1), ...parts, indent + '}' + after];
  lines.splice(idx, 1, ...replacement);
}

// Удаляет диапазон строк [start, end] ВКЛЮЧИТЕЛЬНО.
function deleteRange(lines, start, end) {
  lines.splice(start, end - start + 1);
}

// =========================================================================
// Удаление маркеров и legacy-кода
// =========================================================================

const RE_START = /^\/\/\s*NCS-[A-Z][A-Z0-9_-]*-START\b/;
const RE_END   = /^\/\/\s*NCS-[A-Z][A-Z0-9_-]*-END\b/;

// Удаляет все куски, обрамлённые NCS-*-START / NCS-*-END (с прошлых запусков).
function stripMarkedBlocks(lines) {
  const out = [];
  let skip = 0;
  for (const line of lines) {
    const t = line.trim();
    if (RE_START.test(t)) { skip++; continue; }
    if (RE_END.test(t))   { skip--; continue; }
    if (skip > 0) continue;
    out.push(line);
  }
  return out;
}

// Схлопывает >1 идущих подряд пустых строк внутри android-блока до одной.
function collapseBlankLines(lines) {
  const a = findAndroidBlock(lines);
  if (!a) return lines;
  const res = [];
  let blanks = 0;
  for (let k = 0; k < lines.length; k++) {
    const inside = k > a.line && k < a.closeLine;
    if (inside && lines[k].trim() === '') {
      blanks++;
      if (blanks <= 1) res.push(lines[k]);
    } else {
      blanks = 0;
      res.push(lines[k]);
    }
  }
  return res;
}

// Удаляет legacy keystore-хелперы, если они были вставлены без маркеров
// (старой версией плагина или руками). Это весь блок от
// `def findKeystoreFile = {` до `def expectedSha256 = ...` (включительно).
function stripLegacyKeystore(lines) {
  for (let pass = 0; pass < 5; pass++) {
    const a = findAndroidBlock(lines);
    if (!a) return;
    let start = -1, end = -1;
    for (let i = a.line + 1; i < a.closeLine; i++) {
      const t = lines[i].trim();
      if (start < 0 && /^def\s+findKeystoreFile\b/.test(t)) start = i;
      if (start >= 0 && /^def\s+expectedSha256\b/.test(t)) { end = i; break; }
    }
    if (start < 0 || end < 0) return;
    // прихватим предшествующий комментарий про keystore (если есть и не NCS-маркер)
    if (start > a.line + 1
        && /^\/\/\s*Load release signing/i.test(lines[start - 1].trim())
        && !/NCS-/.test(lines[start - 1])) {
      start--;
    }
    // прихватим соседние пустые строки
    while (start > a.line + 1 && lines[start - 1].trim() === '') start--;
    while (end < a.closeLine - 1 && lines[end + 1].trim() === '') end++;
    deleteRange(lines, start, end);
  }
}

// Удаляет legacy-блоки внутри signingConfigs.release, buildTypes.release и
// buildConfigField EXPECTED_* внутри defaultConfig (оставшиеся от ручной
// правки или старых версий плагина).
function stripLegacyInBlocks(lines) {
  for (let pass = 0; pass < 10; pass++) {
    let changed = false;
    const a = findAndroidBlock(lines);
    if (!a) return;

    // --- signingConfigs: удалить старый release { ... } ---
    const sc = findChild(lines, a, /^signingConfigs$/);
    if (sc) {
      const rel = findChild(lines, sc, /^release$/);
      if (rel) {
        // Проверим, что это НЕ наш маркированный блок (наши марки имеют NCS-RELEASE-SIGNING-START
        // сразу после открывающей '{' signingConfigs, так что сам release-блок НЕ содержит
        // маркеров на своей первой строке; но на всякий случай пропустим, если внутри есть маркер).
        const body = lines.slice(rel.line, rel.closeLine + 1).join('\n');
        if (!/NCS-RELEASE-SIGNING-/.test(body)) {
          deleteRange(lines, rel.line, rel.closeLine);
          changed = true;
          continue;
        }
      }
    }

    const a2 = findAndroidBlock(lines); if (!a2) return;

    // --- buildTypes.release: удалить hasReleaseKey / GradleException / signingConfig ---
    const bt = findChild(lines, a2, /^buildTypes$/);
    if (bt) {
      const rel0 = findChild(lines, bt, /^release$/);
      if (rel0) {
        ensureMultiline(lines, rel0.line);
        const bt2 = findChild(lines, findAndroidBlock(lines), /^buildTypes$/);
        if (bt2) {
          const rel = findChild(lines, bt2, /^release$/);
          if (rel) {
            // Удалить все if (!hasReleaseKey) { ... } (даже пустые, оставшиеся
            // от старых версий плагина или ручной правки). На этом этапе NCS-блок
            // уже снесён stripMarkedBlocks, так что любая встреча — это legacy.
            for (let pass = 0; pass < 5; pass++) {
              let killed = false;
              const relCur = findChild(lines, findChild(lines, findAndroidBlock(lines), /^buildTypes$/), /^release$/);
              if (!relCur) break;
              for (let pi = relCur.line + 1; pi < relCur.closeLine; pi++) {
                if (/if\s*\(\s*!hasReleaseKey\s*\)\s*\{/.test(lines[pi].trim())) {
                  const op = lines[pi].indexOf('{');
                  if (op >= 0) {
                    const cl = matchCloseBrace(lines, pi, op, 0);
                    if (cl) {
                      // Сносим только если тело не содержит сторонний код
                      // (minifyEnabled/shrinkResources/proguardFiles и т.п.).
                      // Внутри наших legacy-блоков был только throw GradleException.
                      let safe = true;
                      for (let k = pi + 1; k < cl.line; k++) {
                        const tt = lines[k].trim();
                        if (tt === '' || /^\/\//.test(tt) || /^\*|throw\s+new\s+GradleException/.test(tt)) continue;
                        safe = false; break;
                      }
                      if (safe) {
                        deleteRange(lines, pi, cl.line);
                      } else {
                        // Удалить только throw внутри
                        for (let k = cl.line - 1; k > pi; k--) {
                          if (/throw\s+new\s+GradleException/.test(lines[k].trim())) {
                            lines.splice(k, 1);
                          }
                        }
                      }
                      changed = true;
                      killed = true;
                      break;
                    }
                  }
                }
              }
              if (!killed) break;
            }
            // Удалить одиночные legacy-строки (def hasReleaseKey, stray throw,
            // stray signingConfig release/debug, старые NCS CHECK-комментарии).
            const rel2 = findChild(lines, findChild(lines, findAndroidBlock(lines), /^buildTypes$/), /^release$/);
            if (rel2) {
              for (let pi = rel2.closeLine - 1; pi > rel2.line; pi--) {
                const t = lines[pi].trim();
                if (/^def\s+hasReleaseKey\b/.test(t)
                    || /throw\s+new\s+GradleException\s*\(/.test(t)
                    || /^signingConfig\s+signingConfigs\.(release|debug)\b/.test(t)
                    || /^\/\/\s*NCS-RELEASE-CHECK-(START|END)\b/.test(t)) {
                  lines.splice(pi, 1);
                  changed = true;
                }
              }
            }
          }
        }
      }
    }

    const a3 = findAndroidBlock(lines); if (!a3) return;

    // --- defaultConfig: удалить старый buildConfigField EXPECTED_* ---
    const dc = findChild(lines, a3, /^defaultConfig$/);
    if (dc) {
      for (let pi = dc.closeLine - 1; pi > dc.line; pi--) {
        if (/buildConfigField\s+"String"\s*,\s*"EXPECTED_SIGNATURE_SHA256"/.test(lines[pi])) {
          lines.splice(pi, 1);
          changed = true;
        }
      }
    }

    if (!changed) break;
  }
}

// =========================================================================
// Вставка свежих NCS-блоков
// =========================================================================

const KEY_S = '    // NCS-KEYSTORE-START (do not edit by hand)';
const KEY_E = '    // NCS-KEYSTORE-END';
const keystoreBlock = [
  KEY_S,
  '    // Load release signing configuration from keystore.properties if present',
  '    def findKeystoreFile = { String name ->',
  '        if (!name) return new File(projectRoot, "ncs.keystore")',
  '        def f1 = new File(projectRoot, name)',
  '        if (f1.exists()) return f1',
  '        def f2 = rootProject.file(name)',
  '        if (f2.exists()) return f2',
  '        def f3 = file(name)',
  '        if (f3.exists()) return f3',
  '        return f1',
  '    }',
  '',
  '    def keystorePropsFile = findKeystoreFile("keystore.properties")',
  '    def keystoreProps = new Properties()',
  '    if (keystorePropsFile.exists()) {',
  '        keystoreProps.load(new FileInputStream(keystorePropsFile))',
  '    }',
  '    def expectedSha256 = keystoreProps.getProperty(\'expectedSha256\', System.getenv("EXPECTED_SIGNATURE_SHA256") ?: "")',
  KEY_E,
];

const REL_S = '        // NCS-RELEASE-SIGNING-START';
const REL_E = '        // NCS-RELEASE-SIGNING-END';
const releaseSignBlock = [
  REL_S,
  '        release {',
  '            if (keystorePropsFile.exists()) {',
  '                def sfPath = keystoreProps[\'storeFile\'] ?: "ncs"',
  '                storeFile findKeystoreFile(sfPath)',
  '                storePassword keystoreProps[\'storePassword\']',
  '                keyAlias keystoreProps[\'keyAlias\']',
  '                keyPassword keystoreProps[\'keyPassword\']',
  '                enableV1Signing true',
  '                enableV2Signing true',
  '                enableV3Signing true',
  '            } else if (System.getenv("KEYSTORE_FILE") != null) {',
  '                storeFile file(System.getenv("KEYSTORE_FILE"))',
  '                storePassword System.getenv("KEYSTORE_PASSWORD")',
  '                keyAlias System.getenv("KEY_ALIAS")',
  '                keyPassword System.getenv("KEY_PASSWORD")',
  '                enableV1Signing true',
  '                enableV2Signing true',
  '                enableV3Signing true',
  '            } else if (findProperty(\'MYAPP_RELEASE_STORE_FILE\') != null) {',
  '                storeFile file(findProperty(\'MYAPP_RELEASE_STORE_FILE\'))',
  '                storePassword findProperty(\'MYAPP_RELEASE_STORE_PASSWORD\')',
  '                keyAlias findProperty(\'MYAPP_RELEASE_KEY_ALIAS\')',
  '                keyPassword findProperty(\'MYAPP_RELEASE_KEY_PASSWORD\')',
  '                enableV1Signing true',
  '                enableV2Signing true',
  '                enableV3Signing true',
  '            }',
  '        }',
  REL_E,
];

const CHK_S = '            // NCS-RELEASE-CHECK-START';
const CHK_E = '            // NCS-RELEASE-CHECK-END';
const checkBlock = [
  CHK_S,
  '            def hasReleaseKey = keystorePropsFile.exists() || System.getenv("KEYSTORE_FILE") != null || findProperty("MYAPP_RELEASE_STORE_FILE") != null',
  '            if (!hasReleaseKey) {',
  '                throw new GradleException("ОШИБКА ПОДПИСИ РЕЛИЗА: Не найден файл keystore.properties или ключ подписи! Перед сборкой релиза запустите \'npm run key\' в корне проекта.")',
  '            }',
  '            signingConfig signingConfigs.release',
  CHK_E,
];

// Вставляет `block` на строке `at` с ровно одной пустой строкой перед ним
// (если перед ним не пусто и не начало android-блока), но НЕ добавляет пустую
// строку после.
function insertBlock(lines, at, block, androidLine) {
  const needBlank = at > androidLine + 1 && lines[at - 1].trim() !== '';
  const toAdd = needBlank ? ['', ...block] : [...block];
  lines.splice(at, 0, ...toAdd);
}

function editBuildGradle(contents) {
  let lines = contents.split(/\r?\n/);

  // 1. Снести все NCS-*-блоки от прошлых запусков
  lines = stripMarkedBlocks(lines);

  // 2. Снести legacy-вставки (без маркеров)
  stripLegacyKeystore(lines);
  stripLegacyInBlocks(lines);

  // 3. Раскрыть однострочные блоки, в которые будем вставлять
  {
    const a = findAndroidBlock(lines);
    if (!a) return lines.join('\n');
    for (const kw of [/^defaultConfig$/, /^signingConfigs$/, /^buildTypes$/]) {
      const b = findChild(lines, a, kw);
      if (b) ensureMultiline(lines, b.line);
    }
    // вложенные debug/release
    const a2 = findAndroidBlock(lines); if (a2) {
      for (const parentK of [/^signingConfigs$/, /^buildTypes$/]) {
        const p = findChild(lines, a2, parentK);
        if (p) {
          for (const ch of [/^debug$/, /^release$/]) {
            const c = findChild(lines, p, ch);
            if (c) ensureMultiline(lines, c.line);
          }
        }
      }
    }
  }

  // 4. Сверить позиции
  let andr = findAndroidBlock(lines);
  if (!andr) return lines.join('\n');
  let ns = findChild(lines, andr, /^defaultConfig$/);
  let sc = findChild(lines, andr, /^signingConfigs$/);
  let bt = findChild(lines, andr, /^buildTypes$/);
  if (!ns) return lines.join('\n');

  // 5. Вставить keystore-хелперы ПЕРЕД defaultConfig
  insertBlock(lines, ns.line, keystoreBlock, andr.line);

  // 6. Пересчитать позиции и вставить release { ... } в signingConfigs
  andr = findAndroidBlock(lines);
  sc = findChild(lines, andr, /^signingConfigs$/);
  bt = findChild(lines, andr, /^buildTypes$/);
  if (sc) {
    lines.splice(sc.line + 1, 0, ...releaseSignBlock);
  }

  // 7. Пересчитать позиции и вставить check-блок в buildTypes.release
  andr = findAndroidBlock(lines);
  bt = findChild(lines, andr, /^buildTypes$/);
  if (bt) {
    // release после раскрытия многострочный
    let rel = findChild(lines, bt, /^release$/);
    if (rel) {
      ensureMultiline(lines, rel.line);
      const bt2 = findChild(lines, findAndroidBlock(lines), /^buildTypes$/);
      rel = bt2 && findChild(lines, bt2, /^release$/);
      if (rel) lines.splice(rel.line + 1, 0, ...checkBlock);
    }
  }

  // 8. Пересчитать позиции и вставить buildConfigField перед '}' defaultConfig
  andr = findAndroidBlock(lines);
  ns = findChild(lines, andr, /^defaultConfig$/);
  if (ns) {
    const fl = '        buildConfigField "String", "EXPECTED_SIGNATURE_SHA256", "\\"${expectedSha256}\\""';
    lines.splice(ns.closeLine, 0, fl);
  }

  // 9. Финальная зачистка сдвоенных пустых строк
  lines = collapseBlankLines(lines);

  return lines.join('\n');
}

// =========================================================================
// MainApplication.kt / Kotlin / proguard
// =========================================================================

function editMainApplication(contents) {
  if (contents.includes('ru.wfllive.nova.security.SecurityPackage')) return contents;
  const lines = contents.split('\n');
  // Добавить import после последнего import
  let lastImport = -1;
  for (let i = 0; i < lines.length; i++) if (/^import\s/.test(lines[i])) lastImport = i;
  if (lastImport >= 0) lines.splice(lastImport + 1, 0, 'import ru.wfllive.nova.security.SecurityPackage');

  // Найти строку вида "PackageList(this).packages.apply {" и вставить
  // add(SecurityPackage()) на следующей строке с правильным отступом.
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^(\s*)PackageList\(this\)\.packages\.apply\s*\{/);
    if (m) {
      const baseIndent = m[1];
      // Отступ = базовый отступ строки + 4 пробела (уровень вложенности внутри apply {})
      const indent = baseIndent + '    ';
      // Проверить: не пуст ли уже блок? Если следующая непустая строка уже с большим отступом,
      // используем этот отступ.
      let insertIndent = indent;
      for (let k = i + 1; k < lines.length; k++) {
        const t = lines[k].trim();
        if (t === '') continue;
        const im = lines[k].match(/^(\s+)/);
        if (im && im[1].length > baseIndent.length) {
          insertIndent = im[1];
        }
        break;
      }
      lines.splice(i + 1, 0, insertIndent + 'add(SecurityPackage())');
      break;
    }
  }
  return lines.join('\n');
}

function copySecurityFiles(projectRoot) {
  const srcDir = path.join(projectRoot, 'src', 'native', 'security');
  const destDir = path.join(projectRoot, 'android', 'app', 'src', 'main', 'java',
                            'ru', 'wfllive', 'nova', 'security');
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(destDir, { recursive: true });
  for (const file of fs.readdirSync(srcDir)) {
    const s = path.join(srcDir, file);
    if (fs.statSync(s).isFile()) fs.copyFileSync(s, path.join(destDir, file));
  }
  const proguardPath = path.join(projectRoot, 'android', 'app', 'proguard-rules.pro');
  if (fs.existsSync(proguardPath)) {
    let p = fs.readFileSync(proguardPath, 'utf8');
    if (!p.includes('ru.wfllive.nova.security')) {
      p += '\n# Anti-Mod Security Guard Rules\n'
         + '-keep class ru.wfllive.nova.security.** { *; }\n'
         + '-keepclassmembers class ru.wfllive.nova.security.** { *; }\n';
      fs.writeFileSync(proguardPath, p, 'utf8');
    }
  }
}

// =========================================================================
// Сам плагин
// =========================================================================

function withSecurityGuard(config) {
  config = withDangerousMod(config, ['android', async (config) => {
    copySecurityFiles(config.modRequest.projectRoot);
    return config;
  }]);

  config = withMainApplication(config, (config) => {
    config.modResults.contents = editMainApplication(config.modResults.contents || '');
    return config;
  });

  config = withAppBuildGradle(config, (config) => {
    config.modResults.contents = editBuildGradle(config.modResults.contents);
    return config;
  });

  return config;
}

module.exports = withSecurityGuard;