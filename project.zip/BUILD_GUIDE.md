# 🚀 Руководство по запуску и сборке

## Способы запуска приложения

### 1. 📱 Expo Go (Для разработки и тестирования)

**Когда использовать:** Быстрое тестирование без сборки APK.

**Требования:**
- Приложение Expo Go на устройстве (Play Store / App Store)
- Компьютер и устройство в одной Wi-Fi сети

**Как запустить:**
```bash
cd sketchware-pro
npx expo start
```

1. Откройте Expo Go на устройстве
2. Отсканируйте QR код из терминала
3. Приложение запустится автоматически

**Горячие клавиши терминала:**
| Клавиша | Действие |
|---------|----------|
| `A` | Открыть на Android устройстве |
| `I` | Открыть в iOS симуляторе |
| `W` | Открыть в браузере |
| `S` | Переключить Expo Go / Dev Build |
| `R` | Перезагрузить |
| `E` | Показать QR код |

**Ограничения Expo Go:**
- ❌ Нет доступа к кастомным нативным модулям
- ❌ Некоторые библиотеки не поддерживаются
- ✅ Быстрый старт без компиляции
- ✅ Hot reload из коробки

---

### 2. 🔨 EAS Build (Для сборки APK/AAB)

**Когда использовать:** Создание готового APK для установки или публикации.

#### Установка EAS CLI

```bash
# Глобальная установка
npm install -g eas-cli

# Или через yarn
yarn global add eas-cli
```

#### Вход в Expo

```bash
eas login
# Введите email и пароль от expo.dev
```

#### Инициализация проекта

```bash
cd sketchware-pro
eas init
# Это создаст проект на expo.dev и добавит projectId в app.json
```

#### Сборка Android APK (Preview)

```bash
# Облачная сборка (рекомендуется)
eas build --platform android --profile preview

# Локальная сборка (требует Android SDK)
eas build --platform android --profile preview --local
```

#### Сборка для Google Play (Production)

```bash
# Создаёт AAB файл для Play Store
eas build --platform android --profile production
```

#### Development Build

```bash
# Сборка с dev-client для разработки
eas build --platform android --profile development
```

---

## 📦 Управление библиотеками

### Рекомендованный способ: `npx expo install`

```bash
# Expo автоматически подберёт совместимую версию
npx expo install react-native-maps
npx expo install expo-camera expo-location
```

### Альтернативные способы

```bash
# npm
npm install <package-name>

# yarn
yarn add <package-name>
```

### ⚠️ Важно

- Используйте `npx expo install` для Expo-библиотек (expo-*)
- Для обычных npm-пакетов можно использовать npm/yarn напрямую
- После установки нативных модулей нужен пересборка (EAS Build)
- Expo Go поддерживает только определённый набор библиотек

### Популярные команды

```bash
# Камера
npx expo install expo-camera

# Геолокация
npx expo install expo-location

# Карты
npx expo install react-native-maps

# Навигация
npx expo install @react-navigation/native @react-navigation/native-stack
npx expo install react-native-screens react-native-safe-area-context

# AsyncStorage
npx expo install @react-native-async-storage/async-storage

# WebView
npx expo install react-native-webview
```

---

## 📋 eas.json конфигурация

Файл `eas.json` уже настроен в проекте:

```json
{
  "cli": {
    "version": ">= 12.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal",
      "android": { "buildType": "apk" }
    },
    "preview": {
      "distribution": "internal",
      "android": { "buildType": "apk" }
    },
    "production": {
      "android": { "buildType": "app-bundle" }
    }
  }
}
```

### Профили сборки

| Профиль | Тип | Для чего |
|---------|-----|----------|
| `development` | APK | Разработка с dev-client |
| `preview` | APK | Тестирование на устройстве |
| `production` | AAB | Публикация в Google Play |

---

## 🔄 Полный цикл разработки

### 1. Начальная разработка (Expo Go)
```bash
npx expo start
# Сканируйте QR код в Expo Go
```

### 2. Добавление нативных модулей
```bash
npx expo install expo-camera
eas build --platform android --profile development
# Установите development build APK
```

### 3. Тестирование (Preview APK)
```bash
eas build --platform android --profile preview
# Скачайте APK с expo.dev и установите на устройство
```

### 4. Публикация (Production)
```bash
eas build --platform android --profile production
# Загрузите AAB в Google Play Console
```

---

## 🔗 Полезные ссылки

- [Expo Documentation](https://docs.expo.dev/)
- [EAS Build Guide](https://docs.expo.dev/build/setup/)
- [Expo Go App](https://expo.dev/go)
- [React Native Directory](https://reactnative.directory/)
- [EAS Dashboard](https://expo.dev/)
