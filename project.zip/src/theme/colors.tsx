import { useColorScheme } from 'react-native';
/**
 * Semantic colour tokens used by the builder. Both palettes are deliberately
 * opaque: system bars
headers and navigation surfaces never rely on blur or
 * transparency to remain readable.
 */
export const lightColors = {
  mode: 'light'
  primary: '#4F46E5'
  primaryLight: '#6366F1'
  primaryDark: '#3730A3'
  primarySurface: '#EEF2FF'
  accent: '#0E7490'
  accentLight: '#0891B2'
  bg: '#F4F6FA'
  bgCard: '#FFFFFF'
  bgElevated: '#F1F3F8'
  bgInput: '#FFFFFF'
  bgHover: '#EAEDF4'
  surface: '#FFFFFF'
  surfaceLight: '#F1F3F8'
  surfaceHigh: '#E4E8F0'
  text: '#111827'
  textSecondary: '#4B5563'
  textTertiary: '#7C8799'
  textInverse: '#FFFFFF'
  border: '#DDE2EA'
  borderLight: '#CBD2DE'
  borderFocus: '#4F46E5'
  success: '#047857'
  successBg: '#D1FAE5'
  successText: '#065F46'
  warning: '#B45309'
  warningBg: '#FEF3C7'
  warningText: '#78350F'
  error: '#B91C1C'
  errorBg: '#FEE2E2'
  errorText: '#991B1B'
  info: '#1D4ED8'
  infoBg: '#DBEAFE'
  infoText: '#1E3A8A'
  blockEvent: '#B45309'
  blockControl: '#B91C1C'
  blockOperator: '#047857'
  blockVariable: '#C2410C'
  blockLogic: '#1D4ED8'
  blockComponent: '#6D28D9'
  blockMath: '#0E7490'
  blockText: '#15803D'
  blockList: '#BE185D'
  compLayout: '#6D28D9'
  compWidget: '#1D4ED8'
  compInput: '#C2410C'
  compMedia: '#0E7490'
  selection: '#E0E7FF'
  selectionBorder: '#4F46E5'
  canvas: '#E9EDF4'
  canvasGrid: '#D7DDE7'
  canvasDot: '#B8C1D0'
  shadow: '#172033'
  overlay: '#111827B3'
  systemBar: '#FFFFFF'
  terminal: '#090D16'
  terminalRaised: '#111827'
};
export const darkColors = {
  mode: 'dark'
  primary: '#818CF8'
  primaryLight: '#A5B4FC'
  primaryDark: '#6366F1'
  primarySurface: '#252B50'
  accent: '#22D3EE'
  accentLight: '#67E8F9'
  bg: '#0B1020'
  bgCard: '#121A2B'
  bgElevated: '#1A2438'
  bgInput: '#151F32'
  bgHover: '#222E45'
  surface: '#121A2B'
  surfaceLight: '#1A2438'
  surfaceHigh: '#26334B'
  text: '#F3F6FB'
  textSecondary: '#B3BED0'
  textTertiary: '#8491A7'
  textInverse: '#0B1020'
  border: '#29364E'
  borderLight: '#3A4861'
  borderFocus: '#818CF8'
  success: '#34D399'
  successBg: '#123D35'
  successText: '#A7F3D0'
  warning: '#FBBF24'
  warningBg: '#4A3414'
  warningText: '#FDE68A'
  error: '#F87171'
  errorBg: '#4B2027'
  errorText: '#FECACA'
  info: '#60A5FA'
  infoBg: '#172F54'
  infoText: '#BFDBFE'
  blockEvent: '#D99A25'
  blockControl: '#E05E65'
  blockOperator: '#24A97A'
  blockVariable: '#E47A3F'
  blockLogic: '#4F8FEA'
  blockComponent: '#8B72DF'
  blockMath: '#25A8BA'
  blockText: '#40AD62'
  blockList: '#D55C99'
  compLayout: '#A78BFA'
  compWidget: '#60A5FA'
  compInput: '#FB923C'
  compMedia: '#22D3EE'
  selection: '#282E58'
  selectionBorder: '#818CF8'
  canvas: '#0E1525'
  canvasGrid: '#182238'
  canvasDot: '#29364E'
  shadow: '#000000'
  overlay: '#020617D9'
  systemBar: '#121A2B'
  terminal: '#070B12'
  terminalRaised: '#111827'
};
const addLegacyAliases = (palette) => ({
  ...palette
  background: palette.bg
  secondary: palette.accent
  onSurface: palette.text
  onSurfaceVariant: palette.textSecondary
  onPrimary: '#FFFFFF'
});
export const themes = {
  light: addLegacyAliases(lightColors)
  dark: addLegacyAliases(darkColors)
};
// Compatibility for older generator/editor modules that have not moved to the
// settings context yet. New UI should use useAppSettings().colors.
const colors = themes.light;
export const useTheme = () => {
  const scheme = useColorScheme();
  return themes[scheme === 'dark' ? 'dark' : 'light'];
};
export default colors;