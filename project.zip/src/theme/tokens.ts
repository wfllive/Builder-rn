/**
 * Токены дизайн-системы Twitblit (JS-зеркало CSS-переменных).
 *
 * ЗАЧЕМ:
 * NativeWind отлично понимает `bg-primary`, но часть RN API
 * (style, SVG fill, Animated) принимает только конкретные строки.
 * Поэтому храним палитру и здесь.
 *
 * Использовать:
 * - className → CSS-переменные (`var(--primary-color)`)
 * - style / svg → `themeTokens.light.primary` или `resolveToken(isDark, "primary")`
 */

/** Имена токенов, совпадающие с web color-styles.css */
export type ThemeTokenName =
  | "primary"
  | "secondary"
  | "tertiary"
  | "text"
  | "textMuted"
  | "background"
  | "modal"
  | "dropdown"
  | "input"
  | "placeholder"
  | "success"
  | "warning"
  | "error"
  | "white"
  | "black"
  | "grey0"
  | "grey1"
  | "orange"
  | "seaBreeze"
  | "lightRed"
  | "red"
  | "blue";

/** Светлая палитра — 1:1 с :root веб-приложения */
export const lightTokens: Record<ThemeTokenName, string> = {
  primary: "#5F18DA",
  secondary: "#a36eff",
  tertiary: "#510082",
  text: "#000000",
  textMuted: "#A9A9A9",
  background: "#ffffff",
  modal: "#ffffff",
  dropdown: "#ffffff",
  input: "#F0F0F0",
  placeholder: "#C8C8C8",
  success: "#5bbb50",
  warning: "#e07436",
  error: "#de5567",
  white: "#ffffff",
  black: "#000000",
  grey0: "#cacaca",
  grey1: "#6D6B6B",
  orange: "#DA5F18",
  seaBreeze: "#18DAC0",
  lightRed: "#FF95A4",
  red: "#de5567",
  blue: "#4098F5",
};

/** Тёмная палитра — 1:1 с html[data-theme="dark"] */
export const darkTokens: Record<ThemeTokenName, string> = {
  ...lightTokens,
  primary: "#701dff",
  text: "#F3F5F7",
  textMuted: "#a1a1a1",
  background: "#0A0A0A",
  modal: "#15111a",
  dropdown: "#15111a",
  input: "#221a2a",
  placeholder: "#6b7280",
};

/**
 * Возвращает конкретный цвет токена для текущей темы.
 * Нужен иконкам, SVG и Animated, где className недоступен.
 */
export function resolveToken(
  isDark: boolean,
  name: ThemeTokenName
): string {
  return (isDark ? darkTokens : lightTokens)[name];
}

/**
 * CSS-переменная по имени токена.
 * Удобно прокидывать в web-совместимые места (Expo Web).
 */
export const cssVars: Record<ThemeTokenName, string> = {
  primary: "var(--primary-color)",
  secondary: "var(--secondary-color)",
  tertiary: "var(--tertiary-color)",
  text: "var(--text-color)",
  textMuted: "var(--text-muted-color)",
  background: "var(--background-color)",
  modal: "var(--container-modal-background)",
  dropdown: "var(--container-dropdown-background)",
  input: "var(--container-input-background)",
  placeholder: "var(--container-input-placeholder-color)",
  success: "var(--container-input-success)",
  warning: "var(--container-input-warning)",
  error: "var(--container-input-error)",
  white: "var(--neutral-white)",
  black: "var(--neutral-black)",
  grey0: "var(--neutral-grey-0)",
  grey1: "var(--neutral-grey-1)",
  orange: "var(--neutral-orange-0)",
  seaBreeze: "var(--neutral-sea-breeze)",
  lightRed: "var(--neutral-light-red)",
  red: "var(--neutral-red)",
  blue: "var(--neutral-blue)",
};
