import { useColorScheme } from 'react-native';

const lightColors = {
  primary: '#6D28D9',
  primaryLight: '#8B5CF6',
  primaryDark: '#5B21B6',
  primarySurface: '#EDE9FE',
  
  accent: '#0891B2',
  accentLight: '#06B6D4',
  
  bg: '#F9FAFB',
  bgCard: '#FFFFFF',
  bgElevated: '#F3F4F6',
  bgInput: '#FFFFFF',
  bgHover: '#F3F4F6',
  
  surface: '#FFFFFF',
  surfaceLight: '#F3F4F6',
  surfaceHigh: '#E5E7EB',
  
  text: '#111827',
  textSecondary: '#4B5563',
  textTertiary: '#9CA3AF',
  textInverse: '#FFFFFF',
  
  border: '#E5E7EB',
  borderLight: '#D1D5DB',
  borderFocus: '#6D28D9',
  
  success: '#059669',
  successBg: '#D1FAE5',
  successText: '#065F46',
  warning: '#D97706',
  warningBg: '#FEF3C7',
  warningText: '#92400E',
  error: '#DC2626',
  errorBg: '#FEE2E2',
  errorText: '#991B1B',
  info: '#2563EB',
  infoBg: '#DBEAFE',
  infoText: '#1E40AF',
  
  blockEvent: '#D97706',
  blockControl: '#DC2626',
  blockOperator: '#059669',
  blockVariable: '#EA580C',
  blockLogic: '#2563EB',
  blockComponent: '#7C3AED',
  blockMath: '#0891B2',
  blockText: '#16A34A',
  blockList: '#DB2777',
  
  compLayout: '#7C3AED',
  compWidget: '#2563EB',
  compInput: '#EA580C',
  compMedia: '#0891B2',
  
  selection: '#6D28D920',
  selectionBorder: '#6D28D9',
  
  canvas: '#F9FAFB',
  canvasGrid: '#E5E7EB',
  canvasDot: '#D1D5DB',
  
  shadow: 'rgba(0,0,0,0.08)',
  overlay: 'rgba(0,0,0,0.4)',
};

const darkColors = {
  primary: '#A78BFA',
  primaryLight: '#C4B5FD',
  primaryDark: '#7C3AED',
  primarySurface: '#7C3AED25',
  
  accent: '#22D3EE',
  accentLight: '#67E8F9',
  
  bg: '#0F172A',
  bgCard: '#1E293B',
  bgElevated: '#334155',
  bgInput: '#1E293B',
  bgHover: '#334155',
  
  surface: '#1E293B',
  surfaceLight: '#334155',
  surfaceHigh: '#475569',
  
  text: '#F1F5F9',
  textSecondary: '#94A3B8',
  textTertiary: '#64748B',
  textInverse: '#0F172A',
  
  border: '#334155',
  borderLight: '#475569',
  borderFocus: '#A78BFA',
  
  success: '#34D399',
  successBg: '#064E3B',
  successText: '#6EE7B7',
  warning: '#FBBF24',
  warningBg: '#78350F',
  warningText: '#FDE68A',
  error: '#F87171',
  errorBg: '#7F1D1D',
  errorText: '#FCA5A5',
  info: '#60A5FA',
  infoBg: '#1E3A5F',
  infoText: '#93C5FD',
  
  blockEvent: '#FBBF24',
  blockControl: '#F87171',
  blockOperator: '#34D399',
  blockVariable: '#FB923C',
  blockLogic: '#60A5FA',
  blockComponent: '#A78BFA',
  blockMath: '#22D3EE',
  blockText: '#4ADE80',
  blockList: '#F472B6',
  
  compLayout: '#A78BFA',
  compWidget: '#60A5FA',
  compInput: '#FB923C',
  compMedia: '#22D3EE',
  
  selection: '#A78BFA30',
  selectionBorder: '#A78BFA',
  
  canvas: '#0F172A',
  canvasGrid: '#1E293B',
  canvasDot: '#334155',
  
  shadow: 'rgba(0,0,0,0.3)',
  overlay: 'rgba(0,0,0,0.6)',
};

// Хук для использования в компонентах
export const useTheme = () => {
  const scheme = useColorScheme();
  return scheme === 'dark' ? darkColors : lightColors;
};

// Дефолтный экспорт (светлая тема для компонентов без хуков)
export default lightColors;
