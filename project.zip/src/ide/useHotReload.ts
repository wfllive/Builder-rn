/**
 * Hot Reload Hook
 *
 * Управляет инкрементальной компиляцией и горячей перезагрузкой предпросмотра:
 * 1. Дебаунсит изменения кода (не перезагружает на каждый нажатие клавиши)
 * 2. Запускает мгновенный XML/Compose preview (мгновенно, без компиляции)
 * 3. По необходимости запускает инкрементальную javac+dex компиляцию в фоне
 * 4. Поддерживает два уровня предпросмотра: быстрый визуальный и полный dex hot swap
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { renderXmlPreview, hotReloadCompile } from '../../modules/apt-manager/src';

export type ReloadStatus = 'idle' | 'parsing' | 'compiling' | 'rendering' | 'ready' | 'error';

export interface HotReloadState {
  status: ReloadStatus;
  previewBase64: string | null;
  lastCompileMs: number;
  changedFilesCount: number;
  error: string | null;
  compileInProgress: boolean;
  instantPreviewReady: boolean;
}

export interface HotReloadOptions {
  projectRoot: string;
  currentFile: string;
  fileContent: string;
  isLayoutXml: boolean;
  isJavaFile: boolean;
  enabled: boolean;
  colors?: Record<string, string>;
  strings?: Record<string, string>;
  darkMode?: boolean;
  density?: number;
  debounceMs?: number;
  onPreviewReady?: (base64: string) => void;
  onCompileResult?: (success: boolean, message: string) => void;
}

export function useHotReload(options: HotReloadOptions): HotReloadState & {
  requestReload: () => void;
  forceFullReload: () => void;
} {
  const {
    projectRoot,
    currentFile,
    fileContent,
    isLayoutXml,
    isJavaFile,
    enabled,
    colors = {},
    strings = {},
    darkMode = false,
    density = 2.625,
    debounceMs = 300,
    onPreviewReady,
    onCompileResult,
  } = options;

  const [state, setState] = useState<HotReloadState>({
    status: 'idle',
    previewBase64: null,
    lastCompileMs: 0,
    changedFilesCount: 0,
    error: null,
    compileInProgress: false,
    instantPreviewReady: false,
  });

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastContentRef = useRef<string>('');
  const pendingChanges = useRef<Set<string>>(new Set());

  // Быстрый мгновенный предпросмотр (без компиляции, нативный рендер)
  const runInstantPreview = useCallback(async () => {
    if (!isLayoutXml || !enabled || !fileContent) return;

    setState(s => ({ ...s, status: 'rendering', error: null }));

    try {
      const result = await renderXmlPreview({
        layoutXml: fileContent,
        widthDp: 411,
        heightDp: 891,
        isDark: darkMode,
        density,
        colors,
        strings,
      });

      if (result.success && result.base64) {
        setState(s => ({
          ...s,
          status: 'ready',
          previewBase64: result.base64,
          instantPreviewReady: true,
          error: null,
        }));
        onPreviewReady?.(result.base64);
      } else {
        setState(s => ({
          ...s,
          status: 'error',
          error: result.output || 'Preview render failed',
        }));
      }
    } catch (e) {
      setState(s => ({
        ...s,
        status: 'error',
        error: e instanceof Error ? e.message : String(e),
      }));
    }
  }, [fileContent, isLayoutXml, enabled, darkMode, density, colors, strings, onPreviewReady]);

  // Инкрементальная компиляция (для Java-кода, в фоне)
  const runIncrementalCompile = useCallback(async (forceFull = false) => {
    if (!enabled || (!isJavaFile && !forceFull)) return;

    const filesToCompile = forceFull
      ? getAllJavaFiles(projectRoot)
      : Array.from(pendingChanges.current);

    if (filesToCompile.length === 0) return;

    setState(s => ({ ...s, status: 'compiling', compileInProgress: true }));

    try {
      const result = await hotReloadCompile({
        projectRoot,
        changedFiles: filesToCompile,
      });

      pendingChanges.current.clear();

      if (result.success) {
        setState(s => ({
          ...s,
          status: 'ready',
          compileInProgress: false,
          lastCompileMs: result.compileMs,
          changedFilesCount: result.changedFiles,
          error: null,
        }));
        onCompileResult?.(true, result.message);
      } else {
        setState(s => ({
          ...s,
          status: 'error',
          compileInProgress: false,
          error: result.message,
        }));
        onCompileResult?.(false, result.message);
      }
    } catch (e) {
      setState(s => ({
        ...s,
        status: 'error',
        compileInProgress: false,
        error: e instanceof Error ? e.message : String(e),
      }));
    }
  }, [projectRoot, isJavaFile, enabled, onCompileResult]);

  // Дебаунс изменений
  useEffect(() => {
    if (!enabled) return;
    if (fileContent === lastContentRef.current) return;

    lastContentRef.current = fileContent;

    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }

    if (currentFile) {
      pendingChanges.current.add(currentFile);
    }

    debounceTimer.current = setTimeout(() => {
      // Сначала запускаем мгновенный предпросмотр (если XML)
      if (isLayoutXml) {
        runInstantPreview();
      }

      // Затем фоновая инкрементальная компиляция для Java
      if (isJavaFile) {
        runIncrementalCompile(false);
      }
    }, debounceMs);

    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current);
      }
    };
  }, [fileContent, enabled, isLayoutXml, isJavaFile, debounceMs, runInstantPreview, runIncrementalCompile, currentFile]);

  const requestReload = useCallback(() => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    if (isLayoutXml) {
      runInstantPreview();
    }
    if (isJavaFile) {
      runIncrementalCompile(false);
    }
  }, [isLayoutXml, isJavaFile, runInstantPreview, runIncrementalCompile]);

  const forceFullReload = useCallback(() => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    pendingChanges.current.clear();
    runInstantPreview();
    runIncrementalCompile(true);
  }, [runInstantPreview, runIncrementalCompile]);

  return {
    ...state,
    requestReload,
    forceFullReload,
  };
}

/**
 * Получает все .java файлы в проекте для полной перекомпиляции
 */
function getAllJavaFiles(projectRoot: string): string[] {
  // В нативном окружении это будет работать через модуль
  // На клиенте мы получаем список через file system API
  return [];
}
