export const API_STRIKES = 'https://meteolive.h1n.ru/strikes.php';

export const RAINVIEWER_API = 'https://api.rainviewer.com/public/weather-maps.json';

export const MAPTILER_KEY = 'ezK8ngy5zoXklqnwQiwT';

// OpenFreeMap - completely free, no key
export const OPENFREEMAP_STYLE = 'https://tiles.openfreemap.org/styles/liberty';

export const MAP_STYLES = {
  dark: {
    name: 'Тёмная',
    url: `https://api.maptiler.com/maps/dataviz-dark/style.json?key=${MAPTILER_KEY}`,
    fallback: 'https://tiles.openfreemap.org/styles/dark',
  },
  light: {
    name: 'Светлая',
    url: `https://api.maptiler.com/maps/dataviz-light/style.json?key=${MAPTILER_KEY}`,
    fallback: OPENFREEMAP_STYLE,
  },
  streets: {
    name: 'Улицы',
    url: `https://api.maptiler.com/maps/streets-v2/style.json?key=${MAPTILER_KEY}`,
    fallback: OPENFREEMAP_STYLE,
  },
  satellite: {
    name: 'Спутник',
    // use OSM raster fallback via style
    url: `https://api.maptiler.com/maps/hybrid/style.json?key=${MAPTILER_KEY}`,
    fallback: OPENFREEMAP_STYLE,
  },
  topo: {
    name: 'Рельеф',
    url: `https://api.maptiler.com/maps/topo-v2/style.json?key=${MAPTILER_KEY}`,
    fallback: OPENFREEMAP_STYLE,
  },
} as const;

export type ThemeKey = keyof typeof MAP_STYLES;

export const DEFAULT_CONFIG = {
  anim: true,
  life: 240,
  sound: false,
  theme: 'dark' as ThemeKey,
  nearby: true,
  wake: false,
  volume: 0.05,
  rain: true,
  rainOpacity: 70,
  rainSpeed: 700,
  rainPlaying: false,
  alerts: true,
  wind: false,
  windOpacity: 60,
  windSize: 2,
  windDensity: 2.5,
  windMode: 'dark',
  advRadar: false,
  advRadarLayer: 'bufr_phenomena,bufr_novosib_phenomena,bufr_vlad_phenomena',
  advRadarOpacity: 70,
  advRadarSpeed: 1000,
  advRadarVectors: false,
};

export type AppConfig = typeof DEFAULT_CONFIG;
