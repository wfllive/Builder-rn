export const ROOTFS_URL = 'https://github.com/wfllive/rootfs/releases/download/1.0/ubuntu-rootfs.tar.gz';
export const ROOTFS_NAME = 'Ubuntu arm64';
// Rai creates projects in ~/projects inside the Ubuntu rootfs (HOME=/root).
export const PROJECTS_ROOT = '/root/projects';

// Versions follow the current Android/Compose documentation (July 2026).
export const ANDROID_GRADLE_PLUGIN = '9.2.0';
export const GRADLE_VERSION = '9.4.1';
export const KOTLIN_VERSION = '2.3.21';
export const COMPOSE_BOM = '2026.06.00';
export const COMPILE_SDK = 37;
export const TARGET_SDK = 36;
export const MIN_SDK = 24;
export const JAVA_VERSION = 17;

export const slugifyProject = (name = '') => {
  const normalized = name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9а-яё]+/gi, '-')
    .replace(/^-+|-+$/g, '');
  const ascii = normalized
    .normalize('NFKD')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-');
  return ascii || `compose-app-${Date.now().toString(36)}`;
};

export const packageSegment = (value = '') => {
  const segment = slugifyProject(value).replace(/-/g, '').replace(/^[0-9]+/, '');
  return segment || 'application';
};

// Rai preserves the user-facing project name in ~/projects (including case).
export const getProjectDir = (project) => project?.projectDir || `${PROJECTS_ROOT}/${project?.name || project?.slug || slugifyProject(project?.name)}`;
export const getSourceRoot = (project) => `app/src/main/java/${String(project?.packageName || 'com.rnstudio.application').replace(/\./g, '/')}`;
export const getDebugApk = () => 'app/build/outputs/apk/debug/app-debug.apk';
export const getReleaseApk = () => 'app/build/outputs/apk/release/app-release-unsigned.apk';
export const getReleaseBundle = () => 'app/build/outputs/bundle/release/app-release.aab';
