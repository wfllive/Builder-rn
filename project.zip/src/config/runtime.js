export const ROOTFS_URL = 'https://github.com/wfllive/rootfs/releases/download/1.0/ubuntu-rootfs.tar.gz';
export const ROOTFS_NAME = 'Ubuntu arm64';
export const EXPO_SDK = '57';
export const EXPO_TEMPLATE = 'default@sdk-57';
export const PROJECTS_ROOT = '/root/projects';

export const slugifyProject = (name = '') => {
  const normalized = name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9а-яё]+/gi, '-')
    .replace(/^-+|-+$/g, '');
  const ascii = normalized
    .normalize('NFKD')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-');
  return ascii || `expo-app-${Date.now().toString(36)}`;
};

export const getProjectDir = (project) => project?.projectDir || `${PROJECTS_ROOT}/${project?.slug || slugifyProject(project?.name)}`;
