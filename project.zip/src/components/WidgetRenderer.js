import React, { useMemo, useRef } from 'react';
import { PanResponder, Pressable, StyleSheet, Text, View } from 'react-native';
import { Icon } from './Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';

const dimension = (value, fallback) => {
  if (value === 'match_parent') return '100%';
  if (value === 'wrap_content' || value == null) return fallback;
  return value;
};

const WidgetRenderer = ({
  component,
  onSelect,
  onEdit,
  onRegisterDropZone,
  onComponentDragStart,
  onComponentDragMove,
  onComponentDrop,
  dropTargetId,
  depth = 0,
}) => {
  const { selectedComponentId } = useProject();
  const { colors } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const viewRef = useRef(null);
  if (!component) return null;
  const p = component.props || {};
  const selected = selectedComponentId === component.id;
  const container = ['Column', 'Row', 'Box', 'LazyColumn', 'Card', 'ElevatedCard', 'Scaffold'].includes(component.type);
  const isDropTarget = dropTargetId === component.id;

  const measure = () => {
    if (!container) return;
    requestAnimationFrame(() => viewRef.current?.measureInWindow?.((x, y, width, height) => {
      onRegisterDropZone?.(component.id, { x, y, width, height, depth });
    }));
  };

  const dragResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: (event, gesture) => onComponentDragStart?.(component.id, { x: gesture.x0, y: gesture.y0 }),
    onPanResponderMove: (event, gesture) => onComponentDragMove?.(component.id, { x: gesture.moveX, y: gesture.moveY }),
    onPanResponderRelease: (event, gesture) => onComponentDrop?.(component.id, { x: gesture.moveX, y: gesture.moveY }),
    onPanResponderTerminate: () => onComponentDrop?.(component.id, null),
  }), [component.id, onComponentDragStart, onComponentDragMove, onComponentDrop]);

  const childProps = {
    onSelect, onEdit, onRegisterDropZone, onComponentDragStart, onComponentDragMove,
    onComponentDrop, dropTargetId,
  };
  const children = () => component.children?.length
    ? component.children.map((child) => <WidgetRenderer key={child.id} component={child} depth={depth + 1} {...childProps} />)
    : <View style={styles.placeholder}><Icon name="add-outline" size={14} color={colors.textTertiary} /><Text style={styles.placeholderText}>Drop components here</Text></View>;

  const render = () => {
    switch (component.type) {
      case 'Column':
        return <View style={{ minHeight: depth ? 45 : 420, width: dimension(p.width, undefined), padding: p.padding ?? 8, flexDirection: 'column', gap: 4, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'Row':
        return <View style={{ minHeight: 45, width: dimension(p.width, undefined), padding: p.padding ?? 8, flexDirection: 'row', alignItems: 'center', gap: Number(p.spacing) || 8, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'Box':
        return <View style={{ minHeight: 60, width: dimension(p.width, undefined), padding: p.padding ?? 8, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'LazyColumn':
        return <View style={[styles.containerPreview, { minHeight: Number(p.height) || 90, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }]}>{children()}</View>;
      case 'Card':
        return <View style={[styles.card, { padding: p.padding ?? 14, borderRadius: p.borderRadius ?? 12, backgroundColor: p.backgroundColor || '#FFFFFF' }]}>{children()}</View>;
      case 'ElevatedCard':
        return <View style={[styles.elevatedCard, { padding: p.padding ?? 14, borderRadius: p.borderRadius ?? 12, backgroundColor: p.backgroundColor || '#FFFFFF' }]}>{children()}</View>;
      case 'Scaffold':
        return (
          <View style={{ flex: 1, minHeight: depth ? 60 : 400, backgroundColor: p.backgroundColor || '#F8FAFC' }}>
            {p.topBar ? (
              <View style={styles.scaffoldTopBar}>
                <Text style={styles.scaffoldTopBarTitle}>{p.topBar.props?.title || 'MyApp'}</Text>
              </View>
            ) : null}
            <View style={{ flex: 1, padding: 8 }}>
              {children()}
            </View>
          </View>
        );
      case 'Text':
        return <Text style={{ width: dimension(p.width, undefined), padding: p.padding ?? 4, fontSize: Number(p.textSize) || 16, color: p.textColor || '#111827', fontWeight: p.textStyle === 'bold' ? '700' : '400', fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal', textAlign: p.textAlign === 'center' ? 'center' : p.textAlign === 'end' ? 'right' : 'left' }}>{p.text || 'Text'}</Text>;
      case 'Button': {
        const btnText = p.text || component.children?.find(c => c.type === 'Text')?.props?.text || 'Button';
        return <View style={[styles.button, { width: dimension(p.width, undefined), padding: p.padding ?? 12, borderRadius: p.borderRadius ?? 9, backgroundColor: p.backgroundColor || '#4F46E5' }]}><Text style={{ color: p.textColor || '#FFFFFF', fontSize: Number(p.textSize) || 15, fontWeight: '700' }}>{btnText}</Text></View>;
      }
      case 'OutlinedButton': {
        const btnText = p.text || component.children?.find(c => c.type === 'Text')?.props?.text || 'OutlinedButton';
        return <View style={[styles.outlinedButton, { width: dimension(p.width, undefined), padding: p.padding ?? 12, borderRadius: p.borderRadius ?? 9 }]}><Text style={{ color: p.textColor || '#4F46E5', fontSize: Number(p.textSize) || 15, fontWeight: '700' }}>{btnText}</Text></View>;
      }
      case 'OutlinedTextField':
        return <View style={[styles.input, { width: dimension(p.width, '100%'), padding: p.padding ?? 12, borderRadius: p.borderRadius ?? 9, backgroundColor: p.backgroundColor || '#FFFFFF' }]}><Text style={{ color: p.text ? p.textColor || '#111827' : '#6B7280', fontSize: Number(p.textSize) || 15 }}>{p.text || p.hint || 'Input'}</Text></View>;
      case 'Image':
        return <View style={[styles.media, { width: dimension(p.width, 110), height: dimension(p.height, 110), borderRadius: p.borderRadius || 8, backgroundColor: p.backgroundColor || '#E5E7EB' }]}><Icon name="image-outline" size={32} color="#64748B" /><Text style={styles.mediaLabel}>Image</Text></View>;
      case 'Checkbox':
        return <View style={styles.row}><Icon name={p.checked ? 'checkbox' : 'square-outline'} size={22} color={p.checked ? '#4F46E5' : '#64748B'} /><Text style={{ color: p.textColor || '#111827', fontSize: Number(p.textSize) || 15 }}>{p.text || 'Checkbox'}</Text></View>;
      case 'Switch':
        return <View style={styles.row}><Text style={{ color: p.textColor || '#111827', fontSize: 15, flex: 1 }}>{p.text || 'Switch'}</Text><View style={[styles.switchTrack, { backgroundColor: p.checked ? '#4F46E5' : '#94A3B8' }]}><View style={[styles.switchKnob, p.checked && { alignSelf: 'flex-end' }]} /></View></View>;
      case 'LinearProgressIndicator':
        return <View style={styles.progress}><View style={{ width: `${Math.min(100, (Number(p.progress) || 0) <= 1 ? (Number(p.progress) || 0) * 100 : Number(p.progress) || 0)}%`, height: '100%', borderRadius: 4, backgroundColor: p.color || '#4F46E5' }} /></View>;
      case 'CircularProgressIndicator':
        return <View style={[styles.circular, { width: Number(p.width) || 48, height: Number(p.height) || 48, borderColor: p.color || '#4F46E5' }]} />;
      case 'HorizontalDivider':
        return <View style={{ height: Number(p.height) || 1, backgroundColor: p.color || '#CBD5E1', marginVertical: Number(p.margin) || 8 }} />;
      case 'Spacer':
        return <View style={[styles.spacer, { height: Number(p.height) || 16 }]}><Text style={styles.spacerText}>Spacer · {Number(p.height) || 16}</Text></View>;
      case 'WebView':
        return <View style={[styles.embed, { height: Number(p.height) || 180 }]}><Icon name="globe-outline" size={30} color="#0E7490" /><Text style={styles.embedTitle}>WebView</Text><Text style={styles.embedText} numberOfLines={1}>{p.url}</Text></View>;
      case 'Icon':
        return <View style={styles.iconPreview}><Icon name="star-outline" size={Number(p.size) || 28} color={p.tint || '#4F46E5'} /><Text style={styles.embedText}>{p.iconName || 'Favorite'}</Text></View>;
      default:
        return <View style={styles.unknown}><Icon name="cube-outline" size={16} color={colors.textSecondary} /><Text style={{ color: colors.textSecondary }}>{component.type}</Text></View>;
    }
  };

  return (
    <Pressable
      ref={viewRef}
      collapsable={false}
      onLayout={measure}
      onPress={(event) => { event.stopPropagation?.(); onSelect?.(component.id); }}
      style={[
        styles.wrapper,
        container && styles.containerBoundary,
        selected && styles.selected,
        isDropTarget && styles.dropTarget,
      ]}
    >
      {selected ? (
        <View style={styles.selectionTools}>
          <View style={styles.selectionName}><Text style={styles.selectionNameText}>{component.type}</Text></View>
          <Pressable onPress={(event) => { event.stopPropagation?.(); onEdit?.(component.id); }} style={styles.selectionButton}>
            <Icon name="create-outline" size={12} color="#FFFFFF" />
          </Pressable>
          {depth > 0 ? (
            <View {...dragResponder.panHandlers} style={styles.selectionButton}>
              <Icon name="move-outline" size={13} color="#FFFFFF" />
            </View>
          ) : null}
        </View>
      ) : null}
      {render()}
    </Pressable>
  );
};

const createStyles = (c) => StyleSheet.create({
  wrapper: { position: 'relative', borderWidth: 1, borderColor: 'transparent', borderRadius: 5, marginVertical: 2 },
  containerBoundary: { borderColor: '#94A3B866', borderStyle: 'dashed' },
  selected: { borderWidth: 2, borderColor: c.selectionBorder, backgroundColor: c.selection },
  dropTarget: { borderWidth: 2, borderColor: c.success, backgroundColor: c.successBg },
  selectionTools: { position: 'absolute', top: -23, left: -2, right: -2, zIndex: 30, height: 22, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 3 },
  selectionName: { height: 21, maxWidth: 120, marginRight: 'auto', paddingHorizontal: 6, justifyContent: 'center', borderRadius: 4, backgroundColor: c.primary },
  selectionNameText: { color: '#FFFFFF', fontSize: 8, fontWeight: '750', fontFamily: 'monospace' },
  selectionButton: { width: 22, height: 22, borderRadius: 5, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary },
  placeholder: { minHeight: 38, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 4 },
  placeholderText: { color: c.textTertiary, fontSize: 9 },
  containerPreview: { padding: 8, borderRadius: 6 },
  card: { marginVertical: 4, borderWidth: 1, borderColor: '#D8DEE8', shadowColor: '#000000', shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  elevatedCard: { marginVertical: 4, borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 12, shadowColor: '#000000', shadowOpacity: 0.12, shadowRadius: 6, elevation: 3, backgroundColor: '#FFFFFF' },
  scaffoldTopBar: { height: 56, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', backgroundColor: '#4F46E5', shadowColor: '#000000', shadowOpacity: 0.15, shadowRadius: 4, elevation: 4 },
  scaffoldTopBarTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: '700' },
  button: { minHeight: 42, alignItems: 'center', justifyContent: 'center', marginVertical: 4, paddingHorizontal: 16 },
  outlinedButton: { minHeight: 42, alignItems: 'center', justifyContent: 'center', marginVertical: 4, paddingHorizontal: 16, borderWidth: 1, borderColor: '#4F46E5', backgroundColor: 'transparent' },
  input: { minHeight: 44, justifyContent: 'center', marginVertical: 4, borderWidth: 1, borderColor: '#CBD5E1' },
  media: { alignItems: 'center', justifyContent: 'center', gap: 4, marginVertical: 4 },
  mediaLabel: { color: '#64748B', fontSize: 10 },
  row: { minHeight: 40, flexDirection: 'row', alignItems: 'center', gap: 9, paddingVertical: 5 },
  switchTrack: { width: 44, height: 24, borderRadius: 12, padding: 3, justifyContent: 'center' },
  switchKnob: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#FFFFFF' },
  progress: { width: '100%', height: 8, borderRadius: 4, overflow: 'hidden', backgroundColor: '#E2E8F0', marginVertical: 9 },
  circular: { borderWidth: 5, borderRadius: 999, borderTopColor: 'transparent', marginVertical: 6 },
  iconPreview: { minHeight: 52, alignItems: 'center', justifyContent: 'center', gap: 3 },
  spacer: { borderWidth: 1, borderColor: '#94A3B8', borderStyle: 'dashed', justifyContent: 'center' },
  spacerText: { color: '#64748B', fontSize: 8, textAlign: 'center' },
  embed: { width: '100%', backgroundColor: '#E8F1F5', borderRadius: 8, alignItems: 'center', justifyContent: 'center', gap: 4, marginVertical: 4 },
  embedTitle: { color: '#334155', fontSize: 12, fontWeight: '700' },
  embedText: { color: '#64748B', fontSize: 9, maxWidth: '80%' },
  unknown: { minHeight: 38, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, backgroundColor: c.bgElevated },
});

export default WidgetRenderer;
