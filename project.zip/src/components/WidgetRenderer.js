import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import colors from '../theme/colors';

const WidgetRenderer = ({ component, isSelected, onSelect, depth = 0 }) => {
  if (!component) return null;

  const props = component.props || {};
  const isContainer = ['LinearLayout', 'ScrollView', 'CardView'].includes(component.type);
  
  const handlePress = (e) => {
    if (e && e.stopPropagation) e.stopPropagation();
    onSelect(component.id);
  };

  const renderWidget = () => {
    switch (component.type) {
      case 'LinearLayout':
        return (
          <View style={[
            widgetStyles.linearLayout,
            {
              flexDirection: props.orientation === 'horizontal' ? 'row' : 'column',
              padding: props.padding || 8,
              backgroundColor: props.backgroundColor !== 'transparent' ? props.backgroundColor : undefined,
              minHeight: 40,
            },
          ]}>
            {component.children && component.children.length > 0 ? (
              component.children.map(child => (
                <WidgetRenderer
                  key={child.id}
                  component={child}
                  isSelected={false}
                  onSelect={onSelect}
                  depth={depth + 1}
                />
              ))
            ) : (
              <Text style={widgetStyles.placeholder}>Пустой контейнер</Text>
            )}
          </View>
        );
      
      case 'ScrollView':
        return (
          <View style={[widgetStyles.scrollView, { padding: 8, minHeight: 60 }]}>
            {component.children && component.children.length > 0 ? (
              component.children.map(child => (
                <WidgetRenderer
                  key={child.id}
                  component={child}
                  isSelected={false}
                  onSelect={onSelect}
                  depth={depth + 1}
                />
              ))
            ) : (
              <Text style={widgetStyles.placeholder}>Scroll View</Text>
            )}
          </View>
        );
      
      case 'CardView':
        return (
          <View style={[
            widgetStyles.cardView,
            {
              padding: props.padding || 16,
              backgroundColor: props.backgroundColor || '#2C2C2C',
              borderRadius: props.borderRadius || 12,
              elevation: props.elevation || 4,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,
              marginVertical: 4,
            },
          ]}>
            {component.children && component.children.length > 0 ? (
              component.children.map(child => (
                <WidgetRenderer
                  key={child.id}
                  component={child}
                  isSelected={false}
                  onSelect={onSelect}
                  depth={depth + 1}
                />
              ))
            ) : (
              <Text style={widgetStyles.placeholder}>Card</Text>
            )}
          </View>
        );
      
      case 'TextView':
        return (
          <View style={{ padding: props.padding || 4, marginVertical: 2 }}>
            <Text style={{
              fontSize: props.textSize || 16,
              color: props.textColor || '#FFFFFF',
              fontWeight: props.textStyle === 'bold' ? 'bold' : 'normal',
              fontStyle: props.textStyle === 'italic' ? 'italic' : 'normal',
              textAlign: props.gravity || 'left',
            }}>
              {props.text || 'Text'}
            </Text>
          </View>
        );
      
      case 'Button':
        return (
          <View style={{
            backgroundColor: props.backgroundColor || '#BB86FC',
            padding: props.padding || 12,
            borderRadius: props.borderRadius || 8,
            alignItems: 'center',
            marginVertical: 4,
          }}>
            <Text style={{
              color: props.textColor || '#FFFFFF',
              fontSize: props.textSize || 16,
              fontWeight: 'bold',
            }}>
              {props.text || 'Button'}
            </Text>
          </View>
        );
      
      case 'EditText':
        return (
          <View style={{
            backgroundColor: props.backgroundColor || '#2C2C2C',
            padding: props.padding || 12,
            borderRadius: props.borderRadius || 8,
            marginVertical: 4,
            borderWidth: 1,
            borderColor: '#444',
          }}>
            <Text style={{
              color: props.text ? (props.textColor || '#FFFFFF') : '#888',
              fontSize: props.textSize || 16,
            }}>
              {props.text || props.hint || 'Input'}
            </Text>
          </View>
        );
      
      case 'ImageView':
        return (
          <View style={{
            width: props.width || 100,
            height: props.height || 100,
            backgroundColor: props.backgroundColor || '#333333',
            borderRadius: props.borderRadius || 0,
            justifyContent: 'center',
            alignItems: 'center',
            marginVertical: 4,
          }}>
            <Text style={{ color: '#666', fontSize: 24 }}>🖼</Text>
          </View>
        );
      
      case 'CheckBox':
        return (
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 4 }}>
            <View style={{
              width: 20,
              height: 20,
              borderWidth: 2,
              borderColor: '#BB86FC',
              borderRadius: 4,
              marginRight: 8,
              backgroundColor: props.checked ? '#BB86FC' : 'transparent',
            }} />
            <Text style={{ color: props.textColor || '#FFFFFF', fontSize: props.textSize || 16 }}>
              {props.text || 'CheckBox'}
            </Text>
          </View>
        );
      
      case 'Switch':
        return (
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 4 }}>
            <Text style={{ color: '#FFFFFF', fontSize: 16, marginRight: 8 }}>
              {props.text || 'Switch'}
            </Text>
            <View style={{
              width: 48,
              height: 24,
              borderRadius: 12,
              backgroundColor: props.checked ? '#BB86FC' : '#555',
              justifyContent: 'center',
              padding: 2,
            }}>
              <View style={{
                width: 20,
                height: 20,
                borderRadius: 10,
                backgroundColor: '#FFFFFF',
                alignSelf: props.checked ? 'flex-end' : 'flex-start',
              }} />
            </View>
          </View>
        );
      
      case 'ProgressBar':
        return (
          <View style={{
            height: 8,
            backgroundColor: '#333',
            borderRadius: 4,
            overflow: 'hidden',
            marginVertical: 8,
          }}>
            <View style={{
              height: '100%',
              width: `${props.progress || 50}%`,
              backgroundColor: props.color || '#BB86FC',
              borderRadius: 4,
            }} />
          </View>
        );
      
      case 'Divider':
        return (
          <View style={{
            height: props.height || 1,
            backgroundColor: props.backgroundColor || '#444444',
            margin: props.margin || 8,
          }} />
        );
      
      case 'Spacer':
        return (
          <View style={{
            height: props.height || 16,
            backgroundColor: 'rgba(187, 134, 252, 0.1)',
            borderWidth: 1,
            borderColor: 'rgba(187, 134, 252, 0.3)',
            borderStyle: 'dashed',
            marginVertical: 2,
          }}>
            <Text style={{ color: '#888', fontSize: 10, textAlign: 'center' }}>Spacer</Text>
          </View>
        );
      
      case 'WebView':
        return (
          <View style={{
            width: '100%',
            height: props.height || 200,
            backgroundColor: '#1a1a2e',
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
            marginVertical: 4,
          }}>
            <Text style={{ color: '#666', fontSize: 24 }}>🌐</Text>
            <Text style={{ color: '#888', fontSize: 12 }}>WebView</Text>
          </View>
        );
      
      case 'MapView':
        return (
          <View style={{
            width: '100%',
            height: props.height || 200,
            backgroundColor: '#1a3a2e',
            borderRadius: 4,
            justifyContent: 'center',
            alignItems: 'center',
            marginVertical: 4,
          }}>
            <Text style={{ color: '#666', fontSize: 24 }}>🗺</Text>
            <Text style={{ color: '#888', fontSize: 12 }}>Map View</Text>
          </View>
        );
      
      default:
        return (
          <View style={{ padding: 8, backgroundColor: '#333', borderRadius: 4 }}>
            <Text style={{ color: '#fff' }}>{component.type}</Text>
          </View>
        );
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.8}
      style={[
        styles.wrapper,
        isSelected && styles.selectedWrapper,
        isContainer && styles.containerWrapper,
      ]}
    >
      {isSelected && (
        <View style={styles.selectionLabel}>
          <Text style={styles.selectionLabelText}>{component.type}</Text>
        </View>
      )}
      {renderWidget()}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    borderWidth: 1,
    borderColor: 'transparent',
    borderRadius: 4,
    marginVertical: 1,
  },
  selectedWrapper: {
    borderColor: colors.selectionBorder,
    borderWidth: 2,
    backgroundColor: colors.selection,
  },
  containerWrapper: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    borderStyle: 'dashed',
  },
  selectionLabel: {
    position: 'absolute',
    top: -18,
    left: 0,
    backgroundColor: colors.primary,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 4,
    zIndex: 10,
  },
  selectionLabelText: {
    color: colors.onPrimary,
    fontSize: 10,
    fontWeight: 'bold',
  },
});

const widgetStyles = StyleSheet.create({
  linearLayout: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    borderStyle: 'dashed',
    borderRadius: 4,
    marginVertical: 2,
  },
  scrollView: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    borderStyle: 'dotted',
    borderRadius: 4,
    marginVertical: 2,
  },
  cardView: {
    marginVertical: 4,
  },
  placeholder: {
    color: 'rgba(255,255,255,0.3)',
    fontSize: 12,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default WidgetRenderer;
