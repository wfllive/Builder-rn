import React, { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Icon } from './Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';

const dimension = (value, fallback) => {
  if (value === 'match_parent') return '100%';
  if (value === 'wrap_content' || value == null) return fallback;
  return value;
};

const WidgetRenderer = ({ component, onSelect, depth = 0 }) => {
  const { selectedComponentId } = useProject();
  const { colors } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  if (!component) return null;
  const p = component.props || {};
  const selected = selectedComponentId === component.id;
  const container = ['LinearLayout', 'ScrollView', 'CardView'].includes(component.type);

  const children = () => component.children?.length
    ? component.children.map((child) => <WidgetRenderer key={child.id} component={child} onSelect={onSelect} depth={depth + 1} />)
    : <View style={styles.placeholder}><Icon name="add-outline" size={14} color={colors.textTertiary} /><Text style={styles.placeholderText}>Drop components here</Text></View>;

  const render = () => {
    switch (component.type) {
      case 'LinearLayout':
        return <View style={{ minHeight: depth ? 45 : 420, width: dimension(p.width, undefined), padding: p.padding ?? 8, flexDirection: p.orientation === 'horizontal' ? 'row' : 'column', gap: 4, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'ScrollView':
        return <View style={[styles.containerPreview, { minHeight: Number(p.height) || 90, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }]}>{children()}</View>;
      case 'CardView':
        return <View style={[styles.card, { padding: p.padding ?? 14, borderRadius: p.borderRadius ?? 12, backgroundColor: p.backgroundColor || colors.bgCard }]}>{children()}</View>;
      case 'TextView':
        return <Text style={{ width: dimension(p.width, undefined), padding: p.padding ?? 4, fontSize: Number(p.textSize) || 16, color: p.textColor || '#111827', fontWeight: p.textStyle === 'bold' ? '700' : '400', fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal', textAlign: p.gravity || 'left' }}>{p.text || 'Text'}</Text>;
      case 'Button':
        return <View style={[styles.button, { width: dimension(p.width, undefined), padding: p.padding ?? 12, borderRadius: p.borderRadius ?? 9, backgroundColor: p.backgroundColor || '#4F46E5' }]}><Text style={{ color: p.textColor || '#FFFFFF', fontSize: Number(p.textSize) || 15, fontWeight: '700' }}>{p.text || 'Button'}</Text></View>;
      case 'EditText':
        return <View style={[styles.input, { width: dimension(p.width, '100%'), padding: p.padding ?? 12, borderRadius: p.borderRadius ?? 9, backgroundColor: p.backgroundColor || '#FFFFFF' }]}><Text style={{ color: p.text ? p.textColor || '#111827' : '#6B7280', fontSize: Number(p.textSize) || 15 }}>{p.text || p.hint || 'Input'}</Text></View>;
      case 'ImageView':
        return <View style={[styles.media, { width: dimension(p.width, 110), height: dimension(p.height, 110), borderRadius: p.borderRadius || 8, backgroundColor: p.backgroundColor || '#E5E7EB' }]}><Icon name="image-outline" size={32} color="#64748B" /><Text style={styles.mediaLabel}>Image</Text></View>;
      case 'CheckBox':
        return <View style={styles.row}><Icon name={p.checked ? 'checkbox' : 'square-outline'} size={22} color={p.checked ? '#4F46E5' : '#64748B'} /><Text style={{ color: p.textColor || '#111827', fontSize: Number(p.textSize) || 15 }}>{p.text || 'Checkbox'}</Text></View>;
      case 'Switch':
        return <View style={styles.row}><Text style={{ color: p.textColor || '#111827', fontSize: 15, flex: 1 }}>{p.text || 'Switch'}</Text><View style={[styles.switchTrack, { backgroundColor: p.checked ? '#4F46E5' : '#94A3B8' }]}><View style={[styles.switchKnob, p.checked && { alignSelf: 'flex-end' }]} /></View></View>;
      case 'ProgressBar':
        return <View style={styles.progress}><View style={{ width: `${Math.min(100, Number(p.progress) || 0)}%`, height: '100%', borderRadius: 4, backgroundColor: p.color || '#4F46E5' }} /></View>;
      case 'Divider':
        return <View style={{ height: Number(p.height) || 1, backgroundColor: p.backgroundColor || '#CBD5E1', marginVertical: Number(p.margin) || 8 }} />;
      case 'Spacer':
        return <View style={[styles.spacer, { height: Number(p.height) || 16 }]}><Text style={styles.spacerText}>Spacer · {Number(p.height) || 16}</Text></View>;
      case 'WebView':
        return <View style={[styles.embed, { height: Number(p.height) || 180 }]}><Icon name="globe-outline" size={30} color="#0E7490" /><Text style={styles.embedTitle}>WebView</Text><Text style={styles.embedText} numberOfLines={1}>{p.url}</Text></View>;
      case 'MapView':
        return <View style={[styles.embed, { height: Number(p.height) || 180, backgroundColor: '#E8F3EE' }]}><Icon name="map-outline" size={30} color="#047857" /><Text style={styles.embedTitle}>Map</Text><Text style={styles.embedText}>{p.latitude}, {p.longitude}</Text></View>;
      default:
        return <View style={styles.unknown}><Icon name="cube-outline" size={16} color={colors.textSecondary} /><Text style={{ color: colors.textSecondary }}>{component.type}</Text></View>;
    }
  };

  return (
    <Pressable
      onPress={(event) => { event.stopPropagation?.(); onSelect?.(component.id); }}
      style={[
        styles.wrapper,
        container && styles.containerBoundary,
        selected && styles.selected,
      ]}
    >
      {selected ? <View style={styles.selectionTag}><Text style={styles.selectionTagText}>{component.type}</Text></View> : null}
      {render()}
    </Pressable>
  );
};

const createStyles = (c) => StyleSheet.create({
  wrapper: { position: 'relative', borderWidth: 1, borderColor: 'transparent', borderRadius: 5, marginVertical: 2 },
  containerBoundary: { borderColor: '#94A3B866', borderStyle: 'dashed' },
  selected: { borderWidth: 2, borderColor: c.selectionBorder, backgroundColor: c.selection },
  selectionTag: { position: 'absolute', top: -17, left: -2, zIndex: 20, backgroundColor: c.primary, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  selectionTagText: { color: '#FFFFFF', fontSize: 8, fontWeight: '750', fontFamily: 'monospace' },
  placeholder: { minHeight: 38, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 4 },
  placeholderText: { color: c.textTertiary, fontSize: 9 },
  containerPreview: { padding: 8, borderRadius: 6 },
  card: { marginVertical: 4, borderWidth: 1, borderColor: '#D8DEE8', shadowColor: '#000000', shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  button: { minHeight: 42, alignItems: 'center', justifyContent: 'center', marginVertical: 4, paddingHorizontal: 16 },
  input: { minHeight: 44, justifyContent: 'center', marginVertical: 4, borderWidth: 1, borderColor: '#CBD5E1' },
  media: { alignItems: 'center', justifyContent: 'center', gap: 4, marginVertical: 4 },
  mediaLabel: { color: '#64748B', fontSize: 10 },
  row: { minHeight: 40, flexDirection: 'row', alignItems: 'center', gap: 9, paddingVertical: 5 },
  switchTrack: { width: 44, height: 24, borderRadius: 12, padding: 3, justifyContent: 'center' },
  switchKnob: { width: 18, height: 18, borderRadius: 9, backgroundColor: '#FFFFFF' },
  progress: { width: '100%', height: 8, borderRadius: 4, overflow: 'hidden', backgroundColor: '#E2E8F0', marginVertical: 9 },
  spacer: { borderWidth: 1, borderColor: '#94A3B8', borderStyle: 'dashed', justifyContent: 'center' },
  spacerText: { color: '#64748B', fontSize: 8, textAlign: 'center' },
  embed: { width: '100%', backgroundColor: '#E8F1F5', borderRadius: 8, alignItems: 'center', justifyContent: 'center', gap: 4, marginVertical: 4 },
  embedTitle: { color: '#334155', fontSize: 12, fontWeight: '700' },
  embedText: { color: '#64748B', fontSize: 9, maxWidth: '80%' },
  unknown: { minHeight: 38, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, backgroundColor: c.bgElevated },
});

export default WidgetRenderer;
