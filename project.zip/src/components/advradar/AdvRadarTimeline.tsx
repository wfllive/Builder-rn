import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';

export function AdvRadarTimeline({ times, currentIndex, isPlaying, onPrev, onNext, onTogglePlay, onSeek, bottomOffset, visible }: any) {
  if (!visible || !times?.length) return null;
  const t = times[currentIndex];
  return (
    <View style={[styles.wrap, { bottom: bottomOffset ?? 70 }]}>
      <View style={styles.row}>
        <Pressable onPress={onPrev} style={styles.btn}><Text style={styles.btnT}>⏮</Text></Pressable>
        <Pressable onPress={onTogglePlay} style={[styles.btn, styles.play]}>
          <Text style={styles.btnT}>{isPlaying ? '⏸' : '▶️'}</Text>
        </Pressable>
        <Pressable onPress={onNext} style={styles.btn}><Text style={styles.btnT}>⏭</Text></Pressable>
        <Text style={styles.time}>
          {t ? new Date(t).toLocaleString('ru-RU', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' }) : '--'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position:'absolute', left:12, right:12, zIndex:46, backgroundColor:'rgba(8,13,26,0.9)', borderRadius:14, padding:10, borderWidth:1, borderColor:'rgba(255,255,255,0.07)' },
  row: { flexDirection:'row', alignItems:'center', gap:10 },
  btn: { paddingHorizontal:12, paddingVertical:8, backgroundColor:'#1e293b', borderRadius:10 },
  play: { backgroundColor:'#4f46e5' },
  btnT: { color:'#fff', fontSize:16, fontWeight:'700' },
  time: { color:'#e5e7eb', marginLeft:'auto', fontSize:12 },
});
