import React, { ReactNode } from 'react';
import { View, Text, StyleSheet, ViewStyle, Pressable } from 'react-native';
import { theme } from '../utils/theme';

export function Card({ children, style, onPress }: { children: ReactNode; style?: ViewStyle; onPress?: () => void }) {
  const Wrap: any = onPress ? Pressable : View;
  return <Wrap onPress={onPress} style={[styles.card, style]}>{children}</Wrap>;
}

export function EmptyState({ icon, title, subtitle }: { icon: string; title: string; subtitle?: string }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 60, paddingHorizontal: 32 }}>
      <Text style={{ fontSize: 64, marginBottom: 12 }}>{icon}</Text>
      <Text style={styles.title}>{title}</Text>
      {subtitle && <Text style={styles.muted}>{subtitle}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.bgCard,
    borderRadius: theme.radius.lg,
    padding: 16,
    borderWidth: 1,
    borderColor: theme.border,
  },
  title: {
    color: theme.text,
    fontSize: 16,
    fontFamily: theme.font.mono,
    fontWeight: '700',
    textAlign: 'center',
  },
  muted: {
    color: theme.textDim,
    fontSize: 12,
    fontFamily: theme.font.mono,
    textAlign: 'center',
    marginTop: 4,
  },
});
