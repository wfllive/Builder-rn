import { getProjectDir } from '../config/runtime';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { Icon } from './Icon';
import { IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill } from './AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { generateComposePreviewSource, syncComposeProject } from '../utils/composeProject';
import { raiBuild } from '../utils/rai';
import * as apt from '../../modules/apt-manager/src/index';



const ComposePreviewPanel = ({ onOpenFullscreen, onOpenBuild }) => {
  const { currentProject, currentScreenId, getCurrentScreen, addWorkspaceLog } = useProject();
  const { colors, language, resolvedTheme } = useAppSettings();
  const screen = getCurrentScreen();
  const [tab, setTab] = useState('preview');
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState('');
  const [built, setBuilt] = useState(false);
  const [previewScale, setPreviewScale] = useState(1.0);
  const [deviceMode, setDeviceMode] = useState('phone'); // phone | tablet
  // Light / Dark preview override. 'auto' follows the project's theme (then the IDE).
  const [previewTheme, setPreviewTheme] = useState('auto'); // auto | light | dark

  const styles = useMemo(() => createStyles(colors), [colors]);
  const screenIndex = currentProject?.screens?.findIndex((item) => item.id === currentScreenId) || 0;

  // Effective preview theme (independent of the IDE's own UI theme).
  const previewDark = previewTheme === 'dark'
    ? true
    : previewTheme === 'light'
      ? false
      : currentProject?.theme?.isDark === true || resolvedTheme === 'dark';
  const previewBg = screen?.backgroundColor || (previewDark ? '#141218' : '#FFFBFE');

  const source = useMemo(() => {
    if (!currentProject || !screen) return '';
    if (screen.source != null && screen.source !== '') return screen.source;
    return generateComposePreviewSource(currentProject, screen, screenIndex);
  }, [currentProject, screen, screenIndex]);

  const deviceWidth = deviceMode === 'tablet' ? 600 : 360;
  const deviceHeight = deviceMode === 'tablet' ? 840 : 740;
  const effectiveScale = Math.max(0.6, Math.min(1.35, previewScale));

  // primary is now supplied by the real Compose renderer (no fake RN chrome)

  const copy = language === 'ru' ? {
    title: 'Предпросмотр React',
    subtitle: 'Локальный Vite dev-сервер через WebView',
    visual: 'Preview',
    code: 'JSX-код',
    sync: 'Сохранить JSX',
    build: 'Собрать Debug APK',
    install: 'Установить APK',
    launch: 'Открыть приложение',
    fullscreen: 'На весь экран',
    previewInfo: 'Локальный Vite dev-сервер (yarn dev) загружен в WebView. Вы видите актуальный React-превью без сборки APK.',
    idle: 'Готов',
    building: 'Gradle работает',
    success: 'Debug APK готов',
    output: 'Gradle output',
  } : {
    title: 'React Preview',
    subtitle: 'Local Vite dev server via WebView',
    visual: 'Preview',
    code: 'JSX code',
    sync: 'Save JSX',
    build: 'Build Debug APK',
    install: 'Install APK',
    launch: 'Open app',
    fullscreen: 'Full screen',
    previewInfo: 'Local Vite dev server (yarn dev) loaded in WebView. You see the actual React preview without building an APK.',
    idle: 'Ready',
    building: 'Gradle is running',
    success: 'Debug APK ready',
    output: 'Gradle output',
  };

  const sync = async () => {
    const result = await syncComposeProject(currentProject);
    setLog(result.output || '');
    addWorkspaceLog(result.output || 'JSX files synchronized', result.success ? 'success' : 'error');
    return result;
  };

  const build = async () => {
    setRunning(true);
    setBuilt(false);
    setLog('$ rai build ' + currentProject.name + '\n');
    try {
      const result = await raiBuild(currentProject, null, getProjectDir(currentProject));
      setLog(result.output || '');
      setBuilt(Boolean(result.success));
      addWorkspaceLog(result.success ? 'Debug APK assembled' : result.output, result.success ? 'success' : 'error');
    } catch (error) {
      setLog(error?.message || String(error));
    } finally {
      setRunning(false);
    }
  };

  const install = async () => {
    const projectName = currentProject?.name;
    if (!projectName) {
      setLog((current) => `${current}\nNo project is open.`);
      return;
    }
    setLog((current) => `${current}\n$ install ${projectName}/android/app/build/outputs/apk/debug/app-debug.apk`);
    const result = await apt.installApk?.(`${getProjectDir(currentProject)}/android/app/build/outputs/apk/debug/app-debug.apk`);
    setLog((current) => `${current}\n${result?.success ? 'Android package installer opened' : result?.output || 'APK install unavailable.'}`);
  };

  const launch = async () => {
    const result = await apt.launchPackage?.(`${currentProject.packageName}.debug`);
    if (!result?.success) setLog((current) => `${current}\n${result?.output || 'Install the Debug APK first.'}`);
  };

  if (!screen) return null;

  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <View style={styles.headerIcon}>
          <Icon name="logo-android" size={21} color={colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.title}>{copy.title}</Text>
          <Text style={styles.subtitle} numberOfLines={1}>{copy.subtitle}</Text>
        </View>

        {/* Professional controls */}
        <View style={styles.deviceControls}>
          {/* Light / Dark / Auto preview theme toggle */}
          <View style={styles.themeControl}>
            {[
              { mode: 'auto', icon: 'contrast-outline', label: language === 'ru' ? 'Авто' : 'Auto' },
              { mode: 'light', icon: 'sunny-outline', label: 'Light' },
              { mode: 'dark', icon: 'moon-outline', label: 'Dark' },
            ].map(({ mode, icon, label }) => {
              const active = previewTheme === mode;
              return (
                <Pressable
                  key={mode}
                  onPress={() => setPreviewTheme(mode)}
                  style={[styles.deviceChip, active && styles.deviceChipActive]}
                  accessibilityLabel={`${label} preview theme`}
                >
                  <Icon name={icon} size={14} color={active ? '#fff' : colors.text} />
                  <Text style={[styles.deviceChipText, active && { color: '#fff' }]}>{label}</Text>
                </Pressable>
              );
            })}
          </View>

          <Pressable
            onPress={() => setDeviceMode(deviceMode === 'phone' ? 'tablet' : 'phone')}
            style={[styles.deviceChip, deviceMode === 'tablet' && styles.deviceChipActive]}
          >
            <Icon
              name={deviceMode === 'tablet' ? 'tablet-portrait-outline' : 'phone-portrait-outline'}
              size={15}
              color={deviceMode === 'tablet' ? '#fff' : colors.text}
            />
            <Text style={[styles.deviceChipText, deviceMode === 'tablet' && { color: '#fff' }]}>
              {deviceMode === 'tablet' ? 'Tablet' : 'Phone'}
            </Text>
          </Pressable>

          <View style={styles.scaleControl}>
            <IconButton name="remove-outline" size={13} onPress={() => setPreviewScale(s => Math.max(0.65, s - 0.1))} />
            <Text style={styles.scaleText}>{Math.round(effectiveScale * 100)}%</Text>
            <IconButton name="add-outline" size={13} onPress={() => setPreviewScale(s => Math.min(1.35, s + 0.1))} />
          </View>
        </View>

        <StatusPill
          label={running ? copy.building : built ? copy.success : copy.idle}
          tone={running ? 'info' : built ? 'success' : 'neutral'}
        />
        <IconButton name="expand-outline" onPress={onOpenFullscreen} />
      </View>

      <View style={styles.tabBar}>
        <SegmentedControl
          compact
          value={tab}
          onChange={setTab}
          options={[
            { value: 'preview', label: copy.visual, icon: 'phone-portrait-outline' },
            { value: 'code', label: copy.code, icon: 'code-slash-outline' },
          ]}
        />
      </View>

      {tab === 'preview' ? (
        <ScrollView contentContainerStyle={styles.previewPage}>
          {/* Professional device frame with real Compose rendering */}
          <View
            style={[
              styles.device,
              {
                width: deviceWidth + 20,
                height: deviceHeight + 72,
                transform: [{ scale: effectiveScale }],
                alignSelf: 'center',
              },
            ]}
          >
            <View style={styles.systemBar}>
              <Text style={styles.time}>9:41</Text>
              <Icon name="battery-full" size={14} color="#111827" />
            </View>

            {/* WebView loads the local Vite dev server for React preview */}

            <View style={[styles.body, { backgroundColor: previewBg }]}>
              <WebView
                source={{ uri: 'http://localhost:5173' }}
                style={{ flex: 1, width: '100%', height: '100%' }}
                javaScriptEnabled
                domStorageEnabled
                originWhitelist={['*']}
                startInLoadingState
                scalesPageToFit
              />
            </View>

            <View style={styles.navBar}>
              <View style={styles.gesture} />
            </View>
          </View>

          <View style={styles.deviceMeta}>
            <View style={styles.deviceMetaChip}>
              <Icon name="phone-portrait-outline" size={11} color={colors.textSecondary} />
              <Text style={styles.deviceMetaText}>{deviceWidth}×{deviceHeight} dp</Text>
            </View>
            <View style={styles.deviceMetaChip}>
              <Icon
                name={previewDark ? 'moon-outline' : 'sunny-outline'}
                size={11}
                color={colors.textSecondary}
              />
              <Text style={styles.deviceMetaText}>{previewDark ? 'Dark' : 'Light'}</Text>
            </View>
            <View style={styles.deviceMetaChip}>
              <Icon name="resize-outline" size={11} color={colors.textSecondary} />
              <Text style={styles.deviceMetaText}>{Math.round(effectiveScale * 100)}%</Text>
            </View>
            {previewTheme === 'auto' ? (
              <View style={styles.deviceMetaChip}>
                <Icon name="contrast-outline" size={11} color={colors.textSecondary} />
                <Text style={styles.deviceMetaText}>{language === 'ru' ? 'Авто' : 'Auto'}</Text>
              </View>
            ) : null}
          </View>

          <SectionCard style={styles.controls} title="React Preview" icon="globe-outline">
            <Text style={styles.info}>{copy.previewInfo}</Text>

            <View style={styles.actions}>
              <IconButton name="save-outline" label={copy.sync} onPress={sync} style={{ flex: 1 }} />
              <PrimaryButton title={copy.build} icon="hammer-outline" loading={running} onPress={build} style={{ flex: 1 }} />
            </View>

            <View style={styles.actions}>
              <IconButton name="download-outline" label={copy.install} disabled={!built} onPress={install} style={{ flex: 1 }} />
              <IconButton name="play-outline" label={copy.launch} onPress={launch} style={{ flex: 1 }} />
              <IconButton name="construct-outline" label="Gradle" onPress={onOpenBuild} style={{ flex: 1 }} />
            </View>

            {log ? (
              <View style={styles.logBox}>
                <Text selectable style={styles.logText}>{log}</Text>
              </View>
            ) : null}
          </SectionCard>
        </ScrollView>
      ) : (
        <View style={styles.codePage}>
          <Text style={styles.info}>{copy.previewInfo}</Text>
          <ScrollView style={styles.codeScroll} horizontal>
            <Text selectable style={styles.code}>{source}</Text>
          </ScrollView>
        </View>
      )}
    </View>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, minHeight: 0, backgroundColor: c.bg },
  header: {
    minHeight: 56,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
    backgroundColor: c.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: c.border,
  },
  headerIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: c.primarySurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { color: c.text, fontSize: 13, fontWeight: '750' },
  subtitle: { color: c.textSecondary, fontSize: 9, marginTop: 2 },
  tabBar: { padding: 6, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },

  previewPage: { padding: 12, paddingBottom: 40, alignItems: 'center', gap: 14 },

  device: {
    borderRadius: 28,
    borderWidth: 6,
    borderColor: '#111827',
    overflow: 'hidden',
    backgroundColor: '#FFFFFF',
  },
  themeControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
    paddingHorizontal: 3,
    backgroundColor: c.bgCard,
    borderRadius: 999,
  },
  systemBar: {
    height: 27,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  time: { color: '#111827', fontSize: 9, fontWeight: '700' },
  topBar: {
    height: 50,
    paddingHorizontal: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  topTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  body: { flex: 1 },

  navBar: { height: 29, alignItems: 'center', justifyContent: 'center' },
  gesture: { width: 95, height: 4, borderRadius: 2, backgroundColor: '#111827' },

  deviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 6,
  },
  deviceMetaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: c.bgElevated || '#F1F5F9',
  },
  deviceMetaText: { color: c.textSecondary, fontSize: 9.5, fontWeight: '700' },

  controls: { width: '100%', maxWidth: 720 },
  info: { color: c.textSecondary, fontSize: 10, lineHeight: 16 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  logBox: { maxHeight: 210, padding: 10, borderRadius: 9, backgroundColor: c.terminal },
  logText: { color: '#C9D3E3', fontFamily: 'monospace', fontSize: 9, lineHeight: 14 },

  codePage: { flex: 1, minHeight: 0, padding: 10, gap: 8 },
  codeScroll: { flex: 1, borderRadius: 10, backgroundColor: c.terminal },
  code: { padding: 12, color: '#C9D3E3', fontFamily: 'monospace', fontSize: 10, lineHeight: 16 },

  // Professional preview toolbar
  deviceControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginRight: 6,
    backgroundColor: c.bgElevated || '#F1F5F9',
    borderRadius: 999,
    padding: 2,
  },
  deviceChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 999,
    backgroundColor: 'transparent',
  },
  deviceChipActive: { backgroundColor: c.primary || '#4F46E5' },
  deviceChipText: { fontSize: 10, fontWeight: '700', color: c.text },
  scaleControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
    paddingHorizontal: 3,
    backgroundColor: c.bgCard,
    borderRadius: 999,
  },
  scaleText: {
    fontSize: 9.5,
    fontWeight: '700',
    color: c.textSecondary,
    minWidth: 34,
    textAlign: 'center',
  },
});

export default ComposePreviewPanel;
