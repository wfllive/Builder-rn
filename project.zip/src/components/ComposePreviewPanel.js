import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Icon } from './Icon';
import { IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill } from './AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { generateComposePreviewSource, runGradleCommand, syncComposeProject } from '../utils/composeProject';
import { getDebugApk, getProjectDir } from '../config/runtime';
import * as apt from '../../modules/apt-manager/src/index';
import NativeComposePreview from './NativeComposePreview';

// ComposeRuntimeWidget is now sourced from the native renderer; this
// compatibility re-export keeps any older call sites compiling until they
// are migrated to NativeComposePreview.
export { default as ComposeRuntimeWidget } from './NativeComposePreview';

const ComposePreviewPanel = ({ onOpenFullscreen, onOpenBuild }) => {
  const { currentProject, currentScreenId, getCurrentScreen, addWorkspaceLog } = useProject();
  const { colors, language } = useAppSettings();
  const screen = getCurrentScreen();
  const [tab, setTab] = useState('preview');
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState('');
  const [built, setBuilt] = useState(false);
  const styles = useMemo(() => createStyles(colors), [colors]);
  const screenIndex = currentProject?.screens?.findIndex((item) => item.id === currentScreenId) || 0;
  const source = useMemo(() => currentProject && screen ? generateComposePreviewSource(currentProject, screen, screenIndex) : '', [currentProject, screen, screenIndex]);
  const primary = currentProject?.theme?.primaryColor || '#4F46E5';
  const copy = language === 'ru' ? {
    title: 'Jetpack Compose Preview', subtitle: 'Макет и настоящий @Preview исходного Kotlin-кода', visual: 'Макет', code: 'Kotlin @Preview',
    sync: 'Сохранить Kotlin', build: 'Собрать Debug APK', install: 'Установить APK', launch: 'Открыть приложение', fullscreen: 'На весь экран',
    previewInfo: 'Макет рендерится нативно: теми же Android-виджетами (FrameLayout, LinearLayout, CardView, Material), что и сгенерированный APK. Чтобы получить финальный @Preview, синхронизируйте Kotlin и соберите Debug APK.',
    idle: 'Готов', building: 'Gradle работает', success: 'Debug APK готов', output: 'Gradle output',
  } : {
    title: 'Jetpack Compose Preview', subtitle: 'Visual canvas and real Kotlin @Preview source', visual: 'Canvas', code: 'Kotlin @Preview',
    sync: 'Save Kotlin', build: 'Build Debug APK', install: 'Install APK', launch: 'Open app', fullscreen: 'Full screen',
    previewInfo: 'The canvas is rendered natively: the same Android widgets (FrameLayout, LinearLayout, CardView, Material) the generated APK uses. To get the final @Preview, sync Kotlin and build the Debug APK.',
    idle: 'Ready', building: 'Gradle is running', success: 'Debug APK ready', output: 'Gradle output',
  };

  const sync = async () => {
    const result = await syncComposeProject(currentProject);
    setLog(result.output || '');
    addWorkspaceLog(result.output || 'Compose sources synchronized', result.success ? 'success' : 'error');
    return result;
  };
  const build = async () => {
    setRunning(true); setBuilt(false); setLog('$ ./gradlew assembleDebug\n');
    try {
      const synced = await sync();
      if (!synced.success) throw new Error(synced.output);
      const result = await execute(runGradleCommand('assembleDebug'), getProjectDir(currentProject));
      setLog(result.output || '');
      setBuilt(Boolean(result.success));
      addWorkspaceLog(result.success ? 'Debug APK assembled' : result.output, result.success ? 'success' : 'error');
    } catch (error) { setLog(error?.message || String(error)); }
    finally { setRunning(false); }
  };
  const install = async () => {
    const path = `${getProjectDir(currentProject)}/${getDebugApk()}`;
    const result = await apt.installApk?.(path);
    setLog((current) => `${current}\n${result?.success ? 'Android package installer opened' : result?.output || 'APK install is unavailable until Compose Studio is rebuilt.'}`);
  };
  const launch = async () => {
    const result = await apt.launchPackage?.(`${currentProject.packageName}.debug`);
    if (!result?.success) setLog((current) => `${current}\n${result?.output || 'Install the Debug APK first.'}`);
  };

  if (!screen) return null;
  return (
    <View style={styles.root}>
      <View style={styles.header}><View style={styles.headerIcon}><Icon name="logo-android" size={21} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.title}>{copy.title}</Text><Text style={styles.subtitle} numberOfLines={1}>{copy.subtitle}</Text></View><StatusPill label={running ? copy.building : built ? copy.success : copy.idle} tone={running ? 'info' : built ? 'success' : 'neutral'} /><IconButton name="expand-outline" onPress={onOpenFullscreen} /></View>
      <View style={styles.tabBar}><SegmentedControl compact value={tab} onChange={setTab} options={[{ value: 'preview', label: copy.visual, icon: 'phone-portrait-outline' }, { value: 'code', label: copy.code, icon: 'code-slash-outline' }]} /></View>
      {tab === 'preview' ? (
        <ScrollView contentContainerStyle={styles.previewPage}>
          <View style={styles.device}>
            <View style={styles.systemBar}><Text style={styles.time}>9:41</Text><Icon name="battery-full" size={14} color="#111827" /></View>
            {screen.showActionBar ? <View style={[styles.topBar, { backgroundColor: primary }]}><Icon name="arrow-back" size={19} color="#FFFFFF" /><Text style={styles.topTitle}>{screen.actionBarTitle || screen.name}</Text></View> : null}
            <View style={[styles.body, { backgroundColor: screen.backgroundColor || '#F8FAFC' }]}>
              <NativeComposePreview
                project={currentProject}
                screen={screen}
                showChrome={false}
                scroll={false}
                widthDp={360}
              />
            </View>
            <View style={styles.navBar}><View style={styles.gesture} /></View>
          </View>
          <SectionCard style={styles.controls} title="Native Android" icon="hardware-chip-outline"><Text style={styles.info}>{copy.previewInfo}</Text><View style={styles.actions}><IconButton name="save-outline" label={copy.sync} onPress={sync} style={{ flex: 1 }} /><PrimaryButton title={copy.build} icon="hammer-outline" loading={running} onPress={build} style={{ flex: 1 }} /></View><View style={styles.actions}><IconButton name="download-outline" label={copy.install} disabled={!built} onPress={install} style={{ flex: 1 }} /><IconButton name="play-outline" label={copy.launch} onPress={launch} style={{ flex: 1 }} /><IconButton name="construct-outline" label="Gradle" onPress={onOpenBuild} style={{ flex: 1 }} /></View>{log ? <View style={styles.logBox}><Text selectable style={styles.logText}>{log}</Text></View> : null}</SectionCard>
        </ScrollView>
      ) : <View style={styles.codePage}><Text style={styles.info}>{copy.previewInfo}</Text><ScrollView style={styles.codeScroll} horizontal><Text selectable style={styles.code}>{source}</Text></ScrollView></View>}
    </View>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, minHeight: 0, backgroundColor: c.bg }, header: { minHeight: 56, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border }, headerIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, title: { color: c.text, fontSize: 13, fontWeight: '750' }, subtitle: { color: c.textSecondary, fontSize: 9, marginTop: 2 }, tabBar: { padding: 6, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  previewPage: { padding: 12, paddingBottom: 40, alignItems: 'center', gap: 14 }, device: { width: '100%', maxWidth: 360, height: 680, borderRadius: 28, borderWidth: 6, borderColor: '#111827', overflow: 'hidden', backgroundColor: '#FFFFFF' }, systemBar: { height: 27, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, time: { color: '#111827', fontSize: 9, fontWeight: '700' }, topBar: { height: 50, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 10 }, topTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' }, body: { flex: 1 }, navBar: { height: 29, alignItems: 'center', justifyContent: 'center' }, gesture: { width: 95, height: 4, borderRadius: 2, backgroundColor: '#111827' }, controls: { width: '100%', maxWidth: 720 }, info: { color: c.textSecondary, fontSize: 10, lineHeight: 16 }, actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 }, logBox: { maxHeight: 210, padding: 10, borderRadius: 9, backgroundColor: c.terminal }, logText: { color: '#C9D3E3', fontFamily: 'monospace', fontSize: 9, lineHeight: 14 }, codePage: { flex: 1, minHeight: 0, padding: 10, gap: 8 }, codeScroll: { flex: 1, borderRadius: 10, backgroundColor: c.terminal }, code: { padding: 12, color: '#C9D3E3', fontFamily: 'monospace', fontSize: 10, lineHeight: 16 },
});

export default ComposePreviewPanel;
