import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Icon } from './Icon';
import { IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill } from './AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { generateComposePreviewSource, runGradleCommand, syncComposeProject } from '../utils/composeProject';
import { getDebugApk, getProjectDir } from '../config/runtime';
import * as apt from '../../modules/apt-manager/src/index';

export const ComposeRuntimeWidget = ({ component, primary = '#4F46E5' }) => {
  const [values, setValues] = useState({});
  if (!component) return null;
  const p = component.props || {};
  const children = (component.children || []).map((child) => <ComposeRuntimeWidget key={child.id} component={child} primary={primary} />);
  const width = p.width === 'match_parent' ? '100%' : typeof p.width === 'number' ? p.width : undefined;
  switch (component.type) {
    case 'Column': return <View style={{ width, padding: p.padding || 0, gap: p.spacing || 0, alignItems: p.horizontalAlignment === 'center' ? 'center' : p.horizontalAlignment === 'end' ? 'flex-end' : 'flex-start', backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children}</View>;
    case 'Row': return <View style={{ width, padding: p.padding || 0, gap: p.spacing || 0, flexDirection: 'row', alignItems: 'center', backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children}</View>;
    case 'Box': return <View style={{ width, minHeight: 50, padding: p.padding || 0, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children}</View>;
    case 'LazyColumn': return <View style={{ width, flex: p.height === 'match_parent' ? 1 : undefined, padding: p.padding || 0, gap: p.spacing || 0 }}>{children}</View>;
    case 'Card': return <View style={{ width, padding: p.padding || 16, gap: 8, borderRadius: p.borderRadius || 16, backgroundColor: p.backgroundColor || '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', elevation: p.elevation || 2 }}>{children}</View>;
    case 'Text': return <Text style={{ width, padding: p.padding || 0, fontSize: Number(p.textSize) || 16, color: p.textColor || '#111827', fontWeight: p.textStyle === 'bold' ? '700' : '400', fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal', textAlign: p.textAlign === 'center' ? 'center' : p.textAlign === 'end' ? 'right' : 'left' }}>{p.text}</Text>;
    case 'Button': return <Pressable onPress={() => {}} style={({ pressed }) => ({ width, minHeight: 44, padding: p.padding || 12, borderRadius: p.borderRadius || 12, backgroundColor: p.backgroundColor || primary, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.75 : p.enabled === false ? 0.45 : 1 })}><Text style={{ color: p.textColor || '#FFFFFF', fontSize: p.textSize || 15, fontWeight: '700' }}>{p.text}</Text></Pressable>;
    case 'OutlinedTextField': return <View style={{ width, gap: 3 }}><Text style={{ color: primary, fontSize: 10 }}>{p.label}</Text><TextInput value={values[component.id] ?? p.text ?? ''} onChangeText={(value) => setValues((current) => ({ ...current, [component.id]: value }))} placeholder={p.hint} placeholderTextColor="#64748B" style={{ minHeight: 48, paddingHorizontal: 12, borderRadius: 7, borderWidth: 1, borderColor: '#64748B', color: '#111827' }} /></View>;
    case 'Image': return <View style={{ width: Number(p.width) || 120, height: Number(p.height) || 120, borderRadius: p.borderRadius || 12, backgroundColor: p.backgroundColor || '#E5E7EB', alignItems: 'center', justifyContent: 'center' }}><Icon name="image-outline" size={34} color="#64748B" /></View>;
    case 'Checkbox': return <View style={{ width, flexDirection: 'row', alignItems: 'center', gap: 8 }}><Icon name={p.checked ? 'checkbox' : 'square-outline'} size={22} color={primary} /><Text style={{ color: p.textColor || '#111827' }}>{p.text}</Text></View>;
    case 'Switch': return <View style={{ width, minHeight: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><Text style={{ color: '#111827' }}>{p.text}</Text><Switch value={Boolean(p.checked)} trackColor={{ false: '#CBD5E1', true: primary }} /></View>;
    case 'LinearProgressIndicator': { const value = Number(p.progress) || 0; return <View style={{ width: width || '100%', height: Number(p.height) || 8, borderRadius: 99, overflow: 'hidden', backgroundColor: p.trackColor || '#E5E7EB' }}><View style={{ width: `${Math.min(100, value <= 1 ? value * 100 : value)}%`, height: '100%', backgroundColor: p.color || primary }} /></View>; }
    case 'CircularProgressIndicator': return <View style={{ width: Number(p.width) || 48, height: Number(p.height) || 48, borderWidth: p.strokeWidth || 4, borderRadius: 99, borderColor: p.color || primary, borderTopColor: 'transparent' }} />;
    case 'HorizontalDivider': return <View style={{ width: width || '100%', height: Number(p.height) || 1, backgroundColor: p.color || '#D1D5DB', marginVertical: p.padding || 8 }} />;
    case 'Spacer': return <View style={{ width, height: Number(p.height) || 16 }} />;
    case 'Icon': return <Icon name="star" size={Number(p.size) || 28} color={p.tint || primary} />;
    case 'WebView': return <View style={{ width: width || '100%', height: Number(p.height) || 260, borderRadius: 8, backgroundColor: '#E8F1F5', alignItems: 'center', justifyContent: 'center' }}><Icon name="globe-outline" size={30} color="#0E7490" /><Text style={{ color: '#334155', fontSize: 10, marginTop: 5 }}>{p.url}</Text></View>;
    default: return <Text style={{ color: '#B91C1C' }}>{component.type}</Text>;
  }
};

const ComposePreviewPanel = ({ onOpenFullscreen, onOpenBuild }) => {
  const { currentProject, currentScreenId, getCurrentScreen, addWorkspaceLog } = useProject();
  const { colors, language } = useAppSettings();
  const screen = getCurrentScreen();
  const [tab, setTab] = useState('preview');
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState('');
  const [built, setBuilt] = useState(false);
  const styles = useMemo(() => createStyles(colors), [colors]);
  const screenIndex = currentProject?.screens?.findIndex((item) => item.id === currentScreenId) || 0;
  const source = useMemo(() => currentProject && screen ? generateComposePreviewSource(currentProject, screen, screenIndex) : '', [currentProject, screen, screenIndex]);
  const primary = currentProject?.theme?.primaryColor || '#4F46E5';
  const copy = language === 'ru' ? {
    title: 'Jetpack Compose Preview', subtitle: 'Макет и настоящий @Preview исходного Kotlin-кода', visual: 'Макет', code: 'Kotlin @Preview',
    sync: 'Сохранить Kotlin', build: 'Собрать Debug APK', install: 'Установить APK', launch: 'Открыть приложение', fullscreen: 'На весь экран',
    previewInfo: '@Preview исполняется через Android Studio Layoutlib. В конструкторе показан эквивалентный интерактивный макет; для полностью нативной проверки соберите и установите Debug APK.',
    idle: 'Готов', building: 'Gradle работает', success: 'Debug APK готов', output: 'Gradle output',
  } : {
    title: 'Jetpack Compose Preview', subtitle: 'Visual canvas and real Kotlin @Preview source', visual: 'Canvas', code: 'Kotlin @Preview',
    sync: 'Save Kotlin', build: 'Build Debug APK', install: 'Install APK', launch: 'Open app', fullscreen: 'Full screen',
    previewInfo: '@Preview is executed by Android Studio Layoutlib. The builder displays an equivalent interactive canvas; build and install the Debug APK for fully native validation.',
    idle: 'Ready', building: 'Gradle is running', success: 'Debug APK ready', output: 'Gradle output',
  };

  const sync = async () => {
    const result = await syncComposeProject(currentProject);
    setLog(result.output || '');
    addWorkspaceLog(result.output || 'Compose sources synchronized', result.success ? 'success' : 'error');
    return result;
  };
  const build = async () => {
    setRunning(true); setBuilt(false); setLog('$ ./gradlew assembleDebug\n');
    try {
      const synced = await sync();
      if (!synced.success) throw new Error(synced.output);
      const result = await execute(runGradleCommand('assembleDebug'), getProjectDir(currentProject));
      setLog(result.output || '');
      setBuilt(Boolean(result.success));
      addWorkspaceLog(result.success ? 'Debug APK assembled' : result.output, result.success ? 'success' : 'error');
    } catch (error) { setLog(error?.message || String(error)); }
    finally { setRunning(false); }
  };
  const install = async () => {
    const path = `${getProjectDir(currentProject)}/${getDebugApk()}`;
    const result = await apt.installApk?.(path);
    setLog((current) => `${current}\n${result?.success ? 'Android package installer opened' : result?.output || 'APK install is unavailable until Compose Studio is rebuilt.'}`);
  };
  const launch = async () => {
    const result = await apt.launchPackage?.(`${currentProject.packageName}.debug`);
    if (!result?.success) setLog((current) => `${current}\n${result?.output || 'Install the Debug APK first.'}`);
  };

  if (!screen) return null;
  return (
    <View style={styles.root}>
      <View style={styles.header}><View style={styles.headerIcon}><Icon name="logo-android" size={21} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.title}>{copy.title}</Text><Text style={styles.subtitle} numberOfLines={1}>{copy.subtitle}</Text></View><StatusPill label={running ? copy.building : built ? copy.success : copy.idle} tone={running ? 'info' : built ? 'success' : 'neutral'} /><IconButton name="expand-outline" onPress={onOpenFullscreen} /></View>
      <View style={styles.tabBar}><SegmentedControl compact value={tab} onChange={setTab} options={[{ value: 'preview', label: copy.visual, icon: 'phone-portrait-outline' }, { value: 'code', label: copy.code, icon: 'code-slash-outline' }]} /></View>
      {tab === 'preview' ? (
        <ScrollView contentContainerStyle={styles.previewPage}>
          <View style={styles.device}><View style={styles.systemBar}><Text style={styles.time}>9:41</Text><Icon name="battery-full" size={14} color="#111827" /></View>{screen.showActionBar ? <View style={[styles.topBar, { backgroundColor: primary }]}><Icon name="arrow-back" size={19} color="#FFFFFF" /><Text style={styles.topTitle}>{screen.actionBarTitle || screen.name}</Text></View> : null}<ScrollView style={[styles.body, { backgroundColor: screen.backgroundColor || '#F8FAFC' }]} contentContainerStyle={{ padding: screen.rootComponent?.props?.padding || 8 }}><ComposeRuntimeWidget component={screen.rootComponent} primary={primary} /></ScrollView><View style={styles.navBar}><View style={styles.gesture} /></View></View>
          <SectionCard style={styles.controls} title="Native Android" icon="hardware-chip-outline"><Text style={styles.info}>{copy.previewInfo}</Text><View style={styles.actions}><IconButton name="save-outline" label={copy.sync} onPress={sync} style={{ flex: 1 }} /><PrimaryButton title={copy.build} icon="hammer-outline" loading={running} onPress={build} style={{ flex: 1 }} /></View><View style={styles.actions}><IconButton name="download-outline" label={copy.install} disabled={!built} onPress={install} style={{ flex: 1 }} /><IconButton name="play-outline" label={copy.launch} onPress={launch} style={{ flex: 1 }} /><IconButton name="construct-outline" label="Gradle" onPress={onOpenBuild} style={{ flex: 1 }} /></View>{log ? <View style={styles.logBox}><Text selectable style={styles.logText}>{log}</Text></View> : null}</SectionCard>
        </ScrollView>
      ) : <View style={styles.codePage}><Text style={styles.info}>{copy.previewInfo}</Text><ScrollView style={styles.codeScroll} horizontal><Text selectable style={styles.code}>{source}</Text></ScrollView></View>}
    </View>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, minHeight: 0, backgroundColor: c.bg }, header: { minHeight: 56, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border }, headerIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, title: { color: c.text, fontSize: 13, fontWeight: '750' }, subtitle: { color: c.textSecondary, fontSize: 9, marginTop: 2 }, tabBar: { padding: 6, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  previewPage: { padding: 12, paddingBottom: 40, alignItems: 'center', gap: 14 }, device: { width: '100%', maxWidth: 360, height: 680, borderRadius: 28, borderWidth: 6, borderColor: '#111827', overflow: 'hidden', backgroundColor: '#FFFFFF' }, systemBar: { height: 27, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, time: { color: '#111827', fontSize: 9, fontWeight: '700' }, topBar: { height: 50, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 10 }, topTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' }, body: { flex: 1 }, navBar: { height: 29, alignItems: 'center', justifyContent: 'center' }, gesture: { width: 95, height: 4, borderRadius: 2, backgroundColor: '#111827' }, controls: { width: '100%', maxWidth: 720 }, info: { color: c.textSecondary, fontSize: 10, lineHeight: 16 }, actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 }, logBox: { maxHeight: 210, padding: 10, borderRadius: 9, backgroundColor: c.terminal }, logText: { color: '#C9D3E3', fontFamily: 'monospace', fontSize: 9, lineHeight: 14 }, codePage: { flex: 1, minHeight: 0, padding: 10, gap: 8 }, codeScroll: { flex: 1, borderRadius: 10, backgroundColor: c.terminal }, code: { padding: 12, color: '#C9D3E3', fontFamily: 'monospace', fontSize: 10, lineHeight: 16 },
});

export default ComposePreviewPanel;
