import React from 'react';
import { View, Text, Pressable, StyleSheet, ScrollView } from 'react-native';

export function RainTimeline({ frames, current, onChange, bottomOffset, visible } : any) {
  if (!visible) return null;
  return (
    <View style={[styles.wrap, { bottom: bottomOffset ?? 70 }]}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {frames.map((f:any, i:number)=> (
          <Pressable key={f.time} onPress={()=>onChange(i)} style={[styles.tick, i===current && styles.tickActive]}>
            <Text style={[styles.tickText, i===current && styles.tickTextActive]}>
              {new Date(f.time*1000).toLocaleTimeString('ru-RU', { hour:'2-digit', minute:'2-digit' })}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position:'absolute', left:12, right:12, zIndex:45 },
  scroll: { paddingVertical:6, gap:6, flexDirection:'row' },
  tick: { paddingHorizontal:10, paddingVertical:6, borderRadius:10, backgroundColor:'rgba(15,23,42,0.85)', borderWidth:1, borderColor:'rgba(255,255,255,0.06)', marginRight:6 },
  tickActive: { backgroundColor:'#2563eb', borderColor:'#3b82f6' },
  tickText: { color:'#cbd5e1', fontSize:12 },
  tickTextActive: { color:'#fff', fontWeight:'700' },
});
