import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Canvas, Image, useImage, Skia, Group, rect, Fill, Shader, SkRuntimeEffect } from '@shopify/react-native-skia';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { RAINRADAR_URL } from '@/hooks/useRainRadarRR';

// Палитра rainradar.ru
const PALETTE_STOPS: [number, number, number, number, number][] = [
  [0, 146, 163, 185, 0],
  [1, 146, 161, 181, 204],
  [5, 103, 104, 158, 255],
  [11, 56, 64, 128, 255],
  [15, 29, 175, 87, 255],
  [30, 255, 247, 0, 255],
  [40, 255, 174, 0, 255],
  [47, 226, 40, 86, 255],
  [58, 169, 10, 158, 255],
  [60, 169, 10, 158, 255],
];

// Генерируем 1D палитру 256px
function makePaletteImage() {
  const width = 256;
  const height = 1;
  const surface = Skia.Surface.MakeOffscreen(width, height);
  if (!surface) return null;
  const canvas = surface.getCanvas();
  const paint = Skia.Paint();
  // рисуем градиент вручную
  const pixels = new Uint8Array(width*4);
  for (let i=0;i<width;i++){
    const v = i / (width-1) * 70;
    // find stops
    let a = PALETTE_STOPS[0], b = PALETTE_STOPS[PALETTE_STOPS.length-1];
    for (let s=0;s<PALETTE_STOPS.length-1;s++){
      if (v >= PALETTE_STOPS[s][0] && v <= PALETTE_STOPS[s+1][0]) { a = PALETTE_STOPS[s]; b = PALETTE_STOPS[s+1]; break; }
    }
    const t = (v - a[0]) / Math.max(0.0001, b[0]-a[0]);
    const r = Math.round(a[1] + (b[1]-a[1])*t);
    const g = Math.round(a[2] + (b[2]-a[2])*t);
    const bl = Math.round(a[3] + (b[3]-a[3])*t);
    const al = Math.round(a[4] + (b[4]-a[4])*t);
    pixels[i*4+0]=r; pixels[i*4+1]=g; pixels[i*4+2]=bl; pixels[i*4+3]=al;
  }
  const imgInfo = Skia.ImageInfo.Make(width, height, Skia.ColorType.RGBA_8888, Skia.AlphaType.Unpremul);
  const data = Skia.Data.fromBytes(pixels);
  const img = Skia.Image.MakeImage(imgInfo, data, width*4);
  return img;
}

const paletteImg = makePaletteImage();

// SkSL shader: взять R канал, нормализовать /70, семплить палитру
const colorizeShader = Skia.RuntimeEffect.Make(`
uniform shader tile;
uniform shader palette;
half4 main(float2 xy) {
  half4 c = tile.eval(xy);
  float v = c.r; // 0..1, rainradar tile хранит данные в R
  // rainradar data 0..70 mapped to 0..1
  // но PNG уже 0..255, где 255 ~= 70
  // v уже 0..1
  half4 pc = palette.eval(float2(v, 0.5));
  return half4(pc.rgb, pc.a * step(0.01, v));
}
`)!;

type TileInfo = { z:number; x:number; y:number; url:string };

function getTileList(bbox: [number,number,number,number], zoom: number, available: Record<number,[number,number][]>): TileInfo[] {
  // bbox: [west, south, east, north]
  const [w,s,e,n] = bbox;
  const z = zoom > 7 ? 5 : zoom > 5 ? 4 : 3;
  const avail = new Set((available[z]||[]).map(([x,y])=>`${x}_${y}`));
  const list: TileInfo[] = [];
  // convert lat/lon to tile
  const lon2tile = (lon:number, z:number)=> Math.floor((lon+180)/360 * Math.pow(2,z));
  const lat2tile = (lat:number, z:number)=> {
    const rad = lat * Math.PI/180;
    return Math.floor((1 - Math.log(Math.tan(rad)+1/Math.cos(rad))/Math.PI)/2 * Math.pow(2,z));
  };
  const x0 = lon2tile(w, z);
  const x1 = lon2tile(e, z);
  const y0 = lat2tile(n, z);
  const y1 = lat2tile(s, z);
  for (let x = Math.min(x0,x1); x<=Math.max(x0,x1); x++){
    for (let y = Math.min(y0,y1); y<=Math.max(y0,y1); y++){
      if (!avail.has(`${x}_${y}`)) continue;
      // ts will be injected by caller
      list.push({ z, x, y, url: '' });
    }
  }
  return list.slice(0, 48); // limit
}

function TileSprite({ tile, ts, mapRef, opacity }: { tile: TileInfo, ts:number, mapRef:any, opacity:number }){
  const url = `${RAINRADAR_URL}/composite/${ts}/${tile.z}/${tile.x}_${tile.y}.png`;
  const image = useImage(url);
  const [pts, setPts] = React.useState<number[] | null>(null);

  // project tile bounds to screen
  useEffect(()=>{
    let cancelled=false;
    const update = async ()=>{
      try {
        const map = mapRef.current;
        if (!map) return;
        // tile bounds in 3857
        const n = tile2lat(tile.y, tile.z);
        const s = tile2lat(tile.y+1, tile.z);
        const w = tile2lon(tile.x, tile.z);
        const e = tile2lon(tile.x+1, tile.z);
        const p1 = await map.getPointInView([w, n]);
        const p2 = await map.getPointInView([e, n]);
        const p3 = await map.getPointInView([e, s]);
        const p4 = await map.getPointInView([w, s]);
        if (!cancelled) setPts([...p1, ...p2, ...p3, ...p4]);
      } catch {}
    };
    update();
    const iv = setInterval(update, 500);
    return ()=> { cancelled=true; clearInterval(iv); };
  }, [tile.x, tile.y, tile.z, mapRef]);

  if (!image || !pts || !paletteImg) return null;

  // simple draw: use 4-point quad via vertices? Skia Image can draw with dst rect only (axis aligned).
  // For simplicity: draw axis-aligned bounding box
  const xs = [pts[0], pts[2], pts[4], pts[6]];
  const ys = [pts[1], pts[3], pts[5], pts[7]];
  const left = Math.min(...xs);
  const top = Math.min(...ys);
  const right = Math.max(...xs);
  const bottom = Math.max(...ys);
  const width = right-left;
  const height = bottom-top;
  if (width < 4 || height < 4) return null;

  return (
    <Group opacity={opacity}>
      <Image
        image={image}
        x={left}
        y={top}
        width={width}
        height={height}
        fit="fill"
        // @ts-ignore colorFilter via shader
        colorFilter={Skia.ColorFilter.MakeRuntimeShader(colorizeShader, {
          tile: undefined, // will be set automatically?
          palette: paletteImg.makeShader(Skia.TileMode.Clamp, Skia.TileMode.Clamp),
        }, null)}
      />
    </Group>
  );
}

// helpers
function tile2lon(x:number, z:number){ return x / Math.pow(2,z) * 360 - 180; }
function tile2lat(y:number, z:number){
  const n = Math.PI - 2*Math.PI*y / Math.pow(2,z);
  return 180/Math.PI * Math.atan(0.5*(Math.exp(n)-Math.exp(-n)));
}

export function RainRadarSkiaOverlay({ frame, mapRef, opacity=0.7 }:{ frame:any; mapRef:any; opacity?:number }) {
  const [bounds, setBounds] = useState<[number,number,number,number] | null>(null);
  const [zoom, setZoom] = useState(3);

  useEffect(()=>{
    let mounted=true;
    const tick = async ()=>{
      try {
        const map = mapRef.current;
        if (!map || !frame) return;
        const b = await map.getVisibleBounds(); // [[west,south],[east,north]]
        if (b && mounted) {
          setBounds([b[0][0], b[0][1], b[1][0], b[1][1]]);
          const z = await map.getZoom();
          setZoom(z);
        }
      } catch {}
    };
    tick();
    const iv = setInterval(tick, 800);
    return ()=> { mounted=false; clearInterval(iv); };
  }, [mapRef, frame]);

  const tiles = useMemo(()=>{
    if (!bounds || !frame?.zooms) return [];
    return getTileList(bounds, Math.floor(zoom), frame.zooms).map(t=> ({...t}));
  }, [bounds, zoom, frame]);

  if (!frame) return null;

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <Canvas style={{ flex:1 }}>
        {tiles.map(t=> (
          <TileSprite
            key={`${t.z}/${t.x}/${t.y}`}
            tile={t}
            ts={frame.ts}
            mapRef={mapRef}
            opacity={opacity}
          />
        ))}
      </Canvas>
      <View style={s.badge}>
        <View style={{width:8,height:8,borderRadius:4,backgroundColor:'#22c55e', marginRight:6}} />
        <View>
          <View style={{flexDirection:'row'}}>
            <View style={{width:26, height:10, backgroundColor:'rgba(255,255,255,0.9)'}} />
            <View style={{marginLeft:4}}>
              
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  badge: { position:'absolute', top:8, left:8, backgroundColor:'rgba(0,0,0,0.5)', paddingHorizontal:8, paddingVertical:4, borderRadius:8, flexDirection:'row', alignItems:'center' }
});
