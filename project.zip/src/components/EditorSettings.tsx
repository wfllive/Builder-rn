import React
{ useMemo } from 'react';
import { Pressable
ScrollView
Text
View } from 'react-native';
import { useAppSettings } from '../store/appSettings';
import { SectionCard
SegmentedControl } from './AppUI';
import { Icon } from './Icon';
/**
 * Settings panel for the CodeMirror IDE editor: font size
indentation
 * word wrap
autocomplete
the symbol toolbar
auto-save and the status bar.
 * Everything applies live — settings are persisted via the app settings store.
 */
const EditorSettings = ({ onClose }) => {
  const { colors
language
editor
setEditorSetting } = useAppSettings();
  const styles = useMemo(() => /* styles removed */(colors)
[colors]);
  const ru = language === 'ru';
  const t = (ruKey
enKey) => (ru ? ruKey : enKey);
  const toggle = (key) => () => setEditorSetting(key
!editor[key]);
  const fontSize = editor.fontSize || 15;
  const setFontSize = (delta) => () => {
    const next = Math.max(9
Math.min(28
fontSize + delta));
    setEditorSetting('fontSize'
next);
  };
  const Row = ({ label
desc
onPress
value
options
right }) => (
    <Pressable onPress={onPress} className="p-4" disabled={!onPress}>
      <View className="flex-1">
        <Text className="p-4">{label}</Text>
        {desc ? <Text className="p-4">{desc}</Text> : null}
      </View>
      {right || (options
        ? <SegmentedControl compact value={value} onChange={onPress} options={options} />
        : <View style={[className="switch
value && className="switchOn]}><View style={[className="knob
value && className="knobOn]} /></View>)}
    </Pressable>
  );
  return (
    <View className="p-4">
      <View className="p-4">
        <View className="p-4"><Icon name="options-outline" size={18} color={colors.primary} /></View>
        <Text className="p-4">{t('Настройки редактора'
'Editor settings')}</Text>
        <View className="flex-1" />
        <Pressable onPress={onClose} className="p-4"><Icon name="close" size={20} color={colors.textSecondary} /></Pressable>
      </View>
      <ScrollView className="p-4" contentContainerStyle={{ padding: 12
gap: 10 }}>
        <SectionCard title={t('Шрифт'
'Font')} icon="text-outline">
          <Row
            label={t('Размер шрифта'
'Font size')}
            desc={t('Применяется и к коду
и к номерам строк'
'Applies to code and line numbers')}
            right={(
              <View className="p-4">
                <Pressable onPress={setFontSize(-1)} className="p-4"><Icon name="remove" size={17} color={colors.text} /></Pressable>
                <Text className="p-4">{fontSize}</Text>
                <Pressable onPress={setFontSize(1)} className="p-4"><Icon name="add" size={17} color={colors.text} /></Pressable>
              </View>
            )}
          />
        </SectionCard>
        <SectionCard title={t('Отступы'
'Indentation')} icon="code-outline">
          <Row
            label={t('Размер табуляции'
'Tab size')}
            value={String(editor.tabSize)}
            onPress={(v) => setEditorSetting('tabSize'
Number(v))}
            options={[{ value: '2'
label: '2' }
{ value: '4'
label: '4' }
{ value: '8'
label: '8' }]}
          />
          <Row
            label={t('Пробелы вместо табуляции'
'Spaces instead of tabs')}
            desc={editor.spacesForTab ? t('Tab вставляет пробелы'
'Tab inserts spaces') : t('Tab вставляет символ табуляции'
'Tab inserts a tab character')}
            value={editor.spacesForTab}
            onPress={toggle('spacesForTab')}
          />
        </SectionCard>
        <SectionCard title={t('Вид'
'View')} icon="color-wand-outline">
          <Row
            label={t('Перенос длинных строк'
'Word wrap')}
            desc={t('Переносить строки
не помещающиеся по ширине'
'Wrap lines wider than the editor')}
            value={editor.wordWrap}
            onPress={toggle('wordWrap')}
          />
          <Row
            label={t('Панель статуса'
'Status bar')}
            desc={t('Строка
столбец
язык — как в VS Code'
'Line
column
language — VS Code style')}
            value={editor.showStatusBar}
            onPress={toggle('showStatusBar')}
          />
        </SectionCard>
        <SectionCard title={t('Редактирование'
'Editing')} icon="flash-outline">
          <Row
            label={t('Автодополнение'
'Autocomplete')}
            desc={t('Подсказки ключевых слов и JSX snippets'
'Keyword hints and Compose snippets')}
            value={editor.completion !== false}
            onPress={toggle('completion')}
          />
          <Row
            label={t('Панель инструментов'
'Symbol toolbar')}
            desc={t('Кнопки скобок
отмены и команд над клавиатурой'
'Bracket
undo and command keys above the keyboard')}
            value={editor.hotkeys !== false}
            onPress={toggle('hotkeys')}
          />
          <Row
            label={t('Автосохранение'
'Auto-save')}
            desc={t('Автоматически сохраняет код на диск'
'Automatically saves code to disk')}
            value={editor.autoSave}
            onPress={toggle('autoSave')}
          />
        </SectionCard>
        <SectionCard title={t('Проверка кода'
'Code analysis')} icon="shield-checkmark-outline">
          <Row
            label={t('Компилятор после сохранения'
'Compiler check after save')}
            desc={t('Фоновой запуск npm run build — ошибки сами появятся в «Проблемах»
ничего запускать не нужно'
'Runs npm run build in the background — compiler errors appear in Problems automatically
nothing to run')}
            value={editor.autoCheck !== false}
            onPress={toggle('autoCheck')}
          />
        </SectionCard>
      </ScrollView>
    </View>
  );
};
// Tailwind className
export default EditorSettings;