import React
{ useEffect
useState } from 'react';
import { ActivityIndicator
ScrollView
Text
TouchableOpacity
View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSettings } from '../store/appSettings';
// Показывается один раз при первом запуске конструктора (и после смены версии
// ключа). Согласие — активным действием пользователя
как требуют правила
// сторов: без автозакрытия и скрытых «согласий».
const PRIVACY_ACCEPTED_KEY = '@nova_privacy_accepted_v2';
const STRINGS = {
  ru: {
    title: 'Политика конфиденциальности'
    intro: 'NovaCompose Studio работает полностью на вашем устройстве. Приложению не нужны аккаунты
и оно не передаёт ваши данные разработчику.'
    points: [
      'Приложение не собирает персональные данные у разработчика: нет своих серверов
аналитики и трекеров.'
      'Приложение бесплатное и показывает рекламу Рекламной сети Яндекса. Для подбора объявлений Яндекс может использовать рекламный идентификатор устройства — он обрабатывается по политике конфиденциальности Яндекса (yandex.ru/legal/confidential).'
      'Доступ к файлам нужен только для чтения и записи проектов и результатов сборки (APK) — файлы остаются на устройстве.'
      'Установка приложений используется исключительно для установки APK
собранных вами в конструкторе
и только через системный диалог Android.'
      'Сеть используется для загрузки открытого инструментария сборки (Ubuntu
Node.js
Gradle
Android SDK) с официальных источников по HTTPS и для показа рекламы.'
      'Уведомления показывают ход фоновых операций: подготовки среды и сборки.'
    ]
    accept: 'Принимаю и продолжаю'
    note: 'Нажимая кнопку
вы подтверждаете
что ознакомлены с политикой конфиденциальности.'
  }
  en: {
    title: 'Privacy policy'
    intro: 'NovaCompose Studio works entirely on your device. It needs no accounts and does not send your data to the developer.'
    points: [
      'The developer collects no personal data: the app has no servers
analytics or trackers of its own.'
      'The app is free and shows ads from the Yandex Advertising Network. To select ads Yandex may use the device advertising ID
processed under the Yandex privacy policy (yandex.ru/legal/confidential).'
      'File access is used only to read and write your projects and build results (APK) — files stay on the device.'
      'App installation is used solely to install APKs you built
via the standard Android system dialog.'
      'The network is used only to download open build tooling (Ubuntu
Node.js
Gradle
Android SDK) from official sources over HTTPS and to display ads.'
      'Notifications show the progress of background work: environment setup and builds.'
    ]
    accept: 'Accept and continue'
    note: 'By tapping the button you confirm that you have read the privacy policy.'
  }
};
const PrivacyGate = ({ children }) => {
  const { colors
language } = useAppSettings();
  const insets = useSafeAreaInsets();
  const [accepted
setAccepted] = useState(null);
  const copy = STRINGS[language] || STRINGS.en;
  useEffect(() => {
    let cancelled = false;
    AsyncStorage.getItem(PRIVACY_ACCEPTED_KEY)
      .then((value) => { if (!cancelled) setAccepted(value === '1'); })
      .catch(() => { if (!cancelled) setAccepted(false); });
    return () => { cancelled = true; };
  }
[]);
  if (accepted === null) {
    return (
      <View style={[styles.loader
{ backgroundColor: colors.bg }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }
  if (accepted) return children;
  const onAccept = async () => {
    try { await AsyncStorage.setItem(PRIVACY_ACCEPTED_KEY
'1'); } catch {}
    setAccepted(true);
  };
  return (
    <View style={[styles.root
{ backgroundColor: colors.bg
paddingTop: insets.top
paddingBottom: insets.bottom }]}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={[styles.title
{ color: colors.text }]}>{copy.title}</Text>
        <Text style={[styles.intro
{ color: colors.text }]}>{copy.intro}</Text>
        {copy.points.map((point) => (
          <View key={point} className="p-4">
            <Text style={[styles.bullet
{ color: colors.primary }]}>•</Text>
            <Text style={[styles.point
{ color: colors.textSecondary }]}>{point}</Text>
          </View>
        ))}
      </ScrollView>
      <View className="p-4">
        <TouchableOpacity style={[styles.button
{ backgroundColor: colors.primary }]} activeOpacity={0.85} onPress={onAccept}>
          <Text className="p-4">{copy.accept}</Text>
        </TouchableOpacity>
        <Text style={[styles.note
{ color: colors.textSecondary }]}>{copy.note}</Text>
      </View>
    </View>
  );
};
const styles = {/* converted to Tailwind */};
export default PrivacyGate;