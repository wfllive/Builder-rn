import React, { useMemo } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from './Icon';
import { useAppSettings } from '../store/appSettings';

export const AppScreen = ({ children, style, safe = true }) => {
  const { colors } = useAppSettings();
  const Component = safe ? SafeAreaView : View;
  return <Component style={[{ flex: 1, backgroundColor: colors.bg }, style]}>{children}</Component>;
};

export const IconButton = ({ name, label, accessibilityLabel, onPress, disabled, active, danger, size = 20, style }) => {
  const { colors } = useAppSettings();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || label || name}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [{
        minWidth: 42,
        height: 42,
        paddingHorizontal: label ? 12 : 0,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: active ? colors.primary : danger ? colors.error : colors.border,
        backgroundColor: active ? colors.primarySurface : colors.bgElevated,
        opacity: disabled ? 0.4 : pressed ? 0.72 : 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 7,
      }, style]}
    >
      <Icon name={name} size={size} color={danger ? colors.error : active ? colors.primary : colors.textSecondary} />
      {label ? <Text style={{ color: danger ? colors.error : colors.text, fontSize: 13, fontWeight: '650' }}>{label}</Text> : null}
    </Pressable>
  );
};

export const TopBar = ({ title, subtitle, onBack, left, right, compact = false }) => {
  const { colors } = useAppSettings();
  const s = useMemo(() => StyleSheet.create({
    root: {
      minHeight: compact ? 58 : 66,
      paddingHorizontal: compact ? 10 : 16,
      paddingVertical: 8,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      backgroundColor: colors.bgCard,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    title: { color: colors.text, fontSize: compact ? 16 : 18, fontWeight: '750' },
    subtitle: { color: colors.textSecondary, fontSize: 11, marginTop: 2 },
  }), [colors, compact]);
  return (
    <View style={s.root}>
      {onBack ? <IconButton name="arrow-back" onPress={onBack} accessibilityLabel="Back" style={{ minWidth: 42, paddingHorizontal: 0 }} /> : left}
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text style={s.title} numberOfLines={1}>{title}</Text>
        {subtitle ? <Text style={s.subtitle} numberOfLines={1}>{subtitle}</Text> : null}
      </View>
      {right ? <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}>{right}</View> : null}
    </View>
  );
};

export const PrimaryButton = ({ title, icon, onPress, disabled, loading, destructive, style }) => {
  const { colors } = useAppSettings();
  const bg = destructive ? colors.error : colors.primary;
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      style={({ pressed }) => [{
        minHeight: 46,
        borderRadius: 11,
        paddingHorizontal: 18,
        backgroundColor: bg,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 8,
        opacity: disabled ? 0.45 : pressed ? 0.8 : 1,
      }, style]}
    >
      {loading ? <ActivityIndicator color="#FFFFFF" size="small" /> : icon ? <Icon name={icon} color="#FFFFFF" size={18} /> : null}
      <Text style={{ color: '#FFFFFF', fontSize: 14, fontWeight: '750' }}>{title}</Text>
    </Pressable>
  );
};

export const Field = ({ label, hint, style, ...props }) => {
  const { colors } = useAppSettings();
  return (
    <View style={[{ gap: 6 }, style]}>
      {label ? <Text style={{ color: colors.textSecondary, fontSize: 12, fontWeight: '650' }}>{label}</Text> : null}
      <TextInput
        placeholderTextColor={colors.textTertiary}
        selectionColor={colors.primary}
        {...props}
        style={[{
          minHeight: 46,
          borderWidth: 1,
          borderColor: colors.borderLight,
          borderRadius: 10,
          paddingHorizontal: 13,
          paddingVertical: 10,
          backgroundColor: colors.bgInput,
          color: colors.text,
          fontSize: 14,
        }, props.style]}
      />
      {hint ? <Text style={{ color: colors.textTertiary, fontSize: 11, lineHeight: 16 }}>{hint}</Text> : null}
    </View>
  );
};

export const SegmentedControl = ({ options, value, onChange, compact = false }) => {
  const { colors } = useAppSettings();
  return (
    <View style={{ flexDirection: 'row', borderRadius: 11, padding: 3, backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border }}>
      {options.map((option) => {
        const selected = option.value === value;
        return (
          <Pressable
            key={option.value}
            onPress={() => onChange(option.value)}
            style={({ pressed }) => ({
              flex: option.flex === false ? undefined : 1,
              minHeight: compact ? 34 : 39,
              paddingHorizontal: 10,
              borderRadius: 8,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 6,
              backgroundColor: selected ? colors.bgCard : 'transparent',
              borderWidth: selected ? 1 : 0,
              borderColor: selected ? colors.borderLight : 'transparent',
              opacity: pressed ? 0.7 : 1,
            })}
          >
            {option.icon ? <Icon name={option.icon} size={16} color={selected ? colors.primary : colors.textSecondary} /> : null}
            <Text numberOfLines={1} style={{ color: selected ? colors.text : colors.textSecondary, fontSize: 12, fontWeight: selected ? '700' : '550' }}>
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
};

export const SectionCard = ({ title, icon, children, style, right }) => {
  const { colors } = useAppSettings();
  return (
    <View style={[{ backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 16, gap: 14 }, style]}>
      {title ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
          {icon ? <Icon name={icon} size={18} color={colors.primary} /> : null}
          <Text style={{ color: colors.text, fontSize: 15, fontWeight: '750', flex: 1 }}>{title}</Text>
          {right}
        </View>
      ) : null}
      {children}
    </View>
  );
};

export const StatusPill = ({ label, tone = 'neutral' }) => {
  const { colors } = useAppSettings();
  const map = {
    success: [colors.successBg, colors.successText],
    warning: [colors.warningBg, colors.warningText],
    error: [colors.errorBg, colors.errorText],
    info: [colors.infoBg, colors.infoText],
    neutral: [colors.bgElevated, colors.textSecondary],
  };
  const [backgroundColor, color] = map[tone] || map.neutral;
  return <View style={{ backgroundColor, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4 }}><Text style={{ color, fontSize: 10, fontWeight: '750' }}>{label}</Text></View>;
};
