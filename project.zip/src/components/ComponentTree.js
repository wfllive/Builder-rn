import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useProject } from '../store/projectStore';
import colors from '../theme/colors';

const ComponentTree = () => {
  const { currentProject, currentScreenId, selectedComponentId, selectComponent, getCurrentScreen } = useProject();
  const currentScreen = getCurrentScreen();

  if (!currentScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Дерево</Text>
        <Text style={styles.emptyText}>Нет активного экрана</Text>
      </View>
    );
  }

  const renderTreeNode = (component, depth = 0) => {
    const isSelected = selectedComponentId === component.id;
    const hasChildren = component.children && component.children.length > 0;
    const isContainer = ['LinearLayout', 'ScrollView', 'CardView'].includes(component.type);

    return (
      <View key={component.id}>
        <TouchableOpacity
          style={[
            styles.treeNode,
            isSelected && styles.selectedNode,
            { paddingLeft: 8 + depth * 16 },
          ]}
          onPress={() => selectComponent(component.id)}
          activeOpacity={0.7}
        >
          <Text style={styles.nodeIcon}>
            {isContainer ? (hasChildren ? '▼' : '▶') : '•'}
          </Text>
          <Text style={[styles.nodeText, isSelected && styles.selectedNodeText]}>
            {component.type}
          </Text>
          {component.props?.text && (
            <Text style={styles.nodePreview} numberOfLines={1}>
              "{component.props.text}"
            </Text>
          )}
        </TouchableOpacity>
        
        {hasChildren && component.children.map(child => renderTreeNode(child, depth + 1))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Дерево компонентов</Text>
      <ScrollView style={styles.tree} showsVerticalScrollIndicator={false}>
        {renderTreeNode(currentScreen.rootComponent)}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 200,
    backgroundColor: colors.surface,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.onSurface,
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 12,
    padding: 12,
    textAlign: 'center',
  },
  tree: {
    flex: 1,
  },
  treeNode: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingRight: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  selectedNode: {
    backgroundColor: colors.selection,
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
  },
  nodeIcon: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    marginRight: 6,
    width: 12,
  },
  nodeText: {
    fontSize: 12,
    color: colors.onSurface,
    fontWeight: '500',
  },
  selectedNodeText: {
    color: colors.primary,
    fontWeight: 'bold',
  },
  nodePreview: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    marginLeft: 6,
    flex: 1,
  },
});

export default ComponentTree;
