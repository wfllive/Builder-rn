import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { Icon, componentIcons } from './Icon';

const ComponentTree = ({ compact = false }) => {
  const { selectedComponentId, selectComponent, getCurrentScreen } = useProject();
  const { colors, language } = useAppSettings();
  const [collapsed, setCollapsed] = useState({});
  const styles = useMemo(() => createStyles(colors, compact), [colors, compact]);
  const screen = getCurrentScreen();

  const renderNode = (component, depth = 0) => {
    const selected = selectedComponentId === component.id;
    const hasChildren = Boolean(component.children?.length);
    const isCollapsed = collapsed[component.id];
    const icon = componentIcons[component.type] || { name: 'cube-outline', color: colors.textSecondary };
    return (
      <View key={component.id}>
        <Pressable
          onPress={() => selectComponent(component.id)}
          style={({ pressed }) => [
            styles.node,
            { paddingLeft: 9 + depth * 14 },
            selected && styles.selected,
            pressed && !selected && { backgroundColor: colors.bgElevated },
          ]}
        >
          <Pressable
            disabled={!hasChildren}
            onPress={() => setCollapsed((value) => ({ ...value, [component.id]: !value[component.id] }))}
            hitSlop={8}
            style={styles.chevron}
          >
            {hasChildren ? <Icon name={isCollapsed ? 'chevron-forward' : 'chevron-down'} size={12} color={colors.textTertiary} /> : null}
          </Pressable>
          <Icon name={icon.name} type={icon.type} size={14} color={selected ? colors.primary : icon.color || colors.textSecondary} />
          <Text style={[styles.nodeText, selected && styles.selectedText]} numberOfLines={1}>{component.type}</Text>
          {component.props?.text ? <Text style={styles.preview} numberOfLines={1}>{component.props.text}</Text> : null}
        </Pressable>
        {hasChildren && !isCollapsed ? component.children.map((child) => renderNode(child, depth + 1)) : null}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Icon name="git-branch-outline" size={16} color={colors.primary} />
        <Text style={styles.title}>{language === 'ru' ? 'Иерархия' : 'Hierarchy'}</Text>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingVertical: 5 }}>
        {screen ? renderNode(screen.rootComponent) : <Text style={styles.empty}>{language === 'ru' ? 'Экран не выбран' : 'No screen selected'}</Text>}
      </ScrollView>
    </View>
  );
};

const createStyles = (c, compact) => StyleSheet.create({
  container: { width: compact ? 176 : 210, backgroundColor: c.bgCard, borderRightWidth: 1, borderRightColor: c.border },
  header: { minHeight: 43, flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 11, borderBottomWidth: 1, borderBottomColor: c.border },
  title: { color: c.text, fontSize: 12, fontWeight: '750' },
  node: { minHeight: 35, paddingRight: 7, flexDirection: 'row', alignItems: 'center', gap: 6, borderLeftWidth: 2, borderLeftColor: 'transparent' },
  selected: { backgroundColor: c.selection, borderLeftColor: c.selectionBorder },
  selectedText: { color: c.primary, fontWeight: '750' },
  chevron: { width: 13, height: 25, alignItems: 'center', justifyContent: 'center' },
  nodeText: { color: c.text, fontSize: 10, fontFamily: 'monospace' },
  preview: { color: c.textTertiary, fontSize: 9, flex: 1 },
  empty: { color: c.textTertiary, fontSize: 11, padding: 12, textAlign: 'center' },
});

export default ComponentTree;
