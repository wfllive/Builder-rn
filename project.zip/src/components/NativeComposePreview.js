import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Icon } from './Icon';
import { useAppSettings } from '../store/appSettings';
import { isAvailable } from '../../modules/apt-manager/src';
import { renderPreviewPng } from '../utils/nativePreview';

/**
 * Live Android preview for the visual Compose model.
 *
 * The component tree is sent to AptManager, which creates and measures a real
 * Android View hierarchy on the device and returns its bitmap.  This is kept
 * deliberately separate from the editable design canvas: selection outlines,
 * drag targets and React Native approximations must never leak into Preview.
 *
 * Rendering is debounced and superseded requests are ignored. Consequently a
 * property change updates the preview automatically, without an APK build or
 * an emulator launch.
 */
const NativeComposePreview = ({
  project,
  screen,
  widthDp = 360,
  heightDp = 780,
  scroll = true,
  showChrome = true,
  placeholder,
  quality = 'high',
  isDark, // explicit light/dark override; undefined -> follow IDE theme
}) => {
  const { colors, resolvedTheme, language } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const [state, setState] = useState({ status: 'idle', uri: null, error: '' });
  const requestRef = useRef(0);
  const nativeReady = isAvailable();

  // Effective theme for the PREVIEW (independent of the IDE's own UI theme).
  const dark = typeof isDark === 'boolean' ? isDark : resolvedTheme === 'dark';
  const chrome = dark
    ? { device: '#141218', systemBar: '#141218', time: '#E2E8F0', canvas: '#141218', navBar: '#141218', gesture: '#94A3B8' }
    : { device: '#FFFFFF', systemBar: '#FFFFFF', time: '#111827', canvas: '#FFFBFE', navBar: '#FFFFFF', gesture: '#111827' };

  // Deep key for accurate change detection (tree + props + theme + explicit dark)
  const treeKey = useMemo(() => {
    try {
      return JSON.stringify({
        root: screen?.rootComponent,
        source: screen?.source,
        theme: project?.theme,
        bg: screen?.backgroundColor,
        vars: project?.variables,
        dark,
      });
    } catch (_) { return ''; }
  }, [screen?.rootComponent, screen?.source, project?.theme, screen?.backgroundColor, project?.variables, dark]);

  const render = async () => {
    if (!project || !screen?.rootComponent) return;
    if (!nativeReady) {
      setState({ status: 'unavailable', uri: null, error: '' });
      return;
    }
    const request = ++requestRef.current;
    setState((previous) => ({ ...previous, status: 'loading', error: '' }));

    const result = await renderPreviewPng(project, screen, {
      widthDp,
      heightPx: Math.round((heightDp || 780) * 2.75),
      isDark: dark,
      backgroundColor: screen.backgroundColor || (dark ? '#141218' : '#FFFBFE'),
      density: 2.75,
      simulateState: true,
      interactive: false,
    });

    if (request !== requestRef.current) return;

    if (result.success && result.dataUri) {
      setState({ status: 'ready', uri: result.dataUri, error: '' });
    } else {
      setState({ status: 'error', uri: null, error: result.output || 'Preview renderer failed' });
    }
  };

  useEffect(() => {
    if (!project || !screen) return undefined;
    // Professional debounce: avoids flicker on fast edits
    const timer = setTimeout(render, 140);
    return () => {
      clearTimeout(timer);
      requestRef.current += 1;
    };
  }, [project?.id, screen?.id, treeKey, widthDp, heightDp, dark, nativeReady]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!project || !screen) return placeholder || <View style={styles.empty} />;

  const preview = state.status === 'ready' ? (
    <Image
      accessibilityLabel="Live Android preview"
      source={{ uri: state.uri }}
      resizeMode="contain"
      style={[styles.image, { minHeight: Math.min(heightDp, 520) }]}
    />
  ) : (
    <View style={[styles.state, { minHeight: Math.min(heightDp, 360) }]}>
      {state.status === 'loading' || state.status === 'idle' ? <ActivityIndicator color={colors.primary} /> : null}
      {state.status === 'unavailable' ? <Icon name="phone-portrait-outline" size={25} color={colors.textTertiary} /> : null}
      {state.status === 'error' ? <Icon name="alert-circle-outline" size={25} color={colors.error} /> : null}
      <Text style={styles.stateTitle}>
        {state.status === 'loading' || state.status === 'idle'
          ? (language === 'ru' ? 'Обновляем Android preview…' : 'Updating Android preview…')
          : state.status === 'unavailable'
            ? (language === 'ru' ? 'Нужна новая development-сборка IDE' : 'A new IDE development build is required')
            : (language === 'ru' ? 'Не удалось отрисовать preview' : 'Could not render preview')}
      </Text>
      {state.status === 'unavailable' ? <Text style={styles.stateHint}>{language === 'ru' ? 'Модуль Android renderer появится после пересборки самого IDE.' : 'Rebuild the IDE once to include the Android renderer module.'}</Text> : null}
      {state.status === 'error' ? <Text selectable style={styles.stateHint}>{state.error}</Text> : null}
      {(state.status === 'error' || state.status === 'unavailable') ? (
        <Pressable onPress={render} style={styles.retry}>
          <Icon name="refresh-outline" size={14} color={colors.primary} />
          <Text style={styles.retryText}>{language === 'ru' ? 'Повторить' : 'Retry'}</Text>
        </Pressable>
      ) : null}
    </View>
  );

  const body = (
    <View style={[styles.device, { aspectRatio: (widthDp || 360) / (heightDp || 800), backgroundColor: chrome.device }]}>
      {showChrome ? (
        <View style={[styles.systemBar, { backgroundColor: chrome.systemBar }]}>
          <Text style={[styles.time, { color: chrome.time }]}>9:41</Text>
          <Icon name="battery-full" size={14} color={chrome.time} />
        </View>
      ) : null}
      <View style={[styles.canvas, { backgroundColor: chrome.canvas }]}>{preview}</View>
      {showChrome ? (
        <View style={[styles.navBar, { backgroundColor: chrome.navBar }]}>
          <View style={[styles.gesture, { backgroundColor: chrome.gesture }]} />
        </View>
      ) : null}
    </View>
  );

  // The bitmap already contains a fully measured Android hierarchy. Scrolling
  // belongs to the parent design surface, not to a second React Native canvas.
  return scroll ? <View style={styles.scroll}>{body}</View> : body;
};

const createStyles = (c) => StyleSheet.create({
  scroll: { flex: 1, backgroundColor: c.canvas, alignItems: 'center', padding: 12 },
  device: { width: '100%', maxWidth: 360, backgroundColor: '#FFFFFF', borderRadius: 26, borderWidth: 6, borderColor: '#111827', overflow: 'hidden' },
  systemBar: { height: 26, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFFFFF' },
  time: { color: '#111827', fontSize: 10, fontWeight: '700' },
  canvas: { flex: 1, minHeight: 0, backgroundColor: '#F8FAFC' },
  image: { width: '100%', flex: 1, alignSelf: 'stretch' },
  navBar: { height: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' },
  gesture: { width: 100, height: 4, borderRadius: 2, backgroundColor: '#111827' },
  empty: { minHeight: 180 },
  state: { width: '100%', alignItems: 'center', justifyContent: 'center', gap: 9, padding: 20 },
  stateTitle: { color: c.text, fontSize: 11, fontWeight: '700', textAlign: 'center' },
  stateHint: { color: c.textSecondary, fontSize: 9.5, lineHeight: 14, textAlign: 'center' },
  retry: { minHeight: 30, paddingHorizontal: 10, borderRadius: 7, borderWidth: 1, borderColor: c.primary, flexDirection: 'row', alignItems: 'center', gap: 5 },
  retryText: { color: c.primary, fontSize: 10, fontWeight: '700' },
});

export default NativeComposePreview;