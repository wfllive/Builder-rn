import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon } from './Icon';
import { useAppSettings } from '../store/appSettings';
import { renderPreviewPng } from '../utils/nativePreview';

/**
 * Native Compose preview component.
 *
 * Replaces the React Native <View> shadow tree that used to approximate
 * Jetpack Compose. The active screen is forwarded to the AptManager native
 * module, which builds a real Android View hierarchy, lays it out, draws it
 * into a Bitmap and returns the PNG. This is the "real" preview the user
 * asked for: what you see is what Android renders.
 */
const NativeComposePreview = ({
  project,
  screen,
  widthDp = 360,
  heightDp = 800,
  scroll = true,
  showChrome = true,
  placeholder,
}) => {
  const { colors, language, resolvedTheme } = useAppSettings();
  const [state, setState] = useState({ status: 'idle', dataUri: null, error: null });
  const tokenRef = useRef(0);
  const styles = useMemo(() => createStyles(colors), [colors]);

  useEffect(() => {
    if (!project || !screen) return undefined;
    const token = ++tokenRef.current;
    setState({ status: 'loading', dataUri: null, error: null });
    renderPreviewPng(project, screen, {
      widthDp,
      isDark: resolvedTheme === 'dark',
    })
      .then((result) => {
        if (token !== tokenRef.current) return;
        if (!result?.success) {
          setState({ status: 'error', dataUri: null, error: result?.output || 'Render failed' });
        } else {
          setState({ status: 'ready', dataUri: result.dataUri, error: null });
        }
      })
      .catch((error) => {
        if (token !== tokenRef.current) return;
        setState({ status: 'error', dataUri: null, error: error?.message || String(error) });
      });
  }, [project, screen, widthDp, resolvedTheme]);

  if (!project || !screen) {
    return placeholder || (
      <View style={styles.empty}>
        <Icon name="phone-portrait-outline" size={28} color={colors.textTertiary} />
        <Text style={styles.emptyText}>
          {language === 'ru' ? 'Нет открытого проекта' : 'No project is open'}
        </Text>
      </View>
    );
  }

  const aspect = (widthDp || 360) / (heightDp || 800);
  const body = (
    <View style={[styles.device, { aspectRatio: aspect }]}>
      {showChrome ? (
        <View style={styles.systemBar}>
          <Text style={styles.time}>9:41</Text>
          <Icon name="battery-full" size={13} color="#111827" />
        </View>
      ) : null}
      <View style={styles.canvas}>
        {state.status === 'loading' ? (
          <View style={styles.loading}>
            <ActivityIndicator color={colors.primary} />
            <Text style={styles.loadingText}>
              {language === 'ru' ? 'Рендерим нативный preview…' : 'Rendering native preview…'}
            </Text>
          </View>
        ) : null}
        {state.status === 'error' ? (
          <View style={styles.error}>
            <Icon name="alert-circle-outline" size={28} color={colors.error} />
            <Text style={styles.errorText}>{state.error}</Text>
          </View>
        ) : null}
        {state.status === 'ready' && state.dataUri ? (
          <Image
            source={{ uri: state.dataUri }}
            style={styles.image}
            resizeMode="stretch"
            fadeDuration={0}
          />
        ) : null}
      </View>
      {showChrome ? (
        <View style={styles.navBar}>
          <View style={styles.gesture} />
        </View>
      ) : null}
    </View>
  );

  if (!scroll) return body;
  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.scrollContent}
      maximumZoomScale={1.4}
      minimumZoomScale={0.5}
    >
      {body}
    </ScrollView>
  );
};

const createStyles = (c) => StyleSheet.create({
  scroll: { flex: 1, backgroundColor: c.canvas },
  scrollContent: { alignItems: 'center', padding: 12 },
  device: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#FFFFFF',
    borderRadius: 26,
    borderWidth: 6,
    borderColor: '#111827',
    overflow: 'hidden',
  },
  systemBar: {
    height: 26,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
  },
  time: { color: '#111827', fontSize: 9, fontWeight: '700' },
  canvas: { flex: 1, backgroundColor: '#F8FAFC' },
  image: { width: '100%', height: '100%' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 16 },
  loadingText: { color: '#475569', fontSize: 11 },
  error: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 6, padding: 16 },
  errorText: { color: '#B91C1C', fontSize: 11, textAlign: 'center' },
  navBar: { height: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' },
  gesture: { width: 100, height: 4, borderRadius: 2, backgroundColor: '#111827' },
  empty: { alignItems: 'center', justifyContent: 'center', gap: 8, padding: 24 },
  emptyText: { color: c.textSecondary, fontSize: 13 },
});

export default NativeComposePreview;
