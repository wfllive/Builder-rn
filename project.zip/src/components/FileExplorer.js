import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppSettings } from '../store/appSettings';
import { Icon } from './Icon';
import { listProjectFiles, buildFileTree } from '../utils/projectFiles';

const fileIcon = (ext) => {
  switch (ext) {
    case 'kt': return { name: 'logo-android', color: '#7C5CFF' };
    case 'kts': return { name: 'settings-outline', color: '#7C5CFF' };
    case 'xml': return { name: 'code-outline', color: '#E8863A' };
    case 'jsx': case 'js': return { name: 'logo-javascript', color: '#F0DB4F' };
    case 'json': return { name: 'braces-outline', color: '#F7C948' };
    case 'properties': return { name: 'settings-outline', color: '#7FB8E8' };
    case 'md': return { name: 'document-text-outline', color: '#7FB8E8' };
    default: return { name: 'document-outline', color: '#8B98AD' };
  }
};

/**
 * A VS Code-style file explorer sidebar. Lists the project's source files as a
 * collapsible tree; tapping a file opens it in the editor.
 */
const FileExplorer = ({ project, activePath, onOpenFile, onClose, width }) => {
  const { colors, language } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const [tree, setTree] = useState(null);
  const [expanded, setExpanded] = useState(() => new Set(['android', 'android/app', 'src', 'src/screens']));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const files = await listProjectFiles(project);
      setTree(buildFileTree(files));
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [project]);

  useEffect(() => { load(); }, [load]);

  const toggle = (path) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  };

  const renderNode = (node, depth) => {
    const isDir = node.isDir;
    if (isDir) {
      const isOpen = expanded.has(node.path);
      return (
        <View key={node.path || 'root'}>
          {node.path !== '' ? (
            <Pressable onPress={() => toggle(node.path)} style={[styles.row, { paddingLeft: 6 + depth * 14 }]}>
              <Icon name={isOpen ? 'chevron-down-outline' : 'chevron-forward-outline'} size={12} color={colors.textTertiary} />
              <Icon name="folder-outline" size={15} color="#E8A33D" />
              <Text style={styles.dirName} numberOfLines={1}>{node.name}</Text>
            </Pressable>
          ) : null}
          {isOpen ? node.children.map((c) => renderNode(c, depth + 1)) : null}
        </View>
      );
    }
    const active = activePath === node.path;
    const icon = fileIcon(node.ext);
    return (
      <Pressable
        key={node.path}
        onPress={() => onOpenFile(node.path)}
        style={[styles.row, { paddingLeft: 22 + depth * 14 }, active && styles.rowActive]}
      >
        <Icon name={icon.name} size={14} color={active ? colors.primary : icon.color} />
        <Text style={[styles.fileName, active && styles.fileNameActive]} numberOfLines={1}>{node.name}</Text>
      </Pressable>
    );
  };

  return (
    <SafeAreaView edges={['top', 'bottom']} style={[styles.root, width ? { width } : null]}>
      <View style={styles.head}>
        <Icon name="folder-open-outline" size={15} color={colors.primary} />
        <Text style={styles.headTitle}>{language === 'ru' ? 'Файлы проекта' : 'Project files'}</Text>
        <View style={{ flex: 1 }} />
        <Pressable onPress={onClose} style={styles.close}><Icon name="close" size={18} color={colors.textSecondary} /></Pressable>
      </View>
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
      ) : error ? (
        <View style={styles.center}><Text style={styles.error}>{error}</Text></View>
      ) : tree && tree.children.length ? (
        <ScrollView style={styles.scroll} contentContainerStyle={{ paddingBottom: 24 }}>
          {tree.children.map((c) => renderNode(c, 0))}
        </ScrollView>
      ) : (
        <View style={styles.center}><Text style={styles.error}>{language === 'ru' ? 'Файлы не найдены' : 'No files found'}</Text></View>
      )}
    </SafeAreaView>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, backgroundColor: c.bgCard, borderRightWidth: 1, borderRightColor: c.border },
  head: { minHeight: 44, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 8, borderBottomWidth: 1, borderBottomColor: c.border },
  headTitle: { color: c.text, fontSize: 12, fontWeight: '750' },
  close: { width: 30, height: 30, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  scroll: { flex: 1 },
  row: { minHeight: 32, flexDirection: 'row', alignItems: 'center', gap: 6, paddingRight: 8 },
  rowActive: { backgroundColor: c.primarySurface },
  dirName: { color: c.text, fontSize: 12, fontWeight: '650', flex: 1 },
  fileName: { color: c.textSecondary, fontSize: 12, flex: 1 },
  fileNameActive: { color: c.primary, fontWeight: '700' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  error: { color: c.textSecondary, fontSize: 11, textAlign: 'center' },
});

export default FileExplorer;
