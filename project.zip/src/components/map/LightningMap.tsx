import React, { useMemo } from 'react';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { StyleSheet } from 'react-native';
import { MAP_STYLES, ThemeKey } from '@/constants/config';
import { Strike } from '@/hooks/useStrikes';

type Props = {
  mapRef: React.RefObject<MapLibreGL.MapView>;
  cameraRef: React.RefObject<MapLibreGL.Camera>;
  strikes: Strike[];
  theme: ThemeKey;
  myPos: [number, number] | null;
  config: any;
  rain: any;
  alerts: any;
  advRadar: any;
};

export function LightningMap({ mapRef, cameraRef, strikes, theme, myPos, config, rain, alerts, advRadar }: Props) {
  const styleURL = MAP_STYLES[theme]?.url || MAP_STYLES.dark.url;

  const strikeGeoJSON = useMemo(() => ({
    type: 'FeatureCollection' as const,
    features: strikes.map(s => ({
      type: 'Feature' as const,
      id: s.id,
      geometry: { type: 'Point' as const, coordinates: [s.lon, s.lat] },
      properties: {
        ts: s.ts,
        age: Math.floor(Date.now()/1000 - s.ts),
        pol: s.ex.pol ?? 0,
      }
    }))
  }), [strikes]);

  const nowSec = Math.floor(Date.now()/1000);

  return (
    <MapLibreGL.MapView
      ref={mapRef}
      style={styles.map}
      styleURL={styleURL}
      logoEnabled={false}
      attributionEnabled={false}
      compassEnabled={false}
    >
      <MapLibreGL.Camera
        ref={cameraRef}
        defaultSettings={{
          centerCoordinate: [37.6, 55.75],
          zoomLevel: 3,
        }}
        minZoomLevel={2}
        maxZoomLevel={16}
      />

      {/* RainViewer raster overlay – only if url present (RainViewer mode).
          rainradar.ru is rendered via Skia overlay, not here */}
      {config.rain && rain.currentFrame?.url && (
        <MapLibreGL.RasterSource
          id="rain-radar"
          tileUrlTemplates={[rain.currentFrame.url]}
          tileSize={256}
          maxZoomLevel={12}
        >
          <MapLibreGL.RasterLayer
            id="rain-radar-layer"
            sourceID="rain-radar"
            style={{ rasterOpacity: (config.rainOpacity ?? 70)/100 }}
          />
        </MapLibreGL.RasterSource>
      )}

      {/* AdvRadar WMS placeholder - simple raster from meteolabs if available */}
      {config.advRadar && advRadar.timeValue ? (
        <MapLibreGL.RasterSource
          id="adv-radar"
          tileUrlTemplates={[
            // Example WMS tile proxy - user should replace with real endpoint + token
            // `https://example.com/wms?layers=${config.advRadarLayer}&time=${advRadar.timeValue}&bbox={bbox-epsg-3857}&width=256&height=256&srs=EPSG:3857&format=image/png&transparent=true`
            // Fallback empty - user to configure
          ]}
          tileSize={256}
        >
          <MapLibreGL.RasterLayer
            id="adv-radar-layer"
            sourceID="adv-radar"
            style={{ rasterOpacity: (config.advRadarOpacity ?? 70)/100 }}
          />
        </MapLibreGL.RasterSource>
      ) : null}

      {/* Strikes */}
      <MapLibreGL.ShapeSource
        id="strikes"
        shape={strikeGeoJSON}
        cluster={false}
      >
        <MapLibreGL.CircleLayer
          id="strike-circles"
          style={{
            circleRadius: [
              'interpolate', ['linear'], ['zoom'],
              3, 5,
              6, 7,
              10, 10,
              14, 14
            ],
            circleColor: [
              'case',
              ['<', ['-', nowSec, ['get', 'ts']], 120], '#ff1744',
              ['<', ['-', nowSec, ['get', 'ts']], 300], '#ff9100',
              ['<', ['-', nowSec, ['get', 'ts']], 600], '#ffeb3b',
              ['<', ['-', nowSec, ['get', 'ts']], 1200], '#00e5ff',
              ['<', ['-', nowSec, ['get', 'ts']], 2400], '#7c4dff',
              ['<', ['-', nowSec, ['get', 'ts']], 5400], '#9e9e9e',
              '#455a64'
            ],
            circleStrokeColor: '#ffffff',
            circleStrokeWidth: 1.5,
            circleOpacity: 0.95,
            circlePitchAlignment: 'map',
          }}
        />
        {/* lightning bolt symbol could be SymbolLayer with icon, simplified to circle */}
      </MapLibreGL.ShapeSource>

      {/* My position */}
      {myPos && (
        <MapLibreGL.ShapeSource
          id="mypos"
          shape={{
            type: 'Feature',
            geometry: { type: 'Point', coordinates: [myPos[1], myPos[0]] },
            properties: {}
          }}
        >
          <MapLibreGL.CircleLayer
            id="mypos-outer"
            style={{
              circleRadius: 20,
              circleColor: 'rgba(59,130,246,0.15)',
              circleStrokeColor: 'rgba(59,130,246,0.5)',
              circleStrokeWidth: 2,
            }}
          />
          <MapLibreGL.CircleLayer
            id="mypos-inner"
            style={{
              circleRadius: 7,
              circleColor: '#3b82f6',
              circleStrokeColor: '#ffffff',
              circleStrokeWidth: 2,
            }}
          />
        </MapLibreGL.ShapeSource>
      )}

      {/* Alerts markers */}
      {config.alerts && alerts.allRegions?.length ? (
        <MapLibreGL.ShapeSource
          id="alerts"
          shape={{
            type: 'FeatureCollection',
            features: alerts.allRegions.map((r:any)=> ({
              type: 'Feature',
              geometry: { type: 'Point', coordinates: [r.lon, r.lat] },
              properties: { id: r.id, level: r.level, name: r.name }
            }))
          }}
          onPress={(e)=> {
            const f = e.features[0];
            if (f?.properties?.id) {
              const reg = alerts.allRegions.find((x:any)=> x.id === f.properties.id);
              if (reg) alerts.selectRegion(reg);
            }
          }}
        >
          <MapLibreGL.CircleLayer
            id="alert-circles"
            style={{
              circleRadius: 10,
              circleColor: [
                'match', ['get','level'],
                'red', '#ef4444',
                'orange', '#f97316',
                /* other */ '#eab308'
              ],
              circleStrokeColor: '#fff',
              circleStrokeWidth: 2,
              circleOpacity: 0.9,
            }}
          />
        </MapLibreGL.ShapeSource>
      ) : null}

      <MapLibreGL.UserLocation visible={false} />
    </MapLibreGL.MapView>
  );
}

const styles = StyleSheet.create({
  map: { flex: 1 },
});
