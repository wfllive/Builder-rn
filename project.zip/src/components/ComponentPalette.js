import React, { useMemo, useRef } from 'react';
import { PanResponder, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon, componentIcons } from './Icon';
import { componentTypes } from '../utils/defaultProject';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';

const categoryDefinitions = [
  { ru: 'Макеты', en: 'Layouts', items: ['LinearLayout', 'ScrollView', 'CardView'] },
  { ru: 'Базовые', en: 'Basic', items: ['TextView', 'Button', 'EditText', 'ImageView'] },
  { ru: 'Управление', en: 'Controls', items: ['CheckBox', 'Switch', 'ProgressBar'] },
  { ru: 'Встраивание', en: 'Embedded', items: ['Divider', 'Spacer', 'WebView', 'MapView'] },
];

const DraggableItem = ({ typeKey, onAdd, onDragStart, onDragMove, onDrop, styles, colors }) => {
  const definition = componentTypes[typeKey];
  const icon = componentIcons[typeKey] || { name: 'cube-outline', color: colors.textSecondary };
  const dragging = useRef(false);
  const responder = useMemo(() => PanResponder.create({
    onMoveShouldSetPanResponder: (_, gesture) => Math.abs(gesture.dx) > 9 && Math.abs(gesture.dx) > Math.abs(gesture.dy),
    onPanResponderGrant: (_, gesture) => {
      dragging.current = true;
      onDragStart?.(typeKey, { x: gesture.x0, y: gesture.y0 });
    },
    onPanResponderMove: (_, gesture) => onDragMove?.(typeKey, { x: gesture.moveX, y: gesture.moveY }),
    onPanResponderRelease: (_, gesture) => {
      onDrop?.(typeKey, { x: gesture.moveX, y: gesture.moveY });
      setTimeout(() => { dragging.current = false; }, 80);
    },
    onPanResponderTerminate: () => {
      dragging.current = false;
      onDrop?.(null, null);
    },
  }), [onDragMove, onDragStart, onDrop, typeKey]);

  return (
    <View {...responder.panHandlers}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`Add ${definition.label}`}
        onPress={() => !dragging.current && onAdd(typeKey)}
        style={({ pressed }) => [styles.item, pressed && styles.itemPressed]}
      >
        <View style={[styles.itemIcon, { backgroundColor: `${icon.color || colors.primary}18` }]}>
          <Icon name={icon.name} type={icon.type} size={17} color={icon.color || colors.primary} />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.itemLabel} numberOfLines={1}>{definition.label}</Text>
          <Text style={styles.itemType} numberOfLines={1}>{definition.isContainer ? 'Container' : typeKey}</Text>
        </View>
        <Icon name="add-circle-outline" size={17} color={colors.textTertiary} />
      </Pressable>
    </View>
  );
};

const ComponentPalette = ({ onDragStart, onDragMove, onDrop, compact = false }) => {
  const { addComponent } = useProject();
  const { colors, language, t } = useAppSettings();
  const styles = useMemo(() => createStyles(colors, compact), [colors, compact]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Icon name="shapes-outline" size={17} color={colors.primary} />
        <Text style={styles.headerText}>{t('components')}</Text>
        <Text style={styles.dragHint}>{language === 'ru' ? 'Перетащите' : 'Drag'}</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} nestedScrollEnabled>
        {categoryDefinitions.map((category) => (
          <View key={category.en} style={styles.category}>
            <Text style={styles.categoryTitle}>{category[language]}</Text>
            {category.items.map((typeKey) => (
              <DraggableItem
                key={typeKey}
                typeKey={typeKey}
                onAdd={addComponent}
                onDragStart={onDragStart}
                onDragMove={onDragMove}
                onDrop={onDrop}
                styles={styles}
                colors={colors}
              />
            ))}
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const createStyles = (c, compact) => StyleSheet.create({
  container: { flex: 1, backgroundColor: c.bgCard },
  header: { minHeight: 48, flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 13, borderBottomWidth: 1, borderBottomColor: c.border },
  headerText: { color: c.text, fontSize: 13, fontWeight: '750', flex: 1 },
  dragHint: { color: c.textTertiary, fontSize: 9, textTransform: 'uppercase', letterSpacing: 0.6 },
  content: { paddingVertical: 7, paddingBottom: 24 },
  category: { paddingVertical: 6 },
  categoryTitle: { color: c.textTertiary, fontSize: 10, fontWeight: '800', letterSpacing: 0.7, textTransform: 'uppercase', paddingHorizontal: 13, marginBottom: 4 },
  item: { minHeight: compact ? 43 : 49, paddingHorizontal: 11, paddingVertical: 6, marginHorizontal: 6, borderRadius: 9, flexDirection: 'row', alignItems: 'center', gap: 9 },
  itemPressed: { backgroundColor: c.bgElevated },
  itemIcon: { width: compact ? 30 : 34, height: compact ? 30 : 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  itemLabel: { color: c.text, fontSize: 12, fontWeight: '650' },
  itemType: { color: c.textTertiary, fontSize: 9, marginTop: 1 },
});

export default ComponentPalette;
