import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Icon, componentIcons } from './Icon';
import { componentTypes } from '../utils/defaultProject';
import { useProject } from '../store/projectStore';
import colors from '../theme/colors';
import { generateId } from '../utils/generateId';

const categories = [
  { name: 'Layouts', items: ['LinearLayout', 'ScrollView', 'CardView'] },
  { name: 'Виджеты', items: ['TextView', 'Button', 'EditText', 'ImageView'] },
  { name: 'Контролы', items: ['CheckBox', 'Switch', 'ProgressBar'] },
  { name: 'Прочее', items: ['Divider', 'Spacer', 'WebView', 'MapView'] },
];

const ComponentPalette = () => {
  const { currentProject, selectedComponentId, updateComponentTree, selectComponent, getCurrentScreen } = useProject();
  const currentScreen = getCurrentScreen();

  const findComponent = (root, id) => {
    if (!root) return null;
    if (root.id === id) return root;
    if (root.children) for (const c of root.children) { const f = findComponent(c, id); if (f) return f; }
    return null;
  };

  const findParent = (root, id, parent = null) => {
    if (root.id === id) return parent;
    if (root.children) for (const c of root.children) { const f = findParent(c, id, root); if (f) return f; }
    return null;
  };

  const handleAdd = (typeKey) => {
    if (!currentScreen) return;
    const def = componentTypes[typeKey];
    if (!def) return;

    const newComp = { id: generateId(), type: typeKey, props: { ...def.defaultProps }, children: [] };

    let targetId = selectedComponentId || currentScreen.rootComponent.id;
    let target = findComponent(currentScreen.rootComponent, targetId);
    const targetDef = componentTypes[target?.type];

    if (!targetDef?.isContainer) {
      const parent = findParent(currentScreen.rootComponent, targetId);
      if (parent) { target = parent; targetId = parent.id; }
      else { target = currentScreen.rootComponent; targetId = currentScreen.rootComponent.id; }
    }

    const addTo = (comp) => {
      if (comp.id === targetId) return { ...comp, children: [...(comp.children || []), newComp] };
      if (comp.children) return { ...comp, children: comp.children.map(addTo) };
      return comp;
    };

    updateComponentTree(addTo(currentScreen.rootComponent));
    selectComponent(newComp.id);
  };

  return (
    <View style={st.container}>
      <View style={st.head}>
        <Icon name="cube-outline" size={16} color={colors.primary} />
        <Text style={st.headText}>Компоненты</Text>
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        {categories.map(cat => (
          <View key={cat.name} style={st.cat}>
            <Text style={st.catTitle}>{cat.name}</Text>
            {cat.items.map(typeKey => {
              const def = componentTypes[typeKey];
              if (!def) return null;
              const icon = componentIcons[typeKey] || { name: 'cube-outline', type: 'ionicons', color: colors.textSecondary };
              return (
                <TouchableOpacity key={typeKey} style={st.item} onPress={() => handleAdd(typeKey)} activeOpacity={0.6}>
                  <View style={[st.itemIcon, { backgroundColor: icon.color + '15' }]}>
                    <Icon name={icon.name} size={16} color={icon.color} type={icon.type || 'ionicons'} />
                  </View>
                  <Text style={st.itemLabel}>{def.label}</Text>
                  {def.isContainer && <View style={st.badge}><Text style={st.badgeText}>+</Text></View>}
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bgCard },
  head: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 14, borderBottomWidth: 1, borderBottomColor: colors.border },
  headText: { fontSize: 14, fontWeight: '700', color: colors.text },
  cat: { paddingTop: 8, paddingBottom: 4, borderBottomWidth: 1, borderBottomColor: colors.border },
  catTitle: { fontSize: 11, fontWeight: '800', color: colors.textTertiary, textTransform: 'uppercase', letterSpacing: 0.5, paddingHorizontal: 14, marginBottom: 4 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: 9, paddingHorizontal: 14, gap: 10 },
  itemIcon: { width: 30, height: 30, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  itemLabel: { fontSize: 13, color: colors.text, fontWeight: '500', flex: 1 },
  badge: { backgroundColor: colors.primarySurface, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  badgeText: { fontSize: 10, fontWeight: '800', color: colors.primary },
});

export default ComponentPalette;
