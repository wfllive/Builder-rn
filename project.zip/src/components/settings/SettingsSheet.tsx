import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet, ScrollView, Switch } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export function SettingsSheet({ visible, onClose, config, updateConfig, toggle, rain, alerts, advRadar }: any) {
  const insets = useSafeAreaInsets();
  const Row = ({ label, value, onValueChange }:{label:string; value:boolean; onValueChange:(v:boolean)=>void}) => (
    <View style={s.row}>
      <Text style={s.label}>{label}</Text>
      <Switch value={value} onValueChange={onValueChange} trackColor={{false:'#334155', true:'#2563eb'}} thumbColor="#fff" />
    </View>
  );
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={s.backdrop} onPress={onClose} />
      <View style={[s.sheet, { paddingBottom: insets.bottom + 16 }]}>
        <Text style={s.title}>Настройки</Text>
        <ScrollView>
          <Row label="Анимация молний" value={config.anim} onValueChange={()=>toggle('anim')} />
          <Row label="Звук" value={config.sound} onValueChange={()=>toggle('sound')} />
          <Row label="Уведомления рядом" value={config.nearby} onValueChange={()=>toggle('nearby')} />
          <Row label="Не гасить экран" value={config.wake} onValueChange={()=>toggle('wake')} />
          <View style={s.sep} />
          <Text style={s.sec}>Радар осадков</Text>
          <Row label="Включить радар" value={config.rain} onValueChange={()=>toggle('rain')} />
          <Text style={s.hint}>Кадров: {rain.frames?.length ?? 0}</Text>

          <View style={s.sep} />
          <Text style={s.sec}>Метеопредупреждения</Text>
          <Row label="Показывать алерты" value={config.alerts} onValueChange={()=>toggle('alerts')} />

          <View style={s.sep} />
          <Text style={s.sec}>NowCast</Text>
          <Row label="Продвинутый радар" value={config.advRadar} onValueChange={()=>toggle('advRadar')} />
          <Text style={s.hint}>Кадров: {advRadar.times?.length ?? 0}</Text>

          <View style={s.sep} />
          <Text style={s.sec}>Время жизни молний: {config.life} мин</Text>
          <View style={s.lifeRow}>
            {[15,30,60,120,240].map(v=>(
              <Pressable key={v} onPress={()=>updateConfig('life', v)} style={[s.lifeBtn, config.life===v && s.lifeBtnActive]}>
                <Text style={[s.lifeTxt, config.life===v && s.lifeTxtActive]}>{v}</Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
        <Pressable onPress={onClose} style={s.closeBtn}><Text style={s.closeTxt}>Закрыть</Text></Pressable>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  backdrop: { flex:1, backgroundColor:'rgba(0,0,0,0.4)' },
  sheet: { position:'absolute', left:0, right:0, bottom:0, backgroundColor:'#0b1220', borderTopLeftRadius:20, borderTopRightRadius:20, padding:16, maxHeight:'80%' },
  title: { color:'#fff', fontSize:18, fontWeight:'800', marginBottom:12 },
  sec: { color:'#9ca3af', fontSize:13, marginTop:4, marginBottom:6, fontWeight:'600' },
  row: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingVertical:10 },
  label: { color:'#e5e7eb', fontSize:15 },
  hint: { color:'#6b7280', fontSize:12, marginBottom:6 },
  sep: { height:1, backgroundColor:'#1f2937', marginVertical:8 },
  lifeRow: { flexDirection:'row', gap:8, flexWrap:'wrap' },
  lifeBtn: { paddingHorizontal:14, paddingVertical:8, borderRadius:10, backgroundColor:'#1e293b' },
  lifeBtnActive: { backgroundColor:'#2563eb' },
  lifeTxt: { color:'#cbd5e1' },
  lifeTxtActive: { color:'#fff', fontWeight:'700' },
  closeBtn: { marginTop:12, backgroundColor:'#1e293b', padding:14, borderRadius:12, alignItems:'center' },
  closeTxt: { color:'#fff', fontWeight:'700' },
});
