import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet } from 'react-native';
import { MAP_STYLES, ThemeKey } from '@/constants/config';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export function ThemeSheet({ visible, current, onClose, onSelect }:{visible:boolean; current:ThemeKey; onClose:()=>void; onSelect:(t:ThemeKey)=>void}) {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={st.backdrop} onPress={onClose} />
      <View style={[st.card, { paddingBottom: insets.bottom + 16 }]}>
        <Text style={st.title}>Тема карты</Text>
        {(Object.keys(MAP_STYLES) as ThemeKey[]).map(k => (
          <Pressable key={k} onPress={()=>onSelect(k)} style={[st.item, current===k && st.itemActive]}>
            <Text style={[st.itemText, current===k && st.itemTextActive]}>{MAP_STYLES[k].name}</Text>
          </Pressable>
        ))}
        <Pressable onPress={onClose} style={st.close}><Text style={st.closeText}>Закрыть</Text></Pressable>
      </View>
    </Modal>
  );
}
const st = StyleSheet.create({
  backdrop:{ flex:1, backgroundColor:'rgba(0,0,0,0.5)' },
  card:{ position:'absolute', left:16, right:16, bottom:24, backgroundColor:'#0b1220', borderRadius:18, padding:16 },
  title:{ color:'#fff', fontSize:16, fontWeight:'700', marginBottom:10 },
  item:{ padding:12, borderRadius:10, backgroundColor:'#111827', marginBottom:8 },
  itemActive:{ backgroundColor:'#2563eb' },
  itemText:{ color:'#d1d5db' },
  itemTextActive:{ color:'#fff', fontWeight:'700' },
  close:{ marginTop:6, alignItems:'center', padding:10 },
  closeText:{ color:'#9ca3af' },
});
