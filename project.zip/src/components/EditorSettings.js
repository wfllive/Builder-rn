import React, { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useAppSettings } from '../store/appSettings';
import { SectionCard, SegmentedControl } from './AppUI';
import { Icon } from './Icon';

/**
 * Settings panel for the CodeMirror IDE editor: font size, indentation,
 * word wrap, autocomplete, the symbol toolbar, auto-save and the status bar.
 * Everything applies live — settings are persisted via the app settings store.
 */
const EditorSettings = ({ onClose }) => {
  const { colors, language, editor, setEditorSetting } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const ru = language === 'ru';
  const t = (ruKey, enKey) => (ru ? ruKey : enKey);

  const toggle = (key) => () => setEditorSetting(key, !editor[key]);
  const fontSize = editor.fontSize || 15;
  const setFontSize = (delta) => () => {
    const next = Math.max(9, Math.min(28, fontSize + delta));
    setEditorSetting('fontSize', next);
  };

  const Row = ({ label, desc, onPress, value, options, right }) => (
    <Pressable onPress={onPress} style={styles.row} disabled={!onPress}>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowLabel}>{label}</Text>
        {desc ? <Text style={styles.rowDesc}>{desc}</Text> : null}
      </View>
      {right || (options
        ? <SegmentedControl compact value={value} onChange={onPress} options={options} />
        : <View style={[styles.switch, value && styles.switchOn]}><View style={[styles.knob, value && styles.knobOn]} /></View>)}
    </Pressable>
  );

  return (
    <View style={styles.root}>
      <View style={styles.head}>
        <View style={styles.headIcon}><Icon name="options-outline" size={18} color={colors.primary} /></View>
        <Text style={styles.headTitle}>{t('Настройки редактора', 'Editor settings')}</Text>
        <View style={{ flex: 1 }} />
        <Pressable onPress={onClose} style={styles.close}><Icon name="close" size={20} color={colors.textSecondary} /></Pressable>
      </View>
      <ScrollView style={styles.scroll} contentContainerStyle={{ padding: 12, gap: 10 }}>
        <SectionCard title={t('Шрифт', 'Font')} icon="text-outline">
          <Row
            label={t('Размер шрифта', 'Font size')}
            desc={t('Применяется и к коду, и к номерам строк', 'Applies to code and line numbers')}
            right={(
              <View style={styles.stepper}>
                <Pressable onPress={setFontSize(-1)} style={styles.stepBtn}><Icon name="remove" size={17} color={colors.text} /></Pressable>
                <Text style={styles.stepValue}>{fontSize}</Text>
                <Pressable onPress={setFontSize(1)} style={styles.stepBtn}><Icon name="add" size={17} color={colors.text} /></Pressable>
              </View>
            )}
          />
        </SectionCard>

        <SectionCard title={t('Отступы', 'Indentation')} icon="code-outline">
          <Row
            label={t('Размер табуляции', 'Tab size')}
            value={String(editor.tabSize)}
            onPress={(v) => setEditorSetting('tabSize', Number(v))}
            options={[{ value: '2', label: '2' }, { value: '4', label: '4' }, { value: '8', label: '8' }]}
          />
          <Row
            label={t('Пробелы вместо табуляции', 'Spaces instead of tabs')}
            desc={editor.spacesForTab ? t('Tab вставляет пробелы', 'Tab inserts spaces') : t('Tab вставляет символ табуляции', 'Tab inserts a tab character')}
            value={editor.spacesForTab}
            onPress={toggle('spacesForTab')}
          />
        </SectionCard>

        <SectionCard title={t('Вид', 'View')} icon="color-wand-outline">
          <Row
            label={t('Перенос длинных строк', 'Word wrap')}
            desc={t('Переносить строки, не помещающиеся по ширине', 'Wrap lines wider than the editor')}
            value={editor.wordWrap}
            onPress={toggle('wordWrap')}
          />
          <Row
            label={t('Панель статуса', 'Status bar')}
            desc={t('Строка, столбец, язык — как в VS Code', 'Line, column, language — VS Code style')}
            value={editor.showStatusBar}
            onPress={toggle('showStatusBar')}
          />
        </SectionCard>

        <SectionCard title={t('Редактирование', 'Editing')} icon="flash-outline">
          <Row
            label={t('Автодополнение', 'Autocomplete')}
            desc={t('Подсказки ключевых слов и Compose-сниппеты', 'Keyword hints and Compose snippets')}
            value={editor.completion !== false}
            onPress={toggle('completion')}
          />
          <Row
            label={t('Панель инструментов', 'Symbol toolbar')}
            desc={t('Кнопки скобок, отмены и команд над клавиатурой', 'Bracket, undo and command keys above the keyboard')}
            value={editor.hotkeys !== false}
            onPress={toggle('hotkeys')}
          />
          <Row
            label={t('Автосохранение', 'Auto-save')}
            desc={t('Автоматически сохраняет код на диск', 'Automatically saves code to disk')}
            value={editor.autoSave}
            onPress={toggle('autoSave')}
          />
        </SectionCard>

        <SectionCard title={t('Проверка кода', 'Code analysis')} icon="shield-checkmark-outline">
          <Row
            label={t('Компилятор после сохранения', 'Compiler check after save')}
            desc={t('Фоновой запуск compileDebugKotlin — ошибки сами появятся в «Проблемах», ничего запускать не нужно', 'Runs compileDebugKotlin in the background — compiler errors appear in Problems automatically, nothing to run')}
            value={editor.autoCheck !== false}
            onPress={toggle('autoCheck')}
          />
        </SectionCard>
      </ScrollView>
    </View>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { width: '100%', maxHeight: 580, backgroundColor: c.bgCard, borderRadius: 16, overflow: 'hidden' },
  head: { minHeight: 52, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9, borderBottomWidth: 1, borderBottomColor: c.border },
  headIcon: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface },
  headTitle: { color: c.text, fontSize: 14, fontWeight: '750' },
  close: { width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  scroll: { flexShrink: 1 },
  row: { minHeight: 46, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 10 },
  rowLabel: { color: c.text, fontSize: 13, fontWeight: '650' },
  rowDesc: { color: c.textTertiary, fontSize: 10, marginTop: 2, paddingRight: 10 },
  switch: { width: 42, height: 24, borderRadius: 12, backgroundColor: c.border, padding: 2 },
  switchOn: { backgroundColor: c.primary },
  knob: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#FFFFFF' },
  knobOn: { transform: [{ translateX: 18 }] },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.bgElevated, borderRadius: 9, paddingHorizontal: 4, paddingVertical: 3, borderWidth: 1, borderColor: c.border },
  stepBtn: { width: 28, height: 26, borderRadius: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bgCard },
  stepValue: { color: c.text, fontSize: 13, fontWeight: '750', minWidth: 20, textAlign: 'center', fontFamily: 'monospace' },
});

export default EditorSettings;