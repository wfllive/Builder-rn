import React
{ useMemo
useRef } from 'react';
import { PanResponder
Pressable
Text
View } from 'react-native';
import { Icon } from './Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
const dimension = (value
fallback) => {
  if (value === 'match_parent') return '100%';
  if (value === 'wrap_content' || value == null) return fallback;
  return value;
};
const WidgetRenderer = ({
  component
  onSelect
  onEdit
  onRegisterDropZone
  onComponentDragStart
  onComponentDragMove
  onComponentDrop
  dropTargetId
  depth = 0
}) => {
  const { selectedComponentId } = useProject();
  const { colors } = useAppSettings();
  const styles = useMemo(() => /* styles removed */(colors)
[colors]);
  const viewRef = useRef(null);
  if (!component) return null;
  const p = component.props || {};
  const selected = selectedComponentId === component.id;
  const container = ['Column'
'Row'
'Box'
'LazyColumn'
'Card'
'ElevatedCard'
'Scaffold'].includes(component.type);
  const isDropTarget = dropTargetId === component.id;
  const measure = () => {
    if (!container) return;
    requestAnimationFrame(() => viewRef.current?.measureInWindow?.((x
y
width
height) => {
      onRegisterDropZone?.(component.id
{ x
y
width
height
depth });
    }));
  };
  const dragResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true
    onMoveShouldSetPanResponder: () => true
    onPanResponderGrant: (event
gesture) => onComponentDragStart?.(component.id
{ x: gesture.x0
y: gesture.y0 })
    onPanResponderMove: (event
gesture) => onComponentDragMove?.(component.id
{ x: gesture.moveX
y: gesture.moveY })
    onPanResponderRelease: (event
gesture) => onComponentDrop?.(component.id
{ x: gesture.moveX
y: gesture.moveY })
    onPanResponderTerminate: () => onComponentDrop?.(component.id
null)
  })
[component.id
onComponentDragStart
onComponentDragMove
onComponentDrop]);
  const childProps = {
    onSelect
onEdit
onRegisterDropZone
onComponentDragStart
onComponentDragMove
    onComponentDrop
dropTargetId
  };
  const children = () => component.children?.length
    ? component.children.map((child) => <WidgetRenderer key={child.id} component={child} depth={depth + 1} {...childProps} />)
    : <View className="p-4"><Icon name="add-outline" size={14} color={colors.textTertiary} /><Text className="p-4">Drop components here</Text></View>;
  const render = () => {
    switch (component.type) {
      case 'Column':
        return <View style={{ minHeight: depth ? 45 : 420
width: dimension(p.width
undefined)
padding: p.padding ?? 8
flexDirection: 'column'
gap: 4
backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'Row':
        return <View style={{ minHeight: 45
width: dimension(p.width
undefined)
padding: p.padding ?? 8
flexDirection: 'row'
alignItems: 'center'
gap: Number(p.spacing) || 8
backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'Box':
        return <View style={{ minHeight: 60
width: dimension(p.width
undefined)
padding: p.padding ?? 8
backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }}>{children()}</View>;
      case 'LazyColumn':
        return <View style={[className="containerPreview
{ minHeight: Number(p.height) || 90
backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor }]}>{children()}</View>;
      case 'Card':
        return <View style={[className="card
{ padding: p.padding ?? 14
borderRadius: p.borderRadius ?? 12
backgroundColor: p.backgroundColor || '#FFFFFF' }]}>{children()}</View>;
      case 'ElevatedCard':
        return <View style={[className="elevatedCard
{ padding: p.padding ?? 14
borderRadius: p.borderRadius ?? 12
backgroundColor: p.backgroundColor || '#FFFFFF' }]}>{children()}</View>;
      case 'Scaffold':
        return (
          <View style={{ flex: 1
minHeight: depth ? 60 : 400
backgroundColor: p.backgroundColor || '#F8FAFC' }}>
            {p.topBar ? (
              <View className="p-4">
                <Text className="p-4">{p.topBar.props?.title || 'MyApp'}</Text>
              </View>
            ) : null}
            <View style={{ flex: 1
padding: 8 }}>
              {children()}
            </View>
          </View>
        );
      case 'Text':
        return <Text style={{ width: dimension(p.width
undefined)
padding: p.padding ?? 4
fontSize: Number(p.textSize) || 16
color: p.textColor || '#111827'
fontWeight: p.textStyle === 'bold' ? '700' : '400'
fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal'
textAlign: p.textAlign === 'center' ? 'center' : p.textAlign === 'end' ? 'right' : 'left' }}>{p.text || 'Text'}</Text>;
      case 'Button': {
        const btnText = p.text || component.children?.find(c => c.type === 'Text')?.props?.text || 'Button';
        return <View style={[className="button
{ width: dimension(p.width
undefined)
padding: p.padding ?? 12
borderRadius: p.borderRadius ?? 9
backgroundColor: p.backgroundColor || '#4F46E5' }]}><Text style={{ color: p.textColor || '#FFFFFF'
fontSize: Number(p.textSize) || 15
fontWeight: '700' }}>{btnText}</Text></View>;
      }
      case 'OutlinedButton': {
        const btnText = p.text || component.children?.find(c => c.type === 'Text')?.props?.text || 'OutlinedButton';
        return <View style={[className="outlinedButton
{ width: dimension(p.width
undefined)
padding: p.padding ?? 12
borderRadius: p.borderRadius ?? 9 }]}><Text style={{ color: p.textColor || '#4F46E5'
fontSize: Number(p.textSize) || 15
fontWeight: '700' }}>{btnText}</Text></View>;
      }
      case 'OutlinedTextField':
        return <View style={[className="input
{ width: dimension(p.width
'100%')
padding: p.padding ?? 12
borderRadius: p.borderRadius ?? 9
backgroundColor: p.backgroundColor || '#FFFFFF' }]}><Text style={{ color: p.text ? p.textColor || '#111827' : '#6B7280'
fontSize: Number(p.textSize) || 15 }}>{p.text || p.hint || 'Input'}</Text></View>;
      case 'Image':
        return <View style={[className="media
{ width: dimension(p.width
110)
height: dimension(p.height
110)
borderRadius: p.borderRadius || 8
backgroundColor: p.backgroundColor || '#E5E7EB' }]}><Icon name="image-outline" size={32} color="#64748B" /><Text className="p-4">Image</Text></View>;
      case 'Checkbox':
        return <View className="p-4"><Icon name={p.checked ? 'checkbox' : 'square-outline'} size={22} color={p.checked ? '#4F46E5' : '#64748B'} /><Text style={{ color: p.textColor || '#111827'
fontSize: Number(p.textSize) || 15 }}>{p.text || 'Checkbox'}</Text></View>;
      case 'Switch':
        return <View className="p-4"><Text style={{ color: p.textColor || '#111827'
fontSize: 15
flex: 1 }}>{p.text || 'Switch'}</Text><View style={[className="switchTrack
{ backgroundColor: p.checked ? '#4F46E5' : '#94A3B8' }]}><View style={[className="switchKnob
p.checked && { alignSelf: 'flex-end' }]} /></View></View>;
      case 'LinearProgressIndicator':
        return <View className="p-4"><View style={{ width: `${Math.min(100
(Number(p.progress) || 0) <= 1 ? (Number(p.progress) || 0) * 100 : Number(p.progress) || 0)}%`
height: '100%'
borderRadius: 4
backgroundColor: p.color || '#4F46E5' }} /></View>;
      case 'CircularProgressIndicator':
        return <View style={[className="circular
{ width: Number(p.width) || 48
height: Number(p.height) || 48
borderColor: p.color || '#4F46E5' }]} />;
      case 'HorizontalDivider':
        return <View style={{ height: Number(p.height) || 1
backgroundColor: p.color || '#CBD5E1'
marginVertical: Number(p.margin) || 8 }} />;
      case 'Spacer':
        return <View style={[className="spacer
{ height: Number(p.height) || 16 }]}><Text className="p-4">Spacer · {Number(p.height) || 16}</Text></View>;
      case 'WebView':
        return <View style={[className="embed
{ height: Number(p.height) || 180 }]}><Icon name="globe-outline" size={30} color="#0E7490" /><Text className="p-4">Web</Text><Text className="p-4" numberOfLines={1}>{p.url}</Text></View>;
      case 'Icon':
        return <View className="p-4"><Icon name="star-outline" size={Number(p.size) || 28} color={p.tint || '#4F46E5'} /><Text className="p-4">{p.iconName || 'Favorite'}</Text></View>;
      default:
        return <View className="p-4"><Icon name="cube-outline" size={16} color={colors.textSecondary} /><Text style={{ color: colors.textSecondary }}>{component.type}</Text></View>;
    }
  };
  return (
    <Pressable
      ref={viewRef}
      collapsable={false}
      onLayout={measure}
      onPress={(event) => { event.stopPropagation?.(); onSelect?.(component.id); }}
      style={[
        className="wrapper
        container && className="containerBoundary
        selected && className="selected
        isDropTarget && className="dropTarget
      ]}
    >
      {selected ? (
        <View className="p-4">
          <View className="p-4"><Text className="p-4">{component.type}</Text></View>
          <Pressable onPress={(event) => { event.stopPropagation?.(); onEdit?.(component.id); }} className="p-4">
            <Icon name="create-outline" size={12} color="#FFFFFF" />
          </Pressable>
          {depth > 0 ? (
            <View {...dragResponder.panHandlers} className="p-4">
              <Icon name="move-outline" size={13} color="#FFFFFF" />
            </View>
          ) : null}
        </View>
      ) : null}
      {render()}
    </Pressable>
  );
};
// Tailwind className
export default WidgetRenderer;