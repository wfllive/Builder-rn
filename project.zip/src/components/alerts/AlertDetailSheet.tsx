import React from 'react';
import { Modal, View, Text, Pressable, StyleSheet, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export function AlertDetailSheet({ region, alerts, loading, onClose }: any) {
  const insets = useSafeAreaInsets();
  if (!region) return null;
  return (
    <Modal visible={!!region} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={s.backdrop} onPress={onClose} />
      <View style={[s.sheet, { paddingBottom: insets.bottom + 20 }]}>
        <Text style={s.title}>{region.name}</Text>
        {loading ? <Text style={s.loading}>Загрузка…</Text> : (
          <ScrollView>
            {alerts?.map((a:any, i:number)=>(
              <View key={i} style={s.alert}>
                <Text style={s.alertTitle}>{a.title}</Text>
                <Text style={s.alertDesc}>{a.description}</Text>
              </View>
            ))}
            {!alerts?.length && <Text style={s.empty}>Нет активных предупреждений</Text>}
          </ScrollView>
        )}
        <Pressable onPress={onClose} style={s.close}><Text style={s.closeText}>Закрыть</Text></Pressable>
      </View>
    </Modal>
  );
}
const s = StyleSheet.create({
  backdrop:{ flex:1, backgroundColor:'rgba(0,0,0,0.45)' },
  sheet:{ position:'absolute', left:0, right:0, bottom:0, backgroundColor:'#0b1220', borderTopLeftRadius:20, borderTopRightRadius:20, padding:16, maxHeight:'70%' },
  title:{ color:'#fff', fontSize:18, fontWeight:'800', marginBottom:10 },
  loading:{ color:'#9ca3af' },
  alert:{ backgroundColor:'#111827', padding:12, borderRadius:12, marginBottom:8 },
  alertTitle:{ color:'#f87171', fontWeight:'700', marginBottom:4 },
  alertDesc:{ color:'#d1d5db' },
  empty:{ color:'#6b7280' },
  close:{ marginTop:10, backgroundColor:'#1e293b', padding:12, borderRadius:12, alignItems:'center' },
  closeText:{ color:'#fff', fontWeight:'700' },
});
