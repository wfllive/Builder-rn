import React, { forwardRef, useImperativeHandle, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from './Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import WidgetRenderer from './WidgetRenderer';
import ComponentTree from './ComponentTree';
import NativeComposePreview from './NativeComposePreview';
import { generateId } from '../utils/generateId';

const mapTree = (root, callback) => {
  const transformed = callback(root);
  return { ...transformed, children: (transformed.children || []).map((child) => mapTree(child, callback)) };
};

const findNode = (root, id) => {
  if (!root) return null;
  if (root.id === id) return root;
  for (const child of root.children || []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
};

const DesignCanvas = forwardRef(({ showHierarchy = false, isDragOver = false, onRequestProperties }, ref) => {
  const { width } = useWindowDimensions();
  const {
    currentProject, selectedComponentId, selectComponent, getCurrentScreen,
    updateComponentTree, dispatch, clipboardComponent, undo, redo, undoStack, redoStack,
    addComponent, moveComponent,
  } = useProject();
  const { colors, language } = useAppSettings();
  const [zoom, setZoom] = useState(1);
  const [dropTargetId, setDropTargetId] = useState(null);
  const [movingComponentId, setMovingComponentId] = useState(null);
  const [renderMode, setRenderMode] = useState('design'); // 'design' | 'native'
  const zonesRef = useRef(new Map());
  const styles = useMemo(() => createStyles(colors), [colors]);
  const screen = getCurrentScreen();
  const hierarchyWidth = showHierarchy ? 176 : 0;
  const phoneWidth = Math.min(360, Math.max(252, width - hierarchyWidth - 28));
  const phoneHeight = Math.round(phoneWidth * 1.92);

  const registerDropZone = (id, bounds) => zonesRef.current.set(id, bounds);
  const targetAt = (point, movingId = null) => {
    if (!point) return null;
    return [...zonesRef.current.entries()]
      .filter(([id, bounds]) => id !== movingId
        && point.x >= bounds.x && point.x <= bounds.x + bounds.width
        && point.y >= bounds.y && point.y <= bounds.y + bounds.height)
      .sort(([, first], [, second]) => second.depth - first.depth || (first.width * first.height) - (second.width * second.height))[0]?.[0] || null;
  };

  const updateDropPoint = (point, movingId = null) => {
    const targetId = targetAt(point, movingId);
    setDropTargetId(targetId);
    return targetId;
  };

  useImperativeHandle(ref, () => ({
    updateDragPoint: (point) => updateDropPoint(point),
    clearDragPoint: () => setDropTargetId(null),
    dropComponent: (typeKey, point) => {
      if (screen?.readOnly) return false;
      const targetId = targetAt(point) || screen?.rootComponent?.id;
      if (!typeKey || !targetId) return false;
      addComponent(typeKey, targetId);
      setDropTargetId(null);
      return true;
    },
  }), [screen?.readOnly, screen?.rootComponent?.id, addComponent]);

  if (!screen) return <View style={styles.empty}><Icon name="phone-portrait-outline" size={34} color={colors.textTertiary} /><Text style={styles.emptyText}>{language === 'ru' ? 'Выберите экран' : 'Select a screen'}</Text></View>;

  const updateChildren = (operation) => updateComponentTree(mapTree(screen.rootComponent, (node) => ({ ...node, children: operation(node.children || [], node) })));

  const remove = () => {
    if (!selectedComponentId || selectedComponentId === screen.rootComponent.id) {
      Alert.alert(language === 'ru' ? 'Корневой контейнер удалить нельзя' : 'The root container cannot be deleted');
      return;
    }
    updateChildren((children) => children.filter((child) => child.id !== selectedComponentId));
    selectComponent(null);
  };

  const move = (direction) => {
    if (!selectedComponentId) return;
    updateChildren((children) => {
      const index = children.findIndex((child) => child.id === selectedComponentId);
      const target = index + direction;
      if (index < 0 || target < 0 || target >= children.length) return children;
      const next = [...children];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  const copy = () => {
    const node = findNode(screen.rootComponent, selectedComponentId);
    if (node && node.id !== screen.rootComponent.id) dispatch({ type: 'SET_CLIPBOARD', payload: JSON.parse(JSON.stringify(node)) });
  };

  const paste = () => {
    if (!clipboardComponent) return;
    const clone = (node) => ({ ...node, id: generateId(), props: { ...node.props }, children: (node.children || []).map(clone) });
    const copied = clone(clipboardComponent);
    let inserted = false;
    const next = mapTree(screen.rootComponent, (node) => {
      if (!inserted && node.id === (selectedComponentId || screen.rootComponent.id) && ['Column', 'Row', 'Box', 'LazyColumn', 'Card'].includes(node.type)) {
        inserted = true;
        return { ...node, children: [...(node.children || []), copied] };
      }
      return node;
    });
    if (!inserted) next.children = [...(next.children || []), copied];
    updateComponentTree(next);
    selectComponent(copied.id);
  };

  const startComponentDrag = (componentId, point) => {
    setMovingComponentId(componentId);
    selectComponent(componentId);
    updateDropPoint(point, componentId);
  };

  const moveComponentDrag = (componentId, point) => updateDropPoint(point, componentId);

  const finishComponentDrag = (componentId, point) => {
    const targetId = targetAt(point, componentId);
    if (targetId) moveComponent(componentId, targetId);
    setMovingComponentId(null);
    setDropTargetId(null);
  };

  const editSelected = (componentId) => {
    selectComponent(componentId);
    onRequestProperties?.(componentId);
  };

  const actions = [
    { icon: 'arrow-undo-outline', onPress: undo, disabled: !undoStack.length, label: 'Undo' },
    { icon: 'arrow-redo-outline', onPress: redo, disabled: !redoStack.length, label: 'Redo' },
    { icon: 'arrow-up-outline', onPress: () => move(-1), disabled: !selectedComponentId, label: 'Move up' },
    { icon: 'arrow-down-outline', onPress: () => move(1), disabled: !selectedComponentId, label: 'Move down' },
    { icon: 'copy-outline', onPress: copy, disabled: !selectedComponentId, label: 'Copy' },
    { icon: 'clipboard-outline', onPress: paste, disabled: !clipboardComponent, label: 'Paste' },
    { icon: 'trash-outline', onPress: remove, disabled: !selectedComponentId, danger: true, label: 'Delete' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.toolbar}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.toolbarContent}>
          <View style={styles.screenLabel}><Icon name="phone-portrait-outline" size={14} color={colors.primary} /><Text style={styles.screenLabelText}>{screen.name}</Text></View>
          <View style={styles.divider} />
          <Pressable
            onPress={() => setRenderMode('design')}
            style={[styles.modeButton, renderMode === 'design' && styles.modeButtonActive]}
            accessibilityLabel="design-mode"
          >
            <Icon name="color-wand-outline" size={14} color={renderMode === 'design' ? colors.primary : colors.textSecondary} />
            <Text style={[styles.modeText, renderMode === 'design' && styles.modeTextActive]}>{language === 'ru' ? 'Дизайн' : 'Design'}</Text>
          </Pressable>
          <Pressable
            onPress={() => setRenderMode('native')}
            style={[styles.modeButton, renderMode === 'native' && styles.modeButtonActive]}
            accessibilityLabel="native-mode"
          >
            <Icon name="logo-android" size={14} color={renderMode === 'native' ? colors.primary : colors.textSecondary} />
            <Text style={[styles.modeText, renderMode === 'native' && styles.modeTextActive]}>{language === 'ru' ? 'Нативный preview' : 'Native preview'}</Text>
          </Pressable>
          {renderMode === 'design' ? (
            <>
              <View style={styles.divider} />
              {actions.map((action) => (
                <Pressable
                  key={action.label}
                  accessibilityLabel={action.label}
                  disabled={action.disabled}
                  onPress={action.onPress}
                  style={({ pressed }) => [styles.tool, action.danger && styles.toolDanger, action.disabled && styles.toolDisabled, pressed && { opacity: 0.65 }]}
                >
                  <Icon name={action.icon} size={17} color={action.danger ? colors.error : colors.textSecondary} />
                </Pressable>
              ))}
            </>
          ) : null}
          <View style={styles.divider} />
          <Pressable onPress={() => setZoom((value) => Math.max(0.6, Number((value - 0.1).toFixed(1))))} style={styles.tool}><Icon name="remove-outline" size={17} color={colors.textSecondary} /></Pressable>
          <Text style={styles.zoom}>{Math.round(zoom * 100)}%</Text>
          <Pressable onPress={() => setZoom((value) => Math.min(1.2, Number((value + 0.1).toFixed(1))))} style={styles.tool}><Icon name="add-outline" size={17} color={colors.textSecondary} /></Pressable>
        </ScrollView>
      </View>

      <View style={styles.body}>
        {screen.readOnly ? (
          <View style={styles.readOnlyBanner}>
            <Icon name="shield-checkmark-outline" size={14} color={colors.primary} />
            <Text style={styles.readOnlyText} numberOfLines={2}>
              {language === 'ru'
                ? `${screen.name}Activity.kt — шаблон проекта. Содержимое отображается из реального файла.`
                : `${screen.name}Activity.kt — project template. Content displayed from the real file.`}
            </Text>
          </View>
        ) : null}
        {showHierarchy ? <ComponentTree compact /> : null}
        <ScrollView
          style={[styles.canvas, isDragOver && styles.canvasDrag]}
          contentContainerStyle={styles.canvasContent}
          showsVerticalScrollIndicator
          showsHorizontalScrollIndicator
          maximumZoomScale={1.5}
          minimumZoomScale={0.6}
        >
          <View style={{ transform: [{ scale: zoom }], marginVertical: -(1 - zoom) * 100 }}>
            <Pressable onPress={() => selectComponent(screen.rootComponent.id)} style={[styles.phone, { width: phoneWidth, height: phoneHeight }]}>
              {screen.showStatusBar !== false ? (
                <View style={[styles.statusBar, { backgroundColor: screen.statusBarColor || '#FFFFFF' }]}>
                  <Text style={styles.statusTime}>9:41</Text>
                  <View style={styles.statusIcons}><Icon name="cellular" size={12} color="#111827" /><Icon name="wifi" size={12} color="#111827" /><Icon name="battery-full" size={14} color="#111827" /></View>
                </View>
              ) : null}
              {screen.showActionBar ? (
                <View style={[styles.actionBar, { backgroundColor: currentProject?.theme?.primaryColor || '#4F46E5' }]}>
                  <Icon name="arrow-back" size={19} color="#FFFFFF" />
                  <Text style={styles.actionTitle} numberOfLines={1}>{screen.actionBarTitle || screen.name}</Text>
                  <Icon name="ellipsis-vertical" size={18} color="#FFFFFF" />
                </View>
              ) : null}
              <View style={[styles.screen, { backgroundColor: screen.backgroundColor || '#F8FAFC' }]}>
                {renderMode === 'native' ? (
                  <View style={{ flex: 1 }}>
                    <NativeComposePreview
                      project={currentProject}
                      screen={screen}
                      showChrome={false}
                      scroll={false}
                      widthDp={Math.round(phoneWidth / 2.625)}
                    />
                  </View>
                ) : (
                  <WidgetRenderer
                    component={screen.rootComponent}
                    onSelect={selectComponent}
                    onEdit={editSelected}
                    onRegisterDropZone={registerDropZone}
                    onComponentDragStart={startComponentDrag}
                    onComponentDragMove={moveComponentDrag}
                    onComponentDrop={finishComponentDrag}
                    dropTargetId={dropTargetId}
                  />
                )}
              </View>
              <View style={styles.deviceNav}><View style={styles.gestureBar} /></View>
            </Pressable>
          </View>
          {isDragOver ? <View pointerEvents="none" style={styles.dropMessage}><Icon name="download-outline" size={18} color={colors.primary} /><Text style={styles.dropText}>{language === 'ru' ? 'Отпустите компонент' : 'Drop component'}</Text></View> : null}
        </ScrollView>
      </View>
    </View>
  );
});

const createStyles = (c) => StyleSheet.create({
  container: { flex: 1, backgroundColor: c.canvas },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 9, backgroundColor: c.canvas },
  emptyText: { color: c.textSecondary, fontSize: 13 },
  toolbar: { minHeight: 46, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  toolbarContent: { alignItems: 'center', paddingHorizontal: 8, paddingVertical: 5, gap: 5 },
  screenLabel: { height: 34, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 8, backgroundColor: c.primarySurface },
  screenLabelText: { color: c.primary, fontSize: 11, fontWeight: '700' },
  divider: { width: 1, height: 22, backgroundColor: c.border, marginHorizontal: 2 },
  tool: { width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  toolDanger: { backgroundColor: c.errorBg, borderColor: c.errorBg },
  toolDisabled: { opacity: 0.36 },
  modeButton: { height: 34, paddingHorizontal: 9, borderRadius: 8, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  modeButtonActive: { backgroundColor: c.primarySurface, borderColor: c.primary },
  modeText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' },
  modeTextActive: { color: c.primary, fontWeight: '750' },
  zoom: { width: 40, color: c.textSecondary, fontFamily: 'monospace', fontSize: 10, textAlign: 'center' },
  body: { flex: 1, flexDirection: 'row' },
  canvas: { flex: 1, borderWidth: 2, borderColor: 'transparent' },
  canvasDrag: { borderColor: c.primary, backgroundColor: c.primarySurface },
  canvasContent: { minHeight: 720, padding: 12, alignItems: 'center', justifyContent: 'flex-start' },
  phone: { maxWidth: '100%', backgroundColor: '#FFFFFF', borderRadius: 28, overflow: 'hidden', borderWidth: 7, borderColor: '#111827', shadowColor: c.shadow, shadowOffset: { width: 0, height: 8 }, shadowOpacity: c.mode === 'dark' ? 0.45 : 0.18, shadowRadius: 18, elevation: 10 },
  statusBar: { height: 28, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statusTime: { color: '#111827', fontSize: 10, fontWeight: '750' },
  statusIcons: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionBar: { height: 50, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 12 },
  actionTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700', flex: 1 },
  screen: { flex: 1, minHeight: 0, padding: 8 },
  deviceNav: { height: 30, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  gestureBar: { width: 100, height: 4, borderRadius: 2, backgroundColor: '#111827' },
  dropMessage: { position: 'absolute', top: 12, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.primary, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 9 },
  dropText: { color: c.primary, fontSize: 12, fontWeight: '700' },
  readOnlyBanner: { position: 'absolute', top: 8, left: 8, right: 8, zIndex: 5, flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.border, borderRadius: 9, paddingHorizontal: 10, paddingVertical: 8 },
  readOnlyText: { color: c.textSecondary, fontSize: 10, flex: 1, lineHeight: 14 },
});

export default DesignCanvas;
