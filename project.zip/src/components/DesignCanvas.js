import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useProject } from '../store/projectStore';
import WidgetRenderer from './WidgetRenderer';
import ComponentTree from './ComponentTree';
import { componentTypes } from '../utils/defaultProject';
import colors from '../theme/colors';
import { generateId } from '../utils/generateId';

const DesignCanvas = () => {
  const {
    currentProject,
    currentScreenId,
    selectedComponentId,
    selectComponent,
    updateComponentTree,
    getCurrentScreen,
    dispatch,
    clipboardComponent,
    undo,
    redo,
    undoStack,
    redoStack,
  } = useProject();

  const [showTree, setShowTree] = useState(true);
  const [dropTargetId, setDropTargetId] = useState(null);

  const currentScreen = getCurrentScreen();

  // Helper: find component and parent in tree
  const findComponentWithParent = (root, id, parent = null) => {
    if (root.id === id) return { component: root, parent };
    if (root.children) {
      for (const child of root.children) {
        const found = findComponentWithParent(child, id, root);
        if (found) return found;
      }
    }
    return null;
  };

  const findComponent = (root, id) => {
    if (root.id === id) return root;
    if (root.children) {
      for (const child of root.children) {
        const found = findComponent(child, id);
        if (found) return found;
      }
    }
    return null;
  };

  const handleAddToSelected = (typeKey) => {
    if (!currentScreen) return;
    const componentDef = componentTypes[typeKey];
    if (!componentDef) return;

    const newComponent = {
      id: generateId(),
      type: typeKey,
      props: { ...componentDef.defaultProps },
      children: [],
    };

    // Find selected component or use root
    let targetId = selectedComponentId || currentScreen.rootComponent.id;
    let targetComp = findComponent(currentScreen.rootComponent, targetId);
    
    // If target is not a container, add to its parent or root
    const targetDef = componentTypes[targetComp?.type];
    if (!targetDef?.isContainer && targetComp?.id !== currentScreen.rootComponent.id) {
      const result = findComponentWithParent(currentScreen.rootComponent, targetId);
      if (result?.parent) {
        targetComp = result.parent;
        targetId = result.parent.id;
      } else {
        targetComp = currentScreen.rootComponent;
        targetId = currentScreen.rootComponent.id;
      }
    }

    // Add to target's children
    const addToTree = (component) => {
      if (component.id === targetId) {
        return {
          ...component,
          children: [...(component.children || []), newComponent],
        };
      }
      if (component.children) {
        return {
          ...component,
          children: component.children.map(addToTree),
        };
      }
      return component;
    };

    const updatedRoot = addToTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
    selectComponent(newComponent.id);
  };

  const handleAddToRoot = (typeKey) => {
    if (!currentScreen) return;
    const componentDef = componentTypes[typeKey];
    if (!componentDef) return;

    const newComponent = {
      id: generateId(),
      type: typeKey,
      props: { ...componentDef.defaultProps },
      children: [],
    };

    const updatedRoot = {
      ...currentScreen.rootComponent,
      children: [...(currentScreen.rootComponent.children || []), newComponent],
    };

    updateComponentTree(updatedRoot);
    selectComponent(newComponent.id);
  };

  const handleDeleteSelected = () => {
    if (!selectedComponentId || !currentScreen) return;
    if (selectedComponentId === currentScreen.rootComponent.id) {
      Alert.alert('Ошибка', 'Нельзя удалить корневой компонент');
      return;
    }

    const removeFromTree = (component) => {
      if (!component.children) return component;
      const filteredChildren = component.children.filter(c => c.id !== selectedComponentId);
      return {
        ...component,
        children: filteredChildren.map(removeFromTree),
      };
    };

    const updatedRoot = removeFromTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
    selectComponent(null);
  };

  const handleMoveUp = () => {
    if (!selectedComponentId || !currentScreen) return;
    
    const moveInTree = (component) => {
      if (!component.children) return component;
      const idx = component.children.findIndex(c => c.id === selectedComponentId);
      if (idx > 0) {
        const newChildren = [...component.children];
        [newChildren[idx - 1], newChildren[idx]] = [newChildren[idx], newChildren[idx - 1]];
        return { ...component, children: newChildren.map(c => idx > 0 ? c : moveInTree(c)) };
      }
      return {
        ...component,
        children: component.children.map(moveInTree),
      };
    };

    const updatedRoot = moveInTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
  };

  const handleMoveDown = () => {
    if (!selectedComponentId || !currentScreen) return;
    
    const moveInTree = (component) => {
      if (!component.children) return component;
      const idx = component.children.findIndex(c => c.id === selectedComponentId);
      if (idx >= 0 && idx < component.children.length - 1) {
        const newChildren = [...component.children];
        [newChildren[idx], newChildren[idx + 1]] = [newChildren[idx + 1], newChildren[idx]];
        return { ...component, children: newChildren };
      }
      return {
        ...component,
        children: component.children.map(moveInTree),
      };
    };

    const updatedRoot = moveInTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
  };

  const handleCopy = () => {
    if (!selectedComponentId || !currentScreen) return;
    if (selectedComponentId === currentScreen.rootComponent.id) {
      Alert.alert('Ошибка', 'Нельзя копировать корневой компонент');
      return;
    }
    const comp = findComponent(currentScreen.rootComponent, selectedComponentId);
    if (comp) {
      dispatch({ type: 'SET_CLIPBOARD', payload: JSON.parse(JSON.stringify(comp)) });
    }
  };

  const handlePaste = () => {
    if (!clipboardComponent || !currentScreen) return;
    
    // Deep clone and regenerate IDs
    const deepClone = (comp) => ({
      ...comp,
      id: generateId(),
      props: { ...comp.props },
      children: comp.children ? comp.children.map(deepClone) : [],
    });

    const newComponent = deepClone(clipboardComponent);

    // Find target (selected or root)
    let targetId = selectedComponentId || currentScreen.rootComponent.id;
    let targetComp = findComponent(currentScreen.rootComponent, targetId);
    
    const targetDef = componentTypes[targetComp?.type];
    if (!targetDef?.isContainer) {
      const result = findComponentWithParent(currentScreen.rootComponent, targetId);
      if (result?.parent) {
        targetComp = result.parent;
        targetId = result.parent.id;
      } else {
        targetComp = currentScreen.rootComponent;
        targetId = currentScreen.rootComponent.id;
      }
    }

    const addToTree = (component) => {
      if (component.id === targetId) {
        return {
          ...component,
          children: [...(component.children || []), newComponent],
        };
      }
      if (component.children) {
        return {
          ...component,
          children: component.children.map(addToTree),
        };
      }
      return component;
    };

    const updatedRoot = addToTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
    selectComponent(newComponent.id);
  };

  const handleWrapInContainer = () => {
    if (!selectedComponentId || !currentScreen) return;
    if (selectedComponentId === currentScreen.rootComponent.id) {
      Alert.alert('Ошибка', 'Нельзя обернуть корневой компонент');
      return;
    }

    const selectedComp = findComponent(currentScreen.rootComponent, selectedComponentId);
    if (!selectedComp) return;

    const wrapper = {
      id: generateId(),
      type: 'CardView',
      props: {
        width: 'match_parent',
        height: 'wrap_content',
        backgroundColor: '#2C2C2C',
        borderRadius: 12,
        padding: 16,
        elevation: 4,
      },
      children: [selectedComp],
    };

    const replaceInTree = (component) => {
      if (!component.children) return component;
      const idx = component.children.findIndex(c => c.id === selectedComponentId);
      if (idx >= 0) {
        const newChildren = [...component.children];
        newChildren[idx] = wrapper;
        return { ...component, children: newChildren };
      }
      return {
        ...component,
        children: component.children.map(replaceInTree),
      };
    };

    const updatedRoot = replaceInTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
    selectComponent(wrapper.id);
  };

  if (!currentScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.emptyText}>Выберите экран</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Toolbar */}
      <View style={styles.toolbar}>
        <View style={styles.toolbarLeft}>
          <TouchableOpacity
            style={[styles.toolButton, showTree && styles.activeToolButton]}
            onPress={() => setShowTree(!showTree)}
          >
            <Text style={styles.toolButtonText}>🌲</Text>
          </TouchableOpacity>
        </View>
        
        <Text style={styles.toolbarTitle}>
          {currentScreen.name}
        </Text>
        
        <View style={styles.toolbarActions}>
          <TouchableOpacity
            style={[styles.toolButton, undoStack.length === 0 && styles.disabledToolButton]}
            onPress={undo}
            disabled={undoStack.length === 0}
          >
            <Text style={styles.toolButtonText}>↶</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toolButton, redoStack.length === 0 && styles.disabledToolButton]}
            onPress={redo}
            disabled={redoStack.length === 0}
          >
            <Text style={styles.toolButtonText}>↷</Text>
          </TouchableOpacity>
          <View style={styles.toolbarDivider} />
          <TouchableOpacity style={styles.toolButton} onPress={handleMoveUp}>
            <Text style={styles.toolButtonText}>↑</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.toolButton} onPress={handleMoveDown}>
            <Text style={styles.toolButtonText}>↓</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.toolButton} onPress={handleCopy}>
            <Text style={styles.toolButtonText}>⧉</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toolButton, !clipboardComponent && styles.disabledToolButton]}
            onPress={handlePaste}
            disabled={!clipboardComponent}
          >
            <Text style={styles.toolButtonText}>📋</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.toolButton} onPress={handleWrapInContainer}>
            <Text style={styles.toolButtonText}>📦</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toolButton, styles.deleteToolButton]}
            onPress={handleDeleteSelected}
          >
            <Text style={styles.toolButtonText}>🗑</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        {/* Component Tree */}
        {showTree && <ComponentTree />}

        {/* Canvas */}
        <View style={styles.canvasWrapper}>
          <ScrollView
            style={styles.canvas}
            contentContainerStyle={styles.canvasContent}
            showsVerticalScrollIndicator={true}
          >
            {/* Phone Frame */}
            <View style={styles.phoneFrame}>
              <View style={styles.statusBar}>
                <Text style={styles.statusBarText}>9:41</Text>
                <Text style={styles.statusBarText}>📶 🔋</Text>
              </View>
              
              {currentScreen.showActionBar && (
                <View style={[styles.actionBar, { backgroundColor: currentProject?.theme?.primaryColor || '#3700B3' }]}>
                  <Text style={styles.actionBarBack}>←</Text>
                  <Text style={styles.actionBarTitle}>
                    {currentScreen.actionBarTitle || currentScreen.name}
                  </Text>
                  <Text style={styles.actionBarMenu}>⋮</Text>
                </View>
              )}

              <View style={[styles.screenContent, { backgroundColor: currentScreen.backgroundColor || '#121212' }]}>
                <WidgetRenderer
                  component={currentScreen.rootComponent}
                  isSelected={selectedComponentId === currentScreen.rootComponent.id}
                  onSelect={selectComponent}
                  dropTargetId={dropTargetId}
                  onDropTarget={setDropTargetId}
                />
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.canvas,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
  },
  toolbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 6,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  toolbarLeft: {
    flexDirection: 'row',
    gap: 4,
  },
  toolbarTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.onSurface,
  },
  toolbarActions: {
    flexDirection: 'row',
    gap: 4,
    alignItems: 'center',
  },
  toolbarDivider: {
    width: 1,
    height: 20,
    backgroundColor: colors.border,
    marginHorizontal: 4,
  },
  toolButton: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: colors.surfaceLight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeToolButton: {
    backgroundColor: colors.primary,
  },
  disabledToolButton: {
    opacity: 0.3,
  },
  deleteToolButton: {
    backgroundColor: '#4a2020',
  },
  toolButtonText: {
    fontSize: 14,
  },
  canvasWrapper: {
    flex: 1,
  },
  canvas: {
    flex: 1,
  },
  canvasContent: {
    padding: 16,
    alignItems: 'center',
  },
  phoneFrame: {
    width: 340,
    minHeight: 600,
    backgroundColor: colors.surface,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: colors.borderLight,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  statusBar: {
    height: 28,
    backgroundColor: '#000',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  statusBarText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  actionBar: {
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  actionBarBack: {
    color: '#FFFFFF',
    fontSize: 20,
    marginRight: 16,
  },
  actionBarTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    flex: 1,
  },
  actionBarMenu: {
    color: '#FFFFFF',
    fontSize: 20,
  },
  screenContent: {
    flex: 1,
    padding: 8,
    minHeight: 500,
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 16,
    textAlign: 'center',
    marginTop: 40,
  },
});

export default DesignCanvas;
