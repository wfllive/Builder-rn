import React, { useMemo, useRef, useState, useCallback } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useAppSettings } from '../store/appSettings';
import { highlightJSX } from '../utils/kotlinHighlighter';

/**
 * A professional VS Code-like monospace JSX editor.
 *
 * Rendering model (reliable on Android):
 *   - a <Text> renders the syntax-highlighted code in flow and defines the
 *     content's natural height;
 *   - an absolutely-positioned <TextInput> sits exactly on top with transparent
 *     text but a visible caret/selection.
 * Both layers share identical metrics (font, size, lineHeight,
 * includeFontPadding:false) and identical padding, so the caret stays aligned
 * with the highlighted text. A compact right-aligned gutter carries the line
 * numbers and highlights the current line.
 */
const CodeEditor = ({
  value = '',
  onChange,
  placeholder,
  readOnly = false,
}) => {
  const { colors, editor } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const inputRef = useRef(null);

  const fontSize = editor.fontSize || 14;
  const tabSize = editor.tabSize || 4;
  const spacesForTab = editor.spacesForTab !== false;
  const wordWrap = editor.wordWrap === true;
  const minimap = editor.minimap !== false;

  const lineHeight = Math.round(fontSize * 1.6);
  const PAD_X = 16;
  const PAD_TOP = 14;
  const PAD_BOTTOM = 24;
  const MINIMAP_W = 18;

  const lines = useMemo(() => {
    const count = value ? value.split('\n').length : 1;
    return Array.from({ length: count }, (_, i) => i + 1);
  }, [value]);

  const highlighted = useMemo(() => highlightJSX(value), [value]);

  const stats = useMemo(() => {
    const text = value || '';
    return { lineCount: text ? text.split('\n').length : 0, chars: text.length };
  }, [value]);

  const [selection, setSelection] = useState({ start: 0, end: 0 });
  const [controlledSelection, setControlledSelection] = useState(null);
  const prevValueRef = useRef(value);
  const caretOverride = useRef(null);

  const pos = useMemo(() => {
    const text = value || '';
    const upTo = Math.max(0, Math.min(selection.start, text.length));
    const before = text.slice(0, upTo);
    const parts = before.split('\n');
    return { line: parts.length, col: parts[parts.length - 1].length + 1 };
  }, [selection.start, value]);
  const currentLineIndex = pos.line - 1;

  const minimapLines = useMemo(() => {
    if (!value) return [];
    return value.split('\n').map((l) => {
      const t = l.trim();
      if (!t) return 0;
      if (/^(val|var|fun|class|object|interface|@)/.test(t)) return 2;
      return 1;
    });
  }, [value]);

  const gutterWidth = useMemo(() => {
    const digits = Math.max(1, String(lines.length).length);
    return 14 + digits * 8 + 6;
  }, [lines.length]);

  const focusInput = useCallback(() => inputRef.current?.focus?.(), []);
  const indentationUnit = spacesForTab ? ' '.repeat(tabSize) : '\t';

  const applyText = useCallback((text, caret = null) => {
    prevValueRef.current = text;
    if (onChange) onChange(text);
    if (caret != null) {
      caretOverride.current = caret;
      setControlledSelection({ start: caret, end: caret });
    }
  }, [onChange]);

  const handleChange = (text) => {
    const prev = prevValueRef.current;
    prevValueRef.current = text;
    if (!onChange) return;
    const appended = text.length >= prev.length ? text.slice(prev.length) : '';
    const isEnter = appended && appended[appended.length - 1] === '\n';
    if (isEnter) {
      const insertStart = text.length - appended.length;
      const before = text.slice(0, insertStart);
      const lineStart = before.lastIndexOf('\n') + 1;
      const prevLine = before.slice(lineStart);
      const indentMatch = prevLine.match(/^[ \t]*/);
      let indent = indentMatch ? indentMatch[0] : '';
      const deeper = /[{\->]\s*$/.test(prevLine) || /->\s*$/.test(prevLine);
      if (deeper) indent += indentationUnit;
      onChange(text);
      if (indent) {
        const newText = text.slice(0, insertStart + appended.length) + indent + text.slice(insertStart + appended.length);
        const caret = insertStart + appended.length + indent.length;
        prevValueRef.current = newText;
        onChange(newText);
        caretOverride.current = caret;
        setControlledSelection({ start: caret, end: caret });
      } else {
        caretOverride.current = insertStart + appended.length;
        setControlledSelection({ start: insertStart + appended.length, end: insertStart + appended.length });
      }
      return;
    }
    onChange(text);
  };

  const handleKeyPress = (e) => {
    if (e.nativeEvent.key === 'Tab') {
      e.preventDefault?.();
      const text = value || '';
      const caret = selection.start;
      const newText = text.slice(0, caret) + indentationUnit + text.slice(caret);
      applyText(newText, caret + indentationUnit.length);
    }
  };

  const codeTextStyle = { fontFamily: 'monospace', fontSize, lineHeight, includeFontPadding: false };

  return (
    <View style={styles.root}>
      <ScrollView
        style={styles.wrap}
        contentContainerStyle={styles.content}
        scrollEventThrottle={32}
        nestedScrollEnabled
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.body}>
          {/* Gutter with line numbers */}
          <View style={[styles.gutter, { width: gutterWidth }]} onStartShouldSetResponder={focusInput}>
            {lines.map((n, i) => {
              const isCurrent = i === currentLineIndex;
              return (
                <View key={i} style={[styles.lineRow, { height: lineHeight }, isCurrent && styles.lineRowCurrent]}>
                  <Text
                    style={[styles.lineNum, { fontSize, lineHeight }, isCurrent && styles.lineNumCurrent]}
                    numberOfLines={1}
                  >
                    {n}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Code area: the highlight <Text> is the ONLY visible layer. The
              TextInput sits on top with its text color equal to the editor
              background, so its own glyphs are invisible even if Android renders
              them — only the caret and selection show. This guarantees the code
              is never doubled or misaligned. */}
          <Pressable onPress={focusInput} style={styles.codeArea} android_disableSound>
            <View style={{ paddingTop: PAD_TOP, paddingBottom: PAD_BOTTOM, paddingHorizontal: PAD_X }}>
              {value.length > 0 ? (
                <Text style={codeTextStyle}>
                  {highlighted.map((span, i) => (
                    <Text key={i} style={{ color: span.color }}>{span.text}</Text>
                  ))}
                </Text>
              ) : (
                <Text style={[styles.placeholder, { fontSize, lineHeight }]}>{placeholder}</Text>
              )}
            </View>

            <TextInput
              ref={inputRef}
              style={[styles.input, { fontSize, lineHeight, paddingTop: PAD_TOP, paddingBottom: PAD_BOTTOM, paddingHorizontal: PAD_X, color: colors.terminal }]}
              value={value}
              onChangeText={handleChange}
              onKeyPress={handleKeyPress}
              selection={controlledSelection || undefined}
              onSelectionChange={(e) => {
                setSelection(e.nativeEvent.selection || { start: 0, end: 0 });
                if (caretOverride.current != null) { caretOverride.current = null; setControlledSelection(null); }
              }}
              multiline
              editable={!readOnly}
              autoCapitalize="none"
              autoCorrect={false}
              spellCheck={false}
              selectionColor={colors.primary}
              caretColor={colors.text}
              scrollEnabled={false}
              textAlignVertical="top"
              pointerEvents="auto"
            />
          </Pressable>

          {/* Minimap */}
          {minimap ? (
            <View style={[styles.minimap, { width: MINIMAP_W }]} pointerEvents="none">
              {minimapLines.map((k, i) => (
                <View key={i} style={[styles.minimapLine, { height: lineHeight }, i === currentLineIndex && styles.minimapLineCurrent]}>
                  <View
                    style={[
                      styles.minimapBlock,
                      { backgroundColor: k === 2 ? '#C586C0' : k === 1 ? '#5F6D83' : 'transparent' },
                    ]}
                  />
                </View>
              ))}
            </View>
          ) : null}
        </View>
      </ScrollView>

      {editor.showStatusBar !== false ? (
        <View style={styles.statusBar}>
          <Text style={styles.statusText}>Ln {pos.line}, Col {pos.col}</Text>
          <Text style={styles.statusText}>{stats.lineCount} lines</Text>
          <Text style={styles.statusText}>{stats.chars} chars</Text>
          <View style={{ flex: 1 }} />
          <Text style={styles.statusText}>{spacesForTab ? `Spaces: ${tabSize}` : 'Tabs'}</Text>
          <Text style={styles.statusText}>{wordWrap ? 'Wrap: On' : 'Wrap: Off'}</Text>
        </View>
      ) : null}
    </View>
  );
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, minHeight: 0 },
  wrap: { flex: 1, backgroundColor: c.terminal, minHeight: 0 },
  content: { flexGrow: 1 },
  body: { flexDirection: 'row', flexGrow: 1, minHeight: '100%' },
  gutter: { paddingRight: 6, backgroundColor: c.terminalRaised, borderRightWidth: 1, borderRightColor: '#1B2433' },
  lineRow: { justifyContent: 'center', paddingRight: 6 },
  lineRowCurrent: { backgroundColor: c.primarySurface },
  lineNum: { color: '#5A6B84', fontFamily: 'monospace', textAlign: 'right', includeFontPadding: false },
  lineNumCurrent: { color: c.primary, fontWeight: '700' },
  codeArea: { flex: 1, minWidth: 0, backgroundColor: c.terminal },
  placeholder: { color: c.textTertiary, fontFamily: 'monospace', includeFontPadding: false },
  input: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    fontFamily: 'monospace', zIndex: 2,
    backgroundColor: 'transparent', includeFontPadding: false,
  },
  minimap: { borderLeftWidth: 1, borderLeftColor: '#1B2433', backgroundColor: c.terminal, overflow: 'hidden', paddingTop: 0 },
  minimapLine: { width: '100%', justifyContent: 'center', paddingHorizontal: 3 },
  minimapLineCurrent: { backgroundColor: 'rgba(255,255,255,0.06)' },
  minimapBlock: { height: 3, borderRadius: 1 },
  statusBar: { minHeight: 26, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: c.terminalRaised, borderTopWidth: 1, borderTopColor: '#1B2433' },
  statusText: { color: '#8B98AD', fontSize: 10, fontFamily: 'monospace', includeFontPadding: false },
});

export default CodeEditor;
