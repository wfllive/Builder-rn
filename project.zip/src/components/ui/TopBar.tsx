import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { EdgeInsets } from 'react-native-safe-area-context';

export function TopBar({ total, count, perMin, isConnected, insets, advClickInfo, isAdvRadar }:{
  total:number; count:number; perMin:number[]; isConnected:boolean; insets: EdgeInsets;
  advClickInfo?: any; isAdvRadar?: boolean;
}) {
  const lastMin = perMin[perMin.length-1] ?? 0;
  return (
    <View style={[styles.wrap, { paddingTop: insets.top + 8 }]}>
      <View style={styles.card}>
        <Text style={styles.big}>{count}</Text>
        <Text style={styles.sub}>молний на карте</Text>
        <Text style={[styles.dot, { color: isConnected ? '#4ade80' : '#f87171' }]}>
          ● {isConnected ? 'онлайн' : 'оффлайн'}
        </Text>
        <Text style={styles.small}>всего: {total} • {lastMin}/мин</Text>
        {isAdvRadar && advClickInfo && (
          <Text style={styles.small}>{advClickInfo?.phenomenon ?? 'NowCast'}</Text>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position:'absolute', top:0, left:12, right:12, zIndex: 50 },
  card: {
    backgroundColor: 'rgba(8,13,26,0.85)',
    borderRadius: 16,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.07)',
  },
  big: { color:'#fff', fontSize:28, fontWeight:'800' },
  sub: { color:'#9ca3af', fontSize:12, marginTop: -2 },
  dot: { fontSize:12, marginTop:4, fontWeight:'600' },
  small: { color:'#6b7280', fontSize:11, marginTop:2 },
});
