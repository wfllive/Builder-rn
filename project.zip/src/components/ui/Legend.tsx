import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { EdgeInsets } from 'react-native-safe-area-context';

export function Legend({ showRain, showAlerts, showAdvRadar, advRadarLayer, hidden, setHidden, insets } : any) {
  if (hidden) {
    return (
      <Pressable onPress={()=>setHidden(false)} style={[styles.fab, { bottom: insets.bottom + 20, left: 16 }]}>
        <Text style={styles.fabText}>📊</Text>
      </Pressable>
    );
  }
  return (
    <View style={[styles.box, { bottom: insets.bottom + 16, left: 16, right: 16 }]}>
      <View style={styles.rowBetween}>
        <Text style={styles.title}>Легенда</Text>
        <Pressable onPress={()=>setHidden(true)}><Text style={styles.hide}>скрыть</Text></Pressable>
      </View>
      <View style={styles.rowWrap}>
        {[
          ['#ff1744','<2 мин'],
          ['#ff9100','<5 мин'],
          ['#ffeb3b','<10 мин'],
          ['#00e5ff','<20 мин'],
          ['#7c4dff','<40 мин'],
          ['#9e9e9e','<90 мин'],
        ].map(([c,l])=>(
          <View key={l} style={styles.item}>
            <View style={[styles.dot, { backgroundColor: c }]} />
            <Text style={styles.itemText}>{l}</Text>
          </View>
        ))}
      </View>
      {(showRain || showAlerts || showAdvRadar) && (
        <Text style={styles.layers}>
          {[
            showRain && '🌧️ Радар',
            showAlerts && '⚠️ Алерты',
            showAdvRadar && '📡 NowCast'
          ].filter(Boolean).join(' • ')}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { position:'absolute', zIndex:40, backgroundColor:'rgba(8,13,26,0.9)', borderRadius:16, padding:12, borderWidth:1, borderColor:'rgba(255,255,255,0.08)' },
  rowBetween: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:6 },
  title: { color:'#fff', fontWeight:'700', fontSize:14 },
  hide: { color:'#60a5fa', fontSize:12 },
  rowWrap: { flexDirection:'row', flexWrap:'wrap', gap:8 },
  item: { flexDirection:'row', alignItems:'center', marginRight:12, marginBottom:4 },
  dot: { width:10, height:10, borderRadius:5, marginRight:6 },
  itemText: { color:'#d1d5db', fontSize:11 },
  layers: { color:'#9ca3af', fontSize:11, marginTop:6 },
  fab: { position:'absolute', zIndex:40, backgroundColor:'#1e293b', paddingHorizontal:14, paddingVertical:10, borderRadius:14 },
  fabText: { color:'#fff', fontSize:16 },
});
