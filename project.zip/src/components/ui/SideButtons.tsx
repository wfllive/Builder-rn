import React from 'react';
import { View, Pressable, Text, StyleSheet } from 'react-native';
import { EdgeInsets } from 'react-native-safe-area-context';

export function SideButtons({ config, onTheme, onSettings, onLocate, onToggleRain, onToggleAlerts, onToggleWind, onToggleAdvRadar, insets } : any) {
  const Btn = ({ label, active, onPress, disabled }:{label:string; active?:boolean; onPress:()=>void; disabled?:boolean}) => (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={[styles.btn, active && styles.btnActive, disabled && styles.btnDisabled]}
    >
      <Text style={[styles.btnText, active && styles.btnTextActive]}>{label}</Text>
    </Pressable>
  );
  return (
    <View style={[styles.wrap, { top: insets.top + 120, right: 12 }]}>
      <Btn label="⚙️" onPress={onSettings} />
      <Btn label="🎨" onPress={onTheme} />
      <Btn label="📍" onPress={onLocate} />
      <Btn label="🌧️" active={config.rain} onPress={onToggleRain} disabled={config.wind} />
      <Btn label="⚠️" active={config.alerts} onPress={onToggleAlerts} disabled={config.wind} />
      <Btn label="🌬️" active={config.wind} onPress={onToggleWind} />
      <Btn label="📡" active={config.advRadar} onPress={onToggleAdvRadar} disabled={config.wind} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position:'absolute', zIndex: 60, gap: 10 },
  btn: {
    width: 48, height: 48, borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.9)',
    alignItems:'center', justifyContent:'center',
    borderWidth:1, borderColor:'rgba(255,255,255,0.08)',
  },
  btnActive: { backgroundColor:'#2563eb', borderColor:'#3b82f6' },
  btnDisabled: { opacity:0.5 },
  btnText: { color:'#e5e7eb', fontSize:18, fontWeight:'700' },
  btnTextActive: { color:'#fff' },
});
