import React, { useEffect, useState } from 'react';
import { Dimensions, View } from 'react-native';

import { ADS } from '../ads/adsConfig';
import { ensureAdsInitialized, getBannerApi, isAdsSupported } from '../ads/yandexAds';

/**
 * Sticky-баннер РСЯ (адаптивная высота, прижат к низу экрана).
 * Если нативный SDK недоступен или реклама не загрузилась — баннер
 * просто не занимает место (рендерится null).
 */
const AdsBanner = () => {
  const [adSize, setAdSize] = useState(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!isAdsSupported()) return;
      const ok = await ensureAdsInitialized();
      const api = getBannerApi();
      if (!ok || !api) return;
      try {
        const size = await api.BannerAdSize.stickySize(Dimensions.get('window').width);
        if (mounted) setAdSize(size);
      } catch {}
    })();
    return () => { mounted = false; };
  }, []);

  const api = getBannerApi();
  const BannerView = api ? api.BannerView : null;
  if (!BannerView || !adSize) return null;

  return (
    <View style={{ alignItems: 'center', overflow: 'hidden' }}>
      <BannerView
        size={adSize}
        adUnitId={ADS.bannerUnitId}
        onAdFailedToLoad={() => setAdSize(null)}
      />
    </View>
  );
};

export default AdsBanner;
