import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { useProject } from '../store/projectStore';
import { componentTypes } from '../utils/defaultProject';
import colors from '../theme/colors';
import { generateId } from '../utils/generateId';

const PropertyPanel = () => {
  const {
    currentProject,
    currentScreenId,
    selectedComponentId,
    updateComponentTree,
    selectComponent,
    getCurrentScreen,
    dispatch,
  } = useProject();

  const currentScreen = getCurrentScreen();
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [activeSection, setActiveSection] = useState('props'); // props | events | layout

  useEffect(() => {
    if (!currentScreen || !selectedComponentId) {
      setSelectedComponent(null);
      return;
    }

    const findComponent = (component, id) => {
      if (component.id === id) return component;
      if (component.children) {
        for (const child of component.children) {
          const found = findComponent(child, id);
          if (found) return found;
        }
      }
      return null;
    };

    const comp = findComponent(currentScreen.rootComponent, selectedComponentId);
    setSelectedComponent(comp);
  }, [currentScreen, selectedComponentId]);

  const updateProperty = (key, value) => {
    if (!selectedComponent || !currentScreen) return;

    const updateInTree = (component) => {
      if (component.id === selectedComponentId) {
        return {
          ...component,
          props: { ...component.props, [key]: value },
        };
      }
      if (component.children) {
        return {
          ...component,
          children: component.children.map(updateInTree),
        };
      }
      return component;
    };

    const updatedRoot = updateInTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
  };

  const handleChangeType = (newType) => {
    if (!selectedComponent || !currentScreen) return;
    const newDef = componentTypes[newType];
    if (!newDef) return;

    const updateInTree = (component) => {
      if (component.id === selectedComponentId) {
        return {
          ...component,
          type: newType,
          props: { ...newDef.defaultProps },
          children: newDef.isContainer ? component.children || [] : [],
        };
      }
      if (component.children) {
        return {
          ...component,
          children: component.children.map(updateInTree),
        };
      }
      return component;
    };

    const updatedRoot = updateInTree(currentScreen.rootComponent);
    updateComponentTree(updatedRoot);
  };

  if (!selectedComponent) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Свойства</Text>
        </View>
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🖱️</Text>
          <Text style={styles.emptyText}>
            Выберите компонент на холсте или в дереве для редактирования
          </Text>
        </View>
      </View>
    );
  }

  const componentDef = componentTypes[selectedComponent.type];
  const isContainer = componentDef?.isContainer || false;

  const renderPropertyInput = (key, value) => {
    // Boolean
    if (typeof value === 'boolean') {
      return (
        <View key={key} style={styles.propertyRow}>
          <View style={styles.propertyRowHeader}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <Switch
              value={value}
              onValueChange={(val) => updateProperty(key, val)}
              trackColor={{ false: '#555', true: colors.primary }}
              thumbColor="#FFFFFF"
            />
          </View>
        </View>
      );
    }

    // Number
    if (typeof value === 'number') {
      return (
        <View key={key} style={styles.propertyRow}>
          <Text style={styles.propertyLabel}>{key}</Text>
          <View style={styles.numberInputRow}>
            <TouchableOpacity
              style={styles.numberButton}
              onPress={() => updateProperty(key, Math.max(0, value - 1))}
            >
              <Text style={styles.numberButtonText}>−</Text>
            </TouchableOpacity>
            <TextInput
              style={styles.numberInput}
              value={String(value)}
              onChangeText={(text) => {
                const num = parseInt(text) || 0;
                updateProperty(key, num);
              }}
              keyboardType="numeric"
            />
            <TouchableOpacity
              style={styles.numberButton}
              onPress={() => updateProperty(key, value + 1)}
            >
              <Text style={styles.numberButtonText}>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }

    // String
    if (typeof value === 'string') {
      // Color
      if (key.toLowerCase().includes('color') || key === 'backgroundColor' || key === 'textColor' || key === 'statusBarColor') {
        const presetColors = ['#BB86FC', '#03DAC6', '#FF6B35', '#CF6679', '#FFFFFF', '#000000', '#121212', '#1E1E1E', '#2C2C2C', '#4CAF50'];
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.colorInputContainer}>
              <View style={[styles.colorPreview, { backgroundColor: value || 'transparent' }]} />
              <TextInput
                style={[styles.textInput, { flex: 1 }]}
                value={value}
                onChangeText={(text) => updateProperty(key, text)}
              />
            </View>
            <View style={styles.colorPresets}>
              {presetColors.map(color => (
                <TouchableOpacity
                  key={color}
                  style={[styles.colorPreset, { backgroundColor: color }]}
                  onPress={() => updateProperty(key, color)}
                />
              ))}
            </View>
          </View>
        );
      }

      // Width / Height
      if (key === 'width' || key === 'height') {
        const isCustom = !isNaN(parseInt(value));
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.segmentedControl}>
              {['match_parent', 'wrap_content'].map(option => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.segmentedButton,
                    value === option && styles.segmentedButtonActive,
                  ]}
                  onPress={() => updateProperty(key, option)}
                >
                  <Text style={[
                    styles.segmentedButtonText,
                    value === option && styles.segmentedButtonTextActive,
                  ]}>
                    {option === 'match_parent' ? 'Fill' : 'Wrap'}
                  </Text>
                </TouchableOpacity>
              ))}
              <TouchableOpacity
                style={[
                  styles.segmentedButton,
                  isCustom && styles.segmentedButtonActive,
                ]}
                onPress={() => updateProperty(key, 100)}
              >
                <Text style={[
                  styles.segmentedButtonText,
                  isCustom && styles.segmentedButtonTextActive,
                ]}>
                  Px
                </Text>
              </TouchableOpacity>
            </View>
            {isCustom && (
              <TextInput
                style={[styles.textInput, { marginTop: 6 }]}
                value={value}
                onChangeText={(text) => updateProperty(key, parseInt(text) || 0)}
                keyboardType="numeric"
              />
            )}
          </View>
        );
      }

      // Orientation
      if (key === 'orientation') {
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.segmentedControl}>
              {['vertical', 'horizontal'].map(option => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.segmentedButton,
                    value === option && styles.segmentedButtonActive,
                  ]}
                  onPress={() => updateProperty(key, option)}
                >
                  <Text style={[
                    styles.segmentedButtonText,
                    value === option && styles.segmentedButtonTextActive,
                  ]}>
                    {option === 'vertical' ? '↕ Vertical' : '↔ Horizontal'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );
      }

      // Gravity / TextAlign
      if (key === 'gravity' || key === 'textAlign') {
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.segmentedControl}>
              {['left', 'center', 'right'].map(option => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.segmentedButton,
                    value === option && styles.segmentedButtonActive,
                  ]}
                  onPress={() => updateProperty(key, option)}
                >
                  <Text style={[
                    styles.segmentedButtonText,
                    value === option && styles.segmentedButtonTextActive,
                  ]}>
                    {option === 'left' ? '⬅ L' : option === 'center' ? '⬛ C' : '➡ R'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );
      }

      // TextStyle
      if (key === 'textStyle') {
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.segmentedControl}>
              {['normal', 'bold', 'italic'].map(option => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.segmentedButton,
                    value === option && styles.segmentedButtonActive,
                  ]}
                  onPress={() => updateProperty(key, option)}
                >
                  <Text style={[
                    styles.segmentedButtonText,
                    value === option && styles.segmentedButtonTextActive,
                    { fontWeight: option === 'bold' ? 'bold' : 'normal', fontStyle: option === 'italic' ? 'italic' : 'normal' },
                  ]}>
                    {option === 'normal' ? 'Aa' : option === 'bold' ? 'B' : 'I'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );
      }

      // ScaleType
      if (key === 'scaleType') {
        return (
          <View key={key} style={styles.propertyRow}>
            <Text style={styles.propertyLabel}>{key}</Text>
            <View style={styles.segmentedControl}>
              {['centerCrop', 'fitCenter', 'centerInside'].map(option => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.segmentedButton,
                    value === option && styles.segmentedButtonActive,
                  ]}
                  onPress={() => updateProperty(key, option)}
                >
                  <Text style={[
                    styles.segmentedButtonText,
                    value === option && styles.segmentedButtonTextActive,
                  ]}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );
      }

      // Default text input
      return (
        <View key={key} style={styles.propertyRow}>
          <Text style={styles.propertyLabel}>{key}</Text>
          <TextInput
            style={styles.textInput}
            value={value}
            onChangeText={(text) => updateProperty(key, text)}
            multiline={key === 'text' && value.length > 30}
          />
        </View>
      );
    }

    return null;
  };

  const renderPropsSection = () => (
    <ScrollView style={styles.propertiesList} showsVerticalScrollIndicator={false}>
      {/* Component type info */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Компонент</Text>
      </View>
      <View style={styles.componentInfo}>
        <Text style={styles.componentTypeText}>{selectedComponent.type}</Text>
        <Text style={styles.componentIdText}>ID: {selectedComponent.id.slice(0, 8)}...</Text>
        {isContainer && (
          <View style={styles.containerBadgeLarge}>
            <Text style={styles.containerBadgeText}>Контейнер ({selectedComponent.children?.length || 0} дочерних)</Text>
          </View>
        )}
      </View>

      {/* Properties */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Свойства</Text>
      </View>
      {selectedComponent.props && Object.entries(selectedComponent.props).map(([key, value]) => (
        renderPropertyInput(key, value)
      ))}
    </ScrollView>
  );

  const renderEventsSection = () => (
    <ScrollView style={styles.propertiesList} showsVerticalScrollIndicator={false}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>События</Text>
      </View>
      <Text style={styles.eventsHint}>
        События настраиваются в блочном редакторе.
        Перейдите на вкладку "Блоки" для добавления логики.
      </Text>
      
      <View style={styles.eventItem}>
        <Text style={styles.eventIcon}>👆</Text>
        <View style={styles.eventInfo}>
          <Text style={styles.eventName}>onClick</Text>
          <Text style={styles.eventDesc}>При нажатии на компонент</Text>
        </View>
      </View>
      <View style={styles.eventItem}>
        <Text style={styles.eventIcon}>📝</Text>
        <View style={styles.eventInfo}>
          <Text style={styles.eventName}>onChange</Text>
          <Text style={styles.eventDesc}>При изменении значения</Text>
        </View>
      </View>
      <View style={styles.eventItem}>
        <Text style={styles.eventIcon}>📏</Text>
        <View style={styles.eventInfo}>
          <Text style={styles.eventName}>onLongPress</Text>
          <Text style={styles.eventDesc}>При долгом нажатии</Text>
        </View>
      </View>
    </ScrollView>
  );

  const renderLayoutSection = () => (
    <ScrollView style={styles.propertiesList} showsVerticalScrollIndicator={false}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Расположение</Text>
      </View>
      
      {renderPropertyInput('width', selectedComponent.props?.width || 'wrap_content')}
      {renderPropertyInput('height', selectedComponent.props?.height || 'wrap_content')}
      
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Отступы</Text>
      </View>
      
      {selectedComponent.props?.padding !== undefined && renderPropertyInput('padding', selectedComponent.props.padding)}
      {selectedComponent.props?.margin !== undefined && renderPropertyInput('margin', selectedComponent.props.margin)}
      
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Внешний вид</Text>
      </View>
      
      {selectedComponent.props?.backgroundColor !== undefined && renderPropertyInput('backgroundColor', selectedComponent.props.backgroundColor)}
      {selectedComponent.props?.borderRadius !== undefined && renderPropertyInput('borderRadius', selectedComponent.props.borderRadius)}
    </ScrollView>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.title}>Свойства</Text>
          <View style={styles.componentBadge}>
            <Text style={styles.componentBadgeText}>{selectedComponent.type}</Text>
          </View>
        </View>
      </View>

      {/* Section tabs */}
      <View style={styles.sectionTabs}>
        <TouchableOpacity
          style={[styles.sectionTab, activeSection === 'props' && styles.activeSectionTab]}
          onPress={() => setActiveSection('props')}
        >
          <Text style={[styles.sectionTabText, activeSection === 'props' && styles.activeSectionTabText]}>
            ⚙ Все
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sectionTab, activeSection === 'layout' && styles.activeSectionTab]}
          onPress={() => setActiveSection('layout')}
        >
          <Text style={[styles.sectionTabText, activeSection === 'layout' && styles.activeSectionTabText]}>
            📐 Layout
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sectionTab, activeSection === 'events' && styles.activeSectionTab]}
          onPress={() => setActiveSection('events')}
        >
          <Text style={[styles.sectionTabText, activeSection === 'events' && styles.activeSectionTabText]}>
            ⚡ Events
          </Text>
        </TouchableOpacity>
      </View>

      {activeSection === 'props' && renderPropsSection()}
      {activeSection === 'layout' && renderLayoutSection()}
      {activeSection === 'events' && renderEventsSection()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 270,
    backgroundColor: colors.surface,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.onSurface,
  },
  componentBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  componentBadgeText: {
    color: colors.onPrimary,
    fontSize: 10,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 20,
  },
  sectionTabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTab: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeSectionTab: {
    borderBottomColor: colors.primary,
  },
  sectionTabText: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    fontWeight: '500',
  },
  activeSectionTabText: {
    color: colors.primary,
    fontWeight: 'bold',
  },
  propertiesList: {
    flex: 1,
  },
  sectionHeader: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: colors.surfaceLight,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.onSurfaceVariant,
    textTransform: 'uppercase',
  },
  componentInfo: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  componentTypeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.onSurface,
  },
  componentIdText: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    fontFamily: 'monospace',
    marginTop: 2,
  },
  containerBadgeLarge: {
    backgroundColor: colors.secondary + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginTop: 6,
    alignSelf: 'flex-start',
  },
  containerBadgeText: {
    color: colors.secondary,
    fontSize: 11,
    fontWeight: '600',
  },
  propertyRow: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  propertyRowHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  propertyLabel: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    marginBottom: 4,
    fontWeight: '600',
  },
  textInput: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 6,
    padding: 8,
    fontSize: 13,
    color: colors.onSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  numberInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  numberInput: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 6,
    padding: 8,
    fontSize: 13,
    color: colors.onSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
    flex: 1,
    textAlign: 'center',
  },
  numberButton: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: colors.surfaceLight,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  numberButtonText: {
    color: colors.onSurface,
    fontSize: 16,
    fontWeight: 'bold',
  },
  colorInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  colorPreview: {
    width: 32,
    height: 32,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  colorPresets: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    marginTop: 6,
  },
  colorPreset: {
    width: 22,
    height: 22,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  segmentedControl: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceLight,
    borderRadius: 6,
    padding: 2,
    gap: 2,
  },
  segmentedButton: {
    flex: 1,
    paddingVertical: 6,
    paddingHorizontal: 4,
    borderRadius: 4,
    alignItems: 'center',
  },
  segmentedButtonActive: {
    backgroundColor: colors.primary,
  },
  segmentedButtonText: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    fontWeight: '600',
  },
  segmentedButtonTextActive: {
    color: colors.onPrimary,
  },
  eventsHint: {
    color: colors.onSurfaceVariant,
    fontSize: 12,
    padding: 12,
    lineHeight: 18,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  eventItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  eventIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  eventInfo: {
    flex: 1,
  },
  eventName: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.onSurface,
    fontFamily: 'monospace',
  },
  eventDesc: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
});

export default PropertyPanel;
