import React, { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Icon, componentIcons } from './Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { SegmentedControl } from './AppUI';

const findNode = (root, id) => {
  if (!root) return null;
  if (root.id === id) return root;
  for (const child of root.children || []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return null;
};

const updateNode = (root, id, updater) => {
  if (root.id === id) return updater(root);
  return { ...root, children: (root.children || []).map((child) => updateNode(child, id, updater)) };
};

const PropertyPanel = ({ compact = false }) => {
  const { selectedComponentId, getCurrentScreen, updateComponentTree } = useProject();
  const { colors, language, t } = useAppSettings();
  const styles = useMemo(() => createStyles(colors, compact), [colors, compact]);
  const screen = getCurrentScreen();
  const component = findNode(screen?.rootComponent, selectedComponentId);

  if (!component) {
    return (
      <View style={styles.container}>
        <View style={styles.header}><Icon name="options-outline" size={17} color={colors.primary} /><Text style={styles.headerText}>{t('properties')}</Text></View>
        <View style={styles.empty}><Icon name="locate-outline" size={34} color={colors.textTertiary} /><Text style={styles.emptyTitle}>{language === 'ru' ? 'Компонент не выбран' : 'No component selected'}</Text><Text style={styles.emptyText}>{language === 'ru' ? 'Выберите элемент на холсте или в иерархии.' : 'Select an element on the canvas or in the hierarchy.'}</Text></View>
      </View>
    );
  }

  const setProp = (key, value) => updateComponentTree(updateNode(screen.rootComponent, component.id, (node) => ({ ...node, props: { ...node.props, [key]: value } })));
  const p = component.props || {};
  const icon = componentIcons[component.type] || { name: 'cube-outline', color: colors.primary };
  const numeric = ['textSize', 'padding', 'spacing', 'borderRadius', 'height', 'width', 'progress', 'strokeWidth', 'size', 'elevation'];
  const hidden = new Set(['checked', 'enabled', 'singleLine', 'textStyle', 'textAlign', 'horizontalAlignment', 'verticalAlignment', 'topBar', 'horizontalArrangement', 'verticalArrangement']);
  const ordered = ['text', 'label', 'hint', 'url', 'iconName', 'contentDescription', 'textStyle', 'textAlign', 'horizontalAlignment', 'verticalAlignment', 'checked', 'enabled', 'singleLine', 'width', 'height', 'padding', 'spacing', 'textSize', 'progress', 'strokeWidth', 'size', 'borderRadius', 'elevation', 'textColor', 'backgroundColor', 'color', 'trackColor', 'tint'];
  const keys = [...new Set([...ordered, ...Object.keys(p)])].filter((key) => key in p);

  const renderField = (key) => {
    const value = p[key];
    if (key === 'orientation') return <View key={key} style={styles.group}><Text style={styles.label}>Orientation</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'vertical', label: 'Vertical', icon: 'swap-vertical-outline' }, { value: 'horizontal', label: 'Horizontal', icon: 'swap-horizontal-outline' }]} /></View>;
    if (key === 'gravity') return <View key={key} style={styles.group}><Text style={styles.label}>Alignment</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'left', label: 'Start' }, { value: 'center', label: 'Center' }, { value: 'right', label: 'End' }]} /></View>;
    if (key === 'textStyle') return <View key={key} style={styles.group}><Text style={styles.label}>Font style</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'normal', label: 'Normal' }, { value: 'bold', label: 'Bold' }, { value: 'italic', label: 'Italic' }]} /></View>;
    if (key === 'textAlign') return <View key={key} style={styles.group}><Text style={styles.label}>Text align</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'start', label: 'Start' }, { value: 'center', label: 'Center' }, { value: 'end', label: 'End' }]} /></View>;
    if (key === 'horizontalAlignment') return <View key={key} style={styles.group}><Text style={styles.label}>Horizontal alignment</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'start', label: 'Start' }, { value: 'center', label: 'Center' }, { value: 'end', label: 'End' }]} /></View>;
    if (key === 'verticalAlignment') return <View key={key} style={styles.group}><Text style={styles.label}>Vertical alignment</Text><SegmentedControl compact value={value} onChange={(next) => setProp(key, next)} options={[{ value: 'top', label: 'Top' }, { value: 'center', label: 'Center' }, { value: 'bottom', label: 'Bottom' }]} /></View>;
    if (['checked', 'enabled', 'singleLine'].includes(key)) return <View key={key} style={styles.switchRow}><Text style={styles.label}>{key}</Text><Switch value={Boolean(value)} onValueChange={(next) => setProp(key, next)} trackColor={{ false: colors.borderLight, true: colors.primary }} thumbColor="#FFFFFF" /></View>;
    if (hidden.has(key)) return null;
    const color = /color/i.test(key);
    return (
      <View key={key} style={styles.group}>
        <Text style={styles.label}>{key}</Text>
        <View style={styles.fieldRow}>
          {color ? <View style={[styles.swatch, { backgroundColor: String(value) }]} /> : null}
          <TextInput
            value={String(value ?? '')}
            onChangeText={(text) => setProp(key, numeric.includes(key) && /^-?\d*(\.\d*)?$/.test(text) && text !== '' ? Number(text) : text)}
            keyboardType={numeric.includes(key) ? 'numeric' : 'default'}
            autoCapitalize="none"
            placeholderTextColor={colors.textTertiary}
            style={styles.input}
          />
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}><Icon name="options-outline" size={17} color={colors.primary} /><Text style={styles.headerText}>{t('properties')}</Text></View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={styles.componentHead}>
          <View style={[styles.componentIcon, { backgroundColor: `${icon.color}18` }]}><Icon name={icon.name} type={icon.type} size={20} color={icon.color} /></View>
          <View style={{ flex: 1 }}><Text style={styles.componentName}>{component.type}</Text><Text style={styles.componentId} numberOfLines={1}>{component.id}</Text></View>
        </View>
        <Text style={styles.sectionLabel}>{language === 'ru' ? 'Параметры' : 'Properties'}</Text>
        {keys.map(renderField)}
      </ScrollView>
    </View>
  );
};

const createStyles = (c, compact) => StyleSheet.create({
  container: { flex: 1, backgroundColor: c.bgCard },
  header: { minHeight: 48, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 8, borderBottomWidth: 1, borderBottomColor: c.border },
  headerText: { color: c.text, fontSize: 13, fontWeight: '750' },
  content: { padding: compact ? 11 : 14, paddingBottom: 30 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 22 },
  emptyTitle: { color: c.text, fontSize: 13, fontWeight: '700', marginTop: 10 },
  emptyText: { color: c.textTertiary, fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: 4 },
  componentHead: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: c.border },
  componentIcon: { width: 40, height: 40, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  componentName: { color: c.text, fontSize: 13, fontWeight: '750' },
  componentId: { color: c.textTertiary, fontSize: 8, fontFamily: 'monospace', marginTop: 3 },
  sectionLabel: { color: c.textTertiary, fontSize: 9, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.7, marginTop: 14, marginBottom: 10 },
  group: { gap: 5, marginBottom: 11 },
  label: { color: c.textSecondary, fontSize: 10, fontWeight: '650' },
  fieldRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  input: { flex: 1, minHeight: 39, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7, backgroundColor: c.bgInput, borderWidth: 1, borderColor: c.borderLight, color: c.text, fontSize: 11, fontFamily: 'monospace' },
  swatch: { width: 30, height: 30, borderRadius: 7, borderWidth: 1, borderColor: c.borderLight },
  switchRow: { minHeight: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
});

export default PropertyPanel;
