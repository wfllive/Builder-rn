import React from 'react';
import { Ionicons, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';

export const Icon = ({ name, size = 20, color = '#111827', type = 'ionicons', style }) => {
  const props = { name, size, color, style };
  if (type === 'material') return <MaterialIcons {...props} />;
  if (type === 'community') return <MaterialCommunityIcons {...props} />;
  return <Ionicons {...props} />;
};

export const componentIcons = {
  Column: { name: 'reorder-four-outline', color: '#7C3AED' },
  Row: { name: 'reorder-three-outline', color: '#7C3AED' },
  Box: { name: 'square-outline', color: '#7C3AED' },
  LazyColumn: { name: 'list-outline', color: '#7C3AED' },
  Card: { name: 'card-outline', color: '#7C3AED' },
  Text: { name: 'text-outline', color: '#2563EB' },
  Button: { name: 'radio-button-on-outline', color: '#2563EB' },
  OutlinedTextField: { name: 'create-outline', color: '#EA580C' },
  Image: { name: 'image-outline', color: '#0891B2' },
  Checkbox: { name: 'checkbox-outline', color: '#EA580C' },
  Switch: { name: 'toggle-outline', color: '#EA580C' },
  LinearProgressIndicator: { name: 'remove-outline', color: '#2563EB' },
  CircularProgressIndicator: { name: 'sync-outline', color: '#2563EB' },
  HorizontalDivider: { name: 'remove-outline', color: '#64748B' },
  Spacer: { name: 'expand-outline', color: '#64748B' },
  Icon: { name: 'star-outline', color: '#0891B2' },
  WebView: { name: 'globe-outline', color: '#0891B2' },
};

export default Icon;
