import React from 'react';
import { Ionicons, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';

// Обёртка для иконок
export const Icon = ({ name, size = 20, color = '#111827', type = 'ionicons', style }) => {
  const props = { name, size, color, style };
  switch (type) {
    case 'material':
      return <MaterialIcons {...props} />;
    case 'community':
      return <MaterialCommunityIcons {...props} />;
    default:
      return <Ionicons {...props} />;
  }
};

// Иконки компонентов — ВСЕ через Ionicons (надёжнее чем Material)
export const componentIcons = {
  LinearLayout: { name: 'layers-outline', type: 'ionicons', color: '#7C3AED' },
  ScrollView:   { name: 'swap-vertical-outline', type: 'ionicons', color: '#7C3AED' },
  CardView:     { name: 'card-outline', type: 'ionicons', color: '#7C3AED' },
  TextView:     { name: 'text-outline', type: 'ionicons', color: '#2563EB' },
  Button:       { name: 'finger-print-outline', type: 'ionicons', color: '#2563EB' },
  EditText:     { name: 'create-outline', type: 'ionicons', color: '#EA580C' },
  ImageView:    { name: 'image-outline', type: 'ionicons', color: '#0891B2' },
  CheckBox:     { name: 'checkbox-outline', type: 'ionicons', color: '#EA580C' },
  Switch:       { name: 'toggle-outline', type: 'ionicons', color: '#EA580C' },
  ProgressBar:  { name: 'speedometer-outline', type: 'ionicons', color: '#2563EB' },
  Divider:      { name: 'remove-outline', type: 'ionicons', color: '#9CA3AF' },
  Spacer:       { name: 'expand-outline', type: 'ionicons', color: '#9CA3AF' },
  WebView:      { name: 'globe-outline', type: 'ionicons', color: '#0891B2' },
  MapView:      { name: 'map-outline', type: 'ionicons', color: '#0891B2' },
};

export default Icon;
