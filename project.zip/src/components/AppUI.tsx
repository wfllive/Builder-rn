import React
{ useMemo } from 'react';
import { ActivityIndicator
Pressable
Text
TextInput
View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from './Icon';
import { useAppSettings } from '../store/appSettings';
export const AppScreen = ({ children
style
safe = true }) => {
  const { colors } = useAppSettings();
  const Component = safe ? SafeAreaView : View;
  return <Component className="flex-1 bg-bg" style={style}>{children}</Component>;
};
export const IconButton = ({ name
label
accessibilityLabel
onPress
disabled
active
danger
size = 20
style }) => {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || label || name}
      disabled={disabled}
      onPress={onPress}
      className={`min-w-[42px] h-[42px] rounded-xl border flex-row items-center justify-center gap-[7px] ${
        active ? 'bg-primarySurface border-primary' : danger ? 'bg-errorBg border-error' : 'bg-bgElevated border-border'
      } ${disabled ? 'opacity-40' : 'opacity-100 active:opacity-70'}`}
      style={style}
    >
      <Icon name={name} size={size} color={danger ? '#EF4444' : active ? '#4F46E5' : '#64748B'} />
      {label ? <Text className={`text-[13px] font-bold ${danger ? 'text-error' : 'text-text'}`}>{label}</Text> : null}
    </Pressable>
  );
};
export const TopBar = ({ title
subtitle
onBack
left
right
compact = false }) => {
  return (
    <View className={`min-h-[58px] md:min-h-[66px] px-4 md:px-4 py-2 flex-row items-center gap-[10px] bg-bgCard border-b border-border ${compact ? 'min-h-[58px] px-3' : ''}`}>
      {onBack ? <IconButton name="arrow-back" onPress={onBack} accessibilityLabel="Back" style={{ minWidth: 42
paddingHorizontal: 0 }} /> : left}
      <View className="flex-1 min-w-0">
        <Text className={`text-text font-extrabold ${compact ? 'text-base' : 'text-lg'}`} numberOfLines={1}>{title}</Text>
        {subtitle ? <Text className="text-textSecondary text-[11px] mt-[2px]" numberOfLines={1}>{subtitle}</Text> : null}
      </View>
      {right ? <View className="flex-row items-center gap-[7px]">{right}</View> : null}
    </View>
  );
};
export const PrimaryButton = ({ title
icon
onPress
disabled
loading
destructive
style }) => {
  const bgColor = destructive ? '#EF4444' : '#4F46E5';
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={onPress}
      className={`min-h-[46px] rounded-[11px] px-[18px] flex-row items-center justify-center gap-[8px] ${disabled ? 'opacity-45' : 'opacity-100 active:opacity-80'}`}
      style={[{ backgroundColor: bgColor }
style]}
    >
      {loading ? <ActivityIndicator color="#FFFFFF" size="small" /> : icon ? <Icon name={icon} color="#FFFFFF" size={18} /> : null}
      <Text className="text-white text-[14px] font-extrabold">{title}</Text>
    </Pressable>
  );
};
export const Field = ({ label
hint
style
...props }) => {
  return (
    <View className="gap-[6px]" style={style}>
      {label ? <Text className="text-textSecondary text-[12px] font-bold">{label}</Text> : null}
      <TextInput
        placeholderTextColor="#94A3B8"
        selectionColor="#4F46E5"
        {...props}
        className="min-h-[46px] border border-borderLight rounded-[10px] px-[13px] py-[10px] bg-bgInput text-text text-[14px]"
        style={props.style}
      />
      {hint ? <Text className="text-textTertiary text-[11px] leading-[16px]">{hint}</Text> : null}
    </View>
  );
};
export const SegmentedControl = ({ options
value
onChange
compact = false }) => {
  return (
    <View className="flex-row rounded-[11px] p-[3px] bg-bgElevated border border-border">
      {options.map((option) => {
        const selected = option.value === value;
        return (
          <Pressable
            key={option.value}
            onPress={() => onChange(option.value)}
            className={`flex-1 min-h-[34px] md:min-h-[39px] px-[10px] rounded-[8px] flex-row items-center justify-center gap-[6px] ${selected ? 'bg-bgCard border border-borderLight' : 'bg-transparent border-0'}`}
          >
            {option.icon ? <Icon name={option.icon} size={16} color={selected ? '#4F46E5' : '#64748B'} /> : null}
            <Text numberOfLines={1} className={`text-[12px] font-medium ${selected ? 'text-text font-bold' : 'text-textSecondary'}`}>
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
};
export const SectionCard = ({ title
icon
children
style
right }) => {
  return (
    <View className="bg-bgCard rounded-[14px] border border-border p-[16px] gap-[14px]" style={style}>
      {title ? (
        <View className="flex-row items-center gap-[9px]">
          {icon ? <Icon name={icon} size={18} color="#4F46E5" /> : null}
          <Text className="text-text text-[15px] font-extrabold flex-1">{title}</Text>
          {right}
        </View>
      ) : null}
      {children}
    </View>
  );
};
export const StatusPill = ({ label
tone = 'neutral' }) => {
  const toneMap = {
    success: 'bg-successBg text-successText'
    warning: 'bg-warningBg text-warningText'
    error: 'bg-errorBg text-errorText'
    info: 'bg-infoBg text-infoText'
    neutral: 'bg-bgElevated text-textSecondary'
  };
  const toneClasses = toneMap[tone] || toneMap.neutral;
  return <View className={`rounded-full px-[9px] py-[4px] ${toneClasses}`}><Text className="text-[10px] font-extrabold">{label}</Text></View>;
};