import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { MAP_STYLES } from '@/constants/config';

// Simple wind mode: MapLibre map with dark style + info panel
// Full particle wind requires native GL, left as future enhancement.
// We show a placeholder with wind speed info.

export function WindOverlay({ position, config, updateConfig }: any) {
  return (
    <View style={styles.container}>
      <MapLibreGL.MapView
        style={styles.map}
        styleURL={MAP_STYLES.dark.url}
        logoEnabled={false}
        attributionEnabled={false}
      >
        <MapLibreGL.Camera
          zoomLevel={3}
          centerCoordinate={ position ? [position[1], position[0]] : [37.6, 55.75] }
        />
      </MapLibreGL.MapView>

      {/* Info panel */}
      <View style={styles.info}>
        <Text style={styles.infoTitle}>🌬️ Ветер</Text>
        <Text style={styles.infoText}>Режим ветра активен</Text>
        <Text style={styles.infoSub}>MapTiler Weather SDK недоступен в React Native без WebView.</Text>
        <Text style={styles.infoSub}>Используется MapLibre базовая карта. Частицы ветра — TODO (Skia / custom native layer).</Text>
        <Text style={styles.infoSub}>Opacity: {config.windOpacity}% • Size: {config.windSize} • Density: {config.windDensity}</Text>
      </View>

      {/* color legend */}
      <View style={styles.legend}>
        {[
          ['#ffffff','0 m/s'],
          ['#facc15','15'],
          ['#fb923c','20'],
          ['#f97316','25'],
          ['#ef4444','30'],
          ['#e11d48','35+'],
        ].map(([c,l])=>(
          <View key={l} style={styles.legendRow}>
            <View style={[styles.legendDot,{backgroundColor:c}]} />
            <Text style={styles.legendText}>{l}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { ...StyleSheet.absoluteFillObject, zIndex: 2, backgroundColor:'#0a0a1a' },
  map: { flex:1 },
  info: { position:'absolute', top:120, left:16, right:90, backgroundColor:'rgba(8,13,26,0.9)', padding:14, borderRadius:14, borderWidth:1, borderColor:'rgba(255,255,255,0.08)' },
  infoTitle:{ color:'#22d3ee', fontWeight:'800', fontSize:16, marginBottom:4 },
  infoText:{ color:'#fff', marginBottom:6 },
  infoSub:{ color:'#9ca3af', fontSize:12, marginTop:2 },
  legend:{ position:'absolute', bottom:120, left:16, backgroundColor:'rgba(8,13,26,0.9)', padding:10, borderRadius:12 },
  legendRow:{ flexDirection:'row', alignItems:'center', marginBottom:4 },
  legendDot:{ width:12, height:12, borderRadius:6, marginRight:6 },
  legendText:{ color:'#e5e7eb', fontSize:12 },
});
