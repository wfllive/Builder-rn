import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon } from './Icon';
import { IconButton, PrimaryButton, SectionCard, StatusPill } from './AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';
import { RuntimeWidget } from '../screens/LivePreviewScreen';

const METRO_DIR = '.rn-studio';
const METRO_PORT = 8081;

const EditorDevClientPreview = ({ onOpenFullscreen }) => {
  const { currentProject, getCurrentScreen, addWorkspaceLog } = useProject();
  const { colors, language } = useAppSettings();
  const screen = getCurrentScreen();
  const [panelWidth, setPanelWidth] = useState(0);
  const [serverState, setServerState] = useState('checking');
  const [serverLog, setServerLog] = useState('');
  const [devUrl, setDevUrl] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const stacked = panelWidth > 0 && panelWidth < 820;
  const primary = currentProject?.theme?.primaryColor || '#4F46E5';

  const copy = language === 'ru' ? {
    title: 'Предпросмотр Dev Client',
    subtitle: 'Metro и управление development client находятся внутри редактора',
    device: 'Интерактивный экран',
    deviceHint: 'Холст обновляется сразу при изменении компонентов.',
    devClient: 'Expo Development Client',
    real: 'Настоящий Metro',
    stopped: 'Остановлен',
    starting: 'Запускается',
    running: 'Работает',
    error: 'Ошибка',
    start: 'Запустить Metro',
    stop: 'Остановить',
    refresh: 'Обновить',
    open: 'Открыть Dev Client',
    fullscreen: 'На весь экран',
    install: 'Проверяем expo-dev-client и запускаем Metro внутри Ubuntu…',
    waiting: 'Metro запускается. Ссылка development client появится в журнале.',
    explanation: 'Это реальный сервер Expo с флагом --dev-client. Сам development client является отдельным нативным приложением проекта, поэтому ссылка открывает установленный APK, а управление и журнал остаются здесь, в редакторе.',
    output: 'Вывод Metro',
    emptyOutput: 'После запуска здесь появится вывод Metro Bundler.',
  } : {
    title: 'Dev Client preview',
    subtitle: 'Metro and development-client controls live inside the editor',
    device: 'Interactive screen',
    deviceHint: 'The canvas updates immediately when components change.',
    devClient: 'Expo Development Client',
    real: 'Real Metro',
    stopped: 'Stopped',
    starting: 'Starting',
    running: 'Running',
    error: 'Error',
    start: 'Start Metro',
    stop: 'Stop',
    refresh: 'Refresh',
    open: 'Open Dev Client',
    fullscreen: 'Full screen',
    install: 'Checking expo-dev-client and starting Metro inside Ubuntu…',
    waiting: 'Metro is starting. The development-client URL will appear in the output.',
    explanation: 'This is a real Expo server running with --dev-client. The development client is the project’s separate native app, so the link opens its installed APK while controls and output stay here in the editor.',
    output: 'Metro output',
    emptyOutput: 'Metro Bundler output will appear here after startup.',
  };

  const parseUrl = (output) => {
    const urls = String(output || '').match(/(?:exp\+[a-z0-9+.-]+:\/\/[^\s]+|https?:\/\/[^\s]+|exp:\/\/[^\s]+)/gi);
    const value = urls?.[urls.length - 1]?.replace(/[),.;]+$/, '') || '';
    if (value) setDevUrl(value);
    return value;
  };

  const refresh = useCallback(async (silent = false) => {
    if (!currentProject) return;
    const cwd = getProjectDir(currentProject);
    const [processResult, logResult] = await Promise.all([
      execute(`[ -f ${METRO_DIR}/metro.pid ] && kill -0 $(cat ${METRO_DIR}/metro.pid) 2>/dev/null`, cwd),
      execute(`cat ${METRO_DIR}/metro.log 2>/dev/null || true`, cwd),
    ]);
    const output = logResult?.output || '';
    setServerLog(output);
    parseUrl(output);
    if (processResult?.success) setServerState('running');
    else if (!silent) setServerState((value) => value === 'error' ? value : 'stopped');
  }, [currentProject?.id]);

  useEffect(() => { refresh(); }, [refresh]);

  useEffect(() => {
    if (serverState !== 'running' && serverState !== 'starting') return undefined;
    const timer = setInterval(() => refresh(true), 1800);
    return () => clearInterval(timer);
  }, [serverState, refresh]);

  const start = async () => {
    if (!currentProject || serverState === 'starting') return;
    const cwd = getProjectDir(currentProject);
    setServerState('starting');
    setServerLog(copy.install);
    setDevUrl('');
    addWorkspaceLog(copy.install, 'info');
    try {
      const installResult = await execute('npx expo install expo-dev-client 2>&1', cwd);
      if (!installResult?.success) throw new Error(installResult?.output || 'expo-dev-client installation failed');
      const command = [
        `mkdir -p ${METRO_DIR}`,
        `[ ! -f ${METRO_DIR}/metro.pid ] || kill $(cat ${METRO_DIR}/metro.pid) 2>/dev/null || true`,
        `(CI=1 npx expo start --dev-client --lan --port ${METRO_PORT} > ${METRO_DIR}/metro.log 2>&1 & echo $! > ${METRO_DIR}/metro.pid)`,
      ].join('; ');
      const startResult = await execute(command, cwd);
      if (!startResult?.success) throw new Error(startResult?.output || 'Metro failed to start');
      setServerState('running');
      addWorkspaceLog(`Metro Dev Client started on port ${METRO_PORT}`, 'success');
      setTimeout(() => refresh(true), 1400);
    } catch (error) {
      const message = error?.message || String(error);
      setServerLog(message);
      setServerState('error');
      addWorkspaceLog(message, 'error');
    }
  };

  const stop = async () => {
    const cwd = getProjectDir(currentProject);
    await execute(`[ ! -f ${METRO_DIR}/metro.pid ] || kill $(cat ${METRO_DIR}/metro.pid) 2>/dev/null || true; rm -f ${METRO_DIR}/metro.pid`, cwd);
    setServerState('stopped');
    addWorkspaceLog('Metro Dev Client stopped', 'info');
  };

  const status = serverState === 'running'
    ? { label: copy.running, tone: 'success' }
    : serverState === 'starting' || serverState === 'checking'
      ? { label: copy.starting, tone: 'info' }
      : serverState === 'error'
        ? { label: copy.error, tone: 'error' }
        : { label: copy.stopped, tone: 'neutral' };

  if (!screen) return null;

  return (
    <View style={styles.root} onLayout={(event) => setPanelWidth(event.nativeEvent.layout.width)}>
      <View style={styles.header}>
        <View style={styles.headerIcon}><Icon name="phone-portrait-outline" size={20} color={colors.primary} /></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.title}>{copy.title}</Text>
          <Text style={styles.subtitle} numberOfLines={1}>{copy.subtitle}</Text>
        </View>
        <StatusPill label={status.label} tone={status.tone} />
        <IconButton name="expand-outline" label={!stacked ? copy.fullscreen : null} onPress={onOpenFullscreen} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={[styles.columns, stacked && styles.columnsStacked]}>
          <View style={[styles.deviceColumn, stacked && styles.deviceColumnStacked]}>
            <View style={styles.sectionHeading}>
              <View><Text style={styles.sectionTitle}>{copy.device}</Text><Text style={styles.sectionHint}>{copy.deviceHint}</Text></View>
            </View>
            <View style={styles.deviceOuter}>
              <View style={styles.device}>
                <View style={styles.statusBar}>
                  <Text style={styles.statusTime}>9:41</Text>
                  <View style={styles.statusIcons}><Icon name="cellular" size={11} color="#111827" /><Icon name="wifi" size={11} color="#111827" /><Icon name="battery-full" size={13} color="#111827" /></View>
                </View>
                {screen.showActionBar ? (
                  <View style={[styles.appBar, { backgroundColor: primary }]}>
                    <Icon name="arrow-back" size={18} color="#FFFFFF" />
                    <Text style={styles.appTitle} numberOfLines={1}>{screen.actionBarTitle || screen.name}</Text>
                    <Icon name="ellipsis-vertical" size={17} color="#FFFFFF" />
                  </View>
                ) : null}
                <ScrollView
                  style={[styles.appBody, { backgroundColor: screen.backgroundColor || currentProject.theme?.backgroundColor || '#F8FAFC' }]}
                  contentContainerStyle={{ padding: screen.rootComponent?.props?.padding || 8 }}
                  nestedScrollEnabled
                >
                  <RuntimeWidget component={screen.rootComponent} colors={colors} primary={primary} />
                </ScrollView>
                <View style={styles.navigationBar}><View style={styles.gestureBar} /></View>
              </View>
            </View>
          </View>

          <View style={[styles.toolsColumn, stacked && styles.toolsColumnStacked]}>
            <SectionCard
              title={copy.devClient}
              icon="rocket-outline"
              right={<StatusPill label={copy.real} tone="info" />}
            >
              <Text style={styles.explanation}>{copy.explanation}</Text>
              <View style={styles.commandBox}>
                <Text selectable style={styles.command}>$ npx expo start --dev-client --lan --port {METRO_PORT}</Text>
              </View>
              <View style={styles.actions}>
                {serverState === 'running' ? (
                  <PrimaryButton title={copy.stop} icon="stop-outline" destructive onPress={stop} style={{ flex: 1 }} />
                ) : (
                  <PrimaryButton title={copy.start} icon="play-outline" loading={serverState === 'starting'} onPress={start} style={{ flex: 1 }} />
                )}
                <IconButton name="refresh-outline" label={copy.refresh} onPress={() => refresh()} style={{ flex: 1 }} />
              </View>

              {devUrl ? (
                <View style={styles.connection}>
                  <View style={styles.qr}><QRCode value={devUrl} size={stacked ? 150 : 132} /></View>
                  <Text selectable style={styles.url}>{devUrl}</Text>
                  <PrimaryButton title={copy.open} icon="open-outline" onPress={() => Linking.openURL(devUrl)} />
                </View>
              ) : serverState === 'running' || serverState === 'starting' ? (
                <View style={styles.waiting}><Icon name="sync-outline" size={17} color={colors.info} /><Text style={styles.waitingText}>{copy.waiting}</Text></View>
              ) : null}
            </SectionCard>

            <SectionCard title={copy.output} icon="terminal-outline">
              <ScrollView style={styles.log} nestedScrollEnabled>
                <Text selectable style={styles.logText}>{serverLog || copy.emptyOutput}</Text>
              </ScrollView>
            </SectionCard>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const QRCode = ({ value, size }) => {
  try {
    const QR = require('react-native-qrcode-svg').default;
    return <QR value={value} size={size} backgroundColor="#FFFFFF" color="#111827" />;
  } catch (error) {
    return <Icon name="qr-code-outline" size={Math.round(size / 2)} color="#111827" />;
  }
};

const createStyles = (c) => StyleSheet.create({
  root: { flex: 1, minHeight: 0, backgroundColor: c.bg },
  header: { minHeight: 56, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  headerIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface },
  title: { color: c.text, fontSize: 13, fontWeight: '750' },
  subtitle: { color: c.textSecondary, fontSize: 9, marginTop: 2 },
  scrollContent: { padding: 12, paddingBottom: 32 },
  columns: { width: '100%', maxWidth: 1120, alignSelf: 'center', flexDirection: 'row', alignItems: 'flex-start', gap: 14 },
  columnsStacked: { flexDirection: 'column', alignItems: 'stretch' },
  deviceColumn: { width: 370 },
  deviceColumnStacked: { width: '100%' },
  toolsColumn: { flex: 1, minWidth: 0, gap: 12 },
  toolsColumnStacked: { width: '100%' },
  sectionHeading: { minHeight: 42, justifyContent: 'center', marginBottom: 8 },
  sectionTitle: { color: c.text, fontSize: 12, fontWeight: '700' },
  sectionHint: { color: c.textTertiary, fontSize: 9, marginTop: 2 },
  deviceOuter: { alignItems: 'center', padding: 10, borderRadius: 18, backgroundColor: c.canvas, borderWidth: 1, borderColor: c.border },
  device: { width: 330, height: 600, borderRadius: 26, borderWidth: 6, borderColor: '#111827', overflow: 'hidden', backgroundColor: '#FFFFFF', shadowColor: c.shadow, shadowOpacity: 0.22, shadowRadius: 10, elevation: 6 },
  statusBar: { height: 26, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#FFFFFF' },
  statusTime: { color: '#111827', fontSize: 9, fontWeight: '750' },
  statusIcons: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  appBar: { height: 47, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 10 },
  appTitle: { flex: 1, color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  appBody: { flex: 1 },
  navigationBar: { height: 27, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' },
  gestureBar: { width: 92, height: 4, borderRadius: 2, backgroundColor: '#111827' },
  explanation: { color: c.textSecondary, fontSize: 10, lineHeight: 16 },
  commandBox: { padding: 11, borderRadius: 9, backgroundColor: c.terminal },
  command: { color: '#D9E2F1', fontSize: 9, lineHeight: 15, fontFamily: 'monospace' },
  actions: { flexDirection: 'row', gap: 8 },
  connection: { gap: 10, alignItems: 'stretch' },
  qr: { alignSelf: 'center', padding: 10, borderRadius: 10, backgroundColor: '#FFFFFF' },
  url: { color: c.info, fontSize: 9, lineHeight: 14, textAlign: 'center', fontFamily: 'monospace' },
  waiting: { padding: 10, borderRadius: 9, flexDirection: 'row', alignItems: 'flex-start', gap: 7, backgroundColor: c.infoBg },
  waitingText: { flex: 1, color: c.infoText, fontSize: 9, lineHeight: 14 },
  log: { height: 185, borderRadius: 9, padding: 10, backgroundColor: c.terminal },
  logText: { color: '#B9C5D8', fontSize: 9, lineHeight: 15, fontFamily: 'monospace' },
});

export default EditorDevClientPreview;
