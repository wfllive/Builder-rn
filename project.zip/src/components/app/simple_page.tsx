/**
 * Заготовка внутреннего экрана: стеклянная шапка + текст + таббар.
 */
import React from "react";
import { Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import AppScreen, { type AppTabId } from "./app_screen";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";

export default function SimplePage({
  selected,
  title,
  description,
}: {
  selected: AppTabId;
  title: string;
  description: string;
}) {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");

  return (
    <AppScreen selected={selected} header={<ShortFlexibleHeader title={title} />}>
      <View
        className="flex-1 px-4"
        style={{ paddingTop: insets.top + CHROME_HEADER_BODY + 16 }}
      >
        <Text className="text-base" style={{ color: ink }}>
          {description}
        </Text>
        <Text className="mt-3 text-sm" style={{ color: muted }}>
          Маршрут Expo Router. Контент экрана подключит app-слой.
        </Text>
      </View>
    </AppScreen>
  );
}
