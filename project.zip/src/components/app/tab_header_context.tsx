/**
 * TabHeaderContext — «поднимает» шапку вкладки на уровень Layout.
 *
 * Каждая вкладка (через TabScaffold) регистрирует здесь свой заголовок
 * (title / subtitle / topExtra), а верхний Layout рисует ScreenHeader
 * поверх прокручиваемого контента.
 */
import React, {
  createContext,
  useContext,
  useMemo,
  useState,
} from "react";

export interface TabHeaderConfig {
  title: string;
  subtitle?: string;
  topExtra?: React.ReactNode;
}

interface TabHeaderContextValue {
  config: TabHeaderConfig | null;
  setConfig: (config: TabHeaderConfig | null) => void;
}

const TabHeaderContext = createContext<TabHeaderContextValue | null>(null);

export function TabHeaderProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<TabHeaderConfig | null>(null);
  const value = useMemo<TabHeaderContextValue>(
    () => ({ config, setConfig }),
    [config]
  );
  return (
    <TabHeaderContext.Provider value={value}>
      {children}
    </TabHeaderContext.Provider>
  );
}

export function useTabHeaderContext(): TabHeaderContextValue {
  const ctx = useContext(TabHeaderContext);
  if (!ctx) {
    throw new Error("useTabHeaderContext must be used inside TabHeaderProvider");
  }
  return ctx;
}
