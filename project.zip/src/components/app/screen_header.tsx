/**
 * Шапка ленты: бургер | twitblit | шестерёнка | вход.
 *
 * GlassBar.safeTop — бар заходит под статус-бар и размывает его,
 * как системный chrome iOS. Контент страницы сам добавляет paddingTop.
 */
import React from "react";
import { Text, View } from "react-native";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import FlyDropdown from "@/shared/ui/navigation/flydropdown";
import TButton from "@/shared/ui/buttons/tbutton";
import GlassBar from "@/shared/ui/layout/glass_bar";
import { User3 } from "@/shared/ui/icons/mingcute/user/user_3_line";
import { Settings3 } from "@/shared/ui/icons/mingcute/system/settings_3_line";
import { Exit } from "@/shared/ui/icons/mingcute/system/exit_line";
import { Menu } from "@/shared/ui/icons/mingcute/editor/menu_line";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { useAppMenu } from "@/shared/templates/providers/app_menu_provider";
import { resolveToken } from "@/theme/tokens";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";

export default function ScreenHeader({
  title,
  subtitle,
  extra,
}: {
  title: string;
  subtitle?: string;
  /** Второй ряд (вкладки ленты, поиск) — внутри того же стекла. */
  extra?: React.ReactNode;
}) {
  const { isDark, theme } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const danger = resolveToken(isDark, "red");
  const nav = useAppNavigation();
  const { openMenu } = useAppMenu();
  const { isAuth, user, logout } = useDemoSession();

  const themeHint =
    theme === "system" ? "система" : theme === "dark" ? "тёмная" : "светлая";

  return (
    <GlassBar edge="bottom" dock="top" safeTop>
      <View className="flex-row items-center justify-between px-2 py-2">
        <View className="flex-row items-center flex-1 pr-2">
          <TButton.Text
            onPress={openMenu}
            centerImage={<Menu size={22} color={ink} />}
            accessibilityLabel="Меню"
          />
          <View className="ml-1 flex-1">
            <Text className="text-xl font-extrabold italic text-primary">{title}</Text>
            {subtitle ? (
              <Text className="text-xs mt-0.5" style={{ color: muted }}>
                {subtitle}
              </Text>
            ) : null}
          </View>
        </View>

        <View className="flex-row items-center">
          <TButton.Text
            onPress={() => nav.push("/settings")}
            centerImage={<Settings3 size={20} color={ink} />}
            accessibilityLabel={`Тема: ${themeHint}`}
          />

          {isAuth && user ? (
            <FlyDropdown
              items={[
                {
                  label: `@${user.user_id} · профиль`,
                  prefix: <User3 size={18} color={ink} />,
                  onClick: () => nav.push(`/tb/${user.user_id}`),
                },
                {
                  label: "Настройки",
                  prefix: <Settings3 size={18} color={ink} />,
                  onClick: () => nav.push("/settings"),
                },
                {
                  label: "Выйти из демо",
                  type: "danger",
                  prefix: <Exit size={18} color={danger} />,
                  onClick: logout,
                },
              ]}
              trigger={<FlyAvatar src={user.avatar ?? undefined} alt={user.username} size={36} />}
            />
          ) : (
            <TButton.Text
              onPress={() => nav.push("/auth/login")}
              className="rounded-full"
              centerImage={<User3 size={22} color={ink} />}
              accessibilityLabel="Войти"
            />
          )}
        </View>
      </View>
      {extra}
    </GlassBar>
  );
}
