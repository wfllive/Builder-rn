/**
 * Каркас вкладки: только контент (лента). Стеклянная шапка регистрируется
 * через tab_header_context и рендерится оверлеем на уровне Layout.
 */
import React, { useEffect } from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import { useTabHeaderContext } from "./tab_header_context";

export function useTabHeaderPad(extra = 0) {
  const insets = useSafeAreaInsets();
  return insets.top + CHROME_HEADER_BODY + extra;
}

export function useTabBarPad() {
  const insets = useSafeAreaInsets();
  return Math.max(insets.bottom, 6) + 52;
}

export default function TabScaffold({
  title,
  subtitle,
  topExtra,
  children,
}: {
  title: string;
  subtitle?: string;
  topExtra?: React.ReactNode;
  children?: React.ReactNode;
}) {
  const { setConfig } = useTabHeaderContext();

  // Регистрируем шапку в контексте; Layout рендерит её над стеклом.
  useEffect(() => {
    setConfig({ title, subtitle, topExtra });
    return () => setConfig(null);
  }, [title, subtitle, topExtra, setConfig]);

  return (
    <View collapsable={false} className="flex-1">
      {children}
    </View>
  );
}
