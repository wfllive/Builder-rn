/**
 * Ловит JS-ошибку на старте и показывает её на экране.
 * Без этого uncaught exception в нативной сборке может выглядеть
 * как «вылетело без ошибок».
 */
import React from "react";
import { ScrollView, Text, View } from "react-native";

type Props = { children: React.ReactNode };
type State = { error: Error | null };

export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error("[Twitblit] uncaught", error);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <View style={{ flex: 1, backgroundColor: "#1a1024", padding: 24, paddingTop: 72 }}>
        <Text style={{ color: "#FF95A4", fontSize: 18, fontWeight: "700", marginBottom: 12 }}>
          Приложение упало
        </Text>
        <ScrollView>
          <Text style={{ color: "#F3F5F7", fontSize: 14 }} selectable>
            {this.state.error.message}
          </Text>
          <Text style={{ color: "#a1a1a1", fontSize: 12, marginTop: 16 }} selectable>
            {this.state.error.stack}
          </Text>
        </ScrollView>
      </View>
    );
  }
}
