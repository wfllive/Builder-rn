// app/index.tsx

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
  StyleSheet,
  StatusBar,
  Animated as RNAnimated,
  Easing,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import {
  Bot, Brain, Circle, Gem, Gift, Grid3X3, Home, Menu, Moon,
  Palette, Play, Plus, RotateCcw, Save, Settings, Smartphone, Sparkles,
  Star, Sun, Trash2, Triangle, Trophy, Users, Vibrate, Volume2, VolumeX, X,
} from 'lucide-react-native';
import { BottomStickyBanner, useYandexAds } from './ads/yandexAds';
import '../global.css';

// ─── Типы ────────────────────────────────────────────────────────────────────
type Player = 'X' | 'O';
type Cell = Player | '';
type Winner = Player | 'tie' | null;
type GameMode = 'human' | 'ai';
type Difficulty = 'easy' | 'medium' | 'hard' | 'impossible';
type TimeTheme = 'day' | 'night' | 'neon';
type ThemeColor = 'blue' | 'pink' | 'purple' | 'green' | 'orange';
type StartingPlayer = 'x' | 'o' | 'random';
type SymbolType = 'classic' | 'shapes' | 'stars';
type Screen = 'menu' | 'game';
type SoundName = 'click' | 'moveX' | 'moveO' | 'win' | 'draw' | 'error';
type IconComponent = React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
type Scores = { X: number; O: number; tie: number };
type GameResult = { winner: Winner; line: number[] };
type Symbols = { X: string; O: string };
type SettingsState = {
  themeColor: ThemeColor;
  timeTheme: TimeTheme;
  startingPlayer: StartingPlayer;
  symbolType: SymbolType;
  boardSize: number;
  winCondition: number;
  difficulty: Difficulty;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
};

// ─── Константы ───────────────────────────────────────────────────────────────
const SETTINGS_KEY = 'neonTicTacToeExpoSettings';
const SCORES_KEY = 'neonTicTacToeExpoScores';

const THEME_COLORS: Record<ThemeColor, string> = {
  blue: '#0ea5ff', pink: '#ff3df2', purple: '#a855f7',
  green: '#22c55e', orange: '#f97316',
};
const SYMBOL_SETS: Record<SymbolType, Symbols> = {
  classic: { X: 'X', O: 'O' },
  shapes: { X: '△', O: '○' },
  stars: { X: '★', O: '◇' },
};
const DEFAULT_SETTINGS: SettingsState = {
  themeColor: 'blue', timeTheme: 'night', startingPlayer: 'random',
  symbolType: 'classic', boardSize: 3, winCondition: 3,
  difficulty: 'medium', soundEnabled: true, vibrationEnabled: true,
};
const SOUND_SOURCES: Record<SoundName, number> = {
  click: require('../assets/sounds/click.wav'),
  moveX: require('../assets/sounds/move-x.wav'),
  moveO: require('../assets/sounds/move-o.wav'),
  win: require('../assets/sounds/win.wav'),
  draw: require('../assets/sounds/draw.wav'),
  error: require('../assets/sounds/error.wav'),
};

// ─── Анимированные звёзды ────────────────────────────────────────────────────
const STAR_COUNT = 45;
type StarData = {
  id: number; x: number; y: number; size: number;
  baseOpacity: number; duration: number; delay: number;
};

function generateStars(): StarData[] {
  return Array.from({ length: STAR_COUNT }, (_, i) => ({
    id: i, x: Math.random() * 100, y: Math.random() * 100,
    size: Math.random() * 3 + 1, baseOpacity: Math.random() * 0.6 + 0.2,
    duration: Math.random() * 3000 + 2000, delay: Math.random() * 2000,
  }));
}

function AnimatedStars({ accent }: { accent: string }) {
  const { width, height } = useWindowDimensions();
  const [stars] = useState(generateStars);
  const anims = useRef(stars.map(() => new RNAnimated.Value(0))).current;

  useEffect(() => {
    anims.forEach((anim, i) => {
      anim.setValue(0);
      RNAnimated.sequence([
        RNAnimated.delay(stars[i].delay),
        RNAnimated.loop(
          RNAnimated.sequence([
            RNAnimated.timing(anim, {
              toValue: 1, duration: stars[i].duration,
              easing: Easing.inOut(Easing.sin), useNativeDriver: true,
            }),
            RNAnimated.timing(anim, {
              toValue: 0, duration: stars[i].duration,
              easing: Easing.inOut(Easing.sin), useNativeDriver: true,
            }),
          ]),
        ),
      ]).start();
    });
    return () => anims.forEach(a => a.stopAnimation());
  }, []);

  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      {stars.map((star, i) => {
        const opacity = anims[i].interpolate({
          inputRange: [0, 1], outputRange: [star.baseOpacity * 0.2, star.baseOpacity],
        });
        const scale = anims[i].interpolate({
          inputRange: [0, 1], outputRange: [0.6, 1.2],
        });
        const color = i % 5 === 0 ? accent : '#ffffff';
        return (
          <RNAnimated.View key={star.id} style={{
            position: 'absolute',
            left: (star.x / 100) * width, top: (star.y / 100) * height,
            width: star.size, height: star.size, borderRadius: star.size / 2,
            backgroundColor: color, opacity, transform: [{ scale }],
            shadowColor: color, shadowOpacity: 0.9,
            shadowRadius: star.size * 2, shadowOffset: { width: 0, height: 0 },
          }} />
        );
      })}
    </View>
  );
}

// ─── Звук ────────────────────────────────────────────────────────────────────
function useSound(name: SoundName) {
  const player = useAudioPlayer(SOUND_SOURCES[name]);
  const play = useCallback(() => {
    try { player.replace(SOUND_SOURCES[name]); player.play(); } catch { }
  }, [name, player]);
  return play;
}

// ─── Палитра ─────────────────────────────────────────────────────────────────
function getPalette(timeTheme: TimeTheme) {
  if (timeTheme === 'day') return {
    bg: ['#f8fafc', '#e0f2fe', '#e2e8f0'] as const,
    panel: '#ffffff', card: 'rgba(255,255,255,0.80)',
    cell: 'rgba(255,255,255,0.90)', text: '#0f172a', muted: '#64748b',
    border: 'rgba(100,116,139,0.25)', overlay: 'rgba(15,23,42,0.5)',
    statusBar: 'dark-content' as const,
    // Непрозрачный цвет для StatusBar
    statusBarBg: '#f8fafc',
  };
  if (timeTheme === 'neon') return {
    bg: ['#0b0f1a', '#1a0b2e', '#0b0f1a'] as const,
    panel: '#111827', card: 'rgba(31,41,55,0.75)',
    cell: 'rgba(17,24,39,0.50)', text: '#ffffff', muted: '#a3a3a3',
    border: 'rgba(236,72,153,0.35)', overlay: 'rgba(0,0,0,0.7)',
    statusBar: 'light-content' as const,
    statusBarBg: '#0b0f1a',
  };
  return {
    bg: ['#020617', '#0f172a', '#020617'] as const,
    panel: '#0f172a', card: 'rgba(30,41,59,0.75)',
    cell: 'rgba(15,23,42,0.50)', text: '#ffffff', muted: '#9ca3af',
    border: 'rgba(148,163,184,0.3)', overlay: 'rgba(0,0,0,0.7)',
    statusBar: 'light-content' as const,
    statusBarBg: '#020617',
  };
}

// ─── Игровая логика ──────────────────────────────────────────────────────────
function getEmptyCells(board: Cell[]) {
  return board.map((c, i) => c === '' ? i : null).filter((i): i is number => i !== null);
}
function getAllLines(bs: number, wc: number) {
  const lines: number[][] = [];
  const dirs = [[0, 1], [1, 0], [1, 1], [1, -1]];
  for (let r = 0; r < bs; r++)
    for (let c = 0; c < bs; c++)
      for (const [dr, dc] of dirs) {
        const er = r + (wc - 1) * dr, ec = c + (wc - 1) * dc;
        if (er < 0 || er >= bs || ec < 0 || ec >= bs) continue;
        const line: number[] = [];
        for (let i = 0; i < wc; i++) line.push((r + i * dr) * bs + (c + i * dc));
        lines.push(line);
      }
  return lines;
}
function checkWinner(board: Cell[], bs: number, wc: number): GameResult {
  for (const line of getAllLines(bs, wc)) {
    const first = board[line[0]];
    if (first && line.every(i => board[i] === first)) return { winner: first, line };
  }
  if (!board.includes('')) return { winner: 'tie', line: [] };
  return { winner: null, line: [] };
}
function findWinningMove(board: Cell[], player: Player, bs: number, wc: number) {
  for (const line of getAllLines(bs, wc)) {
    let cnt = 0, empty: number | null = null, blocked = false;
    for (const i of line) {
      if (board[i] === player) cnt++;
      else if (board[i] === '') empty = i;
      else { blocked = true; break; }
    }
    if (!blocked && cnt === wc - 1 && empty !== null) return empty;
  }
  return null;
}
function findForkBlockMove(board: Cell[], player: Player, bs: number, wc: number) {
  for (const idx of getEmptyCells(board)) {
    const next = [...board]; next[idx] = player; let threats = 0;
    for (const line of getAllLines(bs, wc)) {
      let pc = 0, ec = 0;
      for (const i of line) { if (next[i] === player) pc++; else if (next[i] === '') ec++; }
      if (pc === wc - 1 && ec === 1) threats++;
    }
    if (threats >= 2) return idx;
  }
  return null;
}
function getAvailableCorners(board: Cell[], bs: number) {
  const last = bs - 1;
  return [0, last, bs * last, bs * bs - 1].filter(i => board[i] === '');
}
function minimax(board: Cell[], bs: number, wc: number, isMax: boolean, depth: number, alpha: number, beta: number): number {
  const w = checkWinner(board, bs, wc).winner;
  if (w === 'O') return 10 - depth; if (w === 'X') return depth - 10; if (w === 'tie') return 0;
  if (isMax) {
    let best = -Infinity;
    for (const m of getEmptyCells(board)) {
      const n = [...board]; n[m] = 'O';
      best = Math.max(best, minimax(n, bs, wc, false, depth + 1, alpha, beta));
      alpha = Math.max(alpha, best); if (beta <= alpha) break;
    } return best;
  }
  let best = Infinity;
  for (const m of getEmptyCells(board)) {
    const n = [...board]; n[m] = 'X';
    best = Math.min(best, minimax(n, bs, wc, true, depth + 1, alpha, beta));
    beta = Math.min(beta, best); if (beta <= alpha) break;
  } return best;
}
function minimaxBestMove(board: Cell[], bs: number, wc: number) {
  let best = -Infinity, bestMove: number | null = null;
  for (const m of getEmptyCells(board)) {
    const n = [...board]; n[m] = 'O';
    const s = minimax(n, bs, wc, false, 0, -Infinity, Infinity);
    if (s > best) { best = s; bestMove = m; }
  } return bestMove;
}
function findBestMove(board: Cell[], difficulty: Difficulty, bs: number, wc: number) {
  const empty = getEmptyCells(board); if (!empty.length) return null;
  if (difficulty === 'easy') return empty[Math.floor(Math.random() * empty.length)];
  if (difficulty === 'impossible' && bs === 3 && wc === 3) return minimaxBestMove(board, bs, wc);
  const skill = difficulty === 'medium' ? 0.62 : 0.88;
  if (Math.random() > skill) return empty[Math.floor(Math.random() * empty.length)];
  const win = findWinningMove(board, 'O', bs, wc); if (win !== null) return win;
  const block = findWinningMove(board, 'X', bs, wc); if (block !== null) return block;
  if (bs % 2 === 1) { const center = Math.floor((bs * bs) / 2); if (board[center] === '') return center; }
  const fork = findForkBlockMove(board, 'X', bs, wc); if (fork !== null) return fork;
  const corners = getAvailableCorners(board, bs);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  return empty[Math.floor(Math.random() * empty.length)];
}
function difficultyLabel(d: Difficulty) {
  return { easy: 'Новичок', medium: 'Любитель', hard: 'Эксперт', impossible: 'Невозможный' }[d];
}
function nextWinCondition(size: number) { return size >= 5 ? 4 : 3; }

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const { width: sw, height: sh } = useWindowDimensions();
  const [screen, setScreen] = useState<Screen>('menu');
  const [settings, setSettings] = useState<SettingsState>(DEFAULT_SETTINGS);
  const [scores, setScores] = useState<Scores>({ X: 0, O: 0, tie: 0 });
  const [activeBoardSize, setABS] = useState(DEFAULT_SETTINGS.boardSize);
  const [activeWinCondition, setAWC] = useState(DEFAULT_SETTINGS.winCondition);
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(''));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('X');
  const [gameMode, setGameMode] = useState<GameMode>('human');
  const [gameActive, setGameActive] = useState(true);
  const [winningLine, setWinningLine] = useState<number[]>([]);
  const [result, setResult] = useState<GameResult | null>(null);
  const [aiModal, setAiModal] = useState(false);
  const [settingsModal, setSettingsModal] = useState(false);
  const [menuModal, setMenuModal] = useState(false);
  const [confirmModal, setConfirmModal] = useState(false);

  // ── Реклама ──
  const ads = useYandexAds(settings.timeTheme === 'day' ? 'light' : 'dark');

  // ── Звуки ──
  const sClick = useSound('click');
  const sMoveX = useSound('moveX');
  const sMoveO = useSound('moveO');
  const sWin = useSound('win');
  const sDraw = useSound('draw');
  const sError = useSound('error');

  const soundMap = useRef({ click: sClick, moveX: sMoveX, moveO: sMoveO, win: sWin, draw: sDraw, error: sError });
  soundMap.current = { click: sClick, moveX: sMoveX, moveO: sMoveO, win: sWin, draw: sDraw, error: sError };
  const soundEnabled = useRef(settings.soundEnabled);
  soundEnabled.current = settings.soundEnabled;
  const vibrationEnabled = useRef(settings.vibrationEnabled);
  vibrationEnabled.current = settings.vibrationEnabled;

  const playSound = useCallback(async (name: SoundName) => {
    if (vibrationEnabled.current) {
      try {
        if (name === 'error') await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        else if (name === 'win') await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        else await Haptics.selectionAsync();
      } catch { }
    }
    if (soundEnabled.current) soundMap.current[name]();
  }, []);

  const accent = THEME_COLORS[settings.themeColor];
  const palette = useMemo(() => getPalette(settings.timeTheme), [settings.timeTheme]);
  const symbols = SYMBOL_SETS[settings.symbolType];
  const isTablet = Math.min(sw, sh) > 600;
//  const boardContainerSize = Math.min(isTablet ? 500 : sw * 0.88, 500);
  const boardContainerSize = Math.min(isTablet ? 700 : sw * 0.88, 400);




  
  const dynamicFontSize = Math.floor(boardContainerSize / activeBoardSize * 0.55);
  const showStars = settings.timeTheme === 'night';
  const playerXColor = '#0ea5ff';
  const playerOColor = '#ff3df2';
  const currentColor = currentPlayer === 'X' ? playerXColor : playerOColor;

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'mixWithOthers' }).catch(() => { });
  }, []);

  useEffect(() => {
    (async () => {
      const [s, sc] = await Promise.all([
        AsyncStorage.getItem(SETTINGS_KEY),
        AsyncStorage.getItem(SCORES_KEY),
      ]);
      if (s) {
        try {
          const p = JSON.parse(s) as Partial<SettingsState>;
          setSettings(prev => ({
            ...prev, ...p,
            boardSize: p.boardSize || prev.boardSize,
            winCondition: p.winCondition || nextWinCondition(p.boardSize || prev.boardSize),
          }));
        } catch { }
      }
      if (sc) { try { setScores({ X: 0, O: 0, tie: 0, ...JSON.parse(sc) }); } catch { } }
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(SCORES_KEY, JSON.stringify(scores)).catch(() => { });
  }, [scores]);

  const closeAll = useCallback(() => {
    setAiModal(false); setSettingsModal(false); setMenuModal(false);
  }, []);

  const chooseFirst = useCallback((): Player => {
    if (settings.startingPlayer === 'random') return Math.random() < 0.5 ? 'X' : 'O';
    return settings.startingPlayer.toUpperCase() as Player;
  }, [settings.startingPlayer]);

  const startGame = useCallback((mode: GameMode, difficulty?: Difficulty) => {
    playSound('click');
    const d = difficulty || settings.difficulty;
    setSettings(p => ({ ...p, difficulty: d }));
    setGameMode(mode); setABS(settings.boardSize); setAWC(settings.winCondition);
    setBoard(Array(settings.boardSize * settings.boardSize).fill(''));
    setWinningLine([]); setResult(null); setGameActive(true);
    setCurrentPlayer(chooseFirst()); setScreen('game'); closeAll();
  }, [chooseFirst, closeAll, playSound, settings]);

  const handleGameEnd = useCallback((gr: GameResult) => {
    setGameActive(false); setWinningLine(gr.line); setResult(gr);
    if (gr.winner === 'tie') { setScores(p => ({ ...p, tie: p.tie + 1 })); playSound('draw'); }
    else { setScores(p => ({ ...p, [gr.winner as Player]: p[gr.winner as Player] + 1 })); playSound('win'); }
  }, [playSound]);

  const handleCellPress = useCallback((index: number) => {
    if (!gameActive || board[index] !== '' || (gameMode === 'ai' && currentPlayer === 'O')) {
      playSound('error'); return;
    }
    const next = [...board]; next[index] = currentPlayer; setBoard(next);
    playSound(currentPlayer === 'X' ? 'moveX' : 'moveO');
    const checked = checkWinner(next, activeBoardSize, activeWinCondition);
    if (checked.winner) { handleGameEnd(checked); return; }
    setCurrentPlayer(currentPlayer === 'X' ? 'O' : 'X');
  }, [activeBoardSize, activeWinCondition, board, currentPlayer, gameActive, gameMode, handleGameEnd, playSound]);

  const makeAIMove = useCallback(() => {
    if (!gameActive || gameMode !== 'ai' || currentPlayer !== 'O') return;
    const move = findBestMove(board, settings.difficulty, activeBoardSize, activeWinCondition);
    if (move === null) return;
    const next = [...board]; next[move] = 'O'; setBoard(next); playSound('moveO');
    const checked = checkWinner(next, activeBoardSize, activeWinCondition);
    if (checked.winner) { handleGameEnd(checked); return; }
    setCurrentPlayer('X');
  }, [activeBoardSize, activeWinCondition, board, currentPlayer, gameActive, gameMode, handleGameEnd, playSound, settings.difficulty]);

  useEffect(() => {
    if (screen !== 'game' || gameMode !== 'ai' || currentPlayer !== 'O' || !gameActive) return;
    const t = setTimeout(makeAIMove, 450);
    return () => clearTimeout(t);
  }, [currentPlayer, gameActive, gameMode, makeAIMove, screen]);

  const resetRound = useCallback(() => {
    playSound('click'); setMenuModal(false); setResult(null); setWinningLine([]);
    setBoard(Array(activeBoardSize * activeBoardSize).fill(''));
    setGameActive(true);
    setCurrentPlayer(p => p === 'X' ? 'O' : 'X');
  }, [activeBoardSize, playSound]);

  const goMenu = useCallback(() => {
    playSound('click'); closeAll(); setResult(null); setScreen('menu');
  }, [closeAll, playSound]);

  const saveSettings = useCallback(async () => {
    playSound('click');
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    setSettingsModal(false);
    if (screen === 'game') goMenu();
  }, [goMenu, playSound, screen, settings]);

  const confirmReset = useCallback(() => {
    playSound('click'); setScores({ X: 0, O: 0, tie: 0 });
    setConfirmModal(false); setMenuModal(false);
  }, [playSound]);

  const resultTitle = useMemo(() => {
    if (!result?.winner) return '';
    return result.winner === 'tie' ? 'Ничья!' : `${symbols[result.winner]} Победил!`;
  }, [result, symbols]);

  const resultMessage = useMemo(() => {
    if (!result?.winner) return '';
    return result.winner === 'tie'
      ? 'Партия завершилась вничью!'
      : `Игрок ${symbols[result.winner]} выиграл эту партию!`;
  }, [result, symbols]);

  // ─── RENDER ────────────────────────────────────────────────────────────────
  return (
    <SafeAreaProvider>
      {/* ── StatusBar: непрозрачный, без translucent ── */}
      

      

      <LinearGradient colors={palette.bg} style={{ flex: 1 }}>
        {showStars && <AnimatedStars accent={accent} />}

        <SafeAreaView
          edges={['left', 'right', 'top']}
          style={{
            flex: 1,
            paddingHorizontal: isTablet ? 32 : 16,
          }}
        >
          {/* Отступ снизу под баннер */}
          <View style={{ flex: 1, paddingBottom: ads.bannerReservedHeight + 8 }}>

            {/* ══════════ МЕНЮ ══════════ */}
            {screen === 'menu' ? (
              <View className="flex-1 justify-center">
                <View className="mb-12 items-center">
                  <Text className="text-center font-black tracking-widest"
                    style={{
                      color: accent, fontSize: isTablet ? 52 : 42,
                      textShadowColor: accent, textShadowRadius: 20,
                      textShadowOffset: { width: 0, height: 0 },
                    }}>
                    НЕОНОВЫЕ
                  </Text>
                  <Text className="mt-2 text-center font-black tracking-wide"
                    style={{
                      color: accent, fontSize: isTablet ? 40 : 32,
                      textShadowColor: accent, textShadowRadius: 20,
                      textShadowOffset: { width: 0, height: 0 },
                    }}>
                    КРЕСТИКИ-НОЛИКИ
                  </Text>
                </View>

                <View className="gap-4 self-center" style={{ width: isTablet ? 400 : '100%' }}>
                  <AppButton label="Играть с другом" icon={Users} accent={accent} onPress={() => startGame('human')} />
                  <AppButton label="Играть с ИИ" icon={Bot} accent={accent} onPress={() => { playSound('click'); setAiModal(true); }} />
                  <AppButton label="Настройки" icon={Settings} accent={accent} onPress={() => { playSound('click'); setSettingsModal(true); }} />
                </View>

                {/* Кнопка убрать баннер */}
                <View style={{
                  width: isTablet ? 400 : '100%', alignSelf: 'center', marginTop: 14,
                  opacity: ads.bannerDisabled || ads.rewardedReady ? 1 : 0.65,
                }}>
                  <AppButton
                    label={
                      ads.bannerDisabled
                        ? `Баннер скрыт: ${ads.remainingLabel}`
                        : ads.rewardedLoading
                          ? 'Загружаем видео...'
                          : 'Убрать баннер на 5 минут'
                    }
                    icon={Gift}
                    accent="#22c55e"
                    filled={ads.bannerDisabled}
                    onPress={() => {
                      if (!ads.bannerDisabled && ads.rewardedReady) {
                        playSound('click');
                        ads.showRewardedToHideBanner();
                      }
                    }}
                  />
                  <Text style={{
                    textAlign: 'center', color: palette.muted,
                    fontSize: 12, marginTop: 8,
                  }}>
                    Просмотров видео: {ads.rewardedViewsCount}
                  </Text>
                </View>
              </View>
            ) : (
              /* ══════════ ИГРА ══════════ */
              <View className="flex-1 justify-center">

                {/* Верхняя панель */}
                <View className="mb-5 flex-row items-center justify-between">
                  <IconButton icon={Menu} onPress={() => setMenuModal(true)} color={accent} label="Меню" />

                  <View className="items-center">
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={{ fontSize: 16, fontWeight: '700', color: palette.text }}>
                        Ход:{' '}
                      </Text>
                      <View style={{
                        minWidth: 38, height: 38, borderRadius: 12,
                        backgroundColor: currentPlayer === 'X'
                          ? 'rgba(14,165,255,0.15)' : 'rgba(255,61,242,0.15)',
                        borderWidth: 1.5,
                        borderColor: currentPlayer === 'X'
                          ? 'rgba(14,165,255,0.5)' : 'rgba(255,61,242,0.5)',
                        alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8,
                        shadowColor: currentColor, shadowOpacity: 0.6,
                        shadowRadius: 10, shadowOffset: { width: 0, height: 0 },
                      }}>
                        <Text style={{
                          fontSize: 20, fontWeight: '900', color: currentColor,
                          textShadowColor: currentColor, textShadowRadius: 12,
                          textShadowOffset: { width: 0, height: 0 },
                        }}>
                          {symbols[currentPlayer]}
                        </Text>
                      </View>
                    </View>
                    <Text className="mt-1 text-xs" style={{ color: palette.muted }}>
                      {gameMode === 'ai' ? `ИИ (${difficultyLabel(settings.difficulty)})` : 'Два игрока'}
                    </Text>
                  </View>

                  <IconButton icon={RotateCcw} onPress={resetRound} color={accent} label="Перезапустить" />
                </View>

                {/* Поле */}
                <View className="self-center rounded-3xl border p-2"
                  style={{
                    width: boardContainerSize + 16, height: boardContainerSize + 16,
                    borderColor: `${accent}40`, backgroundColor: palette.card,
                    shadowColor: accent, shadowOpacity: 0.4, shadowRadius: 30,
                    shadowOffset: { width: 0, height: 0 },
                  }}>
                  <View className="flex-row flex-wrap"
                    style={{ width: boardContainerSize, height: boardContainerSize }}>
                    {board.map((cell, index) => {
                      const isWin = winningLine.includes(index);
                      const sc = cell === 'X' ? playerXColor : cell === 'O' ? playerOColor : palette.text;
                      return (
                        <View key={index} style={{
                          width: `${100 / activeBoardSize}%`,
                          height: `${100 / activeBoardSize}%`, padding: 4,
                        }}>
                          <Pressable
                            disabled={Boolean(cell) || !gameActive || (gameMode === 'ai' && currentPlayer === 'O')}
                            onPress={() => handleCellPress(index)}
                            className="flex-1 items-center justify-center rounded-xl border"
                            style={{
                              borderColor: isWin ? accent : cell ? `${sc}50` : palette.border,
                              backgroundColor: isWin ? `${accent}15` : palette.cell,
                              shadowColor: isWin ? accent : cell ? sc : 'transparent',
                              shadowOpacity: isWin ? 0.8 : cell ? 0.5 : 0,
                              shadowRadius: isWin ? 18 : 12,
                              shadowOffset: { width: 0, height: 0 },
                            }}>
                            <Text className="font-black"
                              style={{
                                color: sc, fontSize: dynamicFontSize,
                                textShadowColor: sc, textShadowRadius: cell ? 16 : 0,
                                textShadowOffset: { width: 0, height: 0 },
                              }}>
                              {cell ? symbols[cell] : ''}
                            </Text>
                          </Pressable>
                        </View>
                      );
                    })}
                  </View>
                </View>

                {/* Счёт */}
                <View className="mt-6 flex-row gap-3">
                  <View style={{ flex: 1, opacity: currentPlayer === 'X' && gameActive ? 1 : 0.5 }}>
                    <ScoreCard label={`Игрок ${symbols.X}`} value={scores.X}
                      color={playerXColor} palette={palette}
                      active={currentPlayer === 'X' && gameActive} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <ScoreCard label="Ничьи" value={scores.tie}
                      color={palette.muted} palette={palette} active={false} />
                  </View>
                  <View style={{ flex: 1, opacity: currentPlayer === 'O' && gameActive ? 1 : 0.5 }}>
                    <ScoreCard label={`Игрок ${symbols.O}`} value={scores.O}
                      color={playerOColor} palette={palette}
                      active={currentPlayer === 'O' && gameActive} />
                  </View>
                </View>
              </View>
            )}

          </View>
        </SafeAreaView>

        {/* ══════════ БАННЕР СНИЗУ ══════════ */}
        <BottomStickyBanner
          palette={palette}
          bannerSize={ads.bannerSize}
          bannerRequest={ads.bannerRequest}
          bannerDisabled={ads.bannerDisabled}
          remainingLabel={ads.remainingLabel}
          rewardedViewsCount={ads.rewardedViewsCount}
          reservedHeight={ads.bannerReservedHeight}
        />

        {/* ══════════ МОДАЛКИ ══════════ */}
        <AiModal
          visible={aiModal} accent={accent} palette={palette}
          onClose={() => setAiModal(false)}
          onSelect={l => startGame('ai', l)}
        />
        <SettingsModal
          visible={settingsModal} accent={accent} palette={palette}
          settings={settings} setSettings={setSettings}
          onClose={() => setSettingsModal(false)} onSave={saveSettings}
        />
        <MenuModal
          visible={menuModal} accent={accent} palette={palette}
          onClose={() => setMenuModal(false)}
          onContinue={() => setMenuModal(false)}
          onReset={resetRound} onNewGame={goMenu}
          onSettings={() => { setMenuModal(false); setSettingsModal(true); }}
          onResetScores={() => { playSound('click'); setConfirmModal(true); }}
          onDisableBannerAd={() => {
            playSound('click');
            ads.showRewardedToHideBanner();
          }}
          bannerDisabled={ads.bannerDisabled}
          bannerRemainingLabel={ads.remainingLabel}
          rewardedReady={ads.rewardedReady}
          rewardedLoading={ads.rewardedLoading}
          rewardedViewsCount={ads.rewardedViewsCount}
        />
        <ResultModal
          visible={Boolean(result?.winner)} accent={accent} palette={palette}
          title={resultTitle} message={resultMessage}
          isTie={result?.winner === 'tie'}
          onPlayAgain={resetRound} onNewGame={goMenu}
        />
        <ConfirmModal
          visible={confirmModal} accent={accent} palette={palette}
          onClose={() => setConfirmModal(false)} onConfirm={confirmReset}
        />
      </LinearGradient>
    </SafeAreaProvider>
  );
}

// ─── UI-компоненты ───────────────────────────────────────────────────────────

function AppButton({ label, icon: Icon, onPress, accent, filled = false, danger = false }: {
  label: string; icon?: IconComponent; onPress: () => void; accent: string; filled?: boolean; danger?: boolean;
}) {
  const color = danger ? '#f87171' : accent;
  return (
    <TouchableOpacity activeOpacity={0.82} onPress={onPress}
      className="w-full flex-row items-center justify-center rounded-2xl border px-5 py-4"
      style={{
        borderColor: color, backgroundColor: filled ? color : `${color}18`,
        shadowColor: color, shadowOpacity: 0.45, shadowRadius: 16,
        shadowOffset: { width: 0, height: 0 },
      }}>
      {Icon && <Icon size={22} color={filled ? '#fff' : color} strokeWidth={2.4} />}
      <Text className="ml-3 text-lg font-bold" style={{ color: filled ? '#fff' : color }}>{label}</Text>
    </TouchableOpacity>
  );
}

function IconButton({ icon: Icon, onPress, color, label }: {
  icon: IconComponent; onPress: () => void; color: string; label: string;
}) {
  return (
    <TouchableOpacity accessibilityLabel={label} activeOpacity={0.82} onPress={onPress}
      className="h-12 w-12 items-center justify-center rounded-2xl border"
      style={{ borderColor: `${color}90`, backgroundColor: `${color}16` }}>
      <Icon size={24} color={color} strokeWidth={2.4} />
    </TouchableOpacity>
  );
}

function OptionPill({ label, active, onPress, accent, icon: Icon }: {
  label: string; active: boolean; onPress: () => void; accent: string; icon?: IconComponent;
}) {
  return (
    <TouchableOpacity activeOpacity={0.82} onPress={onPress}
      className="mb-2 mr-2 flex-row items-center rounded-full border px-4 py-2"
      style={{
        borderColor: active ? accent : 'rgba(148,163,184,0.32)',
        backgroundColor: active ? `${accent}22` : 'rgba(255,255,255,0.05)',
      }}>
      {Icon && <Icon size={16} color={active ? accent : '#94a3b8'} />}
      <Text className={Icon ? 'ml-2 font-bold' : 'font-bold'}
        style={{ color: active ? accent : '#cbd5e1' }}>{label}</Text>
    </TouchableOpacity>
  );
}

function ScoreCard({ label, value, color, palette, active }: {
  label: string; value: number; color: string;
  palette: ReturnType<typeof getPalette>; active: boolean;
}) {
  return (
    <View className="items-center rounded-2xl border px-2 py-3"
      style={{
        backgroundColor: active ? `${color}12` : palette.card,
        borderColor: active ? color : palette.border,
        shadowColor: active ? color : 'transparent',
        shadowOpacity: active ? 0.4 : 0, shadowRadius: 10,
        shadowOffset: { width: 0, height: 0 },
      }}>
      <Text className="text-xs" style={{ color: palette.muted }} numberOfLines={1}>{label}</Text>
      <Text className="mt-1 text-2xl font-black"
        style={{
          color, textShadowColor: color,
          textShadowRadius: color === palette.muted ? 0 : 12,
          textShadowOffset: { width: 0, height: 0 },
        }}>{value}</Text>
    </View>
  );
}

function SettingsGroup({ title, icon: Icon, accent, palette, children }: {
  title: string; icon: IconComponent; accent: string;
  palette: ReturnType<typeof getPalette>; children: React.ReactNode;
}) {
  return (
    <View style={{ marginBottom: 20 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
        <Icon size={18} color={accent} />
        <Text style={{ marginLeft: 8, fontSize: 15, fontWeight: '900', color: palette.text }}>{title}</Text>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{children}</View>
    </View>
  );
}

// ─── Модалка: ИИ ─────────────────────────────────────────────────────────────
function AiModal({ visible, accent, palette, onClose, onSelect }: {
  visible: boolean; accent: string; palette: ReturnType<typeof getPalette>;
  onClose: () => void; onSelect: (d: Difficulty) => void;
}) {
  const { width } = useWindowDimensions();
  const items = [
    { level: 'easy' as Difficulty, title: 'Новичок', subtitle: 'Делает случайные ходы', color: '#4ade80' },
    { level: 'medium' as Difficulty, title: 'Любитель', subtitle: 'Иногда ошибается', color: '#fbbf24' },
    { level: 'hard' as Difficulty, title: 'Эксперт', subtitle: 'Часто выбирает сильный ход', color: '#f87171' },
    { level: 'impossible' as Difficulty, title: 'Невозможный', subtitle: 'На 3×3 играет без проигрыша', color: '#a855f7' },
  ];
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <Pressable style={[s.overlay, { backgroundColor: palette.overlay }]} onPress={onClose}>
        <Pressable style={[s.dialog, {
          backgroundColor: palette.panel, borderColor: palette.border,
          maxWidth: Math.min(width - 32, 440),
        }]} onPress={e => e.stopPropagation()}>
          <View style={[s.dialogHeader, { borderBottomColor: palette.border }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Bot size={22} color={accent} />
              <Text style={[s.dialogTitle, { color: accent }]}>Выберите ИИ</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={s.closeBtn}>
              <X size={24} color={palette.muted} />
            </TouchableOpacity>
          </View>
          <View style={{ gap: 12 }}>
            {items.map(item => (
              <TouchableOpacity key={item.level} activeOpacity={0.82}
                onPress={() => onSelect(item.level)}
                style={[s.aiItem, { borderColor: palette.border, backgroundColor: palette.card }]}>
                <View style={[s.aiIcon, { backgroundColor: `${item.color}22` }]}>
                  <Brain size={22} color={item.color} />
                </View>
                <View style={{ marginLeft: 12, flex: 1 }}>
                  <Text style={[s.aiTitle, { color: palette.text }]}>{item.title}</Text>
                  <Text style={[s.aiSubtitle, { color: palette.muted }]}>{item.subtitle}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Модалка: Настройки ──────────────────────────────────────────────────────
function SettingsModal({ visible, accent, palette, settings, setSettings, onClose, onSave }: {
  visible: boolean; accent: string; palette: ReturnType<typeof getPalette>;
  settings: SettingsState; setSettings: React.Dispatch<React.SetStateAction<SettingsState>>;
  onClose: () => void; onSave: () => void;
}) {
  const { height } = useWindowDimensions();
  const update = (patch: Partial<SettingsState>) => setSettings(p => ({ ...p, ...patch }));

  return (
    <Modal visible={visible} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: palette.overlay }}>
        <Pressable style={StyleSheet.absoluteFillObject} onPress={onClose} />
        <View style={{
          width: '100%', maxHeight: height * 0.90, backgroundColor: palette.panel,
          borderTopLeftRadius: 28, borderTopRightRadius: 28,
          borderWidth: 1, borderBottomWidth: 0, borderColor: palette.border,
        }}>
          <View style={{ alignItems: 'center', paddingTop: 12, paddingBottom: 4 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: palette.border }} />
          </View>
          <View style={[s.dialogHeader, {
            borderBottomColor: palette.border, paddingHorizontal: 24, paddingVertical: 16,
          }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Settings size={22} color={accent} />
              <Text style={[s.dialogTitle, { color: accent }]}>Настройки</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={s.closeBtn}>
              <X size={24} color={palette.muted} />
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} bounces
            contentContainerStyle={{ paddingHorizontal: 24, paddingTop: 16, paddingBottom: 48 }}>

            <SettingsGroup title="Цвет неона" icon={Palette} accent={accent} palette={palette}>
              {(Object.keys(THEME_COLORS) as ThemeColor[]).map(k => (
                <TouchableOpacity key={k} activeOpacity={0.82} onPress={() => update({ themeColor: k })}
                  style={{
                    width: 40, height: 40, borderRadius: 20, borderWidth: 2,
                    marginRight: 12, marginBottom: 8, backgroundColor: THEME_COLORS[k],
                    borderColor: settings.themeColor === k ? '#fff' : 'rgba(255,255,255,0.3)',
                    transform: [{ scale: settings.themeColor === k ? 1.15 : 1 }],
                  }} />
              ))}
            </SettingsGroup>

            <SettingsGroup title="Тема оформления" icon={Sparkles} accent={accent} palette={palette}>
              <OptionPill label="День" icon={Sun} active={settings.timeTheme === 'day'} accent={accent} onPress={() => update({ timeTheme: 'day' })} />
              <OptionPill label="Ночь" icon={Moon} active={settings.timeTheme === 'night'} accent={accent} onPress={() => update({ timeTheme: 'night' })} />
              <OptionPill label="Неон" icon={Sparkles} active={settings.timeTheme === 'neon'} accent={accent} onPress={() => update({ timeTheme: 'neon' })} />
            </SettingsGroup>

            <SettingsGroup title="Первый ход" icon={Play} accent={accent} palette={palette}>
              <OptionPill label="X" active={settings.startingPlayer === 'x'} accent={accent} onPress={() => update({ startingPlayer: 'x' })} />
              <OptionPill label="O" active={settings.startingPlayer === 'o'} accent={accent} onPress={() => update({ startingPlayer: 'o' })} />
              <OptionPill label="Случайно" active={settings.startingPlayer === 'random'} accent={accent} onPress={() => update({ startingPlayer: 'random' })} />
            </SettingsGroup>

            <SettingsGroup title="Символы" icon={Circle} accent={accent} palette={palette}>
              <OptionPill label="X / O" active={settings.symbolType === 'classic'} accent={accent} onPress={() => update({ symbolType: 'classic' })} />
              <OptionPill label="△ / ○" icon={Triangle} active={settings.symbolType === 'shapes'} accent={accent} onPress={() => update({ symbolType: 'shapes' })} />
              <OptionPill label="★ / ◇" icon={Star} active={settings.symbolType === 'stars'} accent={accent} onPress={() => update({ symbolType: 'stars' })} />
            </SettingsGroup>

            <SettingsGroup title="Размер поля" icon={Grid3X3} accent={accent} palette={palette}>
              {[3, 4, 5].map(sz => (
                <OptionPill key={sz} label={`${sz}×${sz}`} active={settings.boardSize === sz} accent={accent}
                  onPress={() => update({ boardSize: sz, winCondition: nextWinCondition(sz) })} />
              ))}
            </SettingsGroup>

            <SettingsGroup title="Звук" icon={Volume2} accent={accent} palette={palette}>
              <OptionPill label="Вкл" icon={Volume2} active={settings.soundEnabled} accent={accent} onPress={() => update({ soundEnabled: true })} />
              <OptionPill label="Выкл" icon={VolumeX} active={!settings.soundEnabled} accent={accent} onPress={() => update({ soundEnabled: false })} />
            </SettingsGroup>

            <SettingsGroup title="Вибрация" icon={Smartphone} accent={accent} palette={palette}>
              <OptionPill label="Вкл" icon={Vibrate} active={settings.vibrationEnabled} accent={accent} onPress={() => update({ vibrationEnabled: true })} />
              <OptionPill label="Выкл" icon={Smartphone} active={!settings.vibrationEnabled} accent={accent} onPress={() => update({ vibrationEnabled: false })} />
            </SettingsGroup>

            <AppButton label="Сохранить" icon={Save} accent={accent} filled onPress={onSave} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ─── Модалка: Боковое меню ───────────────────────────────────────────────────
function MenuModal({ visible, accent, palette, onClose, onContinue, onReset, onNewGame, onSettings, onResetScores, onDisableBannerAd, bannerDisabled, bannerRemainingLabel, rewardedReady, rewardedLoading, rewardedViewsCount }: {
  visible: boolean; accent: string; palette: ReturnType<typeof getPalette>;
  onClose: () => void; onContinue: () => void; onReset: () => void;
  onNewGame: () => void; onSettings: () => void; onResetScores: () => void;
  onDisableBannerAd: () => void;
  bannerDisabled: boolean; bannerRemainingLabel: string;
  rewardedReady: boolean; rewardedLoading: boolean; rewardedViewsCount: number;
}) {
  const menuItem = (label: string, Icon: IconComponent, onPress: () => void, color = accent, danger = false, badge?: string) => (
    <TouchableOpacity key={label} activeOpacity={0.82} onPress={onPress}
      style={[s.menuItem, {
        borderColor: danger ? 'rgba(248,113,113,0.4)' : palette.border,
        backgroundColor: danger ? 'rgba(239,68,68,0.1)' : palette.card,
      }]}>
      <Icon size={20} color={color} />
      <Text style={[s.menuLabel, { color: danger ? '#fca5a5' : palette.text, flex: 1 }]}>{label}</Text>
      {badge && (
        <View style={{
          backgroundColor: `${color}22`, borderRadius: 8,
          paddingHorizontal: 8, paddingVertical: 2,
        }}>
          <Text style={{ fontSize: 10, fontWeight: '700', color }}>{badge}</Text>
        </View>
      )}
    </TouchableOpacity>
  );

  return (
    <Modal visible={visible} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={{ flex: 1, flexDirection: 'row', backgroundColor: palette.overlay }}>
        <View style={{
          height: '100%', width: '78%', maxWidth: 300,
          backgroundColor: palette.panel, borderRightWidth: 1,
          borderRightColor: palette.border, paddingTop: 56,
          paddingHorizontal: 16, paddingBottom: 32,
        }}>
          <View style={{
            flexDirection: 'row', alignItems: 'center',
            justifyContent: 'space-between', marginBottom: 20,
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Menu size={22} color={accent} />
              <Text style={{
                marginLeft: 8, fontSize: 22, fontWeight: '900', color: accent,
                textShadowColor: accent, textShadowRadius: 8,
                textShadowOffset: { width: 0, height: 0 },
              }}>Меню</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={s.closeBtn}>
              <X size={22} color={palette.muted} />
            </TouchableOpacity>
          </View>

          {menuItem('Продолжить', Play, onContinue, '#4ade80')}
          {menuItem('Начать заново', RotateCcw, onReset, '#fbbf24')}
          {menuItem('Новая игра', Plus, onNewGame, '#60a5fa')}
          {menuItem('Настройки', Settings, onSettings, '#a78bfa')}
          {menuItem('Главное меню', Home, onNewGame, '#f472b6')}

          {menuItem(
            bannerDisabled
              ? `Баннер скрыт: ${bannerRemainingLabel}`
              : rewardedLoading
                ? 'Загружаем видео...'
                : 'Убрать баннер на 5 мин',
            Gift,
            () => {
              if (!bannerDisabled && rewardedReady) onDisableBannerAd();
            },
            '#22c55e',
            false,
            bannerDisabled ? bannerRemainingLabel : rewardedReady ? 'AD' : '...',
          )}
          <Text style={{ color: palette.muted, fontSize: 11, marginBottom: 12, marginLeft: 6 }}>
            Просмотров видео: {rewardedViewsCount}
          </Text>

          <View style={{ flex: 1, justifyContent: 'flex-end' }}>
            {menuItem('Сбросить счёт', Trash2, onResetScores, '#f87171', true)}
          </View>
        </View>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
      </View>
    </Modal>
  );
}

// ─── Модалка: Результат ──────────────────────────────────────────────────────
function ResultModal({ visible, accent, palette, title, message, isTie, onPlayAgain, onNewGame }: {
  visible: boolean; accent: string; palette: ReturnType<typeof getPalette>;
  title: string; message: string; isTie: boolean;
  onPlayAgain: () => void; onNewGame: () => void;
}) {
  const { width } = useWindowDimensions();
  const color = isTie ? palette.muted : accent;
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent>
      <View style={[s.overlay, { backgroundColor: palette.overlay }]}>
        <View style={[s.dialog, {
          backgroundColor: palette.panel, borderColor: palette.border,
          maxWidth: Math.min(width - 32, 400), padding: 32,
        }]}>
          <View style={{
            alignItems: 'center', marginBottom: 16, width: 64, height: 64,
            borderRadius: 32, backgroundColor: `${color}22`, alignSelf: 'center',
            justifyContent: 'center',
          }}>
            {isTie ? <Gem size={32} color={color} /> : <Trophy size={34} color={color} />}
          </View>
          <Text style={{
            textAlign: 'center', fontSize: 36, fontWeight: '900', color,
            textShadowColor: isTie ? 'transparent' : color,
            textShadowRadius: isTie ? 0 : 14,
            textShadowOffset: { width: 0, height: 0 },
          }}>{title}</Text>
          <Text style={{
            textAlign: 'center', fontSize: 15, color: palette.text,
            marginTop: 10, marginBottom: 28,
          }}>{message}</Text>
          <View style={{ gap: 12 }}>
            <AppButton label="Играть снова" icon={RotateCcw} accent={accent} filled onPress={onPlayAgain} />
            <AppButton label="Новая игра" icon={Plus} accent="#a855f7" onPress={onNewGame} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ─── Модалка: Подтверждение сброса ───────────────────────────────────────────
function ConfirmModal({ visible, accent, palette, onClose, onConfirm }: {
  visible: boolean; accent: string; palette: ReturnType<typeof getPalette>;
  onClose: () => void; onConfirm: () => void;
}) {
  const { width } = useWindowDimensions();
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <Pressable style={[s.overlay, { backgroundColor: palette.overlay }]} onPress={onClose}>
        <Pressable style={[s.dialog, {
          backgroundColor: palette.panel, borderColor: palette.border,
          maxWidth: Math.min(width - 32, 380), padding: 28,
        }]} onPress={e => e.stopPropagation()}>
          <View style={{
            width: 56, height: 56, borderRadius: 28,
            backgroundColor: 'rgba(248,113,113,0.15)', alignSelf: 'center',
            alignItems: 'center', justifyContent: 'center', marginBottom: 16,
          }}>
            <Trash2 size={26} color="#f87171" />
          </View>
          <Text style={{
            textAlign: 'center', fontSize: 22, fontWeight: '900',
            color: palette.text, marginBottom: 8,
          }}>Сбросить счёт?</Text>
          <Text style={{
            textAlign: 'center', fontSize: 14, color: palette.muted, marginBottom: 24,
          }}>Все победы и ничьи будут безвозвратно обнулены.</Text>
          <View style={{ gap: 12 }}>
            <AppButton label="Сбросить" icon={Trash2} accent="#f87171" filled danger onPress={onConfirm} />
            <AppButton label="Отмена" accent={accent} onPress={onClose} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Стили ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  overlay: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
  },
  dialog: {
    width: '100%', borderRadius: 24, borderWidth: 1, padding: 20,
  },
  dialogHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderBottomWidth: 1, paddingBottom: 12, marginBottom: 16,
  },
  dialogTitle: {
    marginLeft: 8, fontSize: 22, fontWeight: '900',
  },
  closeBtn: {
    width: 36, height: 36, alignItems: 'center', justifyContent: 'center', borderRadius: 18,
  },
  aiItem: {
    flexDirection: 'row', alignItems: 'center', borderRadius: 16,
    borderWidth: 1, padding: 14,
  },
  aiIcon: {
    width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center',
  },
  aiTitle: {
    fontSize: 17, fontWeight: '900',
  },
  aiSubtitle: {
    fontSize: 13, marginTop: 2,
  },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', borderRadius: 16,
    borderWidth: 1, paddingHorizontal: 14, paddingVertical: 14, marginBottom: 8,
  },
  menuLabel: {
    marginLeft: 12, fontSize: 15, fontWeight: '700',
  },
});