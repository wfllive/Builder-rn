import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Alert, Dimensions, StyleSheet, Text, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  BannerAdSize,
  BannerView,
  MobileAds,
  RewardedAdLoader,
} from 'yandex-mobile-ads';

const BANNER_ID = 'demo-banner-yandex';
const REWARDED_ID = 'demo-rewarded-yandex';

const ADS_DISABLED_UNTIL_KEY = 'yandexAdsDisabledUntil';
const REWARDED_VIEWS_KEY = 'yandexRewardedViewsCount';

const FIVE_MINUTES_MS = 5 * 60 * 1000;

type MiniPalette = {
  panel: string;
  card: string;
  text: string;
  muted: string;
  border: string;
};

function formatTime(totalSeconds: number) {
  const safe = Math.max(0, totalSeconds);
  const mm = String(Math.floor(safe / 60)).padStart(2, '0');
  const ss = String(safe % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

export function useYandexAds(_theme: 'light' | 'dark') {
  const rewardedLoaderRef = useRef<any>(null);
  const rewardedAdRef = useRef<any>(null);

  const [sdkReady, setSdkReady] = useState(false);
  const [bannerSize, setBannerSize] = useState<any>(null);
  const [rewardedReady, setRewardedReady] = useState(false);
  const [rewardedLoading, setRewardedLoading] = useState(false);
  const [adsDisabledUntil, setAdsDisabledUntil] = useState(0);
  const [rewardedViewsCount, setRewardedViewsCount] = useState(0);
  const [tick, setTick] = useState(Date.now());

  // Оставляем для совместимости с App.tsx
  const bannerRequest = undefined;

  const bannerReservedHeight = (bannerSize?.height ?? 50) + 10;

  const remainingSeconds = Math.max(
    0,
    Math.ceil((adsDisabledUntil - tick) / 1000),
  );
  const bannerDisabled = remainingSeconds > 0;
  const remainingLabel = formatTime(remainingSeconds);

  useEffect(() => {
    const id = setInterval(() => setTick(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const preloadRewarded = useCallback(async () => {
    if (!rewardedLoaderRef.current || rewardedLoading || rewardedAdRef.current) return;

    setRewardedLoading(true);
    try {
      // ВАЖНО: без new AdRequestConfiguration(...)
      const ad = await rewardedLoaderRef.current.loadAd({
        adUnitId: REWARDED_ID,
      });

      rewardedAdRef.current = ad;
      setRewardedReady(true);
      console.log('[Yandex Rewarded] loaded');
    } catch (error) {
      console.log('[Yandex Rewarded] load error:', error);
      setRewardedReady(false);
    } finally {
      setRewardedLoading(false);
    }
  }, [rewardedLoading]);

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const [savedUntil, savedViews] = await Promise.all([
          AsyncStorage.getItem(ADS_DISABLED_UNTIL_KEY),
          AsyncStorage.getItem(REWARDED_VIEWS_KEY),
        ]);

        if (!mounted) return;

        setAdsDisabledUntil(Number(savedUntil || '0'));
        setRewardedViewsCount(Number(savedViews || '0'));

        await MobileAds.initialize();
        if (!mounted) return;

        setSdkReady(true);

        const width = Dimensions.get('window').width;
        const size = await BannerAdSize.stickySize(width);
        if (mounted) setBannerSize(size);

        const loader = await RewardedAdLoader.create().catch((e: any) => {
          console.log('[Yandex Rewarded] create loader error:', e);
          return null;
        });

        if (!mounted || !loader) return;
        rewardedLoaderRef.current = loader;

        preloadRewarded();
      } catch (error) {
        console.log('[YandexAds] init error:', error);
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (sdkReady && rewardedLoaderRef.current && !rewardedAdRef.current && !rewardedLoading) {
      preloadRewarded();
    }
  }, [sdkReady, rewardedLoading, preloadRewarded]);

  const activateAdFree = useCallback(async () => {
    const now = Date.now();
    const base = adsDisabledUntil > now ? adsDisabledUntil : now;
    const nextUntil = base + FIVE_MINUTES_MS;
    const nextViews = rewardedViewsCount + 1;

    setAdsDisabledUntil(nextUntil);
    setRewardedViewsCount(nextViews);

    await AsyncStorage.multiSet([
      [ADS_DISABLED_UNTIL_KEY, String(nextUntil)],
      [REWARDED_VIEWS_KEY, String(nextViews)],
    ]);
  }, [adsDisabledUntil, rewardedViewsCount]);

  const showRewardedToHideBanner = useCallback(() => {
    if (bannerDisabled) return;

    const ad = rewardedAdRef.current;

    if (!ad) {
      Alert.alert('Реклама', 'Видео ещё загружается, попробуйте чуть позже.');
      preloadRewarded();
      return;
    }

    ad.onAdShown = () => {
      console.log('[Yandex Rewarded] shown');
    };

    ad.onAdFailedToShow = (error: any) => {
      console.log('[Yandex Rewarded] failed to show:', error);
      rewardedAdRef.current = null;
      setRewardedReady(false);
      preloadRewarded();
    };

    ad.onAdClicked = () => {
      console.log('[Yandex Rewarded] clicked');
    };

    ad.onAdDismissed = () => {
      console.log('[Yandex Rewarded] dismissed');
      rewardedAdRef.current = null;
      setRewardedReady(false);
      setTimeout(() => preloadRewarded(), 800);
    };

    ad.onAdImpression = (impressionData: any) => {
      console.log('[Yandex Rewarded] impression:', impressionData);
    };

    ad.onRewarded = async (reward: any) => {
      console.log('[Yandex Rewarded] rewarded:', reward);
      await activateAdFree();
    };

    ad.show();
  }, [activateAdFree, bannerDisabled, preloadRewarded]);

  return {
    sdkReady,
    bannerSize,
    bannerRequest,
    bannerReservedHeight,
    bannerDisabled,
    remainingSeconds,
    remainingLabel,
    rewardedReady,
    rewardedLoading,
    rewardedViewsCount,
    showRewardedToHideBanner,
  };
}

export function BottomStickyBanner({
  palette,
  bannerSize,
  bannerRequest,
  bannerDisabled,
  remainingLabel,
  rewardedViewsCount,
  reservedHeight,
}: {
  palette: MiniPalette;
  bannerSize: any;
  bannerRequest?: any;
  bannerDisabled: boolean;
  remainingLabel: string;
  rewardedViewsCount: number;
  reservedHeight: number;
}) {
  const [failed, setFailed] = useState(false);

  return (
    <View style={[styles.absoluteWrap, { height: reservedHeight }]}>
      <SafeAreaView
        edges={['bottom']}
        style={[
          styles.safeWrap,
          {
            backgroundColor: palette.panel,
            borderTopColor: palette.border,
          },
        ]}
      >
        <View
          style={[
            styles.bannerArea,
            {
              minHeight: bannerSize?.height ?? 50,
              backgroundColor: palette.card,
              borderColor: palette.border,
            },
          ]}
        >
          {bannerDisabled ? (
            <View style={styles.placeholderInner}>
              <Text style={[styles.placeholderTitle, { color: palette.text }]}>
                Баннер скрыт на {remainingLabel}
              </Text>
              <Text style={[styles.placeholderSub, { color: palette.muted }]}>
                Просмотров видео: {rewardedViewsCount}
              </Text>
            </View>
          ) : failed || !bannerSize ? (
            <View style={styles.placeholderInner}>
              <Text style={[styles.placeholderTitle, { color: palette.text }]}>
                Реклама загружается
              </Text>
              <Text style={[styles.placeholderSub, { color: palette.muted }]}>
                Место зарезервировано, интерфейс не прыгает
              </Text>
            </View>
          ) : (
            <BannerView
              size={bannerSize}
              adUnitId={BANNER_ID}
              adRequest={bannerRequest}
              onAdLoaded={() => {
                console.log('[Yandex Banner] loaded');
                setFailed(false);
              }}
              onAdFailedToLoad={(event: any) => {
                console.log('[Yandex Banner] failed:', event?.nativeEvent);
                setFailed(true);
              }}
              onAdClicked={() => console.log('[Yandex Banner] clicked')}
              onLeftApplication={() => console.log('[Yandex Banner] left app')}
              onWillPresentScreen={() => console.log('[Yandex Banner] will present')}
              onDidDismissScreen={() => console.log('[Yandex Banner] did dismiss')}
              onReturnToApplication={() => console.log('[Yandex Banner] return app')}
              onAdImpression={(event: any) =>
                console.log('[Yandex Banner] impression:', event?.nativeEvent?.impressionData)
              }
              onAdClose={() => console.log('[Yandex Banner] close')}
            />
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  absoluteWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  safeWrap: {
    borderTopWidth: 1,
    paddingTop: 6,
    paddingHorizontal: 8,
  },
  bannerArea: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    borderWidth: 1,
    overflow: 'hidden',
  },
  placeholderInner: {
    minHeight: 50,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  placeholderTitle: {
    fontSize: 13,
    fontWeight: '800',
  },
  placeholderSub: {
    fontSize: 11,
    marginTop: 2,
  },
});