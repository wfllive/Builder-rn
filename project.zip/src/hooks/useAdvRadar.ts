import { useCallback, useEffect, useState } from 'react';

// Simplified NowCast using same API as web? We will stub times.
// Real WMS: https://api.meteolabs.ru  ? need token
// For mobile demo we provide empty / mocked.
export function useAdvRadar(enabled: boolean) {
  const [times, setTimes] = useState<string[]>([]);
  const [timeIndex, setTimeIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [clickInfo, setClickInfo] = useState<any>(null);

  // mock load
  useEffect(() => {
    if (!enabled) { setTimes([]); return; }
    // generate last 12 frames 10min step
    const now = Date.now();
    const arr = Array.from({length:12}, (_,i)=>{
      const t = new Date(now - (11-i)*10*60*1000);
      return t.toISOString();
    });
    setTimes(arr);
    setTimeIndex(arr.length-1);
  }, [enabled]);

  useEffect(() => {
    if (!isPlaying || times.length <2) return;
    const iv = setInterval(()=> {
      setTimeIndex(i => (i+1)%times.length);
    }, 1000);
    return ()=> clearInterval(iv);
  }, [isPlaying, times.length]);

  return {
    times,
    timeIndex,
    timeValue: times[timeIndex] || '',
    isPlaying,
    prev: ()=> setTimeIndex(i => i>0 ? i-1 : times.length-1),
    next: ()=> setTimeIndex(i => (i+1)%times.length),
    togglePlay: ()=> setIsPlaying(p=>!p),
    seek: (idx:number)=> { setIsPlaying(false); setTimeIndex(idx); },
    clickInfo,
    clearClickInfo: ()=> setClickInfo(null),
    loading: false,
  };
}
