import { useCallback, useEffect, useState } from 'react';

// Placeholder: mete oalerts source not defined in repo clearly.
// We will use a dummy empty list, structure compatible.
export type AlertRegion = {
  id: string;
  name: string;
  lat: number;
  lon: number;
  level: 'yellow'|'orange'|'red';
};

export function useMeteoAlerts(enabled: boolean) {
  const [regions, setRegions] = useState<AlertRegion[]>([]);
  const [selected, setSelected] = useState<AlertRegion | null>(null);
  const [regionAlerts, setRegionAlerts] = useState<any[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);

  useEffect(() => {
    if (!enabled) { setRegions([]); return; }
    // TODO: replace with real API
    // For now empty
    setRegions([]);
  }, [enabled]);

  const selectRegion = useCallback(async (r: AlertRegion) => {
    setSelected(r);
    setDetailLoading(true);
    // simulate fetch
    setTimeout(()=> {
      setRegionAlerts([
        { title: 'Гроза', description: 'Ожидается гроза', level: r.level }
      ]);
      setDetailLoading(false);
    }, 400);
  }, []);

  const closeDetail = useCallback(()=> setSelected(null), []);

  return {
    allRegions: regions,
    selected,
    regionAlerts,
    detailLoading,
    selectRegion,
    closeDetail,
  };
}
