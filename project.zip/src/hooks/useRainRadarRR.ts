// rainradar.ru – нативный порт rainEngine
// Без WebView, с обработкой через Skia / JS
import { useCallback, useEffect, useState } from 'react';

export const RAINRADAR_URL = 'https://rainradar.ru';

export type RRRFrame = {
  ts: number;
  zooms: Record<number, [number, number][]>;
};

export function useRainRadarRR(enabled: boolean) {
  const [frames, setFrames] = useState<RRRFrame[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const resp = await fetch(`${RAINRADAR_URL}/composite/manifest.json?_=${Date.now()}`);
      const manifest = await resp.json();
      manifest.sort((a:any,b:any)=>a[0]-b[0]);
      const mapped: RRRFrame[] = manifest.map((f:any)=>{
        const zooms: Record<number, [number, number][]> = {};
        f[1].forEach((tiles:any, zi:number)=> { zooms[zi+3] = tiles; });
        return { ts: f[0], zooms };
      });
      setFrames(mapped);
      setCurrentIndex(mapped.length ? mapped.length-1 : 0);
    } catch(e){ console.warn('RR load', e); }
    finally { setLoading(false); }
  }, []);

  useEffect(()=> {
    if (!enabled) return;
    load();
    const iv = setInterval(load, 300000);
    return ()=> clearInterval(iv);
  }, [enabled, load]);

  return {
    frames,
    currentIndex,
    currentFrame: frames[currentIndex] || null,
    setFrame: setCurrentIndex,
    loading,
    refresh: load,
  };
}
