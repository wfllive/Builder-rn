import { useEffect, useRef, useState, useCallback } from 'react';
import { AppConfig } from '@/constants/config';
import { API_STRIKES } from '@/constants/config';
import { AppState, AppStateStatus, Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { distanceKm } from '@/utils/geo';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

const POLL_MIN = 5000;
const POLL_MAX = 30000;
const POLL_STEP = 5000;
const FULL_RELOAD_INTERVAL = 60000;

export function useLightningStream(
  onStrike: (s:any)=>boolean | void,
  config: AppConfig,
  resetStrikes?: () => void,
  replaceAll?: (arr:any[])=>number
) {
  const [isConnected, setIsConnected] = useState(false);
  const onStrikeRef = useRef(onStrike);
  const configRef = useRef(config);
  const resetRef = useRef(resetStrikes);
  const replaceRef = useRef(replaceAll);

  useEffect(() => { onStrikeRef.current = onStrike; }, [onStrike]);
  useEffect(() => { configRef.current = config; }, [config]);
  useEffect(() => { resetRef.current = resetStrikes; }, [resetStrikes]);
  useEffect(() => { replaceRef.current = replaceAll; }, [replaceAll]);

  const lastTimeRef = useRef(0);
  const lastFullReloadRef = useRef(0);
  const isLoadingRef = useRef(false);
  const pollIntervalRef = useRef(POLL_MIN);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeRef = useRef(true);

  const clearTimer = useCallback(() => {
    if (timeoutRef.current) { clearTimeout(timeoutRef.current); timeoutRef.current = null; }
  }, []);

  const schedule = useCallback((fn: ()=>void, ms: number) => {
    clearTimer();
    timeoutRef.current = setTimeout(fn, ms);
  }, [clearTimer]);

  const loadFromDB = useCallback(async (life: number, reason='load', fullReplace=false) => {
    if (isLoadingRef.current) return;
    isLoadingRef.current = true;
    try {
      const url = `${API_STRIKES}?life=${life}`;
      const resp = await fetch(url);
      if (!resp.ok) throw new Error('http '+resp.status);
      const data = await resp.json();
      if (data.ok && Array.isArray(data.strikes)) {
        if (fullReplace && replaceRef.current) {
          replaceRef.current(data.strikes);
        } else {
          data.strikes.forEach((s:any)=> onStrikeRef.current?.(s));
        }
        if (data.strikes.length) {
          lastTimeRef.current = Math.max(...data.strikes.map((s:any)=> Math.floor((s.time||0)/1e9))) + 1;
        }
        setIsConnected(true);
        pollIntervalRef.current = POLL_MIN;
      }
      lastFullReloadRef.current = Date.now();
    } catch(e) {
      setIsConnected(false);
      console.warn('strike load err', e);
    } finally {
      isLoadingRef.current = false;
    }
  }, []);

  const poll = useCallback(async () => {
    if (!activeRef.current) return;
    const life = configRef.current?.life || 60;
    const now = Date.now();
    if (now - lastFullReloadRef.current > FULL_RELOAD_INTERVAL) {
      await loadFromDB(life, 'periodic', true);
      schedule(poll, pollIntervalRef.current);
      return;
    }
    try {
      const since = lastTimeRef.current;
      const url = since > 0
        ? `${API_STRIKES}?since=${since}&limit=200&life=${life}`
        : `${API_STRIKES}?life=${life}`;
      const resp = await fetch(url);
      if (!resp.ok) throw new Error('http '+resp.status);
      const data = await resp.json();
      if (data.ok && data.strikes?.length) {
        let added = 0;
        data.strikes.forEach((s:any)=> { const r = onStrikeRef.current?.(s); if (r) added++; });
        const maxTime = Math.max(...data.strikes.map((s:any)=> Math.floor((s.time||0)/1e9)));
        if (maxTime >= lastTimeRef.current) lastTimeRef.current = maxTime + 1;
        if (added > 0) pollIntervalRef.current = POLL_MIN;
        else pollIntervalRef.current = Math.min(pollIntervalRef.current + POLL_STEP, POLL_MAX);
        setIsConnected(true);
      } else {
        pollIntervalRef.current = Math.min(pollIntervalRef.current + POLL_STEP, POLL_MAX);
      }
    } catch(e) {
      setIsConnected(false);
      pollIntervalRef.current = POLL_MAX;
    }
    schedule(poll, pollIntervalRef.current);
  }, [loadFromDB, schedule]);

  // initial
  useEffect(() => {
    activeRef.current = true;
    loadFromDB(configRef.current.life, 'initial', false).then(()=>{
      schedule(poll, POLL_MIN);
    });
    return () => { activeRef.current = false; clearTimer(); };
  }, [loadFromDB, poll, schedule, clearTimer]);

  // life change
  const prevLife = useRef(config.life);
  useEffect(() => {
    if (config.life !== prevLife.current) {
      prevLife.current = config.life;
      lastTimeRef.current = 0;
      lastFullReloadRef.current = 0;
      pollIntervalRef.current = POLL_MIN;
      loadFromDB(config.life, 'life-changed', true);
    }
  }, [config.life, loadFromDB]);

  // app state
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state: AppStateStatus) => {
      if (state === 'active') {
        activeRef.current = true;
        loadFromDB(configRef.current.life, 'resumed', true).then(()=>{
          schedule(poll, POLL_MIN);
        });
      } else {
        activeRef.current = false;
        clearTimer();
      }
    });
    return () => sub.remove();
  }, [loadFromDB, poll, schedule, clearTimer]);

  return { isConnected };
}
