import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppConfig } from '@/constants/config';

export type Strike = {
  id: string;
  lat: number;
  lon: number;
  ts: number; // seconds unix
  time: number; // ns from api? we normalize
  ex: { pol?: number; sta?: number };
  born: number;
};

function makeId(s: any) {
  const t = Math.floor((s.time || s.ts*1e9)/1e9);
  return `${s.lat.toFixed(3)}_${s.lon.toFixed(3)}_${t}`;
}

export function useStrikes(config: AppConfig, myPos: [number, number] | null) {
  const [map, setMap] = useState<Map<string, Strike>>(new Map());
  const mapRef = useRef(map);
  useEffect(() => { mapRef.current = map; }, [map]);

  // cleanup old
  useEffect(() => {
    const iv = setInterval(() => {
      const lifeMs = config.life * 60 * 1000;
      const now = Date.now();
      let changed = false;
      const next = new Map(mapRef.current);
      next.forEach((v, k) => {
        if (now - v.born > lifeMs) { next.delete(k); changed = true; }
      });
      if (changed) setMap(next);
    }, 5000);
    return () => clearInterval(iv);
  }, [config.life]);

  const addStrike = useCallback((raw: any) => {
    // normalize: api gives time in ns
    const timeNs = raw.time ?? (raw.ts ? raw.ts * 1e9 : Date.now()*1e6);
    const ts = Math.floor(timeNs / 1e9);
    const s: Strike = {
      id: '',
      lat: raw.lat,
      lon: raw.lon,
      ts,
      time: timeNs,
      ex: { pol: raw.pol, sta: raw.sta },
      born: Date.now(),
    };
    s.id = makeId(s);
    let added = false;
    setMap(prev => {
      if (prev.has(s.id)) return prev;
      const n = new Map(prev);
      n.set(s.id, s);
      added = true;
      return n;
    });
    return added;
  }, []);

  const reset = useCallback(() => setMap(new Map()), []);
  const replaceAll = useCallback((arr: any[]) => {
    const n = new Map<string, Strike>();
    const now = Date.now();
    arr.forEach(raw => {
      const timeNs = raw.time ?? (raw.ts ? raw.ts * 1e9 : now*1e6);
      const ts = Math.floor(timeNs/1e9);
      const s: Strike = {
        id: '',
        lat: raw.lat,
        lon: raw.lon,
        ts,
        time: timeNs,
        ex: { pol: raw.pol, sta: raw.sta },
        born: now,
      };
      s.id = makeId(s);
      n.set(s.id, s);
    });
    setMap(n);
    return n.size;
  }, []);

  const list = useMemo(() => Array.from(map.values()), [map]);
  const total = list.length;

  const perMin = useMemo(() => {
    const now = Date.now()/1000;
    const buckets = Array(60).fill(0);
    list.forEach(st => {
      const age = Math.floor(now - st.ts);
      if (age >=0 && age < 60) buckets[59-age]++;
    });
    return buckets;
  }, [list]);

  return { list, total, perMin, addStrike, reset, replaceAll };
}
