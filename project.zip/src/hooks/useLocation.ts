import { useEffect, useState } from 'react';
import * as Location from 'expo-location';

export function useLocation() {
  const [position, setPosition] = useState<[number, number] | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);

  useEffect(() => {
    let sub: Location.LocationSubscription | null = null;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({});
      setPosition([loc.coords.latitude, loc.coords.longitude]);
      setAccuracy(loc.coords.accuracy ?? null);
      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.Balanced, distanceInterval: 20, timeInterval: 5000 },
        (l) => {
          setPosition([l.coords.latitude, l.coords.longitude]);
          setAccuracy(l.coords.accuracy ?? null);
        }
      );
    })();
    return () => { sub?.remove(); };
  }, []);

  return { position, accuracy };
}
