import { useCallback, useEffect, useState } from 'react';
import { RAINVIEWER_API } from '@/constants/config';

export type RainFrame = {
  time: number;
  path: string;
  url: string;
};

export function useRainRadar(enabled: boolean) {
  const [frames, setFrames] = useState<RainFrame[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(RAINVIEWER_API);
      const json = await res.json();
      const host = json.host as string;
      const past = json.radar?.past ?? [];
      const nowcast = json.radar?.nowcast ?? [];
      const all = [...past, ...nowcast];
      const mapped: RainFrame[] = all.map((f:any)=> ({
        time: f.time,
        path: f.path,
        url: `${host}${f.path}/256/{z}/{x}/{y}/2/1_1.png`,
      }));
      setFrames(mapped);
      setCurrentIndex(mapped.length ? mapped.length-1 : 0);
    } catch(e) {
      console.warn('rain load', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    load();
    const iv = setInterval(load, 5*60*1000);
    return ()=> clearInterval(iv);
  }, [enabled, load]);

  return {
    frames,
    currentIndex,
    currentFrame: frames[currentIndex] || null,
    setFrame: setCurrentIndex,
    loading,
    refresh: load,
  };
}
