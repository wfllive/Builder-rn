import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { themes } from '../theme/colors';

const STORAGE_KEY = '@skpro_app_settings_v2';

const messages = {
  ru: {
    appName: 'RN Studio',
    appSubtitle: 'Конструктор Expo и React Native',
    projects: 'Проекты',
    newProject: 'Новый проект',
    createProject: 'Создать проект',
    projectName: 'Название проекта',
    searchProjects: 'Поиск проектов',
    noProjects: 'Проектов пока нет',
    noProjectsHint: 'Создайте Expo Router проект, чтобы начать работу.',
    settings: 'Настройки',
    appearance: 'Оформление',
    language: 'Язык',
    theme: 'Тема',
    system: 'Системная',
    light: 'Светлая',
    dark: 'Тёмная',
    russian: 'Русский',
    english: 'English',
    cancel: 'Отмена',
    save: 'Сохранить',
    delete: 'Удалить',
    close: 'Закрыть',
    retry: 'Повторить',
    back: 'Назад',
    install: 'Установить',
    continue: 'Продолжить',
    terminal: 'Терминал',
    libraries: 'Библиотеки',
    build: 'Сборка',
    editor: 'Редактор',
    design: 'Дизайн',
    logic: 'Логика',
    preview: 'Предпросмотр',
    properties: 'Свойства',
    components: 'Компоненты',
    logs: 'Журнал',
    hidden: 'Скрыт',
    half: 'Половина',
    full: 'Полный',
    screens: 'Экраны',
    addScreen: 'Добавить экран',
    loading: 'Загрузка',
    ready: 'Готово',
  },
  en: {
    appName: 'RN Studio',
    appSubtitle: 'Expo and React Native builder',
    projects: 'Projects',
    newProject: 'New project',
    createProject: 'Create project',
    projectName: 'Project name',
    searchProjects: 'Search projects',
    noProjects: 'No projects yet',
    noProjectsHint: 'Create an Expo Router project to get started.',
    settings: 'Settings',
    appearance: 'Appearance',
    language: 'Language',
    theme: 'Theme',
    system: 'System',
    light: 'Light',
    dark: 'Dark',
    russian: 'Русский',
    english: 'English',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    close: 'Close',
    retry: 'Retry',
    back: 'Back',
    install: 'Install',
    continue: 'Continue',
    terminal: 'Terminal',
    libraries: 'Libraries',
    build: 'Build',
    editor: 'Editor',
    design: 'Design',
    logic: 'Logic',
    preview: 'Preview',
    properties: 'Properties',
    components: 'Components',
    logs: 'Logs',
    hidden: 'Hidden',
    half: 'Half',
    full: 'Full',
    screens: 'Screens',
    addScreen: 'Add screen',
    loading: 'Loading',
    ready: 'Ready',
  },
};

const AppSettingsContext = createContext(null);

export const AppSettingsProvider = ({ children }) => {
  const systemScheme = useColorScheme();
  const [themeMode, setThemeModeState] = useState('system');
  const [language, setLanguageState] = useState('ru');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!raw) return;
        const value = JSON.parse(raw);
        if (['system', 'light', 'dark'].includes(value.themeMode)) setThemeModeState(value.themeMode);
        if (['ru', 'en'].includes(value.language)) setLanguageState(value.language);
      })
      .catch(() => {})
      .finally(() => setLoaded(true));
  }, []);

  const persist = (next) => AsyncStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({ themeMode: next.themeMode, language: next.language }),
  ).catch(() => {});

  const setThemeMode = (value) => {
    setThemeModeState(value);
    persist({ themeMode: value, language });
  };

  const setLanguage = (value) => {
    setLanguageState(value);
    persist({ themeMode, language: value });
  };

  const resolvedTheme = themeMode === 'system'
    ? (systemScheme === 'dark' ? 'dark' : 'light')
    : themeMode;
  const colors = themes[resolvedTheme];
  const t = (key) => messages[language]?.[key] || messages.ru[key] || key;

  const value = useMemo(() => ({
    loaded,
    themeMode,
    setThemeMode,
    language,
    setLanguage,
    resolvedTheme,
    colors,
    t,
  }), [loaded, themeMode, language, resolvedTheme, colors]);

  return <AppSettingsContext.Provider value={value}>{children}</AppSettingsContext.Provider>;
};

export const useAppSettings = () => {
  const value = useContext(AppSettingsContext);
  if (!value) throw new Error('useAppSettings must be used inside AppSettingsProvider');
  return value;
};

export default AppSettingsContext;
