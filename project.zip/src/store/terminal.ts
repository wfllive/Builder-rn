/**
 * Глобальный стор приложения
 */
import { create } from 'zustand';
import type { ScreenBuffer } from '../terminal/ansi';
import { AnsiParser } from '../terminal/ansi';
import { ProotSession } from '../services/native';
import { DISTROS, DistroInfo } from '../data/distros';

interface SessionInfo {
  id: string;
  distroId: string;
  alive: boolean;
  exitCode?: number;
  startedAt: number;
}

interface TerminalState {
  // Setup
  initialized: boolean;
  prootDir: string;
  rootfsDir: string;
  setupError?: string;

  // Sessions
  sessions: Map<string, SessionInfo>;
  currentSessionId: string | null;
  screens: Map<string, ScreenBuffer>;
  parsers: Map<string, AnsiParser>;

  // Distros
  installedDistros: { id: string; sizeMB: number; path: string; installedAt: number }[];
  installProgress: { distroId: string; percent: number; message: string } | null;

  // Actions
  setup: () => Promise<void>;
  startSession: (distroId: string) => Promise<string | null>;
  closeSession: (id: string) => void;
  setCurrent: (id: string) => void;
  writeToSession: (id: string, text: string) => void;
  resizeSession: (id: string, rows: number, cols: number) => void;

  refreshInstalled: () => Promise<void>;
  installDistro: (d: DistroInfo) => Promise<void>;
  removeDistro: (id: string) => Promise<void>;
}

const base64ToUtf8 = (b64: string): string => {
  const bin = global.Buffer
    ? Buffer.from(b64, 'base64')
    : Uint8Array.from(atob(b64), c => c.charCodeAt(0));
  if (typeof bin === 'string') return bin;
  // RN обычно не имеет atob глобально; используем глобальную обвязку
  // Фоллбэк — UTF-8 decode
  let str = '';
  for (let i = 0; i < (bin as Uint8Array).length; i++) {
    str += String.fromCharCode((bin as Uint8Array)[i]);
  }
  return str;
};

export const useTerminal = create<TerminalState>((set, get) => {
  // Подписки на события
  ProotSession.onOutput((e) => {
    const { sessionId, data } = e;
    const parser = get().parsers.get(sessionId);
    if (!parser) return;
    const text = base64ToUtf8(data);
    parser.feed(text);
    // Триггерим re-render
    set({ screens: new Map(get().screens) });
  });

  ProotSession.onExit((e) => {
    const s = get().sessions.get(e.sessionId);
    if (s) {
      s.alive = false;
      s.exitCode = e.code;
      set({ sessions: new Map(get().sessions) });
    }
  });

  ProotSession.onInstallProgress((e) => {
    set({ installProgress: e });
    if (e.percent >= 100) {
      setTimeout(() => {
        if (get().installProgress?.distroId === e.distroId) {
          set({ installProgress: null });
        }
      }, 1500);
    }
  });

  return {
    initialized: false,
    prootDir: '',
    rootfsDir: '',
    sessions: new Map(),
    currentSessionId: null,
    screens: new Map(),
    parsers: new Map(),
    installedDistros: [],
    installProgress: null,

    async setup() {
      try {
        const r = await ProotSession.setup();
        set({
          initialized: true,
          prootDir: r.prootDir,
          rootfsDir: r.rootfsDir,
        });
        await get().refreshInstalled();
      } catch (e: any) {
        set({ setupError: e.message });
      }
    },

    async startSession(distroId) {
      if (!get().initialized) {
        await get().setup();
      }
      const installed = get().installedDistros.find((d) => d.id === distroId);
      if (!installed) {
        return null;
      }
      const id = `sess-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      try {
        await ProotSession.startSession(id, distroId);
        const info: SessionInfo = {
          id,
          distroId,
          alive: true,
          startedAt: Date.now(),
        };
        const screen = new (require('../terminal/ansi').ScreenBuffer)();
        const parser = new AnsiParser(screen);
        screen.writeBack = (data: string) => ProotSession.writeText(id, data);
        const newSessions = new Map(get().sessions);
        newSessions.set(id, info);
        const newScreens = new Map(get().screens);
        newScreens.set(id, screen);
        const newParsers = new Map(get().parsers);
        newParsers.set(id, parser);
        set({
          sessions: newSessions,
          screens: newScreens,
          parsers: newParsers,
          currentSessionId: id,
        });
        return id;
      } catch (e) {
        console.warn('startSession error:', e);
        return null;
      }
    },

    closeSession(id) {
      ProotSession.kill(id);
      const newSessions = new Map(get().sessions);
      newSessions.delete(id);
      const newScreens = new Map(get().screens);
      newScreens.delete(id);
      const newParsers = new Map(get().parsers);
      newParsers.delete(id);
      set({
        sessions: newSessions,
        screens: newScreens,
        parsers: newParsers,
        currentSessionId: get().currentSessionId === id ? null : get().currentSessionId,
      });
    },

    setCurrent(id) {
      set({ currentSessionId: id });
    },

    writeToSession(id, text) {
      ProotSession.writeText(id, text);
    },

    resizeSession(id, rows, cols) {
      ProotSession.resize(id, rows, cols);
    },

    async refreshInstalled() {
      try {
        const list = await ProotSession.listInstalled();
        set({ installedDistros: list });
      } catch (e) {
        console.warn('refreshInstalled error:', e);
      }
    },

    async installDistro(d) {
      try {
        await ProotSession.installDistro(d.id, d.tarballUrl);
        await get().refreshInstalled();
      } catch (e: any) {
        set({ installProgress: { distroId: d.id, percent: 0, message: 'Ошибка: ' + e.message } });
      }
    },

    async removeDistro(id) {
      await ProotSession.removeDistro(id);
      await get().refreshInstalled();
    },
  };
});
