import { create } from 'zustand';
import { DEFAULT_CONFIG, AppConfig } from '@/constants/config';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

const STORAGE_KEY = 'ms_config_v1';

async function loadPersisted(): Promise<Partial<AppConfig> | null> {
  try {
    if (Platform.OS === 'web') {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } else {
      const raw = await SecureStore.getItemAsync(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    }
  } catch { return null; }
}
async function savePersisted(cfg: AppConfig) {
  try {
    const str = JSON.stringify(cfg);
    if (Platform.OS === 'web') localStorage.setItem(STORAGE_KEY, str);
    else await SecureStore.setItemAsync(STORAGE_KEY, str);
  } catch {}
}

type State = {
  config: AppConfig;
  hydrated: boolean;
  toggle: (k: keyof AppConfig) => void;
  update: <K extends keyof AppConfig>(k: K, v: AppConfig[K]) => void;
  setConfig: (c: Partial<AppConfig>) => void;
  hydrate: () => Promise<void>;
};

export const useConfigStore = create<State>((set, get) => ({
  config: DEFAULT_CONFIG,
  hydrated: false,
  toggle: (k) => {
    const cur = get().config;
    // @ts-ignore boolean toggle
    const next = { ...cur, [k]: !cur[k] };
    set({ config: next });
    savePersisted(next);
  },
  update: (k, v) => {
    const next = { ...get().config, [k]: v };
    set({ config: next });
    savePersisted(next);
  },
  setConfig: (c) => {
    const next = { ...get().config, ...c };
    set({ config: next });
    savePersisted(next);
  },
  hydrate: async () => {
    const p = await loadPersisted();
    if (p) set({ config: { ...DEFAULT_CONFIG, ...p }, hydrated: true });
    else set({ hydrated: true });
  },
}));

// auto hydrate
useConfigStore.getState().hydrate();
