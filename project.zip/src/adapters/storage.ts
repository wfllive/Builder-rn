/**
 * Адаптер постоянного хранилища.
 *
 * WEB: localStorage
 * NATIVE: AsyncStorage
 *
 * Shared-слой (тема, UI-настройки, черновики) больше не ходит
 * в localStorage напрямую — только через эти функции.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";

/** Прочитать строку. null — ключа нет. */
export async function storageGet(key: string): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(key);
  } catch {
    return null;
  }
}

/** Записать строку. */
export async function storageSet(key: string, value: string): Promise<void> {
  try {
    await AsyncStorage.setItem(key, value);
  } catch {
    // Молча: хранилище не должно ронять UI
  }
}

/** Удалить ключ. */
export async function storageRemove(key: string): Promise<void> {
  try {
    await AsyncStorage.removeItem(key);
  } catch {
    // no-op
  }
}
