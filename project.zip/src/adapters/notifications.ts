/**
 * Адаптер уведомлений.
 *
 * На вебе виджеты читали Zustand-стор `useNotifications`.
 * Здесь — тонкий контракт, чтобы shared не знал про конкретный стор.
 */

import React from "react";

export interface NotificationsAdapter {
  unreadCount: number;
}

let adapter: NotificationsAdapter = { unreadCount: 0 };
const listeners = new Set<() => void>();

/** Подключить реальный стор уведомлений. */
export function setNotificationsAdapter(next: NotificationsAdapter): void {
  adapter = next;
  listeners.forEach((l) => l());
}

/** Хук количества непрочитанных — порт useNotifications. */
export function useNotifications(): NotificationsAdapter {
  const [, setTick] = React.useState(0);

  React.useEffect(() => {
    const listener = () => setTick((v) => v + 1);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  return adapter;
}

/** Заглушка звука уведомлений (на native подключается expo-av в оболочке). */
export function useNotificationSound(_unreadCount: number): void {
  // no-op: звук живёт в app-слое, не в shared
}
