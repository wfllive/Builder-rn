/**
 * Лёгкий аналог clsx/cn для склейки Tailwind-классов.
 * Пустые значения выкидываются — удобно в условных className.
 */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}
