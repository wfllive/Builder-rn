/**
 * Навигационный адаптер на Expo Router.
 *
 * Shared-виджеты не импортируют `expo-router` напрямую —
 * только этот файл. Так UI-кит остаётся независимым от оболочки.
 */
import { usePathname, useRouter } from "expo-router";

/** Контракт навигатора (на случай кастомной подмены в тестах). */
export interface AppNavigator {
  push: (href: string) => void;
  replace: (href: string) => void;
  back: () => void;
  pathname: () => string;
}

let navigatorOverride: AppNavigator | null = null;

/** Подмена навигатора (тесты / storybook). В обычном приложении не нужна. */
export function setAppNavigator(next: AppNavigator | null): void {
  navigatorOverride = next;
}

/**
 * Хук навигации для shared-слоя.
 * Внутри экранов Expo Router — это useRouter + usePathname.
 */
export function useAppNavigation() {
  const router = useRouter();
  const pathname = usePathname();

  if (navigatorOverride) {
    return {
      push: navigatorOverride.push,
      replace: navigatorOverride.replace,
      back: navigatorOverride.back,
      pathname: navigatorOverride.pathname(),
    };
  }

  return {
    push: (href: string) => {
      router.push(href as never);
    },
    replace: (href: string) => {
      router.replace(href as never);
    },
    back: () => {
      if (router.canGoBack()) router.back();
      else router.replace("/" as never);
    },
    pathname,
  };
}
