/**
 * Адаптер авторизации.
 *
 * На вебе shared тянул `useAuth`, `useAuthGate`, `userStore`.
 * В мобильном приложении эти сторы живут в другом пакете,
 * поэтому shared получает данные только через этот контракт.
 *
 * Оболочка приложения вызывает `setAuthAdapter` при старте.
 */

/** Минимальный пользователь, нужный shared-виджетам. */
export interface AuthUser {
  id: number;
  user_id: string;
  username: string;
  avatar?: string | null;
}

/** Контракт, который реализует слой state приложения. */
export interface AuthAdapter {
  isAuth: boolean;
  user: AuthUser | null;
  /**
   * Выполнить действие только если пользователь авторизован.
   * Иначе показать модалку «нужна авторизация».
   */
  runWithAuth: (action: () => void, payload?: AuthGatePayload) => void;
}

/** Данные для модалки «войди, чтобы…» */
export interface AuthGatePayload {
  title?: string;
  message?: string;
  icon?: React.ReactNode;
}

import React from "react";

const defaultAdapter: AuthAdapter = {
  isAuth: false,
  user: null,
  runWithAuth: (action) => {
    // Базовый пример: без реальной сессии просто выполняем действие
    action();
  },
};

let adapter: AuthAdapter = defaultAdapter;
const listeners = new Set<() => void>();

/** Подключить реальный auth-слой приложения. */
export function setAuthAdapter(next: AuthAdapter): void {
  adapter = next;
  listeners.forEach((l) => l());
}

/** Хук доступа к auth из shared-виджетов. */
export function useAuth(): AuthAdapter {
  const [, setTick] = React.useState(0);

  React.useEffect(() => {
    const listener = () => setTick((v) => v + 1);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  return adapter;
}

/** Хук «действие под авторизацией» — порт useAuthGate. */
export function useAuthGate() {
  const auth = useAuth();
  return { runWithAuth: auth.runWithAuth, isAuth: auth.isAuth };
}
