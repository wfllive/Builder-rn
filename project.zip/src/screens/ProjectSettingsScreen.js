import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Switch,
} from 'react-native';
import { useProject } from '../store/projectStore';
import colors from '../theme/colors';

const ProjectSettingsScreen = ({ navigation }) => {
  const { currentProject, dispatch, updateComponentTree, getCurrentScreen } = useProject();

  const [projectName, setProjectName] = useState(currentProject?.name || '');
  const [packageName, setPackageName] = useState(currentProject?.packageName || '');
  const [versionName, setVersionName] = useState(currentProject?.versionName || '1.0.0');
  const [primaryColor, setPrimaryColor] = useState(currentProject?.theme?.primaryColor || '#BB86FC');
  const [secondaryColor, setSecondaryColor] = useState(currentProject?.theme?.secondaryColor || '#03DAC6');
  const [backgroundColor, setBackgroundColor] = useState(currentProject?.theme?.backgroundColor || '#121212');
  const [isDark, setIsDark] = useState(currentProject?.theme?.isDark !== false);

  // Variables management
  const [newVarName, setNewVarName] = useState('');
  const [newVarType, setNewVarType] = useState('text');
  const [newVarValue, setNewVarValue] = useState('');

  if (!currentProject) {
    return (
      <View style={styles.container}>
        <Text style={styles.emptyText}>Нет открытого проекта</Text>
      </View>
    );
  }

  const handleSave = () => {
    const updatedProject = {
      ...currentProject,
      name: projectName,
      packageName,
      versionName,
      theme: {
        primaryColor,
        secondaryColor,
        backgroundColor,
        isDark,
      },
    };
    dispatch({ type: 'UPDATE_PROJECT', payload: updatedProject });
    Alert.alert('Сохранено', 'Настройки проекта обновлены');
  };

  const handleAddVariable = () => {
    if (!newVarName.trim()) {
      Alert.alert('Ошибка', 'Введите имя переменной');
      return;
    }
    const { generateId } = require('../utils/generateId');
    dispatch({
      type: 'ADD_VARIABLE',
      payload: {
        id: generateId(),
        name: newVarName.trim(),
        type: newVarType,
        value: newVarType === 'number' ? Number(newVarValue) || 0 : newVarValue,
      },
    });
    setNewVarName('');
    setNewVarValue('');
  };

  const handleDeleteVariable = (id) => {
    Alert.alert('Удалить переменную?', '', [
      { text: 'Отмена', style: 'cancel' },
      { text: 'Удалить', style: 'destructive', onPress: () => dispatch({ type: 'DELETE_VARIABLE', payload: id }) },
    ]);
  };

  const handleAddList = () => {
    const { generateId } = require('../utils/generateId');
    Alert.alert(
      'Новый список',
      'Введите имя списка',
      [
        { text: 'Отмена', style: 'cancel' },
      ]
    );
  };

  const presetColors = ['#BB86FC', '#03DAC6', '#FF6B35', '#CF6679', '#4CAF50', '#2196F3', '#FFC107', '#9C27B0', '#00BCD4', '#FF5722'];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
          <Text style={styles.backButtonText}>← Назад</Text>
        </TouchableOpacity>
        <Text style={styles.title}>⚙️ Настройки проекта</Text>
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveButtonText}>💾 Сохранить</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {/* General Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📋 Общие</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Название проекта</Text>
            <TextInput
              style={styles.textInput}
              value={projectName}
              onChangeText={setProjectName}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Package Name</Text>
            <TextInput
              style={styles.textInput}
              value={packageName}
              onChangeText={setPackageName}
              placeholder="com.example.app"
              placeholderTextColor={colors.onSurfaceVariant}
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Версия</Text>
            <TextInput
              style={styles.textInput}
              value={versionName}
              onChangeText={setVersionName}
              placeholder="1.0.0"
              placeholderTextColor={colors.onSurfaceVariant}
            />
          </View>
        </View>

        {/* Theme */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎨 Тема</Text>
          
          <View style={styles.switchRow}>
            <Text style={styles.switchLabel}>Тёмная тема</Text>
            <Switch
              value={isDark}
              onValueChange={setIsDark}
              trackColor={{ false: '#555', true: colors.primary }}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Основной цвет (Primary)</Text>
            <View style={styles.colorRow}>
              <View style={[styles.colorPreview, { backgroundColor: primaryColor }]} />
              <TextInput
                style={[styles.textInput, { flex: 1 }]}
                value={primaryColor}
                onChangeText={setPrimaryColor}
              />
            </View>
            <View style={styles.colorPresets}>
              {presetColors.map(c => (
                <TouchableOpacity
                  key={c}
                  style={[styles.colorPreset, { backgroundColor: c }]}
                  onPress={() => setPrimaryColor(c)}
                />
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Вторичный цвет (Secondary)</Text>
            <View style={styles.colorRow}>
              <View style={[styles.colorPreview, { backgroundColor: secondaryColor }]} />
              <TextInput
                style={[styles.textInput, { flex: 1 }]}
                value={secondaryColor}
                onChangeText={setSecondaryColor}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Фон</Text>
            <View style={styles.colorRow}>
              <View style={[styles.colorPreview, { backgroundColor }]} />
              <TextInput
                style={[styles.textInput, { flex: 1 }]}
                value={backgroundColor}
                onChangeText={setBackgroundColor}
              />
            </View>
          </View>
        </View>

        {/* Variables */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Переменные ({currentProject.variables?.length || 0})</Text>
          
          {/* Add variable */}
          <View style={styles.addRow}>
            <TextInput
              style={[styles.textInput, { flex: 1 }]}
              placeholder="Имя переменной"
              placeholderTextColor={colors.onSurfaceVariant}
              value={newVarName}
              onChangeText={setNewVarName}
            />
            <View style={styles.typeSelector}>
              {['text', 'number', 'boolean'].map(t => (
                <TouchableOpacity
                  key={t}
                  style={[styles.typeButton, newVarType === t && styles.typeButtonActive]}
                  onPress={() => setNewVarType(t)}
                >
                  <Text style={[styles.typeButtonText, newVarType === t && styles.typeButtonTextActive]}>
                    {t === 'text' ? 'Aa' : t === 'number' ? '#' : '⊘'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput
              style={[styles.textInput, { width: 80 }]}
              placeholder="Знач."
              placeholderTextColor={colors.onSurfaceVariant}
              value={newVarValue}
              onChangeText={setNewVarValue}
            />
            <TouchableOpacity style={styles.addButton} onPress={handleAddVariable}>
              <Text style={styles.addButtonText}>+</Text>
            </TouchableOpacity>
          </View>

          {/* Variables list */}
          {(currentProject.variables || []).map(v => (
            <View key={v.id} style={styles.variableRow}>
              <View style={styles.variableInfo}>
                <Text style={styles.variableName}>{v.name}</Text>
                <Text style={styles.variableMeta}>
                  {v.type}: {String(v.value)}
                </Text>
              </View>
              <TouchableOpacity
                style={styles.deleteVarButton}
                onPress={() => handleDeleteVariable(v.id)}
              >
                <Text style={styles.deleteVarText}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {/* Project Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ℹ️ Информация</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Экранов:</Text>
            <Text style={styles.infoValue}>{currentProject.screens?.length || 0}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Переменных:</Text>
            <Text style={styles.infoValue}>{currentProject.variables?.length || 0}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Создан:</Text>
            <Text style={styles.infoValue}>
              {new Date(currentProject.createdAt).toLocaleDateString('ru-RU')}
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Обновлён:</Text>
            <Text style={styles.infoValue}>
              {new Date(currentProject.updatedAt).toLocaleDateString('ru-RU')}
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>ID проекта:</Text>
            <Text style={styles.infoValueMono}>{currentProject.id.slice(0, 16)}...</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 16,
    textAlign: 'center',
    marginTop: 100,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 44,
    paddingHorizontal: 12,
    paddingBottom: 12,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: colors.primary,
    fontSize: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.onSurface,
    flex: 1,
    textAlign: 'center',
  },
  saveButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  saveButtonText: {
    color: colors.onPrimary,
    fontSize: 13,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  section: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.onSurface,
    marginBottom: 12,
  },
  inputGroup: {
    marginBottom: 14,
  },
  inputLabel: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
    marginBottom: 6,
    fontWeight: '600',
  },
  textInput: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: colors.onSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  colorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  colorPreview: {
    width: 36,
    height: 36,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  colorPresets: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 8,
  },
  colorPreset: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  switchLabel: {
    fontSize: 14,
    color: colors.onSurface,
  },
  addRow: {
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center',
    marginBottom: 12,
  },
  typeSelector: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceLight,
    borderRadius: 6,
    padding: 2,
  },
  typeButton: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 4,
  },
  typeButtonActive: {
    backgroundColor: colors.primary,
  },
  typeButtonText: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
    fontWeight: 'bold',
  },
  typeButtonTextActive: {
    color: colors.onPrimary,
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonText: {
    color: colors.onPrimary,
    fontSize: 18,
    fontWeight: 'bold',
  },
  variableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceLight,
    borderRadius: 8,
    padding: 12,
    marginBottom: 6,
  },
  variableInfo: {
    flex: 1,
  },
  variableName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.onSurface,
    fontFamily: 'monospace',
  },
  variableMeta: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  deleteVarButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.error + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteVarText: {
    color: colors.error,
    fontSize: 12,
    fontWeight: 'bold',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  infoLabel: {
    fontSize: 13,
    color: colors.onSurfaceVariant,
  },
  infoValue: {
    fontSize: 13,
    color: colors.onSurface,
    fontWeight: '600',
  },
  infoValueMono: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    fontFamily: 'monospace',
  },
});

export default ProjectSettingsScreen;
