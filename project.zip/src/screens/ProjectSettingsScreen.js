import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { checkCommand, execute, installEas } from '../utils/shellExecutor';
import { easEnvironment, getEasToken, readWorkspaceJson, saveEasToken, shellQuote, writeWorkspaceJson } from '../utils/workspace';
import { getProjectDir } from '../config/runtime';
import { generateId } from '../utils/generateId';

const EAS_CONFIG = {
  cli: { version: '>= 16.18.0', appVersionSource: 'remote' },
  build: {
    development: { developmentClient: true, distribution: 'internal' },
    preview: { distribution: 'internal', android: { buildType: 'apk' } },
    production: { autoIncrement: true },
  },
  submit: { production: {} },
};

const ProjectSettingsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { currentProject, dispatch } = useProject();
  const { colors, language, t } = useAppSettings();
  const [tab, setTab] = useState('app');
  const [form, setForm] = useState(() => ({
    name: currentProject?.name || '',
    packageName: currentProject?.packageName || '',
    scheme: currentProject?.scheme || currentProject?.slug || '',
    sdkVersion: currentProject?.sdkVersion || '57.0.0',
    versionName: currentProject?.versionName || '1.0.0',
    versionCode: String(currentProject?.versionCode || 1),
    runtimeVersion: currentProject?.runtimeVersion || currentProject?.versionName || '1.0.0',
    primaryColor: currentProject?.theme?.primaryColor || '#4F46E5',
    secondaryColor: currentProject?.theme?.secondaryColor || '#0E7490',
    backgroundColor: currentProject?.theme?.backgroundColor || '#F8FAFC',
    isDark: Boolean(currentProject?.theme?.isDark),
  }));
  const [saving, setSaving] = useState(false);
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [easStatus, setEasStatus] = useState({ checking: false, cli: false, account: null, error: '' });
  const [newVariable, setNewVariable] = useState({ name: '', type: 'text', value: '' });
  const styles = useMemo(() => createStyles(colors), [colors]);
  const twoColumns = width >= 780;

  const copy = language === 'ru' ? {
    title: 'Настройки проекта', app: 'Приложение', visual: 'Тема проекта', eas: 'EAS Build', variables: 'Переменные',
    identity: 'Идентификаторы и версии', workspace: 'Рабочая среда', name: 'Название', package: 'Android package', scheme: 'URL scheme',
    sdk: 'Expo SDK', version: 'Версия приложения', code: 'Android versionCode', runtime: 'Runtime version',
    saved: 'Настройки синхронизированы с app.json', saveFailed: 'Метаданные сохранены, но app.json обновить не удалось.',
    projectTheme: 'Тема создаваемого приложения', dark: 'Тёмная тема приложения', primary: 'Основной цвет', secondary: 'Акцент', background: 'Фон',
    auth: 'Авторизация Expo', token: 'Expo access token', tokenHint: 'Токен хранится в зашифрованном SecureStore и не попадает в JSON проекта.',
    saveToken: 'Сохранить и проверить', cli: 'EAS CLI', installCli: 'Установить EAS CLI', account: 'Аккаунт', notLogged: 'Не авторизован',
    loginTerminal: 'Войти в терминале', configure: 'Настроить development build', configuring: 'Настройка', buildDev: 'Development build', buildPreview: 'Preview APK', buildProd: 'Production AAB',
    variableName: 'Имя переменной', add: 'Добавить', remove: 'Удалить переменную?', noProject: 'Проект не открыт',
  } : {
    title: 'Project settings', app: 'Application', visual: 'Project theme', eas: 'EAS Build', variables: 'Variables',
    identity: 'Identifiers and versions', workspace: 'Workspace', name: 'Name', package: 'Android package', scheme: 'URL scheme',
    sdk: 'Expo SDK', version: 'App version', code: 'Android versionCode', runtime: 'Runtime version',
    saved: 'Settings synced to app.json', saveFailed: 'Metadata was saved, but app.json could not be updated.',
    projectTheme: 'Generated application theme', dark: 'Dark app theme', primary: 'Primary color', secondary: 'Accent', background: 'Background',
    auth: 'Expo authentication', token: 'Expo access token', tokenHint: 'The token is encrypted in SecureStore and is never included in project JSON.',
    saveToken: 'Save and verify', cli: 'EAS CLI', installCli: 'Install EAS CLI', account: 'Account', notLogged: 'Not authenticated',
    loginTerminal: 'Log in in terminal', configure: 'Configure development build', configuring: 'Configuring', buildDev: 'Development build', buildPreview: 'Preview APK', buildProd: 'Production AAB',
    variableName: 'Variable name', add: 'Add', remove: 'Delete variable?', noProject: 'No project is open',
  };

  useEffect(() => { getEasToken().then((value) => setToken(value || '')).catch(() => {}); }, []);

  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const save = async () => {
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(form.packageName)) {
      Alert.alert('Invalid Android package', 'Example: com.company.application');
      return;
    }
    setSaving(true);
    const updated = {
      ...currentProject,
      name: form.name.trim(),
      packageName: form.packageName.trim(),
      scheme: form.scheme.trim(),
      sdkVersion: form.sdkVersion.trim(),
      versionName: form.versionName.trim(),
      versionCode: Math.max(1, Number.parseInt(form.versionCode, 10) || 1),
      runtimeVersion: form.runtimeVersion.trim(),
      theme: { primaryColor: form.primaryColor, secondaryColor: form.secondaryColor, backgroundColor: form.backgroundColor, isDark: form.isDark },
    };
    dispatch({ type: 'UPDATE_PROJECT', payload: updated });
    try {
      let config;
      try { config = await readWorkspaceJson(updated, 'app.json'); } catch (e) { config = { expo: {} }; }
      config.expo = {
        ...(config.expo || {}),
        name: updated.name,
        slug: updated.slug,
        scheme: updated.scheme,
        version: updated.versionName,
        runtimeVersion: updated.runtimeVersion,
        userInterfaceStyle: updated.theme.isDark ? 'dark' : 'light',
        backgroundColor: updated.theme.backgroundColor,
        android: { ...(config.expo?.android || {}), package: updated.packageName, versionCode: updated.versionCode },
        ios: { ...(config.expo?.ios || {}), bundleIdentifier: updated.packageName, buildNumber: String(updated.versionCode) },
      };
      const result = await writeWorkspaceJson(updated, 'app.json', config);
      if (!result?.success) throw new Error(result?.output);
      Alert.alert(t('ready'), copy.saved);
    } catch (e) {
      Alert.alert(copy.saveFailed, e?.message || String(e));
    } finally {
      setSaving(false);
    }
  };

  const checkEas = async (nextToken = token) => {
    setEasStatus((value) => ({ ...value, checking: true, error: '' }));
    try {
      const cli = await checkCommand('eas');
      if (!cli.exists) {
        setEasStatus({ checking: false, cli: false, account: null, error: '' });
        return;
      }
      const env = nextToken.trim() ? `EXPO_TOKEN=${shellQuote(nextToken.trim())} ` : await easEnvironment();
      const result = await execute(`${env}eas whoami 2>&1`, getProjectDir(currentProject));
      setEasStatus({ checking: false, cli: true, account: result.success ? result.output.trim().split('\n').pop() : null, error: result.success ? '' : result.output });
    } catch (e) {
      setEasStatus({ checking: false, cli: false, account: null, error: e?.message || String(e) });
    }
  };

  useEffect(() => { if (tab === 'eas') checkEas(); }, [tab]);

  const storeToken = async () => {
    await saveEasToken(token);
    await checkEas(token);
  };

  const installCli = async () => {
    setEasStatus((value) => ({ ...value, checking: true }));
    const result = await installEas();
    if (!result?.success) Alert.alert('EAS CLI', result?.output || 'Installation failed');
    await checkEas();
  };

  const configure = async () => {
    setEasStatus((value) => ({ ...value, checking: true, error: '' }));
    try {
      const install = await execute('npx expo install expo-dev-client 2>&1', getProjectDir(currentProject));
      if (!install.success) throw new Error(install.output);
      const write = await writeWorkspaceJson(currentProject, 'eas.json', EAS_CONFIG);
      if (!write.success) throw new Error(write.output);
      const env = await easEnvironment();
      const init = await execute(`${env}eas init --non-interactive --force 2>&1`, getProjectDir(currentProject));
      if (!init.success) throw new Error(init.output);
      Alert.alert(t('ready'), copy.configure);
    } catch (e) {
      setEasStatus((value) => ({ ...value, error: e?.message || String(e) }));
      Alert.alert('EAS', (e?.message || String(e)).slice(0, 1400));
    } finally {
      setEasStatus((value) => ({ ...value, checking: false }));
    }
  };

  const addVariable = () => {
    if (!newVariable.name.trim()) return;
    const value = newVariable.type === 'number' ? Number(newVariable.value) || 0 : newVariable.type === 'boolean' ? newVariable.value === 'true' : newVariable.value;
    dispatch({ type: 'ADD_VARIABLE', payload: { id: generateId(), name: newVariable.name.trim(), type: newVariable.type, value } });
    setNewVariable({ name: '', type: 'text', value: '' });
  };

  if (!currentProject) return <AppScreen style={styles.center}><Text style={styles.muted}>{copy.noProject}</Text></AppScreen>;

  return (
    <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${currentProject.projectDir}`} onBack={() => navigation.goBack()} right={tab !== 'eas' ? <PrimaryButton title={width >= 600 ? t('save') : ''} icon="save-outline" loading={saving} onPress={save} /> : null} />
      <View style={styles.tabBar}><SegmentedControl value={tab} onChange={setTab} options={[
        { value: 'app', label: copy.app, icon: 'phone-portrait-outline' },
        { value: 'visual', label: copy.visual, icon: 'color-palette-outline' },
        { value: 'eas', label: copy.eas, icon: 'cloud-upload-outline' },
        { value: 'variables', label: copy.variables, icon: 'code-working-outline' },
      ]} /></View>
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
        <View style={styles.column}>
          {tab === 'app' ? <>
            <SectionCard title={copy.identity} icon="finger-print-outline">
              <View style={twoColumns ? styles.twoColumns : null}>
                <Field label={copy.name} value={form.name} onChangeText={(value) => set('name', value)} style={styles.field} />
                <Field label={copy.package} value={form.packageName} onChangeText={(value) => set('packageName', value)} autoCapitalize="none" style={styles.field} />
                <Field label={copy.scheme} value={form.scheme} onChangeText={(value) => set('scheme', value)} autoCapitalize="none" style={styles.field} />
                <Field label={copy.sdk} value={form.sdkVersion} onChangeText={(value) => set('sdkVersion', value)} keyboardType="decimal-pad" style={styles.field} />
                <Field label={copy.version} value={form.versionName} onChangeText={(value) => set('versionName', value)} style={styles.field} />
                <Field label={copy.code} value={form.versionCode} onChangeText={(value) => set('versionCode', value)} keyboardType="number-pad" style={styles.field} />
                <Field label={copy.runtime} value={form.runtimeVersion} onChangeText={(value) => set('runtimeVersion', value)} style={styles.field} />
              </View>
            </SectionCard>
            <SectionCard title={copy.workspace} icon="folder-open-outline">
              <View style={styles.infoRow}><Text style={styles.infoLabel}>Directory</Text><Text selectable style={styles.infoValue}>{currentProject.projectDir}</Text></View>
              <View style={styles.infoRow}><Text style={styles.infoLabel}>Template</Text><Text selectable style={styles.infoValue}>{currentProject.createdWith}</Text></View>
            </SectionCard>
          </> : null}

          {tab === 'visual' ? <SectionCard title={copy.projectTheme} icon="color-palette-outline">
            <View style={styles.switchRow}><View><Text style={styles.switchTitle}>{copy.dark}</Text><Text style={styles.switchHint}>userInterfaceStyle: {form.isDark ? 'dark' : 'light'}</Text></View><Switch value={form.isDark} onValueChange={(value) => set('isDark', value)} trackColor={{ false: colors.borderLight, true: colors.primary }} thumbColor="#FFFFFF" /></View>
            <ColorField label={copy.primary} value={form.primaryColor} onChange={(value) => set('primaryColor', value)} colors={colors} styles={styles} />
            <ColorField label={copy.secondary} value={form.secondaryColor} onChange={(value) => set('secondaryColor', value)} colors={colors} styles={styles} />
            <ColorField label={copy.background} value={form.backgroundColor} onChange={(value) => set('backgroundColor', value)} colors={colors} styles={styles} />
            <View style={[styles.appPreview, { backgroundColor: form.backgroundColor }]}><View style={[styles.appPreviewBar, { backgroundColor: form.primaryColor }]}><Text style={styles.appPreviewTitle}>{form.name || 'Application'}</Text></View><View style={styles.appPreviewBody}><View style={[styles.previewButton, { backgroundColor: form.primaryColor }]} /><View style={[styles.previewAccent, { backgroundColor: form.secondaryColor }]} /></View></View>
          </SectionCard> : null}

          {tab === 'eas' ? <>
            <SectionCard title={copy.auth} icon="person-circle-outline" right={<StatusPill label={easStatus.account || copy.notLogged} tone={easStatus.account ? 'success' : 'warning'} />}>
              <Field label={copy.token} hint={copy.tokenHint} value={token} onChangeText={setToken} secureTextEntry={!showToken} autoCapitalize="none" rightIcon="eye" />
              <View style={styles.buttonRow}><IconButton name={showToken ? 'eye-off-outline' : 'eye-outline'} label={showToken ? 'Hide' : 'Show'} onPress={() => setShowToken((value) => !value)} style={{ flex: 1 }} /><PrimaryButton title={copy.saveToken} icon="shield-checkmark-outline" loading={easStatus.checking} onPress={storeToken} style={{ flex: 2 }} /></View>
              {easStatus.error ? <View style={styles.errorBox}><Icon name="alert-circle-outline" size={17} color={colors.error} /><Text selectable style={styles.errorText}>{easStatus.error}</Text></View> : null}
            </SectionCard>
            <SectionCard title={copy.cli} icon="terminal-outline" right={<StatusPill label={easStatus.cli ? 'Installed' : 'Not found'} tone={easStatus.cli ? 'success' : 'warning'} />}>
              <View style={styles.buttonRow}>{!easStatus.cli ? <PrimaryButton title={copy.installCli} icon="download-outline" loading={easStatus.checking} onPress={installCli} style={{ flex: 1 }} /> : null}<IconButton name="log-in-outline" label={copy.loginTerminal} onPress={() => navigation.navigate('Terminal', { initialCommand: 'eas login' })} style={{ flex: 1 }} /><IconButton name="refresh-outline" label={t('retry')} onPress={() => checkEas()} style={{ flex: 1 }} /></View>
              <PrimaryButton title={copy.configure} icon="construct-outline" disabled={!easStatus.cli || !easStatus.account} loading={easStatus.checking} onPress={configure} />
            </SectionCard>
            <SectionCard title="Build profiles" icon="layers-outline">
              <View style={styles.buildGrid}><BuildButton icon="hammer-outline" title={copy.buildDev} subtitle="development · APK" onPress={() => navigation.navigate('Build', { profile: 'development' })} colors={colors} styles={styles} /><BuildButton icon="phone-portrait-outline" title={copy.buildPreview} subtitle="preview · APK" onPress={() => navigation.navigate('Build', { profile: 'preview' })} colors={colors} styles={styles} /><BuildButton icon="cloud-upload-outline" title={copy.buildProd} subtitle="production · AAB" onPress={() => navigation.navigate('Build', { profile: 'production' })} colors={colors} styles={styles} /></View>
            </SectionCard>
          </> : null}

          {tab === 'variables' ? <SectionCard title={`${copy.variables} (${currentProject.variables?.length || 0})`} icon="code-working-outline">
            <View style={twoColumns ? styles.variableForm : { gap: 8 }}><Field placeholder={copy.variableName} value={newVariable.name} onChangeText={(value) => setNewVariable((current) => ({ ...current, name: value }))} style={{ flex: 2 }} /><SegmentedControl value={newVariable.type} onChange={(value) => setNewVariable((current) => ({ ...current, type: value }))} options={[{ value: 'text', label: 'Text' }, { value: 'number', label: 'Number' }, { value: 'boolean', label: 'Bool' }]} /><Field placeholder="Value" value={newVariable.value} onChangeText={(value) => setNewVariable((current) => ({ ...current, value }))} style={{ flex: 1 }} /><PrimaryButton title={copy.add} icon="add" onPress={addVariable} disabled={!newVariable.name.trim()} /></View>
            {(currentProject.variables || []).map((variable) => <View key={variable.id} style={styles.variableRow}><View style={styles.variableIcon}><Icon name="code-slash-outline" size={16} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={styles.variableName}>{variable.name}</Text><Text style={styles.variableValue}>{variable.type} · {String(variable.value)}</Text></View><IconButton name="trash-outline" danger onPress={() => Alert.alert(copy.remove, '', [{ text: t('cancel') }, { text: t('delete'), style: 'destructive', onPress: () => dispatch({ type: 'DELETE_VARIABLE', payload: variable.id }) }])} style={{ width: 38, minWidth: 38, height: 38 }} /></View>)}
          </SectionCard> : null}
        </View>
      </ScrollView>
    </AppScreen>
  );
};

const ColorField = ({ label, value, onChange, styles }) => <View style={styles.colorField}><View style={[styles.colorSwatch, { backgroundColor: value }]} /><Field label={label} value={value} onChangeText={onChange} autoCapitalize="characters" style={{ flex: 1 }} /></View>;
const BuildButton = ({ icon, title, subtitle, onPress, colors, styles }) => <Pressable onPress={onPress} style={({ pressed }) => [styles.buildButton, pressed && { borderColor: colors.primary }]}><View style={styles.buildIcon}><Icon name={icon} size={20} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={styles.buildTitle}>{title}</Text><Text style={styles.buildSubtitle}>{subtitle}</Text></View><Icon name="chevron-forward" size={17} color={colors.textTertiary} /></Pressable>;

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center' }, muted: { color: c.textSecondary },
  tabBar: { padding: 8, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  page: { padding: 14, paddingBottom: 50 }, column: { width: '100%', maxWidth: 900, alignSelf: 'center', gap: 13 },
  twoColumns: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 }, field: { width: '48%', flexGrow: 1, minWidth: 240 },
  infoRow: { flexDirection: 'row', gap: 12, paddingVertical: 5 }, infoLabel: { width: 90, color: c.textSecondary, fontSize: 11 }, infoValue: { flex: 1, color: c.text, fontSize: 10, fontFamily: 'monospace' },
  switchRow: { minHeight: 52, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, switchTitle: { color: c.text, fontSize: 13, fontWeight: '650' }, switchHint: { color: c.textTertiary, fontSize: 10, marginTop: 3 },
  colorField: { flexDirection: 'row', alignItems: 'flex-end', gap: 9 }, colorSwatch: { width: 46, height: 46, borderRadius: 10, borderWidth: 1, borderColor: c.borderLight },
  appPreview: { height: 180, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: c.border }, appPreviewBar: { height: 48, justifyContent: 'center', paddingHorizontal: 14 }, appPreviewTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' }, appPreviewBody: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 11 }, previewButton: { width: 120, height: 34, borderRadius: 8 }, previewAccent: { width: 76, height: 7, borderRadius: 4 },
  buttonRow: { flexDirection: 'row', gap: 8 }, errorBox: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderRadius: 9, backgroundColor: c.errorBg, padding: 11 }, errorText: { color: c.errorText, fontSize: 10, fontFamily: 'monospace', lineHeight: 15, flex: 1 },
  buildGrid: { gap: 8 }, buildButton: { minHeight: 62, borderRadius: 11, borderWidth: 1, borderColor: c.border, backgroundColor: c.bg, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 10 }, buildIcon: { width: 39, height: 39, borderRadius: 10, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, buildTitle: { color: c.text, fontSize: 12, fontWeight: '700' }, buildSubtitle: { color: c.textTertiary, fontSize: 9, fontFamily: 'monospace', marginTop: 3 },
  variableForm: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 }, variableRow: { minHeight: 58, borderRadius: 10, backgroundColor: c.bg, borderWidth: 1, borderColor: c.border, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 10 }, variableIcon: { width: 34, height: 34, borderRadius: 9, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, variableName: { color: c.text, fontSize: 12, fontFamily: 'monospace', fontWeight: '700' }, variableValue: { color: c.textSecondary, fontSize: 9, marginTop: 3 },
});

export default ProjectSettingsScreen;
