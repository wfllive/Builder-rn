import React, { useMemo, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { syncComposeProject } from '../utils/composeProject';
import { generateId } from '../utils/generateId';

const ProjectSettingsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { currentProject, dispatch } = useProject();
  const { colors, language, t } = useAppSettings();
  const [tab, setTab] = useState('app');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(() => ({
    name: currentProject?.name || '', packageName: currentProject?.packageName || '', namespace: currentProject?.namespace || currentProject?.packageName || '',
    versionName: currentProject?.versionName || '1.0.0', versionCode: String(currentProject?.versionCode || 1), minSdk: String(currentProject?.minSdk || 24), targetSdk: String(currentProject?.targetSdk || 37), compileSdk: String(currentProject?.compileSdk || 37),
    reactVersion: currentProject?.reactVersion || '19.2.8', viteVersion: currentProject?.viteVersion || '5.4.0',
    primaryColor: currentProject?.theme?.primaryColor || '#4F46E5', secondaryColor: currentProject?.theme?.secondaryColor || '#0E7490', backgroundColor: currentProject?.theme?.backgroundColor || '#F8FAFC', isDark: Boolean(currentProject?.theme?.isDark),
    keystorePath: currentProject?.signing?.keystorePath || '', keyAlias: currentProject?.signing?.keyAlias || '', storePasswordEnv: currentProject?.signing?.storePasswordEnv || 'KEYSTORE_PASSWORD', keyPasswordEnv: currentProject?.signing?.keyPasswordEnv || 'KEY_PASSWORD',
  }));
  const [variable, setVariable] = useState({ name: '', type: 'text', value: '' });
  const styles = useMemo(() => createStyles(colors), [colors]);
  const two = width >= 760;
  const copy = language === 'ru' ? {
    title: 'Настройки React проекта', app: 'Приложение', android: 'Android WebView', theme: 'Тема', variables: 'Состояние (React)',
    identity: 'Идентификаторы и версии', build: 'Сборка и SDK', signing: 'Подпись Release', name: 'Название', package: 'Application ID', namespace: 'Namespace', version: 'Version name', code: 'Version code',
    min: 'Min SDK', target: 'Target SDK', compile: 'Compile SDK', react: 'React', vite: 'Vite',
    primary: 'Primary', secondary: 'Secondary', background: 'Background', dark: 'Тёмная тема',
    keystore: 'Путь к .jks', alias: 'Key alias', password: 'Переменная пароля', keyPassword: 'Переменная ключа',
    saved: 'package.json и React-файлы обновлены', invalid: 'Проверьте Application ID.', add: 'Добавить', stateName: 'Имя', remove: 'Удалить?', noProject: 'Проект не открыт',
  } : {
    title: 'React project settings', app: 'Application', android: 'Android WebView', theme: 'Theme', variables: 'State (React)',
    identity: 'Identifiers and versions', build: 'Build and SDK', signing: 'Release signing', name: 'Application name', package: 'Application ID', namespace: 'Namespace', version: 'Version name', code: 'Version code', min: 'Min SDK', target: 'Target SDK', compile: 'Compile SDK', react: 'React', vite: 'Vite', primary: 'Primary', secondary: 'Secondary', background: 'Background', dark: 'Dark theme',
    keystore: '.jks path', alias: 'Key alias', password: 'Store password env', keyPassword: 'Key password env', saved: 'package.json and React files updated', invalid: 'Check Application ID.', add: 'Add state', stateName: 'State name', remove: 'Delete state?', noProject: 'No project is open',
  };
  if (!currentProject) return <AppScreen style={styles.center}><Text style={styles.muted}>{copy.noProject}</Text></AppScreen>;
  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));
  const save = async () => {
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(form.packageName)) { Alert.alert(copy.invalid); return; }
    setSaving(true);
    const updated = {
      ...currentProject, name: form.name.trim(), packageName: form.packageName.trim(), namespace: form.namespace.trim() || form.packageName.trim(), versionName: form.versionName.trim(), versionCode: Math.max(1, parseInt(form.versionCode, 10) || 1), minSdk: parseInt(form.minSdk, 10) || 24, targetSdk: parseInt(form.targetSdk, 10) || 37, compileSdk: parseInt(form.compileSdk, 10) || 37, reactVersion: form.reactVersion.trim(), viteVersion: form.viteVersion.trim(), theme: { primaryColor: form.primaryColor, secondaryColor: form.secondaryColor, backgroundColor: form.backgroundColor, isDark: form.isDark }, signing: { keystorePath: form.keystorePath, keyAlias: form.keyAlias, storePasswordEnv: form.storePasswordEnv, keyPasswordEnv: form.keyPasswordEnv }, updatedAt: Date.now(),
    };
    dispatch({ type: 'UPDATE_PROJECT', payload: updated });
    const result = await syncComposeProject(updated);
    setSaving(false);
    Alert.alert(result.success ? t('ready') : 'Build', result.success ? copy.saved : result.output || 'Save failed');
  };
  const addVariable = () => {
    if (!variable.name.trim()) return;
    const value = variable.type === 'number' ? Number(variable.value) || 0 : variable.type === 'boolean' ? variable.value === 'true' : variable.value;
    dispatch({ type: 'ADD_VARIABLE', payload: { id: generateId(), name: variable.name.trim(), type: variable.type, value } });
    setVariable({ name: '', type: 'text', value: '' });
  };

  return <AppScreen>
    <TopBar title={copy.title} subtitle={`${currentProject.name} · ${currentProject.packageName}`} onBack={() => navigation.goBack()} right={<PrimaryButton title={width >= 560 ? t('save') : ''} icon="save-outline" loading={saving} onPress={save} />} />
    <View style={styles.tabs}><SegmentedControl value={tab} onChange={setTab} options={[{ value: 'app', label: copy.app, icon: 'logo-react' }, { value: 'android', label: copy.android, icon: 'logo-android' }, { value: 'theme', label: copy.theme, icon: 'color-palette-outline' }, { value: 'variables', label: copy.variables, icon: 'code-working-outline' }]} /></View>
    <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled"><View style={styles.column}>
      {tab === 'app' ? <SectionCard title={copy.identity} icon="finger-print-outline"><View style={two ? styles.grid : null}><Field label={copy.name} value={form.name} onChangeText={(v) => set('name', v)} style={styles.field} /><Field label={copy.package} value={form.packageName} onChangeText={(v) => set('packageName', v)} autoCapitalize="none" style={styles.field} /><Field label={copy.namespace} value={form.namespace} onChangeText={(v) => set('namespace', v)} autoCapitalize="none" style={styles.field} /><Field label={copy.version} value={form.versionName} onChangeText={(v) => set('versionName', v)} style={styles.field} /><Field label={copy.code} value={form.versionCode} onChangeText={(v) => set('versionCode', v)} keyboardType="number-pad" style={styles.field} /></View></SectionCard> : null}
      {tab === 'android' ? <><SectionCard title={copy.build} icon="hammer-outline"><View style={two ? styles.grid : null}><Field label={copy.min} value={form.minSdk} onChangeText={(v) => set('minSdk', v)} keyboardType="number-pad" style={styles.field} /><Field label={copy.target} value={form.targetSdk} onChangeText={(v) => set('targetSdk', v)} keyboardType="number-pad" style={styles.field} /><Field label={copy.compile} value={form.compileSdk} onChangeText={(v) => set('compileSdk', v)} keyboardType="number-pad" style={styles.field} /><Field label={copy.react} value={form.reactVersion} onChangeText={(v) => set('reactVersion', v)} style={styles.field} /><Field label={copy.vite} value={form.viteVersion} onChangeText={(v) => set('viteVersion', v)} style={styles.field} /></View><Text style={{color: colors.textSecondary, fontSize:11, marginTop:8, lineHeight:16}}>{language==='ru'? 'WebView обёртка использует минимальный Android SDK. UI собирается полностью на React, нативный WebView только загружает dist/index.html из assets.': 'WebView wrapper uses minimal Android SDK. UI is fully React, native WebView only loads dist/index.html from assets.'}</Text></SectionCard><SectionCard title={copy.signing} icon="key-outline"><Field label={copy.keystore} value={form.keystorePath} onChangeText={(v) => set('keystorePath', v)} autoCapitalize="none" /><Field label={copy.alias} value={form.keyAlias} onChangeText={(v) => set('keyAlias', v)} /><View style={two ? styles.grid : null}><Field label={copy.password} value={form.storePasswordEnv} onChangeText={(v) => set('storePasswordEnv', v)} style={styles.field} /><Field label={copy.keyPassword} value={form.keyPasswordEnv} onChangeText={(v) => set('keyPasswordEnv', v)} style={styles.field} /></View></SectionCard></> : null}
      {tab === 'theme' ? <SectionCard title={copy.theme} icon="color-palette-outline"><Toggle label={copy.dark} value={form.isDark} onChange={(v) => set('isDark', v)} colors={colors} styles={styles} /><ColorField label={copy.primary} value={form.primaryColor} onChange={(v) => set('primaryColor', v)} styles={styles} /><ColorField label={copy.secondary} value={form.secondaryColor} onChange={(v) => set('secondaryColor', v)} styles={styles} /><ColorField label={copy.background} value={form.backgroundColor} onChange={(v) => set('backgroundColor', v)} styles={styles} /><View style={[styles.preview, { backgroundColor: form.backgroundColor }]}><View style={[styles.previewBar, { backgroundColor: form.primaryColor }]}><Text style={styles.previewTitle}>{form.name}</Text></View><View style={[styles.previewButton, { backgroundColor: form.primaryColor }]} /><View style={[styles.previewAccent, { backgroundColor: form.secondaryColor }]} /></View></SectionCard> : null}
      {tab === 'variables' ? <SectionCard title={`${copy.variables} (${currentProject.variables?.length || 0})`} icon="code-working-outline"><View style={[styles.variableForm, !two && { flexDirection: 'column', alignItems: 'stretch' }]}><Field placeholder={copy.stateName} value={variable.name} onChangeText={(v) => setVariable((c) => ({ ...c, name: v }))} style={{ flex: 2 }} /><SegmentedControl value={variable.type} onChange={(v) => setVariable((c) => ({ ...c, type: v }))} options={[{ value: 'text', label: 'String' }, { value: 'number', label: 'Int' }, { value: 'boolean', label: 'Boolean' }]} /><Field placeholder="Initial value" value={variable.value} onChangeText={(v) => setVariable((c) => ({ ...c, value: v }))} style={{ flex: 1 }} /><PrimaryButton title={copy.add} icon="add" disabled={!variable.name.trim()} onPress={addVariable} /></View>{(currentProject.variables || []).map((item) => <View key={item.id} style={styles.variableRow}><View style={styles.variableIcon}><Icon name="code-slash-outline" size={16} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={styles.variableName}>{item.name}</Text><Text style={styles.variableMeta}>{item.type} · {String(item.value)}</Text></View><IconButton name="trash-outline" danger onPress={() => Alert.alert(copy.remove, '', [{ text: t('cancel') }, { text: t('delete'), style: 'destructive', onPress: () => dispatch({ type: 'DELETE_VARIABLE', payload: item.id }) }])} /></View>)}</SectionCard> : null}
    </View></ScrollView>
  </AppScreen>;
};

const Toggle = ({ label, value, onChange, colors, styles }) => <View style={styles.toggle}><Text style={styles.toggleText}>{label}</Text><Switch value={value} onValueChange={onChange} trackColor={{ false: colors.borderLight, true: colors.primary }} thumbColor="#FFFFFF" /></View>;
const ColorField = ({ label, value, onChange, styles }) => <View style={styles.colorRow}><View style={[styles.swatch, { backgroundColor: value }]} /><Field label={label} value={value} onChangeText={onChange} autoCapitalize="characters" style={{ flex: 1 }} /></View>;
const createStyles = (c) => StyleSheet.create({ center: { alignItems: 'center', justifyContent: 'center' }, muted: { color: c.textSecondary }, tabs: { padding: 8, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border }, page: { padding: 14, paddingBottom: 50 }, column: { width: '100%', maxWidth: 900, alignSelf: 'center', gap: 13 }, grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 }, field: { width: '48%', minWidth: 230, flexGrow: 1 }, toggle: { minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, toggleText: { color: c.text, fontSize: 13, fontWeight: '650' }, colorRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 9 }, swatch: { width: 46, height: 46, borderRadius: 10, borderWidth: 1, borderColor: c.borderLight }, preview: { height: 190, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: c.border, alignItems: 'center', gap: 13 }, previewBar: { width: '100%', height: 50, justifyContent: 'center', paddingHorizontal: 14 }, previewTitle: { color: '#FFFFFF', fontSize: 15, fontWeight: '700' }, previewButton: { width: 130, height: 38, borderRadius: 19 }, previewAccent: { width: 80, height: 8, borderRadius: 4 }, variableForm: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 }, variableRow: { minHeight: 58, paddingHorizontal: 10, borderRadius: 10, borderWidth: 1, borderColor: c.border, backgroundColor: c.bg, flexDirection: 'row', alignItems: 'center', gap: 10 }, variableIcon: { width: 34, height: 34, borderRadius: 9, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, variableName: { color: c.text, fontFamily: 'monospace', fontSize: 12, fontWeight: '700' }, variableMeta: { color: c.textSecondary, fontSize: 9, marginTop: 3 } });
export default ProjectSettingsScreen;
