import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AppState, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { AppScreen, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import {
  hasStorageAccess, openStorageSettings, requestStoragePermissions,
  hasNotificationPermission, requestNotificationPermission,
} from '../utils/background';
import { RAI_VERSION } from '../utils/raiSetup';

const AppSettingsScreen = ({ navigation }) => {
  const { colors, t, language, setLanguage, themeMode, setThemeMode, editor, setEditorSetting } = useAppSettings();
  const [storageGranted, setStorageGranted] = useState(false);
  const [notifGranted, setNotifGranted] = useState(true);
  const styles = useMemo(() => createStyles(colors), [colors]);

  const refreshPermissions = useCallback(async () => {
    setStorageGranted(await hasStorageAccess());
    setNotifGranted(await hasNotificationPermission());
  }, []);

  useEffect(() => { refreshPermissions(); }, [refreshPermissions]);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);

  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions, 600);
  };

  const grantNotif = async () => {
    const granted = await hasNotificationPermission();
    if (!granted) await requestNotificationPermission();
    setTimeout(refreshPermissions, 600);
  };

  return (
    <AppScreen>
      <TopBar title={t('settings')} subtitle={t('appSubtitle')} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.page}>
        <View style={styles.column}>
          <SectionCard title={t('appearance')} icon="color-palette-outline">
            <Text style={styles.label}>{t('theme')}</Text>
            <SegmentedControl
              value={themeMode}
              onChange={setThemeMode}
              options={[
                { value: 'system', label: t('system'), icon: 'phone-portrait-outline' },
                { value: 'light', label: t('light'), icon: 'sunny-outline' },
                { value: 'dark', label: t('dark'), icon: 'moon-outline' },
              ]}
            />
            <View style={styles.previewRow}>
              <View style={styles.previewWindow}>
                <View style={styles.previewBar} />
                <View style={styles.previewBody}>
                  <View style={styles.previewSide} />
                  <View style={{ flex: 1, gap: 7 }}><View style={styles.previewLine} /><View style={[styles.previewLine, { width: '62%' }]} /><View style={styles.previewButton} /></View>
                </View>
              </View>
              <Text style={styles.description}>
                {language === 'ru'
                  ? 'Контрастная палитра применяется ко всем экранам. Системные панели и заголовки остаются непрозрачными.'
                  : 'The high-contrast palette applies across the app. System bars and headers remain opaque.'}
              </Text>
            </View>
          </SectionCard>

          <SectionCard title={t('language')} icon="language-outline">
            <SegmentedControl
              value={language}
              onChange={setLanguage}
              options={[
                { value: 'ru', label: t('russian') },
                { value: 'en', label: t('english') },
              ]}
            />
            <Text style={styles.description}>
              {language === 'ru'
                ? 'Язык интерфейса сохраняется на устройстве и применяется сразу.'
                : 'The interface language is stored on this device and applied immediately.'}
            </Text>
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'Дизайн предпросмотр (двойная защита)' : 'Design Preview (double guard)'} icon="eye-outline">
            <View style={styles.toggleRow}>
              <View style={{flex:1}}>
                <Text style={styles.toggleTitle}>{language==='ru' ? 'Предпросмотр дизайна' : 'Design preview'}</Text>
                <Text style={styles.toggleDesc}>{language==='ru' ? 'Рендер дерева в вкладке Дизайн / Превью' : 'Render tree in Design / Preview tabs'}</Text>
              </View>
              <Switch value={editor.designPreview !== false} onValueChange={(v)=>setEditorSetting('designPreview', v)} trackColor={{false: colors.borderLight, true: colors.primary}} thumbColor="#FFFFFF" />
            </View>
            <View style={[styles.toggleRow, {opacity: editor.designPreview===false ? 0.4 : 1}]}>
              <View style={{flex:1}}>
                <Text style={styles.toggleTitle}>{language==='ru' ? 'Двойная защита' : 'Double guard'}</Text>
                <Text style={styles.toggleDesc}>{language==='ru' ? 'Требовать подтверждение при включении (второй выключатель)' : 'Require confirmation when enabling (second switch)'}</Text>
              </View>
              <Switch value={!!editor.designPreviewGuard} onValueChange={(v)=>setEditorSetting('designPreviewGuard', v)} disabled={editor.designPreview===false} trackColor={{false: colors.borderLight, true: colors.warning}} thumbColor="#FFFFFF" />
            </View>
            {!editor.designPreview ? (
              <View style={styles.guardNote}><Icon name="shield-outline" size={14} color={colors.warning} /><Text style={styles.guardText}>{language==='ru' ? 'Предпросмотр полностью выключен — Design/Preview покажут заглушку. Включите для рендера.' : 'Preview fully disabled — Design/Preview will show placeholder. Enable to render.'}</Text></View>
            ) : editor.designPreviewGuard ? (
              <View style={styles.guardNote}><Icon name="shield-checkmark-outline" size={14} color={colors.primary} /><Text style={styles.guardText}>{language==='ru' ? 'Двойная защита включена: предпросмотр потребует тап «Показать» при каждом открытии.' : 'Double guard on: preview will require tap "Show" on each open.'}</Text></View>
            ) : null}
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'Память и фон' : 'Storage & background'} icon="folder-open-outline">
            <View style={styles.toggleRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.toggleTitle}>{language === 'ru' ? 'Доступ к памяти' : 'Storage access'}</Text>
                <Text style={styles.toggleDesc}>{language === 'ru' ? 'All files access — сохранение APK в /sdcard/Download и общий доступ к файлам' : 'All files access — save APKs to /sdcard/Download and share files'}</Text>
              </View>
              {storageGranted ? (
                <Icon name="checkmark-circle" size={20} color={colors.success} />
              ) : (
                <Pressable onPress={grantStorage} style={[styles.smallBtn, { backgroundColor: colors.primary }]}>
                  <Text style={styles.smallBtnText}>{language === 'ru' ? 'Разрешить' : 'Grant'}</Text>
                </Pressable>
              )}
            </View>
            <View style={styles.toggleRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.toggleTitle}>{language === 'ru' ? 'Уведомления о фоновых задачах' : 'Background task notifications'}</Text>
                <Text style={styles.toggleDesc}>{language === 'ru' ? 'Статус установки/сборки, пока приложение свёрнуто' : 'Install/build status while the app is minimized'}</Text>
              </View>
              {notifGranted ? (
                <Icon name="checkmark-circle" size={20} color={colors.success} />
              ) : (
                <Pressable onPress={grantNotif} style={[styles.smallBtn, { backgroundColor: colors.primary }]}>
                  <Text style={styles.smallBtnText}>{language === 'ru' ? 'Разрешить' : 'Allow'}</Text>
                </Pressable>
              )}
            </View>
            <View style={styles.guardNote}>
              <Icon name="information-circle-outline" size={14} color={colors.info} />
              <Text style={styles.guardText}>{language === 'ru'
                ? 'Установка RAI и сборка APK продолжаются в фоне (foreground service). При закрытии приложения незавершённые шаги установки продолжатся при следующем запуске.'
                : 'RAI setup and APK builds keep running in the background (foreground service). If the app is closed, unfinished setup steps resume on the next launch.'}</Text>
            </View>
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'О приложении' : 'About'} icon="information-circle-outline">
            <View style={styles.infoRow}><Text style={styles.infoLabel}>React Studio</Text><Text style={styles.infoValue}>1.0.0</Text></View>
            <View style={styles.infoRow}><Text style={styles.infoLabel}>React</Text><Text style={styles.infoValue}>19.2.8</Text></View>
            <View style={styles.infoRow}><Text style={styles.infoLabel}>Vite</Text><Text style={styles.infoValue}>5.4.0</Text></View>
            <View style={styles.infoRow}><Text style={styles.infoLabel}>Android SDK</Text><Text style={styles.infoValue}>API 37</Text></View>
            <View style={styles.infoRow}><Text style={styles.infoLabel}>SDK</Text><Text style={styles.infoValue}>37.0.0 (обязателен)</Text></View>
            <View style={styles.infoRow}><Text style={styles.infoLabel}>RAI</Text><Text style={styles.infoValue}>v{RAI_VERSION} (локально)</Text></View>
          </SectionCard>
        </View>
      </ScrollView>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  page: { padding: 16, paddingBottom: 40 },
  column: { width: '100%', maxWidth: 760, alignSelf: 'center', gap: 14 },
  label: { color: c.textSecondary, fontSize: 12, fontWeight: '650', marginBottom: -5 },
  description: { color: c.textSecondary, fontSize: 12, lineHeight: 18, flex: 1 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: c.borderLight },
  toggleTitle: { color: c.text, fontSize: 13, fontWeight: '700' },
  toggleDesc: { color: c.textSecondary, fontSize: 11, marginTop: 2, lineHeight: 14 },
  guardNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 10, borderRadius: 8, backgroundColor: c.bgElevated, marginTop: 4 },
  guardText: { flex: 1, color: c.textSecondary, fontSize: 11, lineHeight: 14 },
  smallBtn: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 8 },
  smallBtnText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  previewRow: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  previewWindow: { width: 140, height: 88, borderRadius: 9, overflow: 'hidden', borderWidth: 1, borderColor: c.borderLight, backgroundColor: c.bg },
  previewBar: { height: 18, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  previewBody: { flex: 1, flexDirection: 'row', padding: 8, gap: 8 },
  previewSide: { width: 25, borderRadius: 4, backgroundColor: c.bgElevated },
  previewLine: { height: 7, borderRadius: 3, backgroundColor: c.borderLight, width: '88%' },
  previewButton: { height: 15, borderRadius: 4, backgroundColor: c.primary, width: 42, marginTop: 3 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  infoLabel: { color: c.textSecondary, fontSize: 13 },
  infoValue: { color: c.text, fontSize: 13, fontWeight: '650', fontFamily: 'monospace' },
});

export default AppSettingsScreen;
