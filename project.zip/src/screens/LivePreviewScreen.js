import React from 'react';
import { AppScreen, TopBar } from '../components/AppUI';
import ComposePreviewPanel from '../components/ComposePreviewPanel';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';

const LivePreviewScreen = ({ navigation }) => {
  const { currentProject, getCurrentScreen } = useProject();
  const { language } = useAppSettings();
  const screen = getCurrentScreen();
  return (
    <AppScreen>
      <TopBar
        title={language === 'ru' ? 'Живой Android preview' : 'Live Android preview'}
        subtitle={`${currentProject?.name || ''} · ${screen?.name || ''} · auto refresh`}
        onBack={() => navigation.goBack()}
      />
      <ComposePreviewPanel
        onOpenFullscreen={() => {}}
        onOpenBuild={() => navigation.navigate('Build', { task: 'assembleDebug' })}
      />
    </AppScreen>
  );
};

export default LivePreviewScreen;