import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Switch, Alert, Dimensions, StatusBar, BackHandler,
} from 'react-native';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import colors from '../theme/colors';

const { width: W, height: H } = Dimensions.get('window');
const isTablet = W >= 768;

/**
 * LivePreviewScreen — запуск сгенерированного приложения
 * Работает как настоящее приложение — полноэкранно, без рамок.
 */
const LivePreviewScreen = ({ navigation }) => {
  const { currentProject, currentScreenId } = useProject();
  const [activeScreenId, setActiveScreenId] = useState(currentScreenId);
  const [screenStack, setScreenStack] = useState([currentScreenId]);
  const [showMenu, setShowMenu] = useState(false);

  const activeScreen = currentProject?.screens?.find(s => s.id === activeScreenId);

  // Back handler
  useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screenStack.length > 1) {
        const newStack = [...screenStack];
        newStack.pop();
        setScreenStack(newStack);
        setActiveScreenId(newStack[newStack.length - 1]);
        return true;
      }
      navigation.goBack();
      return true;
    });
    return () => handler.remove();
  }, [screenStack, navigation]);

  const navigateTo = useCallback((screenName) => {
    const target = currentProject?.screens?.find(s => s.name === screenName);
    if (target) {
      setScreenStack(prev => [...prev, target.id]);
      setActiveScreenId(target.id);
    }
  }, [currentProject]);

  const goBack = useCallback(() => {
    if (screenStack.length > 1) {
      const newStack = [...screenStack];
      newStack.pop();
      setScreenStack(newStack);
      setActiveScreenId(newStack[newStack.length - 1]);
    } else {
      navigation.goBack();
    }
  }, [screenStack, navigation]);

  // Execute onCreate blocks
  useEffect(() => {
    if (!activeScreen) return;
    const blocks = activeScreen.blocks || [];
    const onCreate = blocks.find(b => b.definitionId === 'on_create');
    if (onCreate?.children?.next) {
      onCreate.children.next.forEach(action => {
        if (action.definitionId === 'show_toast') {
          setTimeout(() => Alert.alert(activeScreen.name, action.inputs?.text || ''), 200);
        }
      });
    }
  }, [activeScreenId]);

  if (!currentProject || !activeScreen) {
    return (
      <View style={st.container}>
        <Text style={st.emptyText}>Нет экранов</Text>
      </View>
    );
  }

  const bgColor = activeScreen.backgroundColor || currentProject.theme?.backgroundColor || colors.bg;
  const primaryColor = currentProject.theme?.primaryColor || colors.primary;

  // ─── Render component as REAL widget ───
  const renderComp = (comp, depth = 0) => {
    if (!comp) return null;
    const p = comp.props || {};

    switch (comp.type) {
      case 'LinearLayout':
        return (
          <View key={comp.id} style={{
            flexDirection: p.orientation === 'horizontal' ? 'row' : 'column',
            padding: p.padding || 0,
            backgroundColor: p.backgroundColor !== 'transparent' ? p.backgroundColor : undefined,
            borderRadius: p.borderRadius || 0,
            width: p.width === 'match_parent' ? '100%' : p.width,
            justifyContent: p.gravity === 'center' ? 'center' : undefined,
            alignItems: p.gravity === 'center' ? 'center' : p.gravity === 'right' ? 'flex-end' : undefined,
          }}>
            {(comp.children || []).map(c => renderComp(c, depth + 1))}
          </View>
        );

      case 'ScrollView':
        return (
          <ScrollView key={comp.id} style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
            {(comp.children || []).map(c => renderComp(c, depth + 1))}
          </ScrollView>
        );

      case 'CardView':
        return (
          <View key={comp.id} style={{
            backgroundColor: p.backgroundColor || colors.bgElevated,
            borderRadius: p.borderRadius || 14,
            padding: p.padding || 16,
            marginVertical: 6,
            shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 6, elevation: p.elevation || 3,
          }}>
            {(comp.children || []).map(c => renderComp(c, depth + 1))}
          </View>
        );

      case 'TextView':
        return (
          <Text key={comp.id} style={{
            fontSize: p.textSize || 16,
            color: p.textColor || colors.text,
            fontWeight: p.textStyle === 'bold' ? 'bold' : p.textStyle === 'italic' ? 'normal' : 'normal',
            fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal',
            textAlign: p.gravity || 'left',
            padding: p.padding || 0,
            width: p.width === 'match_parent' ? '100%' : undefined,
          }}>
            {p.text || ''}
          </Text>
        );

      case 'Button':
        return (
          <TouchableOpacity key={comp.id} activeOpacity={0.7} style={{
            backgroundColor: p.backgroundColor || primaryColor,
            paddingVertical: p.padding || 14,
            paddingHorizontal: (p.padding || 14) * 2,
            borderRadius: p.borderRadius || 10,
            alignItems: 'center',
            marginVertical: 6,
            width: p.width === 'match_parent' ? '100%' : undefined,
          }} onPress={() => Alert.alert(p.text || 'Button', 'Нажато!')}>
            <Text style={{ color: p.textColor || '#fff', fontSize: p.textSize || 16, fontWeight: '700' }}>
              {p.text || 'Button'}
            </Text>
          </TouchableOpacity>
        );

      case 'EditText':
        return (
          <TextInput key={comp.id} style={{
            backgroundColor: p.backgroundColor || colors.bgInput,
            padding: p.padding || 14,
            borderRadius: p.borderRadius || 10,
            color: p.textColor || colors.text,
            fontSize: p.textSize || 16,
            marginVertical: 6,
            borderWidth: 1,
            borderColor: colors.border,
            width: p.width === 'match_parent' ? '100%' : undefined,
          }} placeholder={p.hint || ''} placeholderTextColor={colors.textTertiary} />
        );

      case 'ImageView':
        return (
          <View key={comp.id} style={{
            width: typeof p.width === 'number' ? p.width : 120,
            height: typeof p.height === 'number' ? p.height : 120,
            backgroundColor: p.backgroundColor || colors.bgElevated,
            borderRadius: p.borderRadius || 10,
            justifyContent: 'center', alignItems: 'center', marginVertical: 6,
          }}>
            <Icon name="image-outline" size={36} color={colors.textTertiary} />
          </View>
        );

      case 'CheckBox':
        return (
          <View key={comp.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }}>
            <View style={{
              width: 22, height: 22, borderWidth: 2, borderColor: primaryColor,
              borderRadius: 5, backgroundColor: p.checked ? primaryColor : 'transparent',
            }} />
            <Text style={{ color: p.textColor || colors.text, fontSize: p.textSize || 16, marginLeft: 10 }}>
              {p.text || 'CheckBox'}
            </Text>
          </View>
        );

      case 'Switch':
        return (
          <View key={comp.id} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 }}>
            <Text style={{ color: colors.text, fontSize: 16 }}>{p.text || 'Switch'}</Text>
            <Switch value={p.checked || false} trackColor={{ true: primaryColor }} />
          </View>
        );

      case 'ProgressBar':
        return (
          <View key={comp.id} style={{
            height: 8, backgroundColor: colors.bgElevated, borderRadius: 4, overflow: 'hidden', marginVertical: 10,
            width: p.width === 'match_parent' ? '100%' : undefined,
          }}>
            <View style={{ height: '100%', width: `${p.progress || 50}%`, backgroundColor: p.color || primaryColor, borderRadius: 4 }} />
          </View>
        );

      case 'Divider':
        return <View key={comp.id} style={{ height: p.height || 1, backgroundColor: p.backgroundColor || colors.border, marginVertical: p.margin || 10 }} />;

      case 'Spacer':
        return <View key={comp.id} style={{ height: p.height || 16 }} />;

      default:
        return <View key={comp.id} style={{ padding: 8, backgroundColor: colors.bgElevated, borderRadius: 6, marginVertical: 2 }}><Text style={{ color: colors.text }}>{comp.type}</Text></View>;
    }
  };

  return (
    <View style={[st.container, { backgroundColor: bgColor }]}>
      <StatusBar barStyle={activeScreen.statusBarColor === '#FFFFFF' || bgColor > '#888' ? 'dark-content' : 'light-content'} backgroundColor={bgColor} />

      {/* Action bar */}
      {activeScreen.showActionBar && (
        <View style={[st.actionBar, { backgroundColor: primaryColor }]}>
          <TouchableOpacity style={st.actionBtn} onPress={goBack}>
            <Icon name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <Text style={st.actionTitle} numberOfLines={1}>
            {activeScreen.actionBarTitle || activeScreen.name}
          </Text>
          <TouchableOpacity style={st.actionBtn} onPress={() => setShowMenu(!showMenu)}>
            <Icon name="ellipsis-vertical" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      )}

      {/* Menu overlay */}
      {showMenu && (
        <TouchableOpacity style={st.menuOverlay} activeOpacity={1} onPress={() => setShowMenu(false)}>
          <View style={st.menuDropdown}>
            {currentProject.screens.filter(s => s.id !== activeScreenId).map(sc => (
              <TouchableOpacity key={sc.id} style={st.menuItem} onPress={() => { navigateTo(sc.name); setShowMenu(false); }}>
                <Icon name="phone-portrait-outline" size={16} color={colors.textSecondary} />
                <Text style={st.menuItemText}>Перейти: {sc.name}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={[st.menuItem, st.menuItemLast]} onPress={() => { setShowMenu(false); navigation.goBack(); }}>
              <Icon name="close-circle-outline" size={16} color={colors.error} />
              <Text style={[st.menuItemText, { color: colors.error }]}>Выйти из предпросмотра</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      )}

      {/* App content — full screen */}
      <ScrollView
        style={st.content}
        contentContainerStyle={[st.contentInner, { padding: activeScreen.rootComponent?.props?.padding || 16 }]}
        showsVerticalScrollIndicator={false}
      >
        {renderComp(activeScreen.rootComponent)}
      </ScrollView>

      {/* Exit button (floating) */}
      <TouchableOpacity style={st.exitBtn} onPress={() => navigation.goBack()}>
        <Icon name="close" size={18} color="#fff" />
      </TouchableOpacity>
    </View>
  );
};

const st = StyleSheet.create({
  container: { flex: 1 },
  emptyText: { color: colors.textSecondary, fontSize: 16, textAlign: 'center', marginTop: 100 },

  actionBar: {
    flexDirection: 'row', alignItems: 'center',
    paddingTop: 44, paddingHorizontal: 8, paddingBottom: 10,
  },
  actionBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center', borderRadius: 20 },
  actionTitle: { flex: 1, color: '#fff', fontSize: 18, fontWeight: '700', marginHorizontal: 4 },

  content: { flex: 1 },
  contentInner: {
    maxWidth: isTablet ? 700 : undefined,
    alignSelf: isTablet ? 'center' : undefined,
    width: '100%',
  },

  exitBtn: {
    position: 'absolute', bottom: 24, right: 24,
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 6,
  },

  menuOverlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.3)', zIndex: 100,
    paddingTop: 96, paddingRight: 12,
  },
  menuDropdown: {
    backgroundColor: colors.bgCard, borderRadius: 14, padding: 6,
    borderWidth: 1, borderColor: colors.border, alignSelf: 'flex-end',
    minWidth: 200,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8,
  },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    padding: 12, borderRadius: 8,
  },
  menuItemLast: { borderTopWidth: 1, borderTopColor: colors.border, marginTop: 4, paddingTop: 14 },
  menuItemText: { fontSize: 14, color: colors.text },
});

export default LivePreviewScreen;
