import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';

export const RuntimeWidget = ({ component, colors, primary }) => {
  const p = component.props || {};
  const children = (component.children || []).map((child) => <RuntimeWidget key={child.id} component={child} colors={colors} primary={primary} />);
  switch (component.type) {
    case 'LinearLayout': return <View style={{ flexDirection: p.orientation === 'horizontal' ? 'row' : 'column', padding: p.padding || 0, gap: 4, backgroundColor: p.backgroundColor === 'transparent' ? undefined : p.backgroundColor, width: p.width === 'match_parent' ? '100%' : p.width }}>{children}</View>;
    case 'ScrollView': return <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: p.padding || 0 }}>{children}</ScrollView>;
    case 'CardView': return <View style={{ padding: p.padding || 14, borderRadius: p.borderRadius || 12, backgroundColor: p.backgroundColor || '#FFFFFF', borderWidth: 1, borderColor: '#E2E8F0', marginVertical: 5 }}>{children}</View>;
    case 'TextView': return <Text style={{ padding: p.padding || 0, fontSize: Number(p.textSize) || 16, color: p.textColor || '#111827', fontWeight: p.textStyle === 'bold' ? '700' : '400', fontStyle: p.textStyle === 'italic' ? 'italic' : 'normal', textAlign: p.gravity || 'left', width: p.width === 'match_parent' ? '100%' : undefined }}>{p.text}</Text>;
    case 'Button': return <Pressable onPress={() => Alert.alert(p.text || 'Button')} style={({ pressed }) => ({ padding: p.padding || 13, borderRadius: p.borderRadius || 9, backgroundColor: p.backgroundColor || primary, alignItems: 'center', marginVertical: 5, opacity: pressed ? 0.78 : 1, width: p.width === 'match_parent' ? '100%' : undefined })}><Text style={{ color: p.textColor || '#FFFFFF', fontSize: Number(p.textSize) || 15, fontWeight: '700' }}>{p.text || 'Button'}</Text></Pressable>;
    case 'EditText': return <TextInput defaultValue={p.text} placeholder={p.hint} placeholderTextColor="#64748B" style={{ minHeight: 44, borderRadius: p.borderRadius || 9, borderWidth: 1, borderColor: '#CBD5E1', backgroundColor: p.backgroundColor || '#FFFFFF', color: p.textColor || '#111827', padding: p.padding || 12, marginVertical: 5, width: p.width === 'match_parent' ? '100%' : undefined }} />;
    case 'ImageView': return <View style={{ width: Number(p.width) || 110, height: Number(p.height) || 110, borderRadius: p.borderRadius || 8, backgroundColor: p.backgroundColor || '#E2E8F0', alignItems: 'center', justifyContent: 'center' }}><Icon name="image-outline" size={34} color="#64748B" /></View>;
    case 'CheckBox': return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 40 }}><Icon name={p.checked ? 'checkbox' : 'square-outline'} size={22} color={primary} /><Text style={{ color: p.textColor || '#111827' }}>{p.text}</Text></View>;
    case 'Switch': return <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 42 }}><Text style={{ color: p.textColor || '#111827' }}>{p.text}</Text><Switch value={Boolean(p.checked)} trackColor={{ false: '#CBD5E1', true: primary }} /></View>;
    case 'ProgressBar': return <View style={{ height: 8, borderRadius: 4, backgroundColor: '#E2E8F0', overflow: 'hidden', marginVertical: 8 }}><View style={{ height: '100%', width: `${p.progress || 0}%`, backgroundColor: p.color || primary }} /></View>;
    case 'Divider': return <View style={{ height: p.height || 1, backgroundColor: p.backgroundColor || '#CBD5E1', marginVertical: p.margin || 8 }} />;
    case 'Spacer': return <View style={{ height: p.height || 16 }} />;
    case 'WebView': return <View style={{ minHeight: Number(p.height) || 180, backgroundColor: '#E8F1F5', alignItems: 'center', justifyContent: 'center', borderRadius: 8 }}><Icon name="globe-outline" size={30} color="#0E7490" /><Text style={{ color: '#334155', marginTop: 6 }}>{p.url}</Text></View>;
    case 'MapView': return <View style={{ minHeight: Number(p.height) || 180, backgroundColor: '#E8F3EE', alignItems: 'center', justifyContent: 'center', borderRadius: 8 }}><Icon name="map-outline" size={30} color="#047857" /><Text style={{ color: '#334155', marginTop: 6 }}>{p.latitude}, {p.longitude}</Text></View>;
    default: return <View style={{ padding: 8 }}><Text style={{ color: colors.textSecondary }}>{component.type}</Text></View>;
  }
};

const LivePreviewScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { currentProject, currentScreenId, setCurrentScreen } = useProject();
  const { colors, language, t } = useAppSettings();
  const [mode, setMode] = useState('runtime');
  const [serverState, setServerState] = useState('stopped');
  const [serverLog, setServerLog] = useState('');
  const [devUrl, setDevUrl] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const screen = currentProject?.screens?.find((item) => item.id === currentScreenId) || currentProject?.screens?.[0];
  const copy = language === 'ru' ? {
    title: 'Предпросмотр', local: 'Интерактивный', dev: 'Dev Client',
    localHint: 'Быстрый интерактивный рендер интерфейса конструктора.',
    devTitle: 'Настоящий Expo development client', devText: 'Metro запускается внутри Ubuntu командой npx expo start --dev-client. Откройте ссылку или отсканируйте QR-код в development build созданного приложения.',
    start: 'Запустить Metro', stop: 'Остановить', refresh: 'Обновить журнал', stopped: 'Остановлен', running: 'Работает', starting: 'Запуск',
    installHint: 'Перед первым запуском будет установлен expo-dev-client.', open: 'Открыть Dev Client', noUrl: 'Metro запускается. Обновите журнал через несколько секунд.',
  } : {
    title: 'Preview', local: 'Interactive', dev: 'Dev Client',
    localHint: 'Fast interactive rendering of the builder UI.',
    devTitle: 'Real Expo development client', devText: 'Metro runs inside Ubuntu with npx expo start --dev-client. Open the URL or scan the QR code using the generated app development build.',
    start: 'Start Metro', stop: 'Stop', refresh: 'Refresh log', stopped: 'Stopped', running: 'Running', starting: 'Starting',
    installHint: 'expo-dev-client will be installed before the first run.', open: 'Open Dev Client', noUrl: 'Metro is starting. Refresh the log in a few seconds.',
  };

  const refreshLog = useCallback(async () => {
    if (!currentProject) return;
    const result = await execute('cat .rn-studio/metro.log 2>/dev/null || true', getProjectDir(currentProject));
    const output = result.output || '';
    setServerLog(output);
    const urls = output.match(/(?:exp\+[a-z0-9+.-]+:\/\/[^\s]+|https?:\/\/[^\s]+|exp:\/\/[^\s]+)/gi);
    if (urls?.length) setDevUrl(urls[urls.length - 1].replace(/[),.;]+$/, ''));
  }, [currentProject?.id]);

  useEffect(() => {
    if (serverState !== 'running') return undefined;
    const timer = setInterval(refreshLog, 2200);
    return () => clearInterval(timer);
  }, [serverState, refreshLog]);

  const start = async () => {
    setServerState('starting');
    setServerLog('');
    setDevUrl('');
    const cwd = getProjectDir(currentProject);
    try {
      const install = await execute('npx expo install expo-dev-client 2>&1', cwd);
      if (!install.success) throw new Error(install.output || 'expo-dev-client installation failed');
      await execute('mkdir -p .rn-studio; if [ -f .rn-studio/metro.pid ]; then kill $(cat .rn-studio/metro.pid) 2>/dev/null || true; fi; (CI=1 npx expo start --dev-client --port 8081 > .rn-studio/metro.log 2>&1 & echo $! > .rn-studio/metro.pid)', cwd);
      setServerState('running');
      setTimeout(refreshLog, 1800);
    } catch (e) {
      setServerLog(e?.message || String(e));
      setServerState('error');
    }
  };

  const stop = async () => {
    await execute('if [ -f .rn-studio/metro.pid ]; then kill $(cat .rn-studio/metro.pid) 2>/dev/null || true; rm -f .rn-studio/metro.pid; fi', getProjectDir(currentProject));
    setServerState('stopped');
  };

  if (!currentProject || !screen) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View style={styles.empty}><Text style={styles.muted}>No project</Text></View></AppScreen>;
  const primary = currentProject.theme?.primaryColor || '#4F46E5';

  return (
    <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${screen.name}`} onBack={() => navigation.goBack()} right={<IconButton name="build-outline" label={width >= 720 ? t('build') : null} onPress={() => navigation.navigate('Build', { profile: 'development' })} />} />
      <View style={styles.modeBar}>
        <SegmentedControl value={mode} onChange={setMode} options={[{ value: 'runtime', label: copy.local, icon: 'play-outline' }, { value: 'dev', label: copy.dev, icon: 'phone-portrait-outline' }]} />
        {mode === 'runtime' ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.screenTabs}>{currentProject.screens.map((item) => <Pressable key={item.id} onPress={() => setCurrentScreen(item.id)} style={[styles.screenTab, item.id === screen.id && styles.screenTabActive]}><Icon name="phone-portrait-outline" size={13} color={item.id === screen.id ? colors.primary : colors.textSecondary} /><Text style={[styles.screenTabText, item.id === screen.id && { color: colors.primary }]}>{item.name}</Text></Pressable>)}</ScrollView> : null}
      </View>

      {mode === 'runtime' ? (
        <ScrollView style={styles.runtimeArea} contentContainerStyle={styles.runtimeContent}>
          <Text style={styles.hint}>{copy.localHint}</Text>
          <View style={styles.device}>
            <View style={styles.statusBar}><Text style={styles.statusText}>9:41</Text><View style={{ flexDirection: 'row', gap: 5 }}><Icon name="cellular" size={12} color="#111827" /><Icon name="wifi" size={12} color="#111827" /><Icon name="battery-full" size={14} color="#111827" /></View></View>
            {screen.showActionBar ? <View style={[styles.appBar, { backgroundColor: primary }]}><Icon name="arrow-back" size={20} color="#FFFFFF" /><Text style={styles.appTitle}>{screen.actionBarTitle || screen.name}</Text><Icon name="ellipsis-vertical" size={18} color="#FFFFFF" /></View> : null}
            <ScrollView style={[styles.appBody, { backgroundColor: screen.backgroundColor || currentProject.theme?.backgroundColor || '#F8FAFC' }]} contentContainerStyle={{ padding: screen.rootComponent?.props?.padding || 8 }}><RuntimeWidget component={screen.rootComponent} colors={colors} primary={primary} /></ScrollView>
            <View style={styles.navBar}><View style={styles.navGesture} /></View>
          </View>
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={styles.devPage}>
          <View style={styles.devColumn}>
            <SectionCard title={copy.devTitle} icon="phone-portrait-outline" right={<StatusPill label={serverState === 'running' ? copy.running : serverState === 'starting' ? copy.starting : copy.stopped} tone={serverState === 'running' ? 'success' : serverState === 'error' ? 'error' : 'neutral'} />}>
              <Text style={styles.devText}>{copy.devText}</Text>
              <View style={styles.command}><Text selectable style={styles.commandText}>$ npx expo start --dev-client --port 8081</Text></View>
              <Text style={styles.devHint}>{copy.installHint}</Text>
              <View style={styles.buttonRow}>{serverState === 'running' ? <PrimaryButton title={copy.stop} icon="stop-outline" destructive onPress={stop} style={{ flex: 1 }} /> : <PrimaryButton title={copy.start} icon="play-outline" loading={serverState === 'starting'} onPress={start} style={{ flex: 1 }} />}<IconButton name="refresh-outline" label={copy.refresh} onPress={refreshLog} style={{ flex: 1 }} /></View>
            </SectionCard>
            {devUrl ? <SectionCard title="Development URL" icon="qr-code-outline"><View style={styles.qr}><QRCode value={devUrl} size={170} /></View><Text selectable style={styles.url}>{devUrl}</Text><PrimaryButton title={copy.open} icon="open-outline" onPress={() => Linking.openURL(devUrl)} /></SectionCard> : serverState === 'running' ? <Text style={styles.hint}>{copy.noUrl}</Text> : null}
            <SectionCard title="Metro output" icon="terminal-outline"><ScrollView style={styles.log} nestedScrollEnabled><Text selectable style={styles.logText}>{serverLog || '$ Metro output will appear here'}</Text></ScrollView></SectionCard>
          </View>
        </ScrollView>
      )}
    </AppScreen>
  );
};

const QRCode = ({ value, size }) => {
  try { const QR = require('react-native-qrcode-svg').default; return <QR value={value} size={size} backgroundColor="#FFFFFF" color="#111827" />; }
  catch (e) { return <Icon name="qr-code-outline" size={size / 2} color="#111827" />; }
};

const createStyles = (c) => StyleSheet.create({
  modeBar: { minHeight: 53, flexDirection: 'row', alignItems: 'center', gap: 10, padding: 7, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  screenTabs: { alignItems: 'center', gap: 5 }, screenTab: { minHeight: 36, paddingHorizontal: 10, borderRadius: 8, flexDirection: 'row', alignItems: 'center', gap: 5 }, screenTabActive: { backgroundColor: c.primarySurface }, screenTabText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' },
  runtimeArea: { flex: 1, backgroundColor: c.canvas }, runtimeContent: { minHeight: 760, alignItems: 'center', padding: 18 }, hint: { color: c.textSecondary, fontSize: 10, textAlign: 'center', marginBottom: 12 },
  device: { width: '100%', maxWidth: 390, height: 700, borderRadius: 30, borderWidth: 7, borderColor: '#111827', overflow: 'hidden', backgroundColor: '#FFFFFF', shadowColor: c.shadow, shadowOpacity: 0.25, shadowRadius: 14, elevation: 10 },
  statusBar: { height: 29, paddingHorizontal: 15, backgroundColor: '#FFFFFF', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, statusText: { color: '#111827', fontSize: 10, fontWeight: '750' },
  appBar: { height: 52, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 13 }, appTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '700', flex: 1 }, appBody: { flex: 1 }, navBar: { height: 30, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' }, navGesture: { width: 105, height: 4, borderRadius: 2, backgroundColor: '#111827' },
  devPage: { padding: 14, paddingBottom: 50 }, devColumn: { width: '100%', maxWidth: 760, alignSelf: 'center', gap: 12 }, devText: { color: c.textSecondary, fontSize: 12, lineHeight: 19 }, devHint: { color: c.textTertiary, fontSize: 10 },
  command: { padding: 12, borderRadius: 9, backgroundColor: c.terminal }, commandText: { color: '#D9E2F1', fontFamily: 'monospace', fontSize: 10 }, buttonRow: { flexDirection: 'row', gap: 8 },
  qr: { alignSelf: 'center', padding: 12, borderRadius: 10, backgroundColor: '#FFFFFF' }, url: { color: c.info, fontFamily: 'monospace', fontSize: 10, lineHeight: 16, textAlign: 'center' },
  log: { maxHeight: 260, borderRadius: 9, backgroundColor: c.terminal, padding: 11 }, logText: { color: '#B9C5D8', fontFamily: 'monospace', fontSize: 9, lineHeight: 15 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' }, muted: { color: c.textSecondary },
});

export default LivePreviewScreen;
