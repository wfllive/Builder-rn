import React from 'react';
import { AppScreen, TopBar } from '../components/AppUI';
import ComposePreviewPanel from '../components/ComposePreviewPanel';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';

const LivePreviewScreen = ({ navigation }) => {
  const { currentProject, getCurrentScreen } = useProject();
  const { language } = useAppSettings();
  const screen = getCurrentScreen();
  return (
    <AppScreen>
      <TopBar
        title={language === 'ru' ? 'Предпросмотр Jetpack Compose' : 'Jetpack Compose preview'}
        subtitle={`${currentProject?.name || ''} · ${screen?.name || ''} · @Preview`}
        onBack={() => navigation.goBack()}
      />
      <ComposePreviewPanel
        onOpenFullscreen={() => {}}
        onOpenBuild={() => navigation.navigate('Build', { task: 'assembleDebug' })}
      />
    </AppScreen>
  );
};

export default LivePreviewScreen;
