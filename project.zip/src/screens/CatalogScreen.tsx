/**
 * Каталог дистрибутивов с кнопкой "Установить" — скачивает и распаковывает
 */
import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  TextInput,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { theme } from '../utils/theme';
import { DISTROS, DistroInfo } from '../data/distros';
import { useTerminal } from '../store/terminal';
import { Card, EmptyState } from '../components/TerminalView';

export default function CatalogScreen() {
  const { installedDistros, installDistro, installProgress, refreshInstalled, setup, initialized } =
    useTerminal();
  const [query, setQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { setup(); }, [setup]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refreshInstalled();
    setRefreshing(false);
  }, [refreshInstalled]);

  const installedIds = new Set(installedDistros.map((d) => d.id));

  const list = DISTROS.filter((d) => {
    if (query.trim()) {
      const q = query.toLowerCase();
      return d.name.toLowerCase().includes(q) || d.description.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <View style={styles.root}>
      <View style={styles.searchBox}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          value={query}
          onChangeText={setQuery}
          placeholder="поиск…"
          placeholderTextColor={theme.textMuted}
        />
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />
        }
      >
        {installProgress && (
          <Card style={[styles.card, { borderColor: theme.accent }]}>
            <Text style={styles.installTitle}>
              {installProgress.distroId} — {installProgress.message}
            </Text>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${installProgress.percent}%` },
                ]}
              />
            </View>
            <Text style={styles.percentText}>{installProgress.percent}%</Text>
          </Card>
        )}

        {list.length === 0 ? (
          <EmptyState icon="🪺" title="Ничего не найдено" />
        ) : (
          list.map((d) => (
            <DistroCard
              key={d.id}
              d={d}
              installed={installedIds.has(d.id)}
              onInstall={() => installDistro(d)}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

function DistroCard({
  d, installed, onInstall,
}: { d: DistroInfo; installed: boolean; onInstall: () => void }) {
  const { installProgress } = useTerminal();
  const busy = installProgress?.distroId === d.id && installProgress.percent < 100;

  return (
    <Card style={styles.card}>
      <View style={styles.row}>
        <Text style={styles.icon}>{d.iconEmoji}</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{d.name}</Text>
          <Text style={styles.meta}>
            {d.version ?? d.family} · {d.sizeMB} МБ
          </Text>
        </View>
      </View>
      <Text style={styles.desc}>{d.description}</Text>

      {installed ? (
        <View style={[styles.btn, { backgroundColor: theme.bgInput, borderColor: theme.success }]}>
          <Text style={[styles.btnText, { color: theme.success }]}>✓ Установлено</Text>
        </View>
      ) : (
        <Pressable
          onPress={onInstall}
          disabled={busy}
          style={({ pressed }) => [
            styles.btn,
            {
              backgroundColor: busy ? theme.bgInput : theme.primary,
              opacity: pressed ? 0.7 : 1,
            },
          ]}
        >
          {busy ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <ActivityIndicator color={theme.bg} size="small" />
              <Text style={styles.btnText}>{installProgress?.percent ?? 0}%</Text>
            </View>
          ) : (
            <Text style={styles.btnText}>⬇ Установить</Text>
          )}
        </Pressable>
      )}
    </Card>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.bg },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.bgCard,
    margin: 16,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: theme.border,
    paddingHorizontal: 12,
  },
  searchIcon: { fontSize: 14, marginRight: 8 },
  searchInput: {
    flex: 1,
    color: theme.text,
    fontFamily: theme.font.mono,
    fontSize: 14,
    paddingVertical: 10,
  },
  card: { marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8 },
  icon: { fontSize: 32 },
  name: { color: theme.text, fontFamily: theme.font.mono, fontSize: 16, fontWeight: '700' },
  meta: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 11, marginTop: 2 },
  desc: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 12, lineHeight: 17, marginBottom: 12 },
  btn: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  btnText: { color: theme.bg, fontFamily: theme.font.mono, fontWeight: '700', fontSize: 14 },
  installTitle: {
    color: theme.accent,
    fontFamily: theme.font.mono,
    fontSize: 12,
    marginBottom: 8,
  },
  progressBar: {
    height: 6,
    backgroundColor: theme.bgInput,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: theme.primary,
  },
  percentText: {
    color: theme.textDim,
    fontFamily: theme.font.mono,
    fontSize: 11,
    marginTop: 4,
    textAlign: 'right',
  },
});
