import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { AppScreen, IconButton, PrimaryButton, SectionCard, StatusPill, TopBar } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { TerminalView } from '../../modules/termux-terminal/src/index';
import AdsBanner from '../components/AdsBanner';
import { installApk } from '../../modules/apt-manager/src/index';

const EXTRA_KEYS = '[]';

/**
 * Экран быстрой NCS сборки для Java + XML проектов
 * Сборка debug/release APK за 2-8 секунд
 */
const NcsBuildScreen = ({ navigation, route }) => {
  const { projectPath, projectName = 'Project' } = route?.params || {};
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const { colors, language } = useAppSettings();
  const ru = language === 'ru';

  const [variant, setVariant] = useState<'debug' | 'release'>('debug');
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [buildResult, setBuildResult] = useState<'idle' | 'success' | 'error'>('idle');
  const [apkPath, setApkPath] = useState<string | null>(null);
  const [buildTime, setBuildTime] = useState<number>(0);
  const [fontSize, setFontSize] = useState(14);
  const scrollRef = useRef<ScrollView>(null);
  const terminalRef = useRef<any>(null);

  const styles = useMemo(() => createStyles(colors), [colors]);
  const narrow = width < 560;

  const copy = {
    title: ru ? 'Быстрая NCS сборка' : 'NCS Fast Build',
    subtitle: ru ? 'Java + XML без Gradle' : 'Java + XML without Gradle',
    debug: 'Debug',
    release: 'Release',
    build: ru ? 'Собрать APK' : 'Build APK',
    building: ru ? 'Сборка...' : 'Building...',
    install: ru ? 'Установить' : 'Install',
    run: ru ? 'Запустить' : 'Run',
    log: ru ? 'Лог сборки' : 'Build log',
    ready: ru ? 'Сборка готова' : 'Build successful',
    failed: ru ? 'Ошибка сборки' : 'Build failed',
    time: ru ? 'Время' : 'Time',
    size: ru ? 'Размер' : 'Size',
    apk: ru ? 'APK файл' : 'APK file',
    clean: ru ? 'Очистить' : 'Clean',
    startBuild: ru ? 'Запустить сборку' : 'Start build',
  };

  const appendLog = useCallback((line: string) => {
    setLogs(prev => [...prev, line]);
    if (terminalRef.current?.writeText) {
      try {
        terminalRef.current.writeText(line.replace(/\n/g, '\r\n') + '\r\n');
      } catch {}
    }
  }, []);

  const runBuild = useCallback(async () => {
    if (!projectPath || running) return;
    
    setRunning(true);
    setBuildResult('idle');
    setApkPath(null);
    setLogs([]);
    
    const startTime = Date.now();
    appendLog(`=== NCS Build ${variant.toUpperCase()} ===`);
    appendLog(`Проект: ${projectName}`);
    appendLog(`Папка: ${projectPath}`);
    appendLog('');

    try {
      // Запускаем ncs build в proot
      const cmd = `source ~/.bashrc 2>/dev/null; cd "${projectPath}" && ncs build ${variant} 2>&1; echo "EXIT:$?"`;
      const result = await execute(cmd);
      const output = result.output || '';
      
      output.split('\n').forEach(line => {
        if (line.trim()) appendLog(line);
      });

      const exitMatch = output.match(/EXIT:(\d+)/);
      const exitCode = exitMatch ? parseInt(exitMatch[1], 10) : -1;
      
      const elapsed = Date.now() - startTime;
      setBuildTime(elapsed);

      // Ищем APK
      const apkMatch = output.match(/APK:\s*(build\/outputs\/[^\n]+\.apk)/);
      if (apkMatch) {
        const fullApkPath = `${projectPath}/${apkMatch[1].trim()}`;
        setApkPath(fullApkPath);
        setBuildResult('success');
        appendLog('');
        appendLog(`✅ Сборка завершена за ${(elapsed / 1000).toFixed(1)} сек!`);
        appendLog(`APK: ${fullApkPath}`);
      } else if (exitCode === 0) {
        // Пробуем найти apk через find
        const findRes = await execute(`find "${projectPath}/build/outputs" -name "*.apk" 2>/dev/null | head -1`);
        const found = findRes.output?.trim();
        if (found) {
          setApkPath(found);
          setBuildResult('success');
          appendLog(`✅ Сборка завершена за ${(elapsed / 1000).toFixed(1)} сек!`);
          appendLog(`APK: ${found}`);
        } else {
          setBuildResult('error');
          appendLog('❌ APK не найден после сборки');
        }
      } else {
        setBuildResult('error');
        appendLog(`❌ Ошибка сборки (код ${exitCode})`);
      }
    } catch (e) {
      appendLog(`❌ Ошибка: ${e instanceof Error ? e.message : String(e)}`);
      setBuildResult('error');
    } finally {
      setRunning(false);
    }
  }, [projectPath, projectName, variant, running, appendLog]);

  const installBuild = useCallback(async () => {
    if (!apkPath) return;
    appendLog('Установка APK...');
    try {
      const result = await installApk(apkPath);
      if (result?.success) {
        appendLog('✅ Установлено');
      } else {
        appendLog(`⚠ Установка: ${result?.output || 'откройте файл вручную'}`);
      }
    } catch (e) {
      appendLog(`❌ Не удалось установить: ${e}`);
    }
  }, [apkPath, appendLog]);

  const cleanBuild = useCallback(async () => {
    if (!projectPath) return;
    await execute(`cd "${projectPath}" && ncs clean 2>&1`);
    setLogs([]);
    setApkPath(null);
    setBuildResult('idle');
    appendLog('✅ Очищено');
  }, [projectPath, appendLog]);

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }, [logs]);

  return (
    <AppScreen>
      <TopBar
        title={copy.title}
        subtitle={`${projectName} · ${copy.subtitle}`}
        onBack={() => navigation.goBack()}
      />

      <ScrollView
        ref={scrollRef}
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 80,
          gap: 12,
        }}
      >
        <SectionCard title={ru ? 'Вариант сборки' : 'Build variant'} icon="settings-outline">
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {(['debug', 'release'] as const).map(v => (
              <Pressable
                key={v}
                onPress={() => setVariant(v)}
                style={[
                  styles.variantBtn,
                  variant === v && { backgroundColor: colors.primarySurface, borderColor: colors.primary }
                ]}
              >
                <Text style={[styles.variantText, { color: variant === v ? colors.primary : colors.textSecondary }]}>
                  {v === 'debug' ? copy.debug : copy.release}
                </Text>
              </Pressable>
            ))}
          </View>
        </SectionCard>

        <View style={{ flexDirection: narrow ? 'column' : 'row', gap: 8 }}>
          <PrimaryButton
            title={running ? copy.building : copy.build}
            icon="hammer-outline"
            loading={running}
            onPress={runBuild}
            disabled={running || !projectPath}
            style={{ flex: 1 }}
          />
          <IconButton
            name="trash-outline"
            label={copy.clean}
            onPress={cleanBuild}
            disabled={running}
            style={{ flex: narrow ? 1 : 0 }}
          />
        </View>

        {buildResult === 'success' && (
          <View style={[styles.resultCard, { backgroundColor: colors.successBg }]}>
            <Icon name="checkmark-circle" size={28} color={colors.success} />
            <View style={{ flex: 1, gap: 4 }}>
              <Text style={[styles.resultTitle, { color: colors.successText }]}>{copy.ready}</Text>
              <View style={{ flexDirection: 'row', gap: 16 }}>
                <Text style={[styles.resultMeta, { color: colors.successText }]}>
                  ⏱ {copy.time}: {(buildTime / 1000).toFixed(1)}s
                </Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Pressable onPress={installBuild} style={[styles.actionBtn, { backgroundColor: colors.primary }]}>
                <Icon name="download-outline" size={16} color="#FFF" />
                <Text style={styles.actionBtnText}>{copy.install}</Text>
              </Pressable>
            </View>
          </View>
        )}

        {buildResult === 'error' && (
          <View style={[styles.resultCard, { backgroundColor: colors.errorBg }]}>
            <Icon name="close-circle" size={28} color={colors.error} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.resultTitle, { color: colors.errorText }]}>{copy.failed}</Text>
              <Text style={[styles.resultMeta, { color: colors.errorText }]}>
                {ru ? 'Смотрите лог ниже для деталей' : 'See log below for details'}
              </Text>
            </View>
          </View>
        )}

        <View style={styles.consoleWrap}>
          <View style={styles.consoleHead}>
            <View style={styles.dots}>
              <View style={[styles.dot, { backgroundColor: '#F87171' }]} />
              <View style={[styles.dot, { backgroundColor: '#FBBF24' }]} />
              <View style={[styles.dot, { backgroundColor: '#34D399' }]} />
            </View>
            <Text style={styles.consoleTitle}>{copy.log}</Text>
            <View style={{ flex: 1 }} />
            <IconButton name="remove-outline" onPress={() => setFontSize(Math.max(10, fontSize - 2))} />
            <IconButton name="add-outline" onPress={() => setFontSize(Math.min(24, fontSize + 2))} />
          </View>
          
          {terminalRef ? (
            <View style={{ height: 350 }}>
              <TerminalView
                ref={terminalRef}
                style={{ flex: 1, backgroundColor: colors.terminal }}
                fontSize={fontSize}
                extraKeys={EXTRA_KEYS}
                readOnly
              />
            </View>
          ) : (
            <ScrollView
              style={[styles.logFallback, { backgroundColor: colors.terminal }]}
              contentContainerStyle={{ padding: 12 }}
            >
              {logs.length === 0 ? (
                <Text style={{ color: '#8B98AD', fontSize: 12, textAlign: 'center', marginTop: 40 }}>
                  {ru ? 'Нажмите «Собрать APK» для начала' : 'Press "Build APK" to start'}
                </Text>
              ) : (
                logs.map((line, i) => (
                  <Text key={i} style={{ color: line.includes('✅') ? '#4ADE80' : line.includes('❌') ? '#F87171' : '#C9D3E3', fontFamily: 'monospace', fontSize: fontSize - 2 }}>
                    {line}
                  </Text>
                ))
              )}
            </ScrollView>
          )}
        </View>
      </ScrollView>
      <AdsBanner />
    </AppScreen>
  );
};

const createStyles = (c: any) => StyleSheet.create({
  variantBtn: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: c.border,
    alignItems: 'center',
  },
  variantText: {
    fontSize: 14,
    fontWeight: '700',
  },
  resultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 12,
  },
  resultTitle: {
    fontSize: 14,
    fontWeight: '700',
  },
  resultMeta: {
    fontSize: 11,
    marginTop: 2,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  actionBtnText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '700',
  },
  consoleWrap: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#253046',
    marginTop: 8,
  },
  consoleHead: {
    minHeight: 40,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: c.terminalRaised,
    borderBottomWidth: 1,
    borderBottomColor: '#253046',
  },
  dots: {
    flexDirection: 'row',
    gap: 5,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  consoleTitle: {
    color: '#D6DEEB',
    fontSize: 11,
    fontWeight: '700',
  },
  logFallback: {
    height: 300,
  },
});

export default NcsBuildScreen;
