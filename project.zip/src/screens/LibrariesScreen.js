import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Linking,
  FlatList,
} from 'react-native';
import colors from '../theme/colors';

// Популярные библиотеки для React Native / Expo
const popularLibraries = [
  {
    name: 'expo-camera',
    description: 'Камера для фото и видео',
    category: 'Media',
    install: 'npx expo install expo-camera',
    icon: '📷',
  },
  {
    name: 'expo-image-picker',
    description: 'Выбор изображений из галереи',
    category: 'Media',
    install: 'npx expo install expo-image-picker',
    icon: '🖼',
  },
  {
    name: 'expo-location',
    description: 'Геолокация и GPS',
    category: 'Device',
    install: 'npx expo install expo-location',
    icon: '📍',
  },
  {
    name: 'expo-notifications',
    description: 'Push-уведомления',
    category: 'Device',
    install: 'npx expo install expo-notifications',
    icon: '🔔',
  },
  {
    name: 'expo-av',
    description: 'Аудио и видео плеер',
    category: 'Media',
    install: 'npx expo install expo-av',
    icon: '🎵',
  },
  {
    name: 'expo-file-system',
    description: 'Работа с файловой системой',
    category: 'Storage',
    install: 'npx expo install expo-file-system',
    icon: '📁',
  },
  {
    name: 'expo-secure-store',
    description: 'Безопасное хранилище',
    category: 'Storage',
    install: 'npx expo install expo-secure-store',
    icon: '🔐',
  },
  {
    name: 'expo-sqlite',
    description: 'Локальная база данных SQLite',
    category: 'Storage',
    install: 'npx expo install expo-sqlite',
    icon: '🗃',
  },
  {
    name: 'react-native-maps',
    description: 'Карты Google/Apple',
    category: 'UI',
    install: 'npx expo install react-native-maps',
    icon: '🗺',
  },
  {
    name: 'react-native-webview',
    description: 'Встроенный браузер',
    category: 'UI',
    install: 'npx expo install react-native-webview',
    icon: '🌐',
  },
  {
    name: 'react-native-chart-kit',
    description: 'Графики и диаграммы',
    category: 'UI',
    install: 'npm install react-native-chart-kit react-native-svg',
    icon: '📊',
  },
  {
    name: 'react-native-paper',
    description: 'Material Design компоненты',
    category: 'UI',
    install: 'npm install react-native-paper react-native-safe-area-context',
    icon: '🎨',
  },
  {
    name: 'react-native-elements',
    description: 'UI toolkit компоненты',
    category: 'UI',
    install: 'npm install @rneui/themed @rneui/base',
    icon: '🧱',
  },
  {
    name: 'axios',
    description: 'HTTP клиент для API запросов',
    category: 'Network',
    install: 'npm install axios',
    icon: '🌍',
  },
  {
    name: 'zustand',
    description: 'Легковесный state manager',
    category: 'State',
    install: 'npm install zustand',
    icon: '🐻',
  },
  {
    name: 'react-query',
    description: 'Data fetching и кэширование',
    category: 'State',
    install: 'npm install @tanstack/react-query',
    icon: '🔄',
  },
  {
    name: 'expo-auth-session',
    description: 'OAuth авторизация',
    category: 'Auth',
    install: 'npx expo install expo-auth-session expo-crypto',
    icon: '🔑',
  },
  {
    name: 'expo-barcode-scanner',
    description: 'Сканер штрих-кодов',
    category: 'Device',
    install: 'npx expo install expo-barcode-scanner',
    icon: '📱',
  },
  {
    name: 'expo-haptics',
    description: 'Тактильная обратная связь',
    category: 'Device',
    install: 'npx expo install expo-haptics',
    icon: '📳',
  },
  {
    name: 'expo-sharing',
    description: 'Шаринг файлов',
    category: 'Device',
    install: 'npx expo install expo-sharing',
    icon: '📤',
  },
];

const categories = ['All', 'UI', 'Media', 'Device', 'Storage', 'Network', 'State', 'Auth'];

const LibrariesScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [customPackage, setCustomPackage] = useState('');

  const filteredLibraries = popularLibraries.filter(lib => {
    const matchesSearch = lib.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lib.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || lib.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleInstallLibrary = (lib) => {
    Alert.alert(
      'Установка библиотеки',
      `Для установки ${lib.name} выполните в терминале:\n\n${lib.install}\n\nОткрыть npm страницу?`,
      [
        { text: 'Отмена', style: 'cancel' },
        {
          text: 'Открыть npm',
          onPress: () => Linking.openURL(`https://www.npmjs.com/package/${lib.name}`),
        },
      ]
    );
  };

  const handleCustomInstall = () => {
    if (!customPackage.trim()) {
      Alert.alert('Ошибка', 'Введите название пакета');
      return;
    }
    Alert.alert(
      'Установка пакета',
      `Для установки ${customPackage} выполните:\n\nnpx expo install ${customPackage}\n\nили:\n\nnpm install ${customPackage}\n\n⚠️ Используйте npx expo install для Expo-совместимых библиотек.`,
      [
        { text: 'OK' },
        {
          text: 'Открыть npm',
          onPress: () => Linking.openURL(`https://www.npmjs.com/package/${customPackage}`),
        },
      ]
    );
  };

  const renderLibraryCard = ({ item }) => (
    <TouchableOpacity
      style={styles.libraryCard}
      onPress={() => handleInstallLibrary(item)}
      activeOpacity={0.7}
    >
      <View style={styles.libraryHeader}>
        <Text style={styles.libraryIcon}>{item.icon}</Text>
        <View style={styles.libraryInfo}>
          <Text style={styles.libraryName}>{item.name}</Text>
          <Text style={styles.libraryDesc}>{item.description}</Text>
        </View>
      </View>
      <View style={styles.libraryFooter}>
        <View style={styles.categoryBadge}>
          <Text style={styles.categoryBadgeText}>{item.category}</Text>
        </View>
        <View style={styles.installHint}>
          <Text style={styles.installHintText}>Нажмите для установки</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Назад</Text>
        </TouchableOpacity>
        <Text style={styles.title}>📦 Библиотеки</Text>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Поиск библиотек..."
          placeholderTextColor={colors.onSurfaceVariant}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Categories */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
        {categories.map(cat => (
          <TouchableOpacity
            key={cat}
            style={[
              styles.categoryTab,
              selectedCategory === cat && styles.categoryTabActive,
            ]}
            onPress={() => setSelectedCategory(cat)}
          >
            <Text style={[
              styles.categoryTabText,
              selectedCategory === cat && styles.categoryTabTextActive,
            ]}>
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Custom Install */}
      <View style={styles.customInstall}>
        <TextInput
          style={styles.customInput}
          placeholder="Название пакета (npm install ...)"
          placeholderTextColor={colors.onSurfaceVariant}
          value={customPackage}
          onChangeText={setCustomPackage}
        />
        <TouchableOpacity
          style={styles.customButton}
          onPress={handleCustomInstall}
        >
          <Text style={styles.customButtonText}>Установить</Text>
        </TouchableOpacity>
      </View>

      {/* Info Banner */}
      <View style={styles.infoBanner}>
        <Text style={styles.infoBannerText}>
          💡 Используйте <Text style={styles.highlight}>npx expo install</Text> для Expo-библиотек,{' '}
          <Text style={styles.highlight}>npm install</Text> или{' '}
          <Text style={styles.highlight}>yarn add</Text> для остальных
        </Text>
      </View>

      {/* Libraries List */}
      <FlatList
        data={filteredLibraries}
        keyExtractor={item => item.name}
        renderItem={renderLibraryCard}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>Ничего не найдено</Text>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 44,
    paddingHorizontal: 12,
    paddingBottom: 12,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    padding: 8,
    marginRight: 8,
  },
  backButtonText: {
    color: colors.primary,
    fontSize: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.onSurface,
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    marginHorizontal: 12,
    marginTop: 12,
    borderRadius: 10,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  searchIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 10,
    fontSize: 14,
    color: colors.onSurface,
  },
  categories: {
    maxHeight: 44,
    marginTop: 8,
    paddingHorizontal: 12,
  },
  categoryTab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 6,
    borderRadius: 8,
    backgroundColor: colors.surfaceLight,
  },
  categoryTabActive: {
    backgroundColor: colors.primary,
  },
  categoryTabText: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
    fontWeight: '600',
  },
  categoryTabTextActive: {
    color: colors.onPrimary,
  },
  customInstall: {
    flexDirection: 'row',
    marginHorizontal: 12,
    marginTop: 12,
    gap: 8,
  },
  customInput: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: colors.onSurface,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  customButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 16,
    borderRadius: 10,
    justifyContent: 'center',
  },
  customButtonText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: 'bold',
  },
  infoBanner: {
    backgroundColor: colors.surfaceLight,
    marginHorizontal: 12,
    marginTop: 12,
    padding: 10,
    borderRadius: 8,
  },
  infoBannerText: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
    lineHeight: 18,
  },
  highlight: {
    color: colors.secondary,
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  listContent: {
    padding: 12,
  },
  libraryCard: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  libraryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  libraryIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  libraryInfo: {
    flex: 1,
  },
  libraryName: {
    fontSize: 15,
    fontWeight: 'bold',
    color: colors.onSurface,
    fontFamily: 'monospace',
  },
  libraryDesc: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  libraryFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryBadge: {
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 4,
  },
  categoryBadgeText: {
    color: colors.primary,
    fontSize: 10,
    fontWeight: 'bold',
  },
  installHint: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  installHintText: {
    fontSize: 11,
    color: colors.secondary,
  },
  emptyState: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 14,
  },
});

export default LibrariesScreen;
