import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, Field, IconButton, PrimaryButton, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import { useProject } from '../store/projectStore';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';
import { syncComposeProject } from '../utils/composeProject';

const catalog = [
  { coordinate: 'react-router-dom@^6.26.0', icon: 'git-branch-outline', category: 'Routing', ru: 'Роутер для React', en: 'Router for React' },
  { coordinate: 'zustand@^4.5.0', icon: 'layers-outline', category: 'State', ru: 'Управление состоянием', en: 'State management' },
  { coordinate: 'axios@^1.7.0', icon: 'swap-horizontal-outline', category: 'Network', ru: 'HTTP клиент', en: 'HTTP client' },
  { coordinate: '@tanstack/react-query@^5.0.0', icon: 'sync-outline', category: 'Network', ru: 'Кэширование запросов', en: 'Query caching' },
  { coordinate: 'react-hook-form@^7.0.0', icon: 'create-outline', category: 'UI', ru: 'Формы React', en: 'React forms' },
  { coordinate: 'framer-motion@^11.0.0', icon: 'color-wand-outline', category: 'UI', ru: 'Анимации', en: 'Animations' },
  { coordinate: 'dayjs@^1.11.0', icon: 'calendar-outline', category: 'Utils', ru: 'Дата/время', en: 'Date/time' },
  { coordinate: 'lodash@^4.17.0', icon: 'code-slash-outline', category: 'Utils', ru: 'Утилиты', en: 'Utilities' },
];
const categories = ['All', 'UI', 'Routing', 'State', 'Network', 'Utils'];
const validNpm = (value) => /^(@[a-z0-9-]+\/)?[a-z0-9-]+(@.+)?$/i.test(value.trim());

const LibrariesScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, language, t } = useAppSettings();
  const { currentProject, dispatch } = useProject();
  const [tab, setTab] = useState('catalog');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [custom, setCustom] = useState('');
  const [resolved, setResolved] = useState({});
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1050 ? 3 : width >= 680 ? 2 : 1;
  const copy = language === 'ru' ? {
    title: 'npm зависимости', subtitle: 'package.json · React + Vite', catalog: 'Каталог', installed: 'Установлены',
    search: 'Поиск npm пакетов', custom: 'package@version', add: 'Установить', remove: 'Удалить',
    declared: 'В package.json', cached: 'Установлен', unresolved: 'Не установлен', refresh: 'Проверить node_modules',
    resolve: 'Установить всё (npm install)', invalid: 'Введите npm пакет: name или name@version', noProject: 'Сначала откройте React проект.',
    removeTitle: 'Удалить пакет?', removeText: 'Зависимость будет удалена из package.json.', empty: 'Дополнительные зависимости не установлены',
  } : {
    title: 'npm dependencies', subtitle: 'package.json · React + Vite', catalog: 'Catalog', installed: 'Installed',
    search: 'Search npm packages', custom: 'package@version', add: 'Install', remove: 'Remove', declared: 'In package.json',
    cached: 'Installed', unresolved: 'Not installed', refresh: 'Check node_modules', resolve: 'Install all (npm install)',
    invalid: 'Enter npm package: name or name@version', noProject: 'Open a React project first.', removeTitle: 'Remove package?',
    removeText: 'Dependency will be removed from package.json.', empty: 'No additional dependencies installed',
  };
  const declared = currentProject?.gradleDependencies || currentProject?.dependencies || [];

  const checkCache = useCallback(async () => {
    if (!currentProject) return;
    const next = {};
    for (const dep of declared) {
      const name = dep.split('@').filter(Boolean)[0].replace(/^@/,'');
      const pkgName = dep.includes('@') && dep.startsWith('@') ? '@'+name : dep.split('@')[0];
      const simple = pkgName.split('@')[0] || pkgName;
      const result = await execute(`[ -d "node_modules/${simple}" ] && printf yes || true`, getProjectDir(currentProject));
      next[dep] = result.output?.includes('yes');
    }
    setResolved(next);
  }, [currentProject?.id, JSON.stringify(declared)]);
  useEffect(() => { checkCache(); }, [checkCache]);

  const updateDependencies = async (nextDependencies) => {
    const updated = { ...currentProject, gradleDependencies: nextDependencies, dependencies: nextDependencies, updatedAt: Date.now() };
    dispatch({ type: 'UPDATE_PROJECT', payload: updated });
    const result = await syncComposeProject(updated).catch(()=>({success:true}));
    return updated;
  };
  const add = async (coordinate) => {
    const value = coordinate.trim();
    if (!validNpm(value)) { Alert.alert(copy.invalid); return; }
    if (declared.includes(value)) return;
    setBusy(value); setError('');
    try {
      await updateDependencies([...declared, value]);
      // install immediately
      const dir = getProjectDir(currentProject);
      const r = await execute(`npm install ${value} --save 2>&1 | tail -20`, dir);
      if (!r.success && !/added/i.test(r.output||'')) throw new Error(r.output?.slice(0,800)||'npm install failed');
      setCustom('');
      await checkCache();
    }
    catch (err) { setError(err?.message || String(err)); }
    finally { setBusy(null); }
  };
  const remove = (coordinate) => Alert.alert(copy.removeTitle, `${coordinate}\n\n${copy.removeText}`, [
    { text: t('cancel'), style: 'cancel' },
    { text: copy.remove, style: 'destructive', onPress: async () => {
      setBusy(coordinate);
      try {
        await updateDependencies(declared.filter((item) => item !== coordinate));
        const dir = getProjectDir(currentProject);
        await execute(`npm uninstall ${coordinate.split('@')[0]} 2>&1 | tail -10`, dir);
        await checkCache();
      }
      catch (err) { setError(err?.message || String(err)); }
      finally { setBusy(null); }
    } },
  ]);
  const resolveAll = async () => {
    setBusy('resolve'); setError('');
    const result = await execute('npm install 2>&1 | tail -30', getProjectDir(currentProject));
    if (!result.success && !/up to date|added/i.test(result.output||'')) setError(result.output || 'npm install failed');
    await checkCache(); setBusy(null);
  };

  if (!currentProject) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View style={styles.empty}><Text style={styles.emptyText}>{copy.noProject}</Text></View></AppScreen>;
  const filtered = catalog.filter((item) => (category === 'All' || item.category === category) && `${item.coordinate} ${item[language]}`.toLowerCase().includes(query.toLowerCase()));
  const installedRows = declared.filter((item) => item.toLowerCase().includes(query.toLowerCase()));
  const card = ({ item }) => {
    const connected = declared.includes(item.coordinate);
    return <View style={styles.card}><View style={styles.cardHead}><View style={styles.packageIcon}><Icon name={item.icon} size={21} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.coordinate} numberOfLines={2}>{item.coordinate}</Text><Text style={styles.description}>{item[language]}</Text></View></View><View style={styles.cardFooter}>{connected ? <StatusPill label={resolved[item.coordinate] ? copy.cached : copy.declared} tone={resolved[item.coordinate] ? 'success' : 'info'} /> : <StatusPill label={item.category} />}{connected ? <IconButton name="trash-outline" danger onPress={() => remove(item.coordinate)} style={styles.action} /> : <Pressable onPress={() => add(item.coordinate)} style={styles.addLink}><Icon name="add-circle-outline" size={15} color={colors.primary} /><Text style={styles.addText}>{copy.add}</Text></Pressable>}</View></View>;
  };

  return <AppScreen>
    <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="refresh-outline" label={width >= 700 ? copy.refresh : null} onPress={checkCache} />} />
    <View style={styles.controls}><SegmentedControl value={tab} onChange={setTab} options={[{ value: 'catalog', label: copy.catalog, icon: 'grid-outline' }, { value: 'installed', label: `${copy.installed} (${declared.length})`, icon: 'list-outline' }]} /><View style={[styles.searchRow, width < 620 && styles.mobile]}><Field value={query} onChangeText={setQuery} placeholder={copy.search} style={{ flex: 1 }} /><View style={styles.customRow}><Field value={custom} onChangeText={setCustom} placeholder={copy.custom} autoCapitalize="none" style={{ flex: 1 }} /><PrimaryButton title={width >= 640 ? copy.add : ''} icon="add" loading={busy === custom.trim()} disabled={!custom.trim()} onPress={() => add(custom)} /></View></View>{tab === 'catalog' ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categories}>{categories.map((item) => <Pressable key={item} onPress={() => setCategory(item)} style={[styles.category, category === item && styles.categoryActive]}><Text style={[styles.categoryText, category === item && styles.categoryTextActive]}>{item}</Text></Pressable>)}</ScrollView> : <PrimaryButton title={copy.resolve} icon="cloud-download-outline" loading={busy === 'resolve'} onPress={resolveAll} />}{error ? <View style={styles.errorBox}><Text selectable style={styles.errorText}>{error}</Text></View> : null}</View>
    {tab === 'catalog' ? <FlatList key={columns} numColumns={columns} data={filtered} renderItem={card} keyExtractor={(item) => item.coordinate} columnWrapperStyle={columns > 1 ? { gap: 10 } : null} contentContainerStyle={styles.list} /> : <FlatList data={installedRows} keyExtractor={(item) => item} contentContainerStyle={styles.installedList} ListEmptyComponent={<View style={styles.empty}><Icon name="cube-outline" size={36} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.empty}</Text></View>} renderItem={({ item }) => <View style={styles.row}><View style={[styles.dot, { backgroundColor: resolved[item] ? colors.success : colors.warning }]} /><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.coordinate} numberOfLines={2}>{item}</Text><Text style={styles.description}>npm install {item}</Text></View><StatusPill label={resolved[item] ? copy.cached : copy.unresolved} tone={resolved[item] ? 'success' : 'warning'} /><IconButton name="trash-outline" danger onPress={() => remove(item)} style={styles.action} /></View>} />}
  </AppScreen>;
};

const createStyles = (c) => StyleSheet.create({
  controls: { padding: 12, gap: 9, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border }, searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 }, mobile: { flexDirection: 'column', alignItems: 'stretch' }, customRow: { flex: 1, minWidth: 0, flexDirection: 'row', gap: 8, alignItems: 'center' }, categories: { gap: 6 }, category: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 8, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border }, categoryActive: { backgroundColor: c.primarySurface, borderColor: c.primary }, categoryText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' }, categoryTextActive: { color: c.primary }, errorBox: { padding: 10, borderRadius: 8, backgroundColor: c.errorBg }, errorText: { color: c.errorText, fontFamily: 'monospace', fontSize: 9 }, list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 12, paddingBottom: 40 }, card: { flex: 1, minWidth: 0, padding: 13, marginBottom: 10, borderRadius: 13, borderWidth: 1, borderColor: c.border, backgroundColor: c.bgCard }, cardHead: { minHeight: 58, flexDirection: 'row', alignItems: 'center', gap: 10 }, packageIcon: { width: 40, height: 40, borderRadius: 11, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, coordinate: { color: c.text, fontFamily: 'monospace', fontSize: 10, lineHeight: 14, fontWeight: '700' }, description: { color: c.textSecondary, fontSize: 9, lineHeight: 14, marginTop: 3 }, cardFooter: { marginTop: 10, paddingTop: 9, borderTopWidth: 1, borderTopColor: c.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, addLink: { padding: 6, flexDirection: 'row', alignItems: 'center', gap: 5 }, addText: { color: c.primary, fontSize: 10, fontWeight: '700' }, action: { width: 36, minWidth: 36, height: 36, paddingHorizontal: 0 }, installedList: { width: '100%', maxWidth: 900, alignSelf: 'center', padding: 12, paddingBottom: 40 }, row: { minHeight: 66, padding: 11, marginBottom: 7, borderRadius: 11, borderWidth: 1, borderColor: c.border, backgroundColor: c.bgCard, flexDirection: 'row', alignItems: 'center', gap: 9 }, dot: { width: 9, height: 9, borderRadius: 5 }, empty: { flex: 1, minHeight: 280, alignItems: 'center', justifyContent: 'center', gap: 9 }, emptyText: { color: c.textSecondary, fontSize: 12 },
});
export default LibrariesScreen;
