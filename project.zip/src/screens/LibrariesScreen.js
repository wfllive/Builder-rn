import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, Field, IconButton, PrimaryButton, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import { useProject } from '../store/projectStore';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';
import { readWorkspaceJson, shellQuote } from '../utils/workspace';

const catalog = [
  { name: 'expo-camera', icon: 'camera-outline', category: 'Media', ru: 'Камера и запись видео', en: 'Camera and video capture' },
  { name: 'expo-image-picker', icon: 'images-outline', category: 'Media', ru: 'Выбор фото и видео', en: 'Photo and video picker' },
  { name: 'expo-location', icon: 'location-outline', category: 'Device', ru: 'Геолокация и GPS', en: 'Location and GPS' },
  { name: 'expo-notifications', icon: 'notifications-outline', category: 'Device', ru: 'Push-уведомления', en: 'Push notifications' },
  { name: 'expo-audio', icon: 'musical-notes-outline', category: 'Media', ru: 'Воспроизведение аудио', en: 'Audio playback' },
  { name: 'expo-file-system', icon: 'folder-outline', category: 'Storage', ru: 'Файловая система', en: 'File system access' },
  { name: 'expo-secure-store', icon: 'shield-checkmark-outline', category: 'Storage', ru: 'Защищённое хранилище', en: 'Secure key-value storage' },
  { name: 'expo-sqlite', icon: 'server-outline', category: 'Storage', ru: 'Локальная SQLite база', en: 'Local SQLite database' },
  { name: 'react-native-maps', icon: 'map-outline', category: 'UI', ru: 'Нативные карты', en: 'Native maps' },
  { name: 'react-native-webview', icon: 'globe-outline', category: 'UI', ru: 'Встроенный браузер', en: 'Embedded browser' },
  { name: '@tanstack/react-query', icon: 'cloud-download-outline', category: 'State', ru: 'Серверное состояние и кеш', en: 'Server state and cache' },
  { name: 'zustand', icon: 'layers-outline', category: 'State', ru: 'Управление состоянием', en: 'State management' },
  { name: 'axios', icon: 'swap-horizontal-outline', category: 'Network', ru: 'HTTP-клиент', en: 'HTTP client' },
  { name: 'expo-auth-session', icon: 'key-outline', category: 'Auth', ru: 'OAuth авторизация', en: 'OAuth authentication' },
  { name: 'expo-haptics', icon: 'phone-portrait-outline', category: 'Device', ru: 'Тактильный отклик', en: 'Haptic feedback' },
];

const categories = ['All', 'UI', 'Media', 'Device', 'Storage', 'Network', 'State', 'Auth'];

const LibrariesScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, language, t } = useAppSettings();
  const { currentProject, dispatch } = useProject();
  const [tab, setTab] = useState('catalog');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [custom, setCustom] = useState('');
  const [manifest, setManifest] = useState({ dependencies: {}, devDependencies: {} });
  const [diskStatus, setDiskStatus] = useState({});
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1050 ? 3 : width >= 680 ? 2 : 1;
  const copy = language === 'ru' ? {
    subtitle: 'package.json и node_modules текущего проекта',
    catalog: 'Каталог', installed: 'Зависимости', search: 'Поиск пакетов', custom: 'Имя npm-пакета',
    install: 'Установить', declared: 'В package.json', onDisk: 'Установлен', missing: 'Не установлен',
    empty: 'Зависимости не найдены', refresh: 'Проверить', noProject: 'Сначала откройте проект.',
    failed: 'Команда установки завершилась с ошибкой', version: 'Версия', packageJson: 'Объявлен',
  } : {
    subtitle: 'Current project package.json and node_modules',
    catalog: 'Catalog', installed: 'Dependencies', search: 'Search packages', custom: 'npm package name',
    install: 'Install', declared: 'In package.json', onDisk: 'Installed', missing: 'Missing',
    empty: 'No dependencies found', refresh: 'Check', noProject: 'Open a project first.',
    failed: 'The install command failed', version: 'Version', packageJson: 'Declared',
  };

  const refresh = useCallback(async () => {
    if (!currentProject) return;
    setError('');
    try {
      const packageJson = await readWorkspaceJson(currentProject, 'package.json');
      const next = { dependencies: packageJson.dependencies || {}, devDependencies: packageJson.devDependencies || {} };
      setManifest(next);
      const names = [...new Set([...Object.keys(next.dependencies), ...Object.keys(next.devDependencies)])];
      const statuses = {};
      if (names.length) {
        const checks = names.map((name) => `[ -d node_modules/${shellQuote(name)} ] && printf '%s|1\\n' ${shellQuote(name)} || printf '%s|0\\n' ${shellQuote(name)}`).join('; ');
        const result = await execute(checks, getProjectDir(currentProject));
        String(result.output || '').split('\n').forEach((line) => {
          const [name, value] = line.split('|');
          if (name) statuses[name] = value === '1';
        });
      }
      setDiskStatus(statuses);
      dispatch({ type: 'UPDATE_PROJECT', payload: { ...currentProject, ...next } });
    } catch (e) {
      setError(e?.message || String(e));
    }
  }, [currentProject?.id]);

  useEffect(() => { refresh(); }, [refresh]);

  const install = async (packageName) => {
    const name = packageName.trim();
    if (!/^(@[a-z0-9._-]+\/)?[a-z0-9._-]+$/i.test(name)) {
      Alert.alert('Invalid package name');
      return;
    }
    setBusy(name);
    setError('');
    try {
      const result = await execute(`npx expo install ${shellQuote(name)} 2>&1`, getProjectDir(currentProject));
      if (!result?.success) throw new Error(result?.output || copy.failed);
      setCustom('');
      await refresh();
    } catch (e) {
      setError(e?.message || String(e));
      Alert.alert(copy.failed, (e?.message || String(e)).slice(0, 1200));
    } finally {
      setBusy(null);
    }
  };

  if (!currentProject) return <AppScreen><TopBar title={t('libraries')} onBack={() => navigation.goBack()} /><View style={styles.empty}><Icon name="cube-outline" size={38} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.noProject}</Text></View></AppScreen>;

  const declared = { ...manifest.devDependencies, ...manifest.dependencies };
  const filteredCatalog = catalog.filter((item) => (category === 'All' || item.category === category) && (`${item.name} ${item[language]}`).toLowerCase().includes(query.toLowerCase()));
  const dependencies = Object.entries(declared).filter(([name]) => name.toLowerCase().includes(query.toLowerCase())).map(([name, version]) => ({ name, version, installed: diskStatus[name] }));

  const renderCatalog = ({ item }) => {
    const isDeclared = Boolean(declared[item.name]);
    const installed = diskStatus[item.name];
    return (
      <View style={styles.card}>
        <View style={styles.cardHead}><View style={styles.packageIcon}><Icon name={item.icon} size={21} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.packageName} numberOfLines={1}>{item.name}</Text><Text style={styles.description} numberOfLines={2}>{item[language]}</Text></View></View>
        <View style={styles.cardFooter}>
          {isDeclared ? <StatusPill label={installed ? copy.onDisk : copy.missing} tone={installed ? 'success' : 'warning'} /> : <StatusPill label={item.category} />}
          {!installed ? <Pressable disabled={Boolean(busy)} onPress={() => install(item.name)} style={styles.installLink}>{busy === item.name ? <Icon name="sync-outline" size={14} color={colors.primary} /> : <Icon name="download-outline" size={14} color={colors.primary} />}<Text style={styles.installText}>{copy.install}</Text></Pressable> : <Icon name="checkmark-circle" size={19} color={colors.success} />}
        </View>
      </View>
    );
  };

  return (
    <AppScreen>
      <TopBar title={t('libraries')} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="refresh-outline" label={width >= 700 ? copy.refresh : null} onPress={refresh} />} />
      <View style={styles.controls}>
        <SegmentedControl value={tab} onChange={setTab} options={[{ value: 'catalog', label: copy.catalog, icon: 'grid-outline' }, { value: 'installed', label: `${copy.installed} (${Object.keys(declared).length})`, icon: 'list-outline' }]} />
        <View style={styles.searchRow}><Field value={query} onChangeText={setQuery} placeholder={copy.search} style={{ flex: 1 }} /><Field value={custom} onChangeText={setCustom} placeholder={copy.custom} autoCapitalize="none" style={{ flex: 1 }} /><PrimaryButton title={width >= 640 ? copy.install : ''} icon="download-outline" disabled={!custom.trim() || Boolean(busy)} loading={busy === custom.trim()} onPress={() => install(custom)} /></View>
        {tab === 'catalog' ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categories}>{categories.map((item) => <Pressable key={item} onPress={() => setCategory(item)} style={[styles.category, category === item && styles.categoryActive]}><Text style={[styles.categoryText, category === item && styles.categoryTextActive]}>{item}</Text></Pressable>)}</ScrollView> : null}
        {error ? <View style={styles.error}><Icon name="alert-circle-outline" size={16} color={colors.error} /><Text selectable style={styles.errorText} numberOfLines={3}>{error}</Text></View> : null}
      </View>

      {tab === 'catalog' ? (
        <FlatList key={columns} numColumns={columns} data={filteredCatalog} renderItem={renderCatalog} keyExtractor={(item) => item.name} columnWrapperStyle={columns > 1 ? { gap: 10 } : null} contentContainerStyle={styles.list} />
      ) : (
        <FlatList
          data={dependencies}
          keyExtractor={(item) => item.name}
          contentContainerStyle={styles.dependencyList}
          ListEmptyComponent={<View style={styles.empty}><Icon name="document-text-outline" size={36} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.empty}</Text></View>}
          renderItem={({ item }) => <View style={styles.dependencyRow}><View style={[styles.statusDot, { backgroundColor: item.installed ? colors.success : colors.warning }]} /><View style={{ flex: 1 }}><Text style={styles.packageName}>{item.name}</Text><Text style={styles.description}>{copy.version}: {item.version}</Text></View><StatusPill label={`${copy.packageJson} · ${item.installed ? copy.onDisk : copy.missing}`} tone={item.installed ? 'success' : 'warning'} />{!item.installed ? <IconButton name="download-outline" onPress={() => install(item.name)} style={{ width: 38, minWidth: 38, height: 38 }} /> : null}</View>}
        />
      )}
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  controls: { padding: 12, gap: 10, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  categories: { gap: 6 },
  category: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 8, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  categoryActive: { backgroundColor: c.primarySurface, borderColor: c.primary },
  categoryText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' },
  categoryTextActive: { color: c.primary },
  error: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 10, borderRadius: 8, backgroundColor: c.errorBg },
  errorText: { color: c.errorText, fontSize: 10, lineHeight: 15, flex: 1, fontFamily: 'monospace' },
  list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 12, paddingBottom: 40 },
  card: { flex: 1, minWidth: 0, backgroundColor: c.bgCard, borderRadius: 13, borderWidth: 1, borderColor: c.border, padding: 13, marginBottom: 10 },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 54 },
  packageIcon: { width: 40, height: 40, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface },
  packageName: { color: c.text, fontFamily: 'monospace', fontSize: 12, fontWeight: '700' },
  description: { color: c.textSecondary, fontSize: 10, lineHeight: 15, marginTop: 3 },
  cardFooter: { marginTop: 11, paddingTop: 10, borderTopWidth: 1, borderTopColor: c.border, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  installLink: { flexDirection: 'row', alignItems: 'center', gap: 5, padding: 5 },
  installText: { color: c.primary, fontSize: 10, fontWeight: '700' },
  dependencyList: { width: '100%', maxWidth: 900, alignSelf: 'center', padding: 12, paddingBottom: 40 },
  dependencyRow: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 11, paddingHorizontal: 13, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.border, borderRadius: 11, marginBottom: 7 },
  statusDot: { width: 9, height: 9, borderRadius: 5 },
  empty: { flex: 1, minHeight: 260, alignItems: 'center', justifyContent: 'center', gap: 10 },
  emptyText: { color: c.textSecondary, fontSize: 12 },
});

export default LibrariesScreen;
