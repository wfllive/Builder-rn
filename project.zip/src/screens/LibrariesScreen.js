import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, Field, IconButton, PrimaryButton, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import { useProject } from '../store/projectStore';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';
import { syncComposeProject } from '../utils/composeProject';

const catalog = [
  { coordinate: 'io.coil-kt.coil3:coil-compose:3.3.0', icon: 'image-outline', category: 'UI', ru: 'Загрузка изображений Coil', en: 'Coil image loading' },
  { coordinate: 'androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0', icon: 'layers-outline', category: 'Architecture', ru: 'ViewModel для Compose', en: 'Compose ViewModel integration' },
  { coordinate: 'androidx.lifecycle:lifecycle-runtime-compose:2.10.0', icon: 'pulse-outline', category: 'Architecture', ru: 'Lifecycle-aware state', en: 'Lifecycle-aware state' },
  { coordinate: 'androidx.room:room-runtime:2.8.4', icon: 'server-outline', category: 'Storage', ru: 'Локальная база Room', en: 'Room local database' },
  { coordinate: 'androidx.room:room-ktx:2.8.4', icon: 'code-slash-outline', category: 'Storage', ru: 'Kotlin extensions для Room', en: 'Room Kotlin extensions' },
  { coordinate: 'com.squareup.retrofit2:retrofit:3.0.0', icon: 'swap-horizontal-outline', category: 'Network', ru: 'Типобезопасный HTTP-клиент', en: 'Type-safe HTTP client' },
  { coordinate: 'com.squareup.okhttp3:logging-interceptor:5.1.0', icon: 'terminal-outline', category: 'Network', ru: 'Логи HTTP-запросов', en: 'HTTP request logging' },
  { coordinate: 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2', icon: 'git-network-outline', category: 'Kotlin', ru: 'Kotlin Coroutines', en: 'Kotlin Coroutines' },
  { coordinate: 'org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0', icon: 'document-text-outline', category: 'Kotlin', ru: 'JSON сериализация', en: 'JSON serialization' },
  { coordinate: 'com.google.accompanist:accompanist-permissions:0.37.3', icon: 'shield-checkmark-outline', category: 'Device', ru: 'Разрешения Android в Compose', en: 'Android permissions for Compose' },
  { coordinate: 'com.google.maps.android:maps-compose:6.7.2', icon: 'map-outline', category: 'Device', ru: 'Google Maps Compose', en: 'Google Maps Compose' },
];
const categories = ['All', 'UI', 'Architecture', 'Storage', 'Network', 'Kotlin', 'Device'];
const validCoordinate = (value) => /^[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+:[A-Za-z0-9_.+\-]+$/.test(value.trim());

const LibrariesScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, language, t } = useAppSettings();
  const { currentProject, dispatch } = useProject();
  const [tab, setTab] = useState('catalog');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [custom, setCustom] = useState('');
  const [resolved, setResolved] = useState({});
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1050 ? 3 : width >= 680 ? 2 : 1;
  const copy = language === 'ru' ? {
    title: 'Gradle-библиотеки', subtitle: 'Maven-зависимости app/build.gradle.kts', catalog: 'Каталог', installed: 'Подключённые',
    search: 'Поиск Maven-зависимостей', custom: 'group:artifact:version', add: 'Подключить', remove: 'Удалить',
    declared: 'В Gradle', cached: 'Загружена', unresolved: 'Не загружена', refresh: 'Проверить Gradle cache',
    resolve: 'Загрузить зависимости', invalid: 'Введите Maven coordinate в формате group:artifact:version', noProject: 'Сначала откройте Compose-проект.',
    removeTitle: 'Удалить библиотеку?', removeText: 'Зависимость будет удалена из app/build.gradle.kts.', empty: 'Дополнительные библиотеки не подключены',
  } : {
    title: 'Gradle libraries', subtitle: 'Maven dependencies in app/build.gradle.kts', catalog: 'Catalog', installed: 'Connected',
    search: 'Search Maven dependencies', custom: 'group:artifact:version', add: 'Connect', remove: 'Remove', declared: 'In Gradle',
    cached: 'Resolved', unresolved: 'Not resolved', refresh: 'Check Gradle cache', resolve: 'Resolve dependencies',
    invalid: 'Enter a Maven coordinate as group:artifact:version', noProject: 'Open a Compose project first.', removeTitle: 'Remove library?',
    removeText: 'The dependency will be removed from app/build.gradle.kts.', empty: 'No additional libraries connected',
  };
  const declared = currentProject?.gradleDependencies || [];

  const checkCache = useCallback(async () => {
    if (!currentProject) return;
    const next = {};
    for (const coordinate of declared) {
      const [group, artifact, version] = coordinate.split(':');
      const result = await execute(`[ -d "$HOME/.gradle/caches/modules-2/files-2.1/${group}/${artifact}/${version}" ] && printf yes || true`, getProjectDir(currentProject));
      next[coordinate] = result.output?.includes('yes');
    }
    setResolved(next);
  }, [currentProject?.id, JSON.stringify(declared)]);
  useEffect(() => { checkCache(); }, [checkCache]);

  const updateDependencies = async (nextDependencies) => {
    const updated = { ...currentProject, gradleDependencies: nextDependencies, updatedAt: Date.now() };
    dispatch({ type: 'UPDATE_PROJECT', payload: updated });
    const result = await syncComposeProject(updated);
    if (!result.success) throw new Error(result.output || 'Gradle file update failed');
    return updated;
  };
  const add = async (coordinate) => {
    const value = coordinate.trim();
    if (!validCoordinate(value)) { Alert.alert(copy.invalid); return; }
    if (declared.includes(value)) return;
    setBusy(value); setError('');
    try { await updateDependencies([...declared, value]); setCustom(''); }
    catch (err) { setError(err?.message || String(err)); }
    finally { setBusy(null); }
  };
  const remove = (coordinate) => Alert.alert(copy.removeTitle, `${coordinate}\n\n${copy.removeText}`, [
    { text: t('cancel'), style: 'cancel' },
    { text: copy.remove, style: 'destructive', onPress: async () => {
      setBusy(coordinate);
      try { await updateDependencies(declared.filter((item) => item !== coordinate)); }
      catch (err) { setError(err?.message || String(err)); }
      finally { setBusy(null); }
    } },
  ]);
  const resolveAll = async () => {
    setBusy('resolve'); setError('');
    const result = await execute('chmod +x gradlew && ./gradlew :app:dependencies --configuration debugRuntimeClasspath --console=plain', getProjectDir(currentProject));
    if (!result.success) setError(result.output || 'Gradle dependency resolution failed');
    await checkCache(); setBusy(null);
  };

  if (!currentProject) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View style={styles.empty}><Text style={styles.emptyText}>{copy.noProject}</Text></View></AppScreen>;
  const filtered = catalog.filter((item) => (category === 'All' || item.category === category) && `${item.coordinate} ${item[language]}`.toLowerCase().includes(query.toLowerCase()));
  const installedRows = declared.filter((item) => item.toLowerCase().includes(query.toLowerCase()));
  const card = ({ item }) => {
    const connected = declared.includes(item.coordinate);
    return <View style={styles.card}><View style={styles.cardHead}><View style={styles.packageIcon}><Icon name={item.icon} size={21} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.coordinate} numberOfLines={2}>{item.coordinate}</Text><Text style={styles.description}>{item[language]}</Text></View></View><View style={styles.cardFooter}>{connected ? <StatusPill label={resolved[item.coordinate] ? copy.cached : copy.declared} tone={resolved[item.coordinate] ? 'success' : 'info'} /> : <StatusPill label={item.category} />}{connected ? <IconButton name="trash-outline" danger onPress={() => remove(item.coordinate)} style={styles.action} /> : <Pressable onPress={() => add(item.coordinate)} style={styles.addLink}><Icon name="add-circle-outline" size={15} color={colors.primary} /><Text style={styles.addText}>{copy.add}</Text></Pressable>}</View></View>;
  };

  return <AppScreen>
    <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="refresh-outline" label={width >= 700 ? copy.refresh : null} onPress={checkCache} />} />
    <View style={styles.controls}><SegmentedControl value={tab} onChange={setTab} options={[{ value: 'catalog', label: copy.catalog, icon: 'grid-outline' }, { value: 'installed', label: `${copy.installed} (${declared.length})`, icon: 'list-outline' }]} /><View style={[styles.searchRow, width < 620 && styles.mobile]}><Field value={query} onChangeText={setQuery} placeholder={copy.search} style={{ flex: 1 }} /><View style={styles.customRow}><Field value={custom} onChangeText={setCustom} placeholder={copy.custom} autoCapitalize="none" style={{ flex: 1 }} /><PrimaryButton title={width >= 640 ? copy.add : ''} icon="add" loading={busy === custom.trim()} disabled={!custom.trim()} onPress={() => add(custom)} /></View></View>{tab === 'catalog' ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categories}>{categories.map((item) => <Pressable key={item} onPress={() => setCategory(item)} style={[styles.category, category === item && styles.categoryActive]}><Text style={[styles.categoryText, category === item && styles.categoryTextActive]}>{item}</Text></Pressable>)}</ScrollView> : <PrimaryButton title={copy.resolve} icon="cloud-download-outline" loading={busy === 'resolve'} onPress={resolveAll} />}{error ? <View style={styles.errorBox}><Text selectable style={styles.errorText}>{error}</Text></View> : null}</View>
    {tab === 'catalog' ? <FlatList key={columns} numColumns={columns} data={filtered} renderItem={card} keyExtractor={(item) => item.coordinate} columnWrapperStyle={columns > 1 ? { gap: 10 } : null} contentContainerStyle={styles.list} /> : <FlatList data={installedRows} keyExtractor={(item) => item} contentContainerStyle={styles.installedList} ListEmptyComponent={<View style={styles.empty}><Icon name="cube-outline" size={36} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.empty}</Text></View>} renderItem={({ item }) => <View style={styles.row}><View style={[styles.dot, { backgroundColor: resolved[item] ? colors.success : colors.warning }]} /><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.coordinate} numberOfLines={2}>{item}</Text><Text style={styles.description}>implementation({JSON.stringify(item)})</Text></View><StatusPill label={resolved[item] ? copy.cached : copy.unresolved} tone={resolved[item] ? 'success' : 'warning'} /><IconButton name="trash-outline" danger onPress={() => remove(item)} style={styles.action} /></View>} />}
  </AppScreen>;
};

const createStyles = (c) => StyleSheet.create({
  controls: { padding: 12, gap: 9, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border }, searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8 }, mobile: { flexDirection: 'column', alignItems: 'stretch' }, customRow: { flex: 1, minWidth: 0, flexDirection: 'row', gap: 8, alignItems: 'center' }, categories: { gap: 6 }, category: { paddingHorizontal: 11, paddingVertical: 7, borderRadius: 8, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border }, categoryActive: { backgroundColor: c.primarySurface, borderColor: c.primary }, categoryText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' }, categoryTextActive: { color: c.primary }, errorBox: { padding: 10, borderRadius: 8, backgroundColor: c.errorBg }, errorText: { color: c.errorText, fontFamily: 'monospace', fontSize: 9 }, list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 12, paddingBottom: 40 }, card: { flex: 1, minWidth: 0, padding: 13, marginBottom: 10, borderRadius: 13, borderWidth: 1, borderColor: c.border, backgroundColor: c.bgCard }, cardHead: { minHeight: 58, flexDirection: 'row', alignItems: 'center', gap: 10 }, packageIcon: { width: 40, height: 40, borderRadius: 11, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, coordinate: { color: c.text, fontFamily: 'monospace', fontSize: 10, lineHeight: 14, fontWeight: '700' }, description: { color: c.textSecondary, fontSize: 9, lineHeight: 14, marginTop: 3 }, cardFooter: { marginTop: 10, paddingTop: 9, borderTopWidth: 1, borderTopColor: c.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, addLink: { padding: 6, flexDirection: 'row', alignItems: 'center', gap: 5 }, addText: { color: c.primary, fontSize: 10, fontWeight: '700' }, action: { width: 36, minWidth: 36, height: 36, paddingHorizontal: 0 }, installedList: { width: '100%', maxWidth: 900, alignSelf: 'center', padding: 12, paddingBottom: 40 }, row: { minHeight: 66, padding: 11, marginBottom: 7, borderRadius: 11, borderWidth: 1, borderColor: c.border, backgroundColor: c.bgCard, flexDirection: 'row', alignItems: 'center', gap: 9 }, dot: { width: 9, height: 9, borderRadius: 5 }, empty: { flex: 1, minHeight: 280, alignItems: 'center', justifyContent: 'center', gap: 9 }, emptyText: { color: c.textSecondary, fontSize: 12 },
});
export default LibrariesScreen;
