import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { execute, isAvailable } from '../utils/shellExecutor';
import { createJavaProject, isNcsReady } from '../utils/ncsBuild';
import AdsBanner from '../components/AdsBanner';
import { cn } from "../utils/cn";

const CONTENT_MAX_WIDTH = 1180;

const getGutter = (width: number) => {
  if (width < 360) return 14;
  if (width < 430) return 16;
  if (width < 720) return 20;
  return 24;
};

interface ProjectInfo {
  name: string;
  path: string;
  type: 'ncs-java' | 'gradle-kotlin';
  packageName?: string;
  updatedAt?: number;
}

const ProjectsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const { colors, language } = useAppSettings();
  const [projects, setProjects] = useState<ProjectInfo[]>([]);
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [packageName, setPackageName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createLog, setCreateLog] = useState('');
  const [projectType, setProjectType] = useState<'ncs-java' | 'gradle-kotlin'>('ncs-java');
  const [ncsReady, setNcsReady] = useState(false);

  const compact = width < 430;
  const tiny = width < 360;
  const gutter = getGutter(width);
  const padLeft = Math.max(gutter, insets.left);
  const padRight = Math.max(gutter, insets.right);
  const columns = width >= 1180 ? 3 : width >= 720 ? 2 : 1;
  const cardGap = compact ? 10 : 14;
  const stackDialogButtons = width < 560;

  const styles = useMemo(() => createStyles(colors, compact), [colors, compact]);
  const ru = language === 'ru';

  const copy = {
    title: 'NCS Studio',
    subtitle: ru ? 'Java + XML · сборка за 2-8 секунд без Gradle' : 'Java + XML · builds in 2-8 seconds without Gradle',
    recent: ru ? 'Ваши проекты' : 'Your projects',
    empty: ru ? 'Создайте своё первое Android-приложение на Java + XML' : 'Create your first Android app in Java + XML',
    longPress: ru ? 'Удерживайте карточку для удаления' : 'Long-press a card to delete',
    deleteTitle: ru ? 'Удалить проект?' : 'Delete project?',
    deleteText: ru ? 'Файлы проекта будут удалены.' : 'Project files will be deleted.',
    createFailed: ru ? 'Не удалось создать проект' : 'Failed to create project',
    ncsReady: ru ? '✅ NCS Build готов' : '✅ NCS Build ready',
    ncsNotReady: ru ? '⚠️ Требуется установка NCS Build' : '⚠️ NCS Build needs to be installed',
    projectName: ru ? 'Название приложения' : 'Application name',
    packageId: ru ? 'Package name (Application ID)' : 'Package name (Application ID)',
    projectType: ru ? 'Тип проекта' : 'Project type',
    typeJava: ru ? '⚡ Java + XML (NCS Build, быстро)' : '⚡ Java + XML (NCS Build, fast)',
    typeKotlin: ru ? '🐢 Kotlin + Compose (Gradle, медленно)' : '🐢 Kotlin + Compose (Gradle, slow)',
    createJava: ru ? 'Создать Java проект' : 'Create Java project',
    structure: ru ? 'Структура проекта' : 'Project structure',
    building: ru ? 'Создаём проект...' : 'Creating project...',
    cancel: ru ? 'Отмена' : 'Cancel',
    create: ru ? 'Создать' : 'Create',
    buildButton: ru ? 'Собрать APK' : 'Build APK',
    openButton: ru ? 'Открыть редактор' : 'Open editor',
    noProjects: ru ? 'Нет проектов' : 'No projects',
    fastBuild: ru ? 'Быстрая сборка' : 'Fast build',
    javaXml: ru ? 'Java + XML' : 'Java + XML',
    installed: ru ? 'Установить NCS' : 'Install NCS',
  };

  // Сканируем проекты при открытии экрана
  const refreshProjects = useCallback(async () => {
    if (!isAvailable()) return;
    try {
      const result = await execute(`
        echo "===SCAN==="
        if [ -d ~/projects ]; then
          for d in ~/projects/*/; do
            if [ -f "$d/ncs-project.toml" ]; then
              echo "NCS:$(basename "$d"):$d"
            elif [ -f "$d/settings.gradle.kts" ] || [ -f "$d/settings.gradle" ]; then
              echo "GRADLE:$(basename "$d"):$d"
            fi
          done
        fi
      `);
      
      const projectsList: ProjectInfo[] = [];
      const lines = result.split('\n');
      for (const line of lines) {
        if (line.startsWith('NCS:')) {
          const parts = line.split(':');
          projectsList.push({
            name: parts[1],
            path: parts.slice(2).join(':'),
            type: 'ncs-java',
          });
        } else if (line.startsWith('GRADLE:')) {
          const parts = line.split(':');
          projectsList.push({
            name: parts[1],
            path: parts.slice(2).join(':'),
            type: 'gradle-kotlin',
          });
        }
      }
      setProjects(projectsList);
    } catch (e) {
      console.error('Failed to scan projects', e);
    }
  }, []);

  useEffect(() => {
    refreshProjects();
    isNcsReady().then(setNcsReady);
  }, [refreshProjects]);

  const openProject = (project: ProjectInfo) => {
    // Для Java+XML проектов открываем в редакторе, сразу показываем activity_main.xml
    if (project.type === 'ncs-java') {
      navigation.navigate('Editor', {
        projectPath: project.path,
        projectType: project.type,
        initialFile: `${project.path}/app/src/main/res/layout/activity_main.xml`,
      });
    } else {
      // @ts-ignore
      navigation.navigate('Editor', { projectPath: project.path, projectType: project.type });
    }
  };

  const buildProject = async (project: ProjectInfo) => {
    if (project.type === 'ncs-java') {
      // Быстрая NCS сборка для Java+XML
      navigation.navigate('NcsBuild', {
        projectPath: project.path,
        projectName: project.name,
      });
    } else {
      // Старая Gradle сборка для Kotlin+Compose
      navigation.navigate('Build', { projectPath: project.path, projectType: project.type });
    }
  };

  const askDelete = (project: ProjectInfo) => Alert.alert(copy.deleteTitle, copy.deleteText, [
    { text: copy.cancel, style: 'cancel' },
    {
      text: ru ? 'Удалить' : 'Delete',
      style: 'destructive',
      onPress: async () => {
        try {
          await execute(`rm -rf "${project.path}"`);
          refreshProjects();
        } catch (e) {
          Alert.alert('Error', String(e));
        }
      }
    }
  ]);

  const create = async () => {
    const cleanName = name.trim();
    if (!cleanName || creating) return;
    
    const suggestedPkg = packageName.trim() || `com.example.${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(suggestedPkg)) {
      Alert.alert('Package name', 'Example: com.example.myapp');
      return;
    }

    setCreating(true);
    setCreateLog(copy.building);
    let success = false;

    try {
      if (projectType === 'ncs-java') {
        setCreateLog(prev => prev + '\n→ Создаём Java+XML проект...');
        success = await createJavaProject(cleanName, suggestedPkg, (line) => {
          setCreateLog(prev => prev + '\n' + line);
        });
      } else {
        // Legacy Gradle/Kotlin
        setCreateLog(prev => prev + '\n→ Создаём Gradle Kotlin+Compose проект...');
        const { raiNew } = require('../utils/rai');
        const res = await raiNew(cleanName, suggestedPkg);
        success = res?.success;
        setCreateLog(prev => prev + '\n' + (res?.output || ''));
      }

      if (success) {
        setCreateLog(prev => prev + '\n✅ Проект создан!');
        await new Promise(res => setTimeout(res, 800));
        setName('');
        setPackageName('');
        setCreateOpen(false);
        setCreateLog('');
        await refreshProjects();
        // Открываем созданный проект
        const newProj = projects.find(p => p.name === cleanName);
        if (newProj) openProject(newProj);
      } else {
        setCreateLog(prev => prev + '\n❌ Ошибка создания проекта');
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setCreateLog(prev => prev + '\n❌ ' + message);
      Alert.alert(copy.createFailed, message.slice(0, 500));
    } finally {
      setCreating(false);
    }
  };

  const installNcs = async () => {
    setCreating(true);
    setCreateLog('⚡ Устанавливаем NCS Build (быстрая среда, ~300 МБ)...\n');
    try {
      const { installNcsFast } = require('../utils/ncsBuild');
      const ok = await installNcsFast((line) => {
        setCreateLog(prev => prev + line + '\n');
      });
      if (ok) {
        setCreateLog(prev => prev + '\n✅ NCS Build установлен!');
        setNcsReady(true);
      }
    } catch (e) {
      setCreateLog(prev => prev + '\n❌ ' + String(e));
    } finally {
      setCreating(false);
    }
  };

  const filtered = projects.filter(p => p.name.toLowerCase().includes(search.trim().toLowerCase()));

  const renderProject = useCallback(({ item }) => (
    <Pressable
      onPress={() => openProject(item)}
      onLongPress={() => askDelete(item)}
      className={cn(styles.card, 'active:border-primary')}
      style={{ marginBottom: cardGap }}
    >
      <View style={styles.cardTop}>
        <View style={styles.projectIcon}>
          <Icon
            name={item.type === 'ncs-java' ? 'code-slash' : 'logo-react'}
            size={24}
            color={colors.primary}
          />
        </View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.projectName} numberOfLines={1}>{item.name}</Text>
          <Text style={styles.path} numberOfLines={1}>{item.path}</Text>
        </View>
      </View>

      <View style={styles.metaRow}>
        <StatusPill
          label={item.type === 'ncs-java' ? '⚡ Java+XML' : '🐢 Kotlin+Compose'}
          tone={item.type === 'ncs-java' ? 'success' : 'warning'}
        />
        <StatusPill label={item.type === 'ncs-java' ? 'NCS Build' : 'Gradle'} tone="info" />
      </View>

      <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
        <Pressable
          onPress={(e) => { e.stopPropagation(); openProject(item); }}
          style={[styles.smallBtn, { backgroundColor: colors.bgElevated }]}
        >
          <Icon name="create-outline" size={16} color={colors.text} />
          <Text style={[styles.smallBtnText, { color: colors.text }]}>{copy.openButton}</Text>
        </Pressable>
        <Pressable
          onPress={(e) => { e.stopPropagation(); buildProject(item); }}
          style={[styles.smallBtn, { backgroundColor: colors.primary }]}
        >
          <Icon name="hammer-outline" size={16} color="#FFFFFF" />
          <Text style={[styles.smallBtnText, { color: '#FFFFFF' }]}>{copy.buildButton}</Text>
        </Pressable>
      </View>
    </Pressable>
  ), [styles, colors, cardGap, copy]);

  return (
    <AppScreen>
      <View style={[styles.header, { paddingLeft: padLeft, paddingRight: padRight }]}>
        {!tiny ? (
          <View style={styles.brand}>
            <Icon name="code-slash" size={compact ? 22 : 25} color="#FFFFFF" />
          </View>
        ) : null}
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.title} numberOfLines={1}>{compact ? 'NCS Studio' : copy.title}</Text>
          {width >= 520 ? <Text style={styles.subtitle} numberOfLines={1}>{copy.subtitle}</Text> : null}
        </View>
        <View style={styles.actions}>
          {__DEV__ ? (
            <IconButton name="terminal-outline" onPress={() => navigation.navigate('Terminal')} />
          ) : null}
          <IconButton name="settings-outline" onPress={() => navigation.navigate('AppSettings')} />
          
          {width >= 520 ? (
            <PrimaryButton
              title={ru ? '+ Новый проект' : '+ New project'}
              icon="add"
              onPress={() => setCreateOpen(true)}
            />
          ) : (
            <Pressable
              onPress={() => setCreateOpen(true)}
              hitSlop={4}
              style={[styles.fabBtn, { backgroundColor: colors.primary }]}
            >
              <Icon name="add" size={24} color="#FFFFFF" />
            </Pressable>
          )}
        </View>
      </View>

      <View style={[styles.searchWrap, { paddingLeft: padLeft, paddingRight: padRight, maxWidth: CONTENT_MAX_WIDTH }]}>
        <Icon name="search-outline" size={18} color={colors.textTertiary} />
        <View style={{ flex: 1, minWidth: 0 }}>
          <Field
            value={search}
            onChangeText={setSearch}
            placeholder={ru ? 'Поиск проектов...' : 'Search projects...'}
            style={{ width: '100%' }}
          />
        </View>
        {search ? (
          <IconButton name="close" onPress={() => setSearch('')} style={{ borderWidth: 0, backgroundColor: colors.bg }} />
        ) : null}
      </View>

      {!ncsReady && isAvailable() ? (
        <View style={[styles.setupBanner, { marginHorizontal: padLeft }]}>
          <Icon name="construct-outline" size={22} color={colors.warning} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.bannerTitle, { color: colors.text }]}>
              {ru ? 'Установите NCS Build для быстрой сборки' : 'Install NCS Build for fast builds'}
            </Text>
            <Text style={[styles.bannerText, { color: colors.textSecondary }]}>
              {ru ? 'Займет ~1 минуту и ~300 МБ места' : 'Takes ~1 minute and ~300 MB'}
            </Text>
          </View>
          <Pressable onPress={installNcs} style={[styles.smallBtn, { backgroundColor: colors.primary }]}>
            <Text style={[styles.smallBtnText, { color: '#FFFFFF' }]}>{copy.installed}</Text>
          </Pressable>
        </View>
      ) : null}

      {filtered.length ? (
        <FlatList
          key={columns}
          numColumns={columns}
          data={filtered}
          keyExtractor={item => item.path}
          renderItem={renderProject}
          showsVerticalScrollIndicator={false}
          style={{ flex: 1 }}
          columnWrapperStyle={columns > 1 ? { gap: cardGap } : undefined}
          contentContainerStyle={{
            width: '100%',
            maxWidth: CONTENT_MAX_WIDTH,
            alignSelf: 'center',
            paddingLeft: padLeft,
            paddingRight: padRight,
            paddingTop: compact ? 10 : 14,
            paddingBottom: 36 + insets.bottom,
          }}
          ListHeaderComponent={
            <View style={{ marginBottom: 12, gap: 3 }}>
              <Text style={styles.sectionTitle} numberOfLines={1}>{copy.recent}</Text>
              <Text style={styles.hint} numberOfLines={1}>{copy.longPress}</Text>
            </View>
          }
        />
      ) : (
        <View style={[styles.empty, { paddingLeft: padLeft + 8, paddingRight: padRight + 8 }]}>
          <View style={styles.emptyIcon}>
            <Icon name="code-slash" size={40} color={colors.primary} />
          </View>
          <Text style={styles.emptyTitle}>{copy.noProjects}</Text>
          <Text style={styles.emptyText}>{copy.empty}</Text>
          <PrimaryButton
            title={ru ? '+ Создать первый проект' : '+ Create first project'}
            icon="add"
            onPress={() => setCreateOpen(true)}
            style={{ marginTop: 8 }}
          />
        </View>
      )}

      <Modal
        visible={createOpen}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => !creating && setCreateOpen(false)}
      >
        <KeyboardAvoidingView
          style={styles.overlay}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            contentContainerStyle={{
              flexGrow: 1,
              justifyContent: 'center',
              paddingLeft: padLeft,
              paddingRight: padRight,
              paddingTop: Math.max(insets.top, 16),
              paddingBottom: Math.max(insets.bottom, 16),
            }}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <View style={{ width: '100%', maxWidth: 560, alignSelf: 'center' }}>
              <SectionCard style={styles.dialog} title={ru ? 'Новый проект' : 'New project'} icon="add-circle">
                <Field
                  label={copy.projectName}
                  value={name}
                  onChangeText={setName}
                  autoFocus={!creating}
                  editable={!creating}
                  placeholder="MyApp"
                />
                <Field
                  label={copy.packageId}
                  value={packageName}
                  onChangeText={setPackageName}
                  autoCapitalize="none"
                  editable={!creating}
                  placeholder="com.example.myapp"
                />

                <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>{copy.projectType}</Text>
                <View style={{ gap: 8, marginBottom: 12 }}>
                  <Pressable
                    onPress={() => setProjectType('ncs-java')}
                    style={[
                      styles.typeOption,
                      projectType === 'ncs-java' && styles.typeOptionSelected,
                      { borderColor: projectType === 'ncs-java' ? colors.primary : colors.border, backgroundColor: projectType === 'ncs-java' ? colors.primarySurface : colors.bg }
                    ]}
                  >
                    <Text style={styles.typeEmoji}>⚡</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.typeTitle, { color: colors.text, fontWeight: '700' }]}>{copy.typeJava}</Text>
                      <Text style={[styles.typeDesc, { color: colors.textSecondary }]}>
                        {ru ? 'Сборка 2-8 сек · нет Gradle · мгновенный XML предпросмотр' : 'Builds in 2-8s · no Gradle · instant XML preview'}
                      </Text>
                    </View>
                    {projectType === 'ncs-java' && <Icon name="checkmark-circle" size={22} color={colors.primary} />}
                  </Pressable>

                  <Pressable
                    onPress={() => setProjectType('gradle-kotlin')}
                    style={[
                      styles.typeOption,
                      projectType === 'gradle-kotlin' && styles.typeOptionSelected,
                      { borderColor: projectType === 'gradle-kotlin' ? colors.warning : colors.border, backgroundColor: projectType === 'gradle-kotlin' ? colors.warningBg : colors.bg }
                    ]}
                  >
                    <Text style={styles.typeEmoji}>🐢</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.typeTitle, { color: colors.text, fontWeight: '700' }]}>{copy.typeKotlin}</Text>
                      <Text style={[styles.typeDesc, { color: colors.textSecondary }]}>
                        {ru ? 'Сборка 30-90 сек · для совместимости со старыми проектами' : '30-90s builds · for legacy Compose projects'}
                      </Text>
                    </View>
                    {projectType === 'gradle-kotlin' && <Icon name="checkmark-circle" size={22} color={colors.warning} />}
                  </Pressable>
                </View>

                <View style={styles.commandBox}>
                  <Text style={styles.commandLabel}>{copy.structure}</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    <Text selectable style={styles.command}>{
                      projectType === 'ncs-java'
                        ? `~/projects/${name || 'my-app'}/\n├── ncs-project.toml\n├── app/\n│   ├── src/main/\n│   │   ├── AndroidManifest.xml\n│   │   ├── java/.../MainActivity.java\n│   │   └── res/\n│   │       ├── layout/activity_main.xml\n│   │       └── values/{colors,strings,themes}.xml\n└── build/outputs/*.apk`
                        : `~/projects/${name || 'my-app'}/\n├── settings.gradle.kts\n├── build.gradle.kts\n├── gradlew\n└── app/src/main/java/.../MainActivity.kt`
                    }</Text>
                  </ScrollView>
                </View>

                {createLog ? (
                  <ScrollView nestedScrollEnabled style={{ maxHeight: 140 }} contentContainerStyle={styles.logBox}>
                    <Text selectable style={styles.logText}>{createLog}</Text>
                  </ScrollView>
                ) : null}

                <View style={stackDialogButtons ? { flexDirection: 'column', gap: 8 } : { flexDirection: 'row', gap: 9 }}>
                  <IconButton
                    name="close"
                    label={copy.cancel}
                    disabled={creating}
                    onPress={() => { setCreateOpen(false); setName(''); setPackageName(''); setCreateLog(''); }}
                    style={stackDialogButtons ? { width: '100%' } : { flex: 1 }}
                  />
                  <PrimaryButton
                    title={copy.create}
                    icon="arrow-forward"
                    loading={creating}
                    disabled={!name.trim() || creating}
                    onPress={create}
                    style={stackDialogButtons ? { width: '100%' } : { flex: 1 }}
                  />
                </View>
              </SectionCard>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>

      <AdsBanner />
    </AppScreen>
  );
};

const createStyles = (c, compact) => ({
  header: [
    compact ? "min-h-[64px] py-[8px] flex-row items-center gap-[8px] bg-bg-card border-b border-b-border" : "min-h-[76px] py-[10px] flex-row items-center gap-[12px] bg-bg-card border-b border-b-border",
  ],
  brand: compact ? "w-[38px] h-[38px] rounded-[11px] items-center justify-center bg-primary shrink-0" : "w-[44px] h-[44px] rounded-[13px] items-center justify-center bg-primary shrink-0",
  title: compact ? "text-text text-[16px] font-bold" : "text-text text-[19px] font-bold",
  subtitle: "text-text-secondary text-[11px] mt-[2px]",
  actions: "flex-row items-center gap-[7px] shrink-0",
  fabBtn: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  searchWrap: "w-full self-center flex-row items-center gap-[8px] pt-[10px]",
  setupBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    marginTop: 10,
    borderRadius: 12,
    backgroundColor: c.warningBg,
    maxWidth: CONTENT_MAX_WIDTH,
    alignSelf: 'center',
    width: '100%',
  },
  bannerTitle: { fontSize: 13, fontWeight: '700' },
  bannerText: { fontSize: 11, marginTop: 2 },
  sectionTitle: "text-text text-[15px] font-bold",
  hint: "text-text-tertiary text-[10px]",
  card: "flex-1 min-w-0 bg-bg-card border border-border rounded-[14px] p-[15px]",
  cardTop: "flex-row items-center gap-[11px]",
  projectIcon: "w-[44px] h-[44px] items-center justify-center rounded-[12px] bg-primary-surface shrink-0",
  projectName: "text-text text-[15px] font-bold",
  path: "text-text-tertiary text-[9px] font-mono mt-[4px]",
  metaRow: "flex-row flex-wrap items-center gap-x-[10px] gap-y-[6px] mt-[14px] pt-[12px] border-t border-t-border",
  smallBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    flex: 1,
    justifyContent: 'center',
  },
  smallBtnText: { fontSize: 12, fontWeight: '700' },
  empty: "flex-1 items-center justify-center py-[24px]",
  emptyIcon: "w-[76px] h-[76px] rounded-[22px] items-center justify-center bg-primary-surface mb-[16px]",
  emptyTitle: "text-text text-[20px] font-bold text-center",
  emptyText: "text-text-secondary text-[13px] leading-[20px] text-center max-w-[430px] mt-[7px]",
  overlay: { flex: 1, backgroundColor: c.overlay },
  dialog: compact ? "w-full p-[14px]" : "w-full p-[20px]",
  fieldLabel: { fontSize: 11, fontWeight: '700', marginBottom: 6, marginTop: 8 },
  typeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderWidth: 2,
  },
  typeOptionSelected: {
    borderWidth: 2,
  },
  typeEmoji: { fontSize: 24 },
  typeTitle: { fontSize: 14 },
  typeDesc: { fontSize: 11, marginTop: 2 },
  commandBox: "rounded-[9px] p-[12px] bg-terminal overflow-hidden mb-2",
  commandLabel: "color: #8B98AD; fontSize: 10; marginBottom: 6",
  command: { color: '#DCE5F3', fontSize: 10, lineHeight: 16, fontFamily: 'monospace' },
  logBox: { borderRadius: 9, padding: 11, backgroundColor: c.bgElevated, marginBottom: 10 },
  logText: { color: c.textSecondary, fontFamily: 'monospace', fontSize: 10 },
});

export default ProjectsScreen;
