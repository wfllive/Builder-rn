import React
{ useCallback
useEffect
useMemo
useState } from 'react';
import { AppState
Pressable
ScrollView
Switch
Text
View } from 'react-native';
import { AppScreen
SectionCard
SegmentedControl
TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import {
  hasStorageAccess
openStorageSettings
requestStoragePermissions
  hasNotificationPermission
requestNotificationPermission
} from '../utils/background';
import { RAI_VERSION } from '../utils/raiSetup';
const AppSettingsScreen = ({ navigation }) => {
  const { colors
t
language
setLanguage
themeMode
setThemeMode
editor
setEditorSetting } = useAppSettings();
  const [storageGranted
setStorageGranted] = useState(false);
  const [notifGranted
setNotifGranted] = useState(true);
  const styles = useMemo(() => /* styles removed */(colors)
[colors]);
  const refreshPermissions = useCallback(async () => {
    setStorageGranted(await hasStorageAccess());
    setNotifGranted(await hasNotificationPermission());
  }
[]);
  useEffect(() => { refreshPermissions(); }
[refreshPermissions]);
  useEffect(() => {
    const sub = AppState.addEventListener('change'
(state) => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }
[refreshPermissions]);
  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions
600);
  };
  const grantNotif = async () => {
    const granted = await hasNotificationPermission();
    if (!granted) await requestNotificationPermission();
    setTimeout(refreshPermissions
600);
  };
  return (
    <AppScreen>
      <TopBar title={t('settings')} subtitle={t('appSubtitle')} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={className="page}>
        <View className="p-4">
          <SectionCard title={t('appearance')} icon="color-palette-outline">
            <Text className="p-4">{t('theme')}</Text>
            <SegmentedControl
              value={themeMode}
              onChange={setThemeMode}
              options={[
                { value: 'system'
label: t('system')
icon: 'phone-portrait-outline' }
                { value: 'light'
label: t('light')
icon: 'sunny-outline' }
                { value: 'dark'
label: t('dark')
icon: 'moon-outline' }
              ]}
            />
            <View className="p-4">
              <View className="p-4">
                <View className="p-4" />
                <View className="p-4">
                  <View className="p-4" />
                  <View style={{ flex: 1
gap: 7 }}><View className="p-4" /><View style={[className="previewLine
{ width: '62%' }]} /><View className="p-4" /></View>
                </View>
              </View>
              <Text className="p-4">
                {language === 'ru'
                  ? 'Контрастная палитра применяется ко всем экранам. Системные панели и заголовки остаются непрозрачными.'
                  : 'The high-contrast palette applies across the app. System bars and headers remain opaque.'}
              </Text>
            </View>
          </SectionCard>
          <SectionCard title={t('language')} icon="language-outline">
            <SegmentedControl
              value={language}
              onChange={setLanguage}
              options={[
                { value: 'ru'
label: t('russian') }
                { value: 'en'
label: t('english') }
              ]}
            />
            <Text className="p-4">
              {language === 'ru'
                ? 'Язык интерфейса сохраняется на устройстве и применяется сразу.'
                : 'The interface language is stored on this device and applied immediately.'}
            </Text>
          </SectionCard>
          <SectionCard title={language === 'ru' ? 'Дизайн предпросмотр (двойная защита)' : 'Design Preview (double guard)'} icon="eye-outline">
            <View className="p-4">
              <View style={{flex:1}}>
                <Text className="p-4">{language==='ru' ? 'Предпросмотр дизайна' : 'Design preview'}</Text>
                <Text className="p-4">{language==='ru' ? 'Рендер дерева в вкладке Дизайн / Превью' : 'Render tree in Design / Preview tabs'}</Text>
              </View>
              <Switch value={editor.designPreview !== false} onValueChange={(v)=>setEditorSetting('designPreview'
v)} trackColor={{false: colors.borderLight
true: colors.primary}} thumbColor="#FFFFFF" />
            </View>
            <View style={[className="toggleRow
{opacity: editor.designPreview===false ? 0.4 : 1}]}>
              <View style={{flex:1}}>
                <Text className="p-4">{language==='ru' ? 'Двойная защита' : 'Double guard'}</Text>
                <Text className="p-4">{language==='ru' ? 'Требовать подтверждение при включении (второй выключатель)' : 'Require confirmation when enabling (second switch)'}</Text>
              </View>
              <Switch value={!!editor.designPreviewGuard} onValueChange={(v)=>setEditorSetting('designPreviewGuard'
v)} disabled={editor.designPreview===false} trackColor={{false: colors.borderLight
true: colors.warning}} thumbColor="#FFFFFF" />
            </View>
            {!editor.designPreview ? (
              <View className="p-4"><Icon name="shield-outline" size={14} color={colors.warning} /><Text className="p-4">{language==='ru' ? 'Предпросмотр полностью выключен — Design/Preview покажут заглушку. Включите для рендера.' : 'Preview fully disabled — Design/Preview will show placeholder. Enable to render.'}</Text></View>
            ) : editor.designPreviewGuard ? (
              <View className="p-4"><Icon name="shield-checkmark-outline" size={14} color={colors.primary} /><Text className="p-4">{language==='ru' ? 'Двойная защита включена: предпросмотр потребует тап «Показать» при каждом открытии.' : 'Double guard on: preview will require tap "Show" on each open.'}</Text></View>
            ) : null}
          </SectionCard>
          <SectionCard title={language === 'ru' ? 'Память и фон' : 'Storage & background'} icon="folder-open-outline">
            <View className="p-4">
              <View className="flex-1">
                <Text className="p-4">{language === 'ru' ? 'Доступ к памяти' : 'Storage access'}</Text>
                <Text className="p-4">{language === 'ru' ? 'All files access — сохранение APK в /sdcard/Download и общий доступ к файлам' : 'All files access — save APKs to /sdcard/Download and share files'}</Text>
              </View>
              {storageGranted ? (
                <Icon name="checkmark-circle" size={20} color={colors.success} />
              ) : (
                <Pressable onPress={grantStorage} style={[className="smallBtn
{ backgroundColor: colors.primary }]}>
                  <Text className="p-4">{language === 'ru' ? 'Разрешить' : 'Grant'}</Text>
                </Pressable>
              )}
            </View>
            <View className="p-4">
              <View className="flex-1">
                <Text className="p-4">{language === 'ru' ? 'Уведомления о фоновых задачах' : 'Background task notifications'}</Text>
                <Text className="p-4">{language === 'ru' ? 'Статус установки/сборки
пока приложение свёрнуто' : 'Install/build status while the app is minimized'}</Text>
              </View>
              {notifGranted ? (
                <Icon name="checkmark-circle" size={20} color={colors.success} />
              ) : (
                <Pressable onPress={grantNotif} style={[className="smallBtn
{ backgroundColor: colors.primary }]}>
                  <Text className="p-4">{language === 'ru' ? 'Разрешить' : 'Allow'}</Text>
                </Pressable>
              )}
            </View>
            <View className="p-4">
              <Icon name="information-circle-outline" size={14} color={colors.info} />
              <Text className="p-4">{language === 'ru'
                ? 'Установка RAI и сборка APK продолжаются в фоне (foreground service). При закрытии приложения незавершённые шаги установки продолжатся при следующем запуске.'
                : 'RAI setup and APK builds keep running in the background (foreground service). If the app is closed
unfinished setup steps resume on the next launch.'}</Text>
            </View>
          </SectionCard>
          <SectionCard title={language === 'ru' ? 'О приложении' : 'About'} icon="information-circle-outline">
            <View className="p-4"><Text className="p-4">React Studio</Text><Text className="p-4">1.0.0</Text></View>
            <View className="p-4"><Text className="p-4">React</Text><Text className="p-4">19.2.8</Text></View>
            <View className="p-4"><Text className="p-4">Vite</Text><Text className="p-4">5.4.0</Text></View>
            <View className="p-4"><Text className="p-4">Android SDK</Text><Text className="p-4">API 37</Text></View>
            <View className="p-4"><Text className="p-4">SDK</Text><Text className="p-4">37.0.0 (обязателен)</Text></View>
            <View className="p-4"><Text className="p-4">RAI</Text><Text className="p-4">v{RAI_VERSION} (локально)</Text></View>
          </SectionCard>
        </View>
      </ScrollView>
    </AppScreen>
  );
};
// Tailwind className
export default AppSettingsScreen;