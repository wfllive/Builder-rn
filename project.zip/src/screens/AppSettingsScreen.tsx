import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AppState, Pressable, ScrollView, Switch, Text, View } from 'react-native';
import { AppScreen, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import { hasStorageAccess, openStorageSettings, requestStoragePermissions, hasNotificationPermission, requestNotificationPermission } from '../utils/background';
import { RAI_VERSION } from '../utils/raiSetup';
import { cn } from "../utils/cn";
const AppSettingsScreen = ({
  navigation
}) => {
  const {
    colors,
    t,
    language,
    setLanguage,
    themeMode,
    setThemeMode,
    editor,
    setEditorSetting
  } = useAppSettings();
  const [storageGranted, setStorageGranted] = useState(false);
  const [notifGranted, setNotifGranted] = useState(true);
  const styles = useMemo(() => createStyles(colors), [colors]);
  const refreshPermissions = useCallback(async () => {
    setStorageGranted(await hasStorageAccess());
    setNotifGranted(await hasNotificationPermission());
  }, []);
  useEffect(() => {
    refreshPermissions();
  }, [refreshPermissions]);
  useEffect(() => {
    const sub = AppState.addEventListener('change', state => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);
  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions, 600);
  };
  const grantNotif = async () => {
    const granted = await hasNotificationPermission();
    if (!granted) await requestNotificationPermission();
    setTimeout(refreshPermissions, 600);
  };
  return <AppScreen>
      <TopBar title={t('settings')} subtitle={t('appSubtitle')} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerClassName={styles.page}>
        <View className={styles.column}>
          <SectionCard title={t('appearance')} icon="color-palette-outline">
            <Text className={styles.label}>{t('theme')}</Text>
            <SegmentedControl value={themeMode} onChange={setThemeMode} options={[{
            value: 'system',
            label: t('system'),
            icon: 'phone-portrait-outline'
          }, {
            value: 'light',
            label: t('light'),
            icon: 'sunny-outline'
          }, {
            value: 'dark',
            label: t('dark'),
            icon: 'moon-outline'
          }]} />
            <View className={styles.previewRow}>
              <View className={styles.previewWindow}>
                <View className={styles.previewBar} />
                <View className={styles.previewBody}>
                  <View className={styles.previewSide} />
                  <View style={{
                  flex: 1,
                  gap: 7
                }}><View className={styles.previewLine} /><View className={styles.previewLine} style={{
                    width: '62%'
                  }} /><View className={styles.previewButton} /></View>
                </View>
              </View>
              <Text className={styles.description}>
                {language === 'ru' ? 'Контрастная палитра применяется ко всем экранам. Системные панели и заголовки остаются непрозрачными.' : 'The high-contrast palette applies across the app. System bars and headers remain opaque.'}
              </Text>
            </View>
          </SectionCard>

          <SectionCard title={t('language')} icon="language-outline">
            <SegmentedControl value={language} onChange={setLanguage} options={[{
            value: 'ru',
            label: t('russian')
          }, {
            value: 'en',
            label: t('english')
          }]} />
            <Text className={styles.description}>
              {language === 'ru' ? 'Язык интерфейса сохраняется на устройстве и применяется сразу.' : 'The interface language is stored on this device and applied immediately.'}
            </Text>
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'Дизайн предпросмотр (двойная защита)' : 'Design Preview (double guard)'} icon="eye-outline">
            <View className={styles.toggleRow}>
              <View style={{
              flex: 1
            }}>
                <Text className={styles.toggleTitle}>{language === 'ru' ? 'Предпросмотр дизайна' : 'Design preview'}</Text>
                <Text className={styles.toggleDesc}>{language === 'ru' ? 'Рендер дерева в вкладке Дизайн / Превью' : 'Render tree in Design / Preview tabs'}</Text>
              </View>
              <Switch value={editor.designPreview !== false} onValueChange={v => setEditorSetting('designPreview', v)} trackColor={{
              false: colors.borderLight,
              true: colors.primary
            }} thumbColor="#FFFFFF" />
            </View>
            <View className={styles.toggleRow} style={{
            opacity: editor.designPreview === false ? 0.4 : 1
          }}>
              <View style={{
              flex: 1
            }}>
                <Text className={styles.toggleTitle}>{language === 'ru' ? 'Двойная защита' : 'Double guard'}</Text>
                <Text className={styles.toggleDesc}>{language === 'ru' ? 'Требовать подтверждение при включении (второй выключатель)' : 'Require confirmation when enabling (second switch)'}</Text>
              </View>
              <Switch value={!!editor.designPreviewGuard} onValueChange={v => setEditorSetting('designPreviewGuard', v)} disabled={editor.designPreview === false} trackColor={{
              false: colors.borderLight,
              true: colors.warning
            }} thumbColor="#FFFFFF" />
            </View>
            {!editor.designPreview ? <View className={styles.guardNote}><Icon name="shield-outline" size={14} color={colors.warning} /><Text className={styles.guardText}>{language === 'ru' ? 'Предпросмотр полностью выключен — Design/Preview покажут заглушку. Включите для рендера.' : 'Preview fully disabled — Design/Preview will show placeholder. Enable to render.'}</Text></View> : editor.designPreviewGuard ? <View className={styles.guardNote}><Icon name="shield-checkmark-outline" size={14} color={colors.primary} /><Text className={styles.guardText}>{language === 'ru' ? 'Двойная защита включена: предпросмотр потребует тап «Показать» при каждом открытии.' : 'Double guard on: preview will require tap "Show" on each open.'}</Text></View> : null}
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'Память и фон' : 'Storage & background'} icon="folder-open-outline">
            <View className={styles.toggleRow}>
              <View style={{
              flex: 1
            }}>
                <Text className={styles.toggleTitle}>{language === 'ru' ? 'Доступ к памяти' : 'Storage access'}</Text>
                <Text className={styles.toggleDesc}>{language === 'ru' ? 'All files access — сохранение APK в /sdcard/Download и общий доступ к файлам' : 'All files access — save APKs to /sdcard/Download and share files'}</Text>
              </View>
              {storageGranted ? <Icon name="checkmark-circle" size={20} color={colors.success} /> : <Pressable onPress={grantStorage} className={styles.smallBtn} style={{
              backgroundColor: colors.primary
            }}>
                  <Text className={styles.smallBtnText}>{language === 'ru' ? 'Разрешить' : 'Grant'}</Text>
                </Pressable>}
            </View>
            <View className={styles.toggleRow}>
              <View style={{
              flex: 1
            }}>
                <Text className={styles.toggleTitle}>{language === 'ru' ? 'Уведомления о фоновых задачах' : 'Background task notifications'}</Text>
                <Text className={styles.toggleDesc}>{language === 'ru' ? 'Статус установки/сборки, пока приложение свёрнуто' : 'Install/build status while the app is minimized'}</Text>
              </View>
              {notifGranted ? <Icon name="checkmark-circle" size={20} color={colors.success} /> : <Pressable onPress={grantNotif} className={styles.smallBtn} style={{
              backgroundColor: colors.primary
            }}>
                  <Text className={styles.smallBtnText}>{language === 'ru' ? 'Разрешить' : 'Allow'}</Text>
                </Pressable>}
            </View>
            <View className={styles.guardNote}>
              <Icon name="information-circle-outline" size={14} color={colors.info} />
              <Text className={styles.guardText}>{language === 'ru' ? 'Установка RAI и сборка APK продолжаются в фоне (foreground service). При закрытии приложения незавершённые шаги установки продолжатся при следующем запуске.' : 'RAI setup and APK builds keep running in the background (foreground service). If the app is closed, unfinished setup steps resume on the next launch.'}</Text>
            </View>
          </SectionCard>

          <SectionCard title={language === 'ru' ? 'О приложении' : 'About'} icon="information-circle-outline">
            <View className={styles.infoRow}><Text className={styles.infoLabel}>React Studio</Text><Text className={styles.infoValue}>1.0.0</Text></View>
            <View className={styles.infoRow}><Text className={styles.infoLabel}>React</Text><Text className={styles.infoValue}>19.2.8</Text></View>
            <View className={styles.infoRow}><Text className={styles.infoLabel}>Vite</Text><Text className={styles.infoValue}>5.4.0</Text></View>
            <View className={styles.infoRow}><Text className={styles.infoLabel}>Android SDK</Text><Text className={styles.infoValue}>API 37</Text></View>
            <View className={styles.infoRow}><Text className={styles.infoLabel}>SDK</Text><Text className={styles.infoValue}>37.0.0 (обязателен)</Text></View>
            <View className={styles.infoRow}><Text className={styles.infoLabel}>RAI</Text><Text className={styles.infoValue}>v{RAI_VERSION} (локально)</Text></View>
          </SectionCard>
        </View>
      </ScrollView>
    </AppScreen>;
};
const createStyles = c => ({
  page: "p-[16px] pb-[40px]",
  column: "w-full max-w-[760px] self-center gap-[14px]",
  label: "text-text-secondary text-[12px] font-semibold mb-[-5px]",
  description: "text-text-secondary text-[12px] leading-[18px] flex-1",
  toggleRow: "flex-row items-center gap-[12px] py-[8px] border-b border-b-border-light",
  toggleTitle: "text-text text-[13px] font-bold",
  toggleDesc: "text-text-secondary text-[11px] mt-[2px] leading-[14px]",
  guardNote: "flex-row items-start gap-[8px] p-[10px] rounded-[8px] bg-bg-elevated mt-[4px]",
  guardText: "flex-1 text-text-secondary text-[11px] leading-[14px]",
  smallBtn: "px-[12px] py-[7px] rounded-[8px]",
  smallBtnText: "text-white text-[11px] font-bold",
  previewRow: "flex-row items-center gap-[16px]",
  previewWindow: "w-[140px] h-[88px] rounded-[9px] overflow-hidden border border-border-light bg-bg",
  previewBar: "h-[18px] bg-bg-card border-b border-b-border",
  previewBody: "flex-1 flex-row p-[8px] gap-[8px]",
  previewSide: "w-[25px] rounded-[4px] bg-bg-elevated",
  previewLine: "h-[7px] rounded-[3px] bg-border-light w-[88%]",
  previewButton: "h-[15px] rounded-[4px] bg-primary w-[42px] mt-[3px]",
  infoRow: "flex-row justify-between py-[6px]",
  infoLabel: "text-text-secondary text-[13px]",
  infoValue: "text-text text-[13px] font-semibold font-mono"
});
export default AppSettingsScreen;
