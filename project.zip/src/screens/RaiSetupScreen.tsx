import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { SETUP_STEPS, runRaiSetup, SETUP_STEP_FILE } from '../utils/raiSetup';
import { TerminalView, isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';
import {
  startBackground,
  stopBackground,
  updateBackground,
  hasStorageAccess,
  openStorageSettings,
  requestStoragePermissions,
  getNotificationPermissionStatus,
  notificationNeedsSettings,
  openNotificationSettings,
  requestNotificationPermission,
  type NotificationPermissionStatus,
} from '../utils/background';
import { execute } from '../utils/shellExecutor';

// Без строки спец-клавиш (ESC/CTRL/...): в установщике она не нужна,
// терминал — для чтения вывода apt/dpkg/rai.
import { cn } from "../utils/cn";
const EXTRA_KEYS = '[]';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const RaiSetupScreen = ({
  onComplete,
  resume = false,
  resumeStep = null
}) => {
  const {
    colors,
    language
  } = useAppSettings();
  const ru = language === 'ru';
  const { width, height } = useWindowDimensions();
  const narrow = width < 430;
  const short = height < 720;
  const styles = useMemo(() => createStyles(colors, narrow, short), [colors, narrow, short]);
  const [phase, setPhase] = useState('idle'); // idle | running | done | error
  const [stepStates, setStepStates] = useState({});
  const [error, setError] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [fontSize, setFontSize] = useState(24); // крупный шрифт терминала по умолчанию
  const [storageGranted, setStorageGranted] = useState(false);
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermissionStatus | null>(null);
  const scrollRef = useRef(null);
  const terminalRef = useRef(null);
  const terminalReadyRef = useRef(false);
  const busyRef = useRef(false);
  const startedAtRef = useRef(0);
  const runRef = useRef(() => {});
  const statusOutputRef = useRef('');
  const copy = {
    title: ru ? 'Установка RAI' : 'RAI setup',
    subtitle: ru ? 'Реальный терминал Ubuntu (proot). Команды идут прямо в нём — можно вводить вручную.' : 'Real Ubuntu terminal (proot). Commands run right in it — you can type manually.',
    stepsTitle: ru ? 'Шаги установки' : 'Setup steps',
    start: ru ? 'Начать установку' : 'Start setup',
    resume: ru ? 'Продолжить установку' : 'Resume setup',
    running: ru ? 'Установка идёт…' : 'Installing…',
    retry: ru ? 'Повторить' : 'Retry',
    continueAnyway: ru ? 'Продолжить в проекты' : 'Continue to projects',
    done: ru ? 'Среда готова' : 'Environment is ready',
    doneText: ru ? 'Java, Android SDK и RAI установлены. Сейчас откроется список проектов.' : 'Java, Android SDK and RAI are installed. Opening the project list.',
    background: ru ? 'Установка идёт в фоне (foreground service + wakelock). Закрыли приложение? При следующем запуске она сама продолжится с того же шага.' : 'Setup runs in the background (foreground service + wakelock). Closed the app? It resumes automatically from the same step.',
    noShell: ru ? 'Нативный терминал недоступен. Откройте development-сборку.' : 'Native terminal unavailable. Open the development build.',
    logTitle: ru ? 'Терминал Ubuntu' : 'Ubuntu terminal',
    permissionsTitle: ru ? 'Разрешения' : 'Permissions',
    permissionsSub: ru ? 'Нужны для фоновой установки и сохранения APK.' : 'Needed for background setup and saving APKs.',
    storage: ru ? 'Память' : 'Storage',
    storageText: ru ? 'Сохранять собранные APK в /sdcard/Download и видеть файлы.' : 'Save built APKs to /sdcard/Download and access files.',
    storageGrant: ru ? 'Разрешить доступ' : 'Grant access',
    granted: ru ? 'Разрешено' : 'Granted',
    notGranted: ru ? 'Не разрешено' : 'Not granted',
    notif: ru ? 'Уведомления' : 'Notifications',
    notifText: ru ? 'Показывать статус фоновой установки/сборки.' : 'Show background setup/build status.',
    notifGrant: ru ? 'Разрешить' : 'Allow',
    notifSettings: ru ? 'Настройки Android' : 'Android settings',
    notifGranted: ru ? 'Разрешены' : 'Allowed',
    notifDenied: ru ? 'Не разрешены' : 'Not allowed',
    resumeInfo: ru ? 'Установка не была завершена. Продолжаем с места обрыва — готовые шаги будут пропущены.' : 'Setup was not finished. Resuming — finished steps will be skipped.',
    resumeStepInfo: label => ru ? `Продолжаем с шага: ${label}` : `Resuming from step: ${label}`,
    errorText: ru ? 'Установка не завершилась. Смотрите терминал выше. «Повторить» пропустит готовые шаги.' : 'Setup failed. See the terminal above. Retry skips finished steps.',
    waiting: ru ? 'Запускаю терминал…' : 'Starting terminal…'
  };
  const stepMeta = useMemo(() => {
    const m = {};
    SETUP_STEPS.forEach(s => {
      m[s.id] = s;
    });
    return m;
  }, []);

  // Permission requests remain user-driven. The app-level notification gate handles the
  // first request; this setup screen only reports status and offers recovery controls.
  const refreshPermissions = useCallback(async () => {
    const [storage, notifications] = await Promise.all([
      hasStorageAccess(),
      getNotificationPermissionStatus(),
    ]);
    setStorageGranted(storage);
    setNotificationStatus(notifications);
  }, []);
  useEffect(() => {
    refreshPermissions();
  }, [refreshPermissions]);
  useEffect(() => {
    const sub = AppState.addEventListener('change', state => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);

  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions, 600);
  };
  const grantNotif = async () => {
    if (!notificationStatus?.granted) {
      if (notificationNeedsSettings(notificationStatus)) {
        await openNotificationSettings();
      } else {
        await requestNotificationPermission();
      }
    }
    setTimeout(refreshPermissions, 600);
  };
  useEffect(() => {
    if (phase !== 'running') return undefined;
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startedAtRef.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, [phase]);
  const setStep = useCallback((id, state) => {
    setStepStates(s => ({
      ...s,
      [id]: state
    }));
  }, []);
  const waitTerminalReady = async () => {
    if (terminalReadyRef.current) return;
    const deadline = Date.now() + 15000;
    while (Date.now() < deadline && !terminalReadyRef.current) {
      await sleep(300);
    }
    // Даём bash закончить загрузку profile перед первым вводом.
    if (terminalReadyRef.current) await sleep(600);
  };
  const run = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setPhase('running');
    setError('');
    setElapsed(0);
    startedAtRef.current = Date.now();
    SETUP_STEPS.forEach(s => setStep(s.id, 'pending'));
    await startBackground(copy.title);
    await updateBackground(copy.subtitle);
    const onStepStart = id => setStep(id, 'running');
    const onStepEnd = (id, step, res) => {
      setStep(id, res.status === 'done' ? 'done' : res.status === 'skipped' ? 'skipped' : 'error');
      const label = stepMeta[id]?.title?.ru || id;
      updateBackground(`${copy.title}: ${res.status === 'skipped' ? '✓' : res.status === 'done' ? '✓' : '✗'} ${label}`).catch(() => {});
    };
    try {
      // Commands run in the native durable-job supervisor. TerminalView is now only a live log
      // viewer, so destroying the React activity cannot destroy apt/RAI child processes.
      const result = await runRaiSetup({
        onStepStart,
        onStepEnd,
        onLine: line => {
          try { terminalRef.current?.writeText?.(`${line}\r\n`); } catch (_) {}
        }
      });
      if (result.ok) {
        setPhase('done');
        try {
          terminalRef.current?.writeText?.('\r\n\u2705 ' + copy.done + '\r\n');
        } catch (_) {}
        await stopBackground();
        setTimeout(onComplete, 900);
      } else {
        const failed = result.summary.find(r => r.status === 'failed');
        setError(failed ? stepMeta[failed.id]?.title?.ru || failed.id : copy.errorText);
        setPhase('error');
        try {
          terminalRef.current?.writeText?.('\r\n\u274c ' + copy.errorText + '\r\n');
        } catch (_) {}
      }
    } catch (e) {
      setError(e?.message || String(e));
      setPhase('error');
    } finally {
      busyRef.current = false;
      if (phase !== 'done') stopBackground().catch(() => {});
      setTimeout(() => scrollRef.current?.scrollToEnd({
        animated: true
      }), 80);
    }
  }, [copy, onComplete, phase, setStep, stepMeta]);
  runRef.current = run;

  // Авто-продолжение после закрытия (resume): стартуем сами, без кнопки.
  useEffect(() => {
    if (resume) {
      const t = setTimeout(() => {
        runRef.current();
      }, 400);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [resume]);
  const restartFromScratch = async () => {
    try {
      await execute(`rm -f ${SETUP_STEP_FILE}`, '/');
    } catch (_) {}
    setStepStates({});
    runRef.current();
  };
  const onTerminalEvent = event => {
    const value = event?.nativeEvent || event;
    if (value?.type === 'started') {
      terminalReadyRef.current = true;
    }
    if (value?.type === 'exit') {
      // Сессия завершилась (например, при перезапуске rootfs) — терминал пересоздастся.
      terminalReadyRef.current = false;
    }
  };
  const stepIcon = state => {
    switch (state) {
      case 'done':
        return <Icon name="checkmark-circle" size={17} color={colors.success} />;
      case 'skipped':
        return <Icon name="checkmark-done-circle-outline" size={17} color={colors.textTertiary} />;
      case 'error':
        return <Icon name="close-circle" size={17} color={colors.error} />;
      case 'running':
        return <Icon name="sync" size={15} color={colors.primary} />;
      default:
        return <View className={styles.dot} style={{
          backgroundColor: colors.border
        }} />;
    }
  };
  const stepTone = state => state === 'error' ? 'error' : state === 'done' || state === 'skipped' ? 'success' : 'neutral';
  return <AppScreen>
      <ScrollView contentContainerClassName={styles.page} keyboardShouldPersistTaps="handled" ref={scrollRef}>
        <View className={styles.content}>
          <View className={styles.brandMark}><Icon name="terminal-outline" size={30} color="#FFFFFF" /></View>
          <Text className={styles.title}>{copy.title}</Text>
          <Text className={styles.subtitle}>{copy.subtitle}</Text>

          {resume && phase === 'idle' ? <View className={styles.resumeBox}>
              <Icon name="information-circle-outline" size={18} color={colors.info} />
              <Text className={styles.resumeText}>
                {copy.resumeInfo}
                {resumeStep && stepMeta[resumeStep] ? `\n${copy.resumeStepInfo(stepMeta[resumeStep].title[ru ? 'ru' : 'en'])}` : ''}
              </Text>
            </View> : null}

          <SectionCard title={copy.stepsTitle} icon="list-outline" className={styles.card}>
            {SETUP_STEPS.map(s => {
            const state = stepStates[s.id] || 'pending';
            return <View key={s.id} className={styles.stepRow}>
                  {stepIcon(state)}
                  <Text className={styles.stepText} style={state === 'error' && {
                color: colors.error
              }} numberOfLines={1}>
                    {s.title[ru ? 'ru' : 'en']}
                  </Text>
                  <StatusPill label={state === 'done' ? ru ? 'Готово' : 'Done' : state === 'skipped' ? ru ? 'Пропущен' : 'Skipped' : state === 'running' ? ru ? 'Идёт' : 'Run' : state === 'error' ? ru ? 'Ошибка' : 'Error' : ''} tone={stepTone(state)} />
                </View>;
          })}
          </SectionCard>

          {phase === 'error' && error ? <View className={styles.errorBox}>
              <Icon name="alert-circle-outline" size={20} color={colors.error} />
              <Text className={styles.errorText}>{error}</Text>
            </View> : null}

          {/* Разрешения — в начале установки */}
          <SectionCard title={copy.permissionsTitle} icon="shield-checkmark-outline" className={styles.card}>
            <Text className={styles.permissionsSub}>{copy.permissionsSub}</Text>
            <View className={styles.permRow}>
              <View className={styles.permIcon}><Icon name="folder-open-outline" size={18} color={colors.primary} /></View>
              <View style={{
              flex: 1,
              minWidth: 0
            }}>
                <Text className={styles.permTitle}>{copy.storage}</Text>
                <Text className={styles.permText}>{copy.storageText}</Text>
              </View>
              <View style={{
              alignItems: 'flex-end',
              flexDirection: narrow ? 'row' : 'column',
              justifyContent: narrow ? 'flex-end' : undefined,
              width: narrow ? '100%' : undefined,
              gap: 6
            }}>
                <StatusPill label={storageGranted ? copy.granted : copy.notGranted} tone={storageGranted ? 'success' : 'warning'} />
                {!storageGranted ? <Pressable onPress={grantStorage} className={styles.miniBtn}><Text className={styles.miniBtnText}>{copy.storageGrant}</Text></Pressable> : null}
              </View>
            </View>
            <View className={styles.permRow}>
              <View className={styles.permIcon}><Icon name="notifications-outline" size={18} color={colors.primary} /></View>
              <View style={{
              flex: 1,
              minWidth: 0
            }}>
                <Text className={styles.permTitle}>{copy.notif}</Text>
                <Text className={styles.permText}>{copy.notifText}</Text>
              </View>
              <View style={{
              alignItems: 'flex-end',
              flexDirection: narrow ? 'row' : 'column',
              justifyContent: narrow ? 'flex-end' : undefined,
              width: narrow ? '100%' : undefined,
              gap: 6
            }}>
                <StatusPill
                  label={notificationStatus?.granted ? copy.notifGranted : copy.notifDenied}
                  tone={notificationStatus?.granted ? 'success' : 'warning'}
                />
                {notificationStatus && !notificationStatus.granted ? <Pressable onPress={grantNotif} className={styles.miniBtn}>
                    <Text className={styles.miniBtnText}>
                      {notificationNeedsSettings(notificationStatus) ? copy.notifSettings : copy.notifGrant}
                    </Text>
                  </Pressable> : null}
              </View>
            </View>
          </SectionCard>

          {/* Реальный интерактивный терминал */}
          <View className={styles.consoleWrap}>
            <View className={styles.consoleHead}>
              {!narrow ? <View className={styles.dots}><View className={styles.dot} style={{
                backgroundColor: '#F87171'
              }} /><View className={styles.dot} style={{
                backgroundColor: '#FBBF24'
              }} /><View className={styles.dot} style={{
                backgroundColor: '#34D399'
              }} /></View> : null}
              <Text className={styles.consoleTitle} numberOfLines={1}>{copy.logTitle}</Text>
              <View style={{
              flex: 1
            }} />
              <IconButton name="remove-outline" onPress={() => setFontSize(v => Math.max(10, v - 2))} />
              <IconButton name="add-outline" onPress={() => setFontSize(v => Math.min(34, v + 2))} />
              {phase === 'running' ? <StatusPill label={`${elapsed}s`} tone="info" /> : null}
            </View>
            <View className={styles.terminalWrap}>
              {terminalAvailable() ? <TerminalView ref={terminalRef} className={styles.terminal} fontSize={fontSize} extraKeys={EXTRA_KEYS} readOnly onTerminalEvent={onTerminalEvent} /> : <View className={styles.fallbackTerminal}>
                  <Icon name="hardware-chip-outline" size={28} color="#526079" />
                  <Text className={styles.fallbackText}>{copy.noShell}</Text>
                </View>}
            </View>
          </View>

          {phase === 'done' ? <View className={styles.successBox}>
              <Icon name="checkmark-circle" size={26} color={colors.success} />
              <Text className={styles.successText}>{copy.doneText}</Text>
            </View> : <View style={{
          width: '100%',
          gap: 8,
          marginTop: 14
        }}>
              <PrimaryButton title={phase === 'running' ? copy.running : phase === 'error' ? copy.retry : resume && phase === 'idle' ? copy.resume : copy.start} icon={phase === 'running' ? undefined : 'download-outline'} loading={phase === 'running'} disabled={phase === 'running'} onPress={run} style={{
            width: '100%'
          }} />
              {phase === 'error' ? <Pressable onPress={restartFromScratch} className={styles.link}>
                  <Text className={styles.linkText}>{ru ? 'Сбросить и начать заново' : 'Reset & restart'}</Text>
                </Pressable> : null}
            </View>}

          <Text className={styles.backgroundHint}>{copy.background}</Text>

          {phase === 'done' ? <Pressable onPress={onComplete} className={styles.link}>
              <Text className={styles.linkText}>{copy.continueAnyway}</Text>
            </Pressable> : null}
        </View>
      </ScrollView>
    </AppScreen>;
};
const createStyles = (c, narrow, short) => ({
  page: narrow ? "grow px-[12px] py-[16px]" : "grow p-[20px]",
  content: "w-full max-w-[680px] self-center items-center",
  brandMark: narrow ? "w-[52px] h-[52px] rounded-[15px] items-center justify-center bg-primary mb-[12px]" : "w-[62px] h-[62px] rounded-[18px] items-center justify-center bg-primary mb-[18px]",
  title: narrow ? "text-text text-[22px] font-bold text-center tracking-[-0.3px]" : "text-text text-[26px] font-bold text-center tracking-[-0.4px]",
  subtitle: narrow ? "text-text-secondary text-[12px] leading-[18px] text-center mt-[6px] mb-[14px]" : "text-text-secondary text-[13px] leading-[20px] text-center max-w-[520px] mt-[8px] mb-[20px]",
  resumeBox: "w-full flex-row items-start gap-[9px] p-[12px] rounded-[11px] bg-info-bg mb-[12px]",
  resumeText: "flex-1 text-info-text text-[12px] leading-[18px]",
  card: narrow ? "w-full p-[12px]" : "w-full p-[16px]",
  stepRow: "min-h-[34px] flex-row items-center gap-[9px]",
  stepText: narrow ? "flex-1 text-text text-[12px] font-semibold" : "flex-1 text-text text-[13px] font-semibold",
  dot: "w-[7px] h-[7px] rounded-[4px]",
  errorBox: "w-full flex-row items-start gap-[9px] p-[12px] rounded-[11px] bg-error-bg mt-[12px]",
  errorText: "flex-1 text-error-text text-[12px] leading-[18px]",
  consoleWrap: "w-full rounded-[12px] overflow-hidden bg-terminal border border-[#253046] mt-[14px]",
  consoleHead: "min-h-[44px] px-[11px] flex-row items-center gap-[8px] bg-terminal-raised border-b border-b-[#253046]",
  dots: "flex-row gap-[5px]",
  consoleTitle: "shrink text-[#D6DEEB] text-[11px] font-bold",
  terminalWrap: narrow ? (short ? "h-[260px] bg-terminal" : "h-[320px] bg-terminal") : "h-[440px] bg-terminal",
  terminal: "flex-1 bg-terminal",
  fallbackTerminal: "flex-1 items-center justify-center gap-[8px]",
  fallbackText: "text-[#8B98AD] text-[12px] text-center px-[20px]",
  successBox: "w-full flex-row items-center gap-[10px] p-[14px] rounded-[12px] bg-success-bg mt-[14px]",
  successText: "flex-1 text-success-text text-[13px] font-bold",
  permissionsSub: "text-text-secondary text-[11px] mt-[-8px]",
  permRow: narrow ? "flex-row flex-wrap items-center gap-[10px] p-[10px] rounded-[11px] border border-border bg-bg" : "flex-row items-center gap-[10px] p-[10px] rounded-[11px] border border-border bg-bg",
  permIcon: "w-[36px] h-[36px] rounded-[9px] bg-primary-surface items-center justify-center",
  permTitle: "text-text text-[13px] font-bold",
  permText: "text-text-secondary text-[10px] leading-[14px] mt-[2px]",
  miniBtn: "px-[10px] py-[6px] rounded-[8px] bg-primary",
  miniBtnText: "text-white text-[11px] font-bold",
  backgroundHint: "text-text-secondary text-[11px] leading-[17px] text-center max-w-[540px] mt-[14px]",
  link: "mt-[10px] p-[8px]",
  linkText: "text-primary text-[13px] font-bold"
});
export default RaiSetupScreen;
