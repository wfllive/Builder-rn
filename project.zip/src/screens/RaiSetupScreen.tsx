import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  AppState,
  Pressable,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { SETUP_STEPS, runRaiSetup, SETUP_STEP_FILE } from '../utils/raiSetup';
import {
  startBackground,
  stopBackground,
  updateBackground,
  hasStorageAccess,
  openStorageSettings,
  requestStoragePermissions,
  getNotificationPermissionStatus,
  notificationNeedsSettings,
  openNotificationSettings,
  requestNotificationPermission,
  type NotificationPermissionStatus,
} from '../utils/background';
import { execute } from '../utils/shellExecutor';
import {
  isAvailable as terminalAvailable,
  TerminalView,
  type TerminalEvent,
  type TerminalViewRef,
} from '../../modules/termux-terminal/src';
import { cn } from '../utils/cn';

type SetupPhase = 'idle' | 'running' | 'done' | 'error';
type StepState = 'pending' | 'running' | 'done' | 'skipped' | 'error';
type LogLevel = 'normal' | 'success' | 'error';
type LogLine = { id: number; text: string; level: LogLevel };

type RaiSetupScreenProps = {
  onComplete: () => void;
  resume?: boolean;
  resumeStep?: string | null;
};

const elapsedLabel = (seconds: number) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return [hours, minutes, secs].map(value => String(value).padStart(2, '0')).join(':');
};

const terminalLine = (value: unknown, level: LogLevel) => {
  const normalized = String(value ?? '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const color = level === 'success' ? '\u001b[1;92m' : level === 'error' ? '\u001b[1;91m' : '\u001b[0m';
  return `${color}${normalized.split('\n').join('\r\n')}\u001b[0m\r\n`;
};

const RaiSetupScreen = ({ onComplete, resume = false, resumeStep = null }: RaiSetupScreenProps) => {
  const { colors, language } = useAppSettings();
  const ru = language === 'ru';
  const { width, height } = useWindowDimensions();
  const narrow = width < 430;
  const short = height < 720;

  const [phase, setPhase] = useState<SetupPhase>('idle');
  const [stepStates, setStepStates] = useState<Record<string, StepState>>({});
  const [error, setError] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [fontSize, setFontSize] = useState(12);
  const [logLines, setLogLines] = useState<LogLine[]>([]);
  const [storageGranted, setStorageGranted] = useState(false);
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermissionStatus | null>(null);

  const scrollRef = useRef<ScrollView>(null);
  const fallbackLogRef = useRef<ScrollView>(null);
  const terminalRef = useRef<TerminalViewRef>(null);
  const terminalReadyRef = useRef(false);
  const pendingTerminalOutputRef = useRef<string[]>([]);
  const logIdRef = useRef(0);
  const busyRef = useRef(false);
  const startedAtRef = useRef(0);
  const runRef = useRef<() => void>(() => {});

  const copy = useMemo(() => ({
    title: ru ? 'Установка RAI' : 'RAI setup',
    subtitle: ru
      ? 'Профессиональная среда сборки устанавливается в Ubuntu. Вывод ниже отображается настоящим движком терминала Termux.'
      : 'The professional build environment is installed in Ubuntu. Output below is rendered by the real Termux terminal engine.',
    stepsTitle: ru ? 'План установки' : 'Installation plan',
    start: ru ? 'Начать установку' : 'Start setup',
    resume: ru ? 'Продолжить установку' : 'Resume setup',
    retry: ru ? 'Повторить установку' : 'Retry setup',
    continueAnyway: ru ? 'Продолжить в проекты' : 'Continue to projects',
    done: ru ? 'Среда готова' : 'Environment is ready',
    doneText: ru
      ? 'Java, Android SDK и RAI установлены. Сейчас откроется список проектов.'
      : 'Java, Android SDK and RAI are installed. Opening the project list.',
    background: ru
      ? 'Можно свернуть приложение: установка продолжится в защищённой фоновой задаче и восстановится после повторного открытия.'
      : 'You may leave the app: setup continues in a protected background job and restores when reopened.',
    terminalTitle: ru ? 'ТЕРМИНАЛ УСТАНОВКИ' : 'SETUP TERMINAL',
    terminalEmpty: ru ? 'Ожидание вывода установщика…' : 'Waiting for installer output…',
    permissionsTitle: ru ? 'Доступ приложения' : 'App access',
    permissionsSub: ru ? 'Для фоновой работы и сохранения собранных APK.' : 'For background work and saving built APKs.',
    storage: ru ? 'Память' : 'Storage',
    storageText: ru ? 'Сохранять APK в /sdcard/Download и видеть файлы.' : 'Save APKs to /sdcard/Download and access files.',
    storageGrant: ru ? 'Разрешить доступ' : 'Grant access',
    granted: ru ? 'Разрешено' : 'Granted',
    notGranted: ru ? 'Не разрешено' : 'Not granted',
    notif: ru ? 'Уведомления' : 'Notifications',
    notifText: ru ? 'Показывать текущий этап фоновой установки и сборки.' : 'Show the current background setup and build stage.',
    notifGrant: ru ? 'Разрешить' : 'Allow',
    notifSettings: ru ? 'Настройки Android' : 'Android settings',
    notifGranted: ru ? 'Разрешены' : 'Allowed',
    notifDenied: ru ? 'Не разрешены' : 'Not allowed',
    resumeInfo: ru
      ? 'Незавершённая установка найдена. Готовые этапы будут автоматически пропущены.'
      : 'An unfinished setup was found. Completed stages will be skipped automatically.',
    resumeStepInfo: (label: string) => ru ? `Продолжение с этапа: ${label}` : `Resuming from: ${label}`,
    errorText: ru
      ? 'Установка остановилась. Подробности сохранены в терминале; повторный запуск пропустит готовые этапы.'
      : 'Setup stopped. Details remain in the terminal; retry skips completed stages.',
    preparing: ru ? 'Подготовка к запуску' : 'Preparing to start',
    currentStage: ru ? 'СЕЙЧАС ВЫПОЛНЯЕТСЯ' : 'RUNNING NOW',
    readyToStart: ru ? 'Готово к запуску' : 'Ready to start',
    completedStages: ru ? 'этапов завершено' : 'stages complete',
    stage: ru ? 'Этап' : 'Stage',
    allComplete: ru ? 'Все этапы завершены' : 'All stages completed',
    failed: ru ? 'Требуется внимание' : 'Needs attention',
    live: 'LIVE',
    copyTerminal: ru ? 'Копировать вывод терминала' : 'Copy terminal output',
    copied: ru ? 'Вывод терминала скопирован' : 'Terminal output copied',
    copyFailed: ru ? 'В терминале пока нет текста для копирования.' : 'There is no terminal output to copy yet.',
  }), [ru]);

  const stepMeta = useMemo(() => Object.fromEntries(SETUP_STEPS.map(step => [step.id, step])), []);
  const nativeTerminalAvailable = terminalAvailable();

  const terminalBanner = useCallback((status?: string) => {
    const state = status || copy.terminalEmpty;
    return (
      '\u001b[2J\u001b[H' +
      '\u001b[1;96mNovaCompose Studio  •  RAI Installer\u001b[0m\r\n' +
      '\u001b[90mUbuntu / proot  •  output-only Termux renderer\u001b[0m\r\n' +
      '\u001b[90m────────────────────────────────────────────────────────\u001b[0m\r\n' +
      `\u001b[37m${state}\u001b[0m\r\n\r\n`
    );
  }, [copy.terminalEmpty]);

  const appendTerminalOutput = useCallback((text: string) => {
    if (!text) return;
    if (terminalReadyRef.current && terminalRef.current) {
      terminalRef.current.appendOutput(text);
    } else {
      pendingTerminalOutputRef.current.push(text);
      if (pendingTerminalOutputRef.current.length > 4000) {
        pendingTerminalOutputRef.current = pendingTerminalOutputRef.current.slice(-4000);
      }
    }
  }, []);

  const resetTerminalOutput = useCallback((status?: string) => {
    pendingTerminalOutputRef.current = [];
    if (terminalReadyRef.current && terminalRef.current) {
      terminalRef.current.clearOutput();
      terminalRef.current.appendOutput(terminalBanner(status));
    }
  }, [terminalBanner]);

  const onTerminalEvent = useCallback((event: { nativeEvent: TerminalEvent }) => {
    if (event.nativeEvent.type === 'started') {
      terminalReadyRef.current = true;
      terminalRef.current?.clearOutput();
      terminalRef.current?.appendOutput(terminalBanner(phase === 'running' ? copy.preparing : undefined));
      const queued = pendingTerminalOutputRef.current;
      pendingTerminalOutputRef.current = [];
      queued.forEach(text => terminalRef.current?.appendOutput(text));
    } else if (event.nativeEvent.type === 'exit') {
      terminalReadyRef.current = false;
    }
  }, [copy.preparing, phase, terminalBanner]);

  const appendLog = useCallback((value: unknown, level: LogLevel = 'normal') => {
    const normalized = String(value ?? '').replace(/\r/g, '');
    const lines = normalized.split('\n');
    setLogLines(current => {
      const next = lines.map(text => ({
        id: ++logIdRef.current,
        text: text || ' ',
        level,
      }));
      return [...current, ...next].slice(-4000);
    });
    appendTerminalOutput(terminalLine(normalized, level));
  }, [appendTerminalOutput]);

  // Permission requests stay user-driven. The app-level gate handles the first notification
  // request; this screen reports current status and offers recovery actions.
  const refreshPermissions = useCallback(async () => {
    const [storage, notifications] = await Promise.all([
      hasStorageAccess(),
      getNotificationPermissionStatus(),
    ]);
    setStorageGranted(storage);
    setNotificationStatus(notifications);
  }, []);

  useEffect(() => {
    refreshPermissions();
  }, [refreshPermissions]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', state => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);

  useEffect(() => {
    if (phase !== 'running') return undefined;
    const timer = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startedAtRef.current) / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [phase]);

  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions, 600);
  };

  const grantNotifications = async () => {
    if (!notificationStatus?.granted) {
      if (notificationNeedsSettings(notificationStatus)) {
        await openNotificationSettings();
      } else {
        await requestNotificationPermission();
      }
    }
    setTimeout(refreshPermissions, 600);
  };

  const setStep = useCallback((id: string, state: StepState) => {
    setStepStates(current => ({ ...current, [id]: state }));
  }, []);

  const run = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setPhase('running');
    setError('');
    setLogLines([]);
    setElapsed(0);
    startedAtRef.current = Date.now();
    SETUP_STEPS.forEach(step => setStep(step.id, 'pending'));
    resetTerminalOutput(copy.preparing);

    await startBackground(copy.title);
    await updateBackground(copy.preparing);

    const onStepStart = (id: string, step: any) => {
      setStep(id, 'running');
      const label = step?.title?.[ru ? 'ru' : 'en'] || id;
      updateBackground(`${copy.title}: ${label}`).catch(() => {});
    };
    const onStepEnd = (id: string, step: any, result: any) => {
      const state: StepState = result.status === 'done'
        ? 'done'
        : result.status === 'skipped'
          ? 'skipped'
          : 'error';
      setStep(id, state);
      const label = step?.title?.[ru ? 'ru' : 'en'] || id;
      appendLog(`${state === 'error' ? '✗' : '✓'} ${label}`, state === 'error' ? 'error' : 'success');
    };

    let completed = false;
    try {
      // The durable native supervisor owns commands. Lines go only to appendOutput(), which feeds
      // TerminalEmulator.append() directly and never writes package-manager output into Bash stdin.
      const result = await runRaiSetup({
        onStepStart,
        onStepEnd,
        onLine: (line: string) => appendLog(line),
      });
      if (result.ok) {
        completed = true;
        setPhase('done');
        appendLog(`✓ ${copy.done}`, 'success');
        await stopBackground();
        setTimeout(onComplete, 900);
      } else {
        const failed = result.summary.find((item: any) => item.status === 'failed');
        if (failed?.id) setStep(failed.id, 'error');
        setError(failed ? stepMeta[failed.id]?.title?.[ru ? 'ru' : 'en'] || failed.id : copy.errorText);
        setPhase('error');
        appendLog(`✗ ${copy.errorText}`, 'error');
      }
    } catch (caught: any) {
      const message = caught?.message || String(caught);
      setError(message);
      setPhase('error');
      appendLog(`✗ ${message}`, 'error');
    } finally {
      busyRef.current = false;
      if (!completed) stopBackground().catch(() => {});
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
    }
  }, [appendLog, copy, onComplete, resetTerminalOutput, ru, setStep, stepMeta]);
  runRef.current = run;

  useEffect(() => {
    if (!resume) return undefined;
    const timer = setTimeout(() => runRef.current(), 400);
    return () => clearTimeout(timer);
  }, [resume]);

  const restartFromScratch = async () => {
    try {
      await execute(`rm -f ${SETUP_STEP_FILE}`, '/');
    } catch (_) {}
    setStepStates({});
    runRef.current();
  };

  const copyTerminalTranscript = async () => {
    const copied = await terminalRef.current?.copyTranscriptToClipboard();
    Alert.alert(copy.terminalTitle, copied ? copy.copied : copy.copyFailed);
  };

  const completedCount = SETUP_STEPS.filter(step => ['done', 'skipped'].includes(stepStates[step.id])).length;
  const activeIndex = SETUP_STEPS.findIndex(step => stepStates[step.id] === 'running');
  const failedIndex = SETUP_STEPS.findIndex(step => stepStates[step.id] === 'error');
  const displayIndex = activeIndex >= 0
    ? activeIndex
    : failedIndex >= 0
      ? failedIndex
      : Math.min(completedCount, SETUP_STEPS.length - 1);
  const activeStep = SETUP_STEPS[displayIndex];
  const progress = phase === 'done' ? 100 : Math.round((completedCount / SETUP_STEPS.length) * 100);
  const activeLabel = phase === 'done'
    ? copy.allComplete
    : phase === 'error'
      ? copy.failed
      : phase === 'running' && activeIndex >= 0
        ? activeStep.title[ru ? 'ru' : 'en']
        : copy.readyToStart;

  const stepIcon = (state: StepState, index: number) => {
    if (state === 'done') return <Icon name="checkmark" size={15} color="#FFFFFF" />;
    if (state === 'skipped') return <Icon name="checkmark-done" size={14} color="#FFFFFF" />;
    if (state === 'error') return <Icon name="close" size={15} color="#FFFFFF" />;
    if (state === 'running') return <ActivityIndicator size="small" color="#FFFFFF" />;
    return <Text className="text-[11px] font-extrabold text-text-tertiary">{index + 1}</Text>;
  };

  const stepStatus = (state: StepState) => {
    if (state === 'done') return ru ? 'Готово' : 'Done';
    if (state === 'skipped') return ru ? 'Уже готово' : 'Already done';
    if (state === 'running') return ru ? 'Выполняется' : 'Running';
    if (state === 'error') return ru ? 'Ошибка' : 'Error';
    return ru ? 'Ожидает' : 'Pending';
  };

  return (
    <AppScreen>
      <ScrollView
        ref={scrollRef}
        keyboardShouldPersistTaps="handled"
        contentContainerClassName={cn('grow', narrow ? 'px-3 py-4' : 'p-5')}
      >
        <View className="w-full max-w-[720px] self-center items-center">
          <View className={cn('items-center justify-center bg-primary', narrow ? 'mb-3 h-[52px] w-[52px] rounded-2xl' : 'mb-[18px] h-[62px] w-[62px] rounded-[18px]')}>
            <Icon name="terminal-outline" size={30} color="#FFFFFF" />
          </View>
          <Text className={cn('text-center font-extrabold tracking-[-0.4px] text-text', narrow ? 'text-[23px]' : 'text-[28px]')}>{copy.title}</Text>
          <Text className={cn('mt-1.5 text-center text-text-secondary', narrow ? 'mb-3.5 text-xs leading-[18px]' : 'mb-5 max-w-[580px] text-[13px] leading-5')}>{copy.subtitle}</Text>

          {resume && phase === 'idle' ? (
            <View className="mb-3 w-full flex-row items-start gap-[9px] rounded-xl bg-info-bg p-3">
              <Icon name="information-circle-outline" size={19} color={colors.info} />
              <Text className="flex-1 text-xs leading-[18px] text-info-text">
                {copy.resumeInfo}
                {resumeStep && stepMeta[resumeStep]
                  ? `\n${copy.resumeStepInfo(stepMeta[resumeStep].title[ru ? 'ru' : 'en'])}`
                  : ''}
              </Text>
            </View>
          ) : null}

          {/* Prominent, always-visible stage overview. */}
          <View className="mb-3 w-full overflow-hidden rounded-[18px] border border-[#263650] bg-[#101827]">
            <View className={cn('flex-row items-center', narrow ? 'px-4 pb-3 pt-4' : 'px-5 pb-4 pt-5')}>
              <View className="min-w-0 flex-1">
                <View className="mb-1 flex-row items-center gap-2">
                  {phase === 'running' ? <View className="h-2 w-2 rounded-full bg-[#43D39E]" /> : null}
                  <Text className="text-[10px] font-extrabold tracking-[1.2px] text-[#8EA1C0]">
                    {phase === 'running' ? copy.currentStage : copy.stage.toUpperCase()}
                  </Text>
                </View>
                <Text className={cn('font-bold text-white', narrow ? 'text-[16px]' : 'text-lg')} numberOfLines={2}>
                  {activeLabel}
                </Text>
                <Text className="mt-1 text-[11px] text-[#91A0B8]">
                  {phase === 'done'
                    ? `${SETUP_STEPS.length} / ${SETUP_STEPS.length} ${copy.completedStages}`
                    : `${completedCount} / ${SETUP_STEPS.length} ${copy.completedStages}`}
                </Text>
              </View>
              <View className="ml-3 items-end">
                <Text className="text-[28px] font-black tracking-[-1px] text-white">{progress}%</Text>
                <View className="mt-1 flex-row items-center gap-1.5 rounded-full bg-[#1B2940] px-2.5 py-1.5">
                  <Icon name="time-outline" size={13} color="#9FB0CA" />
                  <Text className="font-mono text-[11px] font-bold text-[#C8D5E8]">{elapsedLabel(elapsed)}</Text>
                </View>
              </View>
            </View>
            <View className="mx-4 mb-4 h-2 overflow-hidden rounded-full bg-[#243149]">
              <View className="h-full rounded-full bg-[#35C99A]" style={{ width: `${progress}%` }} />
            </View>
            <View className="flex-row items-center border-t border-[#243149] bg-[#121D2D] px-4 py-3">
              <View className={cn(
                'mr-3 h-9 w-9 items-center justify-center rounded-[11px]',
                phase === 'error' ? 'bg-[#D04456]' : phase === 'done' ? 'bg-[#24A777]' : 'bg-primary',
              )}>
                {phase === 'running' ? <ActivityIndicator size="small" color="#FFFFFF" /> : (
                  <Icon name={phase === 'done' ? 'checkmark' : phase === 'error' ? 'alert' : 'play'} size={17} color="#FFFFFF" />
                )}
              </View>
              <View className="min-w-0 flex-1">
                <Text className="text-[10px] font-bold uppercase tracking-[0.9px] text-[#8294AF]">
                  {copy.stage} {Math.max(displayIndex + 1, 1)} {ru ? 'из' : 'of'} {SETUP_STEPS.length}
                </Text>
                <Text className="mt-0.5 text-xs font-semibold text-[#D7E2F2]" numberOfLines={1}>
                  {activeStep?.title?.[ru ? 'ru' : 'en'] || copy.preparing}
                </Text>
              </View>
              {phase === 'running' ? <StatusPill label={copy.live} tone="success" /> : null}
            </View>
          </View>

          {phase === 'error' && error ? (
            <View className="mb-3 w-full flex-row items-start gap-[9px] rounded-xl bg-error-bg p-3">
              <Icon name="alert-circle-outline" size={20} color={colors.error} />
              <Text className="flex-1 text-xs leading-[18px] text-error-text">{error}</Text>
            </View>
          ) : null}

          {phase !== 'running' && phase !== 'done' ? (
            <View className="mb-3 w-full gap-1">
              <PrimaryButton
                title={phase === 'error' ? copy.retry : resume ? copy.resume : copy.start}
                icon={phase === 'error' ? 'refresh-outline' : 'download-outline'}
                onPress={run}
                className="w-full"
              />
              {phase === 'error' ? (
                <Pressable onPress={restartFromScratch} className="self-center p-2">
                  <Text className="text-[13px] font-bold text-primary">{ru ? 'Сбросить прогресс и начать заново' : 'Reset progress and start over'}</Text>
                </Pressable>
              ) : null}
            </View>
          ) : null}

          {/* Real Termux TerminalView in output-only mode. appendOutput() never touches PTY input. */}
          <View className={cn(
            'mb-3 w-full overflow-hidden rounded-[15px] border border-[#253046] bg-[#0D1117]',
            narrow ? (short ? 'h-[310px]' : 'h-[360px]') : 'h-[460px]',
          )}>
            <View className="min-h-[47px] flex-row items-center gap-2 border-b border-[#253046] bg-[#151D2B] px-3">
              <View className="flex-row gap-[5px]">
                <View className="h-[7px] w-[7px] rounded-full bg-[#F87171]" />
                <View className="h-[7px] w-[7px] rounded-full bg-[#FBBF24]" />
                <View className="h-[7px] w-[7px] rounded-full bg-[#34D399]" />
              </View>
              <View className="ml-1 min-w-0 flex-1">
                <Text className="text-[10px] font-extrabold tracking-[0.9px] text-[#D6DEEB]" numberOfLines={1}>{copy.terminalTitle}</Text>
                <Text className="mt-0.5 text-[9px] text-[#73829A]" numberOfLines={1}>Ubuntu · Termux VT / ANSI · read-only</Text>
              </View>
              <IconButton name="remove-outline" onPress={() => setFontSize(value => Math.max(9, value - 1))} className="h-8 min-h-0 min-w-8 border-[#2B374B] bg-[#192333]" />
              <IconButton name="add-outline" onPress={() => setFontSize(value => Math.min(22, value + 1))} className="h-8 min-h-0 min-w-8 border-[#2B374B] bg-[#192333]" />
              {nativeTerminalAvailable ? (
                <IconButton name="copy-outline" accessibilityLabel={copy.copyTerminal} onPress={copyTerminalTranscript} className="h-8 min-h-0 min-w-8 border-[#2B374B] bg-[#192333]" />
              ) : null}
            </View>
            <View className="flex-1 bg-[#0D1117]">
              {nativeTerminalAvailable ? (
                <TerminalView
                  ref={terminalRef}
                  className="flex-1"
                  fontSize={fontSize}
                  readOnly
                  outputOnly
                  extraKeys="[]"
                  onTerminalEvent={onTerminalEvent}
                />
              ) : (
                <ScrollView
                  ref={fallbackLogRef}
                  className="flex-1 bg-[#0D1117]"
                  contentContainerClassName="grow p-3 pb-6"
                  onContentSizeChange={() => fallbackLogRef.current?.scrollToEnd({ animated: phase === 'running' })}
                >
                  {!logLines.length ? (
                    <View className="grow items-center justify-center gap-2">
                      <Icon name="terminal-outline" size={28} color="#526079" />
                      <Text className="px-5 text-center text-xs text-[#8B98AD]">{copy.terminalEmpty}</Text>
                    </View>
                  ) : logLines.map(line => (
                    <Text
                      selectable
                      key={line.id}
                      className={cn(
                        'font-mono text-[#C9D3E3]',
                        line.level === 'success' && 'font-bold text-[#4ADE80]',
                        line.level === 'error' && 'font-bold text-[#F87171]',
                      )}
                      style={{ fontSize, lineHeight: fontSize + 6 }}
                    >
                      {line.text}
                    </Text>
                  ))}
                </ScrollView>
              )}
            </View>
          </View>

          {phase === 'done' ? (
            <View className="mb-3 w-full flex-row items-center gap-2.5 rounded-xl bg-success-bg p-3.5">
              <Icon name="checkmark-circle" size={26} color={colors.success} />
              <Text className="flex-1 text-[13px] font-bold text-success-text">{copy.doneText}</Text>
            </View>
          ) : null}

          <SectionCard title={copy.stepsTitle} icon="git-branch-outline" className="mb-3 w-full p-3.5">
            {SETUP_STEPS.map((step, index) => {
              const state = stepStates[step.id] || 'pending';
              const active = state === 'running';
              return (
                <View key={step.id} className="flex-row">
                  <View className="mr-3 items-center">
                    <View className={cn(
                      'h-8 w-8 items-center justify-center rounded-[10px] border',
                      state === 'done' || state === 'skipped'
                        ? 'border-success bg-success'
                        : state === 'error'
                          ? 'border-error bg-error'
                          : active
                            ? 'border-primary bg-primary'
                            : 'border-border bg-bg-elevated',
                    )}>
                      {stepIcon(state, index)}
                    </View>
                    {index < SETUP_STEPS.length - 1 ? (
                      <View className={cn('my-1 w-px flex-1', ['done', 'skipped'].includes(state) ? 'bg-success' : 'bg-border')} />
                    ) : null}
                  </View>
                  <View className={cn('mb-2.5 min-h-[48px] flex-1 rounded-[11px] border px-3 py-2.5', active ? 'border-primary bg-primary-surface' : 'border-transparent bg-bg')}>
                    <View className="flex-row items-start gap-2">
                      <Text className={cn('flex-1 text-xs font-bold', state === 'error' ? 'text-error' : 'text-text')} numberOfLines={2}>
                        {step.title[ru ? 'ru' : 'en']}
                      </Text>
                      <Text className={cn(
                        'text-[10px] font-bold',
                        active ? 'text-primary' : state === 'error' ? 'text-error' : ['done', 'skipped'].includes(state) ? 'text-success' : 'text-text-tertiary',
                      )}>
                        {stepStatus(state)}
                      </Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </SectionCard>

          <SectionCard title={copy.permissionsTitle} icon="shield-checkmark-outline" className="w-full p-3.5">
            <Text className="mt-[-8px] text-[11px] text-text-secondary">{copy.permissionsSub}</Text>
            <View className={cn('items-center gap-2.5 rounded-xl border border-border bg-bg p-2.5', narrow ? 'flex-row flex-wrap' : 'flex-row')}>
              <View className="h-9 w-9 items-center justify-center rounded-[9px] bg-primary-surface">
                <Icon name="folder-open-outline" size={18} color={colors.primary} />
              </View>
              <View className="min-w-0 flex-1">
                <Text className="text-[13px] font-bold text-text">{copy.storage}</Text>
                <Text className="mt-0.5 text-[10px] leading-[14px] text-text-secondary">{copy.storageText}</Text>
              </View>
              <View className={cn('items-end gap-1.5', narrow && 'w-full flex-row justify-end')}>
                <StatusPill label={storageGranted ? copy.granted : copy.notGranted} tone={storageGranted ? 'success' : 'warning'} />
                {!storageGranted ? (
                  <Pressable onPress={grantStorage} className="rounded-lg bg-primary px-2.5 py-1.5">
                    <Text className="text-[11px] font-bold text-white">{copy.storageGrant}</Text>
                  </Pressable>
                ) : null}
              </View>
            </View>
            <View className={cn('items-center gap-2.5 rounded-xl border border-border bg-bg p-2.5', narrow ? 'flex-row flex-wrap' : 'flex-row')}>
              <View className="h-9 w-9 items-center justify-center rounded-[9px] bg-primary-surface">
                <Icon name="notifications-outline" size={18} color={colors.primary} />
              </View>
              <View className="min-w-0 flex-1">
                <Text className="text-[13px] font-bold text-text">{copy.notif}</Text>
                <Text className="mt-0.5 text-[10px] leading-[14px] text-text-secondary">{copy.notifText}</Text>
              </View>
              <View className={cn('items-end gap-1.5', narrow && 'w-full flex-row justify-end')}>
                <StatusPill label={notificationStatus?.granted ? copy.notifGranted : copy.notifDenied} tone={notificationStatus?.granted ? 'success' : 'warning'} />
                {notificationStatus && !notificationStatus.granted ? (
                  <Pressable onPress={grantNotifications} className="rounded-lg bg-primary px-2.5 py-1.5">
                    <Text className="text-[11px] font-bold text-white">
                      {notificationNeedsSettings(notificationStatus) ? copy.notifSettings : copy.notifGrant}
                    </Text>
                  </Pressable>
                ) : null}
              </View>
            </View>
          </SectionCard>

          <Text className="mt-3.5 max-w-[560px] text-center text-[11px] leading-[17px] text-text-secondary">{copy.background}</Text>

          {phase === 'done' ? (
            <Pressable onPress={onComplete} className="mt-2 p-2">
              <Text className="text-[13px] font-bold text-primary">{copy.continueAnyway}</Text>
            </Pressable>
          ) : null}
        </View>
      </ScrollView>
    </AppScreen>
  );
};

export default RaiSetupScreen;