// @ts-nocheck
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import {
  SETUP_STEPS,
  NCS_FAST_STEPS,
  runRaiSetupPty,
  SETUP_STEP_FILE,
  type SetupMode,
} from '../utils/raiSetup';
import { TerminalView, isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';
import {
  startBackground,
  stopBackground,
  updateBackground,
  hasStorageAccess,
  openStorageSettings,
  requestStoragePermissions,
  hasNotificationPermission,
  requestNotificationPermission,
} from '../utils/background';
import { execute } from '../utils/shellExecutor';

const EXTRA_KEYS = '[]';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const RaiSetupScreen = ({ onComplete, resume = false, resumeStep = null }) => {
  const { colors, language } = useAppSettings();
  const ru = language === 'ru';
  const styles = useMemo(() => createStyles(colors), [colors]);

  // 'ncs' — быстрый по умолчанию (300 МБ, 1–2 мин), 'full' — полный Gradle/Kotlin/Compose (1.2–1.5 ГБ)
  const [mode, setMode] = useState<SetupMode>('ncs');
  const [phase, setPhase] = useState<'idle' | 'running' | 'done' | 'error'>('idle');
  const [stepStates, setStepStates] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [fontSize, setFontSize] = useState(12);
  const [storageGranted, setStorageGranted] = useState(false);
  const [notifGranted, setNotifGranted] = useState(true);
  const permissionsAskedRef = useRef(false);
  const scrollRef = useRef(null);
  const terminalRef = useRef<any>(null);
  const terminalReadyRef = useRef(false);
  const busyRef = useRef(false);
  const startedAtRef = useRef(0);
  const runRef = useRef<() => void>(() => {});
  const modeRef = useRef<SetupMode>('ncs');
  useEffect(() => { modeRef.current = mode; }, [mode]);

  const steps = mode === 'ncs' ? NCS_FAST_STEPS : SETUP_STEPS;

  const copy = useMemo(() => ({
    titleNcs: ru ? 'Установка NCS Build' : 'Install NCS Build',
    subtitleNcs: ru
      ? '⚡ Быстрая Java+XML среда без Gradle. Установка за 1–2 мин, ~300 МБ.'
      : '⚡ Fast Java+XML environment without Gradle. Installs in 1–2 min, ~300 MB.',
    titleFull: ru ? 'Полная установка (Gradle + Kotlin + Compose)' : 'Full install (Gradle + Kotlin + Compose)',
    subtitleFull: ru
      ? '🐢 Полное окружение для старых Kotlin+Compose проектов. 5–10 мин, ~1.5 ГБ.'
      : '🐢 Full environment for legacy Kotlin+Compose projects. 5–10 min, ~1.5 GB.',
    stepsTitle: ru ? 'Шаги установки' : 'Setup steps',
    startNcs: ru ? '🚀 Быстрая установка NCS' : '🚀 Fast NCS Install',
    startFull: ru ? '🐢 Установить полный стек (Gradle)' : '🐢 Install full stack (Gradle)',
    switchToNcs: ru ? 'Переключиться на быструю NCS' : 'Switch to fast NCS',
    switchToFull: ru ? 'Нужен старый режим (Gradle+Kotlin+Compose)?' : 'Need the legacy (Gradle+Kotlin+Compose) mode?',
    resume: ru ? 'Продолжить установку' : 'Resume setup',
    running: ru ? 'Установка идёт…' : 'Installing…',
    retry: ru ? 'Повторить' : 'Retry',
    continueAnyway: ru ? 'Продолжить в проекты' : 'Continue to projects',
    done: ru ? '✅ Среда готова к работе!' : '✅ Environment is ready!',
    doneTextNcs: ru
      ? 'Java + Android SDK (build-tools 35 + platform 35) + NCS Build установлены. Создавайте Java+XML приложения и собирайте APK за 2–8 секунд.'
      : 'Java + Android SDK (build-tools 35 + platform 35) + NCS Build installed. Create Java+XML apps and build APKs in 2–8 seconds.',
    doneTextFull: ru
      ? 'Полное RAI-окружение (Gradle/Kotlin/Compose + NCS) установлено.'
      : 'Full RAI environment (Gradle/Kotlin/Compose + NCS) installed.',
    background: ru
      ? 'Установка идёт в фоне. Закрыли приложение — она продолжится с того же шага при следующем запуске.'
      : 'Setup runs in background. If you close the app, it resumes from where it stopped.',
    noShell: ru
      ? 'Нативный терминал недоступен. Откройте development-сборку.'
      : 'Native terminal unavailable. Open the development build.',
    logTitle: ru ? 'Терминал Ubuntu' : 'Ubuntu terminal',
    permissionsTitle: ru ? 'Разрешения' : 'Permissions',
    permissionsSub: ru ? 'Нужны для фоновой установки и сохранения APK.' : 'Needed for background setup and saving APKs.',
    storage: ru ? 'Память' : 'Storage',
    storageText: ru
      ? 'Сохранять собранные APK в /sdcard/Download и видеть файлы.'
      : 'Save built APKs to /sdcard/Download and access files.',
    storageGrant: ru ? 'Разрешить доступ' : 'Grant access',
    granted: ru ? 'Разрешено' : 'Granted',
    notGranted: ru ? 'Не разрешено' : 'Not granted',
    notif: ru ? 'Уведомления' : 'Notifications',
    notifText: ru ? 'Показывать статус фоновой установки/сборки.' : 'Show background setup/build status.',
    notifGrant: ru ? 'Разрешить' : 'Allow',
    notifGranted: ru ? 'Разрешены' : 'Allowed',
    notifDenied: ru ? 'Не разрешены' : 'Not allowed',
    resumeInfo: ru
      ? 'Установка не была завершена. Продолжаем с места обрыва.'
      : 'Setup was not finished. Resuming from where it stopped.',
    errorText: ru
      ? 'Установка не завершилась. Смотрите терминал выше.'
      : 'Setup failed. See the terminal above.',
    waiting: ru ? 'Запускаю терминал…' : 'Starting terminal…',
  }), [ru]);

  const stepMeta = useMemo(() => {
    const m: Record<string, any> = {};
    steps.forEach((s) => { m[s.id] = s; });
    return m;
  }, [steps]);

  const refreshPermissions = useCallback(async () => {
    setStorageGranted(await hasStorageAccess());
    setNotifGranted(await hasNotificationPermission());
  }, []);

  useEffect(() => { refreshPermissions(); }, [refreshPermissions]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);

  useEffect(() => {
    if (permissionsAskedRef.current) return;
    permissionsAskedRef.current = true;
    const t = setTimeout(async () => {
      try {
        if (!(await hasStorageAccess())) {
          await requestStoragePermissions();
          await openStorageSettings();
        }
      } catch {}
      try {
        if (!(await hasNotificationPermission())) {
          await requestNotificationPermission();
        }
      } catch {}
      setTimeout(refreshPermissions, 800);
    }, 600);
    return () => clearTimeout(t);
  }, [refreshPermissions]);

  const grantStorage = async () => {
    if (!(await hasStorageAccess())) {
      await requestStoragePermissions();
      await openStorageSettings();
    }
    setTimeout(refreshPermissions, 600);
  };
  const grantNotif = async () => {
    if (!(await hasNotificationPermission())) await requestNotificationPermission();
    setTimeout(refreshPermissions, 600);
  };

  useEffect(() => {
    if (phase !== 'running') return;
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startedAtRef.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const setStep = useCallback((id: string, state: string) => {
    setStepStates((s) => ({ ...s, [id]: state }));
  }, []);

  const waitTerminalReady = async () => {
    if (terminalReadyRef.current) return;
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline && !terminalReadyRef.current) await sleep(300);
    if (terminalReadyRef.current) await sleep(800);
  };

  const run = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    const currentMode = modeRef.current;
    setPhase('running');
    setError('');
    setElapsed(0);
    setStepStates({});
    startedAtRef.current = Date.now();
    const title = currentMode === 'ncs' ? copy.titleNcs : copy.titleFull;
    await startBackground(title);
    await updateBackground(copy.subtitleNcs);

    const onStepStart = (id: string) => setStep(id, 'running');
    const onStepEnd = (id: string, step: any, res: any) => {
      const state = res.status === 'done' ? 'done' : res.status === 'skipped' ? 'skipped' : 'error';
      setStep(id, state);
      const label = step?.title?.[ru ? 'ru' : 'en'] || id;
      updateBackground(`${title}: ${res.status === 'done' ? '✓' : res.status === 'skipped' ? '~' : '✗'} ${label}`).catch(() => {});
    };

    try {
      let result: any;
      if (terminalRef.current && terminalAvailable()) {
        await waitTerminalReady();
        if (terminalReadyRef.current) {
          result = await runRaiSetupPty({
            terminal: { write: (text: string) => { try { terminalRef.current?.writeText?.(text); } catch {} } },
            onStepStart,
            onStepEnd,
            mode: currentMode,
          });
        } else {
          result = await runRaiSetup({ onStepStart, onStepEnd, onLine: () => {}, mode: currentMode });
        }
      } else {
        result = await runRaiSetup({ onStepStart, onStepEnd, onLine: () => {}, mode: currentMode });
      }

      if (result?.ok) {
        setPhase('done');
        try { terminalRef.current?.writeText?.('\r\n✅ ' + copy.done + '\r\n'); } catch {}
        await stopBackground();
        setTimeout(onComplete, 1200);
      } else {
        setError(copy.errorText);
        setPhase('error');
        try { terminalRef.current?.writeText?.('\r\n❌ ' + copy.errorText + '\r\n'); } catch {}
      }
    } catch (e: any) {
      setError(e?.message || String(e));
      setPhase('error');
    } finally {
      busyRef.current = false;
      setTimeout(() => scrollRef.current?.scrollToEnd?.({ animated: true }), 100);
    }
  }, [copy, onComplete, ru, setStep]);

  runRef.current = run;

  useEffect(() => {
    if (resume) {
      const t = setTimeout(() => runRef.current(), 500);
      return () => clearTimeout(t);
    }
  }, [resume]);

  const restartFromScratch = async () => {
    try {
      await execute(`rm -f ${SETUP_STEP_FILE} /root/.rai-step.done /root/.ncs/.setup.done /root/.rai-setup.done`, '/');
    } catch {}
    setStepStates({});
    runRef.current();
  };

  const onTerminalEvent = (event: any) => {
    const value = event?.nativeEvent || event;
    if (value?.type === 'started') terminalReadyRef.current = true;
    if (value?.type === 'exit') terminalReadyRef.current = false;
  };

  const stepIcon = (state: string) => {
    switch (state) {
      case 'done': return <Icon name="checkmark-circle" size={17} color={colors.success} />;
      case 'skipped': return <Icon name="checkmark-done-circle-outline" size={17} color={colors.textTertiary} />;
      case 'error': return <Icon name="close-circle" size={17} color={colors.error} />;
      case 'running': return <Icon name="sync" size={15} color={colors.primary} />;
      default: return <View style={[styles.dot, { backgroundColor: colors.border }]} />;
    }
  };
  const stepTone = (state: string) =>
    state === 'error' ? 'error' : state === 'done' || state === 'skipped' ? 'success' : 'neutral';

  const title = mode === 'ncs' ? copy.titleNcs : copy.titleFull;
  const subtitle = mode === 'ncs' ? copy.subtitleNcs : copy.subtitleFull;
  const startLabel =
    phase === 'running' ? copy.running :
    phase === 'error' ? copy.retry :
    resume && phase === 'idle' ? copy.resume :
    mode === 'ncs' ? copy.startNcs : copy.startFull;

  return (
    <AppScreen>
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled" ref={scrollRef}>
        <View style={styles.content}>
          <View style={styles.brandMark}>
            <Icon name={mode === 'ncs' ? 'flash' : 'build'} size={30} color="#FFFFFF" />
          </View>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>{subtitle}</Text>

          {/* Переключатель режима */}
          {phase === 'idle' && (
            <View style={styles.modeSwitch}>
              <Pressable
                style={[styles.modeBtn, mode === 'ncs' && styles.modeBtnActive]}
                onPress={() => setMode('ncs')}
              >
                <Text style={[styles.modeBtnText, mode === 'ncs' && styles.modeBtnTextActive]}>
                  ⚡ {ru ? 'Быстрая NCS' : 'Fast NCS'}
                </Text>
                <Text style={[styles.modeBtnHint, mode === 'ncs' && styles.modeBtnTextActive]}>
                  ~300 МБ · 1–2 мин
                </Text>
              </Pressable>
              <Pressable
                style={[styles.modeBtn, mode === 'full' && styles.modeBtnActive]}
                onPress={() => setMode('full')}
              >
                <Text style={[styles.modeBtnText, mode === 'full' && styles.modeBtnTextActive]}>
                  🐢 {ru ? 'Полная Gradle' : 'Full Gradle'}
                </Text>
                <Text style={[styles.modeBtnHint, mode === 'full' && styles.modeBtnTextActive]}>
                  ~1.5 ГБ · 5–10 мин
                </Text>
              </Pressable>
            </View>
          )}

          {resume && phase === 'idle' ? (
            <View style={styles.resumeBox}>
              <Icon name="information-circle-outline" size={18} color={colors.info} />
              <Text style={styles.resumeText}>{copy.resumeInfo}</Text>
            </View>
          ) : null}

          <SectionCard title={copy.stepsTitle} icon="list-outline" style={styles.card}>
            {steps.map((s: any) => {
              const state = stepStates[s.id] || 'pending';
              return (
                <View key={s.id} style={styles.stepRow}>
                  {stepIcon(state)}
                  <Text style={[styles.stepText, state === 'error' && { color: colors.error }]} numberOfLines={2}>
                    {s.title[ru ? 'ru' : 'en']}
                  </Text>
                  <StatusPill
                    label={
                      state === 'done' ? (ru ? 'Готово' : 'Done') :
                      state === 'skipped' ? (ru ? 'Пропущен' : 'Skipped') :
                      state === 'running' ? (ru ? 'Идёт' : 'Run') :
                      state === 'error' ? (ru ? 'Ошибка' : 'Error') :
                      ''
                    }
                    tone={stepTone(state)}
                  />
                </View>
              );
            })}
          </SectionCard>

          {phase === 'error' && error ? (
            <View style={styles.errorBox}>
              <Icon name="alert-circle-outline" size={20} color={colors.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          {/* Разрешения */}
          <SectionCard title={copy.permissionsTitle} icon="shield-checkmark-outline" style={styles.card}>
            <Text style={styles.permissionsSub}>{copy.permissionsSub}</Text>
            <View style={styles.permRow}>
              <View style={styles.permIcon}><Icon name="folder-open-outline" size={18} color={colors.primary} /></View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.permTitle}>{copy.storage}</Text>
                <Text style={styles.permText}>{copy.storageText}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <StatusPill label={storageGranted ? copy.granted : copy.notGranted} tone={storageGranted ? 'success' : 'warning'} />
                {!storageGranted ? <Pressable onPress={grantStorage} style={styles.miniBtn}><Text style={styles.miniBtnText}>{copy.storageGrant}</Text></Pressable> : null}
              </View>
            </View>
            <View style={styles.permRow}>
              <View style={styles.permIcon}><Icon name="notifications-outline" size={18} color={colors.primary} /></View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.permTitle}>{copy.notif}</Text>
                <Text style={styles.permText}>{copy.notifText}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <StatusPill label={notifGranted ? copy.notifGranted : copy.notifDenied} tone={notifGranted ? 'success' : 'warning'} />
                {!notifGranted ? <Pressable onPress={grantNotif} style={styles.miniBtn}><Text style={styles.miniBtnText}>{copy.notifGrant}</Text></Pressable> : null}
              </View>
            </View>
          </SectionCard>

          {/* Терминал */}
          <View style={styles.consoleWrap}>
            <View style={styles.consoleHead}>
              <View style={styles.dots}>
                <View style={[styles.dot, { backgroundColor: '#F87171' }]} />
                <View style={[styles.dot, { backgroundColor: '#FBBF24' }]} />
                <View style={[styles.dot, { backgroundColor: '#34D399' }]} />
              </View>
              <Text style={styles.consoleTitle}>{copy.logTitle}</Text>
              <View style={{ flex: 1 }} />
              <IconButton name="remove-outline" onPress={() => setFontSize((v) => Math.max(8, v - 1))} />
              <IconButton name="add-outline" onPress={() => setFontSize((v) => Math.min(22, v + 1))} />
              {phase === 'running' ? <StatusPill label={`${elapsed}s`} tone="info" /> : null}
            </View>
            <View style={styles.terminalWrap}>
              {terminalAvailable() ? (
                <TerminalView
                  ref={terminalRef}
                  style={styles.terminal}
                  fontSize={fontSize}
                  extraKeys={EXTRA_KEYS}
                  readOnly
                  onTerminalEvent={onTerminalEvent}
                />
              ) : (
                <View style={styles.fallbackTerminal}>
                  <Icon name="hardware-chip-outline" size={28} color="#526079" />
                  <Text style={styles.fallbackText}>{copy.noShell}</Text>
                </View>
              )}
            </View>
          </View>

          {phase === 'done' ? (
            <View style={styles.successBox}>
              <Icon name="checkmark-circle" size={26} color={colors.success} />
              <Text style={styles.successText}>
                {mode === 'ncs' ? copy.doneTextNcs : copy.doneTextFull}
              </Text>
            </View>
          ) : (
            <View style={{ width: '100%', gap: 8, marginTop: 14 }}>
              <PrimaryButton
                title={startLabel}
                icon={phase === 'running' ? undefined : 'download-outline'}
                loading={phase === 'running'}
                disabled={phase === 'running'}
                onPress={run}
                style={{ width: '100%' }}
              />
              {phase === 'error' ? (
                <Pressable onPress={restartFromScratch} style={styles.link}>
                  <Text style={styles.linkText}>{ru ? 'Сбросить и начать заново' : 'Reset & restart'}</Text>
                </Pressable>
              ) : null}
            </View>
          )}

          <Text style={styles.backgroundHint}>{copy.background}</Text>

          {phase === 'idle' && mode === 'ncs' && (
            <Pressable onPress={() => setMode('full')} style={styles.link}>
              <Text style={styles.linkText}>{copy.switchToFull}</Text>
            </Pressable>
          )}
          {phase === 'idle' && mode === 'full' && (
            <Pressable onPress={() => setMode('ncs')} style={styles.link}>
              <Text style={styles.linkText}>← {copy.switchToNcs}</Text>
            </Pressable>
          )}

          {phase === 'done' ? (
            <Pressable onPress={onComplete} style={styles.link}>
              <Text style={styles.linkText}>{copy.continueAnyway}</Text>
            </Pressable>
          ) : null}
        </View>
      </ScrollView>
    </AppScreen>
  );
};

const createStyles = (c: any) => StyleSheet.create({
  page: { flexGrow: 1, padding: 20 },
  content: { width: '100%', maxWidth: 680, alignSelf: 'center', alignItems: 'center' },
  brandMark: { width: 62, height: 62, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary, marginBottom: 18 },
  title: { color: c.text, fontSize: 26, fontWeight: '800', textAlign: 'center', letterSpacing: -0.4 },
  subtitle: { color: c.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 540, marginTop: 8, marginBottom: 14 },
  modeSwitch: {
    flexDirection: 'row',
    gap: 10,
    width: '100%',
    marginBottom: 14,
  },
  modeBtn: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: c.border,
    backgroundColor: c.bgElevated,
    alignItems: 'center',
    gap: 2,
  },
  modeBtnActive: {
    borderColor: c.primary,
    backgroundColor: c.primarySurface,
  },
  modeBtnText: { color: c.text, fontSize: 13, fontWeight: '700', textAlign: 'center' },
  modeBtnHint: { color: c.textSecondary, fontSize: 11, textAlign: 'center' },
  modeBtnTextActive: { color: c.primary },
  resumeBox: { width: '100%', flexDirection: 'row', alignItems: 'flex-start', gap: 9, padding: 12, borderRadius: 11, backgroundColor: c.infoBg, marginBottom: 12 },
  resumeText: { flex: 1, color: c.infoText, fontSize: 12, lineHeight: 18 },
  card: { width: '100%', padding: 16 },
  stepRow: { minHeight: 38, flexDirection: 'row', alignItems: 'center', gap: 9 },
  stepText: { flex: 1, color: c.text, fontSize: 13, fontWeight: '600' },
  dot: { width: 7, height: 7, borderRadius: 4 },
  errorBox: { width: '100%', flexDirection: 'row', alignItems: 'flex-start', gap: 9, padding: 12, borderRadius: 11, backgroundColor: c.errorBg, marginTop: 12 },
  errorText: { flex: 1, color: c.errorText, fontSize: 12, lineHeight: 18 },
  consoleWrap: { width: '100%', borderRadius: 12, overflow: 'hidden', backgroundColor: c.terminal, borderWidth: 1, borderColor: '#253046', marginTop: 14 },
  consoleHead: { minHeight: 40, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.terminalRaised, borderBottomWidth: 1, borderBottomColor: '#253046' },
  dots: { flexDirection: 'row', gap: 5 },
  consoleTitle: { color: '#D6DEEB', fontSize: 11, fontWeight: '700' },
  terminalWrap: { height: 360, backgroundColor: c.terminal },
  terminal: { flex: 1, backgroundColor: c.terminal },
  fallbackTerminal: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  fallbackText: { color: '#8B98AD', fontSize: 12, textAlign: 'center', paddingHorizontal: 20 },
  successBox: { width: '100%', flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderRadius: 12, backgroundColor: c.successBg, marginTop: 14 },
  successText: { flex: 1, color: c.successText, fontSize: 13, fontWeight: '700' },
  permissionsSub: { color: c.textSecondary, fontSize: 11, marginTop: -8, marginBottom: 6 },
  permRow: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 10, borderRadius: 11, borderWidth: 1, borderColor: c.border, backgroundColor: c.bg },
  permIcon: { width: 36, height: 36, borderRadius: 9, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' },
  permTitle: { color: c.text, fontSize: 13, fontWeight: '750' },
  permText: { color: c.textSecondary, fontSize: 10, lineHeight: 14, marginTop: 2 },
  miniBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: c.primary },
  miniBtnText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  backgroundHint: { color: c.textSecondary, fontSize: 11, lineHeight: 17, textAlign: 'center', maxWidth: 540, marginTop: 14 },
  link: { marginTop: 10, padding: 8 },
  linkText: { color: c.primary, fontSize: 13, fontWeight: '700', textAlign: 'center' },
});

export default RaiSetupScreen;
