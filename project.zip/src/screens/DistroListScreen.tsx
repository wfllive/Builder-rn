/**
 * Экран со списком установленных дистрибутивов — отсюда запускаем сессии
 */
import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { theme } from '../utils/theme';
import { useTerminal } from '../store/terminal';
import { DISTROS } from '../data/distros';
import { Card } from '../components/TerminalView';

export default function DistroListScreen({ navigation }: any) {
  const {
    initialized,
    installedDistros,
    setup,
    refreshInstalled,
    startSession,
    removeDistro,
    setupError,
  } = useTerminal();

  useEffect(() => {
    setup();
  }, [setup]);

  useEffect(() => {
    const unsub = navigation.addListener('focus', () => refreshInstalled());
    return unsub;
  }, [navigation]);

  if (!initialized) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={theme.primary} size="large" />
        <Text style={styles.muted}>
          {setupError ? `Ошибка: ${setupError}` : 'Инициализация ядра proot…'}
        </Text>
      </View>
    );
  }

  const onLaunch = async (id: string) => {
    const sid = await startSession(id);
    if (sid) {
      navigation.navigate('Terminal');
    }
  };

  const onRemove = (id: string) => {
    Alert.alert('Удалить?', `Удалить ${id}? Все данные будут потеряны.`, [
      { text: 'Отмена', style: 'cancel' },
      { text: 'Удалить', style: 'destructive', onPress: () => removeDistro(id) },
    ]);
  };

  return (
    <ScrollView style={styles.root} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.title}>📥 Установленные дистрибутивы</Text>
      <Text style={styles.muted}>
        {installedDistros.length} шт · {installedDistros.reduce((a, d) => a + d.sizeMB, 0).toFixed(0)} МБ
      </Text>

      {installedDistros.length === 0 ? (
        <Card style={{ alignItems: 'center', padding: 32, marginTop: 20 }}>
          <Text style={{ fontSize: 48, marginBottom: 12 }}>📭</Text>
          <Text style={styles.title}>Пока ничего</Text>
          <Text style={styles.muted}>Перейдите в каталог и установите</Text>
        </Card>
      ) : (
        installedDistros.map((d) => {
          const info = DISTROS.find((x) => x.id === d.id);
          if (!info) return null;
          return (
            <Card key={d.id} style={styles.card}>
              <View style={styles.row}>
                <Text style={styles.icon}>{info.iconEmoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{info.name}</Text>
                  <Text style={styles.meta}>
                    {info.version ?? info.family} · {d.sizeMB.toFixed(0)} МБ
                  </Text>
                </View>
              </View>
              <View style={styles.btnRow}>
                <Pressable
                  onPress={() => onLaunch(d.id)}
                  style={({ pressed }) => [
                    styles.btnPrimary,
                    { opacity: pressed ? 0.7 : 1 },
                  ]}
                >
                  <Text style={styles.btnPrimaryText}>▶ Запустить</Text>
                </Pressable>
                <Pressable
                  onPress={() => onRemove(d.id)}
                  style={({ pressed }) => [
                    styles.btnDanger,
                    { opacity: pressed ? 0.7 : 1 },
                  ]}
                >
                  <Text style={styles.btnDangerText}>🗑 Удалить</Text>
                </Pressable>
              </View>
            </Card>
          );
        })
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.bg },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.bg,
  },
  title: {
    color: theme.text,
    fontFamily: theme.font.mono,
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  muted: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 12, marginBottom: 16 },
  card: { marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  icon: { fontSize: 32 },
  name: { color: theme.text, fontFamily: theme.font.mono, fontSize: 16, fontWeight: '700' },
  meta: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 11, marginTop: 2 },
  btnRow: { flexDirection: 'row', gap: 8 },
  btnPrimary: {
    flex: 1,
    backgroundColor: theme.primary,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  btnPrimaryText: {
    color: theme.bg,
    fontFamily: theme.font.mono,
    fontWeight: '700',
    fontSize: 14,
  },
  btnDanger: {
    backgroundColor: theme.bgInput,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.error,
  },
  btnDangerText: {
    color: theme.error,
    fontFamily: theme.font.mono,
    fontWeight: '600',
    fontSize: 13,
  },
});
