import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { blockCategories, blockDefinitions } from '../utils/blockDefinitions';
import { generateId } from '../utils/generateId';
import { generateComposePreviewSource, syncComposeProject } from '../utils/composeProject';

const englishCategoryLabels = {
  EVENT: 'Events', CONTROL: 'Control', OPERATOR: 'Operators', VARIABLE: 'Variables',
  LOGIC: 'Logic', COMPONENT: 'Components', MATH: 'Math', TEXT: 'Text', LIST: 'Lists',
};

const englishBlockLabels = {
  on_click: 'When component is pressed', on_create: 'When screen opens', on_back_pressed: 'When back is pressed',
  if_else: 'if … else', repeat: 'repeat N times', forever: 'repeat forever', wait: 'wait (ms)',
  add: 'add', subtract: 'subtract', multiply: 'multiply', divide: 'divide',
  set_var: 'set variable', get_var: 'get variable', change_var: 'change variable by',
  and: 'and', or: 'or', not: 'not', equals: 'equals', set_text: 'set component text', get_text: 'get component text',
  set_visible: 'set visibility', navigate: 'navigate to screen', show_toast: 'show alert',
  random: 'random number from … to', round: 'round', join: 'join text', length: 'text length',
  list_add: 'add to list', list_get: 'get list item',
};

const categoryIcons = {
  EVENT: 'flash-outline', CONTROL: 'git-branch-outline', OPERATOR: 'code-slash-outline',
  VARIABLE: 'server-outline', LOGIC: 'git-compare-outline', COMPONENT: 'shapes-outline',
  MATH: 'calculator-outline', TEXT: 'text-outline', LIST: 'list-outline',
};

const eventIds = new Set(['on_create', 'on_click', 'on_back_pressed']);
const branchBlocks = new Set(['if_else', 'repeat', 'forever']);

const flattenComponents = (root, result = []) => {
  if (!root) return result;
  result.push({ id: root.id, type: root.type, label: root.props?.text || root.props?.hint || root.type });
  (root.children || []).forEach((child) => flattenComponents(child, result));
  return result;
};

const findBlock = (list, id) => {
  for (const block of list || []) {
    if (block.id === id) return block;
    for (const slot of ['next', 'do', 'else']) {
      const found = findBlock(block.children?.[slot] || [], id);
      if (found) return found;
    }
  }
  return null;
};

const patchBlocks = (list, id, updater) => (list || []).map((block) => {
  if (block.id === id) return updater(block);
  const children = { ...block.children };
  ['next', 'do', 'else'].forEach((slot) => {
    if (children[slot]) children[slot] = patchBlocks(children[slot], id, updater);
  });
  return { ...block, children };
});

const removeBlock = (list, id) => (list || [])
  .filter((block) => block.id !== id)
  .map((block) => {
    const children = { ...block.children };
    ['next', 'do', 'else'].forEach((slot) => {
      if (children[slot]) children[slot] = removeBlock(children[slot], id);
    });
    return { ...block, children };
  });

const createBlock = (definition) => ({
  id: generateId(),
  definitionId: definition.id,
  category: definition.category,
  position: { x: 0, y: 0 },
  inputs: Object.fromEntries((definition.inputs || []).map((input) => [input.label, ''])),
  children: {},
});

const BlockEditorScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, language, t } = useAppSettings();
  const {
    currentProject, currentScreenId, getCurrentScreen, updateBlocks,
    undo, redo, undoStack, redoStack, addWorkspaceLog,
  } = useProject();
  const screen = getCurrentScreen();
  const blocks = screen?.blocks || [];
  const [expanded, setExpanded] = useState({ EVENT: true, COMPONENT: true });
  const [selectedBlockId, setSelectedBlockId] = useState(blocks[0]?.id || null);
  const [viewMode, setViewMode] = useState('visual');
  const [saveState, setSaveState] = useState('saved');
  const [picker, setPicker] = useState(null);
  const styles = useMemo(() => createStyles(colors, width), [colors, width]);
  const compact = width < 620;
  const components = useMemo(() => flattenComponents(screen?.rootComponent), [screen?.rootComponent]);
  const screenIndex = currentProject?.screens?.findIndex((item) => item.id === currentScreenId) || 0;
  const source = useMemo(
    () => currentProject && screen ? generateComposePreviewSource(currentProject, screen, screenIndex) : '',
    [currentProject, screen, screenIndex],
  );

  const copy = language === 'ru' ? {
    title: 'Логика Compose', subtitle: 'Блоки сохраняются как настоящий Kotlin @Composable код',
    library: 'Блоки', workspace: 'Рабочая область', code: 'Kotlin Compose', visual: 'Блоки',
    empty: 'Добавьте событие или действие слева', emptyHint: 'Раскройте категорию и нажмите блок. Выбранное действие добавится внутрь текущего блока.',
    delete: 'Удалить блок?', save: 'Сохранить код', saving: 'Сохранение', saved: 'Сохранено', error: 'Ошибка сохранения',
    addInside: 'Добавить внутрь', addElse: 'Добавить в иначе', selected: 'Выбран', topLevel: 'В начало сценария',
    component: 'Компонент', selectComponent: 'Выберите компонент на экране', close: 'Закрыть',
    generated: 'Этот Kotlin-код записывается в ui/screens/*Screen.kt и компилируется Gradle как Jetpack Compose.',
    autoSaveError: 'Блоки сохранены в конструкторе, но Compose-файл обновить не удалось.',
  } : {
    title: 'Compose logic', subtitle: 'Blocks are persisted as real Kotlin @Composable code',
    library: 'Blocks', workspace: 'Workspace', code: 'Kotlin Compose', visual: 'Blocks',
    empty: 'Add an event or action from the left', emptyHint: 'Expand a category and press a block. An action is inserted into the selected block.',
    delete: 'Delete block?', save: 'Save code', saving: 'Saving', saved: 'Saved', error: 'Save error',
    addInside: 'Add inside', addElse: 'Add to else', selected: 'Selected', topLevel: 'Top level',
    component: 'Component', selectComponent: 'Select a screen component', close: 'Close',
    generated: 'This Kotlin source is written to ui/screens/*Screen.kt and compiled by Gradle as Jetpack Compose.',
    autoSaveError: 'Blocks were saved in the builder, but the Compose source file could not be updated.',
  };

  const blockLabel = (definition) => language === 'en' ? (englishBlockLabels[definition.id] || definition.label) : definition.label;
  const categoryLabel = (category) => language === 'en' ? englishCategoryLabels[category.id] : category.label;

  const save = async (silent = false) => {
    if (!currentProject) return;
    setSaveState('saving');
    const result = await syncComposeProject(currentProject);
    if (result?.success) {
      setSaveState('saved');
      if (!silent) addWorkspaceLog(result.output || 'Kotlin Compose code saved', 'success');
    } else {
      setSaveState('error');
      addWorkspaceLog(result?.output || copy.autoSaveError, 'error');
      if (!silent) Alert.alert(copy.error, result?.output || copy.autoSaveError);
    }
  };

  const blockSnapshot = useMemo(() => JSON.stringify(blocks), [blocks]);
  useEffect(() => {
    if (!currentProject) return undefined;
    setSaveState('saving');
    const projectToSave = currentProject;
    const timer = setTimeout(async () => {
      const result = await syncComposeProject(projectToSave);
      setSaveState(result?.success ? 'saved' : 'error');
      if (!result?.success) addWorkspaceLog(result?.output || copy.autoSaveError, 'error');
    }, 850);
    return () => clearTimeout(timer);
  }, [blockSnapshot]);

  if (!screen) return <AppScreen style={styles.center}><Text style={styles.muted}>No active screen</Text></AppScreen>;

  const insertBlock = (definition, slot = null) => {
    const nextBlock = createBlock(definition);
    const selected = findBlock(blocks, selectedBlockId);
    if (!eventIds.has(definition.id) && selected) {
      const targetSlot = slot || (branchBlocks.has(selected.definitionId) ? 'do' : 'next');
      updateBlocks(patchBlocks(blocks, selected.id, (block) => ({
        ...block,
        children: { ...block.children, [targetSlot]: [...(block.children?.[targetSlot] || []), nextBlock] },
      })));
    } else {
      updateBlocks([...blocks, nextBlock]);
    }
    setSelectedBlockId(nextBlock.id);
    setPicker(null);
  };

  const setInput = (id, key, value) => updateBlocks(patchBlocks(blocks, id, (block) => ({
    ...block,
    inputs: { ...block.inputs, [key]: value },
  })));

  const requestDelete = (id) => Alert.alert(copy.delete, '', [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: () => {
      updateBlocks(removeBlock(blocks, id));
      if (selectedBlockId === id) setSelectedBlockId(null);
    } },
  ]);

  const renderInput = (block, input) => {
    const value = String(block.inputs?.[input.label] ?? '');
    if (input.type === 'component') {
      return (
        <View key={input.label} style={styles.blockInputGroup}>
          <Text style={styles.inputLabel}>{copy.component}</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.componentChips}>
            {components.map((component) => {
              const active = value === component.id;
              return (
                <Pressable key={component.id} onPress={() => setInput(block.id, input.label, component.id)} style={[styles.componentChip, active && styles.componentChipActive]}>
                  <Icon name={component.type === 'Button' ? 'radio-button-on-outline' : 'cube-outline'} size={13} color={active ? colors.primary : colors.textSecondary} />
                  <Text style={[styles.componentChipText, active && { color: colors.primary }]} numberOfLines={1}>{component.label}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
        </View>
      );
    }
    return (
      <View key={input.label} style={styles.inputRow}>
        <Text style={styles.inputLabel}>{input.label}</Text>
        <TextInput
          value={value}
          onChangeText={(next) => setInput(block.id, input.label, next)}
          placeholder={input.type}
          placeholderTextColor={colors.textTertiary}
          keyboardType={input.type === 'number' ? 'numeric' : 'default'}
          autoCapitalize="none"
          style={styles.input}
        />
      </View>
    );
  };

  const BlockCard = ({ block, nested = false, slot = 'next' }) => {
    const definition = blockDefinitions.find((item) => item.id === block.definitionId);
    if (!definition) return null;
    const category = blockCategories[definition.category];
    const selected = block.id === selectedBlockId;
    return (
      <Pressable onPress={() => setSelectedBlockId(block.id)} style={[styles.block, nested && styles.blockNested, selected && styles.blockSelected, { borderLeftColor: category.color }]}>
        <View style={styles.blockHead}>
          <View style={[styles.blockIcon, { backgroundColor: `${category.color}22` }]}><Icon name={categoryIcons[definition.category]} size={15} color={category.color} /></View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={styles.blockName} numberOfLines={2}>{blockLabel(definition)}</Text>
            <Text style={styles.blockType}>{selected ? copy.selected : definition.shape}</Text>
          </View>
          <IconButton name="add-outline" onPress={() => setPicker({ parentId: block.id, slot: branchBlocks.has(block.definitionId) ? 'do' : 'next' })} style={styles.smallButton} />
          <IconButton name="trash-outline" danger onPress={() => requestDelete(block.id)} style={styles.smallButton} />
        </View>
        {(definition.inputs || []).length ? <View style={styles.inputs}>{definition.inputs.map((input) => renderInput(block, input))}</View> : null}

        {branchBlocks.has(block.definitionId) ? (
          <Branch
            label={copy.addInside}
            blocks={block.children?.do || []}
            onAdd={() => setPicker({ parentId: block.id, slot: 'do' })}
            render={(child) => <BlockCard key={child.id} block={child} nested slot="do" />}
            styles={styles}
            colors={colors}
          />
        ) : null}
        {block.definitionId === 'if_else' ? (
          <Branch
            label={copy.addElse}
            blocks={block.children?.else || []}
            onAdd={() => setPicker({ parentId: block.id, slot: 'else' })}
            render={(child) => <BlockCard key={child.id} block={child} nested slot="else" />}
            styles={styles}
            colors={colors}
          />
        ) : null}
        {(block.children?.next || []).length ? <View style={styles.nextBlocks}>{block.children.next.map((child) => <BlockCard key={child.id} block={child} nested slot="next" />)}</View> : null}
      </Pressable>
    );
  };

  const statusTone = saveState === 'saved' ? 'success' : saveState === 'error' ? 'error' : 'info';
  const statusLabel = saveState === 'saved' ? copy.saved : saveState === 'error' ? copy.error : copy.saving;

  return (
    <AppScreen>
      <TopBar
        compact
        title={copy.title}
        subtitle={`${screen.name} · ${copy.subtitle}`}
        onBack={() => navigation.goBack()}
        right={<>
          {!compact ? <StatusPill label={statusLabel} tone={statusTone} /> : null}
          <IconButton name="arrow-undo-outline" disabled={!undoStack.length} onPress={undo} />
          {!compact ? <IconButton name="arrow-redo-outline" disabled={!redoStack.length} onPress={redo} /> : null}
          <PrimaryButton title={!compact ? copy.save : ''} icon="save-outline" loading={saveState === 'saving'} onPress={() => save(false)} />
        </>}
      />

      <View style={styles.main}>
        <View style={styles.library}>
          <View style={styles.panelHead}><Icon name="library-outline" size={16} color={colors.primary} /><Text style={styles.panelTitle}>{copy.library}</Text></View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.libraryContent}>
            {Object.values(blockCategories).map((category) => {
              const open = Boolean(expanded[category.id]);
              const definitions = blockDefinitions.filter((definition) => definition.category === category.id);
              return (
                <View key={category.id} style={styles.categoryGroup}>
                  <Pressable onPress={() => setExpanded((value) => ({ ...value, [category.id]: !open }))} style={styles.categoryRow}>
                    <View style={[styles.categoryIcon, { backgroundColor: `${category.color}20` }]}><Icon name={categoryIcons[category.id]} size={14} color={category.color} /></View>
                    <Text style={styles.categoryName} numberOfLines={1}>{categoryLabel(category)}</Text>
                    <Icon name={open ? 'chevron-down' : 'chevron-forward'} size={13} color={colors.textTertiary} />
                  </Pressable>
                  {open ? definitions.map((definition) => (
                    <Pressable key={definition.id} onPress={() => insertBlock(definition)} style={({ pressed }) => [styles.libraryBlock, pressed && { backgroundColor: colors.primarySurface }]}>
                      <View style={[styles.blockDot, { backgroundColor: category.color }]} />
                      <Text style={styles.libraryBlockText} numberOfLines={2}>{blockLabel(definition)}</Text>
                      <Icon name="add-circle-outline" size={14} color={category.color} />
                    </Pressable>
                  )) : null}
                </View>
              );
            })}
          </ScrollView>
        </View>

        <View style={styles.workspace}>
          <View style={styles.workspaceHead}>
            <SegmentedControl compact value={viewMode} onChange={setViewMode} options={[
              { value: 'visual', label: copy.visual, icon: 'git-network-outline' },
              { value: 'code', label: copy.code, icon: 'code-slash-outline' },
            ]} />
            <View style={{ flex: 1 }} />
            <Text style={styles.blockCount}>{blocks.length} top-level</Text>
          </View>

          {viewMode === 'visual' ? (
            <ScrollView style={styles.blockScroll} contentContainerStyle={styles.blockContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              {blocks.length ? blocks.map((block) => <BlockCard key={block.id} block={block} />) : (
                <View style={styles.empty}>
                  <View style={styles.emptyIcon}><Icon name="git-network-outline" size={29} color={colors.primary} /></View>
                  <Text style={styles.emptyTitle}>{copy.empty}</Text>
                  <Text style={styles.emptyHint}>{copy.emptyHint}</Text>
                </View>
              )}
            </ScrollView>
          ) : (
            <View style={styles.codeWrap}>
              <Text style={styles.codeHint}>{copy.generated}</Text>
              <ScrollView style={styles.codeScroll} horizontal nestedScrollEnabled><Text selectable style={styles.codeText}>{source}</Text></ScrollView>
            </View>
          )}
        </View>
      </View>

      <Modal visible={Boolean(picker)} transparent animationType="fade" onRequestClose={() => setPicker(null)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.pickerCard} title={picker?.slot === 'else' ? copy.addElse : copy.addInside} icon="add-circle-outline">
            <ScrollView style={styles.pickerScroll}>
              {blockDefinitions.filter((definition) => !eventIds.has(definition.id) && definition.shape !== 'reporter').map((definition) => {
                const category = blockCategories[definition.category];
                return (
                  <Pressable key={definition.id} onPress={() => {
                    setSelectedBlockId(picker.parentId);
                    const next = createBlock(definition);
                    updateBlocks(patchBlocks(blocks, picker.parentId, (block) => ({ ...block, children: { ...block.children, [picker.slot]: [...(block.children?.[picker.slot] || []), next] } })));
                    setSelectedBlockId(next.id);
                    setPicker(null);
                  }} style={styles.pickerRow}>
                    <View style={[styles.categoryIcon, { backgroundColor: `${category.color}20` }]}><Icon name={categoryIcons[definition.category]} size={14} color={category.color} /></View>
                    <Text style={styles.pickerText}>{blockLabel(definition)}</Text>
                    <Icon name="add" size={16} color={colors.primary} />
                  </Pressable>
                );
              })}
            </ScrollView>
            <IconButton name="close" label={copy.close} onPress={() => setPicker(null)} />
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>
  );
};

const Branch = ({ label, blocks, onAdd, render, styles, colors }) => (
  <View style={styles.branch}>
    <View style={styles.branchHead}><Icon name="return-down-forward-outline" size={14} color={colors.textTertiary} /><Text style={styles.branchLabel}>{label}</Text><Pressable onPress={onAdd} hitSlop={8}><Icon name="add-circle-outline" size={17} color={colors.primary} /></Pressable></View>
    {blocks.length ? blocks.map(render) : <Pressable onPress={onAdd} style={styles.branchEmpty}><Icon name="add-outline" size={14} color={colors.textTertiary} /><Text style={styles.branchEmptyText}>{label}</Text></Pressable>}
  </View>
);

const createStyles = (c, width) => {
  const compact = width < 620;
  return StyleSheet.create({
    center: { alignItems: 'center', justifyContent: 'center' }, muted: { color: c.textSecondary },
    main: { flex: 1, minHeight: 0, flexDirection: 'row' },
    library: { width: compact ? 148 : 230, flexShrink: 0, backgroundColor: c.bgCard, borderRightWidth: 1, borderRightColor: c.border },
    panelHead: { height: 45, paddingHorizontal: compact ? 8 : 12, flexDirection: 'row', alignItems: 'center', gap: 7, borderBottomWidth: 1, borderBottomColor: c.border },
    panelTitle: { color: c.text, fontSize: 12, fontWeight: '750' },
    libraryContent: { padding: compact ? 4 : 7, paddingBottom: 30 },
    categoryGroup: { marginBottom: 3 },
    categoryRow: { minHeight: 42, paddingHorizontal: compact ? 5 : 7, flexDirection: 'row', alignItems: 'center', gap: compact ? 5 : 8, borderRadius: 8 },
    categoryIcon: { width: 29, height: 29, flexShrink: 0, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
    categoryName: { flex: 1, minWidth: 0, color: c.text, fontSize: compact ? 9 : 11, fontWeight: '700' },
    libraryBlock: { minHeight: 40, marginLeft: compact ? 4 : 10, paddingHorizontal: compact ? 5 : 8, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 7 },
    blockDot: { width: 5, height: 22, borderRadius: 3, flexShrink: 0 },
    libraryBlockText: { flex: 1, minWidth: 0, color: c.textSecondary, fontSize: compact ? 8 : 10, lineHeight: compact ? 11 : 14 },
    workspace: { flex: 1, minWidth: 0, backgroundColor: c.canvas },
    workspaceHead: { minHeight: 47, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
    blockCount: { color: c.textTertiary, fontSize: 8, fontFamily: 'monospace' },
    blockScroll: { flex: 1 },
    blockContent: { width: '100%', maxWidth: 780, alignSelf: 'center', padding: compact ? 8 : 16, paddingBottom: 60 },
    block: { minWidth: 0, marginBottom: 9, padding: compact ? 8 : 11, borderRadius: 11, borderWidth: 1, borderLeftWidth: 5, borderColor: c.border, backgroundColor: c.bgCard },
    blockNested: { marginLeft: compact ? 7 : 15, marginTop: 8, marginBottom: 0 },
    blockSelected: { borderColor: c.primary, backgroundColor: c.primarySurface },
    blockHead: { minHeight: 36, flexDirection: 'row', alignItems: 'center', gap: compact ? 5 : 8 },
    blockIcon: { width: 31, height: 31, flexShrink: 0, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
    blockName: { color: c.text, fontSize: compact ? 9 : 12, lineHeight: compact ? 12 : 16, fontWeight: '700' },
    blockType: { color: c.textTertiary, fontSize: 8, marginTop: 2 },
    smallButton: { minWidth: compact ? 28 : 32, width: compact ? 28 : 32, height: compact ? 28 : 32, paddingHorizontal: 0, borderWidth: 0, backgroundColor: 'transparent' },
    inputs: { marginTop: 8, paddingTop: 8, gap: 7, borderTopWidth: 1, borderTopColor: c.border },
    inputRow: { flexDirection: compact ? 'column' : 'row', alignItems: compact ? 'stretch' : 'center', gap: 5 },
    inputLabel: { width: compact ? undefined : 82, color: c.textSecondary, fontSize: 9 },
    input: { minHeight: 35, flex: 1, minWidth: 0, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 7, borderWidth: 1, borderColor: c.borderLight, backgroundColor: c.bgInput, color: c.text, fontSize: 10, fontFamily: 'monospace' },
    blockInputGroup: { gap: 5 },
    componentChips: { gap: 5, paddingBottom: 2 },
    componentChip: { maxWidth: 145, minHeight: 32, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 7, borderWidth: 1, borderColor: c.border, backgroundColor: c.bg },
    componentChipActive: { borderColor: c.primary, backgroundColor: c.primarySurface },
    componentChipText: { maxWidth: 105, color: c.textSecondary, fontSize: 8 },
    branch: { marginTop: 8, paddingTop: 7, borderTopWidth: 1, borderTopColor: c.border },
    branchHead: { minHeight: 27, flexDirection: 'row', alignItems: 'center', gap: 6 },
    branchLabel: { flex: 1, color: c.textSecondary, fontSize: 9, fontWeight: '650' },
    branchEmpty: { minHeight: 37, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, borderWidth: 1, borderStyle: 'dashed', borderColor: c.borderLight, borderRadius: 7 },
    branchEmptyText: { color: c.textTertiary, fontSize: 8 },
    nextBlocks: { marginTop: 7 },
    empty: { minHeight: 380, alignItems: 'center', justifyContent: 'center', padding: 18 },
    emptyIcon: { width: 62, height: 62, borderRadius: 18, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' },
    emptyTitle: { color: c.text, fontSize: 14, fontWeight: '750', textAlign: 'center', marginTop: 13 },
    emptyHint: { maxWidth: 390, color: c.textSecondary, fontSize: 10, lineHeight: 16, textAlign: 'center', marginTop: 5 },
    codeWrap: { flex: 1, minHeight: 0, padding: compact ? 7 : 12, gap: 8 },
    codeHint: { color: c.textSecondary, fontSize: 9, lineHeight: 14 },
    codeScroll: { flex: 1, borderRadius: 10, backgroundColor: c.terminal },
    codeText: { padding: 12, color: '#C9D3E3', fontFamily: 'monospace', fontSize: compact ? 8 : 10, lineHeight: compact ? 13 : 16 },
    overlay: { flex: 1, justifyContent: 'center', padding: 16, backgroundColor: c.overlay },
    pickerCard: { width: '100%', maxWidth: 520, maxHeight: '78%', alignSelf: 'center' },
    pickerScroll: { maxHeight: 430 },
    pickerRow: { minHeight: 48, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 9, borderBottomWidth: 1, borderBottomColor: c.border },
    pickerText: { flex: 1, color: c.text, fontSize: 11, fontWeight: '650' },
  });
};

export default BlockEditorScreen;
