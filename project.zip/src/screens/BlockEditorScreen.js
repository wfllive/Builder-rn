import React, { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import { Alert, Modal, PanResponder, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { blockCategories, blockDefinitions } from '../utils/blockDefinitions';
import { generateId } from '../utils/generateId';
import { generateComposePreviewSource, syncComposeProject } from '../utils/composeProject';

const englishBlockLabels = {
  remember_int_state: 'Remember Int State', remember_string_state: 'Remember String State', remember_boolean_state: 'Remember Boolean State', update_state: 'Update State Value',
  scaffold: 'Scaffold with TopBar', column: 'Column Layout', row: 'Row Layout', elevated_card: 'ElevatedCard',
  text: 'Text', text_with_variable: 'Text with $variable', button: 'Button', outlined_button: 'OutlinedButton', info_row: 'InfoRow (Label + Value)',
  modifier_fill_max_size: 'Fill Max Size', modifier_fill_max_width: 'Fill Max Width', modifier_padding: 'Padding', modifier_vertical_scroll: 'Vertical Scroll',
  on_click_increment: 'Increment Variable', on_click_set_value: 'Set Variable Value',
  style_headline_small: 'Headline Small Style', style_title_large: 'Title Large Style', style_label_large: 'Label Large Style', style_body_medium: 'Body Medium Style', font_weight_bold: 'Bold Font Weight',
};

const categoryIcons = {
  STATE: 'server-outline', LAYOUT: 'layers-outline', UI: 'cube-outline', MODIFIER: 'color-palette-outline', EVENT: 'flash-outline', TEXT_STYLE: 'text-outline',
};

const branchBlocks = new Set([
  'scaffold', 'column', 'row', 'box', 'elevated_card', 'outlined_card', 'surface',
  'if_else', 'repeat_times', 'while_loop', 'when_expression', 'try_catch',
  'launched_effect', 'disposable_effect', 'side_effect', 'produce_state',
  'alert_dialog', 'modal_bottom_sheet', 'lazy_column', 'lazy_row'
]);

const flattenComponents = (root, result = []) => {
  if (!root) return result;
  result.push({ id: root.id, type: root.type, label: root.props?.text || root.props?.hint || root.type });
  (root.children || []).forEach((child) => flattenComponents(child, result));
  return result;
};

const findBlock = (list, id) => {
  for (const block of list || []) {
    if (block.id === id) return block;
    for (const slot of ['next', 'content']) {
      const found = findBlock(block.children?.[slot] || [], id);
      if (found) return found;
    }
  }
  return null;
};

const findBlockParent = (list, id, parent = null) => {
  for (const block of list || []) {
    if (block.id === id) return parent;
    for (const slot of ['next', 'content']) {
      const found = findBlockParent(block.children?.[slot] || [], id, block);
      if (found !== undefined) return found;
    }
  }
  return undefined;
};

const patchBlocks = (list, id, updater) => (list || []).map((block) => {
  if (block.id === id) return updater(block);
  const children = { ...block.children };
  ['next', 'content'].forEach((slot) => {
    if (children[slot]) children[slot] = patchBlocks(children[slot], id, updater);
  });
  return { ...block, children };
});

const removeBlock = (list, id) => (list || [])
  .filter((block) => block.id !== id)
  .map((block) => {
    const children = { ...block.children };
    ['next', 'content'].forEach((slot) => {
      if (children[slot]) children[slot] = removeBlock(children[slot], id);
    });
    return { ...block, children };
  });

const createBlock = (definition) => ({
  id: generateId(),
  definitionId: definition.id,
  category: definition.category,
  inputs: Object.fromEntries((definition.inputs || []).map((input) => [input.label, ''])),
  children: {},
});

const BlockEditorScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors } = useAppSettings();
  const {
    currentProject, currentScreenId, getCurrentScreen, updateBlocks,
    addWorkspaceLog,
  } = useProject();
  const screen = getCurrentScreen();
  const blocks = screen?.blocks || [];
  const [expanded, setExpanded] = useState({ STATE: true, UI: true });
  const [selectedBlockId, setSelectedBlockId] = useState(blocks[0]?.id || null);
  const [viewMode, setViewMode] = useState('visual');
  const [saveState, setSaveState] = useState('saved');
  const [showLibrary, setShowLibrary] = useState(false);
  const styles = useMemo(() => createStyles(colors, width), [colors, width]);
  const components = useMemo(() => flattenComponents(screen?.rootComponent), [screen?.rootComponent]);
  const screenIndex = currentProject?.screens?.findIndex((item) => item.id === currentScreenId) || 0;
  const source = useMemo(
    () => {
      if (!currentProject || !screen) return '';
      // Всегда показываем оригинальный код из файла
      // НЕ генерируем из блоков - это вызывает дублирование
      if (screen.source != null && screen.source !== '') return screen.source;
      return generateComposePreviewSource(currentProject, screen, screenIndex);
    },
    [currentProject, screen, screenIndex],
  );

  const copy = {
    title: 'React Logic', subtitle: 'Blocks generate JSX components',
    library: 'Blocks', empty: 'No blocks yet', emptyHint: 'Tap + to add blocks from library',
    delete: 'Delete block?', save: 'Save', saving: 'Saving', saved: 'Saved', error: 'Error',
    addInside: 'Add inside', selected: 'Selected', close: 'Close',
    generated: 'React JSX source',
    autoSaveError: 'Blocks saved but Compose file update failed.',
  };

  const blockLabel = (definition) => englishBlockLabels[definition.id] || definition.label;

  const save = async (silent = false) => {
    if (!currentProject) return;
    setSaveState('saving');
    const result = await syncComposeProject(currentProject, { skipPreamble: true });
    if (result?.success) {
      setSaveState('saved');
      if (!silent) addWorkspaceLog(result.output || 'JSX code saved', 'success');
    } else {
      setSaveState('error');
    }
  };

  const blockSnapshot = useMemo(() => JSON.stringify(blocks), [blocks]);
  useEffect(() => {
    if (!currentProject) return undefined;
    setSaveState('saving');
    const projectToSave = currentProject;
    const timer = setTimeout(async () => {
      const result = await syncComposeProject(projectToSave, { skipPreamble: true });
      setSaveState(result?.success ? 'saved' : 'error');
    }, 850);
    return () => clearTimeout(timer);
  }, [blockSnapshot]);

  if (!screen) return <AppScreen style={styles.center}><Text style={styles.muted}>No active screen</Text></AppScreen>;

  const insertBlock = (definition, parentId = null, slot = 'content') => {
    const nextBlock = createBlock(definition);
    if (parentId) {
      updateBlocks(patchBlocks(blocks, parentId, (block) => ({
        ...block,
        children: { ...block.children, [slot]: [...(block.children?.[slot] || []), nextBlock] },
      })));
    } else {
      updateBlocks([...blocks, nextBlock]);
    }
    setSelectedBlockId(nextBlock.id);
  };

  const moveBlockUp = (blockId) => {
    const parent = findBlockParent(blocks, blockId);
    if (!parent) {
      // Top-level block
      const idx = blocks.findIndex((b) => b.id === blockId);
      if (idx > 0) {
        const newBlocks = [...blocks];
        [newBlocks[idx - 1], newBlocks[idx]] = [newBlocks[idx], newBlocks[idx - 1]];
        updateBlocks(newBlocks);
      }
    } else {
      const slot = parent.children?.content?.find((b) => b.id === blockId) ? 'content' : 'next';
      const siblings = parent.children?.[slot] || [];
      const idx = siblings.findIndex((b) => b.id === blockId);
      if (idx > 0) {
        const newSiblings = [...siblings];
        [newSiblings[idx - 1], newSiblings[idx]] = [newSiblings[idx], newSiblings[idx - 1]];
        updateBlocks(patchBlocks(blocks, parent.id, (p) => ({
          ...p,
          children: { ...p.children, [slot]: newSiblings },
        })));
      }
    }
  };

  const moveBlockDown = (blockId) => {
    const parent = findBlockParent(blocks, blockId);
    if (!parent) {
      const idx = blocks.findIndex((b) => b.id === blockId);
      if (idx < blocks.length - 1) {
        const newBlocks = [...blocks];
        [newBlocks[idx], newBlocks[idx + 1]] = [newBlocks[idx + 1], newBlocks[idx]];
        updateBlocks(newBlocks);
      }
    } else {
      const slot = parent.children?.content?.find((b) => b.id === blockId) ? 'content' : 'next';
      const siblings = parent.children?.[slot] || [];
      const idx = siblings.findIndex((b) => b.id === blockId);
      if (idx < siblings.length - 1) {
        const newSiblings = [...siblings];
        [newSiblings[idx], newSiblings[idx + 1]] = [newSiblings[idx + 1], newSiblings[idx]];
        updateBlocks(patchBlocks(blocks, parent.id, (p) => ({
          ...p,
          children: { ...p.children, [slot]: newSiblings },
        })));
      }
    }
  };

  const setInput = (id, key, value) => updateBlocks(patchBlocks(blocks, id, (block) => ({
    ...block,
    inputs: { ...block.inputs, [key]: value },
  })));

  const requestDelete = (id) => Alert.alert(copy.delete, '', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: () => {
      updateBlocks(removeBlock(blocks, id));
      if (selectedBlockId === id) setSelectedBlockId(null);
    } },
  ]);

  const renderInput = (block, input) => {
    const value = String(block.inputs?.[input.label] ?? '');
    const placeholder = input.placeholder || input.label;
    if (input.type === 'component') {
      return (
        <View key={input.label} style={styles.inputRow}>
          <Text style={styles.inputLabel}>{input.label}</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.componentChips}>
            {components.map((component) => {
              const active = value === component.id;
              return (
                <Pressable key={component.id} onPress={() => setInput(block.id, input.label, component.id)} style={[styles.componentChip, active && styles.componentChipActive]}>
                  <Text style={[styles.componentChipText, active && { color: colors.primary }]} numberOfLines={1}>{component.label}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
        </View>
      );
    }
    return (
      <View key={input.label} style={styles.inputRow}>
        <Text style={styles.inputLabel}>{input.label}</Text>
        <TextInput
          value={value}
          onChangeText={(next) => setInput(block.id, input.label, next)}
          placeholder={placeholder}
          placeholderTextColor={colors.textTertiary}
          keyboardType={input.type === 'number' ? 'numeric' : 'default'}
          style={styles.input}
          editable={true}
        />
      </View>
    );
  };

  const BlockCard = React.memo(({ block, depth = 0 }) => {
    const definition = blockDefinitions.find((item) => item.id === block.definitionId);
    if (!definition) return null;
    const category = blockCategories[definition.category];
    const selected = block.id === selectedBlockId;
    const children = block.children || {};

    // Determine content slots based on block type
    const renderContentSlot = (slotName, label) => {
      const slotChildren = children[slotName] || [];
      const isEmpty = slotChildren.length === 0;
      
      return (
        <View style={styles.contentArea}>
          <Text style={styles.contentSlotLabel}>{label}:</Text>
          {isEmpty ? (
            <Pressable onPress={() => setShowLibrary(true)} style={styles.emptyContentSlot}>
              <Icon name="add-outline" size={16} color={colors.primary} />
              <Text style={styles.emptyContentText}>Drop blocks here</Text>
            </Pressable>
          ) : (
            slotChildren.map((child) => (
              <BlockCard key={child.id} block={child} depth={depth + 1} />
            ))
          )}
        </View>
      );
    };

    return (
      <View style={[styles.blockWrapper, { marginLeft: depth * 20 }]}>
        <Pressable
          onPress={() => setSelectedBlockId(block.id)}
          style={[
            styles.block, 
            selected && styles.blockSelected, 
            { borderLeftColor: category?.color || '#666', borderLeftWidth: definition.shape === 'c-block' ? 5 : 4 }
          ]}
        >
          {/* Header */}
          <View style={styles.blockHeader}>
            <View style={[styles.blockIcon, { backgroundColor: `${category?.color || '#666'}20` }]}>
              <Icon name={categoryIcons[definition.category] || 'cube-outline'} size={18} color={category?.color || '#666'} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.blockTitle}>{blockLabel(definition)}</Text>
              {definition.description ? <Text style={styles.blockDesc} numberOfLines={1}>{definition.description}</Text> : null}
            </View>
            {/* Action buttons */}
            <View style={styles.blockActions}>
              <Pressable onPress={() => moveBlockUp(block.id)} style={styles.actionBtn}>
                <Icon name="arrow-up-outline" size={16} color={colors.textSecondary} />
              </Pressable>
              <Pressable onPress={() => moveBlockDown(block.id)} style={styles.actionBtn}>
                <Icon name="arrow-down-outline" size={16} color={colors.textSecondary} />
              </Pressable>
              <Pressable onPress={() => requestDelete(block.id)} style={styles.actionBtn}>
                <Icon name="trash-outline" size={16} color="#F87171" />
              </Pressable>
            </View>
          </View>

          {/* Inputs */}
          {(definition.inputs || []).length > 0 ? (
            <View style={styles.inputsContainer}>
              {definition.inputs.map((input) => renderInput(block, input))}
            </View>
          ) : null}

          {/* C-Block content slots */}
          {definition.shape === 'c-block' ? (
            <View style={styles.cBlockContainer}>
              {/* Then/Do slot */}
              {definition.outputs?.includes('then') && renderContentSlot('then', 'Then')}
              {definition.outputs?.includes('do') && renderContentSlot('do', 'Do')}
              {definition.outputs?.includes('try') && renderContentSlot('try', 'Try')}
              
              {/* Else slot */}
              {definition.outputs?.includes('else') && renderContentSlot('else', 'Else')}
              {definition.outputs?.includes('catch') && renderContentSlot('catch', 'Catch')}
              {definition.outputs?.includes('onDispose') && renderContentSlot('onDispose', 'On Dispose')}
              
              {/* Branches slot (for when expression) */}
              {definition.outputs?.includes('branches') && renderContentSlot('branches', 'Cases')}
            </View>
          ) : null}

          {/* Next blocks */}
          {children.next?.length > 0 && (
            <View style={styles.nextArea}>
              {children.next.map((child) => (
                <BlockCard key={child.id} block={child} depth={depth} />
              ))}
            </View>
          )}
        </Pressable>
      </View>
    );
  }, (prevProps, nextProps) => {
    // Only re-render if block ID or selected state changed
    return prevProps.block.id === nextProps.block.id && prevProps.depth === nextProps.depth;
  });

  return (
    <AppScreen>
      <TopBar
        compact
        title={copy.title}
        subtitle={`${screen.name} · ${copy.subtitle}`}
        onBack={() => navigation.goBack()}
        right={<PrimaryButton title={copy.save} icon="save-outline" loading={saveState === 'saving'} onPress={() => save(false)} />}
      />

      <View style={styles.workspace}>
        <View style={styles.workspaceHead}>
          <SegmentedControl compact value={viewMode} onChange={setViewMode} options={[
            { value: 'visual', label: 'Blocks', icon: 'git-network-outline' },
            { value: 'code', label: 'Code', icon: 'code-slash-outline' },
          ]} />
        </View>

        {viewMode === 'visual' ? (
          <ScrollView style={styles.blockScroll} contentContainerStyle={styles.blockContent}>
            {blocks.length > 0 ? (
              blocks.map((block) => <BlockCard key={block.id} block={block} />)
            ) : (
              <View style={styles.empty}>
                <Icon name="cube-outline" size={56} color={colors.textTertiary} />
                <Text style={styles.emptyTitle}>{copy.empty}</Text>
                <Text style={styles.emptyHint}>{copy.emptyHint}</Text>
              </View>
            )}
          </ScrollView>
        ) : (
          <ScrollView style={styles.codeScroll}>
            <Text style={styles.codeText}>{source}</Text>
          </ScrollView>
        )}

        {/* FAB */}
        <Pressable onPress={() => setShowLibrary(true)} style={styles.fab}>
          <Icon name="add" size={32} color="#FFFFFF" />
        </Pressable>
      </View>

      {/* Library Modal */}
      <Modal visible={showLibrary} transparent animationType="slide" onRequestClose={() => setShowLibrary(false)}>
        <View style={styles.overlay}>
          <View style={styles.libraryModal}>
            <View style={styles.libraryHeader}>
              <Text style={styles.libraryTitle}>Block Library</Text>
              <IconButton name="close" onPress={() => setShowLibrary(false)} />
            </View>
            <ScrollView style={styles.libraryScroll}>
              {Object.entries(blockCategories).map(([catId, category]) => {
                const isExpanded = expanded[catId];
                const defs = blockDefinitions.filter((d) => d.category === catId);
                return (
                  <View key={catId} style={styles.categorySection}>
                    <Pressable onPress={() => setExpanded({ ...expanded, [catId]: !isExpanded })} style={styles.categoryHeader}>
                      <Icon name={categoryIcons[catId] || 'cube-outline'} size={20} color={category.color} />
                      <Text style={[styles.categoryName, { color: category.color }]}>{category.label}</Text>
                      <Icon name={isExpanded ? 'chevron-up-outline' : 'chevron-down-outline'} size={18} color={colors.textTertiary} />
                    </Pressable>
                    {isExpanded && defs.map((def) => (
                      <Pressable
                        key={def.id}
                        onPress={() => { insertBlock(def); setShowLibrary(false); }}
                        style={({ pressed }) => [styles.libraryBlock, pressed && styles.libraryBlockPressed]}
                      >
                        <View style={[styles.libraryBlockIcon, { backgroundColor: `${category.color}20` }]}>
                          <Icon name={categoryIcons[catId] || 'cube-outline'} size={16} color={category.color} />
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.libraryBlockText}>{blockLabel(def)}</Text>
                          {def.description ? <Text style={styles.libraryBlockDesc} numberOfLines={1}>{def.description}</Text> : null}
                        </View>
                      </Pressable>
                    ))}
                  </View>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </AppScreen>
  );
};

const createStyles = (colors, width) => StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  muted: { color: colors.textSecondary },
  workspace: { flex: 1, backgroundColor: colors.bg },
  workspaceHead: { padding: 12, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  blockScroll: { flex: 1 },
  blockContent: { padding: 16, paddingBottom: 100 },
  blockWrapper: { marginBottom: 12 },
  block: { backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderLeftWidth: 5, borderLeftColor: '#666', borderColor: colors.border, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.12, shadowRadius: 6, elevation: 4 },
  blockSelected: { borderColor: colors.primary, borderLeftColor: colors.primary, shadowColor: colors.primary, shadowOpacity: 0.2 },
  blockHeader: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  blockIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  blockTitle: { color: colors.text, fontSize: 15, fontWeight: '700' },
  blockDesc: { color: colors.textTertiary, fontSize: 10, marginTop: 3, fontFamily: 'monospace' },
  blockActions: { flexDirection: 'row', gap: 4 },
  actionBtn: { width: 32, height: 32, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  inputsContainer: { paddingHorizontal: 14, paddingBottom: 14, gap: 10 },
  inputRow: { gap: 6 },
  inputLabel: { color: colors.textSecondary, fontSize: 11, fontWeight: '600' },
  input: { backgroundColor: colors.bgInput, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, color: colors.text, fontSize: 13, borderWidth: 1, borderColor: colors.border },
  componentChips: { gap: 8 },
  componentChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, backgroundColor: colors.bgInput, borderWidth: 1, borderColor: colors.border },
  componentChipActive: { borderColor: colors.primary, backgroundColor: `${colors.primary}15` },
  componentChipText: { color: colors.textSecondary, fontSize: 12 },
  contentArea: { 
    borderTopWidth: 1, 
    borderTopColor: colors.border, 
    padding: 12, 
    backgroundColor: `${colors.bg}50`,
    borderLeftWidth: 3,
    borderLeftColor: colors.border,
    marginLeft: 8,
  },
  contentSlotLabel: { 
    color: colors.textTertiary, 
    fontSize: 10, 
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  addInsideBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 10, borderWidth: 1.5, borderStyle: 'dashed', borderColor: colors.primary },
  addInsideText: { color: colors.primary, fontSize: 12, fontWeight: '600' },
  emptyContentSlot: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 8, 
    padding: 12, 
    borderRadius: 10, 
    borderWidth: 1.5, 
    borderStyle: 'dashed', 
    borderColor: colors.primary,
    backgroundColor: `${colors.primary}08`,
  },
  emptyContentText: { color: colors.primary, fontSize: 12, fontWeight: '600' },
  cBlockContainer: { gap: 4 },
  nextArea: { borderTopWidth: 1, borderTopColor: colors.border },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 60, gap: 16 },
  emptyTitle: { color: colors.text, fontSize: 18, fontWeight: '700' },
  emptyHint: { color: colors.textSecondary, fontSize: 13, textAlign: 'center' },
  fab: { position: 'absolute', bottom: 80, right: 28, width: 64, height: 64, borderRadius: 32, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.35, shadowRadius: 8, elevation: 10 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  libraryModal: { backgroundColor: colors.bgCard, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '70%', marginBottom: 60 },
  libraryHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 18, borderBottomWidth: 1, borderBottomColor: colors.border },
  libraryTitle: { color: colors.text, fontSize: 20, fontWeight: '700' },
  libraryScroll: { maxHeight: 650 },
  categorySection: { borderBottomWidth: 1, borderBottomColor: colors.border },
  categoryHeader: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  categoryName: { flex: 1, fontSize: 16, fontWeight: '700' },
  libraryBlock: { flexDirection: 'row', alignItems: 'center', padding: 14, paddingLeft: 50, gap: 12 },
  libraryBlockPressed: { backgroundColor: colors.primarySurface },
  libraryBlockIcon: { position: 'absolute', left: 14, width: 28, height: 28, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  libraryBlockText: { color: colors.text, fontSize: 14, fontWeight: '600' },
  libraryBlockDesc: { color: colors.textTertiary, fontSize: 11, marginTop: 3 },
  codeScroll: { flex: 1, backgroundColor: colors.terminal },
  codeText: { padding: 18, color: '#C9D3E3', fontFamily: 'monospace', fontSize: 13, lineHeight: 20 },
});

export default BlockEditorScreen;
