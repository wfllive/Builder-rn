import React, { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { blockCategories, blockDefinitions } from '../utils/blockDefinitions';
import { generateId } from '../utils/generateId';

const englishCategoryLabels = {
  EVENT: 'Events', CONTROL: 'Control', OPERATOR: 'Operators', VARIABLE: 'Variables',
  LOGIC: 'Logic', COMPONENT: 'Components', MATH: 'Math', TEXT: 'Text', LIST: 'Lists',
};

const englishBlockLabels = {
  on_click: 'When pressed', on_create: 'When screen opens', on_back_pressed: 'When back is pressed',
  if_else: 'if … else', repeat: 'repeat N times', forever: 'repeat forever', wait: 'wait (ms)',
  add: 'add', subtract: 'subtract', multiply: 'multiply', divide: 'divide',
  set_var: 'set variable', get_var: 'get variable', change_var: 'change variable by',
  and: 'and', or: 'or', not: 'not', equals: 'equals', set_text: 'set text', get_text: 'get text',
  set_visible: 'set visibility', navigate: 'navigate to screen', show_toast: 'show notification',
  random: 'random number from … to', round: 'round', join: 'join text', length: 'text length',
  list_add: 'add to list', list_get: 'get list item',
};

const categoryIcons = {
  EVENT: 'flash-outline', CONTROL: 'git-branch-outline', OPERATOR: 'code-slash-outline',
  VARIABLE: 'server-outline', LOGIC: 'git-compare-outline', COMPONENT: 'shapes-outline',
  MATH: 'calculator-outline', TEXT: 'text-outline', LIST: 'list-outline',
};

const BlockEditorScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, language, t } = useAppSettings();
  const { getCurrentScreen, updateBlocks, undo, redo, undoStack, redoStack } = useProject();
  const screen = getCurrentScreen();
  const [categoryId, setCategoryId] = useState('EVENT');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const desktop = width >= 800;
  const blocks = screen?.blocks || [];
  const category = blockCategories[categoryId];
  const definitions = blockDefinitions.filter((definition) => definition.category === categoryId);
  const blockLabel = (definition) => language === 'en' ? (englishBlockLabels[definition.id] || definition.label) : definition.label;
  const copy = language === 'ru' ? {
    title: 'Редактор логики',
    subtitle: 'События и действия текущего экрана',
    palette: 'Палитра блоков',
    workspace: 'Сценарий',
    empty: 'Добавьте первый блок из палитры',
    emptyHint: 'Блоки выполняются сверху вниз. Событийный блок запускает вложенные действия.',
    add: 'Добавить',
    delete: 'Удалить блок?',
    shape: { hat: 'Событие', stack: 'Действие', reporter: 'Значение', 'c-block': 'Условие' },
  } : {
    title: 'Logic editor',
    subtitle: 'Events and actions for the current screen',
    palette: 'Block palette',
    workspace: 'Script',
    empty: 'Add the first block from the palette',
    emptyHint: 'Blocks run from top to bottom. Event blocks trigger nested actions.',
    add: 'Add',
    delete: 'Delete block?',
    shape: { hat: 'Event', stack: 'Action', reporter: 'Value', 'c-block': 'Condition' },
  };

  if (!screen) return <AppScreen style={styles.center}><Text style={styles.muted}>No active screen</Text></AppScreen>;

  const add = (definition) => updateBlocks([...blocks, {
    id: generateId(),
    definitionId: definition.id,
    category: definition.category,
    position: { x: 0, y: blocks.length * 80 },
    inputs: Object.fromEntries((definition.inputs || []).map((input) => [input.label, ''])),
    children: {},
  }]);

  const removeRecursive = (list, id) => list
    .filter((block) => block.id !== id)
    .map((block) => ({ ...block, children: { ...block.children, next: removeRecursive(block.children?.next || [], id) } }));
  const remove = (id) => Alert.alert(copy.delete, '', [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: () => updateBlocks(removeRecursive(blocks, id)) },
  ]);

  const patchRecursive = (list, id, updater) => list.map((block) => block.id === id
    ? updater(block)
    : { ...block, children: { ...block.children, next: patchRecursive(block.children?.next || [], id, updater) } });
  const setInput = (id, key, value) => updateBlocks(patchRecursive(blocks, id, (block) => ({ ...block, inputs: { ...block.inputs, [key]: value } })));
  const addChild = (id) => {
    const definition = blockDefinitions.find((item) => item.id === 'show_toast');
    const child = { id: generateId(), definitionId: definition.id, category: definition.category, inputs: { text: '' }, children: {} };
    updateBlocks(patchRecursive(blocks, id, (block) => ({ ...block, children: { ...block.children, next: [...(block.children?.next || []), child] } })));
  };

  const Block = ({ block, nested = false }) => {
    const definition = blockDefinitions.find((item) => item.id === block.definitionId);
    if (!definition) return null;
    const categoryData = blockCategories[definition.category];
    return (
      <View style={[styles.block, nested && styles.blockNested, { borderLeftColor: categoryData.color }]}>
        <View style={styles.blockHead}>
          <View style={[styles.blockIcon, { backgroundColor: `${categoryData.color}22` }]}><Icon name={categoryIcons[definition.category]} size={15} color={categoryData.color} /></View>
          <View style={{ flex: 1 }}><Text style={styles.blockName}>{blockLabel(definition)}</Text><Text style={styles.blockType}>{copy.shape[definition.shape] || definition.shape}</Text></View>
          {definition.outputs?.includes('next') ? <IconButton name="add-outline" onPress={() => addChild(block.id)} style={styles.smallButton} /> : null}
          <IconButton name="trash-outline" danger onPress={() => remove(block.id)} style={styles.smallButton} />
        </View>
        {definition.inputs?.length ? (
          <View style={styles.inputs}>
            {definition.inputs.map((input) => (
              <View key={input.label} style={styles.inputRow}>
                <Text style={styles.inputLabel}>{input.label}</Text>
                <TextInput
                  value={String(block.inputs?.[input.label] ?? '')}
                  onChangeText={(value) => setInput(block.id, input.label, value)}
                  placeholder={input.type}
                  placeholderTextColor={colors.textTertiary}
                  keyboardType={input.type === 'number' ? 'numeric' : 'default'}
                  style={styles.input}
                />
              </View>
            ))}
          </View>
        ) : null}
        {block.children?.next?.length ? <View style={styles.children}>{block.children.next.map((child) => <Block key={child.id} block={child} nested />)}</View> : null}
      </View>
    );
  };

  const Palette = () => (
    <View style={[styles.palette, !desktop && styles.paletteMobile]}>
      <View style={styles.panelTitle}><Icon name="library-outline" size={16} color={colors.primary} /><Text style={styles.panelTitleText}>{copy.palette}</Text></View>
      <ScrollView horizontal={!desktop} showsHorizontalScrollIndicator={false} contentContainerStyle={!desktop ? styles.mobileDefinitions : styles.definitionList}>
        {definitions.map((definition) => (
          <Pressable key={definition.id} onPress={() => add(definition)} style={({ pressed }) => [styles.definition, !desktop && styles.definitionMobile, pressed && { borderColor: category.color }]}>
            <View style={[styles.definitionStripe, { backgroundColor: category.color }]} />
            <View style={{ flex: 1, minWidth: 0 }}><Text style={styles.definitionName} numberOfLines={2}>{blockLabel(definition)}</Text><Text style={styles.definitionType}>{copy.shape[definition.shape] || definition.shape}</Text></View>
            <Icon name="add-circle-outline" size={17} color={category.color} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );

  return (
    <AppScreen>
      <TopBar
        title={copy.title}
        subtitle={`${screen.name} · ${copy.subtitle}`}
        onBack={() => navigation.goBack()}
        right={<><IconButton name="arrow-undo-outline" disabled={!undoStack.length} onPress={undo} /><IconButton name="arrow-redo-outline" disabled={!redoStack.length} onPress={redo} /><IconButton name="color-wand-outline" label={width >= 700 ? t('design') : null} active onPress={() => navigation.navigate('Editor')} /></>}
      />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories} contentContainerStyle={styles.categoryContent}>
        {Object.values(blockCategories).map((item) => {
          const active = item.id === categoryId;
          return <Pressable key={item.id} onPress={() => setCategoryId(item.id)} style={[styles.category, active && { backgroundColor: `${item.color}20`, borderColor: item.color }]}><Icon name={categoryIcons[item.id]} size={15} color={active ? item.color : colors.textSecondary} /><Text style={[styles.categoryText, active && { color: item.color }]}>{language === 'en' ? englishCategoryLabels[item.id] : item.label}</Text></Pressable>;
        })}
      </ScrollView>
      <View style={[styles.main, !desktop && { flexDirection: 'column' }]}>
        <Palette />
        <View style={styles.workspace}>
          <View style={styles.panelTitle}><Icon name="git-network-outline" size={16} color={colors.primary} /><Text style={styles.panelTitleText}>{copy.workspace}</Text><View style={{ flex: 1 }} /><Text style={styles.count}>{blocks.length} blocks</Text></View>
          <ScrollView style={styles.blockScroll} contentContainerStyle={styles.blockContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            {blocks.length ? blocks.map((block) => <Block key={block.id} block={block} />) : (
              <View style={styles.empty}><View style={styles.emptyIcon}><Icon name="git-network-outline" size={30} color={colors.primary} /></View><Text style={styles.emptyTitle}>{copy.empty}</Text><Text style={styles.emptyHint}>{copy.emptyHint}</Text></View>
            )}
          </ScrollView>
        </View>
      </View>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center' },
  muted: { color: c.textSecondary },
  categories: { flexGrow: 0, maxHeight: 53, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  categoryContent: { alignItems: 'center', paddingHorizontal: 9, gap: 5 },
  category: { height: 36, paddingHorizontal: 10, borderRadius: 9, borderWidth: 1, borderColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 6 },
  categoryText: { color: c.textSecondary, fontSize: 10, fontWeight: '650' },
  main: { flex: 1, minHeight: 0, flexDirection: 'row' },
  palette: { width: 270, backgroundColor: c.bgCard, borderRightWidth: 1, borderRightColor: c.border },
  paletteMobile: { width: '100%', height: 146, borderRightWidth: 0, borderBottomWidth: 1, borderBottomColor: c.border },
  panelTitle: { height: 45, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8, borderBottomWidth: 1, borderBottomColor: c.border },
  panelTitleText: { color: c.text, fontSize: 12, fontWeight: '750' },
  count: { color: c.textTertiary, fontFamily: 'monospace', fontSize: 9 },
  definitionList: { padding: 8, gap: 6 },
  mobileDefinitions: { padding: 8, gap: 7 },
  definition: { minHeight: 58, borderRadius: 10, borderWidth: 1, borderColor: c.border, backgroundColor: c.bg, flexDirection: 'row', alignItems: 'center', gap: 9, paddingRight: 10, overflow: 'hidden' },
  definitionMobile: { width: 190, height: 76 },
  definitionStripe: { width: 4, alignSelf: 'stretch' },
  definitionName: { color: c.text, fontSize: 11, fontWeight: '650' },
  definitionType: { color: c.textTertiary, fontSize: 9, marginTop: 3 },
  workspace: { flex: 1, minWidth: 0, backgroundColor: c.canvas },
  blockScroll: { flex: 1 },
  blockContent: { width: '100%', maxWidth: 760, alignSelf: 'center', padding: 18, paddingBottom: 60 },
  block: { backgroundColor: c.bgCard, borderRadius: 12, borderWidth: 1, borderColor: c.border, borderLeftWidth: 5, padding: 11, marginBottom: 9, shadowColor: c.shadow, shadowOpacity: c.mode === 'dark' ? 0.16 : 0.06, shadowRadius: 4, elevation: 1 },
  blockNested: { marginLeft: 14, marginTop: 8, marginBottom: 0 },
  blockHead: { minHeight: 38, flexDirection: 'row', alignItems: 'center', gap: 9 },
  blockIcon: { width: 31, height: 31, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  blockName: { color: c.text, fontSize: 12, fontWeight: '700' },
  blockType: { color: c.textTertiary, fontSize: 9, marginTop: 2 },
  smallButton: { minWidth: 32, width: 32, height: 32, borderWidth: 0 },
  inputs: { marginTop: 9, paddingTop: 9, borderTopWidth: 1, borderTopColor: c.border, gap: 7 },
  inputRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  inputLabel: { width: 80, color: c.textSecondary, fontSize: 10 },
  input: { flex: 1, minHeight: 36, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: c.bgInput, borderWidth: 1, borderColor: c.borderLight, color: c.text, fontSize: 11, fontFamily: 'monospace' },
  children: { marginTop: 8, paddingLeft: 2, borderLeftWidth: 1, borderLeftColor: c.borderLight },
  empty: { alignItems: 'center', justifyContent: 'center', paddingTop: 90, paddingHorizontal: 24 },
  emptyIcon: { width: 65, height: 65, borderRadius: 19, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { color: c.text, fontSize: 15, fontWeight: '750', marginTop: 14 },
  emptyHint: { color: c.textSecondary, fontSize: 11, lineHeight: 17, textAlign: 'center', maxWidth: 380, marginTop: 5 },
});

export default BlockEditorScreen;
