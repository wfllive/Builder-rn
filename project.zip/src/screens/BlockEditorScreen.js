import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { useProject } from '../store/projectStore';
import { blockDefinitions, blockCategories } from '../utils/blockDefinitions';
import colors from '../theme/colors';
import { generateId } from '../utils/generateId';

const BlockEditorScreen = ({ navigation }) => {
  const {
    currentProject,
    currentScreenId,
    updateBlocks,
    getCurrentScreen,
    undo,
    redo,
    undoStack,
    redoStack,
  } = useProject();

  const currentScreen = getCurrentScreen();
  const [selectedCategory, setSelectedCategory] = useState('EVENT');
  const [editingBlockId, setEditingBlockId] = useState(null);
  const [editingInput, setEditingInput] = useState('');
  const [editingValue, setEditingValue] = useState('');
  const [viewMode, setViewMode] = useState('visual'); // visual | list

  if (!currentScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.emptyText}>Нет активного экрана</Text>
      </View>
    );
  }

  const blocks = currentScreen.blocks || [];
  const categoryBlocks = blockDefinitions.filter(b => b.category === selectedCategory);
  const category = blockCategories[selectedCategory];

  const handleAddBlock = (definition) => {
    const newBlock = {
      id: generateId(),
      definitionId: definition.id,
      category: definition.category,
      position: { x: 50 + Math.random() * 100, y: 50 + blocks.length * 100 },
      inputs: {},
      children: {},
    };
    updateBlocks([...blocks, newBlock]);
  };

  const handleDeleteBlock = (blockId) => {
    Alert.alert(
      'Удалить блок?',
      'Блок будет удалён безвозвратно.',
      [
        { text: 'Отмена', style: 'cancel' },
        { text: 'Удалить', style: 'destructive', onPress: () => {
          updateBlocks(blocks.filter(b => b.id !== blockId));
        }},
      ]
    );
  };

  const handleUpdateInput = (blockId, inputKey, value) => {
    const updatedBlocks = blocks.map(b => {
      if (b.id === blockId) {
        return { ...b, inputs: { ...b.inputs, [inputKey]: value } };
      }
      return b;
    });
    updateBlocks(updatedBlocks);
    setEditingBlockId(null);
    setEditingInput('');
    setEditingValue('');
  };

  const handleAddChildBlock = (parentBlockId, childDefinition) => {
    const newChild = {
      id: generateId(),
      definitionId: childDefinition.id,
      category: childDefinition.category,
      inputs: {},
      children: {},
    };

    const updatedBlocks = blocks.map(b => {
      if (b.id === parentBlockId) {
        return {
          ...b,
          children: {
            ...b.children,
            next: [...(b.children?.next || []), newChild],
          },
        };
      }
      return b;
    });
    updateBlocks(updatedBlocks);
  };

  const renderBlock = (block, isNested = false, parentId = null) => {
    const definition = blockDefinitions.find(d => d.id === block.definitionId);
    if (!definition) return null;

    const blockColor = blockCategories[block.category]?.color || '#666';

    return (
      <View
        key={block.id}
        style={[
          styles.block,
          {
            backgroundColor: blockColor,
            borderLeftColor: blockColor,
            marginLeft: isNested ? 16 : 0,
          },
          definition.shape === 'hat' && styles.hatBlock,
          definition.shape === 'reporter' && styles.reporterBlock,
          definition.shape === 'c-block' && styles.cBlock,
        ]}
      >
        <View style={styles.blockHeader}>
          <Text style={styles.blockLabel}>{definition.label}</Text>
          <View style={styles.blockActions}>
            {definition.outputs?.includes('next') && (
              <TouchableOpacity
                style={styles.blockAddChildBtn}
                onPress={() => {
                  // Show menu to add child block
                  Alert.alert(
                    'Добавить блок',
                    'Выберите тип блока',
                    [
                      { text: 'show_toast', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'show_toast')) },
                      { text: 'set_var', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'set_var')) },
                      { text: 'navigate', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'navigate')) },
                      { text: 'Отмена', style: 'cancel' },
                    ]
                  );
                }}
              >
                <Text style={styles.blockAddChildText}>+</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={styles.blockDeleteBtn}
              onPress={() => handleDeleteBlock(block.id)}
            >
              <Text style={styles.blockDeleteText}>✕</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Input fields */}
        {definition.inputs && definition.inputs.length > 0 && (
          <View style={styles.blockInputs}>
            {definition.inputs.map((input, idx) => (
              <View key={idx} style={styles.blockInputRow}>
                <Text style={styles.blockInputLabel}>{input.label}:</Text>
                <TouchableOpacity
                  style={styles.blockInputField}
                  onPress={() => {
                    setEditingBlockId(block.id);
                    setEditingInput(input.label);
                    setEditingValue(block.inputs?.[input.label] || '');
                  }}
                >
                  <Text style={styles.blockInputText}>
                    {block.inputs?.[input.label] || `<${input.type}>`}
                  </Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        {/* Nested children */}
        {block.children?.next && block.children.next.length > 0 && (
          <View style={styles.blockChildren}>
            {block.children.next.map(child => renderBlock(child, true, block.id))}
          </View>
        )}

        {/* Add child button for empty containers */}
        {definition.outputs?.includes('next') && (!block.children?.next || block.children.next.length === 0) && (
          <TouchableOpacity
            style={styles.addChildPlaceholder}
            onPress={() => {
              Alert.alert(
                'Добавить блок',
                'Выберите тип блока',
                [
                  { text: 'show_toast', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'show_toast')) },
                  { text: 'set_var', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'set_var')) },
                  { text: 'navigate', onPress: () => handleAddChildBlock(block.id, blockDefinitions.find(b => b.id === 'navigate')) },
                  { text: 'Отмена', style: 'cancel' },
                ]
              );
            }}
          >
            <Text style={styles.addChildPlaceholderText}>+ Добавить блок</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Назад</Text>
        </TouchableOpacity>
        <Text style={styles.title}>🧩 Блоки - {currentScreen.name}</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            style={[styles.headerButton, undoStack.length === 0 && styles.disabledButton]}
            onPress={undo}
            disabled={undoStack.length === 0}
          >
            <Text style={styles.headerButtonText}>↶</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.headerButton, redoStack.length === 0 && styles.disabledButton]}
            onPress={redo}
            disabled={redoStack.length === 0}
          >
            <Text style={styles.headerButtonText}>↷</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.mainContent}>
        {/* Block Palette */}
        <View style={styles.palette}>
          <Text style={styles.paletteTitle}>Блоки</Text>
          
          {/* Category tabs */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryTabs}>
            {Object.values(blockCategories).map(cat => (
              <TouchableOpacity
                key={cat.id}
                style={[
                  styles.categoryTab,
                  { backgroundColor: selectedCategory === cat.id ? cat.color : colors.surfaceLight },
                ]}
                onPress={() => setSelectedCategory(cat.id)}
              >
                <Text style={[
                  styles.categoryTabText,
                  selectedCategory === cat.id && styles.categoryTabTextActive,
                ]}>
                  {cat.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Block list */}
          <ScrollView style={styles.blockList}>
            {categoryBlocks.map(definition => (
              <TouchableOpacity
                key={definition.id}
                style={[
                  styles.paletteBlock,
                  { borderLeftColor: category.color },
                ]}
                onPress={() => handleAddBlock(definition)}
                activeOpacity={0.7}
              >
                <View style={styles.paletteBlockHeader}>
                  <Text style={styles.paletteBlockLabel}>{definition.label}</Text>
                  <View style={[styles.shapeTag, { backgroundColor: category.color + '40' }]}>
                    <Text style={[styles.shapeTagText, { color: category.color }]}>
                      {definition.shape}
                    </Text>
                  </View>
                </View>
                {definition.inputs && definition.inputs.length > 0 && (
                  <Text style={styles.paletteBlockInputs}>
                    Входы: {definition.inputs.map(i => i.label).join(', ')}
                  </Text>
                )}
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Block Canvas */}
        <View style={styles.canvas}>
          <View style={styles.canvasHeader}>
            <Text style={styles.canvasTitle}>Холст блоков</Text>
            <Text style={styles.canvasInfo}>{blocks.length} блоков</Text>
          </View>
          <ScrollView
            style={styles.canvasScroll}
            contentContainerStyle={styles.canvasContent}
          >
            {blocks.length === 0 ? (
              <View style={styles.emptyCanvas}>
                <Text style={styles.emptyCanvasIcon}>🧩</Text>
                <Text style={styles.emptyCanvasText}>
                  Добавьте блоки из палитры слева
                </Text>
                <Text style={styles.emptyCanvasHint}>
                  Нажмите на блок в палитре, чтобы добавить его на холст
                </Text>
              </View>
            ) : (
              blocks.map(block => renderBlock(block))
            )}
          </ScrollView>
        </View>
      </View>

      {/* Input Edit Modal */}
      {editingBlockId && (
        <View style={styles.inputModal}>
          <View style={styles.inputModalContent}>
            <Text style={styles.inputModalTitle}>Значение: {editingInput}</Text>
            <TextInput
              style={styles.inputField}
              value={editingValue}
              onChangeText={setEditingValue}
              placeholder="Введите значение..."
              placeholderTextColor={colors.onSurfaceVariant}
              autoFocus
            />
            <View style={styles.inputModalButtons}>
              {['Hello!', '42', 'true', 'false', 'counter', 'username', 'Screen2'].map(val => (
                <TouchableOpacity
                  key={val}
                  style={styles.quickValueButton}
                  onPress={() => {
                    handleUpdateInput(editingBlockId, editingInput, val);
                  }}
                >
                  <Text style={styles.quickValueText}>{val}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.inputModalActions}>
              <TouchableOpacity
                style={styles.inputModalCancel}
                onPress={() => {
                  setEditingBlockId(null);
                  setEditingInput('');
                  setEditingValue('');
                }}
              >
                <Text style={styles.inputModalCancelText}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.inputModalSave}
                onPress={() => {
                  handleUpdateInput(editingBlockId, editingInput, editingValue);
                }}
              >
                <Text style={styles.inputModalSaveText}>Сохранить</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyText: {
    color: colors.onSurfaceVariant,
    fontSize: 16,
    textAlign: 'center',
    marginTop: 100,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 44,
    paddingHorizontal: 12,
    paddingBottom: 8,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    padding: 8,
    marginRight: 8,
  },
  backButtonText: {
    color: colors.primary,
    fontSize: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.onSurface,
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 6,
  },
  headerButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: colors.surfaceLight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton: {
    opacity: 0.3,
  },
  headerButtonText: {
    fontSize: 18,
    color: colors.onSurface,
  },
  mainContent: {
    flex: 1,
    flexDirection: 'row',
  },
  palette: {
    width: 220,
    backgroundColor: colors.surface,
    borderRightWidth: 1,
    borderRightColor: colors.border,
  },
  paletteTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.onSurface,
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  categoryTabs: {
    maxHeight: 44,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  categoryTab: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginHorizontal: 2,
  },
  categoryTabText: {
    fontSize: 11,
    color: colors.onSurfaceVariant,
    fontWeight: '600',
  },
  categoryTabTextActive: {
    color: '#000',
  },
  blockList: {
    flex: 1,
  },
  paletteBlock: {
    backgroundColor: colors.surfaceLight,
    padding: 10,
    margin: 6,
    borderRadius: 8,
    borderLeftWidth: 4,
  },
  paletteBlockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  paletteBlockLabel: {
    fontSize: 13,
    color: colors.onSurface,
    fontWeight: '600',
    flex: 1,
  },
  shapeTag: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    marginLeft: 6,
  },
  shapeTagText: {
    fontSize: 9,
    fontWeight: 'bold',
  },
  paletteBlockInputs: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    marginTop: 4,
  },
  paletteBlockType: {
    fontSize: 10,
    color: colors.onSurfaceVariant,
    marginTop: 2,
  },
  canvas: {
    flex: 1,
    backgroundColor: colors.canvas,
  },
  canvasHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  canvasTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.onSurface,
  },
  canvasInfo: {
    fontSize: 12,
    color: colors.onSurfaceVariant,
  },
  canvasScroll: {
    flex: 1,
  },
  canvasContent: {
    padding: 16,
  },
  emptyCanvas: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 80,
  },
  emptyCanvasIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyCanvasText: {
    color: colors.onSurface,
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
  },
  emptyCanvasHint: {
    color: colors.onSurfaceVariant,
    fontSize: 14,
    textAlign: 'center',
  },
  block: {
    backgroundColor: '#555',
    borderRadius: 8,
    padding: 10,
    marginVertical: 6,
    minWidth: 200,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  hatBlock: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 14,
  },
  reporterBlock: {
    borderRadius: 16,
    paddingVertical: 8,
  },
  cBlock: {
    borderLeftWidth: 6,
  },
  blockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  blockLabel: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#000',
    flex: 1,
  },
  blockActions: {
    flexDirection: 'row',
    gap: 4,
  },
  blockAddChildBtn: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  blockAddChildText: {
    color: '#000',
    fontSize: 14,
    fontWeight: 'bold',
  },
  blockDeleteBtn: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  blockDeleteText: {
    color: '#000',
    fontSize: 11,
    fontWeight: 'bold',
  },
  blockInputs: {
    marginTop: 8,
    gap: 6,
  },
  blockInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  blockInputLabel: {
    fontSize: 11,
    color: '#333',
    fontWeight: '600',
  },
  blockInputField: {
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    minWidth: 80,
  },
  blockInputText: {
    fontSize: 12,
    color: '#333',
  },
  blockChildren: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.2)',
  },
  addChildPlaceholder: {
    marginTop: 8,
    padding: 8,
    backgroundColor: 'rgba(0,0,0,0.1)',
    borderRadius: 4,
    borderStyle: 'dashed',
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
  },
  addChildPlaceholderText: {
    color: '#000',
    fontSize: 12,
    fontWeight: '600',
  },
  inputModal: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    padding: 16,
  },
  inputModalContent: {},
  inputModalTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.onSurface,
    marginBottom: 12,
  },
  inputField: {
    backgroundColor: colors.surfaceLight,
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.borderLight,
    marginBottom: 12,
    color: colors.onSurface,
    fontSize: 14,
  },
  inputModalButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  quickValueButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  quickValueText: {
    color: colors.onPrimary,
    fontSize: 12,
    fontWeight: '600',
  },
  inputModalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  inputModalCancel: {
    flex: 1,
    padding: 12,
    backgroundColor: colors.surfaceLight,
    borderRadius: 8,
    alignItems: 'center',
  },
  inputModalCancelText: {
    color: colors.onSurface,
    fontSize: 14,
    fontWeight: '600',
  },
  inputModalSave: {
    flex: 1,
    padding: 12,
    backgroundColor: colors.primary,
    borderRadius: 8,
    alignItems: 'center',
  },
  inputModalSaveText: {
    color: colors.onPrimary,
    fontSize: 14,
    fontWeight: '600',
  },
});

export default BlockEditorScreen;
