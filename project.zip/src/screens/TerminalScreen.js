import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import colors from '../theme/colors';
import {
  TerminalView,
  isAvailable as terminalAvailable,
  getProotStatus,
  diagnoseProot,
} from '../../modules/termux-terminal/src/index';

let apt = null;
try {
  apt = require('../../modules/apt-manager/src/index');
} catch (e) {}

// Termux-style extra keys with a keyboard toggle (8 columns x 2 rows).
const EXTRA_KEYS = JSON.stringify([
  ['ESC', '/', { key: '-', popup: '|' }, 'HOME', 'UP', 'END', 'PGUP', 'KEYBOARD'],
  ['TAB', 'CTRL', 'ALT', 'LEFT', 'DOWN', 'RIGHT', 'PGDN', 'BKSP'],
]);

const TerminalScreen = ({ navigation }) => {
  const termRef = useRef(null);
  const [status, setStatus] = useState('checking'); // checking | installing | ready
  const [logs, setLogs] = useState([]);
  const [fontSize, setFontSize] = useState(13);
  const [sessionInfo, setSessionInfo] = useState(null);
  const [proot, setProot] = useState(null); // { prootBinary, rootfsInstalled, ready }
  const [rootfsUrl, setRootfsUrl] = useState('');
  const [diag, setDiag] = useState(null); // proot diagnostics overlay text

  const runDiag = async () => {
    setDiag('Running proot diagnostics...');
    try {
      const r = await diagnoseProot();
      const verdict = r.ok ? '\n✓ proot EXECUTES on this device' : '\n✗ proot FAILED to execute';
      setDiag(r.output + verdict);
      // refresh proot status too
      const ps = await getProotStatus();
      setProot(ps);
    } catch (e) {
      setDiag('Diagnostics error: ' + e.message);
    }
  };

  const hasNative = terminalAvailable();
  const hasApt = apt?.isAvailable?.() || false;

  const addLog = useCallback((text) => {
    setLogs((prev) => [...prev, text]);
  }, []);

  useEffect(() => {
    initEnv();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const initEnv = async () => {
    setStatus('checking');
    setLogs([]);
    addLog('Preparing environment...');

    if (!hasNative) {
      addLog('✗ Native terminal module not built into this app.');
      addLog('  Rebuild with: npm run bd (dev build)');
      setStatus('ready');
      return;
    }

    // proot / Linux status
    try {
      const ps = await getProotStatus();
      setProot(ps);
      if (ps.ready) {
        addLog('✓ proot + Linux rootfs ready — full Linux with apt');
      } else if (ps.prootBinary && !ps.rootfsInstalled) {
        addLog('✓ proot binary found');
        addLog('• Linux rootfs not installed yet (tap "Install Linux" below)');
      } else if (!ps.prootBinary) {
        addLog('• proot binary not bundled (run scripts/setup-proot.js, then rebuild)');
      }
    } catch (e) {
      addLog('proot status error: ' + e.message);
    }

    addLog('Starting shell...');
    setStatus('ready');
  };

  const installLinux = async () => {
    if (!hasApt) {
      addLog('✗ AptManager not available');
      return;
    }
    setStatus('installing');
    setLogs([]);
    addLog('Installing Linux rootfs (Debian/Ubuntu, ~30-200MB)...');
    try {
      const res = await apt.installProotRootfs(rootfsUrl || undefined);
      if (res.output) res.output.split('\n').forEach((l) => l.trim() && addLog(l));
      if (res.success) {
        addLog('✓ Linux installed! Restarting terminal into Linux...');
        const ps = await getProotStatus();
        setProot(ps);
      } else {
        addLog('✗ rootfs install failed');
      }
    } catch (e) {
      addLog('Error: ' + e.message);
    }
    setStatus('ready');
    // Restart the terminal so it picks up the proot environment.
    setTimeout(() => termRef.current?.restart?.(), 400);
  };

  const onTerminalEvent = useCallback((event) => {
    const e = event.nativeEvent || event;
    if (!e) return;
    if (e.type === 'started') {
      setSessionInfo(e);
    } else if (e.type === 'exit') {
      setSessionInfo((s) => (s ? { ...s, exited: true, exitCode: e.exitCode } : s));
    }
  }, []);

  const modeLabel = sessionInfo
    ? sessionInfo.proot
      ? 'Linux (proot)'
      : (sessionInfo.shell?.split('/').pop() || 'sh')
    : 'Termux engine';

  const header = (
    <View style={s.header}>
      <TouchableOpacity style={s.iconBtn} onPress={() => navigation.goBack()}>
        <Icon name="arrow-back" size={20} color={colors.text} />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>Terminal</Text>
        <Text style={s.subtitle} numberOfLines={1}>
          {modeLabel}
          {sessionInfo?.pid ? ` · pid ${sessionInfo.pid}` : ''}
          {sessionInfo?.exited ? ` · exited ${sessionInfo.exitCode}` : ''}
        </Text>
      </View>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.max(8, f - 1))}>
        <Text style={s.aa}>A−</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.min(32, f + 1))}>
        <Text style={s.aa}>A+</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.toggleKeyboard()}>
        <Icon name="keyboard" size={20} color={colors.text} />
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.restart()}>
        <Icon name="refresh" size={20} color={colors.text} />
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={runDiag}>
        <Icon name="pulse-outline" size={20} color={colors.text} />
      </TouchableOpacity>
    </View>
  );

  const showInstallLinux = proot && proot.prootBinary && !proot.rootfsInstalled && status !== 'installing';

  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>
      {header}

      {status === 'installing' ? (
        <ScrollView style={s.logView} contentContainerStyle={{ padding: 16 }}>
          <ActivityIndicator size="large" color={colors.primary} style={{ marginBottom: 12 }} />
          {logs.map((line, i) => (
            <Text
              key={i}
              style={[
                s.logLine,
                line.includes('✓') && s.logOk,
                (line.includes('✗') || line.includes('Error')) && s.logError,
              ]}
            >
              {line}
            </Text>
          ))}
        </ScrollView>
      ) : (
        <>
          {showInstallLinux && (
            <View style={s.installBar}>
              <Text style={s.installText}>
                Linux (apt) ещё не установлен. Скачается rootfs (~30-200МБ).
              </Text>
              <TouchableOpacity style={s.installBtn} onPress={installLinux}>
                <Text style={s.installBtnText}>Установить Linux</Text>
              </TouchableOpacity>
            </View>
          )}
          {hasNative ? (
            <TerminalView
              ref={termRef}
              style={s.terminal}
              fontSize={fontSize}
              extraKeys={EXTRA_KEYS}
              onTerminalEvent={onTerminalEvent}
            />
          ) : (
            <View style={s.fallback}>
              <Text style={s.fallbackText}>Native TerminalView not available</Text>
            </View>
          )}
        </>
      )}

      {diag !== null && (
        <View style={s.diagOverlay}>
          <View style={s.diagBox}>
            <Text style={s.diagTitle}>proot diagnostics</Text>
            <ScrollView style={s.diagScroll}>
              <Text style={s.diagText}>{diag}</Text>
            </ScrollView>
            <TouchableOpacity style={s.diagClose} onPress={() => setDiag(null)}>
              <Text style={s.diagCloseText}>Закрыть</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D1117' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: colors.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: {
    minWidth: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: colors.bgElevated,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 6,
  },
  aa: { color: colors.text, fontSize: 13, fontWeight: '700' },
  title: { fontSize: 16, fontWeight: '700', color: colors.text },
  subtitle: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  installBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: colors.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  installText: { flex: 1, fontSize: 12, color: colors.textSecondary },
  installBtn: {
    backgroundColor: colors.primary,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  installBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  terminal: { flex: 1, backgroundColor: '#0D1117' },
  logView: { flex: 1, backgroundColor: '#0D1117' },
  logLine: { fontFamily: 'monospace', fontSize: 12, color: '#C9D1D9', lineHeight: 18 },
  logOk: { color: '#3FB950' },
  logError: { color: '#F85149' },
  fallback: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  fallbackText: { color: colors.textSecondary, fontSize: 14 },
  diagOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    zIndex: 10,
  },
  diagBox: {
    width: '100%',
    maxHeight: '70%',
    backgroundColor: colors.bgCard,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 14,
  },
  diagTitle: { color: colors.text, fontSize: 15, fontWeight: '700', marginBottom: 10 },
  diagScroll: { flexGrow: 0 },
  diagText: { fontFamily: 'monospace', fontSize: 12, color: '#C9D1D9', lineHeight: 18 },
  diagClose: {
    marginTop: 12,
    backgroundColor: colors.primary,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  diagCloseText: { color: '#fff', fontSize: 14, fontWeight: '700' },
});

export default TerminalScreen;
