import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import colors from '../theme/colors';
import {
  TerminalView,
  isAvailable as terminalAvailable,
  getProotStatus,
  diagnoseProot,
  copyToClipboard,
} from '../../modules/termux-terminal/src/index';

let apt = null;
try {
  apt = require('../../modules/apt-manager/src/index');
} catch (e) {}

// Minimal ASCII base64 encoder (the node-install script is ASCII), avoids relying on global btoa.
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function toBase64(str) {
  let out = '';
  for (let i = 0; i < str.length; i += 3) {
    const a = str.charCodeAt(i);
    const b = i + 1 < str.length ? str.charCodeAt(i + 1) : 0;
    const c = i + 2 < str.length ? str.charCodeAt(i + 2) : 0;
    const t = (a << 16) | (b << 8) | c;
    out += B64[(t >> 18) & 63] + B64[(t >> 12) & 63] + (i + 1 < str.length ? B64[(t >> 6) & 63] : '=') + (i + 2 < str.length ? B64[t & 63] : '=');
  }
  return out;
}

// Distributions available at runtime (no APK rebuild needed to switch).
// The bundled proot is the Termux-patched armhf build, so armhf distros are the safe default;
// arm64 distros need a 64-bit proot (use scripts/setup-proot.js --aarch64 + rebuild on devices
// where the vanilla 64-bit proot runs guests).
const DISTROS = [
  { id: 'ubuntu-armhf', label: 'Ubuntu armhf', url: 'https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-armhf.tar.gz', libc: 'glibc', arch: 32 },
  { id: 'ubuntu-arm64', label: 'Ubuntu arm64', url: 'https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.3-base-arm64.tar.gz', libc: 'glibc', arch: 64 },
  { id: 'alpine-armhf', label: 'Alpine armhf', url: 'https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/armhf/alpine-minirootfs-3.20.0-armhf.tar.gz', libc: 'musl', arch: 32 },
  { id: 'alpine-arm64', label: 'Alpine arm64', url: 'https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/aarch64/alpine-minirootfs-3.20.0-aarch64.tar.gz', libc: 'musl', arch: 64 },
  { id: 'custom', label: 'Свой URL', url: '', libc: 'glibc', arch: 0 },
];

// Self-adapting Node.js installer (runs INSIDE the proot shell). Detects arch (uname -m) and libc
// (glibc/musl), downloads the official prebuilt tarball (.tar.gz => gzip, NOT xz, so it bypasses the
// liblzma bug that breaks `apt` for big packages under proot) and symlinks node/npm/npx.
const NODE_VERSION = 'v20.18.1';
const NODE_SCRIPT = `set -e
cd /root
A=$(uname -m)
case "$A" in x86_64) N=x64;; aarch64) N=arm64;; armv7l|armv8l) N=armv7l;; *) echo "unsupported arch: $A"; exit 1;; esac
if (ldd --version 2>&1 || true) | grep -qi musl; then LC=musl; else LC=; fi
if [ -n "$LC" ] && [ "$N" = "armv7l" ]; then echo "No official musl-armv7l node. On Alpine use: apk add nodejs npm"; exit 1; fi
SFX="linux-$N\${LC:+-$LC}"
URL="https://nodejs.org/dist/${NODE_VERSION}/node-${NODE_VERSION}-$SFX.tar.gz"
echo ">> $URL"
if command -v wget >/dev/null 2>&1; then wget -O node.tgz "$URL"; elif command -v curl >/dev/null 2>&1; then curl -fSL -o node.tgz "$URL"; else echo "need wget/curl"; exit 1; fi
rm -rf /opt/node && mkdir -p /opt/node
tar -xzf node.tgz -C /opt/node --strip-components=1
ln -sf /opt/node/bin/node /usr/local/bin/node
ln -sf /opt/node/bin/npm /usr/local/bin/npm
ln -sf /opt/node/bin/npx /usr/local/bin/npx
rm -f node.tgz
echo "OK node $(node -v) / npm $(npm -v)"`;

const TerminalScreen = ({ navigation }) => {
  const termRef = useRef(null);
  const [status, setStatus] = useState('checking'); // checking | installing | ready
  const [logs, setLogs] = useState([]);
  const [fontSize, setFontSize] = useState(13);
  const [sessionInfo, setSessionInfo] = useState(null);
  const [proot, setProot] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [progress, setProgress] = useState(null);
  const [diag, setDiag] = useState(null);
  const [copied, setCopied] = useState(false);

  // settings panel
  const [showSettings, setShowSettings] = useState(false);
  const [distroId, setDistroId] = useState('ubuntu-armhf');
  const [customUrl, setCustomUrl] = useState('');
  const [installedDistro, setInstalledDistro] = useState(null);

  const hasNative = terminalAvailable();
  const hasApt = apt?.isAvailable?.() || false;

  const addLog = useCallback((text) => setLogs((p) => [...p, text]), []);

  useEffect(() => {
    initEnv();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (status !== 'installing') { setElapsed(0); setProgress(null); return; }
    const t = setInterval(async () => {
      setElapsed((e) => e + 1);
      try { if (apt?.getRootfsProgress) setProgress(await apt.getRootfsProgress()); } catch (e) {}
    }, 800);
    return () => clearInterval(t);
  }, [status]);

  const initEnv = async () => {
    setStatus('checking');
    setLogs([]);
    if (!hasNative) { setStatus('ready'); return; }
    try {
      const ps = await getProotStatus();
      setProot(ps);
      const pa = ps.prootArch; // 32 or 64 (bundled proot)
      const ra = ps.rootfsArch;
      // best-effort guess of the installed distro id
      setInstalledDistro((prev) => prev || (ra === 64 ? 'ubuntu-arm64' : ra === 32 ? 'ubuntu-armhf' : null));
      const mismatch = pa && ra && pa !== ra; // e.g. 32-bit proot + 64-bit rootfs => guests won't run
      if (!ps.rootfsInstalled || mismatch) {
        // open the panel and pre-select a distro that matches the bundled proot
        if (pa === 32) setDistroId('ubuntu-armhf');
        else if (pa === 64) setDistroId('ubuntu-arm64');
        setShowSettings(true);
      }
    } catch (e) {}
    setStatus('ready');
  };

  const selected = DISTROS.find((d) => d.id === distroId) || DISTROS[0];
  const installUrl = distroId === 'custom' ? customUrl.trim() : selected.url;

  const installDistro = async () => {
    if (!hasApt) { addLog('AptManager недоступен'); return; }
    if (!installUrl) { addLog('Введите URL образа'); return; }
    setShowSettings(false);
    setStatus('installing');
    setLogs([`Установка: ${distroId === 'custom' ? 'custom' : selected.label}`, installUrl]);
    try {
      const res = await apt.installProotRootfs(installUrl);
      if (res.output) res.output.split('\n').forEach((l) => l.trim() && addLog(l));
      if (res.success) {
        setInstalledDistro(distroId === 'custom' ? null : distroId);
        addLog('✓ готово, перезапуск терминала...');
        const ps = await getProotStatus();
        setProot(ps);
      } else {
        addLog('✗ ошибка установки');
      }
    } catch (e) { addLog('Error: ' + e.message); }
    setStatus('ready');
    setTimeout(() => termRef.current?.restart?.(), 400);
  };

  const doDeleteRootfs = async () => {
    if (!hasApt) return;
    try { await apt.deleteRootfs(); } catch (e) {}
    const ps = await getProotStatus();
    setProot(ps);
    setInstalledDistro(null);
    addLog('rootfs удалён');
  };

  const installNode = () => {
    if (!termRef.current) return;
    const b64 = toBase64(NODE_SCRIPT);
    termRef.current.run(`echo '${b64}' | base64 -d > /root/inn.sh && sh /root/inn.sh`);
  };

  const runDiag = async () => {
    setDiag('Running proot diagnostics...');
    try {
      const r = await diagnoseProot();
      setDiag(r.output + (r.ok ? '\n✓ proot --version ok' : '\n✗ proot --version failed'));
    } catch (e) { setDiag('Diagnostics error: ' + e.message); }
  };

  const copyDiag = async () => { if (!diag) return; await copyToClipboard(diag); setCopied(true); setTimeout(() => setCopied(false), 1500); };

  const onTerminalEvent = useCallback((event) => {
    const e = event.nativeEvent || event;
    if (!e) return;
    if (e.type === 'started') setSessionInfo(e);
    else if (e.type === 'exit') setSessionInfo((s) => (s ? { ...s, exited: true, exitCode: e.exitCode } : s));
  }, []);

  const modeLabel = sessionInfo
    ? (sessionInfo.proot ? 'Linux (proot)' : (sessionInfo.shell?.split('/').pop() || 'sh'))
    : 'Termux engine';

  const ra = proot?.rootfsArch;
  const raLabel = ra === 64 ? 'arm64' : ra === 32 ? 'armhf' : (proot?.rootfsInstalled ? '?' : 'нет');

  const header = (
    <View style={s.header}>
      <TouchableOpacity style={s.iconBtn} onPress={() => navigation.goBack()}>
        <Icon name="arrow-back" size={20} color={colors.text} />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>Terminal</Text>
        <Text style={s.subtitle} numberOfLines={1}>
          {modeLabel}{sessionInfo?.pid ? ` · pid ${sessionInfo.pid}` : ''}{sessionInfo?.exited ? ` · exited ${sessionInfo.exitCode}` : ''}
        </Text>
      </View>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.max(8, f - 1))}><Text style={s.aa}>A−</Text></TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.min(32, f + 1))}><Text style={s.aa}>A+</Text></TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.toggleKeyboard?.()}><Icon name="keyboard" size={20} color={colors.text} /></TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.restart?.()}><Icon name="refresh" size={20} color={colors.text} /></TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={runDiag}><Icon name="pulse-outline" size={20} color={colors.text} /></TouchableOpacity>
      <TouchableOpacity style={[s.iconBtn, showSettings && { borderColor: colors.primary }]} onPress={() => setShowSettings((v) => !v)}><Icon name="settings-outline" size={20} color={colors.text} /></TouchableOpacity>
    </View>
  );

  const settingsPanel = showSettings ? (
    <View style={s.panel}>
      <Text style={s.panelTitle}>Образ Linux (rootfs) · сейчас: {raLabel}{installedDistro ? ` (${DISTROS.find((d) => d.id === installedDistro)?.label || '?'})` : ''} · proot: {proot?.prootArch === 64 ? '64-bit' : proot?.prootArch === 32 ? '32-bit' : '?'}</Text>
      {proot?.prootArch && proot?.rootfsArch && proot.prootArch !== proot.rootfsArch ? (
        <Text style={[s.hint, { color: '#F85149' }]}>
          ⚠ proot ({proot.prootArch}-bit) и образ ({proot.rootfsArch}-bit) не совпадают — гости не запустятся. Установи образ нужной разрядности ниже.
        </Text>
      ) : null}
      <View style={s.chips}>
        {DISTROS.map((d) => (
          <TouchableOpacity key={d.id} style={[s.chip, distroId === d.id && s.chipOn]} onPress={() => setDistroId(d.id)}>
            <Text style={[s.chipText, distroId === d.id && s.chipTextOn]}>{d.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {distroId === 'custom' && (
        <TextInput
          style={s.input}
          placeholder="https://.../rootfs.tar.gz"
          placeholderTextColor={colors.textSecondary}
          value={customUrl}
          onChangeText={setCustomUrl}
          autoCapitalize="none"
          autoCorrect={false}
        />
      )}
      <View style={s.panelRow}>
        <TouchableOpacity style={s.btnPrimary} onPress={installDistro}>
          <Text style={s.btnPrimaryText}>{proot?.rootfsInstalled ? 'Переустановить' : 'Установить'}</Text>
        </TouchableOpacity>
        {proot?.rootfsInstalled ? (
          <TouchableOpacity style={s.btnDanger} onPress={doDeleteRootfs}>
            <Text style={s.btnDangerText}>Удалить</Text>
          </TouchableOpacity>
        ) : null}
      </View>
      <Text style={s.hint}>
        armhf — безопасно на Huawei (Termux-патченый proot 32-бит). arm64 — только если 64-битный proot запускает гостей на твоём устройстве. Переключение не требует пересборки APK.
      </Text>
    </View>
  ) : null;

  // action bar over the terminal (only when ready)
  const actionBar = status === 'ready' && hasNative ? (
    <View style={s.actionBar}>
      <TouchableOpacity style={s.actionBtn} onPress={installNode}>
        <Icon name="logo-nodejs" size={16} color={colors.text} />
        <Text style={s.actionBtnText}> Node.js (curl, без apt)</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.actionBtn} onPress={() => setShowSettings(true)}>
        <Text style={s.actionBtnText}>Образ: {raLabel}</Text>
      </TouchableOpacity>
    </View>
  ) : null;

  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>
      {header}
      {settingsPanel}

      {status === 'installing' ? (
        <ScrollView style={s.logView} contentContainerStyle={{ padding: 16 }}>
          <ActivityIndicator size="large" color={colors.primary} style={{ marginBottom: 12 }} />
          <Text style={[s.logLine, s.logOk]}>
            {progress?.stage === 'downloading' && progress.totalBytes > 0
              ? `Скачивание: ${(progress.downloadedBytes / 1048576).toFixed(1)} из ${(progress.totalBytes / 1048576).toFixed(1)} МБ (${Math.min(100, Math.round((progress.downloadedBytes / progress.totalBytes) * 100))}%) · ${elapsed} сек`
              : progress?.stage === 'downloading'
              ? `Скачивание: ${(progress.downloadedBytes / 1048576).toFixed(1)} МБ · ${elapsed} сек`
              : `${progress?.message || 'Скачивание/установка...'} · ${elapsed} сек`}
          </Text>
          {progress?.url ? <Text style={[s.logLine, { color: colors.textSecondary, marginBottom: 6 }]} numberOfLines={2}>{progress.url}</Text> : null}
          {logs.map((line, i) => (
            <Text key={i} style={[s.logLine, line.includes('✓') && s.logOk, (line.includes('✗') || line.includes('Error')) && s.logError]}>{line}</Text>
          ))}
        </ScrollView>
      ) : (
        <>
          {actionBar}
          {hasNative ? (
            <TerminalView ref={termRef} style={s.terminal} fontSize={fontSize} extraKeys={EXTRA_KEYS} onTerminalEvent={onTerminalEvent} />
          ) : (
            <View style={s.fallback}><Text style={s.fallbackText}>Native TerminalView not available</Text></View>
          )}
        </>
      )}

      {diag !== null && (
        <View style={s.diagOverlay}>
          <View style={s.diagBox}>
            <Text style={s.diagTitle}>proot diagnostics</Text>
            <ScrollView style={s.diagScroll}><Text selectable style={s.diagText}>{diag}</Text></ScrollView>
            <View style={s.diagButtons}>
              <TouchableOpacity style={[s.diagClose, { backgroundColor: colors.bgElevated, flex: 1 }]} onPress={copyDiag}>
                <Text style={s.diagCloseText}>{copied ? 'Скопировано ✓' : 'Скопировать'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.diagClose, { flex: 1 }]} onPress={() => setDiag(null)}><Text style={s.diagCloseText}>Закрыть</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const EXTRA_KEYS = JSON.stringify([
  ['ESC', '/', { key: '-', popup: '|' }, 'HOME', 'UP', 'END', 'PGUP', 'KEYBOARD'],
  ['TAB', 'CTRL', 'ALT', 'LEFT', 'DOWN', 'RIGHT', 'PGDN', 'BKSP'],
]);

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D1117' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 8, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  iconBtn: { minWidth: 38, height: 38, borderRadius: 10, backgroundColor: colors.bgElevated, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border, paddingHorizontal: 6 },
  aa: { color: colors.text, fontSize: 13, fontWeight: '700' },
  title: { fontSize: 16, fontWeight: '700', color: colors.text },
  subtitle: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  panel: { paddingHorizontal: 12, paddingVertical: 10, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  panelTitle: { color: colors.text, fontSize: 13, fontWeight: '700', marginBottom: 8 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.text, fontSize: 12 },
  chipTextOn: { color: '#fff', fontWeight: '700' },
  input: { backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8, color: colors.text, fontSize: 12, marginBottom: 8 },
  panelRow: { flexDirection: 'row', gap: 8 },
  btnPrimary: { flex: 1, backgroundColor: colors.primary, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  btnPrimaryText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  btnDanger: { paddingHorizontal: 16, backgroundColor: '#3a1416', paddingVertical: 10, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#F85149' },
  btnDangerText: { color: '#F85149', fontWeight: '700', fontSize: 14 },
  hint: { color: colors.textSecondary, fontSize: 11, marginTop: 8, lineHeight: 16 },
  actionBar: { flexDirection: 'row', gap: 8, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  actionBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 },
  actionBtnText: { color: colors.text, fontSize: 12, fontWeight: '600' },
  terminal: { flex: 1, backgroundColor: '#0D1117' },
  logView: { flex: 1, backgroundColor: '#0D1117' },
  logLine: { fontFamily: 'monospace', fontSize: 12, color: '#C9D1D9', lineHeight: 18 },
  logOk: { color: '#3FB950' },
  logError: { color: '#F85149' },
  fallback: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  fallbackText: { color: colors.textSecondary, fontSize: 14 },
  diagOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 20, zIndex: 10 },
  diagBox: { width: '100%', maxHeight: '75%', backgroundColor: colors.bgCard, borderRadius: 14, borderWidth: 1, borderColor: colors.border, padding: 14 },
  diagTitle: { color: colors.text, fontSize: 15, fontWeight: '700', marginBottom: 10 },
  diagScroll: { flexGrow: 0 },
  diagText: { fontFamily: 'monospace', fontSize: 11, color: '#C9D1D9', lineHeight: 16 },
  diagButtons: { flexDirection: 'row', gap: 10, marginTop: 12 },
  diagClose: { backgroundColor: colors.primary, paddingVertical: 10, borderRadius: 10, alignItems: 'center', paddingHorizontal: 8 },
  diagCloseText: { color: '#fff', fontSize: 14, fontWeight: '700' },
});

export default TerminalScreen;
