import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { requireNativeViewManager } from 'expo-modules-core';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import colors from '../theme/colors';

// Нативные модули
let NativeTerminalView = null;
let apt = null;
try { NativeTerminalView = requireNativeViewManager('TermuxTerminal'); } catch (e) {}
try { apt = require('../../modules/apt-manager/src/index'); } catch (e) {}

const TerminalScreen = ({ navigation }) => {
  const [status, setStatus] = useState('checking');
  const [logs, setLogs] = useState([]);
  const hasNative = !!NativeTerminalView;
  const hasApt = apt?.isAvailable?.() || false;

  useEffect(() => { initEnv(); }, []);

  const addLog = (text) => setLogs(prev => [...prev, text]);

  const initEnv = async () => {
    setStatus('checking');
    addLog('Checking environment...');

      if (hasApt) {
        try {
          const installed = await apt.isBootstrapInstalled();
          if (installed) {
            addLog('✓ Bootstrap installed');
            addLog('Copying binaries to exec directory...');
            const permResult = await apt.ensurePermissions();
            addLog('✓ Binaries ready');
            const execBin = await apt.getExecBinDir();
            if (execBin.path) {
              addLog(`Exec dir: ${execBin.path}`);
            }
            
            // Проверяем что exec работает
            addLog('Testing exec...');
            const testResult = await apt.testExec();
            if (testResult.success) {
              addLog('✓ Exec works!');
              setStatus('ready');
            } else {
              addLog('✗ Exec not supported on this device');
              addLog('');
              addLog('Solution: Install Termux from F-Droid');
              addLog('Then our app will use Termux prefix.');
              setStatus('need-termux');
            }
            return;
          }
        addLog('Installing bootstrap...');
        setStatus('installing');
        const result = await apt.installBootstrap();
        if (result.output) result.output.split('\n').forEach(l => { if (l.trim()) addLog(l); });
        if (result.success) { addLog('✓ Ready!'); setStatus('ready'); }
        else { addLog('✗ Failed'); setStatus('error'); }
      } catch (e) { addLog('Error: ' + e.message); setStatus('error'); }
    } else {
      addLog('AptManager not available');
      setStatus(hasNative ? 'ready' : 'error');
    }
  };

  const header = (
    <View style={s.header}>
      <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
        <Icon name="arrow-back" size={20} color={colors.text} />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>Terminal</Text>
        <Text style={s.subtitle}>{hasNative ? 'Native Termux View ✓' : 'Native View ✗'} · {hasApt ? 'Apt ✓' : 'Apt ✗'}</Text>
      </View>
    </View>
  );

  if (status !== 'ready') {
    if (status === 'need-termux') {
      return (
        <SafeAreaView style={s.container} edges={['top', 'bottom']}>
          {header}
          <ScrollView style={s.logView} contentContainerStyle={{ padding: 16 }}>
            <Text style={[s.logLine, s.logError]}>⚠ Exec Permission Denied</Text>
            <Text style={s.logLine}> </Text>
            <Text style={s.logLine}>Your device blocks exec from app data.</Text>
            <Text style={s.logLine}>This is Android/SELinux limitation.</Text>
            <Text style={s.logLine}> </Text>
            <Text style={[s.logLine, s.logOk]}>✓ Solution: Install Termux</Text>
            <Text style={s.logLine}> </Text>
            <Text style={s.logLine}>1. Install Termux from F-Droid:</Text>
            <Text style={[s.logLine, {color: '#58A6FF'}]}>https://f-droid.org/packages/com.termux/</Text>
            <Text style={s.logLine}> </Text>
            <Text style={s.logLine}>2. Open Termux, run:</Text>
            <Text style={[s.logLine, {color: '#3FB950'}]}>pkg update && pkg install bash</Text>
            <Text style={s.logLine}> </Text>
            <Text style={s.logLine}>3. Return to this app</Text>
            <Text style={s.logLine}>   We will use Termux prefix automatically.</Text>
            <Text style={s.logLine}> </Text>
            <TouchableOpacity style={s.retryBtn} onPress={() => {
              Linking.openURL('https://f-droid.org/packages/com.termux/');
            }}>
              <Text style={s.retryBtnText}>Open F-Droid</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[s.retryBtn, {marginTop: 8}]} onPress={() => {
              setStatus('checking');
              initEnv();
            }}>
              <Text style={s.retryBtnText}>Check Again</Text>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      );
    }
    return (
      <SafeAreaView style={s.container} edges={['top', 'bottom']}>
        {header}
        <ScrollView style={s.logView} contentContainerStyle={{ padding: 16 }}>
          {status === 'installing' && <ActivityIndicator size="large" color={colors.primary} />}
          {logs.map((line, i) => (
            <Text key={i} style={[s.logLine, line.includes('✓') && s.logOk, line.includes('✗') && s.logError]}>{line}</Text>
          ))}
          {status === 'error' && (
            <TouchableOpacity style={s.retryBtn} onPress={() => { setLogs([]); initEnv(); }}>
              <Text style={s.retryBtnText}>Retry</Text>
            </TouchableOpacity>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>
      {header}
      {hasNative ? (
        <NativeTerminalView style={s.terminal} />
      ) : (
        <View style={s.fallback}>
          <Text style={s.fallbackText}>Native TerminalView not available</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D1117' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  backBtn: { width: 40, height: 40, borderRadius: 10, backgroundColor: colors.bgElevated, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  title: { fontSize: 16, fontWeight: '700', color: colors.text },
  subtitle: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  terminal: { flex: 1, backgroundColor: '#0D1117' },
  logView: { flex: 1, backgroundColor: '#0D1117' },
  logLine: { fontFamily: 'monospace', fontSize: 12, color: '#C9D1D9', lineHeight: 18 },
  logOk: { color: '#3FB950' },
  logError: { color: '#F85149' },
  retryBtn: { backgroundColor: colors.primary, paddingVertical: 12, borderRadius: 10, marginTop: 16, alignItems: 'center' },
  retryBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  fallback: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  fallbackText: { color: colors.textSecondary, fontSize: 14 },
});

export default TerminalScreen;
