import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import colors from '../theme/colors';
import {
  TerminalView,
  isAvailable as terminalAvailable,
} from '../../modules/termux-terminal/src/index';

let apt = null;
try {
  apt = require('../../modules/apt-manager/src/index');
} catch (e) {}

// Termux-style extra keys with a keyboard toggle (8 columns x 2 rows).
// Swipe up on a key to reveal its popup (e.g. swipe "-" for "|").
const EXTRA_KEYS = JSON.stringify([
  ['ESC', '/', { key: '-', popup: '|' }, 'HOME', 'UP', 'END', 'PGUP', 'KEYBOARD'],
  ['TAB', 'CTRL', 'ALT', 'LEFT', 'DOWN', 'RIGHT', 'PGDN', 'BKSP'],
]);

const TerminalScreen = ({ navigation }) => {
  const termRef = useRef(null);
  const [status, setStatus] = useState('checking');
  const [logs, setLogs] = useState([]);
  const [fontSize, setFontSize] = useState(13);
  const [sessionInfo, setSessionInfo] = useState(null);

  const hasNative = terminalAvailable();
  const hasApt = apt?.isAvailable?.() || false;

  const addLog = useCallback((text) => {
    setLogs((prev) => [...prev, text]);
  }, []);

  useEffect(() => {
    initEnv();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const initEnv = async () => {
    setStatus('checking');
    setLogs([]);
    addLog('Preparing environment...');

    if (!hasNative) {
      addLog('✗ Native terminal module not built into this app.');
      addLog('  Rebuild with: npm run bd  (dev build)');
      setStatus('error');
      return;
    }

    if (hasApt) {
      try {
        const installed = await apt.isBootstrapInstalled();
        if (installed) {
          addLog('✓ Bootstrap installed');
          await apt.ensurePermissions();
          const test = await apt.testExec();
          if (test.success) {
            addLog('✓ Exec works — starting shell...');
            setStatus('ready');
          } else {
            addLog('✗ Exec blocked by the OS (SELinux).');
            addLog('  Falling back to the system shell.');
            setStatus('ready');
          }
          return;
        }
        addLog('Installing bootstrap (this can take a minute)...');
        setStatus('installing');
        const result = await apt.installBootstrap();
        if (result.output) {
          result.output.split('\n').forEach((l) => l.trim() && addLog(l));
        }
        if (result.success) {
          addLog('✓ Ready!');
          setStatus('ready');
        } else {
          addLog('✗ Bootstrap failed — using system shell.');
          setStatus('ready');
        }
      } catch (e) {
        addLog('Error: ' + e.message);
        setStatus('ready');
      }
    } else {
      addLog('AptManager not available — using system shell.');
      setStatus('ready');
    }
  };

  const onTerminalEvent = useCallback((event) => {
    const e = event.nativeEvent || event;
    if (!e) return;
    if (e.type === 'started') {
      setSessionInfo(e);
    } else if (e.type === 'exit') {
      // Keep the view; user can restart.
      setSessionInfo((s) => (s ? { ...s, exited: true, exitCode: e.exitCode } : s));
    }
  }, []);

  const header = (
    <View style={s.header}>
      <TouchableOpacity style={s.iconBtn} onPress={() => navigation.goBack()}>
        <Icon name="arrow-back" size={20} color={colors.text} />
      </TouchableOpacity>
      <View style={{ flex: 1 }}>
        <Text style={s.title}>Terminal</Text>
        <Text style={s.subtitle} numberOfLines={1}>
          {sessionInfo
            ? `${sessionInfo.shell?.split('/').pop() || 'sh'} · pid ${sessionInfo.pid}${
                sessionInfo.exited ? ` · exited ${sessionInfo.exitCode}` : ''
              }`
            : 'Termux engine'}
        </Text>
      </View>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.max(8, f - 1))}>
        <Text style={s.aa}>A−</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => setFontSize((f) => Math.min(32, f + 1))}>
        <Text style={s.aa}>A+</Text>
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.toggleKeyboard()}>
        <Icon name="keyboard" size={20} color={colors.text} />
      </TouchableOpacity>
      <TouchableOpacity style={s.iconBtn} onPress={() => termRef.current?.restart()}>
        <Icon name="refresh" size={20} color={colors.text} />
      </TouchableOpacity>
    </View>
  );

  if (status !== 'ready') {
    return (
      <SafeAreaView style={s.container} edges={['top', 'bottom']}>
        {header}
        <ScrollView style={s.logView} contentContainerStyle={{ padding: 16 }}>
          {status === 'installing' && (
            <ActivityIndicator size="large" color={colors.primary} style={{ marginBottom: 12 }} />
          )}
          {logs.map((line, i) => (
            <Text
              key={i}
              style={[
                s.logLine,
                line.includes('✓') && s.logOk,
                (line.includes('✗') || line.includes('Error')) && s.logError,
              ]}
            >
              {line}
            </Text>
          ))}
          {status === 'error' && (
            <>
              <TouchableOpacity style={s.retryBtn} onPress={initEnv}>
                <Text style={s.retryBtnText}>Retry</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.retryBtn, { marginTop: 8, backgroundColor: colors.bgElevated }]}
                onPress={() => Linking.openURL('https://f-droid.org/packages/com.termux/')}
              >
                <Text style={s.retryBtnText}>Install Termux (F-Droid)</Text>
              </TouchableOpacity>
            </>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>
      {header}
      {hasNative ? (
        <TerminalView
          ref={termRef}
          style={s.terminal}
          fontSize={fontSize}
          extraKeys={EXTRA_KEYS}
          onTerminalEvent={onTerminalEvent}
        />
      ) : (
        <View style={s.fallback}>
          <Text style={s.fallbackText}>Native TerminalView not available</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0D1117' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: colors.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  iconBtn: {
    minWidth: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: colors.bgElevated,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 6,
  },
  aa: { color: colors.text, fontSize: 13, fontWeight: '700' },
  title: { fontSize: 16, fontWeight: '700', color: colors.text },
  subtitle: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  terminal: { flex: 1, backgroundColor: '#0D1117' },
  logView: { flex: 1, backgroundColor: '#0D1117' },
  logLine: { fontFamily: 'monospace', fontSize: 12, color: '#C9D1D9', lineHeight: 18 },
  logOk: { color: '#3FB950' },
  logError: { color: '#F85149' },
  retryBtn: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 16,
    alignItems: 'center',
  },
  retryBtnText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  fallback: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  fallbackText: { color: colors.textSecondary, fontSize: 14 },
});

export default TerminalScreen;
