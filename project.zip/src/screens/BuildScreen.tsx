import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, Share, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute, observeDetachedJob, persistentStreamExecute } from '../utils/shellExecutor';
import { shellQuote } from '../utils/workspace';
import { getProjectDir, slugifyProject } from '../config/runtime';
import { prepareProject } from '../utils/prepareProject';
import { refreshAndroidScaffold, ensureProjectIntegrity } from '../utils/composeProject';
import * as apt from '../../modules/apt-manager/src/index';
import { startBackground, stopBackground } from '../utils/background';
import { TerminalView, isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';
import AdsBanner from '../components/AdsBanner';
import { maybeShowInterstitial } from '../ads/yandexAds';

// Терминал сборки — только вывод: панель спец-клавиш (ESC/CTRL/…) скрыта,
// экранная клавиатура не появляется, ручной ввод запрещён — всё запускается кнопками.
import { cn } from "../utils/cn";
const EXTRA_KEYS = '[]';
const tasks = {
  dev: {
    icon: 'flash-outline',
    label: 'Vite dev',
    cmd: 'npm run dev',
    desc: 'Локальный Vite dev-server',
    tone: 'info'
  },
  build: {
    icon: 'hammer-outline',
    label: 'Vite build',
    cmd: 'npm run build',
    desc: 'Сборка dist/',
    tone: 'success'
  },
  android: {
    icon: 'logo-android',
    label: 'Android APK',
    cmd: 'bash build-android.sh',
    desc: 'подготовка → dist → assets → APK',
    tone: 'warning'
  },
  prepare: {
    icon: 'shield-checkmark-outline',
    label: 'Prepare SDK37',
    cmd: 'bash prepare.sh',
    desc: '7 шагов: wrapper/SDK37/конфликты',
    tone: 'info'
  }
};
const BuildScreen = ({
  navigation
}) => {
  const {
    width
  } = useWindowDimensions();
  const {
    currentProject,
    addWorkspaceLog
  } = useProject();
  const {
    colors,
    language,
    t
  } = useAppSettings();
  const [task, setTask] = useState('build');
  const [variant, setVariant] = useState('debug'); // debug | release (для задачи android)
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [resultState, setResultState] = useState('idle');

  // Полноэкранная реклама РСЯ — только после успешной сборки и не чаще,
  // чем задано в adsConfig (no-op, если нативный SDK недоступен).
  useEffect(() => {
    if (resultState === 'success') void maybeShowInterstitial();
  }, [resultState]);
  const [artifact, setArtifact] = useState('');
  const [fontSize, setFontSize] = useState(18);
  const scrollRef = useRef(null);
  const terminalRef = useRef(null);
  const terminalReadyRef = useRef(false);
  const terminalPendingRef = useRef([]);
  const reattachedJobRef = useRef('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const desktop = width >= 800;
  const narrow = width < 560; // телефон в портрете: прячем второстепенные кнопки шапки консоли
  const ru = language === 'ru';
  const copy = ru ? {
    title: 'Сборка React',
    subtitle: 'React + Vite',
    choose: 'Задача сборки',
    run: 'Запустить',
    running: 'Выполняется…',
    success: 'Успешно',
    failed: 'Ошибка',
    terminal: 'Журнал сборки',
    clear: 'Очистить',
    install: 'Установить APK',
    launch: 'Открыть',
    note: 'Подготовка проекта выполняется автоматически — отдельный Prepare не нужен. Одна кнопка «Запустить» — полный цикл: файлы проекта → Vite build → assets → Gradle → проверка APK (aapt2) → экспорт в Загрузки/NovaCompose/<проект>/apk.',
    noProject: 'Сначала откройте проект.',
    artifact: 'Артефакт',
    clean: 'Очистить'
  } : {
    title: 'React Build',
    subtitle: 'React + Vite',
    choose: 'Build task',
    run: 'Run',
    running: 'Running…',
    success: 'Success',
    failed: 'Failed',
    terminal: 'Build log',
    clear: 'Clear',
    install: 'Install APK',
    launch: 'Open',
    note: 'Project preparation runs automatically — no separate Prepare needed. One Run button — the full cycle: project files → Vite build → assets → Gradle → APK check (aapt2) → export to Downloads/NovaCompose/<project>/apk.',
    noProject: 'Open a project first.',
    artifact: 'Artifact',
    clean: 'Clean'
  };
  const writeTerminal = text => {
    if (!text && text !== '') return;
    if (terminalReadyRef.current) {
      try {
        terminalRef.current?.writeText?.(String(text).replace(/\n/g, '\r\n') + '\r\n');
      } catch (_) {}
    } else {
      terminalPendingRef.current.push(String(text));
    }
  };

  // Строки журнала/статусов выводим в терминал как КОММЕНТАРИИ bash ("# ...") —
  // иначе shell пытается их выполнить и транскрипт журнала засоряется мусором
  // вида "bash: ✓: command not found" / "syntax error near unexpected token `('".
  const sayInTerminal = text => {
    const s = String(text ?? '').replace(/\r/g, '');
    writeTerminal(s.split('\n').map(l => l ? `# ${l}` : '').join('\n'));
  };

  // Run the complete command in the native durable-job supervisor. The terminal is only a
  // viewer: its PTY and this React activity may disappear without terminating the build.
  const runInTerminal = async (
    label,
    command,
    { cwd, kind = 'project-build', metadata = {} }:
      { cwd?: string; timeoutMs?: number; kind?: string; metadata?: Record<string, unknown> } = {},
  ) => {
    append(`$ ${label}`, 'command');
    sayInTerminal(`── ${label} ──`);
    try {
      const result = await persistentStreamExecute(
        command,
        cwd || '/',
        line => {
          const artifactMarker = /^@@NOVA_ARTIFACT@@:(.+)$/.exec(line);
          if (artifactMarker) {
            setArtifact(artifactMarker[1].trim());
            return;
          }
          append(line);
          sayInTerminal(line);
        },
        {
          label: `Build: ${label}`,
          kind,
          metadata: {
            label,
            projectId: currentProject?.id || '',
            projectName: currentProject?.name || '',
            ...metadata,
          },
        },
      );
      const ok = result.success && result.exitCode === 0;
      append(ok ? `✓ ${label} — готово` : `✗ ${label} — ошибка (rc=${result.exitCode ?? '?'})`, ok ? 'success' : 'error');
      return ok;
    } catch (error) {
      append(`✗ ${label} — ${error?.message || String(error)}`, 'error');
      return false;
    }
  };
  const onTerminalEvent = event => {
    const value = event?.nativeEvent || event;
    if (value?.type === 'started') {
      terminalReadyRef.current = true;
      const buf = terminalPendingRef.current;
      terminalPendingRef.current = [];
      buf.forEach(t => writeTerminal(t));
    }
    if (value?.type === 'exit') terminalReadyRef.current = false;
  };
  const clearConsole = () => {
    setLogs([]);
    try {
      terminalRef.current?.writeText?.('\u001b[2J\u001b[H');
    } catch (_) {}
  };
  const append = (text, level = 'normal') => {
    setLogs(v => [...v, {
      id: `${Date.now()}-${v.length}`,
      text,
      level
    }]);
    sayInTerminal(text);
  };

  // Reattach after activity/process recreation. The full native log is replayed first and then
  // followed live; no new command is submitted and the foreground service remains the owner.
  useEffect(() => {
    let mounted = true;
    void (async () => {
      const job = await apt.getCurrentDetachedJob();
      if (!mounted || !job?.id || job.kind !== 'project-build-workflow') return;
      let metadata: any = {};
      try { metadata = JSON.parse(job.metadata || '{}'); } catch (_) {}
      if (String(metadata.projectId || '') !== String(currentProject?.id || '')) return;
      if (reattachedJobRef.current === job.id) return;
      reattachedJobRef.current = job.id;
      setLogs([]);
      setRunning(['queued', 'running', 'stopping'].includes(job.status));
      setResultState(['queued', 'running', 'stopping'].includes(job.status) ? 'running' : 'idle');
      append(ru ? '↻ Подключение к фоновой сборке…' : '↻ Reattaching to background build…', 'warning');
      const result = await observeDetachedJob(job.id, line => {
        if (!mounted) return;
        const artifactMarker = /^@@NOVA_ARTIFACT@@:(.+)$/.exec(line);
        if (artifactMarker) {
          setArtifact(artifactMarker[1].trim());
        } else {
          append(line);
        }
      }, job);
      if (!mounted) return;
      setRunning(false);
      setResultState(result.success ? 'success' : 'error');
      if (!artifact && metadata.task === 'build') setArtifact(`${getProjectDir(currentProject)}/dist`);
      if (!artifact && metadata.task === 'android') {
        const extension = metadata.variant === 'aab' ? 'aab' : 'apk';
        const found = await execute(`find android/app/build/outputs -name '*.${extension}' 2>/dev/null | head -1`, getProjectDir(currentProject));
        const path = String(found?.output || '').trim();
        if (mounted && path) setArtifact(path.startsWith('/') ? path : `${getProjectDir(currentProject)}/${path}`);
      }
    })().catch(error => {
      if (mounted) append(error?.message || String(error), 'error');
    });
    return () => { mounted = false; };
  }, [currentProject?.id]);

  const runPrepare = async () => {
    if (!currentProject || running) return;
    setRunning(true);
    setResultState('running');
    setLogs([]);
    setArtifact('');
    const cwd = getProjectDir(currentProject);
    await startBackground(`${copy.title}: Prepare`);
    try {
      // prepare в терминале (или JS-фолбэк, если нет терминала)
      if (terminalReadyRef.current) {
        const ok = await runInTerminal('prepare.sh — 7 шагов SDK37', '([ -f prepare.sh ] && bash prepare.sh) || echo "prepare.sh нет — используйте Android APK"', {
          timeoutMs: 30 * 60 * 1000,
          cwd
        });
        if (!ok) throw new Error('prepare не завершился — смотрите терминал');
      } else {
        const r = await prepareProject(currentProject, {
          download: true
        });
        if (!r.success) throw new Error(r.output || 'prepare failed');
      }
      setResultState('success');
    } catch (e) {
      append(e?.message || String(e), 'error');
      setResultState('error');
    } finally {
      setRunning(false);
      await stopBackground();
      setTimeout(() => scrollRef.current?.scrollToEnd({
        animated: true
      }), 80);
    }
  };
  const run = async (selected = task) => {
    if (!currentProject || running) return;
    setRunning(true);
    setResultState('running');
    setLogs([]);
    setArtifact('');
    const cwd = getProjectDir(currentProject);
    // Фоновая служба: долгая сборка (npm install / vite / gradle) продолжается,
    // даже если приложение свернуть или заблокировать экран.
    await startBackground(`${copy.title}: ${selected === 'android' ? `APK ${variant.toUpperCase()}` : tasks[selected]?.label || selected}`);
    try {
      sayInTerminal(`🔧 ${selected === 'android' ? `APK ${variant.toUpperCase()}` : tasks[selected]?.label || selected} — ${currentProject.name}`);
      if (selected === 'dev') {
        // dev-server не ждёт завершения — запускаем в фоне и показываем PID
        const ok = await runInTerminal('Vite dev (фоновый)', 'nohup npm run dev -- --host 0.0.0.0 --port 5173 > /tmp/vite.log 2>&1 & echo $!', {
          timeoutMs: 30000,
          cwd
        });
        sayInTerminal('Откройте http://localhost:5173 или предпросмотр в приложении');
        setResultState('success');
        return;
      }
      if (selected === 'build') {
        // One service-owned workflow: if JS dies after npm install, Android still advances through
        // Vite and the asset copy. Stable markers let a recreated BuildScreen recover the artifact.
        const workflow = [
          'set -e',
          `echo ${shellQuote('── install vite (если нужно) ──')}`,
          '[ -f node_modules/.bin/vite ] || npm install --silent',
          `echo ${shellQuote('── vite build ──')}`,
          'npm run build 2>&1',
          `echo ${shellQuote('── dist → android/assets ──')}`,
          'mkdir -p android/app/src/main/assets',
          'rm -rf android/app/src/main/assets/*',
          'cp -r dist/* android/app/src/main/assets/',
          'test -s dist/index.html',
          `printf '@@NOVA_ARTIFACT@@:%s/dist\\n' "$PWD"`,
        ].join('\n');
        const okBuild = await runInTerminal('Vite build workflow', workflow, {
          cwd,
          kind: 'project-build-workflow',
          metadata: { task: 'build', variant: 'web', workflowVersion: 1 },
        });
        if (!okBuild) throw new Error('vite build не завершился — смотрите терминал');
        setArtifact(`${cwd}/dist`);
        setResultState('success');
        addWorkspaceLog(`vite build: ${copy.success}`, 'success');
      } else if (selected === 'android') {
        // Полный APK/AAB пайплайн в ТЕРМИНАЛЕ: подготовка → npm install → vite build → gradle.
        const gradleTask = variant === 'aab' ? 'bundleRelease' : variant === 'release' ? 'assembleRelease' : 'assembleDebug';
        const label = variant === 'aab' ? 'AAB (bundleRelease)' : `APK ${variant.toUpperCase()}`;
        // Шаг 1. Обновляем android-скелет проекта из текущего шаблона конструктора
        // (MainActivity на WebViewAssetLoader, зависимости, иконки, скрипты) — так
        // старые проекты получают исправления автоматически, без пересоздания.
        // Пользовательский код (src/*) и подпись при этом не трогаются.
        try {
          // Самолечение: восстанавливаем отсутствующие файлы шаблона (прерванное
          // создание, случайное удаление) — существующие файлы не трогаются.
          const integ = await ensureProjectIntegrity(currentProject);
          if (integ?.restored?.length) append(`✓ Восстановлены файлы проекта: ${integ.restored.join(', ')}`, 'warning');
          // Убираем MainActivity по старому package-пути (если пакет меняли в настройках).
          await execute('rm -rf android/app/src/main/java', cwd);
          const rr = await refreshAndroidScaffold(currentProject);
          append(rr?.success ? `✓ ${rr.output || 'Android-шаблон обновлён'}` : `⚠ ${rr?.output || 'не удалось обновить android-шаблон'}`, rr?.success ? 'success' : 'warning');
        } catch (e) {
          append(`⚠ не удалось обновить android-шаблон: ${e?.message || String(e)}`, 'warning');
        }
        // Every expensive transition is part of one persisted command. Android advances from
        // prepare → npm → Vite → assets → Gradle → validation → export even with no JS runtime.
        const sub = variant === 'aab' ? 'bundle/release' : `apk/${variant === 'release' ? 'release' : 'debug'}`;
        const ext = variant === 'aab' ? 'aab' : 'apk';
        const slugName = slugifyProject(currentProject.name || 'app') || 'app';
        const artifactFile = `${slugName}-v${currentProject.versionName || '1.0.0'}-${variant}.${ext}`;
        const exportDir = `/sdcard/Download/NovaCompose/${currentProject.name || slugName}/apk`;
        const workflow = [
          'PROJECT="$PWD"',
          `echo ${shellQuote('── prepare.sh — подготовка проекта ──')}`,
          '([ -f prepare.sh ] && bash prepare.sh) || echo "⚠ prepare завершился с предупреждением — продолжаем"',
          'set -e',
          `echo ${shellQuote('── npm install / Vite build ──')}`,
          '[ -f node_modules/.bin/vite ] || npm install --silent',
          'npm run build 2>&1',
          'mkdir -p android/app/src/main/assets',
          'rm -rf android/app/src/main/assets/*',
          'cp -r dist/* android/app/src/main/assets/',
          `echo ${shellQuote(`── Gradle ${gradleTask} ──`)}`,
          `cd android && ./gradlew ${gradleTask} --no-daemon --console=plain --warning-mode=none 2>&1`,
          'cd "$PROJECT"',
          `ARTIFACT=$(find "$PROJECT/android/app/build/outputs/${sub}" -name '*.${ext}' 2>/dev/null | head -1)`,
          '[ -n "$ARTIFACT" ] && [ -s "$ARTIFACT" ]',
          'echo "✅ artifact: $ARTIFACT"',
          ...(ext === 'apk' ? [
            'SDK="$ANDROID_HOME"; [ -n "$SDK" ] || SDK="$HOME/android-sdk"',
            'BT=$(ls "$SDK/build-tools" 2>/dev/null | grep -E "^[0-9]" | sort -V | tail -1)',
            'if [ -x "$SDK/build-tools/$BT/aapt2" ]; then "$SDK/build-tools/$BT/aapt2" dump badging "$ARTIFACT" 2>/dev/null | grep -E "^(package|application-label|sdkVersion|targetSdkVersion|native-code):" | head -7 || echo "⚠ aapt2 validation produced no metadata"; fi',
          ] : []),
          `DEST=${shellQuote(exportDir)}`,
          `if mkdir -p "$DEST" 2>/dev/null && cp -f "$ARTIFACT" "$DEST/${artifactFile}"; then ls -lh "$DEST/${artifactFile}"; else echo ${shellQuote(`⚠ Не удалось экспортировать в ${exportDir}`)}; fi`,
          `printf '@@NOVA_ARTIFACT@@:%s\\n' "$ARTIFACT"`,
        ].join('\n');
        const ok = await runInTerminal(label, workflow, {
          cwd,
          kind: 'project-build-workflow',
          metadata: { task: 'android', variant, extension: ext, workflowVersion: 1 },
        });
        if (!ok) throw new Error('Сборка не завершилась — смотрите терминал');
        const probe = await execute(`find android/app/build/outputs/${sub} -name '*.${ext}' 2>/dev/null | head -1`, cwd);
        const outPath = String(probe.output || '').trim();
        if (!outPath) throw new Error(ru ? 'Сборка завершилась, но артефакт не найден' : 'Build finished but no artifact was found');
        const absArtifact = outPath.startsWith('/') ? outPath : `${cwd}/${outPath}`;
        setArtifact(absArtifact);
        append(`✓ Экспорт: ${exportDir}/${artifactFile}`, 'success');
        setResultState('success');
        addWorkspaceLog(`${variant} ${ext}: ${copy.success}`, 'success');
      } else if (selected === 'prepare') {
        return runPrepare();
      }
    } catch (e) {
      append(e?.message || String(e), 'error');
      setResultState('error');
      addWorkspaceLog(String(e), 'error');
    } finally {
      setRunning(false);
      await stopBackground();
      setTimeout(() => scrollRef.current?.scrollToEnd({
        animated: true
      }), 80);
    }
  };
  const installDebug = async () => {
    // Используем реальный путь к APK из артефакта, а не зашитый.
    const path = artifact && artifact.endsWith('.apk') ? artifact : `${getProjectDir(currentProject)}/android/app/build/outputs/apk/debug/app-debug.apk`;
    // Проверяем, что файл реально существует и непустой — иначе системный установщик
    // открывается с «ошибкой пакета», хотя приложение сообщает «Installer opened».
    let probe;
    try {
      probe = await execute(`test -s '${path}' && echo FOUND || echo MISSING`);
    } catch (e) {
      probe = null;
    }
    if (!/FOUND/.test(probe?.output || '')) {
      const msg = ru ? `APK не найден: ${path} — сначала выполните сборку (кнопка «Запустить»)` : `APK not found: ${path} — run a build first`;
      append(`✗ ${msg}`, 'error');
      addWorkspaceLog(msg, 'error');
      return;
    }
    append(`$ install ${path}`, 'command');
    const r = await apt.installApk?.(path);
    append(r?.success ? 'Installer opened' : r?.output || 'Install unavailable', r?.success ? 'success' : 'error');
  };

  // «Журнал» — расшарить ПОЛНЫЙ лог сборки (читаем build.log, если есть),
  // чтобы скопировать и скинуть мне/в поддержку.
  // «Журнал» — расшарить ПОЛНЫЙ вывод сборки. Весь вывод идёт в нативный терминал,
  // поэтому в первую очередь забираем его транскрипт (весь скроллбэк), а state-массив
  // logs и build.log — только запасные варианты.
  const shareJournal = async () => {
    let text = '';
    try {
      const t = await terminalRef.current?.getTranscriptText?.();
      if (t && String(t).trim()) text = String(t).trim();
    } catch (e) {}
    if (!text) text = logs.map(l => l.text).join('\n').trim();
    if (!text) {
      try {
        const cwd = getProjectDir(currentProject);
        const f = await execute('cat build.log 2>/dev/null', cwd);
        if (f?.output && f.output.trim()) text = `=== build.log (${cwd}/build.log) ===\n${f.output}`;
      } catch (e) {}
    }
    if (!text) text = ru ? '(журнал пуст — запустите сборку)' : '(log empty — run a build)';
    try {
      await Share.share({
        message: text,
        title: ru ? 'Журнал сборки' : 'Build log'
      });
    } catch (e) {
      append(`${ru ? 'Не удалось открыть' : 'Share failed'}: ${e?.message || e}`, 'error');
    }
  };
  if (!currentProject) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View className={styles.empty}><Icon name="logo-react" size={40} color={colors.textTertiary} /><Text className={styles.muted}>{copy.noProject}</Text></View></AppScreen>;
  const cur = tasks[task];
  return <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="options-outline" label={width >= 720 ? 'Настройки' : null} onPress={() => navigation.navigate('ProjectSettings')} />} />
      <View className={cn(styles.main, !desktop && styles.mainMobile)}>
        <ScrollView className={cn(styles.settingsPane, !desktop && styles.settingsMobile)} contentContainerClassName={styles.settingsContent}>
          <SectionCard title={copy.choose} icon="hammer-outline">
            <SegmentedControl value={task} onChange={setTask} options={Object.entries(tasks).map(([v, it]) => ({
            value: v,
            label: it.label,
            icon: it.icon
          }))} />
            <View className={styles.taskSummary}><View className={styles.taskIcon}><Icon name={cur.icon} size={23} color={colors.primary} /></View><View style={{
              flex: 1
            }}><Text className={styles.taskTitle}>{cur.label}</Text><Text className={styles.taskMeta}>{task === 'android' ? variant === 'aab' ? 'bundleRelease' : variant === 'release' ? 'assembleRelease' : 'assembleDebug' : cur.cmd}</Text><Text style={{
                color: colors.textTertiary,
                fontSize: 10,
                marginTop: 2
              }}>{cur.desc}</Text></View><StatusPill label={cur.label} tone={cur.tone} /></View>
          </SectionCard>
          {task === 'android' ? <SectionCard title={ru ? 'Тип сборки' : 'Build type'} icon={variant === 'aab' ? 'cube-outline' : variant === 'release' ? 'lock-closed-outline' : 'bug-outline'}>
              <SegmentedControl value={variant} onChange={setVariant} options={[{
            value: 'debug',
            label: 'Debug',
            icon: 'bug-outline'
          }, {
            value: 'release',
            label: 'Release',
            icon: 'lock-closed-outline'
          }, {
            value: 'aab',
            label: 'AAB',
            icon: 'cube-outline'
          }]} />
              <Text style={{
            color: colors.textSecondary,
            fontSize: 10,
            lineHeight: 15,
            marginTop: 6
          }}>
                {variant === 'aab' ? ru ? 'AAB: bundleRelease для Google Play (подпись из keystore.properties).' : 'AAB: bundleRelease for Google Play (signed via keystore.properties).' : variant === 'release' ? ru ? 'Release: R8 + minify + подпись. Нужен keystore.properties; иначе APK будет неподписан.' : 'Release: R8 + minify + signing. Needs keystore.properties; otherwise unsigned APK.' : ru ? 'Debug: app-debug.apk с debug-keystore. Подходит для установки и теста.' : 'Debug: app-debug.apk with debug keystore. Good for install & test.'}
              </Text>
            </SectionCard> : null}
          <View className={styles.note}><Icon name="information-circle-outline" size={17} color={colors.info} /><Text className={styles.noteText}>{copy.note}</Text></View>
          <View style={{
          flexDirection: 'row',
          gap: 8
        }}>
            <PrimaryButton title={running ? copy.running : task === 'android' ? `${copy.run} · ${variant === 'aab' ? 'AAB' : variant === 'release' ? 'Release' : 'Debug'}` : copy.run} icon="hammer-outline" loading={running} onPress={() => run()} style={{
            flex: 1
          }} />
            <IconButton name="shield-checkmark-outline" label="Prepare" loading={running} onPress={runPrepare} style={{
            flex: 1
          }} />
          </View>
          <IconButton name="trash-outline" label={copy.clean} disabled={running} onPress={async () => {
          await execute('rm -rf dist android/app/src/main/assets/* android/app/build 2>/dev/null; echo cleaned', getProjectDir(currentProject));
          append('cleaned', 'info');
        }} />
        </ScrollView>
        <View className={cn(styles.consoleWrap, !desktop && styles.consoleMobile)}>
          <View className={styles.consoleHead}>{narrow ? null : <View className={styles.dots}><View className={styles.dot} style={{
              backgroundColor: '#F87171'
            }} /><View className={styles.dot} style={{
              backgroundColor: '#FBBF24'
            }} /><View className={styles.dot} style={{
              backgroundColor: '#34D399'
            }} /></View>}<Text className={styles.consoleTitle}>{copy.terminal}</Text><View style={{
            flex: 1
          }} />
            {narrow ? null : <IconButton name="remove-outline" onPress={() => setFontSize(v => Math.max(10, v - 2))} />}
            {narrow ? null : <IconButton name="add-outline" onPress={() => setFontSize(v => Math.min(34, v + 2))} />}
            {!narrow && resultState !== 'idle' ? <StatusPill label={resultState === 'success' ? copy.success : resultState === 'error' ? 'Error' : '…'} tone={resultState === 'success' ? 'success' : resultState === 'error' ? 'error' : 'info'} /> : null}
            <Pressable onPress={shareJournal} className={styles.clear} style={{
            flexDirection: 'row',
            gap: 4,
            backgroundColor: '#253046',
            paddingHorizontal: 8,
            borderRadius: 6
          }}><Icon name="share-outline" size={13} color="#4ADE80" />{narrow ? null : <Text style={{
              color: '#4ADE80',
              fontSize: 10,
              fontWeight: '700'
            }}>{ru ? 'Журнал' : 'Log'}</Text>}</Pressable>
            <Pressable onPress={clearConsole} className={styles.clear}><Icon name="trash-outline" size={14} color="#8B98AD" /></Pressable>
          </View>
          {terminalAvailable() ? <View className={styles.consoleTerminalWrap}>
              <TerminalView ref={terminalRef} className={styles.consoleTerminal} fontSize={fontSize} extraKeys={EXTRA_KEYS} readOnly workingDirectory={getProjectDir(currentProject)} initialCommand={ru ? 'echo "Сборка: ' + currentProject.name + ' (proot). Нажмите «Запустить»."' : 'echo "Build: ' + currentProject.name + ' (proot). Press Run."'} onTerminalEvent={onTerminalEvent} />
            </View> : <ScrollView ref={scrollRef} className={styles.console} contentContainerClassName={styles.consoleContent} onContentSizeChange={() => scrollRef.current?.scrollToEnd({
          animated: true
        })}>
              {!logs.length ? <View className={styles.consoleEmpty}><Icon name="logo-react" size={30} color="#526079" /><Text className={styles.consoleEmptyText}>{cur.cmd}</Text></View> : logs.map(l => <Text selectable key={l.id} className={cn(styles.log, l.level === 'command' && styles.command, l.level === 'success' && styles.success, l.level === 'error' && styles.error, l.level === 'warning' && styles.warning)}>{l.text}</Text>)}
            </ScrollView>}
          {artifact ? <View className={styles.artifactBar}><Icon name="cube-outline" size={20} color={colors.success} /><View style={{
            flex: 1,
            minWidth: 0
          }}><Text className={styles.artifactLabel}>{copy.artifact}</Text><Text className={styles.artifactPath} numberOfLines={1}>{artifact}</Text></View><PrimaryButton title={copy.install} icon="download-outline" disabled={!artifact.endsWith('.apk')} onPress={installDebug} /></View> : null}
          <AdsBanner />
        </View>
      </View>
    </AppScreen>;
};
const createStyles = c => ({
  main: "flex-1 min-w-0 min-h-0 flex-row overflow-hidden",
  mainMobile: "flex-col",
  settingsPane: "w-[40%] max-w-[440px] min-w-[340px] grow-[0]",
  settingsMobile: "w-full max-w-full min-w-0 flex-none max-h-[53%]",
  settingsContent: "p-[13px] gap-[12px] pb-[40px]",
  taskSummary: "min-h-[66px] p-[10px] rounded-[11px] bg-bg flex-row items-center gap-[10px]",
  taskIcon: "w-[43px] h-[43px] rounded-[11px] bg-primary-surface items-center justify-center",
  taskTitle: "text-text text-[13px] font-bold",
  taskMeta: "text-text-tertiary font-mono text-[9px] mt-[3px]",
  note: "p-[11px] rounded-[10px] flex-row items-start gap-[8px] bg-info-bg",
  noteText: "flex-1 text-info-text text-[10px] leading-[16px]",
  consoleWrap: "flex-1 min-w-0 min-h-0 bg-terminal border-l border-l-[#253046]",
  consoleMobile: "w-full border-l-0 border-t border-t-[#253046]",
  consoleHead: "h-[48px] px-[12px] flex-row items-center gap-[7px] bg-terminal-raised border-b border-b-[#253046]",
  dots: "flex-row gap-[5px]",
  dot: "w-[8px] h-[8px] rounded-[4px]",
  consoleTitle: "text-[#D6DEEB] text-[11px] font-bold",
  clear: "p-[7px]",
  consoleTerminalWrap: "flex-1 min-w-0 min-h-0 bg-terminal",
  consoleTerminal: "flex-1 bg-terminal",
  console: "flex-1",
  consoleContent: "p-[14px] pb-[40px]",
  consoleEmpty: "min-h-[280px] items-center justify-center gap-[9px]",
  consoleEmptyText: "text-[#526079] font-mono text-[10px]",
  log: "text-[#C9D3E3] font-mono text-[10px] leading-[17px]",
  command: "text-white font-bold mt-[8px]",
  success: "text-[#4ADE80]",
  error: "text-[#F87171]",
  warning: "text-[#FBBF24]",
  artifactBar: "min-h-[64px] p-[9px] flex-row items-center gap-[9px] bg-bg-card border-t border-t-border",
  artifactLabel: "text-text text-[10px] font-bold",
  artifactPath: "text-text-secondary font-mono text-[8px] mt-[2px]",
  empty: "flex-1 items-center justify-center gap-[9px]",
  muted: "text-text-secondary"
});
export default BuildScreen;
