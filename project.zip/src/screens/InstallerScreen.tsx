import React
{ useCallback
useEffect
useMemo
useState } from 'react';
import { ActivityIndicator
Platform
ScrollView
Text
View } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen
PrimaryButton
SectionCard
StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { ROOTFS_NAME
ROOTFS_URL } from '../config/runtime';
import { getProotStatus
isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';
import * as apt from '../../modules/apt-manager/src/index';
import { startBackground
stopBackground
updateBackground } from '../utils/background';
const InstallerScreen = ({ onInstalled }) => {
  const { colors
language } = useAppSettings();
  const [phase
setPhase] = useState('checking');
  const [progress
setProgress] = useState(null);
  const [error
setError] = useState('');
  const [elapsed
setElapsed] = useState(0);
  const nativeReady = terminalAvailable() && apt.isAvailable();
  const copy = language === 'ru' ? {
    title: 'Подготовка рабочей среды'
    subtitle: 'Однократная установка Linux-окружения для JDK
Android SDK и Gradle'
    checking: 'Проверяем рабочую среду'
    ready: 'Ubuntu уже установлена'
    install: 'Установить Ubuntu'
    retry: 'Повторить установку'
    unavailable: 'Нужна нативная development-сборка'
    unavailableText: 'Установка rootfs использует нативные модули и недоступна в браузере. Установите нативную development-сборку NovaCompose Studio.'
    security: 'Фиксированный официальный образ проекта'
    size: 'Скачивание и распаковка могут занять несколько минут. Можно свернуть приложение — установка продолжится в фоне.'
    failed: 'Не удалось установить рабочую среду.'
    extracting: 'Распаковываем Ubuntu'
    connecting: 'Подключаемся к серверу'
    downloading: 'Скачиваем образ'
    preparing: 'Настраиваем apt и dpkg'
    verify: 'Проверяем установку'
  } : {
    title: 'Prepare the workspace'
    subtitle: 'One-time Linux environment setup for JDK
Android SDK and Gradle'
    checking: 'Checking the workspace'
    ready: 'Ubuntu is already installed'
    install: 'Install Ubuntu'
    retry: 'Retry installation'
    unavailable: 'A native development build is required'
    unavailableText: 'Rootfs installation uses native modules and is unavailable in the browser. Install the native NovaCompose Studio development build.'
    security: 'Fixed project-provided image'
    size: 'Downloading and extracting can take several minutes. You can minimize the app — it keeps running in the background.'
    failed: 'Workspace installation failed.'
    extracting: 'Extracting Ubuntu'
    connecting: 'Connecting to server'
    downloading: 'Downloading image'
    preparing: 'Configuring apt and dpkg'
    verify: 'Verifying installation'
  };
  const check = useCallback(async () => {
    setPhase('checking');
    setError('');
    if (!nativeReady) {
      setPhase('unavailable');
      return;
    }
    try {
      const status = await getProotStatus();
      if (status?.rootfsInstalled && (!status?.rootfsArch || status.rootfsArch === 64)) {
        setPhase('ready');
        setTimeout(onInstalled
250);
      } else {
        setPhase('idle');
      }
    } catch (e) {
      setError(e?.message || String(e));
      setPhase('idle');
    }
  }
[nativeReady
onInstalled]);
  useEffect(() => { check(); }
[check]);
  useEffect(() => {
    if (phase !== 'installing') return undefined;
    const startedAt = Date.now();
    const timer = setInterval(async () => {
      setElapsed(Math.floor((Date.now() - startedAt) / 1000));
      try { setProgress(await apt.getRootfsProgress()); } catch (e) {}
    }
650);
    return () => clearInterval(timer);
  }
[phase]);
  const install = async () => {
    setPhase('installing');
    setError('');
    setProgress({ stage: 'connecting'
downloadedBytes: 0
totalBytes: 0 });
    // Фоновая служба: скачивание/распаковка продолжается
даже если приложение свёрнуто.
    await startBackground(copy.install);
    try {
      const result = await apt.installProotRootfs(ROOTFS_URL);
      if (!result?.success) throw new Error(result?.output || copy.failed);
      // Note: apt/dpkg auto-preparation runs natively inside installProotRootfs
      // (stage "preparing")
so `apt update && apt upgrade` work right after install.
      setProgress({ stage: 'verifying'
message: copy.verify });
      await updateBackground(copy.verify);
      const status = await getProotStatus();
      if (!status?.rootfsInstalled) throw new Error(copy.failed);
      if (status?.rootfsArch && status.rootfsArch !== 64) throw new Error('Installed rootfs is not arm64.');
      setPhase('ready');
      await stopBackground();
      // Дальше — страница установки RAI (base + sdk + status).
      setTimeout(onInstalled
450);
    } catch (e) {
      await stopBackground();
      setError(e?.message || String(e));
      setPhase('error');
    }
  };
  const percentage = progress?.totalBytes > 0
    ? Math.min(100
Math.round((progress.downloadedBytes / progress.totalBytes) * 100))
    : 0;
  const stageLabel = progress?.stage === 'extracting' ? copy.extracting
    : progress?.stage === 'downloading' ? copy.downloading
      : progress?.stage === 'preparing' ? copy.preparing
        : progress?.stage === 'verifying' ? copy.verify : copy.connecting;
  const styles = useMemo(() => /* styles removed */(colors)
[colors]);
  return (
    <AppScreen>
      <ScrollView contentContainerStyle={className="page} keyboardShouldPersistTaps="handled">
        <View className="p-4">
          <View className="p-4">
            <Icon name="construct-outline" size={30} color="#FFFFFF" />
          </View>
          <Text className="p-4">{copy.title}</Text>
          <Text className="p-4">{copy.subtitle}</Text>
          <SectionCard className="p-4">
            <View className="p-4">
              <View className="p-4"><Icon name="server-outline" size={24} color={colors.primary} /></View>
              <View className="flex-1">
                <Text className="p-4">{ROOTFS_NAME}</Text>
                <Text className="p-4">GNU/Linux · arm64 · rootfs</Text>
              </View>
              <StatusPill label="ARM64" tone="info" />
            </View>
            <View className="p-4">
              <Icon name="lock-closed-outline" size={15} color={colors.success} />
              <Text className="p-4" numberOfLines={2}>{ROOTFS_URL}</Text>
            </View>
            {phase === 'checking' ? (
              <View className="p-4"><ActivityIndicator color={colors.primary} /><Text className="p-4">{copy.checking}</Text></View>
            ) : phase === 'installing' ? (
              <View className="gap-[10px]">
                <View className="p-4">
                  <Text className="p-4">{stageLabel}</Text>
                  <Text className="p-4">{percentage ? `${percentage}% · ` : ''}{elapsed}s</Text>
                </View>
                <View className="p-4"><View style={[className="progressFill
{ width: `${percentage || 8}%` }]} /></View>
                {progress?.downloadedBytes > 0 ? (
                  <Text className="p-4">
                    {(progress.downloadedBytes / 1048576).toFixed(1)} MB{progress.totalBytes > 0 ? ` / ${(progress.totalBytes / 1048576).toFixed(1)} MB` : ''}
                  </Text>
                ) : null}
              </View>
            ) : phase === 'ready' ? (
              <View className="p-4"><Icon name="checkmark-circle" size={22} color={colors.success} /><Text className="p-4">{copy.ready}</Text></View>
            ) : phase === 'unavailable' ? (
              <View className="p-4">
                <Icon name="hardware-chip-outline" size={22} color={colors.warning} />
                <View className="flex-1"><Text className="p-4">{copy.unavailable}</Text><Text className="p-4">{copy.unavailableText}</Text></View>
              </View>
            ) : (
              <>
                {error ? <View className="p-4"><Icon name="alert-circle-outline" size={22} color={colors.error} /><Text selectable style={[className="errorText
{ flex: 1 }]}>{error}</Text></View> : null}
                <PrimaryButton title={phase === 'error' ? copy.retry : copy.install} icon="download-outline" onPress={install} />
              </>
            )}
          </SectionCard>
          <View className="p-4">
            <Icon name="information-circle-outline" size={18} color={colors.textSecondary} />
            <Text className="p-4">{copy.security}. {copy.size}</Text>
          </View>
          <Text className="p-4">NovaCompose Studio · Android · Gradle · {Platform.OS}</Text>
        </View>
      </ScrollView>
    </AppScreen>
  );
};
// Tailwind className
export default InstallerScreen;