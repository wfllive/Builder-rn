import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Platform, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { ROOTFS_NAME, ROOTFS_URL } from '../config/runtime';
import { getProotStatus, isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';
import * as apt from '../../modules/apt-manager/src/index';
import { startBackground, stopBackground, updateBackground } from '../utils/background';
import { cn } from "../utils/cn";
const InstallerScreen = ({
  onInstalled
}) => {
  const {
    colors,
    language
  } = useAppSettings();
  const { width, height } = useWindowDimensions();
  const compact = width < 430;
  const short = height < 720;
  const [phase, setPhase] = useState('checking');
  const [progress, setProgress] = useState(null);
  const [error, setError] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [resumeRequested, setResumeRequested] = useState(false);
  const nativeReady = terminalAvailable() && apt.isAvailable();
  const copy = language === 'ru' ? {
    title: 'Подготовка рабочей среды',
    subtitle: 'Однократная установка Linux-окружения для JDK, Android SDK и Gradle',
    checking: 'Проверяем рабочую среду',
    ready: 'Ubuntu уже установлена',
    install: 'Установить Ubuntu',
    retry: 'Повторить установку',
    unavailable: 'Нужна нативная development-сборка',
    unavailableText: 'Установка rootfs использует нативные модули и недоступна в браузере. Установите нативную development-сборку NovaCompose Studio.',
    security: 'Фиксированный официальный образ проекта',
    size: 'Скачивание и распаковка могут занять несколько минут. Можно свернуть приложение — установка продолжится в фоне.',
    failed: 'Не удалось установить рабочую среду.',
    extracting: 'Распаковываем Ubuntu',
    connecting: 'Подключаемся к серверу',
    downloading: 'Скачиваем образ',
    preparing: 'Настраиваем apt и dpkg',
    verify: 'Проверяем установку'
  } : {
    title: 'Prepare the workspace',
    subtitle: 'One-time Linux environment setup for JDK, Android SDK and Gradle',
    checking: 'Checking the workspace',
    ready: 'Ubuntu is already installed',
    install: 'Install Ubuntu',
    retry: 'Retry installation',
    unavailable: 'A native development build is required',
    unavailableText: 'Rootfs installation uses native modules and is unavailable in the browser. Install the native NovaCompose Studio development build.',
    security: 'Fixed project-provided image',
    size: 'Downloading and extracting can take several minutes. You can minimize the app — it keeps running in the background.',
    failed: 'Workspace installation failed.',
    extracting: 'Extracting Ubuntu',
    connecting: 'Connecting to server',
    downloading: 'Downloading image',
    preparing: 'Configuring apt and dpkg',
    verify: 'Verifying installation'
  };
  const check = useCallback(async () => {
    setPhase('checking');
    setError('');
    if (!nativeReady) {
      setPhase('unavailable');
      return;
    }
    try {
      const status = await getProotStatus();
      if (status?.rootfsInstalled && (!status?.rootfsArch || status.rootfsArch === 64)) {
        setPhase('ready');
        setTimeout(onInstalled, 250);
      } else {
        const installProgress = await apt.getRootfsProgress();
        setProgress(installProgress);
        if (installProgress?.status === 'queued' || installProgress?.status === 'running') {
          // Native installation survived/restarted after activity or process recreation. Calling
          // install again reuses the persisted operation and only reattaches this UI observer.
          setPhase('installing');
          setResumeRequested(true);
        } else {
          setPhase('idle');
        }
      }
    } catch (e) {
      setError(e?.message || String(e));
      setPhase('idle');
    }
  }, [nativeReady, onInstalled]);
  useEffect(() => {
    check();
  }, [check]);
  useEffect(() => {
    if (phase !== 'installing') return undefined;
    const startedAt = Date.now();
    const timer = setInterval(async () => {
      setElapsed(Math.floor((Date.now() - startedAt) / 1000));
      try {
        setProgress(await apt.getRootfsProgress());
      } catch (e) {}
    }, 650);
    return () => clearInterval(timer);
  }, [phase]);
  const install = async () => {
    setPhase('installing');
    setError('');
    setProgress({
      stage: 'connecting',
      downloadedBytes: 0,
      totalBytes: 0
    });
    // Фоновая служба: скачивание/распаковка продолжается, даже если приложение свёрнуто.
    await startBackground(copy.install);
    try {
      const result = await apt.installProotRootfs(ROOTFS_URL);
      if (!result?.success) throw new Error(result?.output || copy.failed);
      // Note: apt/dpkg auto-preparation runs natively inside installProotRootfs
      // (stage "preparing"), so `apt update && apt upgrade` work right after install.
      setProgress({
        stage: 'verifying',
        message: copy.verify
      });
      await updateBackground(copy.verify);
      const status = await getProotStatus();
      if (!status?.rootfsInstalled) throw new Error(copy.failed);
      if (status?.rootfsArch && status.rootfsArch !== 64) throw new Error('Installed rootfs is not arm64.');
      setPhase('ready');
      await stopBackground();
      // Дальше — страница установки RAI (base + sdk + status).
      setTimeout(onInstalled, 450);
    } catch (e) {
      await stopBackground();
      setError(e?.message || String(e));
      setPhase('error');
    }
  };
  useEffect(() => {
    if (!resumeRequested) return;
    setResumeRequested(false);
    void install();
  }, [resumeRequested]);

  const percentage = progress?.totalBytes > 0 ? Math.min(100, Math.round(progress.downloadedBytes / progress.totalBytes * 100)) : 0;
  const stageLabel = progress?.stage === 'extracting' ? copy.extracting : progress?.stage === 'downloading' ? copy.downloading : progress?.stage === 'preparing' ? copy.preparing : progress?.stage === 'verifying' ? copy.verify : copy.connecting;
  const styles = useMemo(() => createStyles(colors, compact, short), [colors, compact, short]);
  return <AppScreen>
      <ScrollView contentContainerClassName={styles.page} keyboardShouldPersistTaps="handled">
        <View className={styles.content}>
          <View className={styles.brandMark}>
            <Icon name="construct-outline" size={30} color="#FFFFFF" />
          </View>
          <Text className={styles.title}>{copy.title}</Text>
          <Text className={styles.subtitle}>{copy.subtitle}</Text>

          <SectionCard className={styles.card}>
            <View className={styles.imageHeader}>
              <View className={styles.serverIcon}><Icon name="server-outline" size={24} color={colors.primary} /></View>
              <View style={{
              flex: 1
            }}>
                <Text className={styles.imageName}>{ROOTFS_NAME}</Text>
                <Text className={styles.arch}>GNU/Linux · arm64 · rootfs</Text>
              </View>
              <StatusPill label="ARM64" tone="info" />
            </View>

            <View className={styles.urlBox}>
              <Icon name="lock-closed-outline" size={15} color={colors.success} />
              <Text className={styles.url} numberOfLines={2}>{ROOTFS_URL}</Text>
            </View>

            {phase === 'checking' ? <View className={styles.stateRow}><ActivityIndicator color={colors.primary} /><Text className={styles.stateText}>{copy.checking}</Text></View> : phase === 'installing' ? <View style={{
            gap: 10
          }}>
                <View className={styles.progressHead}>
                  <Text className={styles.stateText}>{stageLabel}</Text>
                  <Text className={styles.progressMeta}>{percentage ? `${percentage}% · ` : ''}{elapsed}s</Text>
                </View>
                <View className={styles.progressTrack}><View className={styles.progressFill} style={{
                width: `${percentage || 8}%`
              }} /></View>
                {progress?.downloadedBytes > 0 ? <Text className={styles.progressMeta}>
                    {(progress.downloadedBytes / 1048576).toFixed(1)} MB{progress.totalBytes > 0 ? ` / ${(progress.totalBytes / 1048576).toFixed(1)} MB` : ''}
                  </Text> : null}
              </View> : phase === 'ready' ? <View className={styles.successRow}><Icon name="checkmark-circle" size={22} color={colors.success} /><Text className={styles.successText}>{copy.ready}</Text></View> : phase === 'unavailable' ? <View className={styles.errorBox}>
                <Icon name="hardware-chip-outline" size={22} color={colors.warning} />
                <View style={{
              flex: 1
            }}><Text className={styles.errorTitle}>{copy.unavailable}</Text><Text className={styles.errorText}>{copy.unavailableText}</Text></View>
              </View> : <>
                {error ? <View className={styles.errorBox}><Icon name="alert-circle-outline" size={22} color={colors.error} /><Text selectable className={styles.errorText} style={{
                flex: 1
              }}>{error}</Text></View> : null}
                <PrimaryButton title={phase === 'error' ? copy.retry : copy.install} icon="download-outline" onPress={install} />
              </>}
          </SectionCard>

          <View className={styles.note}>
            <Icon name="information-circle-outline" size={18} color={colors.textSecondary} />
            <Text className={styles.noteText}>{copy.security}. {copy.size}</Text>
          </View>
          <Text className={styles.platform}>NovaCompose Studio · Android · Gradle · {Platform.OS}</Text>
        </View>
      </ScrollView>
    </AppScreen>;
};
const createStyles = (c, compact, short) => ({
  page: compact ? "grow justify-center px-[12px] py-[16px]" : "grow justify-center p-[20px]",
  content: "w-full max-w-[620px] self-center items-center",
  brandMark: compact || short ? "w-[52px] h-[52px] rounded-[15px] items-center justify-center bg-primary mb-[13px]" : "w-[62px] h-[62px] rounded-[18px] items-center justify-center bg-primary mb-[20px]",
  title: compact ? "text-text text-[23px] leading-[29px] font-bold text-center tracking-[-0.4px]" : "text-text text-[28px] font-bold text-center tracking-[-0.5px]",
  subtitle: compact || short ? "text-text-secondary text-[12px] leading-[18px] text-center mt-[7px] mb-[15px]" : "text-text-secondary text-[14px] leading-[21px] text-center max-w-[460px] mt-[8px] mb-[24px]",
  card: compact ? "w-full p-[14px]" : "w-full p-[20px]",
  imageHeader: compact ? "flex-row flex-wrap items-center gap-[10px]" : "flex-row items-center gap-[12px]",
  serverIcon: compact ? "w-[42px] h-[42px] rounded-[11px] bg-primary-surface items-center justify-center" : "w-[46px] h-[46px] rounded-[12px] bg-primary-surface items-center justify-center",
  imageName: compact ? "text-text text-[14px] font-bold" : "text-text text-[16px] font-bold",
  arch: "text-text-secondary text-[12px] mt-[3px]",
  urlBox: "flex-row items-center gap-[9px] rounded-[9px] border border-border bg-bg-elevated p-[11px]",
  url: "text-text-secondary font-mono text-[10px] flex-1 leading-[15px]",
  stateRow: "min-h-[48px] flex-row items-center justify-center gap-[10px]",
  stateText: "text-text text-[13px] font-semibold",
  progressHead: "flex-row justify-between items-center",
  progressMeta: "text-text-tertiary text-[11px] font-mono",
  progressTrack: "h-[8px] rounded-[4px] overflow-hidden bg-bg-elevated",
  progressFill: "h-full min-w-[10px] bg-primary rounded-[4px]",
  successRow: "min-h-[48px] flex-row items-center justify-center gap-[8px] bg-success-bg rounded-[10px]",
  successText: "text-success-text text-[13px] font-bold",
  errorBox: "flex-row items-start gap-[10px] p-[13px] bg-error-bg rounded-[10px]",
  errorTitle: "text-error-text text-[13px] font-bold",
  errorText: "text-error-text text-[11px] leading-[17px] mt-[2px]",
  note: compact ? "flex-row items-start gap-[8px] mt-[13px]" : "flex-row items-start gap-[8px] max-w-[520px] mt-[18px]",
  noteText: "text-text-secondary text-[11px] leading-[17px] flex-1",
  platform: compact || short ? "text-text-tertiary text-[9px] mt-[14px]" : "text-text-tertiary text-[10px] mt-[22px]"
});
export default InstallerScreen;
