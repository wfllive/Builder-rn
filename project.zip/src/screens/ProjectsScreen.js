import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Modal, Alert, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import colors from '../theme/colors';

const ProjectsScreen = ({ navigation }) => {
  const { projects, createProject, deleteProject, openProject, isLoaded, importProject } = useProject();
  const [modalVisible, setModalVisible] = useState(false);
  const [importVisible, setImportVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [importData, setImportData] = useState('');
  const [search, setSearch] = useState('');

  const handleCreate = () => {
    if (newName.trim()) {
      createProject(newName.trim());
      setNewName('');
      setModalVisible(false);
    }
  };

  const handleImport = () => {
    try {
      const data = JSON.parse(importData);
      if (!data.name || !data.screens) throw new Error('Invalid');
      importProject(data);
      setImportData('');
      setImportVisible(false);
    } catch (e) {
      Alert.alert('Ошибка', 'Неверный JSON формат');
    }
  };

  const handleDelete = (project) => {
    Alert.alert('Удалить проект?', `"${project.name}" будет удалён.`, [
      { text: 'Отмена', style: 'cancel' },
      { text: 'Удалить', style: 'destructive', onPress: () => deleteProject(project.id) },
    ]);
  };

  const handleOpen = (project) => {
    openProject(project);
    navigation.navigate('Editor');
  };

  const filtered = projects.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const formatDate = (ts) => new Date(ts).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });

  const renderCard = ({ item }) => (
    <TouchableOpacity style={styles.card} onPress={() => handleOpen(item)} onLongPress={() => handleDelete(item)} activeOpacity={0.8}>
      <View style={styles.cardIcon}>
        <Icon name="phone-portrait-outline" size={24} color={colors.primary} />
      </View>
      <View style={styles.cardBody}>
        <Text style={styles.cardName} numberOfLines={1}>{item.name}</Text>
        <View style={styles.cardMeta}>
          <View style={styles.metaChip}>
            <Icon name="layers-outline" size={11} color={colors.textTertiary} />
            <Text style={styles.metaText}>{item.screens?.length || 0}</Text>
          </View>
          <View style={styles.metaChip}>
            <Icon name="time-outline" size={11} color={colors.textTertiary} />
            <Text style={styles.metaText}>{formatDate(item.updatedAt)}</Text>
          </View>
        </View>
      </View>
      <TouchableOpacity style={styles.cardAction} onPress={() => handleOpen(item)}>
        <Icon name="play" size={18} color={colors.primary} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  if (!isLoaded) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.loadingText}>Загрузка...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top','bottom']}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.bg} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.title}>Sketchware Pro</Text>
            <Text style={styles.subtitle}>Конструктор приложений</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Terminal')}>
              <Icon name="terminal-outline" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Libraries')}>
              <Icon name="cube-outline" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Build')}>
              <Icon name="rocket-outline" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconBtn} onPress={() => setImportVisible(true)}>
              <Icon name="download-outline" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>

        {projects.length > 0 && (
          <View style={styles.searchBar}>
            <Icon name="search-outline" size={18} color={colors.textTertiary} />
            <TextInput
              style={styles.searchInput}
              placeholder="Поиск..."
              placeholderTextColor={colors.textTertiary}
              value={search}
              onChangeText={setSearch}
            />
            {search ? (
              <TouchableOpacity onPress={() => setSearch('')}>
                <Icon name="close-circle" size={18} color={colors.textTertiary} />
              </TouchableOpacity>
            ) : null}
          </View>
        )}
      </View>

      {/* FAB */}
      <TouchableOpacity style={styles.fab} onPress={() => setModalVisible(true)} activeOpacity={0.85}>
        <Icon name="add" size={28} color="#fff" />
      </TouchableOpacity>

      {/* List */}
      {filtered.length === 0 ? (
        <View style={styles.emptyState}>
          <View style={styles.emptyIconWrap}>
            <Icon name="folder-open-outline" size={48} color={colors.textTertiary} />
          </View>
          <Text style={styles.emptyTitle}>{search ? 'Не найдено' : 'Нет проектов'}</Text>
          <Text style={styles.emptyDesc}>
            {search ? 'Измените запрос' : 'Нажмите + чтобы создать первый проект'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={renderCard}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Create Modal */}
      <Modal visible={modalVisible} transparent animationType="fade" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Новый проект</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Название"
              placeholderTextColor={colors.textTertiary}
              value={newName}
              onChangeText={setNewName}
              autoFocus
              onSubmitEditing={handleCreate}
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.modalBtn, styles.modalBtnCancel]} onPress={() => { setModalVisible(false); setNewName(''); }}>
                <Text style={styles.modalBtnCancelText}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, styles.modalBtnConfirm]} onPress={handleCreate}>
                <Text style={styles.modalBtnConfirmText}>Создать</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Import Modal */}
      <Modal visible={importVisible} transparent animationType="fade" onRequestClose={() => setImportVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Импорт проекта</Text>
            <TextInput
              style={[styles.modalInput, { height: 140, textAlignVertical: 'top' }]}
              placeholder="JSON данные..."
              placeholderTextColor={colors.textTertiary}
              value={importData}
              onChangeText={setImportData}
              multiline
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.modalBtn, styles.modalBtnCancel]} onPress={() => { setImportVisible(false); setImportData(''); }}>
                <Text style={styles.modalBtnCancelText}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, styles.modalBtnConfirm]} onPress={handleImport}>
                <Text style={styles.modalBtnConfirmText}>Импорт</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  center: { justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: colors.textSecondary, fontSize: 16 },
  
  header: {
    paddingTop: 52, paddingHorizontal: 20, paddingBottom: 16,
    backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 },
  headerActions: { flexDirection: 'row', gap: 8 },
  title: { fontSize: 26, fontWeight: '800', color: colors.primary },
  subtitle: { fontSize: 13, color: colors.textSecondary, marginTop: 2 },
  iconBtn: {
    width: 40, height: 40, borderRadius: 10, backgroundColor: colors.bgElevated,
    justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border,
  },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.bgInput, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: colors.border,
  },
  searchInput: { flex: 1, fontSize: 14, color: colors.text, padding: 0 },

  fab: {
    position: 'absolute', right: 20, bottom: 28, zIndex: 10,
    width: 56, height: 56, borderRadius: 28, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
    shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8, elevation: 8,
  },

  list: { padding: 16, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard,
    borderRadius: 14, padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: colors.border,
  },
  cardIcon: {
    width: 44, height: 44, borderRadius: 12, backgroundColor: colors.primarySurface,
    justifyContent: 'center', alignItems: 'center', marginRight: 12,
  },
  cardBody: { flex: 1 },
  cardName: { fontSize: 16, fontWeight: '700', color: colors.text },
  cardMeta: { flexDirection: 'row', gap: 12, marginTop: 4 },
  metaChip: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: 12, color: colors.textTertiary },
  cardAction: {
    width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primarySurface,
    justifyContent: 'center', alignItems: 'center',
  },

  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 40 },
  emptyIconWrap: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: colors.bgElevated,
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
  },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 6 },
  emptyDesc: { fontSize: 14, color: colors.textSecondary, textAlign: 'center', lineHeight: 20 },

  modalOverlay: { flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: 24 },
  modal: { backgroundColor: colors.bgCard, borderRadius: 20, padding: 24, borderWidth: 1, borderColor: colors.border },
  modalTitle: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 20, textAlign: 'center' },
  modalInput: {
    backgroundColor: colors.bgInput, borderRadius: 12, padding: 14, fontSize: 15,
    color: colors.text, borderWidth: 1, borderColor: colors.border, marginBottom: 20,
  },
  modalBtns: { flexDirection: 'row', gap: 10 },
  modalBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  modalBtnCancel: { backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border },
  modalBtnConfirm: { backgroundColor: colors.primary },
  modalBtnCancelText: { color: colors.textSecondary, fontSize: 15, fontWeight: '600' },
  modalBtnConfirmText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});

export default ProjectsScreen;
