import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute, isAvailable } from '../utils/shellExecutor';
import { PROJECTS_ROOT, getProjectDir, packageSegment, slugifyProject } from '../config/runtime';
import { createDefaultProject, createDefaultScreen } from '../utils/defaultProject';
import { raiNew } from '../utils/rai';
import { ensureProjectIntegrity } from '../utils/composeProject';
import AdsBanner from '../components/AdsBanner';

const ProjectsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, t, language } = useAppSettings();
  const { projects, deleteProject, openProject, importProject, isLoaded } = useProject();
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [packageName, setPackageName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createLog, setCreateLog] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1180 ? 3 : width >= 720 ? 2 : 1;

  const copy = language === 'ru' ? {
    recent: 'React-проекты',
    empty: 'Создайте мобильное приложение на React + Vite + Android .',
    command: 'Структура проекта', longPress: 'Удерживайте карточку, чтобы удалить проект.',
    deleteTitle: 'Удалить проект?', deleteText: 'Метаданные будут удалены из конструктора. Файлы проекта останутся в /root/projects.',
    createFailed: 'Не удалось создать React проект', nativeRequired: 'Создание файлов требует доступ к /root/projects (Ubuntu/).',
    preparing: 'Создаём Vite + React проект', creating: 'Генерация React-приложения', package: 'Application ID',
  } : {
    recent: 'React projects', empty: 'Create a mobile app with React + Vite + Android .',
    command: 'Project structure', longPress: 'Long-press a card to delete it.', deleteTitle: 'Delete project?',
    deleteText: 'Metadata will be removed. Files remain in /root/projects.',
    createFailed: 'Could not create React project', nativeRequired: 'File generation requires /root/projects access.',
    preparing: 'Creating Vite + React project', creating: 'Generating React app', package: 'Application ID',
  };

  const filtered = projects.filter((project) => project.name.toLowerCase().includes(search.trim().toLowerCase()));
  const slug = slugifyProject(name);
  const suggestedPackage = packageName || `com.rnstudio.${packageSegment(slug)}`;

  const open = (project) => {
    openProject(project);
    navigation.navigate('Editor');
    const dir = getProjectDir(project);
    // Самолечение проекта при открытии (фон): восстановить отсутствующие файлы
    // шаблона (прерванное создание, случайное удаление) — пользователь ничего
    // не замечает; затем доустановить зависимости, если node_modules нет.
    (async () => {
      try { await ensureProjectIntegrity(project); } catch (e) {}
      execute('[ -f "' + dir + '/node_modules/.bin/vite" ] || (echo "install for open..."; cd "' + dir + '" && npm install --silent --no-audit --no-fund 2>&1 | tail -10; echo OPEN_YARN_OK)', '/').catch(()=>{});
    })();
  };
  const askDelete = (project) => Alert.alert(copy.deleteTitle, copy.deleteText, [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: async () => { await deleteProject(project.id); } },
  ]);

  const create = async () => {
    const cleanName = name.trim();
    if (!cleanName || creating) return;
    // Защита от повторного создания: второй проект с тем же именем затёр бы файлы первого.
    if (projects.some((p) => (p.slug || slugifyProject(p.name)) === slug)) {
      Alert.alert(
        language === 'ru' ? 'Имя занято' : 'Name taken',
        language === 'ru'
          ? `Проект «${cleanName}» уже существует. Выберите другое имя — иначе файлы существующего проекта были бы перезаписаны.`
          : `A project named "${cleanName}" already exists. Pick another name — otherwise the existing project's files would be overwritten.`,
      );
      return;
    }
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(suggestedPackage)) {
      Alert.alert('Application ID', 'Example: com.company.application');
      return;
    }
    // On device without termux, we still allow creation — project lives in AsyncStorage
    setCreating(true);
    setCreateLog(copy.preparing);
    try {
      const project = createDefaultProject({
        name: cleanName,
        slug,
        packageName: suggestedPackage,
        namespace: suggestedPackage,
        projectDir: `${PROJECTS_ROOT}/${slug}`,
        screens: [createDefaultScreen(null, 'Home')],
      });
      // Try to create files on disk (best effort)
      if (isAvailable()) {
        const raiResult = await raiNew(cleanName, suggestedPackage);
        if (!raiResult?.success) {
          // still import project even if disk write failed — user can edit in-memory
          setCreateLog(prev => prev + '\n  ⚠ ' + (raiResult?.output||'').slice(0,300));
        } else {
          setCreateLog(prev => prev + '\n  ✓ Vite project created: ' + project.projectDir);
        }
      } else {
        setCreateLog(prev => prev + '\n  ✓ Project created (in-memory, no shell). Will be written on first save/build.');
      }
      // Сначала пишем файлы, потом ставим зависимости синхронно чтобы лог был виден
      setCreateLog(prev => prev + '\n  → npm install (1-2 мин, для vite)...');
      let yarnOk = false;
      if (isAvailable()) {
        const projDir = `${PROJECTS_ROOT}/${slug}`;
        try {
          const r = await execute('cd "' + projDir + '" && npm install --silent --no-audit --no-fund 2>&1 | tail -30; echo EXIT:$?', projDir);
          setCreateLog(prev => prev + '\n' + String(r.output||'').slice(0,900));
          yarnOk = /EXIT:0/.test(r.output||'');
          if (yarnOk) {
            setCreateLog(prev => prev + '\n  ✓ node_modules готов — vite запустится в редакторе (Дизайн / Превью)');
          } else {
            // Повторная попытка (была сетевая ошибка?) — затем фоновая доустановка при открытии.
            const r2 = await execute('cd "' + projDir + '" && npm install --silent --no-audit --no-fund 2>&1 | tail -15; echo EXIT:$?', projDir);
            yarnOk = /EXIT:0/.test(r2.output||'');
            setCreateLog(prev => prev + (yarnOk
              ? '\n  ✓ node_modules готов (установлен со второй попытки)'
              : '\n  ⚠ npm install не завершился — проверьте сеть; при открытии проекта установка продолжится автоматически'));
          }
        } catch(e) {
          setCreateLog(prev => prev + '\n  ⚠ npm install error: ' + String(e).slice(0,300));
        }
        // Проверка целостности: все файлы шаблона на диске (иначе восстановим).
        try {
          const integ = await ensureProjectIntegrity(project);
          setCreateLog(prev => prev + (integ?.restored?.length
            ? `\n  ✓ восстановлены недостающие файлы: ${integ.restored.length} шт.`
            : '\n  ✓ проверка файлов проекта пройдена'));
        } catch(e) {}
      } else {
        setCreateLog(prev => prev + '\n  ✓ Project created (без shell — npm install при первой сборке)');
      }
      importProject(project);
      // Даём увидеть лог 1.5 сек перед переходом
      await new Promise(res=>setTimeout(res, 1500));
      setName(''); setPackageName('');
      // Не очищаем лог — оставляем для отладки, Editor покажет
      setCreateOpen(false);
      navigation.navigate('Editor');
    } catch (error) {
      const message = error?.message || String(error);
      setCreateLog(message);
      Alert.alert(copy.createFailed, message.slice(0, 1400));
    } finally { setCreating(false); }
  };

  const renderProject = ({ item }) => {
    const updated = new Date(item.updatedAt || item.createdAt);
    return (
      <Pressable onPress={() => open(item)} onLongPress={() => askDelete(item)} style={({ pressed }) => [styles.card, pressed && { borderColor: colors.primary }]}>
        <View style={styles.cardTop}>
          <View style={styles.projectIcon}><Icon name="logo-react" size={24} color={colors.primary} /></View>
          <View style={{ flex: 1, minWidth: 0 }}><Text style={styles.projectName} numberOfLines={1}>{item.name}</Text><Text style={styles.path} numberOfLines={1}>{getProjectDir(item)}</Text></View>
          <Icon name="chevron-forward" size={18} color={colors.textTertiary} />
        </View>
        <View style={styles.metaRow}>
          <StatusPill label="React + Vite" tone="success" />
          <StatusPill label="android" tone="info" />
          <View style={styles.meta}><Icon name="layers-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{item.screens?.length || 0}</Text></View>
          <View style={styles.meta}><Icon name="time-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{updated.toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US')}</Text></View>
        </View>
      </Pressable>
    );
  };

  if (!isLoaded) return <AppScreen style={styles.center}><View style={styles.brand}><Icon name="logo-react" size={26} color="#FFFFFF" /></View><Text style={styles.muted}>{t('loading')}</Text></AppScreen>;

  return (
    <AppScreen>
      <View style={styles.header}>
        <View style={styles.brand}><Icon name="logo-react" size={25} color="#FFFFFF" /></View>
        <View style={{ flex: 1, minWidth: 0 }}><Text style={styles.title}>NovaCompose Studio</Text>{width >= 520 ? <Text style={styles.subtitle}>React + Vite · конструктор Android-приложений</Text> : null}</View>
        <View style={styles.actions}>{/* ВРЕМЕННО: терминал только в debug/dev-сборке. В релизе (__DEV__ === false) кнопка скрыта — чтобы не путать пользователей и избежать лишних жалоб; вернуть можно позже или вынести тумблером в настройки. */}{__DEV__ ? <IconButton name="terminal-outline" onPress={() => navigation.navigate('Terminal')} /> : null}<IconButton name="settings-outline" onPress={() => navigation.navigate('AppSettings')} /><PrimaryButton title={width >= 520 ? t('newProject') : ''} icon="add" onPress={() => setCreateOpen(true)} style={width < 520 ? { width: 46, paddingHorizontal: 0 } : null} /></View>
      </View>
      <View style={styles.searchWrap}><Icon name="search-outline" size={18} color={colors.textTertiary} /><Field value={search} onChangeText={setSearch} placeholder={t('searchProjects')} style={{ flex: 1 }} />{search ? <IconButton name="close" onPress={() => setSearch('')} style={{ borderWidth: 0, backgroundColor: colors.bg }} /> : null}</View>
      {filtered.length ? (
        <FlatList key={columns} numColumns={columns} data={filtered} keyExtractor={(item) => item.id} renderItem={renderProject} columnWrapperStyle={columns > 1 ? styles.gridRow : undefined} contentContainerStyle={styles.list} ListHeaderComponent={<View style={styles.listHeader}><Text style={styles.sectionTitle}>{copy.recent}</Text><Text style={styles.hint}>{copy.longPress}</Text></View>} />
      ) : (
        <View style={styles.empty}><View style={styles.emptyIcon}><Icon name="logo-react" size={40} color={colors.primary} /></View><Text style={styles.emptyTitle}>{t('noProjects')}</Text><Text style={styles.emptyText}>{copy.empty}</Text><PrimaryButton title={t('createProject')} icon="add" onPress={() => setCreateOpen(true)} style={{ marginTop: 8 }} /></View>
      )}
      <Modal visible={createOpen} transparent animationType="fade" onRequestClose={() => !creating && setCreateOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.dialog} title={t('newProject')} icon="logo-react">
            <Field label={t('projectName')} value={name} onChangeText={(value) => { setName(value); if (!packageName) setPackageName(''); }} autoFocus={!creating} editable={!creating} />
            <Field label={copy.package} value={suggestedPackage} onChangeText={setPackageName} autoCapitalize="none" editable={!creating} />
            <View style={styles.commandBox}><Text style={styles.commandLabel}>{copy.command}</Text><Text selectable style={styles.command}>{`${PROJECTS_ROOT}/${slug}/\n├── package.json\n├── vite.config.js\n├── index.html\n├── src/\n│   ├── App.jsx\n│   ├── main.jsx\n│   └── screens/Home.jsx\n└── android/app/src/main/java/.../MainActivity.kt (нативная оболочка)`}</Text></View>
            {createLog ? <View style={styles.logBox}><Text selectable style={styles.logText}>{createLog}</Text></View> : null}
            <View style={styles.dialogButtons}><IconButton name="close" label={t('cancel')} disabled={creating} onPress={() => { setCreateOpen(false); setName(''); setPackageName(''); setCreateLog(''); }} style={{ flex: 1 }} /><PrimaryButton title={t('createProject')} icon="arrow-forward" loading={creating} disabled={!name.trim()} onPress={create} style={{ flex: 1 }} /></View>
          </SectionCard>
        </View>
      </Modal>
      <AdsBanner />
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center', gap: 12 },
  header: { minHeight: 76, paddingHorizontal: 18, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  brand: { width: 44, height: 44, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary },
  title: { color: c.text, fontSize: 19, fontWeight: '800' }, subtitle: { color: c.textSecondary, fontSize: 11, marginTop: 2 }, actions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  searchWrap: { width: '100%', maxWidth: 1180, alignSelf: 'center', paddingHorizontal: 16, paddingTop: 16, flexDirection: 'row', alignItems: 'center', gap: 9 },
  list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 16, paddingTop: 10, paddingBottom: 40 }, listHeader: { marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between' }, sectionTitle: { color: c.text, fontSize: 15, fontWeight: '750' }, hint: { color: c.textTertiary, fontSize: 10 }, gridRow: { gap: 12 },
  card: { flex: 1, minWidth: 0, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 15, marginBottom: 12 }, cardTop: { flexDirection: 'row', alignItems: 'center', gap: 11 }, projectIcon: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: c.primarySurface }, projectName: { color: c.text, fontSize: 15, fontWeight: '750' }, path: { color: c.textTertiary, fontSize: 9, fontFamily: 'monospace', marginTop: 4 }, metaRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: c.border }, meta: { flexDirection: 'row', alignItems: 'center', gap: 4 }, metaText: { color: c.textSecondary, fontSize: 10 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 }, emptyIcon: { width: 76, height: 76, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface, marginBottom: 16 }, emptyTitle: { color: c.text, fontSize: 20, fontWeight: '750' }, emptyText: { color: c.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 430, marginTop: 7 }, muted: { color: c.textSecondary },
  overlay: { flex: 1, justifyContent: 'center', padding: 18, backgroundColor: c.overlay }, dialog: { width: '100%', maxWidth: 560, alignSelf: 'center', padding: 20 }, commandBox: { borderRadius: 9, padding: 12, backgroundColor: c.terminal }, commandLabel: { color: '#8B98AD', fontSize: 10, marginBottom: 6 }, command: { color: '#DCE5F3', fontSize: 10, lineHeight: 16, fontFamily: 'monospace' }, logBox: { maxHeight: 130, borderRadius: 9, padding: 11, backgroundColor: c.bgElevated }, logText: { color: c.textSecondary, fontFamily: 'monospace', fontSize: 10 }, dialogButtons: { flexDirection: 'row', gap: 9 },
});

export default ProjectsScreen;