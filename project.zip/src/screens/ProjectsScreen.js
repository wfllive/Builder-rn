import React, { useMemo, useState } from 'react';
import {
  Alert, FlatList, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions,
} from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { checkCommand, execute, getNodeVersion, installNode, isAvailable } from '../utils/shellExecutor';
import { EXPO_TEMPLATE, PROJECTS_ROOT, getProjectDir, slugifyProject } from '../config/runtime';

const ProjectsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, t, language } = useAppSettings();
  const { projects, createProject, deleteProject, openProject, isLoaded } = useProject();
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createLog, setCreateLog] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1180 ? 3 : width >= 720 ? 2 : 1;

  const copy = language === 'ru' ? {
    recent: 'Рабочие проекты',
    empty: 'Создайте новый проект на свежем шаблоне Expo Router SDK 57.',
    command: 'Будет выполнена команда',
    longPress: 'Удерживайте карточку, чтобы удалить проект.',
    deleteTitle: 'Удалить проект?',
    deleteText: 'Метаданные проекта будут удалены из конструктора. Файлы Ubuntu останутся на диске.',
    createFailed: 'Не удалось создать Expo проект',
    nativeRequired: 'Создание проекта доступно только в development client после установки Ubuntu.',
    preparing: 'Проверка Node.js и Yarn',
    creating: 'Создание Expo Router проекта',
    open: 'Открыть редактор',
  } : {
    recent: 'Workspace projects',
    empty: 'Create a project from the current Expo Router SDK 57 template.',
    command: 'Command to be executed',
    longPress: 'Long-press a card to delete a project.',
    deleteTitle: 'Delete project?',
    deleteText: 'The project metadata will be removed from the builder. Ubuntu files remain on disk.',
    createFailed: 'Could not create the Expo project',
    nativeRequired: 'Project creation requires the development client and an installed Ubuntu workspace.',
    preparing: 'Checking Node.js and Yarn',
    creating: 'Creating Expo Router project',
    open: 'Open editor',
  };

  const filtered = projects.filter((project) => project.name.toLowerCase().includes(search.trim().toLowerCase()));
  const slug = slugifyProject(name);
  const command = `yarn create expo-app ${slug} --template ${EXPO_TEMPLATE} --yes`;

  const open = (project) => {
    openProject(project);
    navigation.navigate('Editor');
  };

  const askDelete = (project) => Alert.alert(copy.deleteTitle, copy.deleteText, [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: () => deleteProject(project.id) },
  ]);

  const create = async () => {
    const cleanName = name.trim();
    if (!cleanName || creating) return;
    if (!isAvailable()) {
      Alert.alert(copy.createFailed, copy.nativeRequired);
      return;
    }
    setCreating(true);
    setCreateLog(copy.preparing);
    try {
      let node = await getNodeVersion();
      if (!node?.version) {
        const installed = await installNode();
        if (!installed?.success) throw new Error(installed?.output || 'Node.js installation failed');
        node = await getNodeVersion();
      }
      setCreateLog(`${copy.preparing}\nNode.js ${node.version || ''}`);
      let yarn = await checkCommand('yarn');
      if (!yarn?.exists) {
        const installYarn = await execute('npm install --global yarn 2>&1');
        if (!installYarn.success) throw new Error(installYarn.output || 'Yarn installation failed');
        yarn = await checkCommand('yarn');
      }
      setCreateLog(`${copy.creating}\n$ ${command}`);
      await execute(`mkdir -p "${PROJECTS_ROOT}"`);
      const result = await execute(`CI=1 ${command} 2>&1`, PROJECTS_ROOT);
      if (!result?.success) throw new Error(result?.output || copy.createFailed);

      const projectDir = `${PROJECTS_ROOT}/${slug}`;
      let dependencies = {};
      let devDependencies = {};
      try {
        const packageResult = await execute('cat package.json', projectDir);
        const packageJson = JSON.parse(packageResult.output);
        dependencies = packageJson.dependencies || {};
        devDependencies = packageJson.devDependencies || {};
      } catch (e) {}

      createProject(cleanName, {
        slug,
        projectDir,
        sdkVersion: '57.0.0',
        expoVersion: dependencies.expo || '~57.0.6',
        createdWith: command,
        dependencies,
        devDependencies,
      });
      setName('');
      setCreateOpen(false);
      setCreateLog('');
      navigation.navigate('Editor');
    } catch (e) {
      const message = e?.message || String(e);
      setCreateLog(message);
      Alert.alert(copy.createFailed, message.slice(0, 1400));
    } finally {
      setCreating(false);
    }
  };

  const renderProject = ({ item }) => {
    const updated = new Date(item.updatedAt || item.createdAt);
    const locale = language === 'ru' ? 'ru-RU' : 'en-US';
    return (
      <Pressable
        onPress={() => open(item)}
        onLongPress={() => askDelete(item)}
        style={({ pressed }) => [styles.card, pressed && { borderColor: colors.primary, transform: [{ scale: 0.995 }] }]}
      >
        <View style={styles.cardTop}>
          <View style={styles.projectIcon}><Icon name="apps-outline" size={24} color={colors.primary} /></View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text style={styles.projectName} numberOfLines={1}>{item.name}</Text>
            <Text style={styles.path} numberOfLines={1}>{getProjectDir(item)}</Text>
          </View>
          <Icon name="chevron-forward" size={18} color={colors.textTertiary} />
        </View>
        <View style={styles.metaRow}>
          <StatusPill label={`SDK ${String(item.sdkVersion || '57').split('.')[0]}`} tone="info" />
          <View style={styles.meta}><Icon name="layers-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{item.screens?.length || 0}</Text></View>
          <View style={styles.meta}><Icon name="time-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{updated.toLocaleDateString(locale, { day: '2-digit', month: 'short' })}</Text></View>
        </View>
      </Pressable>
    );
  };

  if (!isLoaded) {
    return <AppScreen style={styles.center}><View style={styles.brand}><Icon name="construct-outline" size={26} color="#FFFFFF" /></View><Text style={styles.muted}>{t('loading')}</Text></AppScreen>;
  }

  return (
    <AppScreen>
      <View style={styles.header}>
        <View style={styles.brand}><Icon name="construct-outline" size={24} color="#FFFFFF" /></View>
        <View style={{ flex: 1, minWidth: 0 }}>
          <Text style={styles.title}>{t('appName')}</Text>
          {width >= 520 ? <Text style={styles.subtitle}>{t('appSubtitle')}</Text> : null}
        </View>
        <View style={styles.actions}>
          <IconButton name="terminal-outline" onPress={() => navigation.navigate('Terminal')} />
          <IconButton name="settings-outline" onPress={() => navigation.navigate('AppSettings')} />
          <PrimaryButton title={width >= 520 ? t('newProject') : ''} icon="add" onPress={() => setCreateOpen(true)} style={width < 520 ? { width: 46, paddingHorizontal: 0 } : null} />
        </View>
      </View>

      <View style={styles.searchWrap}>
        <Icon name="search-outline" size={18} color={colors.textTertiary} />
        <Field
          value={search}
          onChangeText={setSearch}
          placeholder={t('searchProjects')}
          style={{ flex: 1 }}
        />
        {search ? <IconButton name="close" onPress={() => setSearch('')} style={{ borderWidth: 0, backgroundColor: colors.bg }} /> : null}
      </View>

      {filtered.length ? (
        <FlatList
          key={columns}
          numColumns={columns}
          data={filtered}
          keyExtractor={(item) => item.id}
          renderItem={renderProject}
          columnWrapperStyle={columns > 1 ? styles.gridRow : undefined}
          contentContainerStyle={styles.list}
          ListHeaderComponent={<View style={styles.listHeader}><Text style={styles.sectionTitle}>{copy.recent}</Text><Text style={styles.hint}>{copy.longPress}</Text></View>}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.empty}>
          <View style={styles.emptyIcon}><Icon name="folder-open-outline" size={38} color={colors.primary} /></View>
          <Text style={styles.emptyTitle}>{t('noProjects')}</Text>
          <Text style={styles.emptyText}>{search ? t('searchProjects') : copy.empty}</Text>
          {!search ? <PrimaryButton title={t('createProject')} icon="add" onPress={() => setCreateOpen(true)} style={{ marginTop: 8 }} /> : null}
        </View>
      )}

      <Modal visible={createOpen} transparent animationType="fade" onRequestClose={() => !creating && setCreateOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.dialog} title={t('newProject')} icon="add-circle-outline">
            <Field label={t('projectName')} value={name} onChangeText={setName} autoFocus={!creating} editable={!creating} onSubmitEditing={create} />
            <View style={styles.commandBox}>
              <Text style={styles.commandLabel}>{copy.command}</Text>
              <Text selectable style={styles.command}>$ {command}</Text>
            </View>
            {createLog ? <View style={styles.logBox}><Text selectable style={styles.logText}>{createLog}</Text></View> : null}
            <View style={styles.dialogButtons}>
              <IconButton name="close" label={t('cancel')} disabled={creating} onPress={() => { setCreateOpen(false); setName(''); setCreateLog(''); }} style={{ flex: 1 }} />
              <PrimaryButton title={t('createProject')} icon="arrow-forward" loading={creating} disabled={!name.trim()} onPress={create} style={{ flex: 1 }} />
            </View>
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center', gap: 12 },
  header: { minHeight: 76, paddingHorizontal: 18, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  brand: { width: 44, height: 44, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary },
  title: { color: c.text, fontSize: 19, fontWeight: '800', letterSpacing: -0.3 },
  subtitle: { color: c.textSecondary, fontSize: 11, marginTop: 2 },
  actions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  searchWrap: { width: '100%', maxWidth: 1180, alignSelf: 'center', paddingHorizontal: 16, paddingTop: 16, flexDirection: 'row', alignItems: 'center', gap: 9 },
  list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 16, paddingTop: 10, paddingBottom: 40 },
  listHeader: { marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', gap: 12 },
  sectionTitle: { color: c.text, fontSize: 15, fontWeight: '750' },
  hint: { color: c.textTertiary, fontSize: 10 },
  gridRow: { gap: 12 },
  card: { flex: 1, minWidth: 0, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 15, marginBottom: 12 },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  projectIcon: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: c.primarySurface },
  projectName: { color: c.text, fontSize: 15, fontWeight: '750' },
  path: { color: c.textTertiary, fontSize: 10, fontFamily: 'monospace', marginTop: 4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: c.border },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { color: c.textSecondary, fontSize: 11 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  emptyIcon: { width: 76, height: 76, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface, marginBottom: 16 },
  emptyTitle: { color: c.text, fontSize: 20, fontWeight: '750' },
  emptyText: { color: c.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 390, marginTop: 7, marginBottom: 10 },
  muted: { color: c.textSecondary, fontSize: 13 },
  overlay: { flex: 1, justifyContent: 'center', padding: 18, backgroundColor: c.overlay },
  dialog: { width: '100%', maxWidth: 540, alignSelf: 'center', padding: 20 },
  commandBox: { borderRadius: 9, padding: 12, backgroundColor: c.terminal },
  commandLabel: { color: '#8B98AD', fontSize: 10, marginBottom: 6 },
  command: { color: '#DCE5F3', fontSize: 11, lineHeight: 17, fontFamily: 'monospace' },
  logBox: { maxHeight: 130, borderRadius: 9, padding: 11, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  logText: { color: c.textSecondary, fontFamily: 'monospace', fontSize: 10, lineHeight: 15 },
  dialogButtons: { flexDirection: 'row', gap: 9 },
});

export default ProjectsScreen;
