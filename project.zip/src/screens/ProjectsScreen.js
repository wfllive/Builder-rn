import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, Field, IconButton, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute, isAvailable } from '../utils/shellExecutor';
import { PROJECTS_ROOT, getProjectDir, packageSegment, slugifyProject } from '../config/runtime';
import { createDefaultProject } from '../utils/defaultProject';
import { raiNew } from '../utils/rai';
import { loadRaiActivities } from '../utils/activityTree';
import { generateBlocksFromSource } from '../utils/blockGenerator';
import { parseActivitySource } from '../utils/activityTree';

const ProjectsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { colors, t, language } = useAppSettings();
  const { projects, deleteProject, openProject, importProject, isLoaded } = useProject();
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [packageName, setPackageName] = useState('');
  const [creating, setCreating] = useState(false);
  const [createLog, setCreateLog] = useState('');
  const styles = useMemo(() => createStyles(colors), [colors]);
  const columns = width >= 1180 ? 3 : width >= 720 ? 2 : 1;

  const copy = language === 'ru' ? {
    recent: 'Android-проекты',
    empty: 'Создайте нативное Android-приложение на Kotlin и Jetpack Compose Material 3.',
    command: 'Структура проекта', longPress: 'Удерживайте карточку, чтобы удалить проект.',
    deleteTitle: 'Удалить проект?', deleteText: 'Метаданные будут удалены из конструктора. Файлы Gradle-проекта останутся в Ubuntu.',
    createFailed: 'Не удалось создать Compose-проект', nativeRequired: 'Создание файлов требует development-сборку Compose Studio с Ubuntu.',
    preparing: 'Создаём Gradle Kotlin DSL и исходники Compose', creating: 'Генерация Android-проекта', package: 'Application ID',
  } : {
    recent: 'Android projects', empty: 'Create a native Android application with Kotlin, Jetpack Compose and Material 3.',
    command: 'Project structure', longPress: 'Long-press a card to delete it.', deleteTitle: 'Delete project?',
    deleteText: 'Metadata will be removed from the builder. Gradle project files remain in Ubuntu.',
    createFailed: 'Could not create the Compose project', nativeRequired: 'File generation requires the Compose Studio development build with Ubuntu.',
    preparing: 'Creating Gradle Kotlin DSL and Compose sources', creating: 'Generating Android project', package: 'Application ID',
  };

  const filtered = projects.filter((project) => project.name.toLowerCase().includes(search.trim().toLowerCase()));
  const slug = slugifyProject(name);
  const suggestedPackage = packageName || `com.rnstudio.${packageSegment(slug)}`;

  const open = (project) => { openProject(project); navigation.navigate('Editor'); };
  const askDelete = (project) => Alert.alert(copy.deleteTitle, copy.deleteText, [
    { text: t('cancel'), style: 'cancel' },
    { text: t('delete'), style: 'destructive', onPress: async () => { await deleteProject(project.id); } },
  ]);

  const create = async () => {
    const cleanName = name.trim();
    if (!cleanName || creating) return;
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(suggestedPackage)) {
      Alert.alert('Application ID', 'Example: com.company.application');
      return;
    }
    if (!isAvailable()) { Alert.alert(copy.createFailed, copy.nativeRequired); return; }
    setCreating(true);
    setCreateLog(copy.preparing);
    try {
      // rai new ALWAYS runs with --modern so the project lands on
      // the same template the editor knows how to edit. Without
      // --modern rai falls back to a different counter-style
      // template and the editor would not find a MainScreen()
      // composable to splice the user's design into.
      const project = createDefaultProject({
        name: cleanName,
        slug,
        packageName: suggestedPackage,
        namespace: suggestedPackage,
        projectDir: `${PROJECTS_ROOT}/${cleanName}`,
        screens: [],
      });
      const raiResult = await raiNew(cleanName, suggestedPackage);
      if (!raiResult?.success) throw new Error(raiResult?.output || 'rai new failed');
      setCreateLog(copy.preparing + '\n  ✓ rai new --modern ' + cleanName);

      // Pull the *Activity.kt files rai just created into the
      // editor's JSON model so the user opens a real MainActivity
      // with counter + ABI card + buttons, not an empty column.
      const activities = await loadRaiActivities(project);
      if (activities.length) {
        project.screens = activities.map((a) => ({
          id: a.id,
          name: a.name,
          fileName: a.fileName,
          rootComponent: a.rootComponent,
          blocks: (a.blocks && a.blocks.length > 0) ? a.blocks : (a.source ? generateBlocksFromSource(parseActivitySource(a.source).body) : []),
          readOnly: a.readOnly === true,
          hasUserFunction: a.hasUserFunction === true,
          rootName: a.rootName || null,
          preamble: a.preamble || [],
          source: a.source || null,
        }));
        setCreateLog(createLog + `\n  ✓ Hydrated ${activities.length} *Activity.kt files`);
      } else {
        setCreateLog(createLog + '\n  ! rai new did not produce any *Activity.kt files');
      }

      importProject(project);
      setName(''); setPackageName(''); setCreateOpen(false); setCreateLog('');
      navigation.navigate('Editor');
    } catch (error) {
      const message = error?.message || String(error);
      setCreateLog(message);
      Alert.alert(copy.createFailed, message.slice(0, 1400));
    } finally { setCreating(false); }
  };

  const renderProject = ({ item }) => {
    const updated = new Date(item.updatedAt || item.createdAt);
    return (
      <Pressable onPress={() => open(item)} onLongPress={() => askDelete(item)} style={({ pressed }) => [styles.card, pressed && { borderColor: colors.primary }]}>
        <View style={styles.cardTop}>
          <View style={styles.projectIcon}><Icon name="logo-android" size={24} color={colors.primary} /></View>
          <View style={{ flex: 1, minWidth: 0 }}><Text style={styles.projectName} numberOfLines={1}>{item.name}</Text><Text style={styles.path} numberOfLines={1}>{getProjectDir(item)}</Text></View>
          <Icon name="chevron-forward" size={18} color={colors.textTertiary} />
        </View>
        <View style={styles.metaRow}>
          <StatusPill label="Jetpack Compose" tone="success" />
          <StatusPill label={`API ${item.targetSdk || 36}`} tone="info" />
          <View style={styles.meta}><Icon name="layers-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{item.screens?.length || 0}</Text></View>
          <View style={styles.meta}><Icon name="time-outline" size={13} color={colors.textTertiary} /><Text style={styles.metaText}>{updated.toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US')}</Text></View>
        </View>
      </Pressable>
    );
  };

  if (!isLoaded) return <AppScreen style={styles.center}><View style={styles.brand}><Icon name="logo-android" size={26} color="#FFFFFF" /></View><Text style={styles.muted}>{t('loading')}</Text></AppScreen>;

  return (
    <AppScreen>
      <View style={styles.header}>
        <View style={styles.brand}><Icon name="logo-android" size={25} color="#FFFFFF" /></View>
        <View style={{ flex: 1, minWidth: 0 }}><Text style={styles.title}>Compose Studio</Text>{width >= 520 ? <Text style={styles.subtitle}>Visual Jetpack Compose Builder</Text> : null}</View>
        <View style={styles.actions}><IconButton name="terminal-outline" onPress={() => navigation.navigate('Terminal')} /><IconButton name="settings-outline" onPress={() => navigation.navigate('AppSettings')} /><PrimaryButton title={width >= 520 ? t('newProject') : ''} icon="add" onPress={() => setCreateOpen(true)} style={width < 520 ? { width: 46, paddingHorizontal: 0 } : null} /></View>
      </View>
      <View style={styles.searchWrap}><Icon name="search-outline" size={18} color={colors.textTertiary} /><Field value={search} onChangeText={setSearch} placeholder={t('searchProjects')} style={{ flex: 1 }} />{search ? <IconButton name="close" onPress={() => setSearch('')} style={{ borderWidth: 0, backgroundColor: colors.bg }} /> : null}</View>
      {filtered.length ? (
        <FlatList key={columns} numColumns={columns} data={filtered} keyExtractor={(item) => item.id} renderItem={renderProject} columnWrapperStyle={columns > 1 ? styles.gridRow : undefined} contentContainerStyle={styles.list} ListHeaderComponent={<View style={styles.listHeader}><Text style={styles.sectionTitle}>{copy.recent}</Text><Text style={styles.hint}>{copy.longPress}</Text></View>} />
      ) : (
        <View style={styles.empty}><View style={styles.emptyIcon}><Icon name="logo-android" size={40} color={colors.primary} /></View><Text style={styles.emptyTitle}>{t('noProjects')}</Text><Text style={styles.emptyText}>{copy.empty}</Text><PrimaryButton title={t('createProject')} icon="add" onPress={() => setCreateOpen(true)} style={{ marginTop: 8 }} /></View>
      )}
      <Modal visible={createOpen} transparent animationType="fade" onRequestClose={() => !creating && setCreateOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.dialog} title={t('newProject')} icon="logo-android">
            <Field label={t('projectName')} value={name} onChangeText={(value) => { setName(value); if (!packageName) setPackageName(''); }} autoFocus={!creating} editable={!creating} />
            <Field label={copy.package} value={suggestedPackage} onChangeText={setPackageName} autoCapitalize="none" editable={!creating} />
            <View style={styles.commandBox}><Text style={styles.commandLabel}>{copy.command}</Text><Text selectable style={styles.command}>{`${PROJECTS_ROOT}/${slug}/\n├── app/build.gradle.kts\n├── app/src/main/.../MainActivity.kt\n├── app/src/main/.../AuthActivity.kt\n└── gradlew assembleDebug`}</Text></View>
            {createLog ? <View style={styles.logBox}><Text selectable style={styles.logText}>{createLog}</Text></View> : null}
            <View style={styles.dialogButtons}><IconButton name="close" label={t('cancel')} disabled={creating} onPress={() => { setCreateOpen(false); setName(''); setPackageName(''); setCreateLog(''); }} style={{ flex: 1 }} /><PrimaryButton title={t('createProject')} icon="arrow-forward" loading={creating} disabled={!name.trim()} onPress={create} style={{ flex: 1 }} /></View>
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center', gap: 12 },
  header: { minHeight: 76, paddingHorizontal: 18, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  brand: { width: 44, height: 44, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary },
  title: { color: c.text, fontSize: 19, fontWeight: '800' }, subtitle: { color: c.textSecondary, fontSize: 11, marginTop: 2 }, actions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  searchWrap: { width: '100%', maxWidth: 1180, alignSelf: 'center', paddingHorizontal: 16, paddingTop: 16, flexDirection: 'row', alignItems: 'center', gap: 9 },
  list: { width: '100%', maxWidth: 1180, alignSelf: 'center', padding: 16, paddingTop: 10, paddingBottom: 40 }, listHeader: { marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between' }, sectionTitle: { color: c.text, fontSize: 15, fontWeight: '750' }, hint: { color: c.textTertiary, fontSize: 10 }, gridRow: { gap: 12 },
  card: { flex: 1, minWidth: 0, backgroundColor: c.bgCard, borderWidth: 1, borderColor: c.border, borderRadius: 14, padding: 15, marginBottom: 12 }, cardTop: { flexDirection: 'row', alignItems: 'center', gap: 11 }, projectIcon: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: c.primarySurface }, projectName: { color: c.text, fontSize: 15, fontWeight: '750' }, path: { color: c.textTertiary, fontSize: 9, fontFamily: 'monospace', marginTop: 4 }, metaRow: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 8, marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: c.border }, meta: { flexDirection: 'row', alignItems: 'center', gap: 4 }, metaText: { color: c.textSecondary, fontSize: 10 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 }, emptyIcon: { width: 76, height: 76, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primarySurface, marginBottom: 16 }, emptyTitle: { color: c.text, fontSize: 20, fontWeight: '750' }, emptyText: { color: c.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 430, marginTop: 7 }, muted: { color: c.textSecondary },
  overlay: { flex: 1, justifyContent: 'center', padding: 18, backgroundColor: c.overlay }, dialog: { width: '100%', maxWidth: 560, alignSelf: 'center', padding: 20 }, commandBox: { borderRadius: 9, padding: 12, backgroundColor: c.terminal }, commandLabel: { color: '#8B98AD', fontSize: 10, marginBottom: 6 }, command: { color: '#DCE5F3', fontSize: 10, lineHeight: 16, fontFamily: 'monospace' }, logBox: { maxHeight: 130, borderRadius: 9, padding: 11, backgroundColor: c.bgElevated }, logText: { color: c.textSecondary, fontFamily: 'monospace', fontSize: 10 }, dialogButtons: { flexDirection: 'row', gap: 9 },
});

export default ProjectsScreen;
