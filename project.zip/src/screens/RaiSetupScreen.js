import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon } from '../components/Icon';
import { AppScreen, PrimaryButton, SectionCard, StatusPill } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { SETUP_STEPS, RAI_VERSION, runRaiSetup } from '../utils/raiSetup';
import {
  startBackground, stopBackground, updateBackground,
  hasStorageAccess, openStorageSettings, requestStoragePermissions,
  hasNotificationPermission, requestNotificationPermission,
} from '../utils/background';

const RaiSetupScreen = ({ onComplete }) => {
  const { colors, language } = useAppSettings();
  const ru = language === 'ru';
  const styles = useMemo(() => createStyles(colors), [colors]);

  const [phase, setPhase] = useState('idle'); // idle | running | done | error
  const [stepStates, setStepStates] = useState({}); // id -> pending|running|done|skipped|error
  const [logs, setLogs] = useState([]);
  const [error, setError] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [storageGranted, setStorageGranted] = useState(false);
  const [notifGranted, setNotifGranted] = useState(true);
  const scrollRef = useRef(null);
  const consoleScrollRef = useRef(null);
  const busyRef = useRef(false);
  const startedAtRef = useRef(0);

  const copy = {
    title: ru ? 'Установка RAI' : 'RAI setup',
    subtitle: ru
      ? 'После Ubuntu: apt → Node.js → локальный RAI (из приложения) → base → SDK → rai status'
      : 'After Ubuntu: apt → Node.js → local RAI (from the app) → base → SDK → rai status',
    stepsTitle: ru ? 'Шаги установки' : 'Setup steps',
    start: ru ? 'Начать установку' : 'Start setup',
    running: ru ? 'Установка идёт…' : 'Installing…',
    retry: ru ? 'Повторить' : 'Retry',
    continueAnyway: ru ? 'Продолжить в проекты' : 'Continue to projects',
    done: ru ? 'Среда готова' : 'Environment is ready',
    doneText: ru
      ? 'Java, Android SDK и RAI установлены. Сейчас откроется список проектов.'
      : 'Java, Android SDK and RAI are installed. Opening the project list.',
    background: ru
      ? 'Установка продолжается в фоне: сверните приложение или заблокируйте экран — служба с уведомлением держит процесс живым. Если приложение закроют, при следующем запуске установка продолжится с того же шага.'
      : 'Setup keeps running in the background: minimize the app or lock the screen — a foreground service keeps the process alive. If the app is closed, setup resumes from the same step on the next launch.',
    storage: ru ? 'Доступ к памяти' : 'Storage access',
    storageText: ru
      ? 'Нужен для сохранения собранных APK в /sdcard/Download и общего доступа к файлам.'
      : 'Needed to save built APKs to /sdcard/Download and share files.',
    storageGrant: ru ? 'Разрешить доступ' : 'Grant access',
    granted: ru ? 'Разрешён' : 'Granted',
    notGranted: ru ? 'Не разрешён' : 'Not granted',
    notif: ru ? 'Уведомления' : 'Notifications',
    notifText: ru ? 'Показывают статус фоновой установки/сборки.' : 'Show background install/build status.',
    notifGrant: ru ? 'Разрешить' : 'Allow',
    notifGranted: ru ? 'Разрешены' : 'Allowed',
    notifDenied: ru ? 'Не разрешены' : 'Not allowed',
    noShell: ru
      ? 'Установка RAI требует нативную development-сборку с Ubuntu. Откройте приложение в нативной сборке.'
      : 'RAI setup requires the native development build with Ubuntu. Open the app in the native build.',
    logTitle: ru ? 'Журнал установки' : 'Setup log',
    errorText: ru
      ? 'Установка не завершилась. Ниже — последние строки журнала. Нажмите «Повторить» — готовые шаги будут пропущены.'
      : 'Setup failed. See the log tail below. Press Retry — finished steps will be skipped.',
  };

  const stepMeta = useMemo(() => {
    const m = {};
    SETUP_STEPS.forEach((s) => { m[s.id] = s; });
    return m;
  }, []);

  const refreshPermissions = useCallback(async () => {
    setStorageGranted(await hasStorageAccess());
    setNotifGranted(await hasNotificationPermission());
  }, []);

  useEffect(() => { refreshPermissions(); }, [refreshPermissions]);

  // Перепроверяем права при возврате из настроек системы (после выдачи разрешения).
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') refreshPermissions();
    });
    return () => sub.remove();
  }, [refreshPermissions]);

  useEffect(() => {
    if (phase !== 'running') return undefined;
    const t = setInterval(() => setElapsed(Math.floor((Date.now() - startedAtRef.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const append = useCallback((text, level = 'normal') => {
    setLogs((v) => [...v, { id: `${Date.now()}-${v.length}-${Math.random().toString(36).slice(2, 6)}`, text, level }]);
  }, []);

  const setStep = useCallback((id, state) => {
    setStepStates((s) => ({ ...s, [id]: state }));
  }, []);

  const run = useCallback(async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setPhase('running');
    setError('');
    setElapsed(0);
    startedAtRef.current = Date.now();
    setLogs([]);
    SETUP_STEPS.forEach((s) => setStep(s.id, 'pending'));
    await startBackground(copy.title);
    await updateBackground(copy.subtitle);

    try {
      const result = await runRaiSetup({
        onStepStart: (id) => setStep(id, 'running'),
        onStepEnd: (id, step, res) => {
          setStep(id, res.status === 'done' ? 'done' : res.status === 'skipped' ? 'skipped' : 'error');
          const label = stepMeta[id]?.title?.ru || id;
          updateBackground(`${copy.title}: ${res.status === 'skipped' ? '✓' : '…'} ${label}`).catch(() => {});
        },
        onLine: (line) => append(line),
      });
      if (result.ok) {
        setPhase('done');
        append('', 'command');
        append('✅ ' + copy.done, 'success');
        await stopBackground();
        setTimeout(onComplete, 900);
      } else {
        const failed = result.summary.find((r) => r.status === 'failed');
        setError(failed ? (stepMeta[failed.id]?.title?.ru || failed.id) : copy.errorText);
        setPhase('error');
        append('', 'command');
        append('❌ ' + copy.errorText, 'error');
      }
    } catch (e) {
      setError(e?.message || String(e));
      setPhase('error');
      append('❌ ' + (e?.message || String(e)), 'error');
    } finally {
      busyRef.current = false;
      if (phase !== 'done') stopBackground().catch(() => {});
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
    }
  }, [append, copy, onComplete, phase, setStep, stepMeta]);

  const grantStorage = async () => {
    const granted = await hasStorageAccess();
    if (!granted) {
      await requestStoragePermissions(); // legacy dialog (API ≤ 32); on 30+ opens nothing
      await openStorageSettings();        // API 30+: All files access settings
    }
    setTimeout(refreshPermissions, 600);
  };

  const grantNotif = async () => {
    const granted = await hasNotificationPermission();
    if (!granted) await requestNotificationPermission();
    setTimeout(refreshPermissions, 600);
  };

  const stepIcon = (state) => {
    switch (state) {
      case 'done': return <Icon name="checkmark-circle" size={17} color={colors.success} />;
      case 'skipped': return <Icon name="checkmark-done-circle-outline" size={17} color={colors.textTertiary} />;
      case 'error': return <Icon name="close-circle" size={17} color={colors.error} />;
      case 'running': return <Icon name="sync" size={15} color={colors.primary} />;
      default: return <View style={[styles.dot, { backgroundColor: colors.border }]} />;
    }
  };
  const stepTone = (state) => (state === 'error' ? 'error' : state === 'done' || state === 'skipped' ? 'success' : 'neutral');

  const logLineStyle = (level) =>
    level === 'command' ? [styles.log, styles.command]
      : level === 'success' ? [styles.log, styles.success]
        : level === 'error' ? [styles.log, styles.error]
          : level === 'warning' ? [styles.log, styles.warning]
            : styles.log;

  return (
    <AppScreen>
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled" ref={scrollRef}>
        <View style={styles.content}>
          <View style={styles.brandMark}><Icon name="terminal-outline" size={30} color="#FFFFFF" /></View>
          <Text style={styles.title}>{copy.title}</Text>
          <Text style={styles.subtitle}>{copy.subtitle}</Text>

          <SectionCard title={copy.stepsTitle} icon="list-outline" style={styles.card}>
            {SETUP_STEPS.map((s) => {
              const state = stepStates[s.id] || 'pending';
              return (
                <View key={s.id} style={styles.stepRow}>
                  {stepIcon(state)}
                  <Text style={[styles.stepText, state === 'error' && { color: colors.error }]} numberOfLines={1}>
                    {s.title[ru ? 'ru' : 'en']}
                  </Text>
                  <StatusPill
                    label={state === 'done' ? (ru ? 'Готово' : 'Done') : state === 'skipped' ? (ru ? 'Пропущен' : 'Skipped') : state === 'running' ? (ru ? 'Идёт' : 'Run') : state === 'error' ? (ru ? 'Ошибка' : 'Error') : ''}
                    tone={stepTone(state)}
                  />
                </View>
              );
            })}
          </SectionCard>

          {phase === 'error' && error ? (
            <View style={styles.errorBox}>
              <Icon name="alert-circle-outline" size={20} color={colors.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          {/* Консоль */}
          <View style={styles.consoleWrap}>
            <View style={styles.consoleHead}>
              <View style={styles.dots}><View style={[styles.dot, { backgroundColor: '#F87171' }]} /><View style={[styles.dot, { backgroundColor: '#FBBF24' }]} /><View style={[styles.dot, { backgroundColor: '#34D399' }]} /></View>
              <Text style={styles.consoleTitle}>{copy.logTitle}</Text>
              <View style={{ flex: 1 }} />
              {phase === 'running' ? <StatusPill label={`${elapsed}s`} tone="info" /> : null}
            </View>
            <ScrollView ref={consoleScrollRef} style={styles.console} contentContainerStyle={styles.consoleContent} onContentSizeChange={() => consoleScrollRef.current?.scrollToEnd({ animated: false })}>
              {!logs.length ? (
                <View style={styles.consoleEmpty}><Icon name="terminal-outline" size={26} color="#526079" /><Text style={styles.consoleEmptyText}>{ru ? 'Журнал появится после запуска' : 'Log will appear after start'}</Text></View>
              ) : logs.map((l) => <Text selectable key={l.id} style={logLineStyle(l.level)}>{l.text || ' '}</Text>)}
            </ScrollView>
          </View>

          {phase === 'done' ? (
            <View style={styles.successBox}>
              <Icon name="checkmark-circle" size={26} color={colors.success} />
              <Text style={styles.successText}>{copy.doneText}</Text>
            </View>
          ) : (
            <PrimaryButton
              title={phase === 'running' ? copy.running : phase === 'error' ? copy.retry : copy.start}
              icon={phase === 'running' ? undefined : 'download-outline'}
              loading={phase === 'running'}
              disabled={phase === 'running'}
              onPress={run}
              style={styles.primaryBtn}
            />
          )}

          <View style={styles.permissions}>
            {/* Память */}
            <View style={styles.permRow}>
              <View style={styles.permIcon}><Icon name="folder-open-outline" size={19} color={colors.primary} /></View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.permTitle}>{copy.storage}</Text>
                <Text style={styles.permText}>{copy.storageText}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <StatusPill label={storageGranted ? copy.granted : copy.notGranted} tone={storageGranted ? 'success' : 'warning'} />
                {!storageGranted ? <Pressable onPress={grantStorage} style={styles.miniBtn}><Text style={styles.miniBtnText}>{copy.storageGrant}</Text></Pressable> : null}
              </View>
            </View>
            {/* Уведомления */}
            <View style={styles.permRow}>
              <View style={styles.permIcon}><Icon name="notifications-outline" size={19} color={colors.primary} /></View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={styles.permTitle}>{copy.notif}</Text>
                <Text style={styles.permText}>{copy.notifText}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <StatusPill label={notifGranted ? copy.notifGranted : copy.notifDenied} tone={notifGranted ? 'success' : 'warning'} />
                {!notifGranted ? <Pressable onPress={grantNotif} style={styles.miniBtn}><Text style={styles.miniBtnText}>{copy.notifGrant}</Text></Pressable> : null}
              </View>
            </View>
          </View>

          <View style={styles.note}>
            <Icon name="information-circle-outline" size={18} color={colors.textSecondary} />
            <Text style={styles.noteText}>{copy.background}</Text>
          </View>

          {phase === 'done' || phase === 'error' ? (
            <Pressable onPress={() => { if (phase === 'done') onComplete(); else { run(); } }} style={styles.link}>
              <Text style={styles.linkText}>{phase === 'done' ? copy.continueAnyway : copy.retry}</Text>
            </Pressable>
          ) : null}
          <Text style={styles.platform}>RAI v{RAI_VERSION} · arm64 · Ubuntu (proot) · Compose Studio</Text>
        </View>
      </ScrollView>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  page: { flexGrow: 1, padding: 20 },
  content: { width: '100%', maxWidth: 680, alignSelf: 'center', alignItems: 'center' },
  brandMark: { width: 62, height: 62, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: c.primary, marginBottom: 18 },
  title: { color: c.text, fontSize: 26, fontWeight: '800', textAlign: 'center', letterSpacing: -0.4 },
  subtitle: { color: c.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center', maxWidth: 520, marginTop: 8, marginBottom: 20 },
  card: { width: '100%', padding: 16 },
  stepRow: { minHeight: 34, flexDirection: 'row', alignItems: 'center', gap: 9 },
  stepText: { flex: 1, color: c.text, fontSize: 13, fontWeight: '600' },
  dot: { width: 7, height: 7, borderRadius: 4 },
  errorBox: { width: '100%', flexDirection: 'row', alignItems: 'flex-start', gap: 9, padding: 12, borderRadius: 11, backgroundColor: c.errorBg, marginTop: 12 },
  errorText: { flex: 1, color: c.errorText, fontSize: 12, lineHeight: 18 },
  consoleWrap: { width: '100%', borderRadius: 12, overflow: 'hidden', backgroundColor: c.terminal, borderWidth: 1, borderColor: '#253046', marginTop: 14 },
  consoleHead: { minHeight: 40, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.terminalRaised, borderBottomWidth: 1, borderBottomColor: '#253046' },
  dots: { flexDirection: 'row', gap: 5 },
  consoleTitle: { color: '#D6DEEB', fontSize: 11, fontWeight: '700' },
  console: { maxHeight: 260 },
  consoleContent: { padding: 12, paddingBottom: 20 },
  consoleEmpty: { minHeight: 90, alignItems: 'center', justifyContent: 'center', gap: 7 },
  consoleEmptyText: { color: '#526079', fontFamily: 'monospace', fontSize: 10 },
  log: { color: '#C9D3E3', fontFamily: 'monospace', fontSize: 10, lineHeight: 16 },
  command: { color: '#FFFFFF', fontWeight: '700', marginTop: 7 },
  success: { color: '#4ADE80' },
  error: { color: '#F87171' },
  warning: { color: '#FBBF24' },
  primaryBtn: { width: '100%', marginTop: 14 },
  successBox: { width: '100%', flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderRadius: 12, backgroundColor: c.successBg, marginTop: 14 },
  successText: { flex: 1, color: c.successText, fontSize: 13, fontWeight: '700' },
  permissions: { width: '100%', gap: 10, marginTop: 14 },
  permRow: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: c.border, backgroundColor: c.bgCard },
  permIcon: { width: 38, height: 38, borderRadius: 10, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' },
  permTitle: { color: c.text, fontSize: 13, fontWeight: '750' },
  permText: { color: c.textSecondary, fontSize: 10, lineHeight: 15, marginTop: 2 },
  miniBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: c.primary },
  miniBtnText: { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  note: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, maxWidth: 540, marginTop: 16 },
  noteText: { color: c.textSecondary, fontSize: 11, lineHeight: 17, flex: 1 },
  link: { marginTop: 10, padding: 8 },
  linkText: { color: c.primary, fontSize: 13, fontWeight: '700' },
  platform: { color: c.textTertiary, fontSize: 10, marginTop: 18 },
});

export default RaiSetupScreen;
