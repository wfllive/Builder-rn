import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Modal, TextInput, Alert, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import ComponentPalette from '../components/ComponentPalette';
import DesignCanvas from '../components/DesignCanvas';
import PropertyPanel from '../components/PropertyPanel';
import colors from '../theme/colors';

const { width: W } = Dimensions.get('window');
const isTablet = W >= 768;

const EditorScreen = ({ navigation }) => {
  const {
    currentProject, currentScreenId, setCurrentScreen,
    addScreen, deleteScreen, duplicateScreen, dispatch,
  } = useProject();

  const [showScreenList, setShowScreenList] = useState(false);
  const [screenModal, setScreenModal] = useState(false);
  const [newScreenName, setNewScreenName] = useState('');
  const [showPalette, setShowPalette] = useState(false);
  const [showProps, setShowProps] = useState(false);

  if (!currentProject) {
    return (
      <SafeAreaView style={s.container} edges={['top','bottom']}>
        <View style={s.emptyWrap}>
          <Icon name="folder-open-outline" size={48} color={colors.textTertiary} />
          <Text style={s.emptyText}>Нет открытого проекта</Text>
          <TouchableOpacity style={s.primaryBtn} onPress={() => navigation.navigate('Projects')}>
            <Text style={s.primaryBtnText}>К проектам</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const currentScreen = currentProject.screens.find(sc => sc.id === currentScreenId);

  const handleAddScreen = () => {
    if (newScreenName.trim()) {
      addScreen(newScreenName.trim());
      setNewScreenName('');
      setScreenModal(false);
    }
  };

  const handleDeleteScreen = (id) => {
    if (currentProject.screens.length <= 1) { Alert.alert('', 'Нельзя удалить единственный экран'); return; }
    Alert.alert('Удалить экран?', '', [
      { text: 'Отмена', style: 'cancel' },
      { text: 'Удалить', style: 'destructive', onPress: () => deleteScreen(id) },
    ]);
  };

  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>

      {/* ═══ HEADER ═══ */}
      <View style={s.header}>
        {/* Left: back */}
        <TouchableOpacity style={s.iconBtn} onPress={() => navigation.navigate('Projects')}>
          <Icon name="arrow-back" size={20} color={colors.text} />
        </TouchableOpacity>

        {/* Center: screen selector */}
        <TouchableOpacity style={s.screenChip} onPress={() => setShowScreenList(true)}>
          <Icon name="phone-portrait-outline" size={14} color={colors.primary} />
          <Text style={s.screenChipText} numberOfLines={1}>{currentScreen?.name || '—'}</Text>
          <Icon name="chevron-down" size={14} color={colors.textTertiary} />
        </TouchableOpacity>

        {/* Right: action buttons */}
        <View style={s.headerRight}>
          {!isTablet && (
            <>
              <TouchableOpacity style={s.iconBtn} onPress={() => { setShowPalette(!showPalette); setShowProps(false); }}>
                <Icon name={showPalette ? 'cube' : 'cube-outline'} size={20} color={showPalette ? colors.primary : colors.textSecondary} />
              </TouchableOpacity>
              <TouchableOpacity style={s.iconBtn} onPress={() => { setShowProps(!showProps); setShowPalette(false); }}>
                <Icon name={showProps ? 'settings' : 'settings-outline'} size={20} color={showProps ? colors.primary : colors.textSecondary} />
              </TouchableOpacity>
            </>
          )}
          {/* PLAY — предпросмотр */}
          <TouchableOpacity style={s.playBtn} onPress={() => navigation.navigate('LivePreview')}>
            <Icon name="play" size={16} color="#fff" />
            <Text style={s.playBtnText}>Запуск</Text>
          </TouchableOpacity>
          {/* BUILD — сборка */}
          <TouchableOpacity style={s.buildBtn} onPress={() => navigation.navigate('Build')}>
            <Icon name="build-outline" size={16} color="#fff" />
            <Text style={s.buildBtnText}>Сборка</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* ═══ MAIN CONTENT ═══ */}
      <View style={s.main}>
        {isTablet && <View style={s.sideL}><ComponentPalette /></View>}
        <View style={s.canvasWrap}><DesignCanvas /></View>
        {isTablet && <View style={s.sideR}><PropertyPanel /></View>}
      </View>

      {/* ═══ MOBILE BOTTOM SHEETS ═══ */}
      {!isTablet && showPalette && (
        <View style={s.sheet}>
          <View style={s.sheetHead}>
            <Text style={s.sheetTitle}>Компоненты</Text>
            <TouchableOpacity onPress={() => setShowPalette(false)} style={s.sheetClose}>
              <Icon name="close" size={22} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={s.sheetBody}><ComponentPalette /></ScrollView>
        </View>
      )}
      {!isTablet && showProps && (
        <View style={s.sheet}>
          <View style={s.sheetHead}>
            <Text style={s.sheetTitle}>Свойства</Text>
            <TouchableOpacity onPress={() => setShowProps(false)} style={s.sheetClose}>
              <Icon name="close" size={22} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView style={s.sheetBody}><PropertyPanel /></ScrollView>
        </View>
      )}

      {/* ═══ SCREEN LIST MODAL ═══ */}
      <Modal visible={showScreenList} transparent animationType="fade" onRequestClose={() => setShowScreenList(false)}>
        <TouchableOpacity style={s.overlay} activeOpacity={1} onPress={() => setShowScreenList(false)}>
          <View style={s.screenListModal}>
            <Text style={s.modalTitle}>Экраны</Text>
            {currentProject.screens.map(sc => (
              <View key={sc.id} style={s.screenRow}>
                <TouchableOpacity
                  style={[s.screenRowBtn, sc.id === currentScreenId && s.screenRowActive]}
                  onPress={() => { setCurrentScreen(sc.id); setShowScreenList(false); }}
                >
                  <Icon name="phone-portrait-outline" size={16} color={sc.id === currentScreenId ? colors.primary : colors.textSecondary} />
                  <Text style={[s.screenRowText, sc.id === currentScreenId && s.screenRowActive]}>{sc.name}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.rowAction} onPress={() => { duplicateScreen(sc.id); setShowScreenList(false); }}>
                  <Icon name="copy-outline" size={16} color={colors.textTertiary} />
                </TouchableOpacity>
                <TouchableOpacity style={s.rowAction} onPress={() => handleDeleteScreen(sc.id)}>
                  <Icon name="trash-outline" size={16} color={colors.error} />
                </TouchableOpacity>
              </View>
            ))}
            <TouchableOpacity style={s.addBtn} onPress={() => { setScreenModal(true); setShowScreenList(false); }}>
              <Icon name="add-circle-outline" size={18} color={colors.primary} />
              <Text style={s.addBtnText}>Добавить экран</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* ═══ NEW SCREEN MODAL ═══ */}
      <Modal visible={screenModal} transparent animationType="fade" onRequestClose={() => setScreenModal(false)}>
        <View style={s.overlay}>
          <View style={s.dialog}>
            <Text style={s.modalTitle}>Новый экран</Text>
            <TextInput style={s.dialogInput} placeholder="Название" placeholderTextColor={colors.textTertiary} value={newScreenName} onChangeText={setNewScreenName} autoFocus onSubmitEditing={handleAddScreen} />
            <View style={s.dialogBtns}>
              <TouchableOpacity style={[s.dialogBtn, s.dialogBtnCancel]} onPress={() => { setScreenModal(false); setNewScreenName(''); }}>
                <Text style={s.dialogBtnCancelText}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.dialogBtn, s.dialogBtnOk]} onPress={handleAddScreen}>
                <Text style={s.dialogBtnOkText}>Создать</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },

  // Empty
  emptyWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyText: { color: colors.textSecondary, fontSize: 16, marginTop: 12 },
  primaryBtn: { marginTop: 16, backgroundColor: colors.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 10 },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },

  // ═══ HEADER ═══
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    paddingHorizontal: 16, paddingVertical: 10,
    backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  iconBtn: {
    width: 40, height: 40, borderRadius: 10,
    backgroundColor: colors.bgElevated, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: colors.border,
  },
  screenChip: {
    flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.bgElevated, paddingHorizontal: 14, paddingVertical: 10,
    borderRadius: 10, borderWidth: 1, borderColor: colors.border,
  },
  screenChipText: { flex: 1, fontSize: 14, fontWeight: '600', color: colors.text },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },

  playBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: colors.success, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10,
  },
  playBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },

  buildBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: colors.primary, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10,
  },
  buildBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },

  // ═══ MAIN ═══
  main: { flex: 1, flexDirection: 'row' },
  sideL: { width: 200, borderRightWidth: 1, borderRightColor: colors.border },
  sideR: { width: 260, borderLeftWidth: 1, borderLeftColor: colors.border },
  canvasWrap: { flex: 1 },

  // ═══ BOTTOM SHEETS ═══
  sheet: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    maxHeight: '60%', backgroundColor: colors.bgCard,
    borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderWidth: 1, borderColor: colors.border,
    shadowColor: '#000', shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.1, shadowRadius: 12, elevation: 12,
  },
  sheetHead: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  sheetTitle: { fontSize: 16, fontWeight: '700', color: colors.text },
  sheetClose: { padding: 4 },
  sheetBody: { flex: 1 },

  // ═══ MODALS ═══
  overlay: { flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: 24 },
  screenListModal: {
    backgroundColor: colors.bgCard, borderRadius: 16, padding: 8,
    borderWidth: 1, borderColor: colors.border, maxWidth: 400, alignSelf: 'center', width: '100%',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 12,
  },
  modalTitle: { fontSize: 17, fontWeight: '700', color: colors.text, padding: 14, textAlign: 'center' },
  screenRow: { flexDirection: 'row', alignItems: 'center' },
  screenRowBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderRadius: 10 },
  screenRowActive: { backgroundColor: colors.primarySurface },
  screenRowText: { fontSize: 14, color: colors.text, fontWeight: '500', flex: 1 },
  rowAction: { padding: 10 },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    padding: 14, borderTopWidth: 1, borderTopColor: colors.border, marginTop: 4,
  },
  addBtnText: { fontSize: 14, fontWeight: '600', color: colors.primary },

  dialog: {
    backgroundColor: colors.bgCard, borderRadius: 20, padding: 24,
    borderWidth: 1, borderColor: colors.border, maxWidth: 400, width: '100%', alignSelf: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 12,
  },
  dialogInput: {
    backgroundColor: colors.bgElevated, borderRadius: 12, padding: 14, fontSize: 15,
    color: colors.text, borderWidth: 1, borderColor: colors.border, marginBottom: 20,
  },
  dialogBtns: { flexDirection: 'row', gap: 10 },
  dialogBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  dialogBtnCancel: { backgroundColor: colors.bgElevated, borderWidth: 1, borderColor: colors.border },
  dialogBtnOk: { backgroundColor: colors.primary },
  dialogBtnCancelText: { color: colors.textSecondary, fontSize: 15, fontWeight: '600' },
  dialogBtnOkText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});

export default EditorScreen;
