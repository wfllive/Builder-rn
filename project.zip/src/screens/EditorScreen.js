import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, BackHandler, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import CodeMirrorEditor from '../ide/CodeMirrorEditor';
import WidgetRenderer from '../components/WidgetRenderer';
import FileExplorer from '../components/FileExplorer';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { generateScreenJSX, writeScreenSource, syncComposeProject } from '../utils/composeProject';
import { findMissingImports, addMissingImports, fileStats } from '../utils/importManager';
import { analyzeKotlin as analyzeJS, summarizeProblems } from '../utils/kotlinAnalyzer';
import { readProjectFile, writeProjectFile, listProjectFiles } from '../utils/projectFiles';
import { execute, isPortServingHttp } from '../utils/shellExecutor';
import { getProjectDir, getScreensDir } from '../config/runtime';
import EditorSettings from '../components/EditorSettings';
import { WebView } from 'react-native-webview';

const fileIcon = (ext) => {
  switch(ext){
    case 'jsx': return { name: 'logo-react', color: '#61DAFB' };
    case 'js': return { name: 'logo-javascript', color: '#F7DF1E' };
    case 'tsx': return { name: 'logo-react', color: '#61DAFB' };
    case 'ts': return { name: 'logo-javascript', color: '#3178C6' };
    case 'css': return { name: 'color-palette-outline', color: '#1572B6' };
    case 'html': return { name: 'code-outline', color: '#E34F26' };
    case 'json': return { name: 'braces-outline', color: '#F7C948' };
    case 'md': return { name: 'document-text-outline', color: '#7FB8E8' };
    default: return { name: 'document-outline', color: '#8B98AD' };
  }
};

const SYMBOL_KEYS = ['{','}','(',')','[',']','<','>','=',';',':','.',',','"','\'','`','$','_','|','&','?','!','/','-','+','*','%','#','@'];
const PREVIEW_DEVICES = [
  { id: 'compact', label: '360×800', widthDp: 360, heightDp: 800 },
  { id: 'standard', label: '412×915', widthDp: 412, heightDp: 915 },
  { id: 'tablet', label: '768×1024', widthDp: 768, heightDp: 1024 },
];

const EditorScreen = ({ navigation }) => {
  const { width, height } = useWindowDimensions();
  const { currentProject, currentScreenId, setCurrentScreen, addScreen, deleteScreen, duplicateScreen, workspaceLogs, clearWorkspaceLogs, addWorkspaceLog, closeProject, dispatch, updateScreen } = useProject();
  const { colors, language, t, editor, setEditorSetting, resolvedTheme } = useAppSettings();
  const styles = useMemo(()=>createStyles(colors),[colors]);
  const insets = useSafeAreaInsets();
  const wide = width >= 900;
  const narrow = width < 600; // компактный режим на телефонах
  const editorTheme = resolvedTheme==='dark' ? 'dark' : 'light';
  const ide = useMemo(()=> editorTheme==='light' ? { editorBg:'#FFFFFF', panel:'#F3F3F3', panelBorder:'#D4D4D4', panelText:'#424242', panelTextDim:'#6E6E6E', status:'#007ACC' } : { editorBg:'#1E1E1E', panel:'#252526', panelBorder:'#3C3C3C', panelText:'#CCCCCC', panelTextDim:'#858585', status:'#007ACC' }, [editorTheme]);

  const [activeTab, setActiveTab] = useState('editor'); // editor | preview | design
  const [previewDeviceId, setPreviewDeviceId] = useState('compact');
  const [previewChrome, setPreviewChrome] = useState(true);
  const [previewMode, setPreviewMode] = useState('webview'); // webview (реальный код) | visual (mockup дерева)
  const [yarnDevRunning, setYarnDevRunning] = useState(false);
  const [yarnDevLog, setYarnDevLog] = useState('');
  const [webViewError, setWebViewError] = useState(false);
  const [previewNonce, setPreviewNonce] = useState(0); // bump → WebView перезагружается (свежий код)
  const viteProcRef = useRef(null);  // holds the non-awaited Vite execute (keeps proot+vite alive)
  useEffect(()=>{ setWebViewError(false); }, [previewMode, activeTab, currentScreenId]);
  // (preview/vite effect перенесён ниже — после объявления previewVisible, чтобы не было TDZ)

  const [screenMenu, setScreenMenu] = useState(false);
  const [explorerOpen, setExplorerOpen] = useState(false);
  const [newScreenOpen, setNewScreenOpen] = useState(false);
  const [newScreenName, setNewScreenName] = useState('');
  const [logMode, setLogMode] = useState('hidden');
  const [dockTab, setDockTab] = useState('output');
  const [saving, setSaving] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [activeFile, setActiveFile] = useState(null);
  const [openTabs, setOpenTabs] = useState([]);
  const [dirtyByPath, setDirtyByPath] = useState({});
  const [missingList, setMissingList] = useState([]);
  const [lintProblems, setLintProblems] = useState([]);
  const [cursorInfo, setCursorInfo] = useState({line:1,col:1,lines:0,canUndo:false,canRedo:false});
  const [gotoOpen, setGotoOpen] = useState(false);
  const [gotoValue, setGotoValue] = useState('');
  const [build, setBuild] = useState({ running:false, ok:false, output:'', at:0 });
  const [previewGuardUnlocked, setPreviewGuardUnlocked] = useState(false);
  useEffect(()=>{ setPreviewGuardUnlocked(false); }, [activeTab, currentScreenId]);
  const previewEnabled = editor.designPreview !== false;
  const guardOn = !!editor.designPreviewGuard;
  const previewVisible = previewEnabled && (!guardOn || previewGuardUnlocked);

  // Запустить (или перезапустить) Vite dev и дождаться HTTP 200. ОБЩАЯ функция
  // для авто-запуска (effect ниже) и кнопки «Старт». Всегда pkill + чистый старт,
  // чтобы не зависеть от зависшего/устаревшего процесса (прежний баг: авто-запуск
  // находил старый vite и не перезапускал). Возвращает true, когда Vite готов.
  const startVite = useCallback(async (cwd) => {
    // Готовность — ЖИВАЯ проверка: реальный HTTP-запрос через node (не лог!).
    // Лог хранит старое "ready" даже когда Vite уже умер → фальшивое "запущен".
    // node всегда есть (на нём Vite); работает там, где curl ненадёжен.
    const http200 = async () => isPortServingHttp(5173, cwd);
    try {
      if (await http200()) return true;
      if (/N/.test((await execute('[ -f node_modules/.bin/vite ] && echo Y || echo N', cwd)).output||'')) { setYarnDevLog('npm install (ставлю Vite)…'); await execute('npm install --silent 2>&1 | tail -5', cwd); }
      setYarnDevLog('Запускаю Vite dev :5173…');
      await execute('pkill -f "vite" 2>/dev/null; sleep 1; rm -f /tmp/vite.log', cwd);
      // Vite в ФОНЕ через НЕ-await execute: нативный мост держит proot+Vite живыми,
      // пока Vite работает. (nohup/& убивал Vite, когда execute возвращался — proot
      // умирал → к открытию WebView уже CONNECTION_REFUSED.)
      viteProcRef.current = execute('npm run dev -- --host 0.0.0.0 --port 5173 > /tmp/vite.log 2>&1', cwd).catch(()=>{});
      for (let i=0; i<30; i++) {
        await new Promise(r=>setTimeout(r,2000));
        if (await http200()) return true;
        const tail=(await execute('tail -2 /tmp/vite.log 2>/dev/null', cwd)).output||'';
        setYarnDevLog('Запуск Vite… ' + tail.replace(/\n/g,' ').slice(-110));
      }
      return false;
    } catch(e){ setYarnDevLog('Ошибка запуска Vite: '+String(e).slice(0,140)); return false; }
  }, []);

  // Авто-запуск Vite при входе в режим WebView. Статус честный: зелёный только при 200.
  useEffect(()=>{
    if(activeTab!=='design' || !previewVisible || previewMode!=='webview') return;
    let cancelled=false;
    (async()=>{
      const cwd=getProjectDir(latestProjectRef.current||currentProject);
      if(!cwd) return;
      setYarnDevRunning(false);
      const ok=await startVite(cwd);
      if(!cancelled){ setYarnDevRunning(ok); if(ok){ setYarnDevLog('Vite готов · http://127.0.0.1:5173'); setWebViewError(false);} }
    })();
    return ()=>{cancelled=true};
  },[activeTab, previewVisible, previewMode, currentProject?.id, startVite]);

  const editorApi = useRef(null);
  const draftRef = useRef('');
  const savedRef = useRef({});
  const dirtyRef = useRef({});
  const closingRef = useRef(false);
  const saveTimerRef = useRef(null);
  const lintTimerRef = useRef(null);
  const latestProjectRef = useRef(currentProject);
  useEffect(()=>{ latestProjectRef.current=currentProject; },[currentProject]);

  const currentScreen = currentProject?.screens?.find(s=>s.id===currentScreenId);
  const previewDevice = PREVIEW_DEVICES.find(x=>x.id===previewDeviceId)||PREVIEW_DEVICES[0];
  // Масштаб рамки устройства под доступное место (края не обрезаются).
  const previewScale = useMemo(()=>{
    const availW = (width||360) - 32;
    const availH = (height||640) - 215; // topBar + workspaceBar + previewHead + logDock
    return Math.max(0.3, Math.min(availW/(previewDevice.widthDp||360), availH/(previewDevice.heightDp||800), 1));
  },[width, height, previewDevice]);
  const ru = language==='ru';

  const screenFilePath = useMemo(()=>{
    if(!currentProject || !currentScreen) return null;
    const safe=(currentScreen.name||'Screen').replace(/[^A-Za-z0-9_]/g,'')||'Screen';
    return `src/screens/${safe}.jsx`;
  },[currentProject, currentScreen]);

  const copy = ru ? {
    noProject:'Проект не открыт', screenName:'Название экрана', deleteScreen:'Удалить экран?', lastScreen:'Нельзя удалить единственный экран.',
    consoleReady:'Редактор готов. Откройте файл слева или сохраните JSX.', clear:'Очистить', output:'Вывод', problems:'Проблемы', noProblems:'Проблем не найдено',
    closing:'Сохраняем и закрываем…', save:'Сохранить', saving:'Сохранение…', saved:'Файл записан', saveFailed:'Ошибка сохранения',
    codePlaceholder:'// Введите JSX — React компонент\nimport React from "react";\nexport default function Home(){\n  return <div>Hello</div>\n}',
    design:'Дизайн', editor:'Код', preview:'Превью', readOnly:'Только чтение', unsaved:'Несохранённые изменения', unsavedHint:'Сохранить перед переключением?', discard:'Не сохранять', unsavedSave:'Сохранить',
    gotoLine:'Перейти к строке', lineNumber:'Номер строки', goto:'Перейти', openFile:'Открыть файл', fallback:'Предпросмотр недоступен — простой редактор',
    importsFix:'Добавить импорт React', checkCode:'Проверить (vite build)', checkRunning:'Сборка…', checkOk:'Сборка успешна', checkFailed:'Сборка упала',
  } : {
    noProject:'No project open', screenName:'Screen name', deleteScreen:'Delete screen?', lastScreen:'Cannot delete the only screen.',
    consoleReady:'Editor ready. Open a file or save JSX.', clear:'Clear', output:'Output', problems:'Problems', noProblems:'No problems',
    closing:'Saving and closing…', save:'Save', saving:'Saving…', saved:'File written', saveFailed:'Save failed',
    codePlaceholder:'// Enter JSX — React component\nimport React from "react";\nexport default function Home(){\n  return <div>Hello</div>\n}',
    design:'Design', editor:'Code', preview:'Preview', readOnly:'Read only', unsaved:'Unsaved changes', unsavedHint:'Save before switching?', discard:"Don't save", unsavedSave:'Save',
    gotoLine:'Go to line', lineNumber:'Line number', goto:'Go', openFile:'Open file', fallback:'Preview unavailable — fallback editor',
    importsFix:'Add React import', checkCode:'Check (vite build)', checkRunning:'Building…', checkOk:'Build succeeded', checkFailed:'Build failed',
  };

  const setDirtyState = useCallback((path, flag)=>{
    dirtyRef.current={...dirtyRef.current,[path]:flag};
    setDirtyByPath(prev=>({...prev,[path]:flag}));
  },[]);

  useEffect(()=>{
    if(!currentScreen || !screenFilePath) return;
    // load JSX source for the screen: generate if missing else keep existing
    let source = currentScreen.source || '';
    if(!source || !source.trim()){
      try{ source = generateScreenJSX(currentScreen); }catch(e){ source = `export default function ${currentScreen.name}(){ return <div>${currentScreen.name}</div> }`; }
    }
    const tab={ path: screenFilePath, name: `${currentScreen.name}.jsx`, isScreen:true };
    savedRef.current[screenFilePath]=source;
    draftRef.current=source;
    setDraft(source);
    setActiveFile(tab);
    setOpenTabs(prev=>[tab, ...prev.filter(t=>!t.isScreen)]);
    setDirtyState(screenFilePath,false);
  },[currentScreen?.id]); // eslint-disable-line

  useEffect(()=>{
    if(lintTimerRef.current) clearTimeout(lintTimerRef.current);
    lintTimerRef.current=setTimeout(()=>{
      // fileStats and analyzeJS
      setLintProblems(analyzeJS(draft));
      setMissingList(findMissingImports(draft).missing);
    },300);
    return ()=>{ if(lintTimerRef.current) clearTimeout(lintTimerRef.current); };
  },[draft]);

  const handleEditorChange = useCallback((text)=>{
    draftRef.current=text; setDraft(text);
    const path=activeFile?.path;
    if(path) setDirtyState(path, text!== (savedRef.current[path] ?? ''));
  },[activeFile?.path, setDirtyState]);

  const applyMissingImports = useCallback(()=>{
    const withImp=addMissingImports(draftRef.current, missingList);
    if(withImp!==draftRef.current){ draftRef.current=withImp; setDraft(withImp); setMissingList([]); addWorkspaceLog(ru?`Добавлен импорт React`:`Added React import`,'success'); }
  },[missingList, addWorkspaceLog, ru]);

  const doSave = useCallback(async(silent=false)=>{
    if(!currentProject) return {success:false};
    const content=draftRef.current;
    if(activeFile && activeFile.isScreen && currentScreen){
      const result=await writeScreenSource(latestProjectRef.current||currentProject, currentScreen, content);
      if(result?.success){
        // try to keep tree in sync: if JSX looks like generated, ignore; else keep source
        updateScreen({ ...currentScreen, source: content });
        savedRef.current[activeFile.path]=content;
        setDirtyState(activeFile.path,false);
        setPreviewNonce(n=>n+1);
        if(!silent) addWorkspaceLog(`${copy.saved} · ${currentScreen.name}.jsx`,'success');
      } else if(!silent) addWorkspaceLog(result?.output||copy.saveFailed,'error');
      return result;
    }
    if(activeFile){
      const result=await writeProjectFile(latestProjectRef.current||currentProject, activeFile.path, content);
      if(result?.success){ savedRef.current[activeFile.path]=content; setDirtyState(activeFile.path,false); setPreviewNonce(n=>n+1); if(!silent) addWorkspaceLog(`${copy.saved} · ${activeFile.name}`,'success'); }
      else if(!silent) addWorkspaceLog(result?.output||copy.saveFailed,'error');
      return result;
    }
    return {success:false};
  },[currentProject, currentScreen, activeFile, updateScreen, addWorkspaceLog, copy.saved, copy.saveFailed, setDirtyState]);

  useEffect(()=>{
    if(!editor.autoSave || !currentProject) return;
    if(saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current=setTimeout(()=>{ doSave(true); },1200);
    return ()=>{ if(saveTimerRef.current) clearTimeout(saveTimerRef.current); };
  },[draft, editor.autoSave, activeFile?.path]);

  const guardUnsaved=useCallback((next)=>{
    const path=activeFile?.path;
    if(!path || !dirtyRef.current[path]){ next(); return; }
    if(editor.autoSave){ doSave(true).finally(next); return; }
    Alert.alert(copy.unsaved, copy.unsavedHint, [
      {text:t('cancel'), style:'cancel'},
      {text:copy.discard, style:'destructive', onPress:()=>{ setDirtyState(path,false); next(); }},
      {text:copy.unsavedSave, onPress: async()=>{ await doSave(true); next(); }},
    ]);
  },[activeFile?.path, editor.autoSave, doSave, t, copy.unsaved, copy.unsavedHint, copy.discard, copy.unsavedSave, setDirtyState]);

  const openFileByPath = useCallback(async(path)=>{
    if(!currentProject) return;
    if(activeFile?.path===path) return;
    try{
      const read=await readProjectFile(currentProject, path);
      const name=path.split('/').pop()||path;
      const text=read.output||'';
      const tab={ path, name, isScreen:false };
      savedRef.current[path]=text; draftRef.current=text; setDraft(text); setActiveFile(tab);
      setOpenTabs(prev=> prev.some(t=>t.path===path)? prev : [...prev, tab]);
      setDirtyState(path,false);
      addWorkspaceLog(`${ru?'Открыт файл':'Opened'}: ${path}`,'info');
    }catch(e){ addWorkspaceLog(`Open failed: ${e?.message||String(e)}`,'error'); }
  },[currentProject, activeFile?.path, addWorkspaceLog, ru]);

  const onOpenFile = useCallback((path)=>{
    if(activeFile?.path===path) return;
    guardUnsaved(()=>{ openFileByPath(path); });
  },[activeFile?.path, guardUnsaved, openFileByPath]);

  const activateScreenTab = useCallback((tab)=>{
    const project=latestProjectRef.current;
    const screen=(project?.screens||[]).find(s=> `${s.name}.jsx`===tab.name);
    if(!screen) return;
    if(screen.id!==currentScreenId){ setCurrentScreen(screen.id); return; }
    let source=screen.source || '';
    if(!source) try{ source=generateScreenJSX(screen);}catch(e){ source=`export default function ${screen.name}(){return <div>${screen.name}</div>}`;}
    savedRef.current[tab.path]=source; draftRef.current=source; setDraft(source); setActiveFile(tab); setDirtyState(tab.path,false);
  },[currentScreenId, setCurrentScreen, setDirtyState]);

  const activateTab=useCallback((tab)=>{
    if(!tab || tab.path===activeFile?.path) return;
    guardUnsaved(()=>{ if(tab.isScreen) activateScreenTab(tab); else openFileByPath(tab.path); });
  },[activeFile?.path, guardUnsaved, activateScreenTab, openFileByPath]);

  const closeTab=useCallback((tab)=>{
    if(tab.isScreen) return;
    const finish=()=>{
      const rest=openTabs.filter(t=>t.path!==tab.path);
      setOpenTabs(rest);
      if(activeFile?.path===tab.path){
        const next=rest.find(t=>!t.isScreen)||rest[0];
        if(next && !next.isScreen) openFileByPath(next.path);
        else if(next) activateScreenTab(next);
      }
    };
    if(dirtyRef.current[tab.path]) guardUnsaved(finish); else finish();
  },[activeFile?.path, openTabs, guardUnsaved, openFileByPath, activateScreenTab]);

  const runBuildCheck = useCallback(async()=>{
    if(build.running || !currentProject) return;
    setBuild(c=>({...c, running:true}));
    addWorkspaceLog('vite build — проверка JSX','info');
    try{
      await doSave(true);
      const cwd=getProjectDir(latestProjectRef.current||currentProject);
      const sync=await syncComposeProject(latestProjectRef.current||currentProject);
      addWorkspaceLog(sync.output||'sync done','info');
      await execute('[ -f node_modules/.bin/vite ] || npm install --silent 2>&1 | tail -10', cwd);
      const result=await execute('npm run build 2>&1 | tail -100', cwd);
      const out=result?.output||'';
      const failed=/error|failed/i.test(out) && !/built in/i.test(out);
      setBuild({ running:false, ok:!failed && result?.success!==false, output:out, at:Date.now() });
      addWorkspaceLog(failed ? copy.checkFailed : copy.checkOk, failed?'error':'success');
      if(failed) setLogMode('half');
    }catch(e){
      setBuild(c=>({...c, running:false, ok:false, output:String(e)}));
      addWorkspaceLog(`${copy.checkFailed}: ${e?.message||String(e)}`,'error');
    }
  },[build.running, currentProject, doSave, addWorkspaceLog, copy.checkOk, copy.checkFailed]);

  const saveNow=useCallback(async()=>{
    if(saving||!currentProject) return;
    setSaving(true);
    try{ const r=await doSave(false); if(!r?.success) addWorkspaceLog(copy.saveFailed,'error'); } catch(e){ addWorkspaceLog(`${copy.saveFailed}: ${e?.message||String(e)}`,'error'); } finally{ setSaving(false); }
    if(editor.autoCheck!==false) runBuildCheck();
  },[saving, currentProject, doSave, addWorkspaceLog, copy.saveFailed, editor.autoCheck, runBuildCheck]);

  const closeAndExit=useCallback(async()=>{
    if(closingRef.current) return; closingRef.current=true;
    if(currentProject){ addWorkspaceLog(copy.closing,'info'); try{ await doSave(false);}catch(e){} }
    try{ await closeProject(); }catch(e){}
    navigation.reset({index:0, routes:[{name:'Projects'}]});
  },[currentProject, closeProject, navigation, copy.closing, addWorkspaceLog, doSave]);

  useFocusEffect(useCallback(()=>{
    const sub=BackHandler.addEventListener('hardwareBackPress',()=>{ closeAndExit(); return true; });
    return ()=>sub.remove();
  },[closeAndExit]));


  // При открытии вкладки Превью — сохранить черновик в файл, чтобы Vite (и WebView)
  // показали свежий код. doSave читает draftRef.current (актуальный текст).
  useEffect(()=>{ if(activeTab==='design' && currentProject){ doSave(true); } },[activeTab]); // eslint-disable-line
  useEffect(()=> navigation.addListener('beforeRemove',(e)=>{ if(closingRef.current) return; e.preventDefault(); closeAndExit(); }),[navigation, closeAndExit]);

  if(!currentProject){
    return <AppScreen style={styles.center}><Icon name="folder-open-outline" size={42} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.noProject}</Text><PrimaryButton title={t('projects')} icon="arrow-back" onPress={()=>navigation.navigate('Projects')} /></AppScreen>;
  }

  const tabs=[
    {key:'editor', label:copy.editor, icon:'code-slash-outline', action:()=>setActiveTab('editor')},
    {key:'design', label:copy.design + ' / ' + copy.preview, icon:'phone-portrait-outline', action:()=>setActiveTab('design')},
  ];

  const createScreen = async()=>{
    const name=newScreenName.trim();
    if(!name) return;
    if(!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) return Alert.alert(ru?'Некорректное имя':'Invalid name', ru?'Только латиница/цифры':'Use Latin letters');
    if((currentProject.screens||[]).some(s=>s.name===name)) return Alert.alert(ru?'Такой экран уже есть':'Exists');
    addScreen(name); setNewScreenName(''); setNewScreenOpen(false); addWorkspaceLog(`${ru?'Создан экран':'Screen created'}: ${name}.jsx`,'info');
  };
  const removeScreen=(id)=>{
    if(currentProject.screens.length<=1) return Alert.alert(copy.lastScreen);
    const target=currentProject.screens.find(s=>s.id===id); if(!target) return;
    Alert.alert(copy.deleteScreen, `${target.name}.jsx`, [
      {text:t('cancel'), style:'cancel'},
      {text:t('delete'), style:'destructive', onPress:()=>{ deleteScreen(id); addWorkspaceLog(`${ru?'Удалён':'Removed'}: ${target.name}.jsx`,'info'); }},
    ]);
  };
  const runGoto=useCallback(()=>{
    const n=parseInt(gotoValue,10); setGotoOpen(false); setGotoValue(''); if(Number.isFinite(n)) editorApi.current?.command('gotoLine', n);
  },[gotoValue]);
  const insertSymbol=useCallback((s)=>{ editorApi.current?.insert(s); },[]);

  const logHeight=logMode==='full'? Math.max(280, Math.round(height*0.5)) : logMode==='half'? Math.min(220, Math.round(height*0.3)) : 34;
  const logs=workspaceLogs.length? workspaceLogs: [{id:'ready', level:'info', text:copy.consoleReady, time:Date.now()}];
  const activeProblems=lintProblems;
  const totalErrors=lintProblems.filter(p=>p.severity==='error').length;
  const totalWarnings=lintProblems.filter(p=>p.severity==='warning').length;
  const activeDirty=activeFile? dirtyByPath[activeFile.path]===true: false;
  const breadcrumb=(activeFile?.path||'').split('/').filter(Boolean);
  const crumbShown=breadcrumb.length>3 && width<520 ? ['…', ...breadcrumb.slice(-2)] : breadcrumb;
  const hotkeysOn=editor.hotkeys!==false;
  const statusOn=editor.showStatusBar!==false;

  const ToolKey=({label,icon,onPress,disabled,accent})=> (
    <Pressable disabled={disabled} onPress={onPress} style={({pressed})=>[{minWidth:narrow?28:34,height:narrow?30:34,paddingHorizontal:narrow?4:6,borderRadius:6,alignItems:'center',justifyContent:'center',backgroundColor: pressed? (editorTheme==='light'?'#E0E0E0':'#37373D'):'transparent', opacity: disabled?0.35:1}]}>
      {icon? <Icon name={icon} size={narrow?15:17} color={accent?'#569CD6':ide.panelText} /> : <Text style={{color: accent? '#569CD6': ide.panelText, fontSize:narrow?13:15, fontFamily:'monospace', fontWeight:'600'}}>{label}</Text>}
    </Pressable>
  );

  return (
    <AppScreen>
      <TopBar compact title={currentProject.name} subtitle={width>=700? currentProject.projectDir: null} onBack={closeAndExit} right={<>
        <IconButton name="folder-open-outline" active={explorerOpen} onPress={()=>setExplorerOpen(v=>!v)} />
        <IconButton name="options-outline" active={settingsOpen} onPress={()=>setSettingsOpen(v=>!v)} />
        <IconButton name="save-outline" label={width>=700? copy.save: null} onPress={saveNow} active={activeDirty} />
        <IconButton name="cube-outline" onPress={()=>navigation.navigate('Libraries')} />
        <IconButton name="hammer-outline" label={width>=880? t('build'):null} active onPress={()=>navigation.navigate('Build')} />
      </>} />

      <View style={styles.workspaceBar}>
        <Pressable onPress={()=>setScreenMenu(true)} style={styles.screenSelect}><Icon name="logo-react" size={15} color={colors.primary} /><Text style={styles.screenText} numberOfLines={1}>{currentScreen?.name||'Screen'}</Text><Icon name="chevron-down" size={13} color={colors.textTertiary} /></Pressable>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.modeTabs}>
          {tabs.map(tab=>(
            <Pressable key={tab.key} onPress={tab.action} style={[styles.modeTab, tab.key===activeTab && styles.modeTabActive]}><Icon name={tab.icon} size={15} color={tab.key===activeTab? colors.primary: colors.textSecondary} /><Text style={[styles.modeTabText, tab.key===activeTab && styles.modeTabTextActive]}>{tab.label}</Text></Pressable>
          ))}
        </ScrollView>
      </View>

      <View style={styles.main}>
        {explorerOpen && wide ? <View style={styles.explorerWrap}><FileExplorer project={currentProject} activePath={activeFile?.path} onOpenFile={onOpenFile} onClose={()=>setExplorerOpen(false)} width={270} /></View> : null}
        <View style={styles.content}>
          {activeTab==='design' ? (
            <View style={styles.previewWrap}>
              <View style={styles.previewHead}>
                <Icon name={previewMode==='webview'?'globe-outline':'color-palette-outline'} size={15} color={colors.primary} />
                <Text style={styles.previewTitle}>{ru?'Дизайн / Превью':'Design / Preview'} · {currentScreen?.name||''}</Text>
                <View style={{flex:1}} />
                <Pressable onPress={()=>setEditorSetting('designPreview', !previewEnabled)} style={[styles.previewControl, !previewEnabled && {opacity:0.5}]}><Icon name={previewEnabled?'eye-outline':'eye-off-outline'} size={13} color={previewEnabled?colors.primary:colors.textTertiary} /><Text style={[styles.previewControlText, !previewEnabled && {color:colors.textTertiary}]}>{previewEnabled? (ru?'Вкл':'On'):(ru?'Выкл':'Off')}</Text></Pressable>
                <Pressable onPress={()=>setPreviewDeviceId(c=>PREVIEW_DEVICES[(PREVIEW_DEVICES.findIndex(x=>x.id===c)+1)%PREVIEW_DEVICES.length].id)} style={styles.previewControl}><Icon name="phone-portrait-outline" size={13} color={colors.primary} /><Text style={styles.previewControlText}>{previewDevice.label}</Text></Pressable>
              </View>
              {previewMode==='webview' && previewVisible ? (
                <View style={{padding:6, flexDirection:'row', alignItems:'center', gap:8, backgroundColor: yarnDevRunning ? '#ECFDF5' : '#FEF3C7', borderBottomWidth:1, borderBottomColor: colors.border}}>
                  <Icon name={yarnDevRunning ? 'checkmark-circle' : 'time-outline'} size={14} color={yarnDevRunning ? colors.success : colors.warning} />
                  <Text style={{flex:1, fontSize:11, color: colors.textSecondary}} numberOfLines={1}>{yarnDevRunning ? (ru?'yarn dev работает :5173':'yarn dev running :5173') : (yarnDevLog || (ru?'yarn dev не запущен':'yarn dev not running'))}</Text>
                  <Pressable onPress={async()=>{
                    const cwd=getProjectDir(latestProjectRef.current||currentProject);
                    if(yarnDevRunning){
                      await execute('pkill -f vite 2>/dev/null; echo stopped', cwd);
                      setYarnDevRunning(false); setYarnDevLog('остановлен');
                    }else{
                      setYarnDevRunning(false);
                      const ok=await startVite(cwd);
                      setYarnDevRunning(ok); if(ok) setWebViewError(false);
                    }
                  }} style={[styles.previewControl, {height:26}]}><Icon name={yarnDevRunning?'pause-outline':'play-outline'} size={12} color={colors.primary} /><Text style={styles.previewControlText}>{yarnDevRunning? (ru?'Стоп':'Stop'):(ru?'Старт':'Start')}</Text></Pressable>
                </View>
              ) : null}
              {!previewVisible ? (
                <View style={{flex:1, alignItems:'center', justifyContent:'center', gap:12, padding:24, backgroundColor: colors.bg}}>
                  <Icon name={previewEnabled ? "shield-checkmark-outline" : "eye-off-outline"} size={42} color={previewEnabled ? colors.primary : colors.textTertiary} />
                  <Text style={{color: colors.text, fontSize:14, fontWeight:'700', textAlign:'center'}}>{previewEnabled ? (guardOn ? 'Двойная защита: предпросмотр заблокирован' : 'Предпросмотр выключен') : 'Предпросмотр отключён в настройках'}</Text>
                  <Text style={{color: colors.textSecondary, fontSize:12, textAlign:'center', lineHeight:16}}>{previewEnabled ? (guardOn ? 'Нажмите «Показать», чтобы временно разблокировать. Отключается при смене экрана.' : 'Включите двойную защиту в Настройки → Дизайн предпросмотр.') : 'Включите: Настройки → Дизайн предпросмотр → Вкл'}</Text>
                  {guardOn && previewEnabled ? <PrimaryButton title="Показать предпросмотр" icon="eye-outline" onPress={()=>setPreviewGuardUnlocked(true)} /> : null}
                  {!previewEnabled ? <PrimaryButton title="Открыть настройки" icon="settings-outline" onPress={()=>navigation.navigate('AppSettings')} /> : null}
                </View>
              ) : (
                // WebView монтируется ТОЛЬКО когда Vite подтвердил готовность
                // (HTTP 200). Поэтому стандартная страница ошибки браузера НИКОГДА
                // не показывается — пока Vite не готов, видна аккуратная заглушка.
                yarnDevRunning ? (
                  <View style={{flex:1, backgroundColor: colors.canvas, alignItems:'center', padding: 8}}>
                    <View style={{
                      flex:1, width:'100%', maxWidth: previewDevice.widthDp,
                      borderRadius: 20, overflow:'hidden', backgroundColor:'#fff',
                      borderWidth: 2, borderColor:'#CBD5E1',
                      shadowColor:'#000', shadowOpacity:0.1, shadowRadius:12, shadowOffset:{width:0,height:2}, elevation:6,
                    }}>
                      <View style={{height:24, backgroundColor:'#0F172A', alignItems:'center', justifyContent:'center'}}>
                        <Text style={{color:'#94A3B8', fontSize:10, fontWeight:'600'}}>9:41</Text>
                      </View>
                      <WebView
                        key={'webview-'+String(yarnDevRunning)+'-'+previewNonce+'-'+previewDeviceId}
                        source={{uri:'http://127.0.0.1:5173'}}
                        style={{flex:1, backgroundColor:'#fff'}}
                        javaScriptEnabled
                        domStorageEnabled
                        allowFileAccess={true}
                        allowUniversalAccessFromFileURLs={true}
                        mixedContentMode="always"
                        originWhitelist={['*']}
                        startInLoadingState
                        renderLoading={() => <View style={{flex:1, alignItems:'center', justifyContent:'center', backgroundColor:'#fff'}}><ActivityIndicator color={colors.primary} /></View>}
                        injectedJavaScriptBeforeContentLoaded={`var m=document.querySelector('meta[name="viewport"]');if(m)m.setAttribute('content','width=${previewDevice.widthDp}, initial-scale=1');`}
                        showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false}
                      />
                    </View>
                  </View>
                ) : (
                  <View style={{flex:1, alignItems:'center', justifyContent:'center', gap:12, padding:24, backgroundColor: colors.bg}}>
                    <ActivityIndicator color={colors.primary} />
                    <Text style={{color: colors.text, fontSize:14, fontWeight:'700', textAlign:'center'}}>{yarnDevLog || (ru?'Запуск Vite…':'Starting Vite…')}</Text>
                    <Text style={{color: colors.textSecondary, fontSize:11, textAlign:'center', lineHeight:15}}>{ru?'Vite dev запускается на :5173. Предпросмотр откроется автоматически, как только сервер будет готов.':'Vite dev is starting on :5173. The preview opens automatically once ready.'}</Text>
                    <View style={{flexDirection:'row', gap:8, marginTop:6}}>
                      <PrimaryButton title={ru?'Перезапустить':'Restart'} icon="refresh-outline" onPress={async()=>{ const c=getProjectDir(currentProject); setYarnDevRunning(false); const ok=await startVite(c); setYarnDevRunning(ok); if(ok) setWebViewError(false); }} />
                    </View>
                  </View>
                )
              )}
            </View>
          ) : (
            <View style={[styles.codeWrap, {backgroundColor: ide.editorBg}]}>
              <View style={[styles.tabStrip, {backgroundColor: ide.panel, borderBottomColor: ide.panelBorder, height: narrow?30:35}]}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{alignItems:'stretch'}}>
                  {openTabs.map(tab=>{
                    const active=tab.path===activeFile?.path; const dirty=dirtyByPath[tab.path]===true; const ext=tab.name.includes('.')? tab.name.split('.').pop():''; const fi=fileIcon(ext);
                    return (
                      <Pressable key={tab.path} onPress={()=>activateTab(tab)} style={[styles.fileTab, {borderRightColor: ide.panelBorder, height: narrow?30:35}, active && {backgroundColor: ide.editorBg, borderTopColor:'#569CD6'}]}>
                        <Icon name={fi.name} size={13} color={active? fi.color: ide.panelTextDim} /><Text numberOfLines={1} style={[styles.fileTabText,{color: active? ide.panelText: ide.panelTextDim}, active&&{fontWeight:'700'}]}>{tab.name}</Text>
                        {tab.isScreen? (dirty? <View style={styles.dirtyDot} />: null) : <Pressable hitSlop={8} onPress={(e)=>{e.stopPropagation?.(); closeTab(tab);}} style={styles.fileTabClose}>{dirty? <View style={styles.dirtyDot} />: <Icon name="close" size={13} color={ide.panelTextDim} />}</Pressable>}
                      </Pressable>
                    );
                  })}
                  <Pressable onPress={()=>setExplorerOpen(v=>!v)} style={styles.fileTabAdd}><Icon name="add" size={17} color={ide.panelTextDim} /></Pressable>
                </ScrollView>
              </View>
              <View style={[styles.crumbs,{backgroundColor: ide.editorBg, borderBottomColor: ide.panelBorder, minHeight:narrow?24:30}]}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{alignItems:'center', gap:2}}>
                  {crumbShown.map((part,i)=>(<React.Fragment key={`${part}-${i}`}>{i>0? <Icon name="chevron-forward" size={11} color={ide.panelTextDim} />: null}<Text style={[styles.crumb,{color: i===crumbShown.length-1? ide.panelText: ide.panelTextDim}]}>{part}</Text></React.Fragment>))}
                </ScrollView>
                <View style={{flex:1}} />
                {build.running? <View style={styles.problemsBtn}><ActivityIndicator size={12} color="#569CD6" /><Text style={styles.checkingText}>{copy.checkRunning}</Text></View>: null}
                {!build.running && (totalErrors>0||totalWarnings>0)? <Pressable onPress={()=>{setDockTab('problems'); setLogMode('half');}} style={styles.problemsBtn}>{totalErrors>0? <><Icon name="close-circle" size={13} color="#F14C4C" /><Text style={styles.problemsCount}>{totalErrors}</Text></>:null}{totalWarnings>0? <><Icon name="warning" size={12} color="#CCA700" style={{marginLeft: totalErrors>0?4:0}} /><Text style={styles.warningsCount}>{totalWarnings}</Text></>:null}</Pressable>:null}
                {missingList.length>0? <Pressable onPress={applyMissingImports} style={styles.importBtn}><Icon name="flash-outline" size={13} color="#C586C0" /><Text style={styles.importBtnText}>{missingList.length}</Text></Pressable>:null}
                <ToolKey icon="refresh-outline" accent onPress={runBuildCheck} disabled={build.running} />
                <ToolKey icon="save-outline" accent={activeDirty} onPress={saveNow} />
              </View>
              {missingList.length>0? <Pressable onPress={applyMissingImports} style={styles.importBar}><Icon name="flash-outline" size={14} color="#C586C0" /><Text style={styles.importText}>{copy.importsFix} ({missingList.length})</Text><Icon name="chevron-forward" size={13} color="#C586C0" /></Pressable>:null}
              <CodeMirrorEditor ref={editorApi} value={draft} onChange={handleEditorChange} readOnly={false} placeholder={copy.codePlaceholder} fallbackTitle={copy.fallback} config={{themeMode: editorTheme, fontSize: editor.fontSize||15, tabSize: editor.tabSize||4, spacesForTab: editor.spacesForTab!==false, wordWrap: editor.wordWrap===true, completion: editor.completion!==false}} diagnostics={activeProblems} onCursor={setCursorInfo} />
              {hotkeysOn? <View style={[styles.toolbar,{backgroundColor: ide.panel, borderTopColor: ide.panelBorder, height: narrow?34:42}]}><ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="always" contentContainerStyle={{alignItems:'center', paddingHorizontal:4, gap:1}}>{SYMBOL_KEYS.map(s=> <ToolKey key={s} label={s} onPress={()=>insertSymbol(s)} />)}<View style={[styles.toolbarSep,{backgroundColor: ide.panelBorder}]} /><ToolKey icon="chevron-back-outline" onPress={()=>editorApi.current?.command('left')} /><ToolKey icon="chevron-forward-outline" onPress={()=>editorApi.current?.command('right')} /></ScrollView></View>:null}
              {statusOn? <View style={[styles.statusBar,{backgroundColor: ide.status, minHeight:narrow?20:24}]}><Pressable onPress={()=>{setDockTab('problems'); setLogMode('half');}} style={styles.statusItem}><Icon name="close-circle" size={12} color="#fff"/><Text style={styles.statusText}>{totalErrors}</Text></Pressable><Pressable onPress={()=>{setDockTab('problems'); setLogMode('half');}} style={styles.statusItem}><Icon name="warning-outline" size={12} color="#fff"/><Text style={styles.statusText}>{totalWarnings}</Text></Pressable><Pressable onPress={()=>setLogMode(logMode==='hidden'?'half':'hidden')} style={styles.statusItem}><Icon name="terminal-outline" size={12} color="#fff"/><Text style={styles.statusText}>{logs.length}</Text></Pressable>{build.running? <View style={styles.statusItem}><ActivityIndicator size={11} color="#fff"/><Text style={styles.statusText}>vite build</Text></View>:null}<View style={{flex:1}} /><Text style={styles.statusText}>Ln {cursorInfo.line}, Col {cursorInfo.col}</Text>{!narrow? <Text style={styles.statusText}>{editor.spacesForTab!==false? `Spaces: ${editor.tabSize||4}`:`Tab Size: ${editor.tabSize||4}`}</Text>:null}{!narrow? <Text style={styles.statusText}>UTF-8</Text>:null}<Text style={styles.statusText}>JSX</Text></View>:null}
            </View>
          )}
        </View>
      </View>

      <View style={[styles.logDock,{height: logHeight, backgroundColor: ide.panel, borderTopColor: ide.panelBorder}]}>
        <View style={[styles.logHead,{backgroundColor: ide.panel}]}>
          <Pressable onPress={()=>setDockTab('output')} style={styles.dockTab}><Text style={[styles.dockTabText,{color: dockTab==='output'? ide.panelText: ide.panelTextDim}, dockTab==='output'&&styles.dockTabActive]}>{copy.output.toUpperCase()}</Text></Pressable>
          <Pressable onPress={()=>setDockTab('problems')} style={styles.dockTab}><Text style={[styles.dockTabText,{color: dockTab==='problems'? (totalErrors?'#F14C4C':ide.panelText):ide.panelTextDim}, dockTab==='problems'&&styles.dockTabActive]}>{`${copy.problems.toUpperCase()}${(totalErrors+totalWarnings)? ` (${totalErrors+totalWarnings})`:''}`}</Text></Pressable>
          <View style={{flex:1}} />
          {logMode!=='hidden' && dockTab==='output'? <Pressable onPress={clearWorkspaceLogs} style={styles.logAction}><Icon name="trash-outline" size={13} color={ide.panelTextDim} /><Text style={[styles.logActionText,{color: ide.panelTextDim}]}>{copy.clear}</Text></Pressable>:null}
          <SegmentedControl compact value={logMode} onChange={setLogMode} options={[{value:'hidden',label:'',icon:'chevron-down-outline',flex:false},{value:'half',label:'',icon:'remove-outline',flex:false},{value:'full',label:'',icon:'chevron-up-outline',flex:false}]} />
        </View>
        {logMode!=='hidden' ? (
          dockTab==='problems' ? (
            <ScrollView style={styles.logs} contentContainerStyle={{padding:8}}>
              <Pressable onPress={runBuildCheck} style={[styles.checkBanner,{borderColor: ide.panelBorder, backgroundColor: editorTheme==='light'? '#FFFFFF':'#2D2D30'}]} disabled={build.running}>
                {build.running? <ActivityIndicator size={14} color="#569CD6" />: <Icon name={build.ok? 'checkmark-circle':'alert-circle-outline'} size={15} color={build.ok? '#4EC9B0':'#F14C4C'} />}
                <Text style={{flex:1,color: ide.panelTextDim, fontSize:10.5, fontFamily:'monospace'}} numberOfLines={2}>{build.running? 'vite build …' : build.at? `${build.ok? copy.checkOk: copy.checkFailed} · ${new Date(build.at).toLocaleTimeString()}`: 'Нажмите чтобы проверить: npm run build'}</Text>
                {!build.running? <Icon name="refresh" size={14} color="#569CD6" />:null}
              </Pressable>
              {activeProblems.map((p,i)=>(
                <Pressable key={i} style={styles.logRow} onPress={()=>editorApi.current?.command('gotoLine', p.line)}>
                  <Icon name={p.severity==='warning'?'warning':'close-circle'} size={13} color={p.severity==='warning'? '#CCA700':'#F14C4C'} />
                  <Text style={[styles.logText,{color: ide.panelText}]}>{p.message}</Text><Text style={[styles.logTime,{width:'auto'}]}>{p.line}:{p.col}</Text>
                </Pressable>
              ))}
              {activeProblems.length===0? <View style={styles.noProblems}><Icon name="checkmark-circle-outline" size={15} color="#4EC9B0" /><Text style={[styles.logText,{color: ide.panelTextDim}]}>{copy.noProblems}</Text></View>:null}
              {build.output? <View style={{marginTop:8, padding:8, backgroundColor: editorTheme==='light'? '#FFFFFF':'#1E1E1E', borderRadius:6}}><Text selectable style={{color: ide.panelTextDim, fontFamily:'monospace', fontSize:9}}>{build.output.slice(0,6000)}</Text></View>:null}
            </ScrollView>
          ) : (
            <ScrollView style={styles.logs} contentContainerStyle={{padding:8}}>
              {logs.map(log=>(
                <View key={log.id} style={styles.logRow}><Text style={styles.logTime}>{new Date(log.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</Text><Icon name={log.level==='success'?'checkmark-circle-outline': log.level==='error'?'alert-circle-outline':'information-circle-outline'} size={13} color={log.level==='success'? '#4EC9B0': log.level==='error'? '#F14C4C':'#569CD6'} /><Text selectable style={[styles.logText,{color: ide.panelText}]}>{log.text}</Text></View>
              ))}
            </ScrollView>
          )
        ):null}
      </View>

      {explorerOpen && !wide? <Modal visible transparent animationType="fade" onRequestClose={()=>setExplorerOpen(false)}><Pressable style={styles.explorerOverlay} onPress={()=>setExplorerOpen(false)}><Pressable style={[styles.explorerDrawer,{width: Math.min(width*0.82,340), paddingTop: insets.top, paddingBottom: insets.bottom}]} onPress={e=>e.stopPropagation?.()}><FileExplorer project={currentProject} activePath={activeFile?.path} onOpenFile={(path)=>{onOpenFile(path); if(!wide) setExplorerOpen(false);}} onClose={()=>setExplorerOpen(false)} /></Pressable></Pressable></Modal>:null}
      <Modal visible={settingsOpen} transparent animationType="fade" onRequestClose={()=>setSettingsOpen(false)}><View style={styles.overlay}><View style={styles.settingsCard}><EditorSettings onClose={()=>setSettingsOpen(false)} /></View></View></Modal>
      <Modal visible={gotoOpen} transparent animationType="fade" onRequestClose={()=>setGotoOpen(false)}><View style={styles.overlay}><SectionCard style={styles.gotoDialog} title={copy.gotoLine} icon="return-down-forward-outline"><TextInput autoFocus value={gotoValue} onChangeText={setGotoValue} onSubmitEditing={()=>{ const n=parseInt(gotoValue,10); setGotoOpen(false); setGotoValue(''); if(Number.isFinite(n)) editorApi.current?.command('gotoLine', n); }} placeholder={`${copy.lineNumber} (1-${Math.max(cursorInfo.lines||1, 0)})`} placeholderTextColor={colors.textTertiary} keyboardType="number-pad" style={styles.input} /><View style={{flexDirection:'row',gap:8}}><IconButton name="close" label={t('cancel')} onPress={()=>setGotoOpen(false)} style={{flex:1}} /><PrimaryButton title={copy.goto} icon="arrow-forward" disabled={!gotoValue.trim()} onPress={()=>{ const n=parseInt(gotoValue,10); setGotoOpen(false); setGotoValue(''); if(Number.isFinite(n)) editorApi.current?.command('gotoLine', n); }} style={{flex:1}} /></View></SectionCard></View></Modal>
      <Modal visible={screenMenu} transparent animationType="fade" onRequestClose={()=>setScreenMenu(false)}><Pressable style={styles.overlay} onPress={()=>setScreenMenu(false)}><SectionCard style={styles.screenDialog} title={t('screens')} icon="layers-outline">{currentProject.screens.map(screen=>(<View key={screen.id} style={[styles.screenRow, screen.id===currentScreenId && styles.screenRowActive]}><Pressable style={styles.screenRowMain} onPress={()=>{ setScreenMenu(false); guardUnsaved(()=>setCurrentScreen(screen.id)); }}><Icon name="logo-react" size={16} color={screen.id===currentScreenId? colors.primary: colors.textSecondary} /><Text style={styles.screenRowText}>{screen.name}</Text></Pressable><IconButton name="copy-outline" onPress={()=>duplicateScreen(screen.id)} style={styles.rowButton} /><IconButton name="trash-outline" danger onPress={()=>removeScreen(screen.id)} style={styles.rowButton} /></View>))}<PrimaryButton title={t('addScreen')} icon="add" onPress={()=>{ setScreenMenu(false); setNewScreenOpen(true); }} /></SectionCard></Pressable></Modal>
      <Modal visible={newScreenOpen} transparent animationType="fade" onRequestClose={()=>setNewScreenOpen(false)}><View style={styles.overlay}><SectionCard style={styles.newDialog} title={t('addScreen')} icon="logo-react"><TextInput autoFocus value={newScreenName} onChangeText={setNewScreenName} onSubmitEditing={createScreen} placeholder={copy.screenName} placeholderTextColor={colors.textTertiary} style={styles.input} /><View style={{flexDirection:'row',gap:8}}><IconButton name="close" label={t('cancel')} onPress={()=>setNewScreenOpen(false)} style={{flex:1}} /><PrimaryButton title={t('addScreen')} icon="add" disabled={!newScreenName.trim()} onPress={createScreen} style={{flex:1}} /></View></SectionCard></View></Modal>
    </AppScreen>
  );
};

const createStyles=(c)=>StyleSheet.create({
  center:{flex:1,alignItems:'center',justifyContent:'center',gap:12,padding:20},
  emptyText:{color:c.textSecondary,fontSize:14,textAlign:'center',paddingHorizontal:24},
  workspaceBar:{minHeight:44,flexDirection:'row',alignItems:'center',paddingHorizontal:8,gap:6,backgroundColor:c.bgCard,borderBottomWidth:1,borderBottomColor:c.border},
  screenSelect:{minWidth:104,maxWidth:200,flexShrink:1,height:32,paddingHorizontal:9,flexDirection:'row',alignItems:'center',gap:6,borderRadius:7,backgroundColor:c.bgElevated,borderWidth:1,borderColor:c.border},
  screenText:{color:c.text,fontSize:11,fontWeight:'650',flex:1},
  modeTabs:{paddingHorizontal:4,gap:2,alignItems:'center'},
  modeTab:{height:33,paddingHorizontal:11,borderRadius:7,flexDirection:'row',alignItems:'center',gap:6},
  modeTabActive:{backgroundColor:c.primarySurface},
  modeTabText:{color:c.textSecondary,fontSize:11,fontWeight:'600'},
  modeTabTextActive:{color:c.primary,fontWeight:'750'},
  main:{flex:1,flexDirection:'row',minHeight:0},
  explorerWrap:{borderRightWidth:1,borderRightColor:c.border},
  content:{flex:1,minWidth:0},
  previewWrap:{flex:1,minHeight:0,backgroundColor:c.canvas},
  previewHead:{height:40,paddingHorizontal:14,flexDirection:'row',alignItems:'center',gap:8,backgroundColor:c.bgCard,borderBottomWidth:1,borderBottomColor:c.border},
  previewTitle:{color:c.text,fontSize:12,fontWeight:'700'},
  previewControl:{height:28,paddingHorizontal:8,borderRadius:7,flexDirection:'row',alignItems:'center',gap:4,backgroundColor:c.primarySurface,borderWidth:1,borderColor:c.border},
  previewControlText:{color:c.primary,fontSize:10,fontFamily:'monospace',fontWeight:'700'},
  deviceFrame:{backgroundColor:'#FFFFFF',borderRadius:28,overflow:'hidden',borderWidth:7,borderColor:'#111827',shadowColor:c.shadow,shadowOpacity:0.18,shadowRadius:18,elevation:10},
  deviceHead:{height:28,paddingHorizontal:14,flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:'#fff'},
  deviceFoot:{height:28,alignItems:'center',justifyContent:'center',backgroundColor:'#fff'},
  previewScroll:{padding:14,paddingBottom:40,alignItems:'center'},
  codeWrap:{flex:1,minHeight:0},
  tabStrip:{height:35,borderBottomWidth:1},
  fileTab:{height:35,paddingHorizontal:10,flexDirection:'row',alignItems:'center',gap:6,maxWidth:200,borderRightWidth:1,borderTopWidth:2,borderTopColor:'transparent'},
  fileTabText:{fontSize:11.5,fontWeight:'500',flexShrink:1},
  fileTabClose:{width:18,height:18,borderRadius:4,alignItems:'center',justifyContent:'center'},
  fileTabAdd:{width:34,height:35,alignItems:'center',justifyContent:'center'},
  dirtyDot:{width:8,height:8,borderRadius:4,backgroundColor:'#569CD6'},
  crumbs:{minHeight:30,paddingHorizontal:8,flexDirection:'row',alignItems:'center',gap:5,borderBottomWidth:1},
  crumb:{fontSize:10.5,fontFamily:'monospace'},
  readOnlyChip:{flexDirection:'row',alignItems:'center',gap:3,paddingHorizontal:6,height:20,borderRadius:9,backgroundColor:'rgba(133,133,133,0.18)'},
  readOnlyChipText:{fontSize:9,fontWeight:'600'},
  savingText:{fontSize:10,marginHorizontal:4},
  problemsBtn:{flexDirection:'row',alignItems:'center',gap:3,paddingHorizontal:7,height:22,borderRadius:6},
  problemsCount:{color:'#F14C4C',fontSize:11,fontWeight:'750'},
  warningsCount:{color:'#CCA700',fontSize:11,fontWeight:'750'},
  checkingText:{color:'#569CD6',fontSize:10.5,fontWeight:'600',marginLeft:3},
  checkBanner:{flexDirection:'row',alignItems:'center',gap:8,paddingHorizontal:10,paddingVertical:7,borderRadius:8,borderWidth:1,marginBottom:7},
  importBtn:{flexDirection:'row',alignItems:'center',gap:3,paddingHorizontal:7,height:22,borderRadius:6},
  importBtnText:{color:'#C586C0',fontSize:11,fontWeight:'750'},
  importBar:{minHeight:30,paddingHorizontal:12,flexDirection:'row',alignItems:'center',gap:8,backgroundColor:'rgba(197,134,192,0.12)',borderBottomWidth:1,borderBottomColor:'rgba(197,134,192,0.25)'},
  importText:{color:'#C586C0',fontSize:11.5,fontWeight:'650',flex:1},
  toolbar:{height:42,borderTopWidth:1},
  toolbarSep:{width:1,height:22,marginHorizontal:5},
  statusBar:{minHeight:24,paddingHorizontal:8,flexDirection:'row',alignItems:'center',gap:12},
  statusItem:{flexDirection:'row',alignItems:'center',gap:4,minHeight:24},
  statusText:{color:'#FFFFFF',fontSize:10.5,fontFamily:'monospace',includeFontPadding:false},
  logDock:{borderTopWidth:1,overflow:'hidden'},
  logHead:{height:34,paddingHorizontal:6,flexDirection:'row',alignItems:'center',gap:4},
  dockTab:{paddingHorizontal:9,height:34,justifyContent:'center'},
  dockTabText:{fontSize:10,fontWeight:'700',letterSpacing:0.6},
  dockTabActive:{borderBottomWidth:2,borderBottomColor:'#569CD6'},
  logAction:{flexDirection:'row',alignItems:'center',gap:4,paddingHorizontal:7},
  logActionText:{fontSize:9},
  logs:{flex:1},
  logRow:{minHeight:22,flexDirection:'row',alignItems:'flex-start',gap:7},
  logTime:{color:'#858585',fontSize:9,fontFamily:'monospace',width:55,marginTop:1},
  logText:{fontSize:10.5,lineHeight:15,fontFamily:'monospace',flex:1},
  noProblems:{flexDirection:'row',alignItems:'center',gap:7,paddingVertical:4},
  overlay:{flex:1,justifyContent:'center',padding:18,backgroundColor:c.overlay},
  settingsCard:{width:'100%',maxWidth:460,maxHeight:'85%',alignSelf:'center',borderRadius:16,overflow:'hidden',backgroundColor:c.bgCard,flexShrink:1},
  explorerOverlay:{flex:1,backgroundColor:'rgba(0,0,0,0.5)',flexDirection:'row'},
  explorerDrawer:{height:'100%',backgroundColor:c.bgCard,overflow:'hidden'},
  screenDialog:{width:'100%',maxWidth:500,alignSelf:'center'},
  newDialog:{width:'100%',maxWidth:430,alignSelf:'center'},
  gotoDialog:{width:'100%',maxWidth:380,alignSelf:'center'},
  screenRow:{minHeight:48,flexDirection:'row',alignItems:'center',borderRadius:9,borderWidth:1,borderColor:'transparent'},
  screenRowActive:{backgroundColor:c.primarySurface,borderColor:c.primary},
  screenRowMain:{flex:1,minHeight:46,flexDirection:'row',alignItems:'center',gap:9,paddingHorizontal:11},
  screenRowText:{color:c.text,fontSize:12,fontWeight:'650'},
  rowButton:{width:36,minWidth:36,height:36,borderWidth:0,backgroundColor:'transparent'},
  input:{minHeight:46,borderRadius:10,paddingHorizontal:12,backgroundColor:c.bgInput,borderWidth:1,borderColor:c.borderLight,color:c.text,fontSize:13},
});

export default EditorScreen;