import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, BackHandler, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import CodeMirrorEditor from '../ide/CodeMirrorEditor';
import NativeComposePreview from '../components/NativeComposePreview';
import FileExplorer from '../components/FileExplorer';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { writeScreenSource, generateComposePreviewSource } from '../utils/composeProject';
import { loadRaiActivities, parseActivitySource } from '../utils/activityTree';
import { findMissingImports, addMissingImports, fileStats } from '../utils/importManager';
import { parseBuildErrors } from '../utils/errorParser';
import { analyzeKotlin, summarizeProblems } from '../utils/kotlinAnalyzer';
import { readProjectFile, writeProjectFile, listProjectFiles } from '../utils/projectFiles';
import { execute } from '../utils/shellExecutor';
import { getSourceRoot, getProjectDir } from '../config/runtime';
import EditorSettings from '../components/EditorSettings';

const fileIcon = (ext) => {
  switch (ext) {
    case 'kt': return { name: 'logo-android', color: '#3DDC84' };
    case 'kts': return { name: 'settings-outline', color: '#7C5CFF' };
    case 'xml': return { name: 'code-outline', color: '#E8863A' };
    case 'json': return { name: 'braces-outline', color: '#F7C948' };
    case 'properties': return { name: 'settings-outline', color: '#7FB8E8' };
    case 'md': return { name: 'document-text-outline', color: '#7FB8E8' };
    case 'gradle': return { name: 'construct-outline', color: '#7FB8E8' };
    default: return { name: 'document-outline', color: '#8B98AD' };
  }
};

const SYMBOL_KEYS = ['{', '}', '(', ')', '[', ']', '<', '>', '=', ';', ':', '.', ',', '"', "'", '$', '_', '|', '&', '?', '!', '/', '-', '+', '*', '%', '#', '@'];
const TOOL_COMMANDS = [
  { name: 'undo', icon: 'arrow-undo-outline' },
  { name: 'redo', icon: 'arrow-redo-outline' },
  { name: 'search', icon: 'search-outline' },
  { name: 'comment', icon: 'chatbox-ellipses-outline' },
  { name: 'indentMore', icon: 'arrow-forward-outline' },
  { name: 'indentLess', icon: 'arrow-back-outline' },
];

/**
 * The IDE screen, laid out like VS Code:
 *   activity/mode bar → file tabs → breadcrumbs+actions → CodeMirror editor →
 *   symbol toolbar → VS Code style accent status bar → output/problems panel.
 */
const EditorScreen = ({ navigation }) => {
  const { width, height } = useWindowDimensions();
  const {
    currentProject, currentScreenId, setCurrentScreen, addScreen, deleteScreen, duplicateScreen,
    workspaceLogs, clearWorkspaceLogs, addWorkspaceLog, closeProject, dispatch, updateScreen,
  } = useProject();
  const { colors, language, t, editor, setEditorSetting, resolvedTheme } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const insets = useSafeAreaInsets();
  const wide = width >= 900;
  const editorTheme = resolvedTheme === 'dark' ? 'dark' : 'light';
  // VS Code surface colours of the editing surface itself.
  const ide = useMemo(() => (editorTheme === 'light' ? {
    editorBg: '#FFFFFF', panel: '#F3F3F3', panelBorder: '#D4D4D4', panelText: '#424242',
    panelTextDim: '#6E6E6E', status: '#007ACC',
  } : {
    editorBg: '#1E1E1E', panel: '#252526', panelBorder: '#3C3C3C', panelText: '#CCCCCC',
    panelTextDim: '#858585', status: '#007ACC',
  }), [editorTheme]);

  const [activeTab, setActiveTab] = useState('editor');
  const [screenMenu, setScreenMenu] = useState(false);
  const [explorerOpen, setExplorerOpen] = useState(false);
  const [newScreenOpen, setNewScreenOpen] = useState(false);
  const [newScreenName, setNewScreenName] = useState('');
  const [logMode, setLogMode] = useState('hidden');
  const [dockTab, setDockTab] = useState('output');
  const [saving, setSaving] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [activeFile, setActiveFile] = useState(null); // { path, name, isScreen }
  const [openTabs, setOpenTabs] = useState([]);
  const [dirtyByPath, setDirtyByPath] = useState({});
  const [missingList, setMissingList] = useState([]);
  const [formatStats, setFormatStats] = useState({ lineCount: 0, chars: 0 });
  const [lintProblems, setLintProblems] = useState([]);
  const [cursorInfo, setCursorInfo] = useState({ line: 1, col: 1, lines: 0, canUndo: false, canRedo: false });
  const [gotoOpen, setGotoOpen] = useState(false);
  const [gotoValue, setGotoValue] = useState('');
  // Real compiler results of `gradlew compileDebugKotlin`, grouped per file.
  const [compiler, setCompiler] = useState({ running: false, byFile: {}, fileless: [], ran: false, success: false, at: 0 });

  const editorApi = useRef(null);
  const draftRef = useRef('');
  const savedRef = useRef({});
  const dirtyRef = useRef({});
  const closingRef = useRef(false);
  const saveTimerRef = useRef(null);
  const lintTimerRef = useRef(null);
  const autoCheckAtRef = useRef(0); // last background compile start (throttle)
  const runCompilerCheckRef = useRef(null); // stable bridge for early effects
  const latestProjectRef = useRef(currentProject);
  useEffect(() => { latestProjectRef.current = currentProject; }, [currentProject]);

  const currentScreen = currentProject?.screens?.find((screen) => screen.id === currentScreenId);
  const readOnly = activeFile ? activeFile.isScreen === true && currentScreen?.readOnly === true : false;

  const screenFilePath = useMemo(() => {
    if (!currentProject || !currentScreen) return null;
    return `${getSourceRoot(currentProject)}/${currentScreen.name}Activity.kt`;
  }, [currentProject, currentScreen]);

  const ru = language === 'ru';
  const copy = ru ? {
    noProject: 'Проект не открыт',
    screenName: 'Название экрана',
    deleteScreen: 'Удалить экран?',
    lastScreen: 'Нельзя удалить единственный экран.',
    consoleReady: 'Редактор готов. Откройте файл слева или сохраните код.',
    clear: 'Очистить',
    output: 'Вывод',
    problems: 'Проблемы',
    noProblems: 'Проблем не найдено',
    closing: 'Сохраняем и закрываем проект…',
    save: 'Сохранить',
    saving: 'Сохранение…',
    saved: 'Файл записан на диск',
    saveFailed: 'Ошибка сохранения',
    codePlaceholder: '// Введите код Kotlin…',
    design: 'Дизайн',
    editor: 'Редактор',
    readOnly: 'Только чтение',
    unsaved: 'Несохранённые изменения',
    unsavedHint: 'Что сделать с изменениями перед переключением?',
    discard: 'Не сохранять',
    unsavedSave: 'Сохранить',
    gotoLine: 'Перейти к строке',
    lineNumber: 'Номер строки',
    goto: 'Перейти',
    openFile: 'Открыть файл',
    fallback: 'WebView недоступен — включён простой редактор',
    importsFix: 'Добавить недостающие импорты',
    checkCode: 'Проверить код',
    checkRunning: 'Компиляция…',
    checkStart: 'Запущена проверка компилятором: compileDebugKotlin',
    checkOk: 'Ошибок компилятора нет — код собирается',
    checkFailed: 'Не удалось запустить проверку',
    checkFound: 'Результат проверки',
    editorProblems: 'Анализ редактора',
    compilerProblems: 'Компилятор',
    notChecked: 'Проверка компилятором ещё не запускалась',
    fileNotFound: 'Файл не найден в проекте',
    otherFiles: 'Другие файлы',
  } : {
    noProject: 'No project is open',
    screenName: 'Screen name',
    deleteScreen: 'Delete screen?',
    lastScreen: 'The only screen cannot be deleted.',
    consoleReady: 'Editor ready. Open a file on the left or save the code.',
    clear: 'Clear',
    output: 'Output',
    problems: 'Problems',
    noProblems: 'No problems detected',
    closing: 'Saving and closing project…',
    save: 'Save',
    saving: 'Saving…',
    saved: 'File written to disk',
    saveFailed: 'Save failed',
    codePlaceholder: '// Enter your Kotlin code…',
    design: 'Design',
    editor: 'Editor',
    readOnly: 'Read only',
    unsaved: 'Unsaved changes',
    unsavedHint: 'What should happen to the changes before switching?',
    discard: "Don't save",
    unsavedSave: 'Save',
    gotoLine: 'Go to line',
    lineNumber: 'Line number',
    goto: 'Go',
    openFile: 'Open file',
    fallback: 'WebView unavailable — basic editor enabled',
    importsFix: 'Add missing imports',
    checkCode: 'Check code',
    checkRunning: 'Compiling…',
    checkStart: 'Compiler check started: compileDebugKotlin',
    checkOk: 'No compiler errors — the code builds',
    checkFailed: 'Could not run the compiler check',
    checkFound: 'Check result',
    editorProblems: 'Editor analysis',
    compilerProblems: 'Compiler',
    notChecked: 'Compiler check has not run yet',
    fileNotFound: 'File not found in the project',
    otherFiles: 'Other files',
  };

  const setDirtyState = useCallback((path, flag) => {
    dirtyRef.current = { ...dirtyRef.current, [path]: flag };
    setDirtyByPath((prev) => ({ ...prev, [path]: flag }));
  }, []);

  /* -------------------------------------------------- document lifecycle */

  // A screen switch loads that screen's source straight from the project model
  // (previously this reused the stale draft of the file being left).
  useEffect(() => {
    if (!currentScreen || !screenFilePath) return;
    const source = (currentScreen.source != null && currentScreen.source !== '')
      ? currentScreen.source
      : generateComposePreviewSource(latestProjectRef.current || currentProject, currentScreen, 0);
    const tab = { path: screenFilePath, name: `${currentScreen.name}Activity.kt`, isScreen: true };
    savedRef.current[screenFilePath] = source;
    draftRef.current = source;
    setDraft(source);
    setActiveFile(tab);
    setOpenTabs((prev) => [tab, ...prev.filter((t2) => !t2.isScreen)]);
    setDirtyState(screenFilePath, false);
  }, [currentScreen?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Debounced heavy analyses (instant analyzer/imports/stats) so typing stays
  // responsive. The analyzer understands Compose scopes (composable context,
  // remember() placement, deprecations, typo hints) plus structural errors.
  useEffect(() => {
    if (lintTimerRef.current) clearTimeout(lintTimerRef.current);
    lintTimerRef.current = setTimeout(() => {
      setFormatStats(fileStats(draft));
      setLintProblems(analyzeKotlin(draft));
      setMissingList(findMissingImports(draft).missing);
    }, 300);
    return () => { if (lintTimerRef.current) clearTimeout(lintTimerRef.current); };
  }, [draft]);

  const handleEditorChange = useCallback((text) => {
    draftRef.current = text;
    setDraft(text);
    const path = activeFile?.path;
    if (path) setDirtyState(path, text !== (savedRef.current[path] ?? ''));
  }, [activeFile?.path, setDirtyState]);

  const applyMissingImports = useCallback(() => {
    const withImports = addMissingImports(draftRef.current, missingList);
    if (withImports !== draftRef.current) {
      draftRef.current = withImports;
      setDraft(withImports);
      setMissingList([]);
      addWorkspaceLog(ru ? `Добавлено импортов: ${missingList.length}` : `Added ${missingList.length} import(s)`, 'success');
    }
  }, [missingList, addWorkspaceLog, ru]);

  const doSave = useCallback(async (silent = false) => {
    if (!currentProject) return { success: false };
    const content = draftRef.current;
    if (activeFile && activeFile.isScreen && currentScreen) {
      const result = await writeScreenSource(latestProjectRef.current || currentProject, currentScreen, content);
      if (result?.success) {
        const parsed = parseActivitySource(content);
        updateScreen({
          ...currentScreen,
          source: content,
          rootComponent: parsed.tree,
          preamble: parsed.preamble || [],
          readOnly: false,
        });
        savedRef.current[activeFile.path] = content;
        setDirtyState(activeFile.path, false);
        if (!silent) addWorkspaceLog(`${copy.saved} · ${currentScreen.name}Activity.kt`, 'success');
      } else if (!silent) {
        addWorkspaceLog(result?.output || copy.saveFailed, 'error');
      }
      return result;
    }
    if (activeFile) {
      const result = await writeProjectFile(latestProjectRef.current || currentProject, activeFile.path, content);
      if (result?.success) {
        savedRef.current[activeFile.path] = content;
        setDirtyState(activeFile.path, false);
        if (!silent) addWorkspaceLog(`${copy.saved} · ${activeFile.name}`, 'success');
      } else if (!silent) {
        addWorkspaceLog(result?.output || copy.saveFailed, 'error');
      }
      return result;
    }
    return { success: false };
  }, [currentProject, currentScreen, activeFile, updateScreen, addWorkspaceLog, copy.saved, copy.saveFailed, setDirtyState]);

  useEffect(() => {
    if (!editor.autoSave || !currentProject) return undefined;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => {
      doSave(true).then((result) => {
        // Background compiler pulse while editing: at most once per 45 s and
        // never overlapping (runCompilerCheck no-ops while one is running) —
        // real compiler errors appear in Problems without any button press.
        if (!result?.success || editor.autoCheck === false) return;
        const now = Date.now();
        if (now - autoCheckAtRef.current < 45000) return;
        autoCheckAtRef.current = now;
        runCompilerCheckRef.current?.();
      });
    }, 1200);
    return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); };
  }, [draft, editor.autoSave, editor.autoCheck, activeFile?.path]);

  // (saveNow lives further below, after runCompilerCheck — a manual save
  // triggers the background compiler check when editor.autoCheck is on)

  /** Run `next()` only after unsaved changes are handled (save / discard). */
  const guardUnsaved = useCallback((next) => {
    const path = activeFile?.path;
    if (!path || !dirtyRef.current[path]) { next(); return; }
    if (editor.autoSave) { doSave(true).finally(next); return; }
    Alert.alert(copy.unsaved, copy.unsavedHint, [
      { text: t('cancel'), style: 'cancel' },
      { text: copy.discard, style: 'destructive', onPress: () => { setDirtyState(path, false); next(); } },
      { text: copy.unsavedSave, onPress: async () => { await doSave(true); next(); } },
    ]);
  }, [activeFile?.path, editor.autoSave, doSave, t, copy.unsaved, copy.unsavedHint, copy.discard, copy.unsavedSave, setDirtyState]);

  const openFileByPath = useCallback(async (path) => {
    if (!currentProject) return;
    if (activeFile?.path === path) return;
    try {
      const read = await readProjectFile(currentProject, path);
      const name = path.split('/').pop() || path;
      const text = read.output || '';
      const tab = { path, name, isScreen: false };
      savedRef.current[path] = text;
      draftRef.current = text;
      setDraft(text);
      setActiveFile(tab);
      setOpenTabs((prev) => (prev.some((t2) => t2.path === path) ? prev : [...prev, tab]));
      setDirtyState(path, false);
      addWorkspaceLog(`${ru ? 'Открыт файл' : 'Opened'}: ${path}`, 'info');
    } catch (e) {
      addWorkspaceLog(`Open failed: ${e?.message || String(e)}`, 'error');
    }
  }, [currentProject, activeFile?.path, addWorkspaceLog, ru]);

  const onOpenFile = useCallback((path) => {
    if (activeFile?.path === path) return;
    guardUnsaved(() => { openFileByPath(path); });
  }, [activeFile?.path, guardUnsaved, openFileByPath]);

  /** Load the source of the screen tab's screen into the editor. Handles both
   * cases: the tab belongs to another screen (switch screens, the screen
   * effect then loads the source) or to the current screen (load directly). */
  const activateScreenTab = useCallback((tab) => {
    const project = latestProjectRef.current;
    const screen = (project?.screens || []).find((s) => `${s.name}Activity.kt` === tab.name);
    if (!screen) return;
    if (screen.id !== currentScreenId) {
      setCurrentScreen(screen.id);
      return;
    }
    const source = (screen.source != null && screen.source !== '')
      ? screen.source
      : generateComposePreviewSource(project, screen, 0);
    savedRef.current[tab.path] = source;
    draftRef.current = source;
    setDraft(source);
    setActiveFile(tab);
    setDirtyState(tab.path, false);
  }, [currentScreenId, setCurrentScreen, setDirtyState]);

  const activateTab = useCallback((tab) => {
    if (!tab || tab.path === activeFile?.path) return;
    guardUnsaved(() => {
      if (tab.isScreen) activateScreenTab(tab);
      else openFileByPath(tab.path);
    });
  }, [activeFile?.path, guardUnsaved, activateScreenTab, openFileByPath]);

  const closeTab = useCallback((tab) => {
    if (tab.isScreen) return; // the screen tab always stays open
    const finish = () => {
      const rest = openTabs.filter((t2) => t2.path !== tab.path);
      setOpenTabs(rest);
      if (activeFile?.path === tab.path) {
        const nextFile = rest.find((t2) => !t2.isScreen) || rest[0];
        if (nextFile && !nextFile.isScreen) openFileByPath(nextFile.path);
        else if (nextFile) activateScreenTab(nextFile);
      }
    };
    if (dirtyRef.current[tab.path]) guardUnsaved(finish); else finish();
  }, [activeFile?.path, openTabs, guardUnsaved, openFileByPath, activateScreenTab]);

  /** Run the REAL Kotlin compiler (gradlew compileDebugKotlin inside the
   * project workspace) and turn its diagnostics into editor problems. */
  const runCompilerCheck = useCallback(async () => {
    if (compiler.running || !currentProject) return;
    setCompiler((c) => ({ ...c, running: true }));
    addWorkspaceLog(copy.checkStart, 'info');
    try {
      await doSave(true);
      const cwd = getProjectDir(latestProjectRef.current || currentProject);
      const result = await execute('chmod +x ./gradlew && ./gradlew compileDebugKotlin --console=plain', cwd);
      const output = result?.output || '';
      const { errors, warnings } = parseBuildErrors(output);
      const byFile = {};
      const fileless = [];
      const push = (p) => {
        const entry = {
          line: p.line, col: p.column, message: p.message,
          severity: p.severity === 'warning' ? 'warning' : 'error',
        };
        const name = p.file ? p.file.split(/[\\/]/).pop() : null;
        if (!name) { fileless.push(entry); return; }
        if (!byFile[name]) byFile[name] = [];
        byFile[name].push(entry);
      };
      errors.forEach(push);
      warnings.forEach(push);
      const total = errors.length + warnings.length;
      const success = result?.success === true && errors.length === 0;
      setCompiler({ running: false, byFile, fileless, ran: true, success, at: Date.now() });
      addWorkspaceLog(
        success
          ? copy.checkOk
          : total
            ? `${copy.checkFound}: ${errors.length} ✕, ${warnings.length} ⚠`
            : `${copy.checkFailed}: ${output.split('\n').filter(Boolean).slice(-2).join(' ') || 'unknown'}`,
        success ? 'success' : 'error',
      );
      if (!success && total > 0) { setDockTab('problems'); setLogMode('half'); }
    } catch (e) {
      setCompiler((c) => ({ ...c, running: false }));
      addWorkspaceLog(`${copy.checkFailed}: ${e?.message || String(e)}`, 'error');
    }
  }, [compiler.running, currentProject, doSave, addWorkspaceLog, copy.checkStart, copy.checkOk, copy.checkFailed, copy.checkFound]);

  // Keep a ref to the latest checker so the early autosave effect can call it.
  useEffect(() => { runCompilerCheckRef.current = runCompilerCheck; }, [runCompilerCheck]);

  /** Manual save — also kicks the background compiler check when enabled, so
   * real compiler errors surface in Problems without the user pressing
   * anything or waiting next to a button. */
  const saveNow = useCallback(async () => {
    if (saving || !currentProject) return;
    setSaving(true);
    let savedOk = false;
    try {
      const result = await doSave(false);
      savedOk = !!result?.success;
      if (!savedOk) addWorkspaceLog(copy.saveFailed, 'error');
    } catch (error) {
      addWorkspaceLog(`${copy.saveFailed}: ${error?.message || String(error)}`, 'error');
    } finally {
      setSaving(false);
    }
    if (savedOk && editor.autoCheck !== false) {
      autoCheckAtRef.current = Date.now(); // don't let the autosave pulse repeat it
      runCompilerCheck();
    }
  }, [saving, currentProject, doSave, addWorkspaceLog, copy.saveFailed, editor.autoCheck, runCompilerCheck]);

  /** Jump to a problem — possibly in another file (opens it first). */
  const openProblemFile = useCallback(async (fileName, lineNo) => {
    if (!fileName || (activeFile?.name === fileName)) {
      editorApi.current?.command('gotoLine', lineNo);
      return;
    }
    const project = latestProjectRef.current;
    const screen = (project?.screens || []).find((s) => `${s.name}Activity.kt` === fileName);
    const reveal = () => setTimeout(() => editorApi.current?.command('gotoLine', lineNo), 700);
    if (screen) {
      guardUnsaved(() => {
        if (screen.id !== currentScreenId) setCurrentScreen(screen.id);
        else activateScreenTab({ path: screenFilePath, name: fileName, isScreen: true });
        reveal();
      });
      return;
    }
    try {
      const files = await listProjectFiles(project);
      const found = files.find((f) => f.name === fileName);
      if (found) {
        guardUnsaved(() => { openFileByPath(found.path); reveal(); });
      } else {
        addWorkspaceLog(`${copy.fileNotFound}: ${fileName}`, 'warning');
      }
    } catch (e) {
      addWorkspaceLog(`${copy.fileNotFound}: ${fileName}`, 'warning');
    }
  }, [activeFile?.name, currentScreenId, screenFilePath, guardUnsaved, activateScreenTab, openFileByPath, setCurrentScreen, addWorkspaceLog, copy.fileNotFound]);

  const closeAndExit = useCallback(async () => {
    if (closingRef.current) return;
    closingRef.current = true;
    if (currentProject) {
      addWorkspaceLog(copy.closing, 'info');
      try { await doSave(false); } catch (error) {}
    }
    try { await closeProject(); } catch (error) {}
    navigation.reset({ index: 0, routes: [{ name: 'Projects' }] });
  }, [currentProject, closeProject, navigation, copy.closing, addWorkspaceLog, doSave]);

  useFocusEffect(useCallback(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      closeAndExit();
      return true;
    });
    return () => subscription.remove();
  }, [closeAndExit]));

  useEffect(() => navigation.addListener('beforeRemove', (event) => {
    if (closingRef.current) return;
    event.preventDefault();
    closeAndExit();
  }), [navigation, closeAndExit]);

  // Hydrate the project's screens from the *Activity.kt files on disk.
  const hydratedFor = useRef(null);
  useFocusEffect(useCallback(() => {
    if (!currentProject) return undefined;
    if (hydratedFor.current === currentProject.id) return undefined;
    hydratedFor.current = currentProject.id;
    let cancelled = false;
    (async () => {
      try {
        const activities = await loadRaiActivities(currentProject);
        if (cancelled) return;
        if (!activities.length) {
          addWorkspaceLog(
            ru ? 'Нет *Activity.kt файлов в proot. Нажмите «+» чтобы создать экран.' : 'No *Activity.kt files in proot. Press + to add a screen.',
            'info',
          );
          return;
        }
        const screens = activities.map((a) => ({
          id: a.id,
          name: a.name,
          fileName: a.fileName,
          rootComponent: a.rootComponent,
          blocks: a.blocks || [],
          readOnly: a.readOnly === true,
          hasUserFunction: a.hasUserFunction === true,
          rootName: a.rootName || null,
          preamble: a.preamble || [],
          source: a.source || null,
        }));
        dispatch({
          type: 'UPDATE_PROJECT',
          payload: { ...currentProject, screens, updatedAt: Date.now() },
        });
        if (screens.length && !screens.find((s) => s.id === currentScreenId)) {
          setCurrentScreen(screens[0].id);
        }
        addWorkspaceLog(ru ? `Загружено ${screens.length} экранов из proot` : `Loaded ${screens.length} screens from proot`, 'success');
      } catch (error) {
        if (!cancelled) addWorkspaceLog(`Hydration failed: ${error?.message || String(error)}`, 'error');
      }
    })();
    return () => { cancelled = true; };
  }, [currentProject?.id])); // eslint-disable-line react-hooks/exhaustive-deps

  if (!currentProject) {
    return (
      <AppScreen style={styles.center}>
        <Icon name="folder-open-outline" size={42} color={colors.textTertiary} />
        <Text style={styles.emptyText}>{copy.noProject}</Text>
        <PrimaryButton title={t('projects')} icon="arrow-back" onPress={() => navigation.navigate('Projects')} />
      </AppScreen>
    );
  }

  const tabs = [
    { key: 'editor', label: copy.editor, icon: 'code-slash-outline', action: () => setActiveTab('editor') },
    { key: 'design', label: copy.design, icon: 'color-wand-outline', action: () => setActiveTab('design') },
    { key: 'settings', label: t('settings'), icon: 'options-outline', action: () => navigation.navigate('ProjectSettings') },
  ];

  const createScreen = async () => {
    const name = newScreenName.trim();
    if (!name) return;
    if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) {
      Alert.alert(
        ru ? 'Некорректное имя' : 'Invalid name',
        ru ? 'Используйте только латиницу и цифры. Например: Auth, Main, Settings' : 'Use Latin letters and digits only. Example: Auth, Main, Settings',
      );
      return;
    }
    if ((currentProject.screens || []).some((s) => s.name === name)) {
      Alert.alert(ru ? 'Такой экран уже есть' : 'Screen already exists', `${name}Activity.kt is already in the project.`);
      return;
    }
    addScreen(name);
    setNewScreenName('');
    setNewScreenOpen(false);
    addWorkspaceLog(`${ru ? 'Создан экран' : 'Screen created'}: ${name}Activity.kt`, 'info');
  };

  const removeScreen = (id) => {
    if (currentProject.screens.length <= 1) return Alert.alert(copy.lastScreen);
    const target = currentProject.screens.find((s) => s.id === id);
    if (!target) return;
    Alert.alert(copy.deleteScreen, `${target.name}Activity.kt`, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: () => {
        deleteScreen(id);
        addWorkspaceLog(`${ru ? 'Удалён экран' : 'Screen removed'}: ${target.name}Activity.kt`, 'info');
      } },
    ]);
  };

  const runGoto = useCallback(() => {
    const n = parseInt(gotoValue, 10);
    setGotoOpen(false);
    setGotoValue('');
    if (Number.isFinite(n)) editorApi.current?.command('gotoLine', n);
  }, [gotoValue]);

  const insertSymbol = useCallback((s) => {
    editorApi.current?.insert(s);
  }, []);

  const logHeight = logMode === 'full' ? Math.max(280, Math.round(height * 0.5)) : logMode === 'half' ? Math.min(220, Math.round(height * 0.3)) : 34;
  const logs = workspaceLogs.length ? workspaceLogs : [{ id: 'ready', level: 'info', text: copy.consoleReady, time: Date.now() }];

  // Problems of the ACTIVE file = instant analyzer + compiler rows for it.
  const compilerForActive = activeFile?.name ? (compiler.byFile[activeFile.name] || []) : [];
  const activeProblems = useMemo(
    () => [...lintProblems, ...compilerForActive],
    [lintProblems, compilerForActive],
  );
  const analyzerSummary = useMemo(() => summarizeProblems(lintProblems), [lintProblems]);
  const compilerTotals = useMemo(() => {
    let errors = 0;
    let warnings = 0;
    Object.values(compiler.byFile).forEach((list) => list.forEach((p) => { if (p.severity === 'warning') warnings++; else errors++; }));
    compiler.fileless.forEach((p) => { if (p.severity === 'warning') warnings++; else errors++; });
    return { errors, warnings };
  }, [compiler.byFile, compiler.fileless]);
  const totalErrors = analyzerSummary.errors + compilerTotals.errors;
  const totalWarnings = analyzerSummary.warnings + compilerTotals.warnings;
  const problemCount = totalErrors;
  const otherFiles = Object.keys(compiler.byFile).filter((name) => name !== activeFile?.name && compiler.byFile[name]?.length);
  const activeDirty = activeFile ? dirtyByPath[activeFile.path] === true : false;
  const breadcrumb = (activeFile?.path || '').split('/').filter(Boolean);
  const crumbShown = breadcrumb.length > 3 && width < 520 ? ['…', ...breadcrumb.slice(-2)] : breadcrumb;
  const hotkeysOn = editor.hotkeys !== false;
  const statusOn = editor.showStatusBar !== false;

  /** Pressable key of the symbol toolbar. */
  const ToolKey = ({ label, icon, onPress, disabled, accent, wide: wideKey }) => (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        {
          minWidth: wideKey ? 42 : 34,
          height: 34,
          paddingHorizontal: wideKey ? 10 : 6,
          borderRadius: 6,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: pressed ? (editorTheme === 'light' ? '#E0E0E0' : '#37373D') : 'transparent',
          opacity: disabled ? 0.35 : 1,
        },
      ]}
    >
      {icon
        ? <Icon name={icon} size={17} color={accent ? '#569CD6' : ide.panelText} />
        : <Text style={{ color: accent ? '#569CD6' : ide.panelText, fontSize: 15, fontFamily: 'monospace', fontWeight: '600' }}>{label}</Text>}
    </Pressable>
  );

  return (
    <AppScreen>
      <TopBar
        compact
        title={currentProject.name}
        subtitle={width >= 700 ? currentProject.projectDir : null}
        onBack={closeAndExit}
        right={<>
          <IconButton name="folder-open-outline" active={explorerOpen} onPress={() => setExplorerOpen((v) => !v)} />
          <IconButton name="options-outline" active={settingsOpen} onPress={() => setSettingsOpen((v) => !v)} />
          <IconButton name="save-outline" label={width >= 700 ? copy.save : null} onPress={saveNow} active={activeDirty} />
          <IconButton name="cube-outline" onPress={() => navigation.navigate('Libraries')} />
          <IconButton name="build-outline" label={width >= 880 ? t('build') : null} active onPress={() => navigation.navigate('Build')} />
        </>}
      />

      <View style={styles.workspaceBar}>
        <Pressable onPress={() => setScreenMenu(true)} style={styles.screenSelect}>
          <Icon name="phone-portrait-outline" size={15} color={colors.primary} />
          <Text style={styles.screenText} numberOfLines={1}>{currentScreen?.name || 'Screen'}</Text>
          <Icon name="chevron-down" size={13} color={colors.textTertiary} />
        </Pressable>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.modeTabs}>
          {tabs.map((tab) => (
            <Pressable key={tab.key} onPress={tab.action} style={[styles.modeTab, tab.key === activeTab && styles.modeTabActive]}>
              <Icon name={tab.icon} size={15} color={tab.key === activeTab ? colors.primary : colors.textSecondary} />
              <Text style={[styles.modeTabText, tab.key === activeTab && styles.modeTabTextActive]}>{tab.label}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <View style={styles.main}>
        {explorerOpen && wide ? (
          <View style={styles.explorerWrap}>
            <FileExplorer
              project={currentProject}
              activePath={activeFile?.path}
              onOpenFile={onOpenFile}
              onClose={() => setExplorerOpen(false)}
              width={270}
            />
          </View>
        ) : null}
        <View style={styles.content}>
          {activeTab === 'design' ? (
            <View style={styles.previewWrap}>
              <View style={styles.previewHead}>
                <Icon name="color-wand-outline" size={15} color={colors.primary} />
                <Text style={styles.previewTitle}>{copy.design} · {currentScreen?.name || ''}</Text>
              </View>
              <ScrollView contentContainerStyle={styles.previewScroll}>
                {currentScreen ? (
                  <NativeComposePreview
                    project={currentProject}
                    screen={currentScreen}
                    showChrome
                    scroll={false}
                    widthDp={360}
                  />
                ) : (
                  <Text style={styles.emptyText}>{copy.consoleReady}</Text>
                )}
              </ScrollView>
            </View>
          ) : (
            <View style={[styles.codeWrap, { backgroundColor: ide.editorBg }]}>
              {/* ——— VS Code file tabs ——— */}
              <View style={[styles.tabStrip, { backgroundColor: ide.panel, borderBottomColor: ide.panelBorder }]}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'stretch' }}>
                  {openTabs.map((tab) => {
                    const active = tab.path === activeFile?.path;
                    const dirty = dirtyByPath[tab.path] === true;
                    const ext = tab.name.includes('.') ? tab.name.split('.').pop() : '';
                    const fi = fileIcon(ext);
                    return (
                      <Pressable
                        key={tab.path}
                        onPress={() => activateTab(tab)}
                        style={[
                          styles.fileTab,
                          { borderRightColor: ide.panelBorder },
                          active && { backgroundColor: ide.editorBg, borderTopColor: '#569CD6' },
                        ]}
                      >
                        <Icon name={fi.name} size={13} color={active ? fi.color : ide.panelTextDim} />
                        <Text
                          numberOfLines={1}
                          style={[
                            styles.fileTabText,
                            { color: active ? ide.panelText : ide.panelTextDim },
                            active && { fontWeight: '700' },
                          ]}
                        >
                          {tab.name}
                        </Text>
                        {tab.isScreen ? (
                          dirty ? <View style={styles.dirtyDot} /> : null
                        ) : (
                          <Pressable
                            hitSlop={8}
                            onPress={(e) => { e.stopPropagation?.(); closeTab(tab); }}
                            style={styles.fileTabClose}
                          >
                            {dirty
                              ? <View style={styles.dirtyDot} />
                              : <Icon name="close" size={13} color={ide.panelTextDim} />}
                          </Pressable>
                        )}
                      </Pressable>
                    );
                  })}
                  <Pressable onPress={() => setExplorerOpen((v) => !v)} accessibilityLabel={copy.openFile} style={styles.fileTabAdd}>
                    <Icon name="add" size={17} color={ide.panelTextDim} />
                  </Pressable>
                </ScrollView>
              </View>

              {/* ——— breadcrumb + quick actions ——— */}
              <View style={[styles.crumbs, { backgroundColor: ide.editorBg, borderBottomColor: ide.panelBorder }]}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'center', gap: 2 }}>
                  {crumbShown.map((part, i) => (
                    <React.Fragment key={`${part}-${i}`}>
                      {i > 0 ? <Icon name="chevron-forward" size={11} color={ide.panelTextDim} /> : null}
                      <Text style={[styles.crumb, { color: i === crumbShown.length - 1 ? ide.panelText : ide.panelTextDim }]}>{part}</Text>
                    </React.Fragment>
                  ))}
                </ScrollView>
                <View style={{ flex: 1 }} />
                {readOnly ? (
                  <View style={styles.readOnlyChip}>
                    <Icon name="lock-closed-outline" size={11} color={ide.panelTextDim} />
                    <Text style={[styles.readOnlyChipText, { color: ide.panelTextDim }]}>{copy.readOnly}</Text>
                  </View>
                ) : null}
                {saving ? <Text style={[styles.savingText, { color: ide.panelTextDim }]}>{copy.saving}</Text> : null}
                {compiler.running ? (
                  <View style={styles.problemsBtn}>
                    <ActivityIndicator size={12} color="#569CD6" />
                    <Text style={styles.checkingText}>{copy.checkRunning}</Text>
                  </View>
                ) : null}
                {!compiler.running && (totalErrors > 0 || totalWarnings > 0) ? (
                  <Pressable onPress={() => { setDockTab('problems'); setLogMode(logMode === 'hidden' ? 'half' : logMode); }} style={styles.problemsBtn}>
                    {totalErrors > 0 ? (
                      <>
                        <Icon name="close-circle" size={13} color="#F14C4C" />
                        <Text style={styles.problemsCount}>{totalErrors}</Text>
                      </>
                    ) : null}
                    {totalWarnings > 0 ? (
                      <>
                        <Icon name="warning" size={12} color="#CCA700" style={{ marginLeft: totalErrors > 0 ? 4 : 0 }} />
                        <Text style={styles.warningsCount}>{totalWarnings}</Text>
                      </>
                    ) : null}
                  </Pressable>
                ) : null}
                {missingList.length > 0 ? (
                  <Pressable onPress={applyMissingImports} style={styles.importBtn}>
                    <Icon name="flash-outline" size={13} color="#C586C0" />
                    <Text style={styles.importBtnText}>{missingList.length}</Text>
                  </Pressable>
                ) : null}
                <ToolKey icon="shield-checkmark-outline" accent onPress={runCompilerCheck} disabled={compiler.running} />
                <ToolKey icon="return-down-forward-outline" accent onPress={() => setGotoOpen(true)} />
                <ToolKey icon="keyboard-outline" accent={hotkeysOn} onPress={() => setEditorSetting('hotkeys', !hotkeysOn)} />
                <ToolKey icon="save-outline" accent={activeDirty} onPress={saveNow} />
              </View>

              {/* ——— missing imports quick fix ——— */}
              {missingList.length > 0 ? (
                <Pressable onPress={applyMissingImports} style={styles.importBar}>
                  <Icon name="flash-outline" size={14} color="#C586C0" />
                  <Text style={styles.importText}>{copy.importsFix} ({missingList.length})</Text>
                  <Icon name="chevron-forward" size={13} color="#C586C0" />
                </Pressable>
              ) : null}

              {/* ——— CodeMirror editor ——— */}
              <CodeMirrorEditor
                ref={editorApi}
                value={draft}
                onChange={handleEditorChange}
                readOnly={readOnly}
                placeholder={copy.codePlaceholder}
                fallbackTitle={copy.fallback}
                config={{
                  themeMode: editorTheme,
                  fontSize: editor.fontSize || 15,
                  tabSize: editor.tabSize || 4,
                  spacesForTab: editor.spacesForTab !== false,
                  wordWrap: editor.wordWrap === true,
                  completion: editor.completion !== false,
                }}
                diagnostics={activeProblems}
                onCursor={setCursorInfo}
              />

              {/* ——— symbol toolbar ——— */}
              {hotkeysOn ? (
                <View style={[styles.toolbar, { backgroundColor: ide.panel, borderTopColor: ide.panelBorder }]}>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="always" contentContainerStyle={{ alignItems: 'center', paddingHorizontal: 4, gap: 1 }}>
                    {TOOL_COMMANDS.map((cmd) => (
                      <ToolKey
                        key={cmd.name}
                        icon={cmd.icon}
                        disabled={(cmd.name === 'undo' && !cursorInfo.canUndo) || (cmd.name === 'redo' && !cursorInfo.canRedo)}
                        onPress={() => editorApi.current?.command(cmd.name)}
                      />
                    ))}
                    <View style={[styles.toolbarSep, { backgroundColor: ide.panelBorder }]} />
                    {SYMBOL_KEYS.map((s) => (
                      <ToolKey key={s} label={s} onPress={() => insertSymbol(s)} />
                    ))}
                    <View style={[styles.toolbarSep, { backgroundColor: ide.panelBorder }]} />
                    <ToolKey icon="chevron-back-outline" onPress={() => editorApi.current?.command('left')} />
                    <ToolKey icon="chevron-forward-outline" onPress={() => editorApi.current?.command('right')} />
                  </ScrollView>
                </View>
              ) : null}

              {/* ——— VS Code status bar ——— */}
              {statusOn ? (
                <View style={[styles.statusBar, { backgroundColor: ide.status }]}>
                  <Pressable
                    onPress={() => { setDockTab('problems'); setLogMode(logMode === 'hidden' ? 'half' : logMode); }}
                    style={styles.statusItem}
                  >
                    <Icon name="close-circle" size={12} color="#FFFFFF" />
                    <Text style={styles.statusText}>{totalErrors}</Text>
                  </Pressable>
                  <Pressable
                    onPress={() => { setDockTab('problems'); setLogMode(logMode === 'hidden' ? 'half' : logMode); }}
                    style={styles.statusItem}
                  >
                    <Icon name="warning-outline" size={12} color="#FFFFFF" />
                    <Text style={styles.statusText}>{totalWarnings}</Text>
                  </Pressable>
                  <Pressable onPress={() => setLogMode(logMode === 'hidden' ? 'half' : 'hidden')} style={styles.statusItem}>
                    <Icon name="terminal-outline" size={12} color="#FFFFFF" />
                    <Text style={styles.statusText}>{logs.length}</Text>
                  </Pressable>
                  {compiler.running ? (
                    <View style={styles.statusItem}>
                      <ActivityIndicator size={11} color="#FFFFFF" />
                      <Text style={styles.statusText}>compileDebugKotlin</Text>
                    </View>
                  ) : null}
                  <View style={{ flex: 1 }} />
                  <Text style={styles.statusText}>Ln {cursorInfo.line}, Col {cursorInfo.col}</Text>
                  <Text style={styles.statusText}>{editor.spacesForTab !== false ? `Spaces: ${editor.tabSize || 4}` : `Tab Size: ${editor.tabSize || 4}`}</Text>
                  <Text style={styles.statusText}>UTF-8</Text>
                  <Text style={styles.statusText}>Kotlin</Text>
                </View>
              ) : null}
            </View>
          )}
        </View>
      </View>

      {/* ——— output / problems panel ——— */}
      <View style={[styles.logDock, { height: logHeight, backgroundColor: ide.panel, borderTopColor: ide.panelBorder }]}>
        <View style={[styles.logHead, { backgroundColor: ide.panel }]}>
          <Pressable onPress={() => setDockTab('output')} style={styles.dockTab}>
            <Text style={[styles.dockTabText, { color: dockTab === 'output' ? ide.panelText : ide.panelTextDim }, dockTab === 'output' && styles.dockTabActive]}>{copy.output.toUpperCase()}</Text>
          </Pressable>
          <Pressable onPress={() => setDockTab('problems')} style={styles.dockTab}>
            <Text style={[styles.dockTabText, { color: dockTab === 'problems' ? (problemCount ? '#F14C4C' : ide.panelText) : ide.panelTextDim }, dockTab === 'problems' && styles.dockTabActive]}>
              {`${copy.problems.toUpperCase()}${(totalErrors + totalWarnings) ? ` (${totalErrors + totalWarnings})` : ''}`}
            </Text>
          </Pressable>
          <View style={{ flex: 1 }} />
          {logMode !== 'hidden' && dockTab === 'output' ? (
            <Pressable onPress={clearWorkspaceLogs} style={styles.logAction}>
              <Icon name="trash-outline" size={13} color={ide.panelTextDim} />
              <Text style={[styles.logActionText, { color: ide.panelTextDim }]}>{copy.clear}</Text>
            </Pressable>
          ) : null}
          <SegmentedControl compact value={logMode} onChange={setLogMode} options={[
            { value: 'hidden', label: '', icon: 'chevron-down-outline', flex: false },
            { value: 'half', label: '', icon: 'remove-outline', flex: false },
            { value: 'full', label: '', icon: 'chevron-up-outline', flex: false },
          ]} />
        </View>
        {logMode !== 'hidden' ? (
          dockTab === 'problems' ? (
            <ScrollView style={styles.logs} contentContainerStyle={{ padding: 8 }}>
              {/* compiler check banner */}
              <Pressable onPress={runCompilerCheck} style={[styles.checkBanner, { borderColor: ide.panelBorder, backgroundColor: editorTheme === 'light' ? '#FFFFFF' : '#2D2D30' }]} disabled={compiler.running}>
                {compiler.running
                  ? <ActivityIndicator size={14} color="#569CD6" />
                  : <Icon name={compiler.ran ? (compiler.success ? 'shield-checkmark' : 'shield-half-outline') : 'shield-checkmark-outline'} size={15} color={compiler.ran ? (compiler.success ? '#4EC9B0' : '#F14C4C') : '#569CD6'} />}
                <Text style={{ flex: 1, color: ide.panelTextDim, fontSize: 10.5, fontFamily: 'monospace' }} numberOfLines={2}>
                  {compiler.running
                    ? `${copy.checkRunning} gradlew compileDebugKotlin`
                    : compiler.ran
                      ? `${copy.compilerProblems}: ${compiler.success ? copy.checkOk : `${compilerTotals.errors} ✕ · ${compilerTotals.warnings} ⚠`} · ${new Date(compiler.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                      : `${copy.notChecked} — gradlew compileDebugKotlin`}
                </Text>
                {!compiler.running ? <Icon name="refresh" size={14} color="#569CD6" /> : null}
              </Pressable>

              {/* active file problems */}
              {activeProblems.length > 0 ? (
                <Text style={[styles.dockSectionHeader, { color: ide.panelTextDim }]}>{activeFile?.name} · {copy.editorProblems.toUpperCase()}{compilerForActive.length ? ` + ${copy.compilerProblems.toUpperCase()}` : ''}</Text>
              ) : null}
              {activeProblems.slice(0, 100).map((p, i) => (
                <Pressable key={`a-${i}`} style={styles.logRow} onPress={() => editorApi.current?.command('gotoLine', p.line)}>
                  <Icon name={p.severity === 'warning' ? 'warning' : 'close-circle'} size={13} color={p.severity === 'warning' ? '#CCA700' : '#F14C4C'} />
                  <Text style={[styles.logText, { color: ide.panelText }]}>{p.message}</Text>
                  <Text style={[styles.logTime, { width: 'auto' }]}>{p.line}:{p.col}</Text>
                </Pressable>
              ))}

              {/* problems in other files */}
              {otherFiles.length > 0 ? (
                <Text style={[styles.dockSectionHeader, { color: ide.panelTextDim }]}>{copy.otherFiles.toUpperCase()} · {copy.compilerProblems.toUpperCase()}</Text>
              ) : null}
              {otherFiles.map((name) => (
                <View key={name}>
                  <Text style={[styles.dockFileHeader, { color: ide.panelText }]}>{name} ({compiler.byFile[name].length})</Text>
                  {compiler.byFile[name].slice(0, 50).map((p, i) => (
                    <Pressable key={`${name}-${i}`} style={styles.logRow} onPress={() => openProblemFile(name, p.line)}>
                      <Icon name={p.severity === 'warning' ? 'warning' : 'close-circle'} size={13} color={p.severity === 'warning' ? '#CCA700' : '#F14C4C'} />
                      <Text style={[styles.logText, { color: ide.panelText }]}>{p.message}</Text>
                      <Text style={[styles.logTime, { width: 'auto' }]}>{p.line}:{p.col}</Text>
                    </Pressable>
                  ))}
                </View>
              ))}

              {/* compiler messages without a file */}
              {compiler.fileless.slice(0, 20).map((p, i) => (
                <View key={`f-${i}`} style={styles.logRow}>
                  <Icon name="close-circle" size={13} color="#F14C4C" />
                  <Text style={[styles.logText, { color: ide.panelText }]}>{p.message}</Text>
                </View>
              ))}

              {totalErrors + totalWarnings === 0 && !compiler.running ? (
                <View style={styles.noProblems}>
                  <Icon name="checkmark-circle-outline" size={15} color="#4EC9B0" />
                  <Text style={[styles.logText, { color: ide.panelTextDim }]}>{copy.noProblems}</Text>
                </View>
              ) : null}
            </ScrollView>
          ) : (
            <ScrollView style={styles.logs} contentContainerStyle={{ padding: 8 }}>
              {logs.map((log) => (
                <View key={log.id} style={styles.logRow}>
                  <Text style={styles.logTime}>{new Date(log.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</Text>
                  <Icon name={log.level === 'success' ? 'checkmark-circle-outline' : log.level === 'error' ? 'alert-circle-outline' : 'information-circle-outline'} size={13} color={log.level === 'success' ? '#4EC9B0' : log.level === 'error' ? '#F14C4C' : '#569CD6'} />
                  <Text selectable style={[styles.logText, { color: ide.panelText }]}>{log.text}</Text>
                </View>
              ))}
            </ScrollView>
          )
        ) : null}
      </View>

      {explorerOpen && !wide ? (
        <Modal visible transparent animationType="fade" onRequestClose={() => setExplorerOpen(false)}>
          <Pressable style={styles.explorerOverlay} onPress={() => setExplorerOpen(false)}>
            <Pressable style={[styles.explorerDrawer, { width: Math.min(width * 0.82, 340), paddingTop: insets.top, paddingBottom: insets.bottom }]} onPress={(e) => e.stopPropagation?.()}>
              <FileExplorer
                project={currentProject}
                activePath={activeFile?.path}
                onOpenFile={(path) => { onOpenFile(path); if (!wide) setExplorerOpen(false); }}
                onClose={() => setExplorerOpen(false)}
              />
            </Pressable>
          </Pressable>
        </Modal>
      ) : null}

      <Modal visible={settingsOpen} transparent animationType="fade" onRequestClose={() => setSettingsOpen(false)}>
        <View style={styles.overlay}>
          <View style={styles.settingsCard}><EditorSettings onClose={() => setSettingsOpen(false)} /></View>
        </View>
      </Modal>

      <Modal visible={gotoOpen} transparent animationType="fade" onRequestClose={() => setGotoOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.gotoDialog} title={copy.gotoLine} icon="return-down-forward-outline">
            <TextInput
              autoFocus
              value={gotoValue}
              onChangeText={setGotoValue}
              onSubmitEditing={runGoto}
              placeholder={`${copy.lineNumber} (1-${Math.max(cursorInfo.lines || 1, formatStats.lineCount || 1)})`}
              placeholderTextColor={colors.textTertiary}
              keyboardType="number-pad"
              style={styles.input}
            />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <IconButton name="close" label={t('cancel')} onPress={() => setGotoOpen(false)} style={{ flex: 1 }} />
              <PrimaryButton title={copy.goto} icon="arrow-forward" disabled={!gotoValue.trim()} onPress={runGoto} style={{ flex: 1 }} />
            </View>
          </SectionCard>
        </View>
      </Modal>

      <Modal visible={screenMenu} transparent animationType="fade" onRequestClose={() => setScreenMenu(false)}>
        <Pressable style={styles.overlay} onPress={() => setScreenMenu(false)}>
          <SectionCard style={styles.screenDialog} title={t('screens')} icon="layers-outline">
            {currentProject.screens.map((screen) => (
              <View key={screen.id} style={[styles.screenRow, screen.id === currentScreenId && styles.screenRowActive]}>
                <Pressable style={styles.screenRowMain} onPress={() => { setScreenMenu(false); guardUnsaved(() => setCurrentScreen(screen.id)); }}>
                  <Icon name="phone-portrait-outline" size={16} color={screen.id === currentScreenId ? colors.primary : colors.textSecondary} />
                  <Text style={styles.screenRowText}>{screen.name}</Text>
                </Pressable>
                <IconButton name="copy-outline" onPress={() => duplicateScreen(screen.id)} style={styles.rowButton} />
                <IconButton name="trash-outline" danger onPress={() => removeScreen(screen.id)} style={styles.rowButton} />
              </View>
            ))}
            <PrimaryButton title={t('addScreen')} icon="add" onPress={() => { setScreenMenu(false); setNewScreenOpen(true); }} />
          </SectionCard>
        </Pressable>
      </Modal>

      <Modal visible={newScreenOpen} transparent animationType="fade" onRequestClose={() => setNewScreenOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.newDialog} title={t('addScreen')} icon="phone-portrait-outline">
            <TextInput autoFocus value={newScreenName} onChangeText={setNewScreenName} onSubmitEditing={createScreen} placeholder={copy.screenName} placeholderTextColor={colors.textTertiary} style={styles.input} />
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <IconButton name="close" label={t('cancel')} onPress={() => setNewScreenOpen(false)} style={{ flex: 1 }} />
              <PrimaryButton title={t('addScreen')} icon="add" disabled={!newScreenName.trim()} onPress={createScreen} style={{ flex: 1 }} />
            </View>
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  emptyText: { color: c.textSecondary, fontSize: 14, textAlign: 'center', paddingHorizontal: 24 },
  workspaceBar: { minHeight: 44, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, gap: 6, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  screenSelect: { minWidth: 104, maxWidth: 200, flexShrink: 1, height: 32, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 7, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  screenText: { color: c.text, fontSize: 11, fontWeight: '650', flex: 1 },
  modeTabs: { paddingHorizontal: 4, gap: 2, alignItems: 'center' },
  modeTab: { height: 33, paddingHorizontal: 11, borderRadius: 7, flexDirection: 'row', alignItems: 'center', gap: 6 },
  modeTabActive: { backgroundColor: c.primarySurface },
  modeTabText: { color: c.textSecondary, fontSize: 11, fontWeight: '600' },
  modeTabTextActive: { color: c.primary, fontWeight: '750' },
  main: { flex: 1, flexDirection: 'row', minHeight: 0 },
  explorerWrap: { borderRightWidth: 1, borderRightColor: c.border },
  content: { flex: 1, minWidth: 0 },
  previewWrap: { flex: 1, minHeight: 0, backgroundColor: c.canvas },
  previewHead: { height: 40, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  previewTitle: { color: c.text, fontSize: 12, fontWeight: '700' },
  previewScroll: { padding: 14, paddingBottom: 40, alignItems: 'center' },
  codeWrap: { flex: 1, minHeight: 0 },
  tabStrip: { height: 35, borderBottomWidth: 1 },
  fileTab: {
    height: 35,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: 200,
    borderRightWidth: 1,
    borderTopWidth: 2,
    borderTopColor: 'transparent',
  },
  fileTabText: { fontSize: 11.5, fontWeight: '500', flexShrink: 1 },
  fileTabClose: { width: 18, height: 18, borderRadius: 4, alignItems: 'center', justifyContent: 'center' },
  fileTabAdd: { width: 34, height: 35, alignItems: 'center', justifyContent: 'center' },
  dirtyDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#569CD6' },
  crumbs: { minHeight: 30, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 5, borderBottomWidth: 1 },
  crumb: { fontSize: 10.5, fontFamily: 'monospace' },
  readOnlyChip: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 6, height: 20, borderRadius: 9, backgroundColor: 'rgba(133,133,133,0.18)' },
  readOnlyChipText: { fontSize: 9, fontWeight: '600' },
  savingText: { fontSize: 10, marginHorizontal: 4 },
  problemsBtn: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, height: 22, borderRadius: 6 },
  problemsCount: { color: '#F14C4C', fontSize: 11, fontWeight: '750' },
  warningsCount: { color: '#CCA700', fontSize: 11, fontWeight: '750' },
  checkingText: { color: '#569CD6', fontSize: 10.5, fontWeight: '600', marginLeft: 3 },
  checkBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, borderWidth: 1, marginBottom: 7 },
  dockSectionHeader: { fontSize: 9.5, fontWeight: '800', letterSpacing: 0.7, marginTop: 4, marginBottom: 5 },
  dockFileHeader: { fontSize: 11, fontWeight: '750', marginTop: 4, marginBottom: 3, fontFamily: 'monospace' },
  importBtn: { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, height: 22, borderRadius: 6 },
  importBtnText: { color: '#C586C0', fontSize: 11, fontWeight: '750' },
  importBar: { minHeight: 30, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(197,134,192,0.12)', borderBottomWidth: 1, borderBottomColor: 'rgba(197,134,192,0.25)' },
  importText: { color: '#C586C0', fontSize: 11.5, fontWeight: '650', flex: 1 },
  toolbar: { height: 42, borderTopWidth: 1 },
  toolbarSep: { width: 1, height: 22, marginHorizontal: 5 },
  statusBar: { minHeight: 24, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 12 },
  statusItem: { flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 24 },
  statusText: { color: '#FFFFFF', fontSize: 10.5, fontFamily: 'monospace', includeFontPadding: false },
  logDock: { borderTopWidth: 1, overflow: 'hidden' },
  logHead: { height: 34, paddingHorizontal: 6, flexDirection: 'row', alignItems: 'center', gap: 4 },
  dockTab: { paddingHorizontal: 9, height: 34, justifyContent: 'center' },
  dockTabText: { fontSize: 10, fontWeight: '700', letterSpacing: 0.6 },
  dockTabActive: { borderBottomWidth: 2, borderBottomColor: '#569CD6' },
  logAction: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7 },
  logActionText: { fontSize: 9 },
  logs: { flex: 1 },
  logRow: { minHeight: 22, flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  logTime: { color: '#858585', fontSize: 9, fontFamily: 'monospace', width: 55, marginTop: 1 },
  logText: { fontSize: 10.5, lineHeight: 15, fontFamily: 'monospace', flex: 1 },
  noProblems: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 4 },
  overlay: { flex: 1, justifyContent: 'center', padding: 18, backgroundColor: c.overlay },
  settingsCard: { width: '100%', maxWidth: 460, maxHeight: '85%', alignSelf: 'center', borderRadius: 16, overflow: 'hidden', backgroundColor: c.bgCard, flexShrink: 1 },
  explorerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', flexDirection: 'row' },
  explorerDrawer: { height: '100%', backgroundColor: c.bgCard, overflow: 'hidden' },
  screenDialog: { width: '100%', maxWidth: 500, alignSelf: 'center' },
  newDialog: { width: '100%', maxWidth: 430, alignSelf: 'center' },
  gotoDialog: { width: '100%', maxWidth: 380, alignSelf: 'center' },
  screenRow: { minHeight: 48, flexDirection: 'row', alignItems: 'center', borderRadius: 9, borderWidth: 1, borderColor: 'transparent' },
  screenRowActive: { backgroundColor: c.primarySurface, borderColor: c.primary },
  screenRowMain: { flex: 1, minHeight: 46, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 11 },
  screenRowText: { color: c.text, fontSize: 12, fontWeight: '650' },
  rowButton: { width: 36, minWidth: 36, height: 36, borderWidth: 0, backgroundColor: 'transparent' },
  input: { minHeight: 46, borderRadius: 10, paddingHorizontal: 12, backgroundColor: c.bgInput, borderWidth: 1, borderColor: c.borderLight, color: c.text, fontSize: 13 },
});

export default EditorScreen;
