import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, BackHandler, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, TopBar } from '../components/AppUI';
import { Icon, componentIcons } from '../components/Icon';
import ComponentPalette from '../components/ComponentPalette';
import DesignCanvas from '../components/DesignCanvas';
import PropertyPanel from '../components/PropertyPanel';
import ComposePreviewPanel from '../components/ComposePreviewPanel';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { syncComposeProject } from '../utils/composeProject';
import { loadRaiActivities } from '../utils/activityTree';

const EditorScreen = ({ navigation }) => {
  const { width, height } = useWindowDimensions();
  const {
    currentProject, currentScreenId, setCurrentScreen, addScreen, deleteScreen, duplicateScreen,
    workspaceLogs, clearWorkspaceLogs, addWorkspaceLog, closeProject, dispatch,
  } = useProject();
  const { colors, language, t } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const [screenMenu, setScreenMenu] = useState(false);
  const [activeTab, setActiveTab] = useState('design');
  const [newScreenOpen, setNewScreenOpen] = useState(false);
  const [newScreenName, setNewScreenName] = useState('');
  const [mobilePanel, setMobilePanel] = useState(null);
  const [logMode, setLogMode] = useState('hidden');
  const [drag, setDrag] = useState(null);
  const canvasRef = useRef(null);
  const designCanvasRef = useRef(null);
  const boundsRef = useRef(null);
  const closingRef = useRef(false);
  const wide = width >= 1100;
  const tablet = width >= 700;
  const currentScreen = currentProject?.screens?.find((screen) => screen.id === currentScreenId);

  const copy = language === 'ru' ? {
    noProject: 'Проект не открыт',
    screenName: 'Название экрана',
    deleteScreen: 'Удалить экран?',
    lastScreen: 'Нельзя удалить единственный экран.',
    drop: 'Перетащите на холст',
    consoleReady: 'Редактор готов. Изменения сохраняются автоматически.',
    clear: 'Очистить',
    output: 'Вывод конструктора',
    closing: 'Сохраняем и закрываем проект…',
    closed: 'Проект сохранён и закрыт',
  } : {
    noProject: 'No project is open',
    screenName: 'Screen name',
    deleteScreen: 'Delete screen?',
    lastScreen: 'The only screen cannot be deleted.',
    drop: 'Drag onto the canvas',
    consoleReady: 'Editor ready. Changes are saved automatically.',
    clear: 'Clear',
    output: 'Builder output',
    closing: 'Saving and closing project…',
    closed: 'Project saved and closed',
  };

  const projectSnapshot = useMemo(() => currentProject ? JSON.stringify({
    id: currentProject.id,
    updatedAt: currentProject.updatedAt,
    screens: currentProject.screens,
    variables: currentProject.variables,
    theme: currentProject.theme,
  }) : '', [currentProject]);

  useEffect(() => {
    if (!currentProject || closingRef.current) return undefined;
    const projectToSave = currentProject;
    const timer = setTimeout(async () => {
      const result = await syncComposeProject(projectToSave);
      if (!result?.success) addWorkspaceLog(result?.output || 'Compose source sync failed', 'error');
    }, 900);
    return () => clearTimeout(timer);
  }, [projectSnapshot]);

  const closeAndExit = useCallback(async () => {
    if (closingRef.current) return;
    closingRef.current = true;
    if (currentProject) {
      addWorkspaceLog(copy.closing, 'info');
      try { await syncComposeProject(currentProject); } catch (error) {}
    }
    try { await closeProject(); } catch (error) {}
    navigation.reset({ index: 0, routes: [{ name: 'Projects' }] });
  }, [currentProject, closeProject, navigation, copy.closing, addWorkspaceLog]);

  useFocusEffect(useCallback(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      closeAndExit();
      return true;
    });
    return () => subscription.remove();
  }, [closeAndExit]));

  // Open the project by reading every *Activity.kt file in the rai
  // project. The editor is a view on top of the rai workspace; the
  // Kotlin sources are the source of truth, the JSON tree in
  // AsyncStorage is a working copy that gets synced back on every
  // change.
  //
  // The hydration runs exactly once per project.id. Re-running on
  // every focus would clobber the user's local edits (the sync
  // pipeline is debounced, so a refocused screen could re-read
  // older on-disk state). If the user later wants to re-import
  // from disk they can clear the AsyncStorage record manually.
  const hydratedFor = useRef(null);
  useFocusEffect(useCallback(() => {
    if (!currentProject) return undefined;
    if (hydratedFor.current === currentProject.id) return undefined;
    hydratedFor.current = currentProject.id;
    let cancelled = false;
    (async () => {
      try {
        const activities = await loadRaiActivities(currentProject);
        if (cancelled) return;
        if (!activities.length) {
          addWorkspaceLog(
            language === 'ru'
              ? 'Нет *Activity.kt файлов в proot. Нажмите «+» чтобы создать экран.'
              : 'No *Activity.kt files in proot. Press + to add a screen.',
            'info',
          );
          return;
        }
        const screens = activities.map((a) => ({
          id: a.id,
          name: a.name,
          fileName: a.fileName,
          rootComponent: a.rootComponent,
          blocks: [],
        }));
        dispatch({
          type: 'UPDATE_PROJECT',
          payload: { ...currentProject, screens, updatedAt: Date.now() },
        });
        if (screens.length && !screens.find((s) => s.id === currentScreenId)) {
          setCurrentScreen(screens[0].id);
        }
        addWorkspaceLog(
          language === 'ru'
            ? `Загружено ${screens.length} экранов из proot`
            : `Loaded ${screens.length} screens from proot`,
          'success',
        );
      } catch (error) {
        if (!cancelled) {
          addWorkspaceLog(
            `Hydration failed: ${error?.message || String(error)}`,
            'error',
          );
        }
      }
    })();
    return () => { cancelled = true; };
  }, [currentProject?.id]));

  useEffect(() => navigation.addListener('beforeRemove', (event) => {
    if (closingRef.current) return;
    event.preventDefault();
    closeAndExit();
  }), [navigation, closeAndExit]);

  if (!currentProject) {
    return <AppScreen style={styles.center}><Icon name="folder-open-outline" size={42} color={colors.textTertiary} /><Text style={styles.emptyText}>{copy.noProject}</Text><PrimaryButton title={t('projects')} icon="arrow-back" onPress={() => navigation.navigate('Projects')} /></AppScreen>;
  }

  const tabs = [
    { key: 'design', label: t('design'), icon: 'color-wand-outline', action: () => { setActiveTab('design'); setMobilePanel(null); } },
    { key: 'logic', label: t('logic'), icon: 'git-network-outline', action: () => navigation.navigate('BlockEditor') },
    { key: 'preview', label: t('preview'), icon: 'play-outline', action: () => { setActiveTab('preview'); setMobilePanel(null); } },
    { key: 'settings', label: t('settings'), icon: 'options-outline', action: () => navigation.navigate('ProjectSettings') },
  ];

  const measureCanvas = () => canvasRef.current?.measureInWindow((x, y, w, h) => {
    boundsRef.current = { x, y, w, h };
  });
  const isInside = (point) => {
    const b = boundsRef.current;
    return Boolean(point && b && point.x >= b.x && point.x <= b.x + b.w && point.y >= b.y && point.y <= b.y + b.h);
  };
  const onDragStart = (type, point) => {
    measureCanvas();
    setDrag({ type, ...point, inside: false });
  };
  const onDragMove = (type, point) => {
    const inside = isInside(point);
    if (inside) designCanvasRef.current?.updateDragPoint?.(point);
    else designCanvasRef.current?.clearDragPoint?.();
    setDrag({ type, ...point, inside });
  };
  const onDrop = (type, point) => {
    if (type && isInside(point) && designCanvasRef.current?.dropComponent?.(type, point)) {
      addWorkspaceLog(`${language === 'ru' ? 'Добавлен компонент' : 'Component added'}: ${type}`, 'success');
    } else {
      designCanvasRef.current?.clearDragPoint?.();
    }
    setDrag(null);
  };

  const createScreen = async () => {
    const name = newScreenName.trim();
    if (!name) return;
    // The user types an English Activity name like "Auth". The file
    // on disk will be <Name>Activity.kt. We reject anything that is
    // not a valid Java identifier to avoid creating files rai build
    // cannot compile.
    if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) {
      Alert.alert(
        language === 'ru' ? 'Некорректное имя' : 'Invalid name',
        language === 'ru'
          ? 'Используйте только латиницу и цифры. Например: Auth, Main, Settings'
          : 'Use Latin letters and digits only. Example: Auth, Main, Settings',
      );
      return;
    }
    if ((currentProject.screens || []).some((s) => s.name === name)) {
      Alert.alert(
        language === 'ru' ? 'Такой экран уже есть' : 'Screen already exists',
        `${name}Activity.kt is already in the project.`,
      );
      return;
    }
    addScreen(name);
    setNewScreenName('');
    setNewScreenOpen(false);
    addWorkspaceLog(`${language === 'ru' ? 'Создан экран' : 'Screen created'}: ${name}Activity.kt`, 'info');
    // Push the new Activity file (and the new manifest entry) to
    // proot right away so the user can build without waiting for
    // the debounced sync.
    const synced = await syncComposeProject({ ...currentProject, screens: [...(currentProject.screens || []), { name, fileName: `${name}Activity.kt`, rootComponent: { id: `r-${name}`, type: 'Column', props: { width: 'match_parent', height: 'match_parent', padding: 0, spacing: 0, backgroundColor: 'transparent' }, children: [] }, blocks: [] }] });
    if (synced?.success) {
      addWorkspaceLog(`Wrote ${name}Activity.kt and updated AndroidManifest.xml`, 'success');
    } else if (synced?.output) {
      addWorkspaceLog(synced.output, 'error');
    }
  };
  const removeScreen = (id) => {
    if (currentProject.screens.length <= 1) return Alert.alert(copy.lastScreen);
    const target = currentProject.screens.find((s) => s.id === id);
    if (!target) return;
    Alert.alert(copy.deleteScreen, `${target.name}Activity.kt`, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: async () => {
        deleteScreen(id);
        addWorkspaceLog(`${language === 'ru' ? 'Удалён экран' : 'Screen removed'}: ${target.name}Activity.kt`, 'info');
        const remaining = (currentProject.screens || []).filter((s) => s.id !== id);
        const synced = await syncComposeProject({ ...currentProject, screens: remaining });
        if (synced?.success) {
          addWorkspaceLog(`Removed ${target.name}Activity.kt from manifest and proot`, 'success');
        } else if (synced?.output) {
          addWorkspaceLog(synced.output, 'error');
        }
      } },
    ]);
  };

  const logHeight = logMode === 'full' ? Math.max(280, Math.round(height * 0.52)) : logMode === 'half' ? Math.min(210, Math.round(height * 0.3)) : 40;
  const logs = workspaceLogs.length ? workspaceLogs : [{ id: 'ready', level: 'info', text: copy.consoleReady, time: Date.now() }];
  const dragIcon = drag ? componentIcons[drag.type] : null;

  return (
    <AppScreen>
      <TopBar
        compact
        title={currentProject.name}
        subtitle={tablet ? currentProject.projectDir : null}
        onBack={closeAndExit}
        right={<>
          {!wide && activeTab === 'design' ? <IconButton name="shapes-outline" active={mobilePanel === 'palette'} onPress={() => setMobilePanel(mobilePanel === 'palette' ? null : 'palette')} /> : null}
          {!wide && activeTab === 'design' ? <IconButton name="options-outline" active={mobilePanel === 'props'} onPress={() => setMobilePanel(mobilePanel === 'props' ? null : 'props')} /> : null}
          <IconButton name="cube-outline" label={width >= 920 ? t('libraries') : null} onPress={() => navigation.navigate('Libraries')} />
          <IconButton name="build-outline" label={width >= 880 ? t('build') : null} active onPress={() => navigation.navigate('Build')} />
        </>}
      />

      <View style={styles.workspaceBar}>
        <Pressable onPress={() => setScreenMenu(true)} style={styles.screenSelect}>
          <Icon name="phone-portrait-outline" size={16} color={colors.primary} />
          <Text style={styles.screenText} numberOfLines={1}>{currentScreen?.name || 'Screen'}</Text>
          <Icon name="chevron-down" size={14} color={colors.textTertiary} />
        </Pressable>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabs}>
          {tabs.map((tab) => (
            <Pressable key={tab.key} onPress={tab.action} style={[styles.tab, tab.key === activeTab && styles.tabActive]}>
              <Icon name={tab.icon} size={16} color={tab.key === activeTab ? colors.primary : colors.textSecondary} />
              <Text style={[styles.tabText, tab.key === activeTab && styles.tabTextActive]}>{tab.label}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <View style={styles.main}>
        {activeTab === 'preview' ? (
          <ComposePreviewPanel
            onOpenFullscreen={() => navigation.navigate('LivePreview')}
            onOpenBuild={() => navigation.navigate('Build', { task: 'assembleDebug' })}
          />
        ) : (
          <>
            {wide ? <View style={styles.left}><ComponentPalette onDragStart={onDragStart} onDragMove={onDragMove} onDrop={onDrop} /></View> : null}
            <View ref={canvasRef} collapsable={false} style={styles.canvas} onLayout={measureCanvas}>
              <DesignCanvas
                ref={designCanvasRef}
                showHierarchy={width >= 1320}
                isDragOver={Boolean(drag?.inside)}
                onRequestProperties={() => !wide && setMobilePanel('props')}
              />
            </View>
            {wide ? <View style={styles.right}><PropertyPanel /></View> : null}

            {!wide && mobilePanel ? (
              <View style={[styles.drawer, tablet ? styles.drawerTablet : styles.drawerPhone]}>
                <View style={styles.drawerHead}>
                  <Text style={styles.drawerTitle}>{mobilePanel === 'palette' ? t('components') : t('properties')}</Text>
                  <IconButton name="close" onPress={() => setMobilePanel(null)} style={{ width: 36, minWidth: 36, height: 36 }} />
                </View>
                <View style={{ flex: 1 }}>
                  {mobilePanel === 'palette'
                    ? <ComponentPalette onDragStart={onDragStart} onDragMove={onDragMove} onDrop={onDrop} compact />
                    : <PropertyPanel compact />}
                </View>
              </View>
            ) : null}
          </>
        )}
      </View>

      <View style={[styles.logDock, { height: logHeight }]}>
        <View style={styles.logHead}>
          <Icon name="terminal-outline" size={15} color={colors.textSecondary} />
          <Text style={styles.logTitle}>{copy.output}</Text>
          <View style={{ flex: 1 }} />
          {logMode !== 'hidden' ? <Pressable onPress={clearWorkspaceLogs} style={styles.logAction}><Icon name="trash-outline" size={13} color={colors.textTertiary} /><Text style={styles.logActionText}>{copy.clear}</Text></Pressable> : null}
          <SegmentedControl compact value={logMode} onChange={setLogMode} options={[
            { value: 'hidden', label: '', icon: 'chevron-down-outline', flex: false },
            { value: 'half', label: '', icon: 'remove-outline', flex: false },
            { value: 'full', label: '', icon: 'chevron-up-outline', flex: false },
          ]} />
        </View>
        {logMode !== 'hidden' ? (
          <ScrollView style={styles.logs} contentContainerStyle={{ padding: 10 }}>
            {logs.map((log) => (
              <View key={log.id} style={styles.logRow}>
                <Text style={styles.logTime}>{new Date(log.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</Text>
                <Icon name={log.level === 'success' ? 'checkmark-circle-outline' : log.level === 'error' ? 'alert-circle-outline' : 'information-circle-outline'} size={13} color={log.level === 'success' ? '#4ADE80' : log.level === 'error' ? '#F87171' : '#60A5FA'} />
                <Text selectable style={styles.logText}>{log.text}</Text>
              </View>
            ))}
          </ScrollView>
        ) : null}
      </View>

      {drag ? (
        <View pointerEvents="none" style={[styles.dragGhost, { left: drag.x - 55, top: drag.y - 24 }, drag.inside && { borderColor: colors.primary }]}>
          <Icon name={dragIcon?.name || 'cube-outline'} type={dragIcon?.type} size={17} color={dragIcon?.color || colors.primary} />
          <Text style={styles.dragText}>{drag.type}</Text>
        </View>
      ) : null}

      <Modal visible={screenMenu} transparent animationType="fade" onRequestClose={() => setScreenMenu(false)}>
        <Pressable style={styles.overlay} onPress={() => setScreenMenu(false)}>
          <SectionCard style={styles.screenDialog} title={t('screens')} icon="layers-outline">
            {currentProject.screens.map((screen) => (
              <View key={screen.id} style={[styles.screenRow, screen.id === currentScreenId && styles.screenRowActive]}>
                <Pressable style={styles.screenRowMain} onPress={() => { setCurrentScreen(screen.id); setScreenMenu(false); }}>
                  <Icon name="phone-portrait-outline" size={16} color={screen.id === currentScreenId ? colors.primary : colors.textSecondary} />
                  <Text style={styles.screenRowText}>{screen.name}</Text>
                </Pressable>
                <IconButton name="copy-outline" onPress={() => duplicateScreen(screen.id)} style={styles.rowButton} />
                <IconButton name="trash-outline" danger onPress={() => removeScreen(screen.id)} style={styles.rowButton} />
              </View>
            ))}
            <PrimaryButton title={t('addScreen')} icon="add" onPress={() => { setScreenMenu(false); setNewScreenOpen(true); }} />
          </SectionCard>
        </Pressable>
      </Modal>

      <Modal visible={newScreenOpen} transparent animationType="fade" onRequestClose={() => setNewScreenOpen(false)}>
        <View style={styles.overlay}>
          <SectionCard style={styles.newDialog} title={t('addScreen')} icon="phone-portrait-outline">
            <TextInput autoFocus value={newScreenName} onChangeText={setNewScreenName} onSubmitEditing={createScreen} placeholder={copy.screenName} placeholderTextColor={colors.textTertiary} style={styles.input} />
            <View style={{ flexDirection: 'row', gap: 8 }}><IconButton name="close" label={t('cancel')} onPress={() => setNewScreenOpen(false)} style={{ flex: 1 }} /><PrimaryButton title={t('addScreen')} icon="add" disabled={!newScreenName.trim()} onPress={createScreen} style={{ flex: 1 }} /></View>
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>
  );
};

const createStyles = (c) => StyleSheet.create({
  center: { alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  emptyText: { color: c.textSecondary, fontSize: 14 },
  workspaceBar: { minHeight: 49, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, backgroundColor: c.bgCard, borderBottomWidth: 1, borderBottomColor: c.border },
  screenSelect: { width: 180, height: 37, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 7, borderRadius: 9, backgroundColor: c.bgElevated, borderWidth: 1, borderColor: c.border },
  screenText: { color: c.text, fontSize: 11, fontWeight: '650', flex: 1 },
  tabs: { paddingHorizontal: 8, gap: 3 },
  tab: { height: 38, paddingHorizontal: 12, borderRadius: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  tabActive: { backgroundColor: c.primarySurface },
  tabText: { color: c.textSecondary, fontSize: 11, fontWeight: '600' },
  tabTextActive: { color: c.primary, fontWeight: '750' },
  main: { flex: 1, flexDirection: 'row', position: 'relative', minHeight: 0 },
  left: { width: 220, borderRightWidth: 1, borderRightColor: c.border },
  canvas: { flex: 1, minWidth: 0 },
  right: { width: 280, borderLeftWidth: 1, borderLeftColor: c.border },
  drawer: { position: 'absolute', zIndex: 30, backgroundColor: c.bgCard, borderColor: c.border, shadowColor: c.shadow, shadowOpacity: 0.25, shadowRadius: 12, elevation: 14, overflow: 'hidden' },
  drawerTablet: { top: 8, bottom: 8, left: 8, width: 300, borderWidth: 1, borderRadius: 14 },
  drawerPhone: { left: 0, right: 0, bottom: 0, height: '70%', borderTopWidth: 1, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  drawerHead: { height: 48, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: c.border },
  drawerTitle: { color: c.text, fontSize: 13, fontWeight: '750', flex: 1 },
  logDock: { backgroundColor: c.terminal, borderTopWidth: 1, borderTopColor: '#253046', overflow: 'hidden' },
  logHead: { height: 39, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: c.terminalRaised },
  logTitle: { color: '#C9D3E3', fontSize: 10, fontWeight: '700' },
  logAction: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7 },
  logActionText: { color: '#8B98AD', fontSize: 9 },
  logs: { flex: 1, backgroundColor: c.terminal },
  logRow: { minHeight: 23, flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  logTime: { color: '#5F6D83', fontSize: 9, fontFamily: 'monospace', width: 55 },
  logText: { color: '#C9D3E3', fontSize: 10, lineHeight: 15, fontFamily: 'monospace', flex: 1 },
  dragGhost: { position: 'absolute', zIndex: 100, height: 48, minWidth: 110, maxWidth: 180, paddingHorizontal: 10, borderRadius: 9, borderWidth: 1, borderColor: c.borderLight, backgroundColor: c.bgCard, flexDirection: 'row', alignItems: 'center', gap: 7, shadowColor: c.shadow, shadowOpacity: 0.3, shadowRadius: 8, elevation: 20 },
  dragText: { color: c.text, fontSize: 10, fontWeight: '700' },
  overlay: { flex: 1, justifyContent: 'center', padding: 18, backgroundColor: c.overlay },
  screenDialog: { width: '100%', maxWidth: 500, alignSelf: 'center' },
  newDialog: { width: '100%', maxWidth: 430, alignSelf: 'center' },
  screenRow: { minHeight: 48, flexDirection: 'row', alignItems: 'center', borderRadius: 9, borderWidth: 1, borderColor: 'transparent' },
  screenRowActive: { backgroundColor: c.primarySurface, borderColor: c.primary },
  screenRowMain: { flex: 1, minHeight: 46, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 11 },
  screenRowText: { color: c.text, fontSize: 12, fontWeight: '650' },
  rowButton: { width: 36, minWidth: 36, height: 36, borderWidth: 0, backgroundColor: 'transparent' },
  input: { minHeight: 46, borderRadius: 10, paddingHorizontal: 12, backgroundColor: c.bgInput, borderWidth: 1, borderColor: c.borderLight, color: c.text, fontSize: 13 },
});

export default EditorScreen;
