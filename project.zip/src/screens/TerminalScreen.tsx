/**
 * Экран терминала — Skia-рендеринг, ввод через системную клавиатуру
 */
import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { theme } from '../utils/theme';
import { useTerminal } from '../store/terminal';
import { SkiaTerminal } from '../terminal/SkiaTerminal';
import type { ScreenBuffer } from '../terminal/ansi';

export default function TerminalScreen() {
  const {
    initialized,
    currentSessionId,
    screens,
    sessions,
    parsers,
    setup,
    startSession,
    writeToSession,
    resizeSession,
  } = useTerminal();

  useEffect(() => {
    setup();
  }, [setup]);

  // Авто-старт сессии если есть установленный дистрибутив
  useEffect(() => {
    if (initialized && !currentSessionId) {
      // Берём первый установленный
      // (если ничего нет — покажем кнопку "Установить")
    }
  }, [initialized, currentSessionId]);

  const screen = currentSessionId ? screens.get(currentSessionId) : null;
  const session = currentSessionId ? sessions.get(currentSessionId) : null;

  if (!initialized) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={theme.primary} size="large" />
        <Text style={styles.muted}>Инициализация proot…</Text>
      </View>
    );
  }

  if (!screen) {
    return (
      <View style={styles.center}>
        <Text style={styles.emoji}>🐧</Text>
        <Text style={styles.title}>Нет активной сессии</Text>
        <Text style={styles.muted}>Запустите дистрибутив из списка установленных</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root} edges={['bottom']}>
      <View style={styles.header}>
        <View style={styles.statusDot} />
        <Text style={styles.title}>
          {session?.distroId ?? 'shell'} @ {currentSessionId?.slice(-5)}
        </Text>
        <Text style={styles.size}>
          {screen.cols}×{screen.rows}
        </Text>
      </View>
      <View style={styles.terminalBox}>
        <SkiaTerminal
          screen={screen as ScreenBuffer}
          onInput={(t) => writeToSession(currentSessionId!, t)}
          onResize={(rows, cols) => resizeSession(currentSessionId!, rows, cols)}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.bg },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.bg,
  },
  emoji: { fontSize: 64, marginBottom: 12 },
  title: {
    color: theme.text,
    fontFamily: theme.font.mono,
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  muted: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 13 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: theme.bgElevated,
    borderBottomWidth: 1,
    borderBottomColor: theme.border,
    gap: 8,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.success,
  },
  size: {
    color: theme.textDim,
    fontFamily: theme.font.mono,
    fontSize: 12,
    marginLeft: 'auto',
  },
  terminalBox: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
});
