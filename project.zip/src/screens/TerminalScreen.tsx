import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useAppSettings } from '../store/appSettings';
import { ROOTFS_NAME, ROOTFS_URL } from '../config/runtime';
import { TerminalView, copyToClipboard, diagnoseProot, getProotStatus, isAvailable, prepareProot } from '../../modules/termux-terminal/src/index';
// prepareProot is kept imported (used by repairAptDpkg below, which is not exposed in the UI).
import * as apt from '../../modules/apt-manager/src/index';

// Терминал Ubuntu — интерактивный: экранная клавиатура и ввод команд разрешены,
// но без панели спец-клавиш (ESC/CTRL/…) — интерфейс проще и чище.
import { cn } from "../utils/cn";
const EXTRA_KEYS = '[]';
const TerminalScreen = ({
  navigation,
  route
}) => {
  const {
    width
  } = useWindowDimensions();
  const {
    colors,
    language,
    t
  } = useAppSettings();
  const styles = useMemo(() => createStyles(colors), [colors]);
  const phone = width < 700;
  const terminalRef = useRef(null);
  const [fontSize, setFontSize] = useState(13);
  const [session, setSession] = useState(null);
  const [status, setStatus] = useState(null);
  const [diagnostics, setDiagnostics] = useState(null);
  const [environmentOpen, setEnvironmentOpen] = useState(false);
  const [installing, setInstalling] = useState(false);
  const [progress, setProgress] = useState(null);
  const copy = language === 'ru' ? {
    title: 'Терминал Ubuntu',
    ready: 'Готов',
    unavailable: 'Нативный терминал недоступен. Откройте development client.',
    environment: 'Среда',
    diagnostics: 'Диагностика',
    reinstall: 'Переустановить Ubuntu',
    image: 'Единственный поддерживаемый образ',
    reinstallText: 'Текущий rootfs будет заменён фиксированным Ubuntu arm64 образом проекта.',
    installing: 'Установка рабочей среды',
    copy: 'Копировать',
    close: 'Закрыть',
    restart: 'Перезапустить'
  } : {
    title: 'Ubuntu terminal',
    ready: 'Ready',
    unavailable: 'The native terminal is unavailable. Open the development client.',
    environment: 'Environment',
    diagnostics: 'Diagnostics',
    reinstall: 'Reinstall Ubuntu',
    image: 'Only supported image',
    reinstallText: 'The current rootfs will be replaced with the fixed project Ubuntu arm64 image.',
    installing: 'Installing workspace',
    copy: 'Copy',
    close: 'Close',
    restart: 'Restart'
  };
  const available = isAvailable();
  const refreshStatus = useCallback(async () => {
    if (!available) return;
    try {
      setStatus(await getProotStatus());
    } catch (e) {}
  }, [available]);
  useEffect(() => {
    refreshStatus();
  }, [refreshStatus]);
  useEffect(() => {
    if (!installing) return undefined;
    const timer = setInterval(async () => {
      try {
        setProgress(await apt.getRootfsProgress());
      } catch (e) {}
    }, 700);
    return () => clearInterval(timer);
  }, [installing]);
  const runDiagnostics = async () => {
    setDiagnostics({
      loading: true,
      output: ''
    });
    try {
      const result = await diagnoseProot();
      setDiagnostics({
        loading: false,
        output: result.output,
        ok: result.ok
      });
    } catch (e) {
      setDiagnostics({
        loading: false,
        output: e?.message || String(e),
        ok: false
      });
    }
  };
  const repairAptDpkg = async () => {
    setDiagnostics({
      loading: true,
      output: ''
    });
    try {
      const result = await prepareProot(true);
      setDiagnostics({
        loading: false,
        output: result.output,
        ok: result.success
      });
    } catch (e) {
      setDiagnostics({
        loading: false,
        output: e?.message || String(e),
        ok: false
      });
    }
  };
  // Note: "Repair apt/dpkg" is not exposed in the UI anymore — the preparation
  // runs automatically on install and before every apt/dpkg command. The function
  // is kept so diagnostics/terminal internals can still trigger it.

  const reinstall = async () => {
    if (!apt.isAvailable()) return;
    setInstalling(true);
    setProgress(null);
    try {
      const result = await apt.installProotRootfs(ROOTFS_URL);
      if (!result.success) throw new Error(result.output || 'Installation failed');
      await refreshStatus();
      setEnvironmentOpen(false);
      setTimeout(() => terminalRef.current?.restart?.(), 300);
    } catch (e) {
      setDiagnostics({
        loading: false,
        output: e?.message || String(e),
        ok: false
      });
    } finally {
      setInstalling(false);
    }
  };
  const onTerminalEvent = event => {
    const value = event.nativeEvent || event;
    if (value.type === 'started') setSession(value);
    if (value.type === 'exit') setSession(current => ({
      ...current,
      exited: true,
      exitCode: value.exitCode
    }));
  };
  const subtitle = session?.pid ? `proot · pid ${session.pid}${session.exited ? ` · exit ${session.exitCode}` : ''}` : status?.ready ? copy.ready : 'proot';
  return <AppScreen style={{
    backgroundColor: colors.terminal
  }}>
      <TopBar compact title={copy.title} subtitle={subtitle} onBack={() => navigation.goBack()} right={phone ? <IconButton name="server-outline" active={environmentOpen} onPress={() => setEnvironmentOpen(value => !value)} /> : <>
          <IconButton name="remove-outline" onPress={() => setFontSize(value => Math.max(8, value - 1))} />
          <IconButton name="add-outline" onPress={() => setFontSize(value => Math.min(30, value + 1))} />
          <IconButton name="clipboard-outline" onPress={() => terminalRef.current?.pasteFromClipboard?.()} />
          <IconButton name="copy-outline" onPress={() => terminalRef.current?.copyTranscriptToClipboard?.()} />
          <IconButton name="keyboard-outline" onPress={() => terminalRef.current?.toggleKeyboard?.()} />
          <IconButton name="refresh-outline" onPress={() => terminalRef.current?.restart?.()} />
          <IconButton name="server-outline" active={environmentOpen} onPress={() => setEnvironmentOpen(value => !value)} />
          <IconButton name="pulse-outline" onPress={runDiagnostics} />
        </>} />

      {phone ? <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        className={styles.phoneTools}
        contentContainerClassName={styles.phoneToolsContent}
        keyboardShouldPersistTaps="always"
      >
        <IconButton name="remove-outline" onPress={() => setFontSize(value => Math.max(8, value - 1))} />
        <IconButton name="add-outline" onPress={() => setFontSize(value => Math.min(30, value + 1))} />
        <IconButton name="clipboard-outline" onPress={() => terminalRef.current?.pasteFromClipboard?.()} />
        <IconButton name="copy-outline" onPress={() => terminalRef.current?.copyTranscriptToClipboard?.()} />
        <IconButton name="keyboard-outline" onPress={() => terminalRef.current?.toggleKeyboard?.()} />
        <IconButton name="refresh-outline" onPress={() => terminalRef.current?.restart?.()} />
        <IconButton name="pulse-outline" onPress={runDiagnostics} />
      </ScrollView> : null}

      {environmentOpen ? <View className={styles.environment}>
          <View className={styles.environmentHead}><View className={styles.serverIcon}><Icon name="server-outline" size={20} color={colors.primary} /></View><View style={{
          flex: 1
        }}><Text className={styles.environmentTitle}>{ROOTFS_NAME}</Text><Text className={styles.environmentMeta}>{copy.image} · arm64</Text></View><StatusPill label={status?.rootfsInstalled ? copy.ready : 'Missing'} tone={status?.rootfsInstalled ? 'success' : 'error'} /></View>
          <Text selectable className={styles.url}>{ROOTFS_URL}</Text>
          <Text className={styles.environmentText}>{copy.reinstallText}</Text>
          <PrimaryButton title={copy.reinstall} icon="download-outline" loading={installing} onPress={reinstall} />
          {installing ? <View className={styles.progressRow}><ActivityIndicator color={colors.primary} /><Text className={styles.progressText}>{progress?.message || copy.installing}{progress?.totalBytes ? ` · ${Math.round(progress.downloadedBytes / progress.totalBytes * 100)}%` : ''}</Text></View> : null}
        </View> : null}

      {available ? <TerminalView ref={terminalRef} className={styles.terminal} fontSize={fontSize} extraKeys={EXTRA_KEYS} initialCommand={route.params?.initialCommand} onTerminalEvent={onTerminalEvent} /> : <View className={styles.fallback}><Icon name="hardware-chip-outline" size={40} color={colors.textTertiary} /><Text className={styles.fallbackText}>{copy.unavailable}</Text></View>}

      <Modal visible={Boolean(diagnostics)} transparent animationType="fade" onRequestClose={() => setDiagnostics(null)}>
        <View className={styles.overlay}>
          <SectionCard className={styles.diagnosticCard} title={copy.diagnostics} icon="pulse-outline" right={diagnostics && !diagnostics.loading ? <StatusPill label={diagnostics.ok ? 'OK' : 'Error'} tone={diagnostics.ok ? 'success' : 'error'} /> : null}>
            {diagnostics?.loading ? <ActivityIndicator color={colors.primary} /> : <ScrollView className={styles.diagnosticOutput}><Text selectable className={styles.diagnosticText}>{diagnostics?.output}</Text></ScrollView>}
            <View className={cn(styles.dialogButtons, phone && 'flex-col')}><IconButton name="copy-outline" label={copy.copy} onPress={() => copyToClipboard(diagnostics?.output || '')} style={phone ? { width: '100%' } : { flex: 1 }} /><PrimaryButton title={copy.close} icon="close" onPress={() => setDiagnostics(null)} style={phone ? { width: '100%' } : { flex: 1 }} /></View>
          </SectionCard>
        </View>
      </Modal>
    </AppScreen>;
};
const createStyles = c => ({
  terminal: "flex-1 bg-terminal",
  phoneTools: "flex-none max-h-[54px] bg-bg-card border-b border-b-border",
  phoneToolsContent: "px-[8px] py-[6px] gap-[7px] items-center",
  environment: "p-[13px] gap-[10px] bg-bg-card border-b border-b-border",
  environmentHead: "flex-row items-center gap-[10px]",
  serverIcon: "w-[38px] h-[38px] rounded-[10px] items-center justify-center bg-primary-surface",
  environmentTitle: "text-text text-[13px] font-bold",
  environmentMeta: "text-text-secondary text-[10px] mt-[2px]",
  environmentText: "text-text-secondary text-[10px] leading-[16px]",
  url: "text-text-tertiary font-mono text-[9px] leading-[14px]",
  progressRow: "flex-row items-center gap-[8px]",
  progressText: "text-text-secondary text-[10px]",
  fallback: "flex-1 items-center justify-center gap-[11px] p-[30px]",
  fallbackText: "text-text-secondary text-center text-[12px] max-w-[400px]",
  overlay: "flex-1 justify-center p-[18px] bg-overlay",
  diagnosticCard: "w-full max-w-[720px] max-h-[78%] self-center",
  diagnosticOutput: "max-h-[430px] rounded-[9px] p-[11px] bg-terminal",
  diagnosticText: "text-[#C9D3E3] font-mono text-[9px] leading-[15px]",
  dialogButtons: "flex-row gap-[8px]"
});
export default TerminalScreen;
