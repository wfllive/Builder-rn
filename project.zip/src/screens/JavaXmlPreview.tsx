import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { AppScreen, IconButton, PrimaryButton, SectionCard, TopBar } from '../components/AppUI';
import { useAppSettings } from '../store/appSettings';
import { renderXmlPreview } from '../../modules/apt-manager/src/index';
import { parseColorsXml, parseStringsXml, prepareLayoutPreview } from '../utils/xmlPreviewParser';

/**
 * Мгновенный предпросмотр XML Layout
 * Нативный Android рендер за 10-30 мс
 */
const JavaXmlPreview = ({ navigation, route }) => {
  const { layoutXml, colorsXml, stringsXml, projectName = 'Preview' } = route?.params || {};
  const { width: screenWidth } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const { colors, language } = useAppSettings();
  const ru = language === 'ru';

  const [darkMode, setDarkMode] = useState(false);
  const [previewBase64, setPreviewBase64] = useState<string | null>(null);
  const [rendering, setRendering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deviceFrame, setDeviceFrame] = useState(true);

  const styles = useMemo(() => createStyles(colors), [colors]);

  const doRender = useCallback(async () => {
    if (!layoutXml) {
      setError(ru ? 'Нет XML разметки для предпросмотра' : 'No XML layout to preview');
      return;
    }

    setRendering(true);
    setError(null);

    try {
      const previewData = prepareLayoutPreview(
        layoutXml,
        colorsXml,
        stringsXml
      );

      // Подбираем плотность в зависимости от экрана
      const density = Math.min(3, Math.max(1.5, screenWidth / 411));
      const result = await renderXmlPreview({
        layoutXml: previewData.layoutXml,
        widthDp: Math.round(screenWidth / density) - 32,
        heightDp: 800,
        isDark: darkMode,
        density,
        colors: previewData.colors,
        strings: previewData.strings,
      });

      if (result.success && result.base64) {
        setPreviewBase64(`data:image/png;base64,${result.base64}`);
      } else {
        setError(result.output || 'Render failed');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRendering(false);
    }
  }, [layoutXml, colorsXml, stringsXml, darkMode, screenWidth, ru]);

  useEffect(() => {
    doRender();
  }, [doRender]);

  return (
    <AppScreen>
      <TopBar
        title={ru ? 'Предпросмотр XML' : 'XML Preview'}
        subtitle={projectName}
        onBack={() => navigation.goBack()}
        right={
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <IconButton
              name={darkMode ? 'moon' : 'sunny'}
              onPress={() => setDarkMode(!darkMode)}
            />
            <IconButton
              name={deviceFrame ? 'phone-portrait' : 'resize'}
              onPress={() => setDeviceFrame(!deviceFrame)}
            />
            <IconButton
              name="refresh"
              onPress={doRender}
              disabled={rendering}
            />
          </View>
        }
      />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 16,
          paddingBottom: insets.bottom + 40,
          alignItems: 'center',
        }}
      >
        <SectionCard
          title={ru ? 'Настройки темы' : 'Theme'}
          icon="color-palette-outline"
          style={{ width: '100%', marginBottom: 16 }}
        >
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Pressable
              onPress={() => setDarkMode(false)}
              style={[
                styles.themeBtn,
                !darkMode && styles.themeBtnActive,
                { borderColor: !darkMode ? colors.primary : colors.border }
              ]}
            >
              <Icon name="sunny" size={20} color={!darkMode ? colors.primary : colors.textSecondary} />
              <Text style={[styles.themeBtnText, { color: !darkMode ? colors.primary : colors.textSecondary }]}>
                {ru ? 'Светлая' : 'Light'}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setDarkMode(true)}
              style={[
                styles.themeBtn,
                darkMode && styles.themeBtnActive,
                { borderColor: darkMode ? colors.primary : colors.border }
              ]}
            >
              <Icon name="moon" size={20} color={darkMode ? colors.primary : colors.textSecondary} />
              <Text style={[styles.themeBtnText, { color: darkMode ? colors.primary : colors.textSecondary }]}>
                {ru ? 'Тёмная' : 'Dark'}
              </Text>
            </Pressable>
          </View>
        </SectionCard>

        {rendering ? (
          <View style={styles.loadingBox}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[styles.loadingText, { color: colors.textSecondary }]}>
              {ru ? 'Рендерим предпросмотр...' : 'Rendering preview...'}
            </Text>
          </View>
        ) : error ? (
          <View style={[styles.errorBox, { backgroundColor: colors.errorBg }]}>
            <Icon name="alert-circle-outline" size={24} color={colors.error} />
            <Text style={[styles.errorText, { color: colors.errorText }]}>{error}</Text>
            <PrimaryButton
              title={ru ? 'Повторить' : 'Retry'}
              icon="refresh"
              onPress={doRender}
              style={{ marginTop: 12 }}
            />
          </View>
        ) : previewBase64 ? (
          <View style={styles.previewContainer}>
            {deviceFrame ? (
              <View style={[styles.deviceFrame, { backgroundColor: darkMode ? '#1C1B1F' : '#FFFFFF' }]}>
                {/* Status bar */}
                <View style={styles.statusBar}>
                  <Text style={styles.statusBarTime}>9:41</Text>
                  <View style={styles.statusBarIcons}>
                    <Icon name="wifi" size={12} color={darkMode ? '#FFFFFF' : '#000000'} />
                    <Icon name="battery-full" size={12} color={darkMode ? '#FFFFFF' : '#000000'} />
                  </View>
                </View>
                <Image
                  source={{ uri: previewBase64 }}
                  style={styles.previewImage}
                  resizeMode="contain"
                />
                {/* Navigation bar */}
                <View style={styles.navBar}>
                  <View style={styles.navHandle} />
                </View>
              </View>
            ) : (
              <Image
                source={{ uri: previewBase64 }}
                style={[styles.previewImageFull, { backgroundColor: darkMode ? '#1C1B1F' : '#FFFFFF' }]}
                resizeMode="contain"
              />
            )}
          </View>
        ) : null}

        <View style={styles.infoBox}>
          <Icon name="flash-outline" size={18} color={colors.success} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.infoTitle, { color: colors.text }]}>
              {ru ? '⚡ Мгновенный нативный предпросмотр' : '⚡ Instant native preview'}
            </Text>
            <Text style={[styles.infoText, { color: colors.textSecondary }]}>
              {ru
                ? 'Рендер настоящими Android View виджетами прямо в приложении, без компиляции. Занимает 10-30 мс.'
                : 'Rendered by real Android View widgets right in the app, without compilation. Takes 10-30 ms.'}
            </Text>
          </View>
        </View>

        {previewBase64 && (
          <Text style={[styles.tipText, { color: colors.textTertiary }]}>
            {ru
              ? 'Это визуальный предпросмотр разметки. Для полной проверки запустите быструю NCS сборку.'
              : 'This is a visual preview of your layout. Run a fast NCS build for full verification.'}
          </Text>
        )}
      </ScrollView>
    </AppScreen>
  );
};

const createStyles = (c: any) => StyleSheet.create({
  themeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 2,
  },
  themeBtnActive: {
    backgroundColor: c.primarySurface,
  },
  themeBtnText: {
    fontSize: 13,
    fontWeight: '700',
  },
  loadingBox: {
    width: '100%',
    minHeight: 300,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    borderRadius: 16,
    backgroundColor: c.bgCard,
  },
  loadingText: {
    fontSize: 14,
  },
  errorBox: {
    width: '100%',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    gap: 10,
  },
  errorText: {
    fontSize: 13,
    textAlign: 'center',
  },
  previewContainer: {
    alignItems: 'center',
    width: '100%',
  },
  deviceFrame: {
    borderRadius: 32,
    borderWidth: 3,
    borderColor: '#253046',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
    width: '90%',
    maxWidth: 380,
  },
  statusBar: {
    height: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  statusBarTime: {
    fontSize: 12,
    fontWeight: '600',
  },
  statusBarIcons: {
    flexDirection: 'row',
    gap: 4,
  },
  previewImage: {
    width: '100%',
    height: 600,
  },
  previewImageFull: {
    width: '100%',
    minHeight: 400,
    borderRadius: 12,
  },
  navBar: {
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  navHandle: {
    width: 100,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#666',
  },
  infoBox: {
    width: '100%',
    flexDirection: 'row',
    gap: 10,
    padding: 14,
    borderRadius: 12,
    backgroundColor: c.successBg,
    marginTop: 16,
  },
  infoTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 4,
  },
  infoText: {
    fontSize: 11,
    lineHeight: 16,
  },
  tipText: {
    fontSize: 10,
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 14,
  },
});

export default JavaXmlPreview;
