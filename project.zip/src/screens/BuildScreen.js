import React, { useMemo, useRef, useState } from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { checkCommand, execute, installEas } from '../utils/shellExecutor';
import { easEnvironment, writeWorkspaceJson } from '../utils/workspace';
import { getProjectDir } from '../config/runtime';

const easConfig = {
  cli: { version: '>= 16.18.0', appVersionSource: 'remote' },
  build: {
    development: { developmentClient: true, distribution: 'internal', android: { buildType: 'apk' } },
    preview: { distribution: 'internal', android: { buildType: 'apk' } },
    production: { autoIncrement: true, android: { buildType: 'app-bundle' } },
  },
  submit: { production: {} },
};

const profiles = {
  development: { icon: 'hammer-outline', format: 'APK', tone: 'info', ru: 'Development client', en: 'Development client' },
  preview: { icon: 'phone-portrait-outline', format: 'APK', tone: 'success', ru: 'Preview', en: 'Preview' },
  production: { icon: 'cloud-upload-outline', format: 'AAB', tone: 'warning', ru: 'Production', en: 'Production' },
};

const BuildScreen = ({ navigation, route }) => {
  const { width } = useWindowDimensions();
  const { currentProject } = useProject();
  const { colors, language, t } = useAppSettings();
  const [profile, setProfile] = useState(route.params?.profile || 'development');
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [resultUrl, setResultUrl] = useState('');
  const [resultState, setResultState] = useState('idle');
  const scrollRef = useRef(null);
  const styles = useMemo(() => createStyles(colors), [colors]);
  const copy = language === 'ru' ? {
    title: 'EAS Build', subtitle: 'Облачная сборка Expo', noProject: 'Сначала откройте проект.',
    choose: 'Профиль сборки', requirements: 'Проверки перед сборкой', cli: 'EAS CLI установлен', auth: 'Expo аккаунт авторизован',
    config: 'eas.json настроен', client: 'expo-dev-client установлен', run: 'Запустить сборку', install: 'Установить EAS CLI',
    openSettings: 'Настройки EAS', running: 'Сборка выполняется', success: 'Сборка отправлена в EAS', failed: 'Сборка завершилась с ошибкой',
    terminal: 'Журнал EAS CLI', clear: 'Очистить', dashboard: 'Открыть EAS dashboard', note: 'EAS выполняет Android-сборку в облаке. APK/AAB появится в аккаунте Expo после завершения очереди.',
  } : {
    title: 'EAS Build', subtitle: 'Expo cloud build', noProject: 'Open a project first.',
    choose: 'Build profile', requirements: 'Pre-build checks', cli: 'EAS CLI installed', auth: 'Expo account authenticated',
    config: 'eas.json configured', client: 'expo-dev-client installed', run: 'Start build', install: 'Install EAS CLI',
    openSettings: 'EAS settings', running: 'Build is running', success: 'Build submitted to EAS', failed: 'Build failed',
    terminal: 'EAS CLI output', clear: 'Clear', dashboard: 'Open EAS dashboard', note: 'EAS builds Android in the cloud. The APK/AAB will appear in the Expo account after the queue completes.',
  };

  const append = (text, level = 'normal') => setLogs((value) => [...value, { id: `${Date.now()}-${value.length}`, text, level }]);
  const run = async () => {
    if (!currentProject || running) return;
    setRunning(true);
    setResultState('running');
    setResultUrl('');
    setLogs([]);
    const cwd = getProjectDir(currentProject);
    try {
      append(`$ cd ${cwd}`, 'command');
      append('$ eas --version', 'command');
      let cli = await checkCommand('eas');
      if (!cli.exists) {
        append('EAS CLI not found. Installing...', 'warning');
        const install = await installEas();
        if (!install.success) throw new Error(install.output || 'EAS CLI installation failed');
        cli = await checkCommand('eas');
      }
      append(`${copy.cli}: ${cli.path}`, 'success');

      const env = await easEnvironment();
      append('$ eas whoami', 'command');
      const whoami = await execute(`${env}eas whoami 2>&1`, cwd);
      if (!whoami.success) throw new Error(`${copy.auth}\n${whoami.output || ''}`);
      append(`${copy.auth}: ${whoami.output.trim().split('\n').pop()}`, 'success');

      append('$ write eas.json', 'command');
      const configWrite = await writeWorkspaceJson(currentProject, 'eas.json', easConfig);
      if (!configWrite.success) throw new Error(configWrite.output || 'Cannot write eas.json');
      append(copy.config, 'success');

      if (profile === 'development') {
        append('$ npx expo install expo-dev-client', 'command');
        const devClient = await execute('npx expo install expo-dev-client 2>&1', cwd);
        String(devClient.output || '').split('\n').filter(Boolean).forEach((line) => append(line, /error/i.test(line) ? 'error' : 'dim'));
        if (!devClient.success) throw new Error(devClient.output || 'expo-dev-client install failed');
        append(copy.client, 'success');
      }

      const command = `${env}eas build --platform android --profile ${profile} --non-interactive 2>&1`;
      append(`$ eas build --platform android --profile ${profile} --non-interactive`, 'command');
      const build = await execute(command, cwd);
      String(build.output || '').split('\n').filter(Boolean).forEach((line) => append(line, /error|failed/i.test(line) ? 'error' : /https?:\/\//i.test(line) ? 'link' : 'normal'));
      const url = String(build.output || '').match(/https?:\/\/[^\s]+/g)?.pop()?.replace(/[),.;]+$/, '') || '';
      if (url) setResultUrl(url);
      if (!build.success) throw new Error(build.output || copy.failed);
      append(copy.success, 'success');
      setResultState('success');
    } catch (e) {
      append(e?.message || String(e), 'error');
      setResultState('error');
    } finally {
      setRunning(false);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    }
  };

  if (!currentProject) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View style={styles.empty}><Icon name="cloud-offline-outline" size={38} color={colors.textTertiary} /><Text style={styles.muted}>{copy.noProject}</Text></View></AppScreen>;

  const current = profiles[profile];
  return (
    <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="options-outline" label={width >= 700 ? copy.openSettings : null} onPress={() => navigation.navigate('ProjectSettings')} />} />
      <View style={[styles.main, width < 800 && { flexDirection: 'column' }]}>
        <ScrollView style={[styles.settings, width < 800 && { flex: 0, maxHeight: 390 }]} contentContainerStyle={styles.settingsContent}>
          <SectionCard title={copy.choose} icon="layers-outline">
            <SegmentedControl value={profile} onChange={setProfile} options={Object.entries(profiles).map(([value, item]) => ({ value, label: item[language], icon: item.icon }))} />
            <View style={styles.profileSummary}>
              <View style={styles.profileIcon}><Icon name={current.icon} size={24} color={colors.primary} /></View>
              <View style={{ flex: 1 }}><Text style={styles.profileTitle}>{current[language]}</Text><Text style={styles.profileText}>Android · {current.format} · {profile}</Text></View>
              <StatusPill label={current.format} tone={current.tone} />
            </View>
          </SectionCard>
          <SectionCard title={copy.requirements} icon="checkmark-done-outline">
            <Requirement icon="terminal-outline" text={copy.cli} colors={colors} styles={styles} />
            <Requirement icon="person-outline" text={copy.auth} colors={colors} styles={styles} />
            <Requirement icon="document-text-outline" text={copy.config} colors={colors} styles={styles} />
            {profile === 'development' ? <Requirement icon="phone-portrait-outline" text={copy.client} colors={colors} styles={styles} /> : null}
          </SectionCard>
          <View style={styles.note}><Icon name="information-circle-outline" size={17} color={colors.info} /><Text style={styles.noteText}>{copy.note}</Text></View>
          <PrimaryButton title={running ? copy.running : copy.run} icon="cloud-upload-outline" loading={running} onPress={run} />
        </ScrollView>

        <View style={styles.consoleWrap}>
          <View style={styles.consoleHead}>
            <View style={styles.consoleDots}><View style={[styles.dot, { backgroundColor: '#F87171' }]} /><View style={[styles.dot, { backgroundColor: '#FBBF24' }]} /><View style={[styles.dot, { backgroundColor: '#34D399' }]} /></View>
            <Text style={styles.consoleTitle}>{copy.terminal}</Text>
            <View style={{ flex: 1 }} />
            {resultState !== 'idle' ? <StatusPill label={resultState === 'running' ? copy.running : resultState === 'success' ? t('ready') : 'Error'} tone={resultState === 'success' ? 'success' : resultState === 'error' ? 'error' : 'info'} /> : null}
            <Pressable onPress={() => setLogs([])} style={styles.clear}><Icon name="trash-outline" size={14} color="#8B98AD" /><Text style={styles.clearText}>{copy.clear}</Text></Pressable>
          </View>
          <ScrollView ref={scrollRef} style={styles.console} contentContainerStyle={styles.consoleContent} onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}>
            {!logs.length ? <View style={styles.consoleEmpty}><Icon name="terminal-outline" size={30} color="#526079" /><Text style={styles.consoleEmptyText}>Select a profile and start EAS Build</Text></View> : logs.map((log) => <Text selectable key={log.id} style={[styles.log, log.level === 'command' && styles.logCommand, log.level === 'success' && styles.logSuccess, log.level === 'error' && styles.logError, log.level === 'warning' && styles.logWarning, log.level === 'dim' && styles.logDim, log.level === 'link' && styles.logLink]}>{log.text}</Text>)}
          </ScrollView>
          {resultUrl || resultState === 'success' ? <View style={styles.resultBar}><Icon name="checkmark-circle" size={20} color={colors.success} /><Text style={styles.resultText} numberOfLines={1}>{resultUrl || copy.success}</Text><PrimaryButton title={copy.dashboard} icon="open-outline" onPress={() => Linking.openURL(resultUrl || 'https://expo.dev/accounts')} /></View> : null}
        </View>
      </View>
    </AppScreen>
  );
};

const Requirement = ({ icon, text, colors, styles }) => <View style={styles.requirement}><View style={styles.requirementIcon}><Icon name={icon} size={16} color={colors.textSecondary} /></View><Text style={styles.requirementText}>{text}</Text><Icon name="ellipse-outline" size={14} color={colors.textTertiary} /></View>;

const createStyles = (c) => StyleSheet.create({
  main: { flex: 1, minHeight: 0, flexDirection: 'row' },
  settings: { width: 430, flexGrow: 0, backgroundColor: c.bg },
  settingsContent: { padding: 13, gap: 12, paddingBottom: 40 },
  profileSummary: { minHeight: 67, borderRadius: 11, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: c.bg },
  profileIcon: { width: 43, height: 43, borderRadius: 11, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' },
  profileTitle: { color: c.text, fontSize: 13, fontWeight: '750' }, profileText: { color: c.textSecondary, fontSize: 9, fontFamily: 'monospace', marginTop: 3 },
  requirement: { minHeight: 42, flexDirection: 'row', alignItems: 'center', gap: 9 }, requirementIcon: { width: 31, height: 31, borderRadius: 8, backgroundColor: c.bgElevated, alignItems: 'center', justifyContent: 'center' }, requirementText: { color: c.textSecondary, fontSize: 11, flex: 1 },
  note: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, padding: 11, borderRadius: 10, backgroundColor: c.infoBg }, noteText: { color: c.infoText, fontSize: 10, lineHeight: 16, flex: 1 },
  consoleWrap: { flex: 1, minWidth: 0, backgroundColor: c.terminal, borderLeftWidth: 1, borderLeftColor: '#253046' },
  consoleHead: { height: 48, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.terminalRaised, borderBottomWidth: 1, borderBottomColor: '#253046' },
  consoleDots: { flexDirection: 'row', gap: 5 }, dot: { width: 8, height: 8, borderRadius: 4 }, consoleTitle: { color: '#D6DEEB', fontSize: 11, fontWeight: '700' }, clear: { flexDirection: 'row', alignItems: 'center', gap: 5, padding: 7 }, clearText: { color: '#8B98AD', fontSize: 9 },
  console: { flex: 1 }, consoleContent: { padding: 14, paddingBottom: 40 }, consoleEmpty: { minHeight: 300, alignItems: 'center', justifyContent: 'center', gap: 9 }, consoleEmptyText: { color: '#526079', fontFamily: 'monospace', fontSize: 10 },
  log: { color: '#C9D3E3', fontSize: 10, lineHeight: 17, fontFamily: 'monospace' }, logCommand: { color: '#FFFFFF', fontWeight: '700', marginTop: 9 }, logSuccess: { color: '#4ADE80' }, logError: { color: '#F87171' }, logWarning: { color: '#FBBF24' }, logDim: { color: '#77849A' }, logLink: { color: '#60A5FA', textDecorationLine: 'underline' },
  resultBar: { minHeight: 62, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.bgCard, borderTopWidth: 1, borderTopColor: c.border }, resultText: { color: c.text, fontSize: 10, fontFamily: 'monospace', flex: 1 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 9 }, muted: { color: c.textSecondary, fontSize: 12 },
});

export default BuildScreen;
