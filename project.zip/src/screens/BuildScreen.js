import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute, inspectAndroidToolchain } from '../utils/shellExecutor';
import { runGradleCommand, syncComposeProject } from '../utils/composeProject';
import { getDebugApk, getProjectDir, getReleaseApk, getReleaseBundle } from '../config/runtime';
import { raiBuild, raiCreateKeystore } from '../utils/rai';
import * as apt from '../../modules/apt-manager/src/index';

const tasks = {
  assembleDebug: { icon: 'bug-outline', format: 'APK', tone: 'info', ru: 'Debug APK', en: 'Debug APK', output: getDebugApk() },
  assembleRelease: { icon: 'shield-checkmark-outline', format: 'APK', tone: 'success', ru: 'Release APK', en: 'Release APK', output: getReleaseApk() },
  bundleRelease: { icon: 'cube-outline', format: 'AAB', tone: 'warning', ru: 'Play Bundle', en: 'Play Bundle', output: getReleaseBundle() },
  testDebugUnitTest: { icon: 'flask-outline', format: 'TEST', tone: 'info', ru: 'Unit tests', en: 'Unit tests', output: '' },
  lintDebug: { icon: 'search-outline', format: 'LINT', tone: 'neutral', ru: 'Android Lint', en: 'Android Lint', output: '' },
};

const BuildScreen = ({ navigation, route }) => {
  const { width } = useWindowDimensions();
  const { currentProject, addWorkspaceLog } = useProject();
  const { colors, language, t } = useAppSettings();
  const [task, setTask] = useState(route.params?.task || 'assembleDebug');
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [resultState, setResultState] = useState('idle');
  const [artifact, setArtifact] = useState('');
  const [toolchain, setToolchain] = useState({ java: false, sdk: false, gradle: true, output: '' });
  const scrollRef = useRef(null);
  const styles = useMemo(() => createStyles(colors), [colors]);
  const desktop = width >= 800;
  const copy = language === 'ru' ? {
    title: 'Gradle Build', subtitle: 'Нативная сборка Android Jetpack Compose', choose: 'Gradle-задача',
    requirements: 'Среда Android', java: 'JDK 17 или новее', sdk: 'Android SDK / compileSdk', wrapper: 'Gradle Wrapper', compose: 'Kotlin и Compose Compiler',
    run: 'Запустить задачу', running: 'Gradle выполняется', success: 'Задача завершена', failed: 'Gradle завершился с ошибкой',
    terminal: 'Журнал Gradle', clear: 'Очистить', install: 'Установить Debug APK', launch: 'Открыть приложение', settings: 'Настройки сборки',
    note: 'assembleDebug создаёт подписанный debug APK. assembleRelease создаёт release APK, а bundleRelease — AAB для Google Play. Для публикации настройте release keystore.',
    noProject: 'Сначала откройте Compose-проект.', artifact: 'Артефакт', clean: 'Очистить build',
  } : {
    title: 'Gradle Build', subtitle: 'Native Android Jetpack Compose build', choose: 'Gradle task', requirements: 'Android environment',
    java: 'JDK 17 or newer', sdk: 'Android SDK / compileSdk', wrapper: 'Gradle Wrapper', compose: 'Kotlin and Compose Compiler',
    run: 'Run task', running: 'Gradle is running', success: 'Task completed', failed: 'Gradle failed', terminal: 'Gradle output', clear: 'Clear',
    install: 'Install Debug APK', launch: 'Open application', settings: 'Build settings', note: 'assembleDebug creates a signed debug APK. assembleRelease creates a release APK and bundleRelease creates a Play Store AAB. Configure a release keystore before publishing.',
    noProject: 'Open a Compose project first.', artifact: 'Artifact', clean: 'Clean build',
  };

  const refreshToolchain = async () => {
    const result = await inspectAndroidToolchain();
    const output = result.output || '';
    const javaLine = output.split('\n').find((line) => line.startsWith('java=')) || '';
    setToolchain({
      java: /version|openjdk/i.test(javaLine) && !/not found/i.test(javaLine),
      sdk: /android_home=\S+/.test(output) || /sdkmanager=\S+/.test(output),
      gradle: true,
      output,
    });
  };
  useEffect(() => { if (currentProject) refreshToolchain(); }, [currentProject?.id]);

  const append = (text, level = 'normal') => setLogs((value) => [...value, { id: `${Date.now()}-${value.length}`, text, level }]);
  const run = async (selectedTask = task) => {
    if (!currentProject || running) return;
    setRunning(true); setResultState('running'); setLogs([]); setArtifact('');
    const cwd = getProjectDir(currentProject);
    try {
      append(`$ cd ${cwd}`, 'command');
      append('$ synchronize generated Kotlin sources', 'command');
      const synced = await syncComposeProject(currentProject);
      if (!synced.success) throw new Error(synced.output || 'Compose source sync failed');
      append(synced.output, 'success');
      const raiVariant = selectedTask === 'assembleRelease' ? 'release' : selectedTask === 'bundleRelease' ? 'bundle' : null;
      if (raiVariant) {
        append(`$ rai keystore create ${currentProject.name}`, 'command');
        const key = await raiCreateKeystore(currentProject.name);
        if (!key?.success && !/already exists|exists/i.test(key?.output || '')) throw new Error(key?.output || 'Could not create release keystore');
        String(key.output || '').split('\\n').filter(Boolean).forEach((line) => append(line, 'normal'));
      }
      append(`$ rai build ${currentProject.name}${raiVariant ? ` ${raiVariant}` : ''}`, 'command');
      const result = (selectedTask === 'assembleDebug' || selectedTask === 'assembleRelease' || selectedTask === 'bundleRelease')
        ? await raiBuild(currentProject.name, raiVariant)
        : await execute(runGradleCommand(selectedTask), cwd);
      String(result.output || '').split('\n').filter(Boolean).forEach((line) => append(line, /error|failed|exception/i.test(line) ? 'error' : /warning/i.test(line) ? 'warning' : /BUILD SUCCESSFUL|up-to-date/i.test(line) ? 'success' : 'normal'));
      if (!result.success) throw new Error(result.output || copy.failed);
      const output = tasks[selectedTask]?.output;
      if (output) {
        const extension = tasks[selectedTask]?.format === 'AAB' ? 'aab' : 'apk';
        const found = await execute(`[ -f "${output}" ] && printf '%s' "${output}" || find app/build/outputs -type f -name '*.${extension}' | sort | tail -1`, cwd);
        const relative = found.output?.trim();
        if (relative) setArtifact(`${cwd}/${relative}`);
      }
      setResultState('success');
      addWorkspaceLog(`${selectedTask}: BUILD SUCCESSFUL`, 'success');
    } catch (error) {
      append(error?.message || String(error), 'error'); setResultState('error');
      addWorkspaceLog(error?.message || String(error), 'error');
    } finally { setRunning(false); setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80); }
  };

  const installDebug = async () => {
    const path = `${getProjectDir(currentProject)}/${getDebugApk()}`;
    const result = await apt.installApk?.(path);
    append(result?.success ? 'Android package installer opened.' : result?.output || 'Rebuild Compose Studio to enable native APK installation.', result?.success ? 'success' : 'error');
  };
  const launch = async () => {
    const packageId = task === 'assembleDebug' ? `${currentProject.packageName}.debug` : currentProject.packageName;
    const result = await apt.launchPackage?.(packageId);
    if (!result?.success) append(result?.output || 'Application is not installed.', 'error');
  };

  if (!currentProject) return <AppScreen><TopBar title={copy.title} onBack={() => navigation.goBack()} /><View style={styles.empty}><Icon name="logo-android" size={40} color={colors.textTertiary} /><Text style={styles.muted}>{copy.noProject}</Text></View></AppScreen>;
  const current = tasks[task];
  const options = Object.entries(tasks).map(([value, item]) => ({ value, label: width < 470 ? item.format : item[language], icon: item.icon }));
  return (
    <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={() => navigation.goBack()} right={<IconButton name="options-outline" label={width >= 720 ? copy.settings : null} onPress={() => navigation.navigate('ProjectSettings')} />} />
      <View style={[styles.main, !desktop && styles.mainMobile]}>
        <ScrollView style={[styles.settingsPane, !desktop && styles.settingsMobile]} contentContainerStyle={styles.settingsContent}>
          <SectionCard title={copy.choose} icon="hammer-outline">
            <SegmentedControl value={task} onChange={setTask} options={options} />
            <View style={styles.taskSummary}><View style={styles.taskIcon}><Icon name={current.icon} size={23} color={colors.primary} /></View><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.taskTitle}>{current[language]}</Text><Text style={styles.taskMeta}>./gradlew {task} · {current.format}</Text></View><StatusPill label={current.format} tone={current.tone} /></View>
          </SectionCard>
          <SectionCard title={copy.requirements} icon="hardware-chip-outline">
            <Requirement icon="cafe-outline" text={copy.java} ok={toolchain.java} styles={styles} colors={colors} />
            <Requirement icon="logo-android" text={`${copy.sdk} ${currentProject.compileSdk}`} ok={toolchain.sdk} styles={styles} colors={colors} />
            <Requirement icon="git-branch-outline" text={`${copy.wrapper} ${currentProject.gradleVersion}`} ok={toolchain.gradle} styles={styles} colors={colors} />
            <Requirement icon="color-wand-outline" text={`${copy.compose} ${currentProject.kotlinVersion}`} ok styles={styles} colors={colors} />
            <IconButton name="refresh-outline" label={t('retry')} onPress={refreshToolchain} />
          </SectionCard>
          <View style={styles.note}><Icon name="information-circle-outline" size={17} color={colors.info} /><Text style={styles.noteText}>{copy.note}</Text></View>
          <PrimaryButton title={running ? copy.running : copy.run} icon="hammer-outline" loading={running} onPress={() => run()} />
          <IconButton name="trash-outline" label={copy.clean} disabled={running} onPress={() => run('clean')} />
        </ScrollView>
        <View style={[styles.consoleWrap, !desktop && styles.consoleMobile]}>
          <View style={styles.consoleHead}><View style={styles.dots}><View style={[styles.dot, { backgroundColor: '#F87171' }]} /><View style={[styles.dot, { backgroundColor: '#FBBF24' }]} /><View style={[styles.dot, { backgroundColor: '#34D399' }]} /></View><Text style={styles.consoleTitle}>{copy.terminal}</Text><View style={{ flex: 1 }} />{resultState !== 'idle' ? <StatusPill label={resultState === 'success' ? copy.success : resultState === 'error' ? 'Error' : 'Gradle…'} tone={resultState === 'success' ? 'success' : resultState === 'error' ? 'error' : 'info'} /> : null}<Pressable onPress={() => setLogs([])} style={styles.clear}><Icon name="trash-outline" size={14} color="#8B98AD" /></Pressable></View>
          <ScrollView ref={scrollRef} style={styles.console} contentContainerStyle={styles.consoleContent} onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}>
            {!logs.length ? <View style={styles.consoleEmpty}><Icon name="hammer-outline" size={30} color="#526079" /><Text style={styles.consoleEmptyText}>./gradlew {task}</Text></View> : logs.map((line) => <Text selectable key={line.id} style={[styles.log, line.level === 'command' && styles.command, line.level === 'success' && styles.success, line.level === 'error' && styles.error, line.level === 'warning' && styles.warning]}>{line.text}</Text>)}
          </ScrollView>
          {artifact ? <View style={styles.artifactBar}><Icon name="cube-outline" size={20} color={colors.success} /><View style={{ flex: 1, minWidth: 0 }}><Text style={styles.artifactLabel}>{copy.artifact}</Text><Text style={styles.artifactPath} numberOfLines={1}>{artifact}</Text></View>{task === 'assembleDebug' ? <PrimaryButton title={copy.install} icon="download-outline" onPress={installDebug} /> : null}<IconButton name="play-outline" label={width >= 600 ? copy.launch : null} onPress={launch} /></View> : null}
        </View>
      </View>
    </AppScreen>
  );
};

const Requirement = ({ icon, text, ok, styles, colors }) => <View style={styles.requirement}><View style={styles.requirementIcon}><Icon name={icon} size={16} color={colors.textSecondary} /></View><Text style={styles.requirementText}>{text}</Text><Icon name={ok ? 'checkmark-circle' : 'alert-circle'} size={16} color={ok ? colors.success : colors.warning} /></View>;
const createStyles = (c) => StyleSheet.create({
  main: { flex: 1, minWidth: 0, minHeight: 0, flexDirection: 'row', overflow: 'hidden' }, mainMobile: { flexDirection: 'column' }, settingsPane: { width: '40%', maxWidth: 440, minWidth: 340, flexGrow: 0 }, settingsMobile: { width: '100%', maxWidth: '100%', minWidth: 0, flex: 0, maxHeight: '53%' }, settingsContent: { padding: 13, gap: 12, paddingBottom: 40 }, taskSummary: { minHeight: 66, padding: 10, borderRadius: 11, backgroundColor: c.bg, flexDirection: 'row', alignItems: 'center', gap: 10 }, taskIcon: { width: 43, height: 43, borderRadius: 11, backgroundColor: c.primarySurface, alignItems: 'center', justifyContent: 'center' }, taskTitle: { color: c.text, fontSize: 13, fontWeight: '750' }, taskMeta: { color: c.textTertiary, fontFamily: 'monospace', fontSize: 9, marginTop: 3 }, requirement: { minHeight: 42, flexDirection: 'row', alignItems: 'center', gap: 9 }, requirementIcon: { width: 31, height: 31, borderRadius: 8, backgroundColor: c.bgElevated, alignItems: 'center', justifyContent: 'center' }, requirementText: { flex: 1, color: c.textSecondary, fontSize: 11 }, note: { padding: 11, borderRadius: 10, flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: c.infoBg }, noteText: { flex: 1, color: c.infoText, fontSize: 10, lineHeight: 16 },
  consoleWrap: { flex: 1, minWidth: 0, minHeight: 0, backgroundColor: c.terminal, borderLeftWidth: 1, borderLeftColor: '#253046' }, consoleMobile: { width: '100%', borderLeftWidth: 0, borderTopWidth: 1, borderTopColor: '#253046' }, consoleHead: { height: 48, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.terminalRaised, borderBottomWidth: 1, borderBottomColor: '#253046' }, dots: { flexDirection: 'row', gap: 5 }, dot: { width: 8, height: 8, borderRadius: 4 }, consoleTitle: { color: '#D6DEEB', fontSize: 11, fontWeight: '700' }, clear: { padding: 7 }, console: { flex: 1 }, consoleContent: { padding: 14, paddingBottom: 40 }, consoleEmpty: { minHeight: 280, alignItems: 'center', justifyContent: 'center', gap: 9 }, consoleEmptyText: { color: '#526079', fontFamily: 'monospace', fontSize: 10 }, log: { color: '#C9D3E3', fontFamily: 'monospace', fontSize: 10, lineHeight: 17 }, command: { color: '#FFFFFF', fontWeight: '700', marginTop: 8 }, success: { color: '#4ADE80' }, error: { color: '#F87171' }, warning: { color: '#FBBF24' }, artifactBar: { minHeight: 64, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 9, backgroundColor: c.bgCard, borderTopWidth: 1, borderTopColor: c.border }, artifactLabel: { color: c.text, fontSize: 10, fontWeight: '700' }, artifactPath: { color: c.textSecondary, fontFamily: 'monospace', fontSize: 8, marginTop: 2 }, empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 9 }, muted: { color: c.textSecondary },
});

export default BuildScreen;
