import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, Share, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { AppScreen, IconButton, PrimaryButton, SectionCard, SegmentedControl, StatusPill, TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { execute } from '../utils/shellExecutor';
import { getProjectDir } from '../config/runtime';
import { prepareProject } from '../utils/prepareProject';
import * as apt from '../../modules/apt-manager/src/index';
import { startBackground, stopBackground } from '../utils/background';
import { TerminalView, isAvailable as terminalAvailable } from '../../modules/termux-terminal/src/index';

const EXTRA_KEYS = JSON.stringify([
  ['ESC', '/', { key: '-', popup: '|' }, 'PASTE', 'HOME', 'UP', 'END', 'KEYBOARD'],
  ['TAB', 'CTRL', 'ALT', 'LEFT', 'DOWN', 'RIGHT', 'PGDN', 'BKSP'],
]);

const tasks = {
  dev: { icon: 'flash-outline', label: 'Vite dev', cmd: 'npm run dev', desc: 'Локальный Vite dev-server', tone: 'info' },
  build: { icon: 'hammer-outline', label: 'Vite build', cmd: 'npm run build', desc: 'Сборка dist/', tone: 'success' },
  android: { icon: 'logo-android', label: 'Android APK', cmd: 'bash build-android.sh', desc: 'dist → android/assets → APK', tone: 'warning' },
  prepare: { icon: 'shield-checkmark-outline', label: 'Prepare SDK37', cmd: 'bash prepare.sh', desc: '7 шагов: wrapper/SDK37/конфликты', tone: 'info' },
};

const BuildScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { currentProject, addWorkspaceLog } = useProject();
  const { colors, language, t } = useAppSettings();
  const [task, setTask] = useState('build');
  const [variant, setVariant] = useState('debug'); // debug | release (для задачи android)
  const [running, setRunning] = useState(false);
  const [logs, setLogs] = useState([]);
  const [resultState, setResultState] = useState('idle');
  const [artifact, setArtifact] = useState('');
  const [fontSize, setFontSize] = useState(18);
  const scrollRef = useRef(null);
  const terminalRef = useRef(null);
  const terminalReadyRef = useRef(false);
  const terminalPendingRef = useRef([]);
  const styles = useMemo(()=>createStyles(colors),[colors]);
  const desktop = width >= 800;
  const ru = language==='ru';
  const copy = ru ? {
    title: 'Сборка React', subtitle: 'Vite + Android WebView', choose:'Задача сборки', run:'Запустить', running:'Выполняется…', success:'Успешно', failed:'Ошибка',
    terminal:'Журнал сборки', clear:'Очистить', install:'Установить APK', launch:'Открыть', note:'Vite собирает React в dist/, build-android.sh копирует dist в app/src/main/assets/ для WebView. Затем собирается APK через Gradle-wrapper обёртки WebView.',
    noProject:'Сначала откройте проект.', artifact:'Артефакт', clean:'Очистить',
  } : {
    title: 'React Build', subtitle: 'Vite + Android WebView', choose:'Build task', run:'Run', running:'Running…', success:'Success', failed:'Failed',
    terminal:'Build log', clear:'Clear', install:'Install APK', launch:'Open', note:'Vite builds React to dist/, build-android.sh copies dist to app/src/main/assets/ for WebView. Then APK is built via WebView Gradle wrapper.',
    noProject:'Open a project first.', artifact:'Artifact', clean:'Clean',
  };

  const writeTerminal = (text) => {
    if (!text && text !== '') return;
    if (terminalReadyRef.current) {
      try { terminalRef.current?.writeText?.(String(text).replace(/\n/g, '\r\n') + '\r\n'); } catch (_) {}
    } else {
      terminalPendingRef.current.push(String(text));
    }
  };

  // Выполнить команду ВНУТРИ терминала (PTY), вернуть true/false по маркеру.
  // Как в установщике: терминал показывает живой bash, а не журнал.
  const runInTerminal = async (label, command, { timeoutMs = 30 * 60 * 1000, cwd } = {}) => {
    if (!terminalReadyRef.current) {
      // Терминал не готов — фолбэк: команда через execute (журнал).
      append(`$ ${label}`, 'command');
      const r = await execute(`cd ${cwd ? `'${cwd}'` : ''} && ${command} 2>&1; echo RC:$?`, cwd);
      String(r.output || '').split('\n').filter(Boolean).forEach((l) => append(l));
      return /RC:0\b/.test(r.output || '');
    }
    const marker = '/root/.rai-build.done';
    const full = `echo "" > ${marker}; cd ${cwd ? `'${cwd}'` : ''} && ${command}; rc=$?; echo "rc:$rc" > ${marker}`;
    writeTerminal(`\r\n── ${label} ──`);
    try { terminalRef.current?.writeText?.(full + '\n'); } catch (_) {}
    // Ждём маркер
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const r = await execute(`cat ${marker} 2>/dev/null`, '/');
        const v = String(r.output || '').trim();
        if (/^rc:\d+$/.test(v)) {
          const ok = v === 'rc:0';
          append(ok ? `✓ ${label} — готово` : `✗ ${label} — ошибка (rc=${v.slice(3)})`, ok ? 'success' : 'error');
          return ok;
        }
      } catch (_) {}
      await new Promise((r) => setTimeout(r, 1500));
    }
    append(`✗ ${label} — таймаут`, 'error');
    return false;
  };

  const onTerminalEvent = (event) => {
    const value = event?.nativeEvent || event;
    if (value?.type === 'started') {
      terminalReadyRef.current = true;
      const buf = terminalPendingRef.current;
      terminalPendingRef.current = [];
      buf.forEach((t) => writeTerminal(t));
    }
    if (value?.type === 'exit') terminalReadyRef.current = false;
  };

  const clearConsole = () => {
    setLogs([]);
    try { terminalRef.current?.writeText?.('\u001b[2J\u001b[H'); } catch (_) {}
  };

  const append = (text, level='normal')=> {
    setLogs(v=>[...v, {id:`${Date.now()}-${v.length}`, text, level}]);
    writeTerminal(text == null ? '' : text);
  };

  const runPrepare = async ()=>{
    if(!currentProject || running) return;
    setRunning(true); setResultState('running'); setLogs([]); setArtifact('');
    const cwd=getProjectDir(currentProject);
    await startBackground(`${copy.title}: Prepare`);
    try{
      // prepare в терминале (или JS-фолбэк, если нет терминала)
      if (terminalReadyRef.current) {
        const ok = await runInTerminal('prepare.sh — 7 шагов SDK37', '([ -f prepare.sh ] && bash prepare.sh) || echo "prepare.sh нет — используйте Android APK"', { timeoutMs: 30*60*1000, cwd });
        if(!ok) throw new Error('prepare не завершился — смотрите терминал');
      } else {
        const r = await prepareProject(currentProject, {download: true});
        if(!r.success) throw new Error(r.output||'prepare failed');
      }
      setResultState('success');
    }catch(e){ append(e?.message||String(e),'error'); setResultState('error'); }
    finally{ setRunning(false); await stopBackground(); setTimeout(()=>scrollRef.current?.scrollToEnd({animated:true}),80); }
  };

  const run = async (selected=task)=>{
    if(!currentProject || running) return;
    setRunning(true); setResultState('running'); setLogs([]); setArtifact('');
    const cwd=getProjectDir(currentProject);
    // Фоновая служба: долгая сборка (npm install / vite / gradle) продолжается,
    // даже если приложение свернуть или заблокировать экран.
    await startBackground(`${copy.title}: ${selected === 'android' ? `APK ${variant.toUpperCase()}` : (tasks[selected]?.label || selected)}`);
    try{
      writeTerminal(`\r\n\ud83d\udd27 ${selected === 'android' ? `APK ${variant.toUpperCase()}` : (tasks[selected]?.label || selected)} — ${currentProject.name}\r\n`);
      if(selected==='dev'){
        // dev-server не ждёт завершения — запускаем в фоне и показываем PID
        const ok = await runInTerminal('Vite dev (фоновый)', 'nohup npm run dev -- --host 0.0.0.0 --port 5173 > /tmp/vite.log 2>&1 & echo $!', { timeoutMs: 30000, cwd });
        writeTerminal('Откройте http://localhost:5173 или WebView превью\r\n');
        setResultState('success');
        return;
      }
      if(selected==='build'){
        // Только Vite (быстро) — как просили, без APK
        const okInstall = await runInTerminal('install vite (если нужно)', '[ -f node_modules/.bin/vite ] || npm install --silent 2>&1 | tail -10', { timeoutMs: 10*60*1000, cwd });
        const okBuild = await runInTerminal('vite build', 'npm run build 2>&1', { timeoutMs: 20*60*1000, cwd });
        if(!okBuild) throw new Error('vite build не завершился — смотрите терминал');
        // Копируем в android/assets
        await runInTerminal('cp dist → android/assets', 'mkdir -p android/app/src/main/assets && rm -rf android/app/src/main/assets/* && cp -r dist/* android/app/src/main/assets/ 2>/dev/null; ls -lh dist/index.html 2>&1 | head -1', { timeoutMs: 60000, cwd });
        const probe=await execute('ls -lh dist/index.html 2>/dev/null && echo FOUND || echo MISSING', cwd);
        if(/FOUND/.test(probe.output||'')) setArtifact(`${cwd}/dist`);
        setResultState('success'); addWorkspaceLog(`vite build: ${copy.success}`,'success');
      } else if(selected==='android'){
        // Полный APK/AAB пайплайн в ТЕРМИНАЛЕ: npm install → vite build → gradle.
        const gradleTask = variant === 'aab' ? 'bundleRelease' : variant === 'release' ? 'assembleRelease' : 'assembleDebug';
        const label = variant === 'aab' ? 'AAB (bundleRelease)' : `APK ${variant.toUpperCase()}`;
        const ok = await runInTerminal(
          label,
          `( [ -f node_modules/.bin/vite ] || npm install --silent 2>&1 | tail -10 ) && npm run build 2>&1 && ` +
          `mkdir -p android/app/src/main/assets && rm -rf android/app/src/main/assets/* && cp -r dist/* android/app/src/main/assets/ 2>/dev/null && ` +
          `cd android && ./gradlew ${gradleTask} --no-daemon --console=plain --warning-mode=none 2>&1`,
          { timeoutMs: 120*60*1000, cwd }
        );
        if(!ok) throw new Error('Сборка не завершилась — смотрите терминал');
        // Ищем APK или AAB
        const sub = variant === 'aab' ? 'bundle/release' : `apk/${variant==='release'?'release':'debug'}`;
        const ext = variant === 'aab' ? 'aab' : 'apk';
        const probe = await execute(`find android/app/build/outputs/${sub} -name '*.${ext}' 2>/dev/null | head -1`, cwd);
        const outPath = String(probe.output||'').trim();
        if(outPath){
          setArtifact(outPath.startsWith('/') ? outPath : `${cwd}/${outPath}`);
          writeTerminal(`\r\n✅ ${variant==='aab'?'AAB':'APK'}: ${outPath}\r\n`);
          setResultState('success'); addWorkspaceLog(`${variant} ${variant==='aab'?'aab':'apk'}: ${copy.success}`, 'success');
        } else {
          setArtifact(`${cwd}/dist`);
          writeTerminal('\r\n⚠ WebView-пейлоад готов, но артефакт не найден — проверьте терминал\r\n');
          setResultState('success'); addWorkspaceLog(`${variant}: dist готов, артефакт не найден`, 'warning');
        }
      } else if(selected==='prepare'){
        return runPrepare();
      }
    }catch(e){ append(e?.message||String(e),'error'); setResultState('error'); addWorkspaceLog(String(e),'error'); writeTerminal(`\r\n\u274c ${e?.message||String(e)}\r\n`); }
    finally{
      setRunning(false);
      await stopBackground();
      setTimeout(()=>scrollRef.current?.scrollToEnd({animated:true}),80);
    }
  };

  const installDebug = async()=>{
    // Используем реальный путь к APK из артефакта, а не зашитый.
    const path = artifact && artifact.endsWith('.apk') ? artifact : `${getProjectDir(currentProject)}/android/app/build/outputs/apk/debug/app-debug.apk`;
    append(`$ install ${path}`,'command');
    const r=await apt.installApk?.(path);
    append(r?.success? 'Installer opened' : r?.output||'Install unavailable', r?.success?'success':'error');
  };

  // «Журнал» — расшарить ПОЛНЫЙ лог сборки (читаем build.log, если есть),
  // чтобы скопировать и скинуть мне/в поддержку.
  const shareJournal = async()=>{
    let text = logs.map(l=>l.text).join('\n') || (ru?'(журнал пуст — запустите сборку)':'(log empty — run a build)');
    try {
      const cwd = getProjectDir(currentProject);
      const f = await execute('cat build.log 2>/dev/null', cwd);
      if (f?.output && f.output.trim()) text = `=== build.log (${cwd}/build.log) ===\n${f.output}`;
    } catch(e){}
    try { await Share.share({ message: text, title: ru?'Журнал сборки':'Build log' }); }
    catch(e){ append(`${ru?'Не удалось открыть':'Share failed'}: ${e?.message||e}`, 'error'); }
  };

  if(!currentProject) return <AppScreen><TopBar title={copy.title} onBack={()=>navigation.goBack()} /><View style={styles.empty}><Icon name="logo-react" size={40} color={colors.textTertiary} /><Text style={styles.muted}>{copy.noProject}</Text></View></AppScreen>;
  const cur=tasks[task];
  return (
    <AppScreen>
      <TopBar title={copy.title} subtitle={`${currentProject.name} · ${copy.subtitle}`} onBack={()=>navigation.goBack()} right={<IconButton name="options-outline" label={width>=720?'Настройки':null} onPress={()=>navigation.navigate('ProjectSettings')} />} />
      <View style={[styles.main, !desktop && styles.mainMobile]}>
        <ScrollView style={[styles.settingsPane, !desktop && styles.settingsMobile]} contentContainerStyle={styles.settingsContent}>
          <SectionCard title={copy.choose} icon="hammer-outline">
            <SegmentedControl value={task} onChange={setTask} options={Object.entries(tasks).map(([v,it])=>({value:v, label:it.label, icon:it.icon}))} />
            <View style={styles.taskSummary}><View style={styles.taskIcon}><Icon name={cur.icon} size={23} color={colors.primary} /></View><View style={{flex:1}}><Text style={styles.taskTitle}>{cur.label}</Text><Text style={styles.taskMeta}>{task==='android' ? (variant==='aab' ? 'bundleRelease' : variant==='release' ? 'assembleRelease' : 'assembleDebug') : cur.cmd}</Text><Text style={{color:colors.textTertiary,fontSize:10,marginTop:2}}>{cur.desc}</Text></View><StatusPill label={cur.label} tone={cur.tone} /></View>
          </SectionCard>
          {task==='android' ? (
            <SectionCard title={ru ? 'Тип сборки' : 'Build type'} icon={variant==='aab' ? 'cube-outline' : variant==='release' ? 'lock-closed-outline' : 'bug-outline'}>
              <SegmentedControl value={variant} onChange={setVariant} options={[
                { value:'debug', label:'Debug', icon:'bug-outline' },
                { value:'release', label:'Release', icon:'lock-closed-outline' },
                { value:'aab', label:'AAB', icon:'cube-outline' },
              ]} />
              <Text style={{color:colors.textSecondary, fontSize:10, lineHeight:15, marginTop:6}}>
                {variant==='aab'
                  ? (ru ? 'AAB: bundleRelease для Google Play (подпись из keystore.properties).' : 'AAB: bundleRelease for Google Play (signed via keystore.properties).')
                  : variant==='release'
                    ? (ru ? 'Release: R8 + minify + подпись. Нужен keystore.properties; иначе APK будет неподписан.' : 'Release: R8 + minify + signing. Needs keystore.properties; otherwise unsigned APK.')
                    : (ru ? 'Debug: app-debug.apk с debug-keystore. Подходит для установки и теста.' : 'Debug: app-debug.apk with debug keystore. Good for install & test.')}
              </Text>
            </SectionCard>
          ) : null}
          <View style={styles.note}><Icon name="information-circle-outline" size={17} color={colors.info} /><Text style={styles.noteText}>{copy.note}</Text></View>
          <View style={{flexDirection:'row', gap:8}}>
            <PrimaryButton title={running? copy.running : (task==='android' ? `${copy.run} · ${variant==='aab'?'AAB':variant==='release'?'Release':'Debug'}` : copy.run)} icon="hammer-outline" loading={running} onPress={()=>run()} style={{flex:1}} />
            <IconButton name="shield-checkmark-outline" label="Prepare" loading={running} onPress={runPrepare} style={{flex:1}} />
          </View>
          <IconButton name="trash-outline" label={copy.clean} disabled={running} onPress={async()=>{ await execute('rm -rf dist android/app/src/main/assets/* android/app/build 2>/dev/null; echo cleaned', getProjectDir(currentProject)); append('cleaned','info'); }} />
        </ScrollView>
        <View style={[styles.consoleWrap, !desktop && styles.consoleMobile]}>
          <View style={styles.consoleHead}><View style={styles.dots}><View style={[styles.dot,{backgroundColor:'#F87171'}]} /><View style={[styles.dot,{backgroundColor:'#FBBF24'}]} /><View style={[styles.dot,{backgroundColor:'#34D399'}]} /></View><Text style={styles.consoleTitle}>{copy.terminal}</Text><View style={{flex:1}} />
            <IconButton name="remove-outline" onPress={()=>setFontSize(v=>Math.max(10, v-2))} />
            <IconButton name="add-outline" onPress={()=>setFontSize(v=>Math.min(34, v+2))} />
            {resultState!=='idle'? <StatusPill label={resultState==='success'? copy.success: resultState==='error'? 'Error':'…'} tone={resultState==='success'?'success': resultState==='error'?'error':'info'} />:null}
            <Pressable onPress={shareJournal} style={[styles.clear, {flexDirection:'row', gap:4, backgroundColor:'#253046', paddingHorizontal:8, borderRadius:6}]}><Icon name="share-outline" size={13} color="#4ADE80" /><Text style={{color:'#4ADE80', fontSize:10, fontWeight:'700'}}>{ru?'Журнал':'Log'}</Text></Pressable>
            <Pressable onPress={clearConsole} style={styles.clear}><Icon name="trash-outline" size={14} color="#8B98AD" /></Pressable>
          </View>
          {terminalAvailable() ? (
            <View style={styles.consoleTerminalWrap}>
              <TerminalView
                ref={terminalRef}
                style={styles.consoleTerminal}
                fontSize={fontSize}
                extraKeys={EXTRA_KEYS}
                workingDirectory={getProjectDir(currentProject)}
                initialCommand={ru ? 'echo "Сборка: ' + currentProject.name + ' (proot). Нажмите «Запустить»."' : 'echo "Build: ' + currentProject.name + ' (proot). Press Run."'}
                onTerminalEvent={onTerminalEvent}
              />
            </View>
          ) : (
            <ScrollView ref={scrollRef} style={styles.console} contentContainerStyle={styles.consoleContent} onContentSizeChange={()=>scrollRef.current?.scrollToEnd({animated:true})}>
              {!logs.length? <View style={styles.consoleEmpty}><Icon name="logo-react" size={30} color="#526079" /><Text style={styles.consoleEmptyText}>{cur.cmd}</Text></View> : logs.map(l=> <Text selectable key={l.id} style={[styles.log, l.level==='command'&&styles.command, l.level==='success'&&styles.success, l.level==='error'&&styles.error, l.level==='warning'&&styles.warning]}>{l.text}</Text>)}
            </ScrollView>
          )}
          {artifact? <View style={styles.artifactBar}><Icon name="cube-outline" size={20} color={colors.success} /><View style={{flex:1,minWidth:0}}><Text style={styles.artifactLabel}>{copy.artifact}</Text><Text style={styles.artifactPath} numberOfLines={1}>{artifact}</Text></View><PrimaryButton title={copy.install} icon="download-outline" onPress={installDebug} /></View>:null}
        </View>
      </View>
    </AppScreen>
  );
};

const createStyles=c=>StyleSheet.create({
  main:{flex:1,minWidth:0,minHeight:0,flexDirection:'row',overflow:'hidden'}, mainMobile:{flexDirection:'column'}, settingsPane:{width:'40%',maxWidth:440,minWidth:340,flexGrow:0}, settingsMobile:{width:'100%',maxWidth:'100%',minWidth:0,flex:0,maxHeight:'53%'}, settingsContent:{padding:13,gap:12,paddingBottom:40}, taskSummary:{minHeight:66,padding:10,borderRadius:11,backgroundColor:c.bg,flexDirection:'row',alignItems:'center',gap:10}, taskIcon:{width:43,height:43,borderRadius:11,backgroundColor:c.primarySurface,alignItems:'center',justifyContent:'center'}, taskTitle:{color:c.text,fontSize:13,fontWeight:'750'}, taskMeta:{color:c.textTertiary,fontFamily:'monospace',fontSize:9,marginTop:3},
  note:{padding:11,borderRadius:10,flexDirection:'row',alignItems:'flex-start',gap:8,backgroundColor:c.infoBg}, noteText:{flex:1,color:c.infoText,fontSize:10,lineHeight:16},
  consoleWrap:{flex:1,minWidth:0,minHeight:0,backgroundColor:c.terminal,borderLeftWidth:1,borderLeftColor:'#253046'}, consoleMobile:{width:'100%',borderLeftWidth:0,borderTopWidth:1,borderTopColor:'#253046'}, consoleHead:{height:48,paddingHorizontal:12,flexDirection:'row',alignItems:'center',gap:7,backgroundColor:c.terminalRaised,borderBottomWidth:1,borderBottomColor:'#253046'}, dots:{flexDirection:'row',gap:5}, dot:{width:8,height:8,borderRadius:4}, consoleTitle:{color:'#D6DEEB',fontSize:11,fontWeight:'700'}, clear:{padding:7}, consoleTerminalWrap:{flex:1,minWidth:0,minHeight:0,backgroundColor:c.terminal}, consoleTerminal:{flex:1,backgroundColor:c.terminal}, console:{flex:1}, consoleContent:{padding:14,paddingBottom:40}, consoleEmpty:{minHeight:280,alignItems:'center',justifyContent:'center',gap:9}, consoleEmptyText:{color:'#526079',fontFamily:'monospace',fontSize:10}, log:{color:'#C9D3E3',fontFamily:'monospace',fontSize:10,lineHeight:17}, command:{color:'#FFFFFF',fontWeight:'700',marginTop:8}, success:{color:'#4ADE80'}, error:{color:'#F87171'}, warning:{color:'#FBBF24'}, artifactBar:{minHeight:64,padding:9,flexDirection:'row',alignItems:'center',gap:9,backgroundColor:c.bgCard,borderTopWidth:1,borderTopColor:c.border}, artifactLabel:{color:c.text,fontSize:10,fontWeight:'700'}, artifactPath:{color:c.textSecondary,fontFamily:'monospace',fontSize:8,marginTop:2}, empty:{flex:1,alignItems:'center',justifyContent:'center',gap:9}, muted:{color:c.textSecondary},
});
export default BuildScreen;