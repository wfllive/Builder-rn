import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Alert, ActivityIndicator, Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { generateFullProject } from '../utils/fullProjectGenerator';
import { isAvailable, execute, checkCommand, getNodeVersion, installNode, installEas } from '../utils/shellExecutor';
import colors from '../theme/colors';

const BuildScreen = ({ navigation }) => {
  const { currentProject } = useProject();
  const [phase, setPhase] = useState('choose');
  const [mode, setMode] = useState(null);
  const [logs, setLogs] = useState([]);
  const [running, setRunning] = useState(false);
  const [snackUrl, setSnackUrl] = useState(null);
  const [generatedFiles, setGeneratedFiles] = useState(null);
  const [easProfile, setEasProfile] = useState(null);
  const [hasShell, setHasShell] = useState(false);
  const [nodeInfo, setNodeInfo] = useState(null);
  const [checking, setChecking] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    (async () => {
      const shell = isAvailable();
      setHasShell(shell);
      if (shell) {
        const info = await getNodeVersion();
        setNodeInfo(info);
      }
      setChecking(false);
    })();
  }, []);

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  }, [logs]);

  const log = useCallback((text, type = 'info') => {
    setLogs(prev => [...prev, { text, type }]);
  }, []);

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const reset = () => {
    setPhase('choose'); setMode(null); setLogs([]); setRunning(false);
    setSnackUrl(null); setGeneratedFiles(null); setEasProfile(null);
  };

  // ═══ Shell с выводом ═══
  const runShell = async (cmd, workDir = null) => {
    log('$ ' + cmd, 'cmd');
    const result = await execute(cmd, workDir);
    if (result.output) {
      result.output.split('\n').forEach(line => {
        if (line.trim()) {
          const t = line.match(/error|Error|FAIL/i) ? 'error' :
                    line.match(/warn|WARN/i) ? 'warn' :
                    line.match(/✓|success|added|Done|installed/i) ? 'ok' : 'dim';
          log('  ' + line, t);
        }
      });
    }
    log('', 'info');
    return result;
  };

  // ═══ Генерация файлов ═══
  const generate = async () => {
    log('$ Генерация проекта...', 'cmd');
    const files = generateFullProject(currentProject);
    setGeneratedFiles(files);
    for (const name of Object.keys(files)) {
      log('  ✓ ' + name, 'ok');
      await sleep(40);
    }
    log('', 'info');
    log('  ' + Object.keys(files).length + ' файлов готово', 'ok');
    log('', 'info');
    return files;
  };

  // ═══ Запись файлов через shell ═══
  const writeFiles = async (files) => {
    const slug = currentProject.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const pkg = currentProject.packageName || 'com.sketchwarepro.app';
    const projectDir = '/data/data/' + pkg + '/files/projects/' + slug;

    log('$ Запись файлов...', 'cmd');
    await execute('mkdir -p "' + projectDir + '/src/screens"');

    for (const [name, content] of Object.entries(files)) {
      const filePath = projectDir + '/' + name;
      const dir = filePath.substring(0, filePath.lastIndexOf('/'));
      await execute('mkdir -p "' + dir + '"');
      // Base64 encoding для безопасной записи
      const b64 = btoa(unescape(encodeURIComponent(content)));
      await execute('echo "' + b64 + '" | base64 -d > "' + filePath + '"');
    }
    log('  ✓ Файлы записаны в ' + projectDir, 'ok');
    log('', 'info');
    return projectDir;
  };

  // ═══ Установка Node.js ═══
  const ensureNode = async () => {
    log('$ Проверка Node.js...', 'cmd');

    // Проверяем текущую версию
    const info = await getNodeVersion();
    if (info.version) {
      log('  ✓ Node.js ' + info.version + ' (' + info.path + ')', 'ok');
      log('', 'info');
      return true;
    }

    log('  Node.js не найден. Устанавливаю...', 'warn');
    log('', 'info');

    const result = await installNode();

    // Выводим лог установки
    if (result.output) {
      result.output.split('\n').forEach(line => {
        if (line.trim()) {
          const t = line.match(/SUCCESS|installed|✓/i) ? 'ok' :
                    line.match(/FAIL|error|Error/i) ? 'error' : 'dim';
          log('  ' + line, t);
        }
      });
    }

    if (result.success) {
      log('', 'info');
      log('  ✓ Node.js установлен: ' + (result.version || 'OK'), 'ok');

      // Проверяем npm
      log('', 'info');
      log('$ Проверка npm...', 'cmd');
      const npm = await checkCommand('npm');
      if (npm.exists) {
        log('  ✓ npm: ' + npm.path, 'ok');
      } else {
        log('  ⚠ npm не найден', 'warn');
      }

      log('', 'info');
      return true;
    } else {
      log('  ✗ Не удалось установить Node.js', 'error');
      log('', 'info');
      return false;
    }
  };

  // ═══ Expo Go ═══
  const runExpoGo = async () => {
    setMode('expo-go');
    setPhase('terminal');
    setLogs([]);
    setRunning(true);

    if (!hasShell) {
      // Fallback: Snack API
      log('$ Expo Go (Snack API)', 'cmd');
      log('  ShellExecutor недоступен — используется Snack API', 'warn');
      log('', 'info');

      const files = await generate();
      log('$ Публикация на Snack...', 'cmd');

      const snackFiles = {};
      Object.entries(files).forEach(([p, c]) => { snackFiles[p] = { type: 'CODE', contents: c }; });

      try {
        const res = await fetch('https://snack.expo.dev/api/v2/snack', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ description: currentProject.name, templateId: 'blank', files: snackFiles }),
        });
        if (res.ok) {
          const data = await res.json();
          const url = data.url || (data.id ? 'https://snack.expo.dev/' + data.id : null);
          if (url) { log('  ✓ ' + url, 'ok'); setSnackUrl(url); }
          else log('  ⚠ URL не получен', 'warn');
        } else {
          log('  ✗ HTTP ' + res.status, 'error');
        }
      } catch (e) { log('  ✗ ' + e.message, 'error'); }
    } else {
      // Нативный режим
      log('$ Expo Go (нативный режим)', 'cmd');
      log('', 'info');

      const ok = await ensureNode();
      if (!ok) { setRunning(false); return; }

      const files = await generate();
      const projectDir = await writeFiles(files);

      // npm install
      log('$ npm install', 'cmd');
      await runShell('npm install', projectDir);

      // npx expo start
      log('$ npx expo start --tunnel', 'cmd');
      log('  Запуск Metro bundler...', 'dim');
      log('  Отсканируйте QR код в Expo Go', 'info');
      log('', 'info');

      const result = await runShell('npx expo start --tunnel 2>&1 | head -30', projectDir);
      if (result.output) {
        const match = result.output.match(/exp:\/\/[^\s]+/);
        if (match) setSnackUrl(match[0]);
      }
    }

    log('', 'info');
    log('══════════════════════════════', 'success');
    log('  ГОТОВО', 'success');
    log('══════════════════════════════', 'success');
    setRunning(false);
  };

  // ═══ EAS Build ═══
  const runEAS = async (profile) => {
    setMode('eas');
    setEasProfile(profile);
    setPhase('terminal');
    setLogs([]);
    setRunning(true);

    if (!hasShell) {
      log('$ EAS Build (требует dev build)', 'cmd');
      log('  ShellExecutor недоступен.', 'warn');
      log('', 'info');
      await generate();
      log('  Файлы сгенерированы. Скопируйте их.', 'info');
      setRunning(false);
      return;
    }

    const slug = currentProject.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const pkg = currentProject.packageName || 'com.app.' + slug;
    const fmt = profile === 'production' ? 'AAB (Google Play)' : 'APK';

    log('$ EAS Build — ' + profile, 'cmd');
    log('  Формат: ' + fmt, 'info');
    log('  Package: ' + pkg, 'info');
    log('', 'info');

    // Node.js
    const ok = await ensureNode();
    if (!ok) { setRunning(false); return; }

    // EAS CLI
    log('$ Проверка EAS CLI...', 'cmd');
    const eas = await checkCommand('eas');
    if (!eas.exists) {
      log('  EAS CLI не найден. Устанавливаю...', 'warn');
      const easResult = await installEas();
      if (easResult.output) {
        easResult.output.split('\n').filter(l => l.trim()).forEach(l => log('  ' + l, 'dim'));
      }
      log(easResult.success ? '  ✓ EAS CLI установлен' : '  ✗ Ошибка установки EAS CLI', easResult.success ? 'ok' : 'error');
      log('', 'info');
    } else {
      log('  ✓ EAS CLI: ' + eas.path, 'ok');
      log('', 'info');
    }

    // Генерация + запись
    const files = await generate();
    const projectDir = await writeFiles(files);

    // npm install
    await runShell('npm install', projectDir);

    // eas init
    log('$ eas init', 'cmd');
    await runShell('eas init --non-interactive 2>&1 || true', projectDir);

    // eas build
    log('$ eas build --platform android --profile ' + profile, 'cmd');
    log('  Запуск облачной сборки (~5-10 мин)...', 'dim');
    log('', 'info');
    await runShell('eas build --platform android --profile ' + profile + ' --non-interactive 2>&1', projectDir);

    log('', 'info');
    log('══════════════════════════════', 'success');
    log('  ГОТОВО', 'success');
    log('══════════════════════════════', 'success');
    setRunning(false);
  };

  // ═══ Тест терминала ═══
  const runTest = async () => {
    setMode('test');
    setPhase('terminal');
    setLogs([]);
    setRunning(true);

    log('╔══════════════════════════════╗', 'cmd');
    log('║  Тест терминала              ║', 'cmd');
    log('╚══════════════════════════════╝', 'cmd');
    log('', 'info');

    // 1. Shell доступен?
    log('$ Проверка ShellExecutor...', 'cmd');
    log('  ' + (hasShell ? '✓ Доступен' : '✗ Недоступен'), hasShell ? 'ok' : 'error');
    log('', 'info');

    if (!hasShell) {
      log('  ShellExecutor работает только в dev build.', 'warn');
      log('  Создайте dev build: eas build --profile development', 'info');
      setRunning(false);
      return;
    }

    // 2. whoami
    await runShell('whoami');

    // 3. uname
    await runShell('uname -a');

    // 4. pwd
    await runShell('pwd');

    // 5. Node.js
    log('$ Проверка Node.js...', 'cmd');
    const nodeInfo = await getNodeVersion();
    if (nodeInfo.version) {
      log('  ✓ Node.js ' + nodeInfo.version, 'ok');
      log('  ✓ Путь: ' + nodeInfo.path, 'ok');
    } else {
      log('  ✗ Node.js не найден', 'error');
      log('  Попытка установки...', 'warn');
      log('', 'info');
      const ok = await ensureNode();
      if (!ok) { setRunning(false); return; }
    }
    log('', 'info');

    // 6. npm version
    await runShell('npm --version');

    // 7. Простой скрипт
    log('$ Тест: запуск Node.js скрипта...', 'cmd');
    await runShell('node -e "console.log(\'Hello from Node.js!\'); console.log(\'Platform:\', process.platform); console.log(\'Arch:\', process.arch);"');

    // 8. Создание файла
    log('$ Тест: запись файла...', 'cmd');
    await runShell('echo "test content" > /tmp/sketchware_test.txt && cat /tmp/sketchware_test.txt && rm /tmp/sketchware_test.txt');

    // 9. EAS CLI
    log('$ Проверка EAS CLI...', 'cmd');
    const eas = await checkCommand('eas');
    log('  ' + (eas.exists ? '✓ EAS CLI: ' + eas.path : '✗ EAS CLI не установлен'), eas.exists ? 'ok' : 'warn');
    log('', 'info');

    log('══════════════════════════════', 'success');
    log('  ТЕСТ ЗАВЕРШЁН', 'success');
    log('══════════════════════════════', 'success');
    setRunning(false);
  };

  const copyText = (text) => {
    try { require('react-native').Clipboard.setString(text); Alert.alert('Скопировано'); } catch (e) {}
  };
  const copyAll = () => {
    if (!generatedFiles) return;
    copyText(Object.entries(generatedFiles).map(([n, c]) => '// ═══ ' + n + ' ═══\n' + c).join('\n\n'));
  };

  // ═══ RENDER ═══

  if (checking) {
    return (
      <SafeAreaView style={s.container} edges={['top', 'bottom']}>
        <View style={s.center}><ActivityIndicator size="large" color={colors.primary} /><Text style={s.emptyText}>Проверка...</Text></View>
      </SafeAreaView>
    );
  }

  if (!currentProject) {
    return (
      <SafeAreaView style={s.container} edges={['top', 'bottom']}>
        <View style={s.header}>
          <TouchableOpacity style={s.hBtn} onPress={() => navigation.goBack()}><Icon name="arrow-back" size={20} color={colors.text} /></TouchableOpacity>
          <Text style={s.hTitle}>Сборка</Text><View style={{ width: 40 }} />
        </View>
        <View style={s.center}><Text style={s.emptyText}>Нет проекта</Text></View>
      </SafeAreaView>
    );
  }

  if (phase === 'choose') {
    return (
      <SafeAreaView style={s.container} edges={['top', 'bottom']}>
        <View style={s.header}>
          <TouchableOpacity style={s.hBtn} onPress={() => navigation.goBack()}><Icon name="arrow-back" size={20} color={colors.text} /></TouchableOpacity>
          <Text style={s.hTitle}>Сборка проекта</Text><View style={{ width: 40 }} />
        </View>

        <View style={[s.envBar, hasShell ? s.envOk : s.envWarn]}>
          <Icon name={hasShell ? 'checkmark-circle' : 'cloud-outline'} size={16} color={hasShell ? colors.success : colors.warning} />
          <Text style={[s.envText, { color: hasShell ? colors.successText : colors.warningText }]}>
            {hasShell
              ? 'Dev Build · Node.js ' + (nodeInfo?.version || '—') + ' · Shell ✓'
              : 'Expo Go · Snack API (dev build для полной сборки)'}
          </Text>
        </View>

        <ScrollView style={s.scroll} contentContainerStyle={s.scrollPad}>
          <View style={s.projCard}>
            <View style={s.projIcon}><Icon name="cube-outline" size={22} color={colors.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.projName}>{currentProject.name}</Text>
              <Text style={s.projMeta}>{currentProject.screens?.length || 0} экранов · v{currentProject.versionName}</Text>
            </View>
          </View>

          <Text style={s.label}>ЗАПУСК</Text>
          <TouchableOpacity style={s.card} onPress={runExpoGo} activeOpacity={0.7}>
            <View style={[s.cardIcon, { backgroundColor: '#DBEAFE' }]}><Icon name="qr-code" size={24} color="#2563EB" /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.cardTitle}>Expo Go</Text>
              <Text style={s.cardDesc}>{hasShell ? 'Локальный dev server → QR' : 'Snack API → QR'}</Text>
            </View>
            <Icon name="chevron-forward" size={20} color={colors.textTertiary} />
          </TouchableOpacity>

          <Text style={[s.label, { marginTop: 24 }]}>СБОРКА APK / AAB</Text>
          {[
            { p: 'development', icon: 'code-slash-outline', c: '#D97706', bg: '#FEF3C7', t: 'Development', d: 'Debug APK' },
            { p: 'preview', icon: 'phone-portrait-outline', c: '#7C3AED', bg: '#EDE9FE', t: 'Preview', d: 'Release APK' },
            { p: 'production', icon: 'rocket-outline', c: '#059669', bg: '#D1FAE5', t: 'Production', d: 'AAB (Google Play)' },
          ].map(item => (
            <TouchableOpacity key={item.p} style={s.card} onPress={() => runEAS(item.p)} activeOpacity={0.7}>
              <View style={[s.cardIcon, { backgroundColor: item.bg }]}><Icon name={item.icon} size={24} color={item.c} /></View>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTitle}>{item.t}</Text>
                <Text style={s.cardDesc}>{item.d}</Text>
              </View>
              <Icon name="chevron-forward" size={20} color={colors.textTertiary} />
            </TouchableOpacity>
          ))}

          <Text style={[s.label, { marginTop: 24 }]}>ПРОСМОТР И ТЕСТ</Text>
          <TouchableOpacity style={s.card} onPress={() => navigation.navigate('LivePreview')} activeOpacity={0.7}>
            <View style={[s.cardIcon, { backgroundColor: '#D1FAE5' }]}><Icon name="play" size={24} color="#059669" /></View>
            <View style={{ flex: 1 }}>
              <Text style={s.cardTitle}>Предпросмотр</Text>
              <Text style={s.cardDesc}>Прямо в конструкторе</Text>
            </View>
            <Icon name="chevron-forward" size={20} color={colors.textTertiary} />
          </TouchableOpacity>

          {hasShell && (
            <TouchableOpacity style={s.card} onPress={() => navigation.navigate('Terminal')} activeOpacity={0.7}>
              <View style={[s.cardIcon, { backgroundColor: '#FEF3C7' }]}><Icon name="terminal-outline" size={24} color="#D97706" /></View>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTitle}>Terminal</Text>
                <Text style={s.cardDesc}>Full interactive terminal</Text>
              </View>
              <Icon name="chevron-forward" size={20} color={colors.textTertiary} />
            </TouchableOpacity>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ─── TERMINAL ───
  return (
    <SafeAreaView style={s.container} edges={['top', 'bottom']}>
      <View style={s.termHead}>
        <TouchableOpacity style={s.termBtn} onPress={running ? () => setRunning(false) : reset}>
          <Icon name={running ? 'stop-circle-outline' : 'arrow-back'} size={20} color="#E5E7EB" />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={s.termTitle}>{mode === 'expo-go' ? 'Expo Go' : mode === 'test' ? 'Тест терминала' : 'EAS · ' + easProfile}</Text>
          <Text style={s.termSub}>{running ? 'Выполняется...' : 'Завершено'}</Text>
        </View>
        {running && <ActivityIndicator size="small" color="#10B981" />}
        {!running && <Icon name="checkmark-circle" size={22} color="#10B981" />}
      </View>

      <ScrollView ref={scrollRef} style={s.terminal} contentContainerStyle={s.termPad}
        onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}>
        <Text style={s.termPrompt}>sketchware-pro ~ $</Text>
        {logs.map((l, i) => l ? (
          <TouchableOpacity key={i} activeOpacity={0.8} onPress={() => {
            const t = l.text?.trim();
            if (t && t.startsWith('$')) copyText(t.substring(2));
          }}>
            <Text style={[s.logLine,
              l.type === 'cmd' && s.logCmd, l.type === 'ok' && s.logOk,
              l.type === 'dim' && s.logDim, l.type === 'success' && s.logSuccess,
              l.type === 'error' && s.logError, l.type === 'warn' && s.logWarn,
            ]}>{l.text}</Text>
          </TouchableOpacity>
        ) : null)}
        {running && <Text style={s.cursor}>▌</Text>}
      </ScrollView>

      {!running && (
        <ScrollView style={s.resultPanel} contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
          {mode === 'expo-go' && snackUrl && (
            <View style={s.qrCard}>
              <View style={s.qrBox}><QRCode value={snackUrl} size={180} /></View>
              <Text style={s.qrLabel}>Отсканируйте в Expo Go</Text>
              <TouchableOpacity onPress={() => Linking.openURL(snackUrl)}>
                <Text style={s.linkText}>{snackUrl}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.actionBtn} onPress={() => copyText(snackUrl)}>
                <Icon name="copy-outline" size={14} color={colors.primary} />
                <Text style={s.actionBtnText}>Копировать</Text>
              </TouchableOpacity>
            </View>
          )}
          {mode === 'eas' && generatedFiles && (
            <View style={{ gap: 8 }}>
              <TouchableOpacity style={s.primaryBtn} onPress={copyAll}>
                <Icon name="copy-outline" size={16} color="#fff" />
                <Text style={s.primaryBtnText}>Копировать все файлы</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.secondaryBtn} onPress={() => Linking.openURL('https://expo.dev')}>
                <Icon name="globe-outline" size={14} color={colors.textSecondary} />
                <Text style={s.secondaryBtnText}>expo.dev</Text>
              </TouchableOpacity>
            </View>
          )}
          {generatedFiles && <FileList files={generatedFiles} />}
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

const QRCode = ({ value, size }) => {
  try { const QR = require('react-native-qrcode-svg').default; return <QR value={value} size={size} backgroundColor="#fff" color="#111" />; }
  catch (e) { return <View style={{ width: size, height: size, backgroundColor: '#f3f4f6', justifyContent: 'center', alignItems: 'center', borderRadius: 8 }}><Text style={{ fontSize: 11, textAlign: 'center' }}>{value}</Text></View>; }
};

const FileList = ({ files }) => {
  const [open, setOpen] = useState(false); const [sel, setSel] = useState(null);
  const names = Object.keys(files || {});
  return (
    <View style={{ marginTop: 12 }}>
      <TouchableOpacity style={s.fileHead} onPress={() => setOpen(!open)}>
        <Icon name="documents-outline" size={16} color={colors.textSecondary} />
        <Text style={s.fileHeadText}>Файлы ({names.length})</Text>
        <Icon name={open ? 'chevron-up' : 'chevron-down'} size={16} color={colors.textTertiary} />
      </TouchableOpacity>
      {open && names.map(name => (
        <View key={name}>
          <TouchableOpacity style={s.fileRow} onPress={() => setSel(sel === name ? null : name)}>
            <Text style={s.fileName}>{name}</Text>
          </TouchableOpacity>
          {sel === name && <ScrollView style={s.codeBlock} horizontal><Text style={s.codeText} selectable>{files[name]}</Text></ScrollView>}
        </View>
      ))}
    </View>
  );
};

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scroll: { flex: 1 }, scrollPad: { padding: 16, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  emptyText: { color: colors.textTertiary, fontSize: 16 },

  envBar: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  envOk: { backgroundColor: colors.successBg }, envWarn: { backgroundColor: colors.warningBg },
  envText: { fontSize: 12, fontWeight: '600', flex: 1 },

  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  hBtn: { width: 40, height: 40, borderRadius: 10, backgroundColor: colors.bgElevated, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  hTitle: { fontSize: 17, fontWeight: '700', color: colors.text },

  projCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard, borderRadius: 14, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: colors.border },
  projIcon: { width: 44, height: 44, borderRadius: 12, backgroundColor: colors.primarySurface, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  projName: { fontSize: 16, fontWeight: '700', color: colors.text },
  projMeta: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },

  label: { fontSize: 11, fontWeight: '800', color: colors.textTertiary, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.bgCard, borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: colors.border },
  cardIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  cardTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  cardDesc: { fontSize: 12, color: colors.textSecondary, marginTop: 2, lineHeight: 17 },

  termHead: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#1F2937', borderBottomWidth: 1, borderBottomColor: '#374151' },
  termBtn: { width: 40, height: 40, borderRadius: 10, backgroundColor: '#374151', justifyContent: 'center', alignItems: 'center' },
  termTitle: { fontSize: 14, fontWeight: '700', color: '#F9FAFB' },
  termSub: { fontSize: 11, color: '#9CA3AF', marginTop: 1 },

  terminal: { flex: 1, backgroundColor: '#0D1117', minHeight: 150 },
  termPad: { padding: 14, paddingBottom: 20 },
  termPrompt: { fontFamily: 'monospace', fontSize: 12, color: '#7C3AED', marginBottom: 4 },
  logLine: { fontFamily: 'monospace', fontSize: 12, lineHeight: 19, color: '#C9D1D9' },
  logCmd: { color: '#F0F6FC', fontWeight: '700', marginTop: 8 },
  logOk: { color: '#3FB950' }, logDim: { color: '#6E7681' },
  logSuccess: { color: '#3FB950', fontWeight: '700' },
  logError: { color: '#F85149' }, logWarn: { color: '#D29922' },
  cursor: { color: '#3FB950', fontSize: 16, marginTop: 2 },

  resultPanel: { backgroundColor: colors.bgCard, borderTopWidth: 1, borderTopColor: colors.border, maxHeight: '50%' },
  qrCard: { alignItems: 'center', backgroundColor: colors.bgElevated, borderRadius: 16, padding: 20, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  qrBox: { padding: 14, backgroundColor: '#fff', borderRadius: 12 },
  qrLabel: { fontSize: 14, fontWeight: '600', color: colors.text, marginTop: 12 },
  linkText: { fontSize: 12, color: colors.info, fontFamily: 'monospace', marginTop: 6 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: colors.primarySurface, paddingVertical: 12, borderRadius: 10, marginTop: 8 },
  actionBtnText: { color: colors.primary, fontSize: 14, fontWeight: '600' },

  primaryBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: colors.primary, paddingVertical: 14, borderRadius: 12 },
  primaryBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  secondaryBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10 },
  secondaryBtnText: { color: colors.textSecondary, fontSize: 13, fontWeight: '500' },

  fileHead: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: colors.bgElevated, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: colors.border },
  fileHeadText: { flex: 1, fontSize: 13, fontWeight: '600', color: colors.text },
  fileRow: { padding: 10, backgroundColor: colors.bgCard, borderBottomWidth: 1, borderBottomColor: colors.border },
  fileName: { fontSize: 12, color: colors.text, fontFamily: 'monospace' },
  codeBlock: { backgroundColor: '#0D1117', padding: 10, maxHeight: 180 },
  codeText: { color: '#C9D1D9', fontSize: 11, fontFamily: 'monospace', lineHeight: 16 },
});

export default BuildScreen;
