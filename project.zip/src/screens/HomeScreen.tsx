/**
 * Главный экран
 */
import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { theme } from '../utils/theme';
import { useTerminal } from '../store/terminal';
import { Card } from '../components/TerminalView';

export default function HomeScreen({ navigation }: any) {
  const { setup, initialized, installedDistros, setupError, prootDir, rootfsDir } =
    useTerminal();

  useEffect(() => { setup(); }, [setup]);

  return (
    <ScrollView style={styles.root} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Text style={styles.brand}>
        <Text style={{ color: theme.primary }}>$</Text> proot-shell
      </Text>
      <Text style={styles.subtitle}>Linux на Android без Termux</Text>

      <Card style={styles.statusCard}>
        <View style={styles.statusRow}>
          <View style={[styles.dot, { backgroundColor: initialized ? theme.success : theme.warning }]} />
          <Text style={styles.statusTitle}>
            {initialized ? 'Ядро proot активно' : 'Инициализация…'}
          </Text>
        </View>
        {setupError && (
          <Text style={styles.errorText}>⚠ {setupError}</Text>
        )}
        <View style={styles.pathRow}>
          <Text style={styles.pathLabel}>proot:</Text>
          <Text style={styles.path} numberOfLines={1}>{prootDir}</Text>
        </View>
        <View style={styles.pathRow}>
          <Text style={styles.pathLabel}>rootfs:</Text>
          <Text style={styles.path} numberOfLines={1}>{rootfsDir}</Text>
        </View>
      </Card>

      <View style={styles.metrics}>
        <Metric
          icon="📦"
          value={String(installedDistros.length)}
          label="дистрибутивов"
        />
        <Metric
          icon="💾"
          value={`${installedDistros.reduce((a, d) => a + d.sizeMB, 0).toFixed(0)}`}
          label="МБ"
        />
        <Metric
          icon="🐧"
          value="100%"
          label="без root"
        />
      </View>

      <Text style={styles.section}>Быстрые действия</Text>
      <View style={styles.actionsRow}>
        <ActionTile
          icon="📥"
          label="Установленные"
          onPress={() => navigation.navigate('Distros')}
        />
        <ActionTile
          icon="🛒"
          label="Каталог"
          onPress={() => navigation.navigate('Catalog')}
        />
        <ActionTile
          icon="▶"
          label="Терминал"
          onPress={() => navigation.navigate('Terminal')}
        />
      </View>

      <Card style={styles.tip}>
        <Text style={styles.tipTitle}>ℹ️ Как это работает</Text>
        <Text style={styles.tipText}>
          Приложение использует встроенный proot-бинарник (без установки Termux).
          Корневые файловые системы дистрибутивов скачиваются с GitHub и
          распаковываются в файлы приложения. Все процессы изолированы
          через termux-exec bypass.
        </Text>
      </Card>
    </ScrollView>
  );
}

function Metric({ icon, value, label }: { icon: string; value: string; label: string }) {
  return (
    <View style={styles.metric}>
      <Text style={styles.metricIcon}>{icon}</Text>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function ActionTile({ icon, label, onPress }: { icon: string; label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.tile, { opacity: pressed ? 0.65 : 1 }]}>
      <Text style={styles.tileIcon}>{icon}</Text>
      <Text style={styles.tileLabel}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.bg },
  brand: { color: theme.text, fontFamily: theme.font.mono, fontSize: 24, fontWeight: '700' },
  subtitle: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 12, marginTop: 2, marginBottom: 16 },
  statusCard: { marginBottom: 12 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  statusTitle: { color: theme.text, fontFamily: theme.font.mono, fontSize: 14, fontWeight: '700' },
  errorText: { color: theme.error, fontFamily: theme.font.mono, fontSize: 11, marginBottom: 8 },
  pathRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
  pathLabel: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 11, width: 50 },
  path: { color: theme.text, fontFamily: theme.font.mono, fontSize: 11, flex: 1 },
  metrics: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  metric: {
    flex: 1,
    backgroundColor: theme.bgCard,
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.border,
  },
  metricIcon: { fontSize: 22, marginBottom: 4 },
  metricValue: { color: theme.primary, fontFamily: theme.font.mono, fontSize: 18, fontWeight: '700' },
  metricLabel: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 10, marginTop: 2 },
  section: {
    color: theme.textDim,
    fontFamily: theme.font.mono,
    fontSize: 12,
    textTransform: 'uppercase',
    fontWeight: '700',
    marginBottom: 8,
    marginTop: 4,
  },
  actionsRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  tile: {
    flex: 1,
    backgroundColor: theme.bgCard,
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.border,
  },
  tileIcon: { fontSize: 24, marginBottom: 4 },
  tileLabel: { color: theme.text, fontFamily: theme.font.mono, fontSize: 11 },
  tip: { borderColor: theme.accent },
  tipTitle: { color: theme.accent, fontFamily: theme.font.mono, fontSize: 12, fontWeight: '700', marginBottom: 4 },
  tipText: { color: theme.textDim, fontFamily: theme.font.mono, fontSize: 11, lineHeight: 16 },
});
