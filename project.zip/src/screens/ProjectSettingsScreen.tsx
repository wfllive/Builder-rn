import React
{ useMemo
useState } from 'react';
import { Alert
ScrollView
Switch
Text
View
useWindowDimensions } from 'react-native';
import { AppScreen
Field
IconButton
PrimaryButton
SectionCard
SegmentedControl
TopBar } from '../components/AppUI';
import { Icon } from '../components/Icon';
import { useProject } from '../store/projectStore';
import { useAppSettings } from '../store/appSettings';
import { syncComposeProject } from '../utils/composeProject';
import { generateId } from '../utils/generateId';
const ProjectSettingsScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const { currentProject
dispatch } = useProject();
  const { colors
language
t } = useAppSettings();
  const [tab
setTab] = useState('app');
  const [saving
setSaving] = useState(false);
  const [form
setForm] = useState(() => ({
    name: currentProject?.name || ''
packageName: currentProject?.packageName || ''
namespace: currentProject?.namespace || currentProject?.packageName || ''
    versionName: currentProject?.versionName || '1.0.0'
versionCode: String(currentProject?.versionCode || 1)
minSdk: String(currentProject?.minSdk || 26)
iconPngPath: currentProject?.iconPngPath || ''
targetSdk: String(currentProject?.targetSdk || 37)
compileSdk: String(currentProject?.compileSdk || 37)
    reactVersion: currentProject?.reactVersion || '19.2.8'
viteVersion: currentProject?.viteVersion || '5.4.0'
    primaryColor: currentProject?.theme?.primaryColor || '#4F46E5'
secondaryColor: currentProject?.theme?.secondaryColor || '#0E7490'
backgroundColor: currentProject?.theme?.backgroundColor || '#F8FAFC'
isDark: Boolean(currentProject?.theme?.isDark)
    keystorePath: currentProject?.signing?.keystorePath || ''
keyAlias: currentProject?.signing?.keyAlias || ''
storePasswordEnv: currentProject?.signing?.storePasswordEnv || 'KEYSTORE_PASSWORD'
keyPasswordEnv: currentProject?.signing?.keyPasswordEnv || 'KEY_PASSWORD'
  }));
  const [variable
setVariable] = useState({ name: ''
type: 'text'
value: '' });
  const styles = useMemo(() => /* styles removed */(colors)
[colors]);
  const two = width >= 760;
  const copy = language === 'ru' ? {
    title: 'Настройки React проекта'
app: 'Приложение'
android: 'Android-сборка'
theme: 'Тема'
variables: 'Состояние (React)'
    identity: 'Идентификаторы и версии'
build: 'Сборка и SDK'
signing: 'Подпись Release'
name: 'Название'
package: 'Application ID'
namespace: 'Namespace'
version: 'Version name'
code: 'Version code'
    min: 'Min SDK'
target: 'Target SDK'
compile: 'Compile SDK'
react: 'React'
vite: 'Vite'
    primary: 'Primary'
secondary: 'Secondary'
background: 'Background'
dark: 'Тёмная тема'
    keystore: 'Путь к .jks'
alias: 'Key alias'
password: 'Переменная пароля'
keyPassword: 'Переменная ключа'
    iconLabel: 'Иконка PNG (путь)'
iconHint: 'Квадратный PNG ≥432×432
например /sdcard/Download/icon.png. Края (~17%) попадут под маску адаптивной иконки — логотип держите по центру. Пусто — иконка генерируется из цвета темы. После смены выполните «Подготовить проект».'
    saved: 'package.json и React-файлы обновлены'
invalid: 'Проверьте Application ID.'
add: 'Добавить'
stateName: 'Имя'
remove: 'Удалить?'
noProject: 'Проект не открыт'
  } : {
    title: 'React project settings'
app: 'Application'
android: 'Android WebView'
theme: 'Theme'
variables: 'State (React)'
    identity: 'Identifiers and versions'
build: 'Build and SDK'
signing: 'Release signing'
name: 'Application name'
package: 'Application ID'
namespace: 'Namespace'
version: 'Version name'
code: 'Version code'
min: 'Min SDK'
target: 'Target SDK'
compile: 'Compile SDK'
react: 'React'
vite: 'Vite'
primary: 'Primary'
secondary: 'Secondary'
background: 'Background'
dark: 'Dark theme'
    keystore: '.jks path'
alias: 'Key alias'
password: 'Store password env'
keyPassword: 'Key password env'
    iconLabel: 'Icon PNG (path)'
iconHint: 'Square PNG ≥432×432
e.g. /sdcard/Download/icon.png. Edges (~17%) fall under the adaptive icon mask — keep the logo centered. Empty — icon is generated from the theme color. Re-run Prepare project after changing.'
saved: 'package.json and React files updated'
invalid: 'Check Application ID.'
add: 'Add state'
stateName: 'State name'
remove: 'Delete state?'
noProject: 'No project is open'
  };
  if (!currentProject) return <AppScreen className="p-4"><Text className="p-4">{copy.noProject}</Text></AppScreen>;
  const set = (key
value) => setForm((current) => ({ ...current
[key]: value }));
  const save = async () => {
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(form.packageName)) { Alert.alert(copy.invalid); return; }
    setSaving(true);
    const updated = {
      ...currentProject
name: form.name.trim()
packageName: form.packageName.trim()
namespace: form.namespace.trim() || form.packageName.trim()
versionName: form.versionName.trim()
versionCode: Math.max(1
parseInt(form.versionCode
10) || 1)
minSdk: Math.max(26
parseInt(form.minSdk
10) || 26)
iconPngPath: form.iconPngPath.trim()
targetSdk: parseInt(form.targetSdk
10) || 37
compileSdk: parseInt(form.compileSdk
10) || 37
reactVersion: form.reactVersion.trim()
viteVersion: form.viteVersion.trim()
theme: { primaryColor: form.primaryColor
secondaryColor: form.secondaryColor
backgroundColor: form.backgroundColor
isDark: form.isDark }
signing: { keystorePath: form.keystorePath
keyAlias: form.keyAlias
storePasswordEnv: form.storePasswordEnv
keyPasswordEnv: form.keyPasswordEnv }
updatedAt: Date.now()
    };
    dispatch({ type: 'UPDATE_PROJECT'
payload: updated });
    const result = await syncComposeProject(updated);
    setSaving(false);
    Alert.alert(result.success ? t('ready') : 'Build'
result.success ? copy.saved : result.output || 'Save failed');
  };
  const addVariable = () => {
    if (!variable.name.trim()) return;
    const value = variable.type === 'number' ? Number(variable.value) || 0 : variable.type === 'boolean' ? variable.value === 'true' : variable.value;
    dispatch({ type: 'ADD_VARIABLE'
payload: { id: generateId()
name: variable.name.trim()
type: variable.type
value } });
    setVariable({ name: ''
type: 'text'
value: '' });
  };
  return <AppScreen>
    <TopBar title={copy.title} subtitle={`${currentProject.name} · ${currentProject.packageName}`} onBack={() => navigation.goBack()} right={<PrimaryButton title={width >= 560 ? t('save') : ''} icon="save-outline" loading={saving} onPress={save} />} />
    <View className="p-4"><SegmentedControl value={tab} onChange={setTab} options={[{ value: 'app'
label: copy.app
icon: 'logo-react' }
{ value: 'android'
label: copy.android
icon: 'logo-android' }
{ value: 'theme'
label: copy.theme
icon: 'color-palette-outline' }
{ value: 'variables'
label: copy.variables
icon: 'code-working-outline' }]} /></View>
    <ScrollView contentContainerStyle={className="page} keyboardShouldPersistTaps="handled"><View className="p-4">
      {tab === 'app' ? <SectionCard title={copy.identity} icon="finger-print-outline"><View style={two ? className="grid : null}><Field label={copy.name} value={form.name} onChangeText={(v) => set('name'
v)} className="p-4" /><Field label={copy.package} value={form.packageName} onChangeText={(v) => set('packageName'
v)} autoCapitalize="none" className="p-4" /><Field label={copy.namespace} value={form.namespace} onChangeText={(v) => set('namespace'
v)} autoCapitalize="none" className="p-4" /><Field label={copy.version} value={form.versionName} onChangeText={(v) => set('versionName'
v)} className="p-4" /><Field label={copy.code} value={form.versionCode} onChangeText={(v) => set('versionCode'
v)} keyboardType="number-pad" className="p-4" /></View><Field label={copy.iconLabel} value={form.iconPngPath} onChangeText={(v) => set('iconPngPath'
v)} autoCapitalize="none" placeholder="/sdcard/Download/icon.png" className="p-4" /><Text style={{color: colors.textSecondary
fontSize:11
marginTop:8
lineHeight:16}}>{copy.iconHint}</Text></SectionCard> : null}
      {tab === 'android' ? <><SectionCard title={copy.build} icon="hammer-outline"><View style={two ? className="grid : null}><Field label={copy.min} value={form.minSdk} onChangeText={(v) => set('minSdk'
v)} keyboardType="number-pad" className="p-4" /><Field label={copy.target} value={form.targetSdk} onChangeText={(v) => set('targetSdk'
v)} keyboardType="number-pad" className="p-4" /><Field label={copy.compile} value={form.compileSdk} onChangeText={(v) => set('compileSdk'
v)} keyboardType="number-pad" className="p-4" /><Field label={copy.react} value={form.reactVersion} onChangeText={(v) => set('reactVersion'
v)} className="p-4" /><Field label={copy.vite} value={form.viteVersion} onChangeText={(v) => set('viteVersion'
v)} className="p-4" /></View><Text style={{color: colors.textSecondary
fontSize:11
marginTop:8
lineHeight:16}}>{language==='ru'? 'Нативная Android-оболочка на минимальном SDK. Интерфейс собирается полностью на React и встраивается в приложение локально (dist/index.html).': 'Thin native Android shell on the minimal SDK. The UI is built fully in React and embedded locally (dist/index.html).'}</Text></SectionCard><SectionCard title={copy.signing} icon="key-outline"><Field label={copy.keystore} value={form.keystorePath} onChangeText={(v) => set('keystorePath'
v)} autoCapitalize="none" /><Field label={copy.alias} value={form.keyAlias} onChangeText={(v) => set('keyAlias'
v)} /><View style={two ? className="grid : null}><Field label={copy.password} value={form.storePasswordEnv} onChangeText={(v) => set('storePasswordEnv'
v)} className="p-4" /><Field label={copy.keyPassword} value={form.keyPasswordEnv} onChangeText={(v) => set('keyPasswordEnv'
v)} className="p-4" /></View></SectionCard></> : null}
      {tab === 'theme' ? <SectionCard title={copy.theme} icon="color-palette-outline"><Toggle label={copy.dark} value={form.isDark} onChange={(v) => set('isDark'
v)} colors={colors} styles={styles} /><ColorField label={copy.primary} value={form.primaryColor} onChange={(v) => set('primaryColor'
v)} styles={styles} /><ColorField label={copy.secondary} value={form.secondaryColor} onChange={(v) => set('secondaryColor'
v)} styles={styles} /><ColorField label={copy.background} value={form.backgroundColor} onChange={(v) => set('backgroundColor'
v)} styles={styles} /><View style={[className="preview
{ backgroundColor: form.backgroundColor }]}><View style={[className="previewBar
{ backgroundColor: form.primaryColor }]}><Text className="p-4">{form.name}</Text></View><View style={[className="previewButton
{ backgroundColor: form.primaryColor }]} /><View style={[className="previewAccent
{ backgroundColor: form.secondaryColor }]} /></View></SectionCard> : null}
      {tab === 'variables' ? <SectionCard title={`${copy.variables} (${currentProject.variables?.length || 0})`} icon="code-working-outline"><View style={[className="variableForm
!two && { flexDirection: 'column'
alignItems: 'stretch' }]}><Field placeholder={copy.stateName} value={variable.name} onChangeText={(v) => setVariable((c) => ({ ...c
name: v }))} style={{ flex: 2 }} /><SegmentedControl value={variable.type} onChange={(v) => setVariable((c) => ({ ...c
type: v }))} options={[{ value: 'text'
label: 'String' }
{ value: 'number'
label: 'Int' }
{ value: 'boolean'
label: 'Boolean' }]} /><Field placeholder="Initial value" value={variable.value} onChangeText={(v) => setVariable((c) => ({ ...c
value: v }))} className="flex-1" /><PrimaryButton title={copy.add} icon="add" disabled={!variable.name.trim()} onPress={addVariable} /></View>{(currentProject.variables || []).map((item) => <View key={item.id} className="p-4"><View className="p-4"><Icon name="code-slash-outline" size={16} color={colors.primary} /></View><View className="flex-1"><Text className="p-4">{item.name}</Text><Text className="p-4">{item.type} · {String(item.value)}</Text></View><IconButton name="trash-outline" danger onPress={() => Alert.alert(copy.remove
''
[{ text: t('cancel') }
{ text: t('delete')
style: 'destructive'
onPress: () => dispatch({ type: 'DELETE_VARIABLE'
payload: item.id }) }])} /></View>)}</SectionCard> : null}
    </View></ScrollView>
  </AppScreen>;
};
const Toggle = ({ label
value
onChange
colors
styles }) => <View className="p-4"><Text className="p-4">{label}</Text><Switch value={value} onValueChange={onChange} trackColor={{ false: colors.borderLight
true: colors.primary }} thumbColor="#FFFFFF" /></View>;
const ColorField = ({ label
value
onChange
styles }) => <View className="p-4"><View style={[className="swatch
{ backgroundColor: value }]} /><Field label={label} value={value} onChangeText={onChange} autoCapitalize="characters" className="flex-1" /></View>;
// Tailwind className
export default ProjectSettingsScreen;