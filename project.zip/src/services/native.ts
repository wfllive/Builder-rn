/**
 * native.ts — TypeScript обёртка над нативным ProotSession модулем
 * Декларация для TypeScript + безопасная обёртка с типами
 */
import {
  NativeModules,
  NativeEventEmitter,
  EmitterSubscription,
  Platform,
} from 'react-native';

export interface SetupResult {
  ok: boolean;
  prootDir: string;
  rootfsDir: string;
}

export interface StartResult {
  pid: number;
  argv0: string;
}

export interface InstalledDistro {
  id: string;
  sizeMB: number;
  path: string;
  installedAt: number;
}

export interface InstallProgress {
  distroId: string;
  percent: number;
  message: string;
}

export interface SessionExit {
  sessionId: string;
  code: number;
}

export interface SessionOutput {
  sessionId: string;
  data: string; // base64
}

interface ProotSessionNative {
  setup(): Promise<SetupResult>;
  startSession(
    sessionId: string,
    distroId: string,
    command: string[],
    rows: number,
    cols: number
  ): Promise<StartResult>;
  write(sessionId: string, dataBase64: string): void;
  writeText(sessionId: string, text: string): void;
  resize(sessionId: string, rows: number, cols: number): void;
  signal(sessionId: string, sig: number): void;
  kill(sessionId: string): void;
  listInstalled(): Promise<InstalledDistro[]>;
  installDistro(distroId: string, tarballUrl: string): Promise<{ ok: boolean; path: string }>;
  removeDistro(distroId: string): Promise<{ ok: boolean }>;
}

const native = NativeModules.ProotSession as ProotSessionNative | undefined;

if (!native && Platform.OS === 'android') {
  console.warn(
    '[ProotSession] Native module not found. Did you rebuild the app?'
  );
}

const emitter = native ? new NativeEventEmitter(NativeModules.ProotSession) : null;

export const ProotSession = {
  isAvailable: !!native,

  async setup() {
    if (!native) throw new Error('Native module not available');
    return native.setup();
  },

  async startSession(id: string, distroId: string, rows = 40, cols = 100) {
    if (!native) throw new Error('Native module not available');
    return native.startSession(id, distroId, [], rows, cols);
  },

  write(id: string, base64: string) {
    native?.write(id, base64);
  },

  writeText(id: string, text: string) {
    native?.writeText(id, text);
  },

  resize(id: string, rows: number, cols: number) {
    native?.resize(id, rows, cols);
  },

  signal(id: string, sig: number) {
    native?.signal(id, sig);
  },

  kill(id: string) {
    native?.kill(id);
  },

  async listInstalled() {
    if (!native) return [];
    return native.listInstalled();
  },

  installDistro(id: string, url: string) {
    if (!native) throw new Error('Native module not available');
    return native.installDistro(id, url);
  },

  async removeDistro(id: string) {
    if (!native) throw new Error('Native module not available');
    return native.removeDistro(id);
  },

  onOutput(cb: (e: SessionOutput) => void): EmitterSubscription | null {
    return emitter?.addListener('ProotShell:output', cb) ?? null;
  },

  onExit(cb: (e: SessionExit) => void): EmitterSubscription | null {
    return emitter?.addListener('ProotShell:exit', cb) ?? null;
  },

  onInstallProgress(cb: (e: InstallProgress) => void): EmitterSubscription | null {
    return emitter?.addListener('ProotShell:installProgress', cb) ?? null;
  },
};
