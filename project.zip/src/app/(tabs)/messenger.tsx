/**
 * Список чатов. Тап ведёт в профиль (демо без API переписки).
 */
import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import TabScaffold, { useTabBarPad, useTabHeaderPad } from "@/app/_components/tab_scaffold";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import { DEMO_AVATARS } from "@/example/demo_media";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";


const CHATS = [
  { id: 1, name: "Аня", userId: "anya", avatar: DEMO_AVATARS.anya, preview: "Ок, вечером скину макет", when: "5м" },
  { id: 2, name: "Лёша", userId: "lesha", avatar: DEMO_AVATARS.lesha, preview: "Таббар уже лучше выглядит", when: "1ч" },
  { id: 3, name: "Twitblit", userId: "twitblit", avatar: DEMO_AVATARS.twitblit, preview: "Добро пожаловать в native", when: "2д" },
];

export default function MessengerRoute() {
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const padTop = useTabHeaderPad();
  const padBottom = useTabBarPad();

  return (
    <TabScaffold title="Сообщения">
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingTop: padTop, paddingBottom: padBottom }}
        showsVerticalScrollIndicator={false}
      >
        {CHATS.map((chat) => (
          <Pressable
            key={chat.id}
            onPress={() => nav.push(`/tb/${chat.userId}`)}
            className="flex-row items-center px-4 py-3.5 border-b border-primary/10"
          >
            <FlyAvatar src={chat.avatar} alt={chat.name} size="sm" />
            <View className="flex-1 ml-3">
              <View className="flex-row justify-between">
                <Text className="font-semibold" style={{ color: ink }}>
                  {chat.name}
                </Text>
                <Text className="text-xs text-muted">{chat.when}</Text>
              </View>
              <Text className="text-sm text-muted mt-0.5" numberOfLines={1}>
                {chat.preview}
              </Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </TabScaffold>
  );
}
