/**
 * Новый тред. После гостевого входа публикуется в локальную ленту.
 */
import React, { useState } from "react";
import { Text, View } from "react-native";
import TabScaffold, { useTabBarPad, useTabHeaderPad } from "@/app/_components/tab_scaffold";
import FormattingTextarea from "@/shared/widgets/texts/formatting_textarea";
import TButton from "@/shared/ui/buttons/tbutton";
import ThreadCreatePreview from "@/shared/templates/threads/thread_create_preview";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";

export default function CreateRoute() {
  const [text, setText] = useState("");
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const padTop = useTabHeaderPad(8);
  const padBottom = useTabBarPad();

  const publish = () => {
    if (!demo.isAuth) {
      demo.openAuth("Войди, чтобы публиковать", "Демо-пост появится в ленте после входа.");
      return;
    }
    const created = demo.publishThread(text);
    if (created) {
      setText("");
      nav.replace("/");
    }
  };

  return (
    <TabScaffold title="Новый тред">
      <View className="flex-1 px-4" style={{ paddingTop: padTop, paddingBottom: padBottom }}>
        <FormattingTextarea value={text} onChange={setText} maxLength={500} />
        <View className="mt-4">
          <ThreadCreatePreview text={text} />
        </View>
        <View className="mt-4">
          <TButton.Solid disabled={!text.trim()} onPress={publish}>
            Опубликовать
          </TButton.Solid>
        </View>
        <Text className="mt-3 text-xs text-muted">
          Демо: пост сразу попадёт в ленту «Новые». API нет.
        </Text>
      </View>
    </TabScaffold>
  );
}
