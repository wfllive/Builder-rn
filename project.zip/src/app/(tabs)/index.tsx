/**
 * Главная как на вебе:
 * вкладки с иконками + фильтр номинаций + #ТредДня + лента.
 */
import React, { useMemo, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import TabScaffold, { useTabBarPad, useTabHeaderPad } from "@/app/_components/tab_scaffold";
import FlyTabs from "@/shared/ui/navigation/flytabs";
import FlyDropdown from "@/shared/ui/navigation/flydropdown";
import TButton from "@/shared/ui/buttons/tbutton";
import ThreadsList, { type SortType } from "@/shared/templates/threads/threads_list";
import ThreadShortItemPlaceholder from "@/shared/templates/threads/thread_short_item_placeholder";
import DailyThreadInfoModal from "@/shared/widgets/bottom_sheet_modals/nominations/daily_thread_info_modal";
import { Emoji2 } from "@/shared/ui/icons/mingcute/emoji/emoji_2_line";
import { Rocket } from "@/shared/ui/icons/mingcute/transport/rocket_line";
import { Fire } from "@/shared/ui/icons/mingcute/system/fire_line";
import { UserHeart } from "@/shared/ui/icons/mingcute/user/user_heart_line";
import { QuillPenAI } from "@/shared/ui/icons/mingcute/design/quill_pen_ai_line";
import { Filter2 } from "@/shared/ui/icons/mingcute/system/filter_2_line";
import { Star } from "@/shared/ui/icons/mingcute/shape/star_line";
import { StarTopper } from "@/shared/ui/icons/mingcute/other/star_topper_line";
import { Question } from "@/shared/ui/icons/mingcute/system/question_line";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { useDemoSession } from "@/example/demo_session";


export default function HomeRoute() {
  const { isDark } = useAppTheme();
  const demo = useDemoSession();
  const [sortType, setSortType] = useState<SortType>("new");
  const [dailyInfo, setDailyInfo] = useState(false);
  const ink = resolveToken(isDark, "text");
  const warn = resolveToken(isDark, "warning");
  const primary = resolveToken(isDark, "primary");
  const isExtra = sortType === "daily_threads" || sortType === "daily_replies";
  const headerPad = useTabHeaderPad(48);
  const tabPad = useTabBarPad();

  const dailyThread = demo.threads.find((t) => t.is_pinned) ?? demo.threads[0];

  const feed = useMemo(() => {
    if (sortType === "daily_threads") return dailyThread ? [dailyThread] : [];
    if (sortType === "following") {
      return demo.threads.filter((t) => t.user_info.followed || t.user_info.user_id === "you");
    }
    if (sortType === "popular") {
      return [...demo.threads].sort((a, b) => b.likes_count - a.likes_count);
    }
    return demo.threads;
  }, [dailyThread, demo.threads, sortType]);

  return (
    <TabScaffold
      title="twitblit"
      topExtra={
        <View className="px-2 pb-1">
            <FlyTabs
              size="sm"
              activeKey={sortType}
              onChange={(key) => setSortType(key as SortType)}
              extraContent={{
                right: (
                  <FlyDropdown
                    items={[
                      {
                        label: "Номинация #ТредДня",
                        prefix: <Star size={16} color={warn} />,
                        type: "warning",
                        onClick: () => setSortType("daily_threads"),
                      },
                      {
                        label: "Номинация #ОтветДня",
                        prefix: <StarTopper size={16} color={warn} />,
                        type: "warning",
                        onClick: () => setSortType("daily_replies"),
                      },
                    ]}
                    trigger={
                      <TButton.Text
                        centerImage={<Filter2 size={20} color={isExtra ? primary : ink} />}
                      />
                    }
                  />
                ),
              }}
              options={[
                { key: "new", label: "Новые", leftIcon: <Emoji2 size={16} color={ink} /> },
                { key: "recommendations", label: "Рекомендации", leftIcon: <Rocket size={16} color={ink} /> },
                {
                  key: "popular",
                  label: "Горячее",
                  leftIcon: <Fire size={16} color={warn} />,
                  typeActive: "warning",
                },
                { key: "following", label: "Подписки", leftIcon: <UserHeart size={16} color={ink} /> },
                { key: "bots", label: "Треды ботов", leftIcon: <QuillPenAI size={16} color={ink} /> },
              ]}
            />
        </View>
      }
    >
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          paddingHorizontal: 12,
          paddingTop: headerPad + 8,
          paddingBottom: tabPad,
          flexGrow: 0,
        }}
        showsVerticalScrollIndicator={false}
      >
        {dailyThread ? (
          <View className="mb-4">
            <View className="flex-row items-center justify-between mb-2 px-1">
              <Text className="text-lg font-semibold" style={{ color: ink }}>
                Номинация <Text className="text-warning">#ТредДня</Text>
              </Text>
              <TButton.Text onPress={() => setDailyInfo(true)} centerImage={<Question size={20} color={ink} />} />
            </View>
            <ThreadShortItemPlaceholder
              data={dailyThread}
              className="border-2 border-warning/40"
              leftPrefixIcon={
                <View className="p-2 rounded-lg bg-warning/40">
                  <Star size={28} color={warn} filled />
                </View>
              }
            />
          </View>
        ) : null}

        <ThreadsList sortType={sortType} items={feed} />
      </ScrollView>

      <DailyThreadInfoModal open={dailyInfo} onCancel={() => setDailyInfo(false)} />
    </TabScaffold>
  );
}
