/**
 * Уведомления. Тап открывает тред или профиль.
 */
import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import TabScaffold, { useTabBarPad, useTabHeaderPad } from "@/components/app/tab_scaffold";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import { notificationStrings } from "@/shared/widgets/snackbars/notifications_strings";
import { useAppNavigation } from "@/adapters/navigation";
import { DEMO_AVATARS } from "@/example/demo_media";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";


const ITEMS = [
  { id: 1, name: "Аня", avatar: DEMO_AVATARS.anya, kind: "like" as const, when: "12м", href: "/tb/twitblit/101" },
  { id: 2, name: "Лёша", avatar: DEMO_AVATARS.lesha, kind: "comment" as const, when: "1ч", href: "/tb/anya/102" },
  { id: 3, name: "Twitblit", avatar: DEMO_AVATARS.twitblit, kind: "follow" as const, when: "вчера", href: "/tb/twitblit" },
];

export default function NotificationsRoute() {
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const padTop = useTabHeaderPad();
  const padBottom = useTabBarPad();

  return (
    <TabScaffold title="Уведомления">
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingTop: padTop, paddingBottom: padBottom }}
        showsVerticalScrollIndicator={false}
      >
        {ITEMS.map((item) => (
          <Pressable
            key={item.id}
            onPress={() => nav.push(item.href)}
            className="flex-row items-center px-4 py-3.5 border-b border-primary/10"
          >
            <FlyAvatar src={item.avatar} alt={item.name} size="sm" />
            <View className="flex-1 ml-3">
              <Text style={{ color: ink }}>
                <Text className="font-semibold">{item.name}</Text> {notificationStrings[item.kind]}
              </Text>
              <Text className="text-xs mt-0.5" style={{ color: muted }}>
                {item.when}
              </Text>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </TabScaffold>
  );
}
