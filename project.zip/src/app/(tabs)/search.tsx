/**
 * Поиск людей и тредов.
 * Шапка стеклянная поверх списка — скролл уходит под blur.
 */
import React, { useMemo, useState } from "react";
import { ScrollView, Text, View } from "react-native";
import TabScaffold, { useTabBarPad, useTabHeaderPad } from "@/app/_components/tab_scaffold";
import FlyInput from "@/shared/ui/data_entry/flyinput";
import ShortProfileHeader from "@/shared/templates/profile/short_profile_header";
import ThreadItemPlaceholder from "@/shared/templates/threads/thread_item_placeholder";
import { Search } from "@/shared/ui/icons/mingcute/file/search_line";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useGlassRecapture } from "@/shared/ui/layout/glass_capture";

export default function SearchRoute() {
  const { isDark } = useAppTheme();
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const recaptureGlass = useGlassRecapture();
  const [query, setQuery] = useState("");
  const icon = resolveToken(isDark, "textMuted");
  const padTop = useTabHeaderPad(56);
  const padBottom = useTabBarPad();

  const people = useMemo(() => {
    const unique = new Map(demo.threads.map((t) => [t.user_info.id, t.user_info]));
    const list = [...unique.values()];
    if (!query.trim()) return list;
    const q = query.toLowerCase();
    return list.filter(
      (u) => u.username.toLowerCase().includes(q) || u.user_id.toLowerCase().includes(q)
    );
  }, [demo.threads, query]);

  const posts = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return demo.threads.filter((t) => t.text_twit.toLowerCase().includes(q));
  }, [demo.threads, query]);

  return (
    <TabScaffold
      title="Поиск"
      topExtra={
        <View className="px-4 pb-3">
          <FlyInput
            value={query}
            onChange={setQuery}
            placeholder="Люди и треды"
            variant="filled"
            prefix={<Search size={16} color={icon} />}
            viewClearButton
          />
        </View>
      }
    >
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingTop: padTop, paddingBottom: padBottom }}
        showsVerticalScrollIndicator={false}
        onMomentumScrollEnd={recaptureGlass}
        onScrollEndDrag={recaptureGlass}
      >
        <Text className="px-4 pb-2 text-xs font-semibold text-muted">Люди</Text>
        {people.map((u) => (
          <ShortProfileHeader
            key={u.id}
            user={u}
            onPress={() => nav.push(`/tb/${u.user_id}`)}
          />
        ))}
        {people.length === 0 ? (
          <Text className="px-4 pt-8 text-center text-muted">Никого не нашли</Text>
        ) : null}

        {posts.length > 0 ? (
          <View className="px-3 pt-4 pb-6">
            <Text className="px-1 pb-2 text-xs font-semibold text-muted">Треды</Text>
            <View className="gap-3">
              {posts.map((t) => (
                <ThreadItemPlaceholder key={t.id} data={t} />
              ))}
            </View>
          </View>
        ) : null}
      </ScrollView>
    </TabScaffold>
  );
}
