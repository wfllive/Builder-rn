/**
 * Общий каркас вкладок.
 *
 * Таббар монтируется один раз. Экраны меняются через Slot.
 * Переключение — replace, без стека «назад по табам».
 * Шапка вкладки рендерится здесь через TabHeaderSlot поверх контента.
 */
import React from "react";
import { Slot, usePathname } from "expo-router";
import Layout from "@/shared/ui/layout/layout";
import FlexibleHeaderMobile from "@/shared/widgets/flexible_header_mobile";
import ScreenHeader from "@/components/app/screen_header";
import {
  TabHeaderProvider,
  useTabHeaderContext,
} from "@/components/app/tab_header_context";
import type { AppTabId } from "@/components/app/app_screen";

function tabFromPath(pathname: string): AppTabId {
  if (pathname.startsWith("/search")) return "search";
  if (pathname.startsWith("/create")) return "create";
  if (pathname.startsWith("/notifications")) return "notifications";
  if (pathname.startsWith("/messenger")) return "messages";
  return "home";
}

/** Шапка вкладки: читает заголовок из контекста (его задаёт TabScaffold). */
function TabHeaderSlot() {
  const { config } = useTabHeaderContext();
  if (!config) return null;
  return (
    <ScreenHeader
      title={config.title}
      subtitle={config.subtitle}
      extra={config.topExtra}
    />
  );
}

export default function TabsLayout() {
  const pathname = usePathname();

  return (
    <TabHeaderProvider>
      <Layout
        header={<TabHeaderSlot />}
        tabBar={
          <FlexibleHeaderMobile
            selected={tabFromPath(pathname)}
            noFillOnSelectIds={["search", "create"]}
          />
        }
      >
        <Slot />
      </Layout>
    </TabHeaderProvider>
  );
}
