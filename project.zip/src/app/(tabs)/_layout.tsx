/**
 * Общий каркас вкладок.
 *
 * Таббар монтируется один раз. Экраны меняются через Slot.
 * Переключение — replace, без стека «назад по табам».
 */
import React from "react";
import { Slot, usePathname } from "expo-router";
import Layout from "@/shared/ui/layout/layout";
import FlexibleHeaderMobile from "@/shared/widgets/flexible_header_mobile";
import type { AppTabId } from "@/app/_components/app_screen";

function tabFromPath(pathname: string): AppTabId {
  if (pathname.startsWith("/search")) return "search";
  if (pathname.startsWith("/create")) return "create";
  if (pathname.startsWith("/notifications")) return "notifications";
  if (pathname.startsWith("/messenger")) return "messages";
  return "home";
}

export default function TabsLayout() {
  const pathname = usePathname();

  return (
    <Layout
      tabBar={
        <FlexibleHeaderMobile
          selected={tabFromPath(pathname)}
          noFillOnSelectIds={["search", "create"]}
        />
      }
    >
      <Slot />
    </Layout>
  );
}
