/**
 * Профиль `/tb/:userId`.
 * Баннер, подписка, треды пользователя из демо-сессии.
 */
import React from "react";
import { ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import AppScreen from "@/components/app/app_screen";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import ProfileHeader from "@/shared/templates/profile/profile_header";
import ThreadsList from "@/shared/templates/threads/threads_list";
import { useDemoSession } from "@/example/demo_session";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ProfileRoute() {
  const { userId } = useLocalSearchParams<{ userId: string }>();
  const demo = useDemoSession();
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const padTop = insets.top + CHROME_HEADER_BODY;
  const padBottom = Math.max(insets.bottom, 6) + 64;
  const user = demo.getUser(String(userId ?? ""));
  const items = demo.getUserThreads(String(userId ?? ""));
  const isOwn = Boolean(demo.user && demo.user.user_id === user?.user_id);

  if (!user) {
    return (
      <AppScreen selected="home" header={<ShortFlexibleHeader title="Профиль" />}>
        <View className="px-4" style={{ paddingTop: padTop + 16 }}>
          <Text className="text-center" style={{ color: muted }}>
            Такого профиля в демо нет.
          </Text>
        </View>
      </AppScreen>
    );
  }

  return (
    <AppScreen selected="home" header={<ShortFlexibleHeader title={user.username} />}>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingTop: padTop, paddingBottom: padBottom, flexGrow: 0 }}
        showsVerticalScrollIndicator={false}
      >
        <ProfileHeader
          user={user}
          isOwn={isOwn}
          threadsCount={items.length}
          onToggleFollow={() => demo.toggleFollow(user.user_id)}
        />
        <Text className="px-4 mt-4 mb-2 text-sm font-semibold" style={{ color: ink }}>
          Треды
        </Text>
        <View className="px-3">
          <ThreadsList items={items} />
        </View>
      </ScrollView>
    </AppScreen>
  );
}
