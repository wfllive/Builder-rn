/**
 * Тред `/tb/:userId/:threadId`.
 * Карточка + комментарии. Лайк и ответ работают из демо-сессии.
 */
import React, { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import AppScreen from "@/components/app/app_screen";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import ThreadItemPlaceholder from "@/shared/templates/threads/thread_item_placeholder";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import FlyInput from "@/shared/ui/data_entry/flyinput";
import TButton from "@/shared/ui/buttons/tbutton";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ThreadRoute() {
  const { threadId } = useLocalSearchParams<{ userId: string; threadId: string }>();
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const primary = resolveToken(isDark, "primary");
  const padTop = insets.top + CHROME_HEADER_BODY + 12;
  const padBottom = Math.max(insets.bottom, 6) + 72;
  const [draft, setDraft] = useState("");
  const id = Number(threadId);
  const thread = Number.isFinite(id) ? demo.getThread(id) : undefined;
  const list = Number.isFinite(id) ? demo.comments[id] ?? [] : [];

  const send = () => {
    if (!demo.isAuth) {
      demo.openAuth("Войди, чтобы комментировать");
      return;
    }
    if (Number.isFinite(id)) {
      demo.addComment(id, draft);
      setDraft("");
    }
  };

  return (
    <AppScreen selected="home" header={<ShortFlexibleHeader title="Тред" />}>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 12, paddingTop: padTop, paddingBottom: padBottom, flexGrow: 0 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {thread ? (
          <ThreadItemPlaceholder data={thread} onPress={() => undefined} />
        ) : (
          <Text className="text-center py-8" style={{ color: muted }}>
            Тред не найден.
          </Text>
        )}

        <Text className="mt-5 mb-2 text-base font-semibold" style={{ color: ink }}>
          Комментарии
        </Text>

        {list.length === 0 ? (
          <Text className="text-sm py-3" style={{ color: muted }}>
            Пока тихо. Напиши первый ответ.
          </Text>
        ) : (
          list.map((c) => (
            <View key={c.id} className="flex-row items-start py-2.5 border-b border-primary/10">
              <FlyAvatar src={c.avatar ?? undefined} alt={c.author} size="xs" />
              <View className="ml-2 flex-1">
                <Text
                  className="text-sm font-semibold"
                  style={{ color: primary }}
                  onPress={() => nav.push(`/tb/${c.authorId}`)}
                >
                  {c.author}
                </Text>
                <Text className="text-sm mt-0.5" style={{ color: ink }}>
                  {c.text}
                </Text>
              </View>
            </View>
          ))
        )}

        <View className="mt-4">
          <FlyInput
            value={draft}
            onChange={setDraft}
            placeholder={demo.isAuth ? "Написать ответ" : "Войди, чтобы ответить"}
            variant="filled"
            onPressEnter={send}
          />
          <View className="mt-2">
            <TButton.Filled onPress={send}>Ответить</TButton.Filled>
          </View>
        </View>
      </ScrollView>
    </AppScreen>
  );
}
