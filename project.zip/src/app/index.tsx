import { Redirect } from 'expo-router';

export default function Index() {
  /*
    Корневой маршрут "/" сразу перенаправляет
    пользователя на главный экран табов.

    В нашем случае:
    /navigation/home
  */
  return <Redirect href="/navigation/home" />;
}