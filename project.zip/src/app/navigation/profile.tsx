import { View, Text, StyleSheet } from 'react-native';

export default function ProfileScreen() {
  return (
    <View className="flex-1 items-center justify-center">
      <Text className="font-bold text-[24px]">Профиль страница</Text>
    </View>
  );
}

