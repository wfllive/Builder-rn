import { Tabs, Link } from 'expo-router';

import { Pressable } from 'react-native';

//временно использование иконок
import { Ionicons } from '@expo/vector-icons';

export default function NavigationLayout() {
  return (
    <Tabs
      screenOptions={{
        /*
          Показываем header у каждого tab-экрана.
          Заголовок будет отображаться сверху.
        */
        headerShown: true,
        /*
          Цвет активной вкладки в bottom tab bar.
        */
        tabBarActiveTintColor: '#007AFF',
        
        /*
          Общая кнопка справа в header для всех вкладок.
          Здесь отображаем иконку поиска.
          
          По нажатию открывается маршрут /search,
          который у нас отображается как modal.
        */
        
        headerRight: () => (
          <Link href="/search" asChild>
            <Pressable style={{ marginRight: 16 }}>
              <Ionicons name="search-outline" size={24} color="#000" />
            </Pressable>
          </Link>
        ),
      }}
    >
      <Tabs.Screen
        name="home"
        options={{
          title: 'Главная',

        }}
      />

      <Tabs.Screen
        name="messages"
        options={{
          title: 'Чат',

        }}
      />

      <Tabs.Screen
        name="favorites"
        options={{
          title: 'Избранное',
          
        }}
      />

      <Tabs.Screen
        name="profile"
        options={{
          title: 'Профиль',
          
        }}
      />
    </Tabs>
  );
}