import { View, Text } from "react-native";
import TButton from "@/shared/ui/buttons/tbuttons";
//import TCollapseButtonsGroup from "@/shared/ui/buttons/tcollapse_buttons_group";

export default function HomeScreen() {
  return (
    <View className="flex-1 items-center justify-center bg-pink-200 px-4">
      <Text className="mb-6 text-[24px] font-bold">Главная страница</Text>

      <View className="w-full gap-3">
           <TButton.Filled
          className="w-full"
          onPress={() => console.log("filled")}
        >
          тест filled
        </TButton.Filled>

        <TButton.Outline
          className="w-full"
          onPress={() => console.log("outline")}
        >
          тест outline
        </TButton.Outline>

        <TButton.Danger
          className="w-full"
          onPress={() => console.log("danger")}
        >
          тест danger
        </TButton.Danger>

        <TButton
          className="w-full"
          onPress={() => console.log("solid")}
        >
          тест solid
        </TButton>

        <TButton.Text
          className="w-full"
          onPress={() => console.log("text")}
        >
          тест text
        </TButton.Text>

        <TButton.Ghost
          className="w-full"
          onPress={() => console.log("ghost")}
        >
          тест ghost
        </TButton.Ghost>

        <TButton.Outline
          className="w-full"
          isLoading
          onPress={() => console.log("loading")}
        >
          загрузка
        </TButton.Outline>

        <TButton.Danger
          className="w-full"
          indicatorNotification
          countNotification={8}
          onPress={() => console.log("notification")}
        >
          уведомления
        </TButton.Danger>
      </View>
    </View>
  );
}