import { View, Text, StyleSheet } from 'react-native';

export default function favoriteScreen() {
  return (
    <View className="flex-1 items-center justify-center">
      <Text className="font-bold text-[24px]">избраный</Text>
    </View>
  );
}
