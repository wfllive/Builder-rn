/**
 * Настройки профиля — секции как на вебе + рабочая смена темы.
 *
 * Тема: три плитки (не сегмент со скроллом). Всегда видны Система / Светлая / Тёмная.
 * padding учитывает стеклянные бары поверх контента.
 */
import React from "react";
import { ScrollView, Text, useWindowDimensions, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AppScreen from "@/components/app/app_screen";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import TSwitch from "@/shared/ui/data_entry/tswitch";
import TContainerButton from "@/shared/ui/buttons/tcontainer_button";
import ThemeChoiceRow from "@/shared/ui/buttons/theme_choice_row";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { useUISettings } from "@/shared/templates/providers/ui_settings_provider";
import { resolveToken } from "@/theme/tokens";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import { SafeLock } from "@/shared/ui/icons/mingcute/system/safe_lock_line";
import { Science } from "@/shared/ui/icons/mingcute/education/science_line";
import { History2 } from "@/shared/ui/icons/mingcute/system/history_2_line";
import { CheckCircle } from "@/shared/ui/icons/mingcute/system/check_circle_line";
import { User4 } from "@/shared/ui/icons/mingcute/user/user_4_line";
import { Blockquote } from "@/shared/ui/icons/mingcute/editor/blockquote_line";
import { At } from "@/shared/ui/icons/mingcute/editor/at_line";
import { Share3 } from "@/shared/ui/icons/mingcute/system/share_3_line";
import { Ship } from "@/shared/ui/icons/mingcute/transport/ship_line";
import { Delete2 } from "@/shared/ui/icons/mingcute/system/delete_2_line";
import { Right } from "@/shared/ui/icons/mingcute/arrow/right_line";

export default function SettingsRoute() {
  const { theme, resolvedTheme, isDark } = useAppTheme();
  const { animations, setAnimationsDisabled } = useUISettings();
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const icon = resolveToken(isDark, "text");
  const danger = resolveToken(isDark, "red");
  const pad = width >= 768 ? 28 : 16;
  const maxW = Math.min(width, 560);

  const now =
    theme === "system"
      ? `система → сейчас ${resolvedTheme === "dark" ? "тёмная" : "светлая"}`
      : theme === "dark"
        ? "тёмная"
        : "светлая";

  const soon = (label: string) => demo.showSnack("Демо", `${label} — на native без API.`);

  return (
    <AppScreen selected="home" header={<ShortFlexibleHeader title="Настройки профиля" />}>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          paddingHorizontal: pad,
          paddingTop: insets.top + CHROME_HEADER_BODY + 16,
          paddingBottom: Math.max(insets.bottom, 6) + 72,
          alignItems: "center",
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ width: "100%", maxWidth: maxW }} className="gap-6">
          <View>
            <Text className="text-sm font-semibold mx-2 mb-2" style={{ color: ink }}>
              Внешний вид
            </Text>
            <View className="rounded-2xl bg-primary/5 p-3">
              <Text className="text-sm mb-3" style={{ color: ink }}>
                Тема приложения
              </Text>
              <ThemeChoiceRow />
              <Text className="text-xs mt-2" style={{ color: muted }}>
                Сейчас: {now}
              </Text>
              <View className="flex-row items-center justify-between mt-4">
                <View className="flex-1 pr-3">
                  <Text style={{ color: ink }}>Убрать анимации фона</Text>
                  <Text className="text-xs mt-0.5" style={{ color: muted }}>
                    Меньше нагрузки, интерфейс быстрее
                  </Text>
                </View>
                <TSwitch checked={animations.disabled} onChange={setAnimationsDisabled} />
              </View>
            </View>
          </View>

          <View>
            <Text className="text-sm font-semibold mx-2 mb-2" style={{ color: ink }}>
              Учётная запись
            </Text>
            <View className="gap-2">
              <TContainerButton
                label="Сбросить пароль"
                leftIcon={<SafeLock size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Сброс пароля")}
              />
              <TContainerButton
                label="Сервисы и способы входа"
                leftIcon={<Science size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Сервисы входа")}
              />
              <TContainerButton
                label="Активные сессии"
                leftIcon={<History2 size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Сессии")}
              />
              <TContainerButton
                label="Подать заявку на верификацию"
                leftIcon={<CheckCircle size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Верификация")}
              />
            </View>
          </View>

          <View>
            <Text className="text-sm font-semibold mx-2 mb-2" style={{ color: ink }}>
              Профиль
            </Text>
            <View className="gap-2">
              <TContainerButton
                label="Аватар и баннер"
                leftIcon={<User4 size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() =>
                  demo.user ? nav.push(`/tb/${demo.user.user_id}`) : nav.push("/auth/login")
                }
              />
              <TContainerButton
                label="Личные данные"
                leftIcon={<Blockquote size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Личные данные")}
              />
              <TContainerButton
                label="Юзернейм и алиасы"
                leftIcon={<At size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Алиасы")}
              />
              <TContainerButton
                label="Социальные сети"
                leftIcon={<Share3 size={20} color={icon} />}
                rightIcon={<Right size={20} color={icon} />}
                onPress={() => soon("Соцсети")}
              />
            </View>
          </View>

          <View>
            <Text className="text-sm font-semibold mx-2 mb-2" style={{ color: danger }}>
              Опасная зона
            </Text>
            <View className="gap-2">
              <TContainerButton
                label="Покинуть корабль"
                leftIcon={<Ship size={20} color={danger} />}
                rightIcon={<Right size={20} color={danger} />}
                onPress={() => {
                  demo.logout();
                  nav.replace("/auth/login");
                }}
              />
              <TContainerButton
                label="Деактивировать и удалить аккаунт"
                leftIcon={<Delete2 size={20} color={danger} />}
                rightIcon={<Right size={20} color={danger} />}
                onPress={() => soon("Удаление аккаунта")}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </AppScreen>
  );
}
