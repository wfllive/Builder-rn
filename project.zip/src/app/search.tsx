import { View, Text, StyleSheet, TextInput, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { useState } from 'react';

export default function SearchScreen() {
  
  /*
    useRouter нужен для программной навигации.
    Здесь он используется, чтобы закрыть modal через router.back().
  */
  
  const router = useRouter();
  
  /*
    Локальное состояние поля поиска.
    Пока экран является заглушкой, но структура уже готова
    для подключения реального поиска.
  */
  
  const [query, setQuery] = useState('');

  return (
  <View className="flex-1 p-5 justify-center">
    <Text className="text-[28px] font-semibold mb-5 text-center">
      Поиск
    </Text>

    {/* 
      Поле ввода поискового запроса.
      Сейчас значение никуда не отправляется,
      это просто базовый UI для модального экрана.
    */}
    <TextInput
      className="border border-[#ccc] rounded-[10px] p-[14px] mb-5"
      placeholder="Введите запрос..."
      value={query}
      onChangeText={setQuery}
    />

    {/* 
      Закрываем модальное окно и возвращаемся назад
      к предыдущему экрану.
    */}
    <Pressable 
      className="bg-[#007AFF] p-[14px] rounded-[10px] items-center" 
      onPress={() => router.back()}
    >
      <Text className="text-white font-semibold">
        Закрыть
      </Text>
    </Pressable>
  </View>
);
}

