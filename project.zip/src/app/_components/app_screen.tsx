/**
 * Обёртка экрана приложения.
 *
 * Для экранов вне группы (tabs): about, auth.
 * Основные вкладки живут в src/app/(tabs)/_layout.tsx.
 */
import React from "react";
import Layout from "@/shared/ui/layout/layout";
import FlexibleHeaderMobile from "@/shared/widgets/flexible_header_mobile";

export type AppTabId = "home" | "search" | "create" | "notifications" | "messages";

export default function AppScreen({
  selected,
  header,
  children,
}: {
  selected: AppTabId;
  header?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <Layout
      header={header}
      tabBar={
        <FlexibleHeaderMobile
          selected={selected}
          noFillOnSelectIds={["search", "create"]}
        />
      }
    >
      {children}
    </Layout>
  );
}
