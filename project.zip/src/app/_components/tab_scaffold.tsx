/**
 * Каркас вкладки: лента + стеклянная шапка как СИБЛИНГИ.
 * Так Liquid Glass видит фон (правило библиотеки).
 */
import React from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ScreenHeader from "@/app/_components/screen_header";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";

export function useTabHeaderPad(extra = 0) {
  const insets = useSafeAreaInsets();
  return insets.top + CHROME_HEADER_BODY + extra;
}

export function useTabBarPad() {
  const insets = useSafeAreaInsets();
  return Math.max(insets.bottom, 6) + 52;
}

export default function TabScaffold({
  title,
  subtitle,
  topExtra,
  children,
}: {
  title: string;
  subtitle?: string;
  topExtra?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <View collapsable={false} className="flex-1">
      {children}
      <ScreenHeader title={title} subtitle={subtitle} extra={topExtra} />
    </View>
  );
}
