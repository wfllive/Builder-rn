/**
 * Каркас вкладки: лента + стеклянная шапка как СИБЛИНГИ.
 *
 * Своя цель размытия (`GlassTargetProvider`): по правилу Dimezis BlurView
 * цель не может содержать BlurView, который её же и размывает.
 * Шапка вкладки живёт внутри контента общего Layout, поэтому здесь
 * заводим вложенную цель — она покрывает только ленту экрана.
 * Вложенные BlurTarget разрешены.
 */
import React from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ScreenHeader from "@/app/_components/screen_header";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import { GlassTargetArea, GlassTargetProvider } from "@/shared/ui/layout/glass_target";

export function useTabHeaderPad(extra = 0) {
  const insets = useSafeAreaInsets();
  return insets.top + CHROME_HEADER_BODY + extra;
}

export function useTabBarPad() {
  const insets = useSafeAreaInsets();
  return Math.max(insets.bottom, 6) + 52;
}

export default function TabScaffold({
  title,
  subtitle,
  topExtra,
  children,
}: {
  title: string;
  subtitle?: string;
  topExtra?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <GlassTargetProvider>
      <View collapsable={false} className="flex-1">
        <GlassTargetArea>{children}</GlassTargetArea>
        <ScreenHeader title={title} subtitle={subtitle} extra={topExtra} />
      </View>
    </GlassTargetProvider>
  );
}
