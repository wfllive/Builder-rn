/**
 * Знак Twitblit ID на экранах входа/регистрации.
 *
 * require через относительный путь: alias @/ в Metro иногда
 * не резолвит картинку, и на экране остаётся только «ID».
 * Если png не загрузился — фиолетовый квадрат с бабочкой.
 */
import React, { useState } from "react";
import { Image, Text, View } from "react-native";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { Butterfly } from "@/shared/ui/icons/mingcute/nature/butterfly_line";

const LOGO = require("../../example/assets/logo_twitblit.png");

export default function AuthIdMark({ size = 56 }: { size?: number }) {
  const { isDark } = useAppTheme();
  const [failed, setFailed] = useState(false);
  const ink = resolveToken(isDark, "text");

  return (
    <View className="flex-row items-center justify-center">
      {failed ? (
        <View
          style={{
            width: size,
            height: size,
            borderRadius: 14,
            backgroundColor: "#5F18DA",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Butterfly size={Math.round(size * 0.52)} color="#FFFFFF" filled />
        </View>
      ) : (
        <Image
          source={LOGO}
          style={{ width: size, height: size, borderRadius: 14 }}
          onError={() => setFailed(true)}
        />
      )}
      <Text className="text-3xl font-semibold ml-2" style={{ color: ink }}>
        ID
      </Text>
    </View>
  );
}
