/**
 * Демо-оверлеи: вход и комментарии поверх любого экрана.
 * Настройки больше не шторка — отдельная страница /settings.
 */
import React, { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import FlyBottomSheetModal from "@/shared/ui/feedback/flybottom_sheet_modal";
import FlySnackbar from "@/shared/ui/feedback/flysnackbar";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import FlyInput from "@/shared/ui/data_entry/flyinput";
import TButton from "@/shared/ui/buttons/tbutton";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppMenu } from "@/shared/templates/providers/app_menu_provider";
import FlyDrawer from "@/shared/ui/feedback/flydrawer";
import LeftSidebar from "@/shared/widgets/sidebars/left_sidebar";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function DemoChrome() {
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const menu = useAppMenu();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const [draft, setDraft] = useState("");
  const threadId = demo.commentsFor;
  const list = threadId != null ? demo.comments[threadId] ?? [] : [];

  const send = () => {
    if (!demo.isAuth) {
      demo.openAuth("Войди, чтобы комментировать");
      return;
    }
    if (threadId != null) {
      demo.addComment(threadId, draft);
      setDraft("");
    }
  };

  return (
    <>
      <FlyDrawer open={menu.menuOpen} onClose={menu.closeMenu} side="left">
        <LeftSidebar onNavigate={menu.closeMenu} />
      </FlyDrawer>

      <FlyBottomSheetModal
        open={demo.authOpen}
        onCancel={demo.closeAuth}
        title={demo.authCopy.title}
        message={demo.authCopy.message}
        actions={
          <View className="flex-row gap-3 w-full">
            <View className="flex-1">
              <TButton.Outline onPress={demo.closeAuth}>Позже</TButton.Outline>
            </View>
            <View className="flex-1">
              <TButton.Solid
                onPress={() => {
                  demo.closeAuth();
                  nav.push("/auth/login");
                }}
              >
                Войти
              </TButton.Solid>
            </View>
          </View>
        }
      />

      <FlyBottomSheetModal
        open={threadId != null}
        onCancel={() => {
          demo.closeComments();
          setDraft("");
        }}
        title="Комментарии"
        actions={null}
      >
        <ScrollView className="max-h-64 mt-2" showsVerticalScrollIndicator={false}>
          {list.length === 0 ? (
            <Text className="text-sm text-muted text-center py-4">
              Пока тихо. Напиши первый ответ.
            </Text>
          ) : (
            list.map((c) => (
              <View key={c.id} className="flex-row items-start py-2.5 border-b border-primary/10">
                <FlyAvatar src={c.avatar ?? undefined} alt={c.author} size="xs" />
                <View className="ml-2 flex-1">
                  <Text className="text-sm font-semibold text-primary">{c.author}</Text>
                  <Text className="text-sm mt-0.5" style={{ color: ink }}>
                    {c.text}
                  </Text>
                </View>
              </View>
            ))
          )}
        </ScrollView>
        <View className="mt-3">
          <FlyInput
            value={draft}
            onChange={setDraft}
            placeholder={demo.isAuth ? "Написать ответ" : "Войди, чтобы ответить"}
            variant="filled"
            onPressEnter={send}
          />
          <View className="mt-2">
            <TButton.Filled onPress={send}>Ответить</TButton.Filled>
          </View>
        </View>
      </FlyBottomSheetModal>

      {demo.snack.open ? (
        <FlySnackbar
          open
          title={demo.snack.title}
          message={demo.snack.message}
          timeSeconds={2.4}
          onClose={demo.hideSnack}
        />
      ) : null}
    </>
  );
}
