/** Маршрут `/about`. */
import React from "react";
import SimplePage from "@/app/_components/simple_page";

export default function AboutRoute() {
  return (
    <SimplePage
      selected="home"
      title="О нас"
      description="Twitblit Native на Expo 57 и Expo Router."
    />
  );
}
