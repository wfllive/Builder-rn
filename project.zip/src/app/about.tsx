/** Маршрут `/about`. */
import React from "react";
import SimplePage from "@/components/app/simple_page";

export default function AboutRoute() {
  return (
    <SimplePage
      selected="home"
      title="О нас"
      description="Twitblit Native на Expo 57 и Expo Router."
    />
  );
}
