/**
 * Регистрация `/auth/create-account` — три шага как на вебе.
 * Демо: код любой из 7 цифр, пароль от 8 символов.
 */
import React, { useEffect, useState } from "react";
import { Linking, ScrollView, Text, useWindowDimensions, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Layout from "@/shared/ui/layout/layout";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import FlySteps from "@/shared/ui/navigation/flysteps";
import FlyInput from "@/shared/ui/data_entry/flyinput";
import FlyOtpInput from "@/shared/ui/data_entry/flyotpinput";
import TCheckbox from "@/shared/ui/data_entry/tcheckbox";
import TButton from "@/shared/ui/buttons/tbutton";
import AuthIdMark from "@/components/app/auth_id_mark";
import { At } from "@/shared/ui/icons/mingcute/editor/at_line";
import { SafeLock } from "@/shared/ui/icons/mingcute/system/safe_lock_line";
import { EggCrack } from "@/shared/ui/icons/mingcute/food/egg_crack_line";
import { Bread } from "@/shared/ui/icons/mingcute/food/bread_line";
import { Butterfly } from "@/shared/ui/icons/mingcute/nature/butterfly_line";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

const year = new Date().getFullYear();

export default function CreateAccountRoute() {
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const icon = resolveToken(isDark, "primary");
  const maxW = Math.min(width - 48, 440);

  const [step, setStep] = useState(0);
  const [email, setEmail] = useState("");
  const [agree, setAgree] = useState(false);
  const [otp, setOtp] = useState("");
  const [password, setPassword] = useState("");
  const [resend, setResend] = useState(0);

  useEffect(() => {
    if (resend <= 0) return;
    const id = setInterval(() => setResend((n) => Math.max(0, n - 1)), 1000);
    return () => clearInterval(id);
  }, [resend]);

  const sendCode = () => {
    if (!email.trim() || !agree) return;
    demo.showSnack("Код отправлен", `Демо-письмо на ${email}`);
    setStep(1);
    setResend(30);
  };

  const verify = () => {
    if (otp.replace(/\s/g, "").length < 7) {
      demo.showSnack("Ошибка", "Введите код из 7 цифр");
      return;
    }
    demo.showSnack("Ок", "Почта подтверждена");
    setStep(2);
  };

  const create = () => {
    if (password.length < 8) {
      demo.showSnack("Ошибка", "Пароль должен быть не короче 8 символов");
      return;
    }
    demo.login();
    demo.showSnack("Готово", "Аккаунт создан. Это Вы.");
    nav.replace("/");
  };

  return (
    <Layout header={<ShortFlexibleHeader title="Регистрация" />}>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          flexGrow: 1,
          alignItems: "center",
          paddingHorizontal: 24,
          paddingTop: insets.top + CHROME_HEADER_BODY + 16,
          paddingBottom: 28,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={{ width: "100%", maxWidth: maxW }} className="items-center">
          <AuthIdMark size={64} />

          <FlySteps
            current={step}
            className="mt-8 mb-8"
            items={[
              {
                title: "Введите почту",
                icon: <EggCrack size={16} color={icon} filled />,
              },
              {
                title: "Подтвердите",
                icon: <Bread size={16} color={icon} filled />,
              },
              {
                title: "Пароль",
                icon: <Butterfly size={16} color={icon} filled />,
              },
            ]}
          />

          {step === 0 ? (
            <View className="w-full items-center">
              <Text className="text-2xl font-semibold text-center mb-2" style={{ color: ink }}>
                Регистрация в Twitblit
              </Text>
              <Text className="text-sm text-center mb-4" style={{ color: muted }}>
                Авторизация займет пару минут, зато потом можно интересно провести время
              </Text>
              <FlyInput
                prefix={<At size={18} color={muted} />}
                placeholder="Введите e-mail"
                value={email}
                onChange={setEmail}
                variant="outlined"
                autoCapitalize="none"
                keyboardType="email-address"
              />
              <View className="flex-row items-start gap-2 mt-4 mb-4 w-full">
                <TCheckbox checked={agree} onChange={setAgree} />
                <Text className="flex-1 text-sm" style={{ color: ink }}>
                  Я согласен с обработкой персональных данных и принимаю{" "}
                  <Text
                    className="text-primary"
                    onPress={() => Linking.openURL("https://help.twitblit.ru/ru/users/legal/terms-of-use")}
                  >
                    Пользовательское соглашение
                  </Text>{" "}
                  и{" "}
                  <Text
                    className="text-primary"
                    onPress={() => Linking.openURL("https://help.twitblit.ru/ru/users/legal/privacy-policy")}
                  >
                    Политику конфиденциальности
                  </Text>
                  .
                </Text>
              </View>
              <TButton.Filled disabled={!email.trim() || !agree} className="w-full" onPress={sendCode}>
                Продолжить
              </TButton.Filled>
              <View className="flex-row justify-between w-full mt-3">
                <Text className="text-xs" style={{ color: ink }}>
                  Уже есть аккаунт?{" "}
                  <Text className="text-primary" onPress={() => nav.push("/auth/login")}>
                    Войти
                  </Text>
                </Text>
                <Text className="text-xs text-primary" onPress={() => demo.showSnack("Демо", "Сброс пароля без API.")}>
                  Забыли пароль?
                </Text>
              </View>
            </View>
          ) : null}

          {step === 1 ? (
            <View className="w-full items-center">
              <Text className="text-sm text-center mb-6" style={{ color: muted }}>
                Мы отправили секретный код на{" "}
                <Text className="text-primary">{email}</Text>. Введите его ниже.
              </Text>
              <FlyOtpInput length={7} value={otp} onChange={setOtp} />
              <View className="mt-6 w-full">
                <TButton.Filled disabled={otp.replace(/\s/g, "").length < 7} onPress={verify}>
                  Подтвердить код
                </TButton.Filled>
              </View>
              <Text className="mt-4 text-sm" style={{ color: muted }}>
                Не пришло письмо?{" "}
                <Text
                  className="text-primary"
                  onPress={() => {
                    if (resend > 0) return;
                    sendCode();
                  }}
                >
                  Отправить снова
                </Text>
                {resend > 0 ? `  00:${String(resend).padStart(2, "0")}` : ""}
              </Text>
            </View>
          ) : null}

          {step === 2 ? (
            <View className="w-full">
              <Text className="text-sm text-center mb-6" style={{ color: muted }}>
                А теперь самое интересное: придумать надёжный пароль!
              </Text>
              <FlyInput
                prefix={<At size={18} color={muted} />}
                value={email}
                editable={false}
                variant="outlined"
              />
              <View className="h-3" />
              <FlyInput
                prefix={<SafeLock size={18} color={muted} />}
                placeholder="Придумайте пароль"
                value={password}
                onChange={setPassword}
                variant="outlined"
                secureTextEntry
              />
              <Text className="text-xs mt-2 mb-5" style={{ color: muted }}>
                Пароль должен содержать не менее 8 символов, включая буквы и цифры.
              </Text>
              <TButton.Filled disabled={password.length < 8} onPress={create}>
                Создать аккаунт
              </TButton.Filled>
            </View>
          ) : null}

          <Text className="text-xs mt-auto pt-10" style={{ color: muted }}>
            © 2024–{year} Twitblit ID. Все права защищены.
          </Text>
        </View>
      </ScrollView>
    </Layout>
  );
}
