/**
 * Вход Twitblit ID.
 *
 * Без бэкенда: «Войти без аккаунта» сразу включает демо-сессию «Вы».
 * Почта/пароль тоже принимают что угодно. VK/Яндекс — тот же гостевой вход.
 */
import React, { useState } from "react";
import { Linking, ScrollView, Text, useWindowDimensions, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Layout from "@/shared/ui/layout/layout";
import ShortFlexibleHeader from "@/shared/widgets/short_flexible_header";
import FlyInput from "@/shared/ui/data_entry/flyinput";
import TButton from "@/shared/ui/buttons/tbutton";
import AuthIdMark from "@/app/_components/auth_id_mark";
import { At } from "@/shared/ui/icons/mingcute/editor/at_line";
import { SafeLock } from "@/shared/ui/icons/mingcute/system/safe_lock_line";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { CHROME_HEADER_BODY } from "@/shared/ui/layout/chrome_metrics";

const year = new Date().getFullYear();

export default function LoginRoute() {
  const { login, isAuth, showSnack } = useDemoSession();
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const icon = resolveToken(isDark, "textMuted");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const maxW = Math.min(width - 48, 420);

  const enterDemo = () => {
    login();
    nav.replace("/");
  };

  const submit = () => {
    if (!email.trim() || !password) {
      showSnack("Подсказка", "Или нажми «Войти без аккаунта» — API не нужен.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      enterDemo();
    }, 280);
  };

  return (
    <Layout header={<ShortFlexibleHeader title="Вход" />}>
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          flexGrow: 1,
          alignItems: "center",
          paddingHorizontal: 24,
          paddingTop: insets.top + CHROME_HEADER_BODY + 20,
          paddingBottom: 36,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={{ width: "100%", maxWidth: maxW }} className="items-center">
          <View className="mb-8">
            <AuthIdMark />
          </View>

          <Text className="text-sm text-center mb-5" style={{ color: muted }}>
            Добро пожаловать! Войдите в свой аккаунт.
          </Text>

          {/* Главный путь для демо: без почты и без сервера. */}
          <View className="w-full mb-4">
            <TButton.Solid onPress={enterDemo}>Войти без аккаунта</TButton.Solid>
          </View>
          <Text className="text-xs text-center mb-5" style={{ color: muted }}>
            Временная сессия на устройстве. Сервер не вызывается.
          </Text>

          <View className="w-full gap-3">
            <FlyInput
              prefix={<At size={18} color={icon} />}
              placeholder="Введите свой Email"
              value={email}
              onChange={setEmail}
              variant="outlined"
              autoCapitalize="none"
              keyboardType="email-address"
            />
            <FlyInput
              prefix={<SafeLock size={18} color={icon} />}
              placeholder="Введите пароль"
              value={password}
              onChange={setPassword}
              variant="outlined"
              secureTextEntry
            />
            <TButton.Filled isLoading={loading} className="w-full mt-1" onPress={submit}>
              Войти
            </TButton.Filled>
          </View>

          <View className="flex-row justify-between w-full mt-4">
            <Text className="text-sm flex-1 pr-2" style={{ color: ink }}>
              Нет аккаунта?{" "}
              <Text className="text-primary" onPress={() => nav.push("/auth/create-account")}>
                Зарегистрируйтесь
              </Text>
            </Text>
            <Text
              className="text-sm text-primary"
              onPress={() => showSnack("Демо", "Сброс пароля без API. Войди как гость.")}
            >
              Забыли пароль?
            </Text>
          </View>

          <View className="flex-row items-center w-full mt-8 mb-3">
            <View className="flex-1 h-px bg-primary/15" />
            <Text className="mx-3 text-sm" style={{ color: muted }}>
              или
            </Text>
            <View className="flex-1 h-px bg-primary/15" />
          </View>

          <View className="flex-row w-full gap-2">
            <View className="flex-1">
              <TButton.Outline onPress={enterDemo}>VK</TButton.Outline>
            </View>
            <View className="flex-1">
              <TButton.Outline onPress={enterDemo}>Яндекс</TButton.Outline>
            </View>
          </View>

          <View className="mt-10 items-center">
            <Text className="text-xs text-center" style={{ color: muted }}>
              <Text onPress={() => Linking.openURL("https://help.twitblit.ru/ru/users/legal/privacy-policy")}>
                Политика конфиденциальности
              </Text>
              {"  ·  "}
              <Text onPress={() => Linking.openURL("https://help.twitblit.ru/ru/users/legal/terms-of-use")}>
                Пользовательское соглашение
              </Text>
            </Text>
            <Text className="text-xs mt-2" style={{ color: muted }}>
              © 2024–{year} Twitblit ID. Все права защищены.
            </Text>
          </View>

          {isAuth ? (
            <Text className="mt-4 text-sm text-success">Уже вошли в демо-сессию.</Text>
          ) : null}
        </View>
      </ScrollView>
    </Layout>
  );
}
