/**
 * Корневой layout.
 *
 * Slot вместо Stack: native-stack + Reanimated 4 в текущей конфигурации
 * на Android может закрыть процесс без красного экрана.
 * SafeArea оставляем — Layout читает insets.
 */
import React from "react";
import { Slot } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { UISettingsProvider } from "@/shared/templates/providers/ui_settings_provider";
import { ThemeProvider, useAppTheme } from "@/shared/templates/providers/theme_provider";
import CurrentUserProvider from "@/shared/templates/providers/current_user_provider";
import AnalyticsProvider from "@/shared/templates/providers/analytics_provider";
import AuthGateProvider from "@/shared/widgets/bottom_sheet_modals/auth/auth_gate_provider";
import ErrorBoundary from "@/components/app/error_boundary";
import { DemoSessionProvider } from "@/example/demo_session";
import { AppMenuProvider } from "@/shared/templates/providers/app_menu_provider";
import DemoChrome from "@/components/app/demo_chrome";

function ThemedStatusBar() {
  const { isDark } = useAppTheme();
  return <StatusBar style={isDark ? "light" : "dark"} />;
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <UISettingsProvider>
          <ThemeProvider>
            <CurrentUserProvider>
              <AnalyticsProvider>
                <AuthGateProvider>
                  <DemoSessionProvider>
                    <AppMenuProvider>
                      <ThemedStatusBar />
                      <Slot />
                      <DemoChrome />
                    </AppMenuProvider>
                  </DemoSessionProvider>
                </AuthGateProvider>
              </AnalyticsProvider>
            </CurrentUserProvider>
          </ThemeProvider>
        </UISettingsProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
