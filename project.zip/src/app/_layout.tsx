import { Stack } from 'expo-router';


export default function RootLayout() {
  return (
    <Stack>
    {/* 
        Основной раздел приложения.
        Внутри него находится папка app/navigation/,
        где уже настраиваются табы.
        
        headerShown: false нужен здесь, потому что
        заголовки будут управляться внутри Tabs.
      */}
      <Stack.Screen
        name="navigation"
        options={{ headerShown: false }}
      />
    {/*
        Экран поиска не является вкладкой.
        Он лежит отдельно в app/search.tsx
        и открывается поверх приложения как modal.
      */}
      <Stack.Screen
        name="search"
        options={{
          presentation: 'modal',
          title: 'Поиск',
        }}
      />
    </Stack>
  );
}