// Генератор React Native кода из визуального проекта
export const generateCode = (project, screen) => {
  const imports = generateImports(screen, project);
  const stateVars = generateStateVariables(project.variables);
  const handlersCode = generateHandlers(screen, project);
  const lifecycleCode = generateLifecycle(screen, project);
  const componentCode = generateComponentTree(screen.rootComponent, 4);
  const stylesCode = generateStyles(screen);
  
  const screenName = screen.name.replace(/\s/g, '') + 'Screen';

  return `import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  ScrollView,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Switch,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
${imports}

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const ${screenName} = ({ navigation }) => {
  // State variables
${stateVars}
  
  // Refs
  const inputRefs = useRef({});

  // Lifecycle
${lifecycleCode}

  // Event Handlers
${handlersCode}

  return (
    <View style={styles.container}>
${componentCode}
    </View>
  );
};

${stylesCode}

export default ${screenName};
`;
};

const generateImports = (screen, project) => {
  const imports = [];
  
  if (hasComponentType(screen.rootComponent, 'WebView')) {
    imports.push("import { WebView } from 'react-native-webview';");
  }
  if (hasComponentType(screen.rootComponent, 'MapView')) {
    imports.push("import MapView, { Marker } from 'react-native-maps';");
  }
  if (hasComponentType(screen.rootComponent, 'CardView')) {
    imports.push("// CardView uses View with shadow styles");
  }
  
  return imports.join('\n');
};

const hasComponentType = (component, type) => {
  if (component.type === type) return true;
  if (component.children) {
    return component.children.some(child => hasComponentType(child, type));
  }
  return false;
};

const generateStateVariables = (variables) => {
  if (!variables || variables.length === 0) return '  // No state variables';
  
  return variables.map(v => {
    const defaultValue = v.type === 'number' ? v.value || 0 : 
                         v.type === 'boolean' ? (v.value || false) :
                         `"${v.value || ''}"`;
    const setter = 'set' + v.name.charAt(0).toUpperCase() + v.name.slice(1);
    return `  const [${v.name}, ${setter}] = useState(${defaultValue});`;
  }).join('\n');
};

const generateLifecycle = (screen, project) => {
  const blocks = screen.blocks || [];
  const onCreateBlock = blocks.find(b => b.definitionId === 'on_create');
  
  if (!onCreateBlock) {
    return '  // No onCreate lifecycle handler';
  }

  const actions = generateBlockActions(onCreateBlock.children?.next || [], project);
  return `  useEffect(() => {
    // Screen created
${actions}
  }, []);`;
};

const generateHandlers = (screen, project) => {
  const blocks = screen.blocks || [];
  const clickBlocks = blocks.filter(b => b.definitionId === 'on_click');
  
  if (clickBlocks.length === 0) {
    return '  const handlePress = () => {\n    // Handle press event\n  };';
  }

  return clickBlocks.map((block, idx) => {
    const actions = generateBlockActions(block.children?.next || [], project);
    return `  const handlePress${idx > 0 ? idx + 1 : ''} = () => {
${actions}
  };`;
  }).join('\n\n');
};

const generateBlockActions = (actions, project) => {
  if (!actions || actions.length === 0) return '    console.log("Action triggered");';
  
  return actions.map(action => {
    switch (action.definitionId) {
      case 'show_toast':
        return `    Alert.alert("Сообщение", "${action.inputs?.text || 'Hello!'}");`;
      case 'set_var':
        const setter = 'set' + (action.inputs?.['имя'] || 'var')?.charAt(0)?.toUpperCase() + (action.inputs?.['имя'] || 'var')?.slice(1);
        return `    ${setter || '// setVar'}("${action.inputs?.['значение'] || ''}");`;
      case 'navigate':
        return `    navigation.navigate("${action.inputs?.['экран'] || 'Screen'}");`;
      case 'wait':
        return `    await new Promise(resolve => setTimeout(resolve, ${action.inputs?.['мс'] || 1000}));`;
      case 'set_text':
        return `    // Set text on component: ${action.inputs?.['компонент'] || ''}`;
      case 'set_visible':
        return `    // Set visibility on component: ${action.inputs?.['компонент'] || ''}`;
      default:
        return `    // Block: ${action.definitionId}`;
    }
  }).join('\n');
};

const generateComponentTree = (component, indent) => {
  return mapComponentToJSX(component, indent);
};

const mapComponentToJSX = (component, indent) => {
  const spaces = ' '.repeat(indent);
  const props = component.props || {};
  const styleRef = `styles.comp_${component.id.slice(0, 8)}`;
  
  switch (component.type) {
    case 'LinearLayout':
      return `${spaces}<View style={${styleRef}}>
${(component.children || []).map(c => mapComponentToJSX(c, indent + 2)).join('\n')}
${spaces}</View>`;
    
    case 'ScrollView':
      return `${spaces}<ScrollView style={${styleRef}} showsVerticalScrollIndicator={false}>
${(component.children || []).map(c => mapComponentToJSX(c, indent + 2)).join('\n')}
${spaces}</ScrollView>`;
    
    case 'CardView':
      return `${spaces}<View style={${styleRef}}>
${(component.children || []).map(c => mapComponentToJSX(c, indent + 2)).join('\n')}
${spaces}</View>`;
    
    case 'TextView':
      return `${spaces}<Text style={${styleRef}}>${props.text || ''}</Text>`;
    
    case 'Button':
      return `${spaces}<TouchableOpacity style={${styleRef}} onPress={() => handlePress()}>
${spaces}  <Text style={${styleRef}_text}>${props.text || 'Button'}</Text>
${spaces}</TouchableOpacity>`;
    
    case 'EditText':
      return `${spaces}<TextInput
${spaces}  style={${styleRef}}
${spaces}  placeholder="${props.hint || ''}"
${spaces}  placeholderTextColor="#888"
${spaces}  onChangeText={(text) => console.log('Input:', text)}
${spaces}/>`;
    
    case 'ImageView':
      return `${spaces}<View style={${styleRef}}>
${spaces}  <Ionicons name="image-outline" size={24} color="#64748B" />
${spaces}</View>`;
    
    case 'CheckBox':
      return `${spaces}<TouchableOpacity style={${styleRef}} onPress={() => {}}>
${spaces}  <View style={[styles.checkbox_box, false && styles.checkbox_checked]} />
${spaces}  <Text style={${styleRef}_text}>${props.text || 'CheckBox'}</Text>
${spaces}</TouchableOpacity>`;
    
    case 'Switch':
      return `${spaces}<View style={${styleRef}}>
${spaces}  <Text style={{ color: '#fff' }}>${props.text || 'Switch'}</Text>
${spaces}  <Switch value={false} onValueChange={() => {}} trackColor={{ true: '${props.color || '#BB86FC'}' }} />
${spaces}</View>`;
    
    case 'ProgressBar':
      return `${spaces}<View style={${styleRef}}>
${spaces}  <View style={[${styleRef}_fill, { width: '${props.progress || 50}%' }]} />
${spaces}</View>`;
    
    case 'Divider':
      return `${spaces}<View style={${styleRef}} />`;
    
    case 'Spacer':
      return `${spaces}<View style={${styleRef}} />`;
    
    case 'WebView':
      return `${spaces}<WebView source={{ uri: '${props.url || 'https://example.com'}' }} style={${styleRef}} />`;
    
    case 'MapView':
      return `${spaces}<MapView style={${styleRef}} initialRegion={{
${spaces}  latitude: ${props.latitude || 55.7558},
${spaces}  longitude: ${props.longitude || 37.6173},
${spaces}  latitudeDelta: 0.0922,
${spaces}  longitudeDelta: 0.0421,
${spaces}}} />`;
    
    default:
      return `${spaces}<View style={${styleRef}}><Text>${component.type}</Text></View>`;
  }
};

const generateStyles = (screen) => {
  const styles = [];
  const rootProps = screen.rootComponent.props || {};
  
  styles.push(`const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '${screen.backgroundColor || '#121212'}',
    padding: ${rootProps.padding || 16},
  },`);
  
  generateComponentStyles(screen.rootComponent, styles);
  
  styles.push('});\n');
  
  return styles.join('\n');
};

const generateComponentStyles = (component, styles) => {
  const props = component.props || {};
  const styleKey = `  comp_${component.id.slice(0, 8)}`;
  
  switch (component.type) {
    case 'LinearLayout':
    case 'CardView':
      styles.push(`${styleKey}: {
    flexDirection: '${props.orientation === 'horizontal' ? 'row' : 'column'}',
    ${getDimensionStyle('width', props.width)}
    ${getDimensionStyle('height', props.height)}
    padding: ${props.padding || 0},
    backgroundColor: '${props.backgroundColor || 'transparent'}',
    borderRadius: ${props.borderRadius || 0},
    ${props.elevation ? `elevation: ${props.elevation},
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,` : ''}
    justifyContent: '${getJustifyContent(props.gravity)}',
    alignItems: '${getAlignItems(props.gravity)}',
  },`);
      break;
    
    case 'ScrollView':
      styles.push(`${styleKey}: {
    ${getDimensionStyle('width', props.width)}
    ${getDimensionStyle('height', props.height)}
  },`);
      break;
    
    case 'TextView':
      styles.push(`${styleKey}: {
    fontSize: ${props.textSize || 16},
    color: '${props.textColor || '#FFFFFF'}',
    fontWeight: '${props.textStyle === 'bold' ? 'bold' : 'normal'}',
    fontStyle: '${props.textStyle === 'italic' ? 'italic' : 'normal'}',
    textAlign: '${props.gravity || 'left'}',
    padding: ${props.padding || 0},
  },`);
      break;
    
    case 'Button':
      styles.push(`${styleKey}: {
    backgroundColor: '${props.backgroundColor || '#BB86FC'}',
    padding: ${props.padding || 12},
    borderRadius: ${props.borderRadius || 8},
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 4,
  },
  ${styleKey}_text: {
    color: '${props.textColor || '#FFFFFF'}',
    fontSize: ${props.textSize || 16},
    fontWeight: 'bold',
  },`);
      break;
    
    case 'EditText':
      styles.push(`${styleKey}: {
    backgroundColor: '${props.backgroundColor || '#2C2C2C'}',
    padding: ${props.padding || 12},
    borderRadius: ${props.borderRadius || 8},
    color: '${props.textColor || '#FFFFFF'}',
    fontSize: ${props.textSize || 16},
    marginVertical: 4,
    borderWidth: 1,
    borderColor: '#444',
  },`);
      break;
    
    case 'ImageView':
      styles.push(`${styleKey}: {
    width: ${typeof props.width === 'number' ? props.width : 100},
    height: ${typeof props.height === 'number' ? props.height : 100},
    backgroundColor: '${props.backgroundColor || '#333333'}',
    borderRadius: ${props.borderRadius || 0},
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },`);
      break;
    
    case 'CheckBox':
      styles.push(`${styleKey}: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  ${styleKey}_text: {
    color: '${props.textColor || '#FFFFFF'}',
    fontSize: ${props.textSize || 16},
    marginLeft: 8,
  },`);
      break;
    
    case 'Switch':
      styles.push(`${styleKey}: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },`);
      break;
    
    case 'ProgressBar':
      styles.push(`${styleKey}: {
    height: 8,
    backgroundColor: '#333',
    borderRadius: 4,
    overflow: 'hidden',
    marginVertical: 8,
  },
  ${styleKey}_fill: {
    height: '100%',
    backgroundColor: '${props.color || '#BB86FC'}',
    borderRadius: 4,
  },`);
      break;
    
    case 'Divider':
      styles.push(`${styleKey}: {
    height: ${props.height || 1},
    backgroundColor: '${props.backgroundColor || '#444444'}',
    margin: ${props.margin || 8},
  },`);
      break;
    
    case 'Spacer':
      styles.push(`${styleKey}: {
    height: ${props.height || 16},
  },`);
      break;
    
    case 'WebView':
    case 'MapView':
      styles.push(`${styleKey}: {
    width: '100%',
    height: ${props.height || 300},
    borderRadius: 8,
    overflow: 'hidden',
  },`);
      break;
  }
  
  if (component.children) {
    component.children.forEach(child => generateComponentStyles(child, styles));
  }
};

const getDimensionStyle = (key, value) => {
  if (value === 'match_parent') return `${key}: '100%',`;
  if (value === 'wrap_content') return '';
  if (typeof value === 'number') return `${key}: ${value},`;
  return '';
};

const getJustifyContent = (gravity) => {
  if (gravity === 'center') return 'center';
  if (gravity === 'right') return 'flex-end';
  return 'flex-start';
};

const getAlignItems = (gravity) => {
  if (gravity === 'center') return 'center';
  if (gravity === 'right') return 'flex-end';
  return 'flex-start';
};

// Additional helper styles
const additionalStyles = `
  checkbox_box: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#BB86FC',
    borderRadius: 4,
  },
  checkbox_checked: {
    backgroundColor: '#BB86FC',
  },
`;

export default generateCode;
