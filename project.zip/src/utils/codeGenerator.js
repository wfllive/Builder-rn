import { generateComposeScreen } from './composeProject';

/** Generate the Kotlin @Composable source for one visual screen. */
export const generateCode = (project, screen) => {
  const index = Math.max(0, (project.screens || []).findIndex((item) => item.id === screen.id));
  return generateComposeScreen(project, screen, index);
};

export default generateCode;
