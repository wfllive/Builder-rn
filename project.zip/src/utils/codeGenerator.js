/**
 * Code generator wrapper for React.
 * Previously generated Kotlin Compose. Now generates JSX.
 */
import { generateScreenJSX } from './composeProject';

export const generateCode = (project, screen) => {
  if (!screen) return '';
  return generateScreenJSX(screen);
};

export default generateCode;
