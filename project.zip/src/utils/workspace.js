import * as SecureStore from 'expo-secure-store';
import { execute } from './shellExecutor';
import { getProjectDir } from '../config/runtime';

const EAS_TOKEN_KEY = '@skpro_eas_token';

export const shellQuote = (value = '') => `'${String(value).replace(/'/g, `'"'"'`)}'`;

export const readWorkspaceJson = async (project, fileName) => {
  const result = await execute(`cat ${shellQuote(fileName)}`, getProjectDir(project));
  if (!result?.success) throw new Error(result?.output || `Cannot read ${fileName}`);
  return JSON.parse(result.output);
};

const toBase64 = (content) => {
  const bytes = unescape(encodeURIComponent(content));
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let result = '';
  for (let index = 0; index < bytes.length; index += 3) {
    const a = bytes.charCodeAt(index);
    const hasB = index + 1 < bytes.length;
    const hasC = index + 2 < bytes.length;
    const b = hasB ? bytes.charCodeAt(index + 1) : 0;
    const c = hasC ? bytes.charCodeAt(index + 2) : 0;
    const value = (a << 16) | (b << 8) | c;
    result += alphabet[(value >> 18) & 63];
    result += alphabet[(value >> 12) & 63];
    result += hasB ? alphabet[(value >> 6) & 63] : '=';
    result += hasC ? alphabet[value & 63] : '=';
  }
  return result;
};

export const writeWorkspaceFile = async (project, fileName, content) => {
  const encoded = toBase64(content);
  const command = `mkdir -p "$(dirname ${shellQuote(fileName)})" && printf %s ${shellQuote(encoded)} | base64 -d > ${shellQuote(fileName)}`;
  return execute(command, getProjectDir(project));
};

export const writeWorkspaceJson = (project, fileName, value) => writeWorkspaceFile(project, fileName, `${JSON.stringify(value, null, 2)}\n`);

export const getEasToken = () => SecureStore.getItemAsync(EAS_TOKEN_KEY);
export const saveEasToken = (token) => token
  ? SecureStore.setItemAsync(EAS_TOKEN_KEY, token.trim(), { keychainAccessible: SecureStore.WHEN_UNLOCKED })
  : SecureStore.deleteItemAsync(EAS_TOKEN_KEY);
export const easEnvironment = async () => {
  const token = await getEasToken();
  return token ? `EXPO_TOKEN=${shellQuote(token)} ` : '';
};
