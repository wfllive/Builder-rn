/**
 * raiSetup.ts — окружение сборки Android на устройстве.
 *
 * Два режима установки:
 *   'ncs'  (по умолчанию) — быстрая минимальная установка NCS Build:
 *           JDK 17 headless + Android build-tools 35.0.0 + platform android-35 + ncs CLI.
 *           Без Node.js, без Gradle, без Compose/Kotlin. ~300 МБ, 1–2 мин.
 *   'full' — полный RAI-стек: apt upgrade + Node.js 24 + rai + rai install base/sdk
 *           с поддержкой старых Gradle/Kotlin/Compose проектов. ~1.2–1.5 ГБ, 5–10 мин.
 *
 * Каждый шаг идемпотентен: при повторе уже выполненные шаги пропускаются.
 */
import * as apt from '../../modules/apt-manager/src/index';
import { execute, persistentStreamExecute } from './shellExecutor';
import { updateBackground } from './background';

export type SetupMode = 'ncs' | 'full';

export const RAI_BUNDLE_DIR = '/root/rai';
export const RAI_BUNDLE = `${RAI_BUNDLE_DIR}/rai.sh`;

// NCS paths (новая быстрая система)
export const NCS_HOME = '/root/.ncs';
export const NCS_SETUP_MARKER = `${NCS_HOME}/.setup.done`;
export const NCS_BIN = `${NCS_HOME}/bin/ncs`;
export const NCS_FAST_INSTALL = `${NCS_HOME}/bin/fast-install.sh`;
export const NCS_SDK = `${NCS_HOME}/sdk`;
export const NCS_BUILD_TOOLS_VER = '35.0.0';
export const NCS_PLATFORM_VER = 'android-35';

// Legacy RAI paths
export const SETUP_MARKER = '/root/.rai-setup.done';
export const SETUP_STEP_FILE = '/root/.rai-step';
export const SETUP_STEP_DONE = '/root/.rai-step.done';
export const SETUP_LOG = '/root/.rai-setup.log';
export const SETUP_STATUS_FILE = '/root/.rai-status.txt';
export const ANDROID_HOME_RAI = '/root/android-sdk';
export const ANDROID_HOME = ANDROID_HOME_RAI;
export const RAI_VERSION = '0.0.1';

const shq = (v = '') => `'${String(v).replace(/'/g, `'\\''`)}'`;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Безопасная оболочка строки для echo в PTY-терминал (не даёт bash-интерпретировать текст)
const ptyEcho = (text: string) => `printf '%s\\r\\n' ${shq(text)};`;

// ---------------------------------------------------------------------------
// Общие хелперы
// ---------------------------------------------------------------------------

const isDone = async (cmd: string): Promise<boolean> => {
  try {
    const r = await execute(`${cmd}; echo RC_$?`, '/');
    return /DONE/.test(r.output || '') && /RC_0\b/.test(r.output || '');
  } catch {
    return false;
  }
};

const streamRun = async (
  command: string,
  onLine: ((l: string) => void) | undefined,
  workDir = '/',
  stepId = 'setup',
) => {
  const res = await persistentStreamExecute(
    command,
    workDir,
    (line) => { try { onLine && onLine(line); } catch {} },
    { label: `setup:${stepId}`, kind: 'rai-setup', metadata: { stepId } },
  );
  return {
    success: res?.success === true && (res?.exitCode ?? 0) === 0,
    output: res?.output || '',
  };
};

// ---------------------------------------------------------------------------
// Шаги БЫСТРОЙ установки NCS Build (умолчание) — без Node.js, без rai CLI
// ---------------------------------------------------------------------------

// seedNcsStep: материализует NCS shell-скрипты из APK-ассетов в proot
// через нативный метод AptManager.seedNcsScripts — без Node.js и без rai.sh.
const seedNcsStep = {
  id: 'seed-ncs',
  title: { ru: 'Копирование NCS-скриптов из APK', en: 'Seeding NCS scripts from APK' },
  check: `[ -x ${NCS_FAST_INSTALL} ] && echo DONE || echo TODO`,
  run: async (emit: (s: string) => void) => {
    emit('→ Копирую NCS-скрипты из APK в proot...');
    let seeded: any = { success: false };
    try { seeded = await apt.seedNcsScripts(); } catch (e: any) { seeded = { success: false, output: String(e) }; }
    if (!seeded?.success) {
      emit(`❌ ${seeded?.output || 'seedNcsScripts failed'}`);
      return false;
    }
    emit(`✓ ${seeded.output || 'NCS-скрипты установлены'}`);
    return true;
  },
};

export const NCS_FAST_STEPS = [
  {
    id: 'apt',
    title: { ru: 'Настройка apt и сети', en: 'Apt and network config' },
    cmd:
      'export DEBIAN_FRONTEND=noninteractive; ' +
      'mkdir -p /tmp /var/tmp && chmod 1777 /tmp /var/tmp 2>/dev/null || true; ' +
      '(dpkg --configure -a 2>/dev/null || true); ' +
      'if ! grep -q "^nameserver" /etc/resolv.conf 2>/dev/null; then ' +
      '  printf "nameserver 8.8.8.8\\nnameserver 1.1.1.1\\nnameserver 8.8.4.4\\n" > /etc/resolv.conf; ' +
      'fi; ' +
      'apt-get update -qq 2>&1 | tail -5',
    check:
      'command -v curl >/dev/null 2>&1 && grep -q "^nameserver" /etc/resolv.conf 2>/dev/null && echo DONE || echo TODO',
  },
  seedNcsStep,
  {
    id: 'ncs-setup',
    title: { ru: 'JDK 17 + Android SDK + ncs CLI', en: 'JDK 17 + Android SDK + ncs CLI' },
    // Запускаем fast-install.sh напрямую — он внутри ставит JDK headless,
    // Android SDK cmdline-tools, build-tools и platform без Node.js/rai.
    cmd: `bash ${shq(NCS_FAST_INSTALL)} 2>&1`,
    check:
      '[ -x ' + shq(NCS_BIN) + ' ] && ' +
      '[ -f ' + shq(NCS_SDK) + '/build-tools/' + NCS_BUILD_TOOLS_VER + '/aapt2 ] && ' +
      '[ -f ' + shq(NCS_SDK) + '/platforms/' + NCS_PLATFORM_VER + '/android.jar ] && ' +
      'command -v javac >/dev/null 2>&1 && echo DONE || echo TODO',
  },
  {
    id: 'ncs-doctor',
    title: { ru: 'Проверка ncs doctor', en: 'NCS doctor verification' },
    always: true,
    run: async (emit: (s: string) => void) => {
      const res = await streamRun(
        'bash -lc "source ~/.bashrc 2>/dev/null; ncs doctor 2>&1"',
        emit,
        '/',
        'ncs-doctor',
      );
      emit('');
      const javac = await execute('command -v javac >/dev/null 2>&1 && echo OK', '/');
      const aapt2 = await execute('test -f ' + shq(NCS_SDK) + '/build-tools/' + NCS_BUILD_TOOLS_VER + '/aapt2 && echo OK', '/');
      const jar = await execute('test -f ' + shq(NCS_SDK) + '/platforms/' + NCS_PLATFORM_VER + '/android.jar && echo OK', '/');
      const ncsBin = await execute('test -x ' + shq(NCS_BIN) + ' && echo OK', '/');
      const ok =
        /OK/.test(javac.output || '') &&
        /OK/.test(aapt2.output || '') &&
        /OK/.test(jar.output || '') &&
        /OK/.test(ncsBin.output || '');
      emit(ok ? '✓ JDK + aapt2 + android.jar + ncs готовы' : '❌ Компоненты NCS неполные');
      return ok && res.success;
    },
  },
  {
    id: 'marker',
    title: { ru: 'Завершение установки', en: 'Finish setup' },
    always: true,
    run: async (emit: (s: string) => void) => {
      await execute('mkdir -p ' + shq(NCS_HOME) + ' && echo ok > ' + shq(NCS_SETUP_MARKER), '/');
      await execute('rm -f ' + shq(SETUP_MARKER), '/');
      emit('✓ NCS Build готов — переходим к проектам');
      return true;
    },
  },
];

// ---------------------------------------------------------------------------
// Шаги ПОЛНОЙ установки (legacy Gradle/Kotlin/Compose)
// ---------------------------------------------------------------------------

const seedRaiStep = {
  id: 'rai',
  title: { ru: 'Установка RAI (локальный бандл)', en: 'Install RAI (local bundle)' },
  check: `command -v rai >/dev/null 2>&1 && echo DONE || echo TODO`,
  run: async (emit: (s: string) => void) => {
    emit('→ Копирую RAI-бандл из APK...');
    let seeded: any = { success: false };
    try { seeded = await apt.seedRaiBundle(); } catch (e: any) { seeded = { success: false, output: String(e) }; }
    if (!seeded?.success) {
      const probe = await execute(`[ -s ${shq(RAI_BUNDLE)} ] && echo YES || echo NO`, '/');
      if (!/YES/.test(probe.output || '')) {
        emit(`❌ ${seeded?.output || 'seedRaiBundle failed'}`);
        return false;
      }
      emit('⚠ Бандл уже есть в rootfs');
    } else {
      emit(`✓ ${seeded.output}`);
    }
    emit('→ Устанавливаю RAI CLI (требует Node.js)...');
    const res = await streamRun(`bash ${shq(RAI_BUNDLE)} 2>&1`, emit, '/', 'rai');
    const check = await execute('command -v rai >/dev/null 2>&1 && echo RAI_OK || echo RAI_MISSING', '/');
    if (!/RAI_OK/.test(check.output || '')) {
      emit('❌ rai не доступен после установки (нужен Node.js 18+)');
      return false;
    }
    return res;
  },
};

export const SETUP_STEPS = [
  {
    id: 'apt',
    title: { ru: 'apt update && apt upgrade', en: 'apt update && apt upgrade' },
    cmd:
      'export DEBIAN_FRONTEND=noninteractive; ' +
      '(dpkg --configure -a 2>/dev/null || true); ' +
      'apt update && apt upgrade -y',
    check: 'command -v curl >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1 && [ -n "$(ls /var/lib/apt/lists/ 2>/dev/null | head -1)" ] && echo DONE || echo TODO',
  },
  {
    id: 'tools',
    title: { ru: 'Утилиты: curl, wget, zip, unzip', en: 'Utilities: curl, wget, zip, unzip' },
    cmd:
      'export DEBIAN_FRONTEND=noninteractive; ' +
      '(dpkg --configure -a 2>/dev/null || true); ' +
      '(apt -f install -y 2>/dev/null || true); ' +
      'apt install -y curl wget zip unzip ca-certificates',
    check: 'command -v curl >/dev/null 2>&1 && command -v wget >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1 && command -v zip >/dev/null 2>&1 && echo DONE || echo TODO',
  },
  {
    id: 'node',
    title: { ru: 'Node.js 24 (nodesource)', en: 'Node.js 24 (nodesource)' },
    cmd:
      'if node -v 2>/dev/null | grep -qE "^v(2[0-9]|[0-9]{3,})"; then echo "node $(node -v) уже установлен"; ' +
      'elif curl -fsSL https://deb.nodesource.com/setup_24.x | bash - && apt install -y nodejs; then echo "node $(node -v) (nodesource 24.x)"; ' +
      'else apt install -y nodejs && echo "node $(node -v) (apt fallback)"; fi',
    check: 'node -v 2>/dev/null | grep -qE "^v(1[89]|[2-9][0-9])" && echo DONE || echo TODO',
  },
  seedRaiStep,
  {
    id: 'base',
    title: { ru: 'rai install base (apt, JDK 17)', en: 'rai install base (apt, JDK 17)' },
    cmd: 'rai install base',
    check: 'command -v javac >/dev/null 2>&1 && command -v java >/dev/null 2>&1 && echo DONE || echo TODO',
  },
  {
    id: 'sdk',
    title: { ru: 'rai install sdk (нативный ARM SDK)', en: 'rai install sdk (native ARM SDK)' },
    cmd: 'rai install sdk',
    check: `[ -d ${ANDROID_HOME_RAI}/build-tools ] && [ -d ${ANDROID_HOME_RAI}/platforms ] && echo DONE || echo TODO`,
  },
  {
    id: 'status',
    title: { ru: 'rai status — проверка компонентов', en: 'rai status — verify components' },
    always: true,
    run: async (emit: (s: string) => void) => {
      const res = await streamRun('rai status 2>&1', emit, '/', 'status');
      const parsed = parseRaiStatus(res.output);
      emit('');
      emit(parsed.ok
        ? '✓ Java + build-tools + platforms на месте'
        : '❌ компоненты неполные: Java/сборка/платформы не найдены');
      return parsed.ok;
    },
  },
  {
    id: 'marker',
    title: { ru: 'Завершение установки', en: 'Finish setup' },
    always: true,
    run: async (emit: (s: string) => void) => {
      await execute(`mkdir -p /root && echo ok > ${shq(SETUP_MARKER)} && echo done > ${shq(SETUP_LOG)}`, '/');
      emit('✓ полная RAI-среда готова');
      return true;
    },
  },
];

// ---------------------------------------------------------------------------
// Парсер `rai status`
// ---------------------------------------------------------------------------

export const parseRaiStatus = (output = '') => {
  const java = /Java\s*:\s*([^\n]+)/.exec(output);
  const bt = /build-tools\s*:\s*([^\n]+)/.exec(output);
  const pl = /platforms\s*:\s*([^\n]+)/.exec(output);
  const no = /нет|none/i;
  const ok = Boolean(
    java && bt && pl &&
    /\d/.test(java[1]) && !no.test(java[1]) &&
    /\d/.test(bt[1]) && !no.test(bt[1]) &&
    /android/i.test(pl[1]) && !no.test(pl[1]),
  );
  return { ok, java: java?.[1].trim() ?? '', buildTools: bt?.[1].trim() ?? '', platforms: pl?.[1].trim() ?? '', output };
};

// ---------------------------------------------------------------------------
// Выбор шагов по режиму
// ---------------------------------------------------------------------------

export const stepsFor = (mode: SetupMode) => (mode === 'ncs' ? NCS_FAST_STEPS : SETUP_STEPS);

// ---------------------------------------------------------------------------
// Общий прогон установки (для фонового сервиса, без PTY)
// ---------------------------------------------------------------------------

const workflowCommandForStep = (step: any, stepsList: any[]) => {
  if (step.id === 'rai') return `bash ${shq(RAI_BUNDLE)} && command -v rai >/dev/null 2>&1`;
  if (step.id === 'seed-ncs') {
    // В фоновом shell-режиме нет JS, но seed уже сделан из JS перед запуском workflow
    return `[ -x ${shq(NCS_FAST_INSTALL)} ] && echo DONE`;
  }
  if (step.id === 'ncs-doctor') {
    return (
      `bash -lc "source ~/.bashrc 2>/dev/null; ncs doctor >/dev/null 2>&1" && ` +
      `test -x ${shq(NCS_BIN)} && ` +
      `test -f ${shq(NCS_SDK)}/build-tools/${NCS_BUILD_TOOLS_VER}/aapt2 && ` +
      `test -f ${shq(NCS_SDK)}/platforms/${NCS_PLATFORM_VER}/android.jar && ` +
      `command -v javac >/dev/null 2>&1`
    );
  }
  if (step.id === 'status') {
    return `rai status 2>&1 | tee ${shq(SETUP_STATUS_FILE)}; ` +
      `grep -qE 'Java[[:space:]]*:[[:space:]]*[0-9]' ${shq(SETUP_STATUS_FILE)} && ` +
      `grep -qE 'build-tools[[:space:]]*:[[:space:]]*[0-9]' ${shq(SETUP_STATUS_FILE)} && ` +
      `grep -qE 'platforms[[:space:]]*:[[:space:]]*android' ${shq(SETUP_STATUS_FILE)}`;
  }
  if (step.id === 'marker') {
    const isNcs = stepsList === NCS_FAST_STEPS;
    const marker = isNcs ? NCS_SETUP_MARKER : SETUP_MARKER;
    const cmd = isNcs
      ? `mkdir -p ${shq(NCS_HOME)} && echo ok > ${shq(marker)} && rm -f ${shq(SETUP_MARKER)}`
      : `mkdir -p /root && echo ok > ${shq(marker)} && echo done > ${shq(SETUP_LOG)}`;
    return cmd;
  }
  return step.cmd || 'true';
};

const buildWorkflowCommand = (steps: any[]) => {
  const lines = [
    'run_nova_step() {',
    '  nova_id="$1"; nova_title="$2"; nova_check="$3"; nova_body="$4"',
    `  printf '%s\\n' "$nova_id" > ${shq(SETUP_STEP_FILE)}`,
    '  printf "@@NOVA_STEP_START@@:%s\\n" "$nova_id"',
    '  printf "── %s ──\\n" "$nova_title"',
    '  if [ -n "$nova_check" ] && eval "$nova_check" | grep -q DONE; then',
    '    printf "@@NOVA_STEP_SKIPPED@@:%s\\n" "$nova_id"',
    '    return 0',
    '  fi',
    '  eval "$nova_body"',
    '  nova_rc=$?',
    '  if [ "$nova_rc" -eq 0 ]; then',
    '    printf "@@NOVA_STEP_DONE@@:%s\\n" "$nova_id"',
    '    return 0',
    '  fi',
    '  printf "@@NOVA_STEP_FAILED@@:%s:%s\\n" "$nova_id" "$nova_rc"',
    '  return "$nova_rc"',
    '}',
  ];
  steps.forEach((step: any) => {
    // JS-шаги (seed, doctor, status, marker) в фоновом shell-режиме заменяем на shell-эквиваленты
    const shellBody = typeof step.run === 'function'
      ? workflowCommandForStep(step, steps)
      : (step.cmd || 'true');
    lines.push(
      `run_nova_step ${shq(step.id)} ${shq(step.title?.ru || step.id)} ` +
      `${shq(step.check || '')} ${shq(shellBody)} || exit $?`,
    );
  });
  lines.push(`rm -f ${shq(SETUP_STEP_FILE)} ${shq(SETUP_STEP_DONE)}`);
  return lines.join('\n');
};

export const runRaiSetup = async ({ onStepStart, onStepEnd, onLine, mode = 'ncs' as SetupMode }) => {
  const steps = stepsFor(mode);

  // Seed-шаги (JS-only копирование из APK) выполняем до запуска shell workflow
  for (const s of steps) {
    if (s.id === 'seed-ncs') {
      try {
        const r = await apt.seedNcsScripts();
        if (!r?.success) {
          return { ok: false, mode, summary: [{ id: 'seed-ncs', status: 'failed', output: r?.output || 'seedNcsScripts failed' }] };
        }
      } catch (e: any) {
        return { ok: false, mode, summary: [{ id: 'seed-ncs', status: 'failed', output: String(e) }] };
      }
    } else if (s.id === 'rai') {
      try {
        const r = await apt.seedRaiBundle();
        if (!r?.success) {
          const probe = await execute(`[ -s ${shq(RAI_BUNDLE)} ] && echo YES || echo NO`, '/');
          if (!/YES/.test(probe.output || '')) {
            return { ok: false, mode, summary: [{ id: 'rai', status: 'failed', output: r?.output || 'seedRaiBundle failed' }] };
          }
        }
      } catch (e: any) {
        return { ok: false, mode, summary: [{ id: 'rai', status: 'failed', output: String(e) }] };
      }
    }
  }

  const byId = Object.fromEntries(steps.map((s: any) => [s.id, s]));
  const states = new Map<string, string>();
  const command = buildWorkflowCommand(steps);
  const result = await persistentStreamExecute(
    command,
    '/',
    (line) => {
      const marker = /^@@NOVA_STEP_(START|DONE|SKIPPED|FAILED)@@:([^:]+)(?::(.*))?$/.exec(line);
      if (!marker) { try { onLine && onLine(line); } catch {}; return; }
      const [, event, id, detail] = marker;
      const step = byId[id];
      if (!step) return;
      if (event === 'START') {
        states.set(id, 'running');
        try { onStepStart && onStepStart(id, step); } catch {}
        return;
      }
      const status = event === 'DONE' ? 'done' : event === 'SKIPPED' ? 'skipped' : 'failed';
      states.set(id, status);
      try { onStepEnd && onStepEnd(id, step, { status, output: detail || '' }); } catch {}
    },
    { label: `${mode} setup`, kind: 'rai-setup-workflow', metadata: { workflow: mode, version: 1 } },
  );
  const summary = steps.filter((s: any) => states.has(s.id)).map((s: any) => ({ id: s.id, status: states.get(s.id) }));
  const last = steps[steps.length - 1];
  return { ok: result.success && states.get(last.id) === 'done', mode, summary };
};

// ---------------------------------------------------------------------------
// PTY-режим — команды выполняются в интерактивном терминале Termux.
// ВАЖНО: terminal.write() пишет в stdin bash, поэтому для вывода логов
// из JS-шагов используем printf/echo, а не сырой текст.
// ---------------------------------------------------------------------------

const ptyStepCommand = (step: any) => {
  switch (step.id) {
    case 'rai': return `bash ${shq(RAI_BUNDLE)}`;
    case 'status': return `rai status 2>&1 | tee ${shq(SETUP_STATUS_FILE)}`;
    case 'ncs-doctor': return `bash -lc "source ~/.bashrc 2>/dev/null; ncs doctor 2>&1"`;
    case 'marker': return `echo ok > ${shq(SETUP_MARKER)}`;
    default: return step.cmd;
  }
};

const ptyStepTimeout = (step: any) => {
  if (step.id === 'marker' || step.id === 'ncs-doctor' || step.id === 'status') return 5 * 60 * 1000;
  if (step.id === 'sdk' || step.id === 'ncs-setup' || step.id === 'node') return 20 * 60 * 1000;
  return 120 * 60 * 1000;
};

const waitForMarker = async (marker: string, intervalMs: number, timeoutMs: number) => {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await execute(`cat ${shq(marker)} 2>/dev/null`, '/');
      const v = String(r.output || '').trim();
      if (v) return v;
    } catch {}
    await sleep(intervalMs);
  }
  return '';
};

export interface PtyRunOptions {
  terminal: { write: (s: string) => void };
  onStepStart?: (id: string, step: any) => void;
  onStepEnd?: (id: string, step: any, res: { status: string; output?: string }) => void;
  onStatusOutput?: (p: any) => void;
  mode?: SetupMode;
}

export const runRaiSetupPty = async (opts: PtyRunOptions) => {
  const { terminal, onStepStart, onStepEnd, onStatusOutput, mode = 'ncs' } = opts;
  const steps = stepsFor(mode);
  const summary: any[] = [];
  const markerWrite = async (path: string, value: string) => {
    try { await execute(`echo ${shq(value)} > ${shq(path)}`, '/'); } catch {}
  };
  try { await execute(`rm -f ${shq(SETUP_STEP_FILE)} ${shq(SETUP_STEP_DONE)} ${shq(SETUP_STATUS_FILE)}`, '/'); } catch {}

  // Вспомогательная функция для безопасного вывода в PTY:
  // отправляет echo-команду, а не голый текст — bash не пытается выполнить его.
  const ptyLog = (s: string) => {
    try { terminal.write(ptyEcho(s)); } catch {}
  };

  for (const [index, step] of steps.entries()) {
    try { onStepStart && onStepStart(step.id, step); } catch {}
    try { await updateBackground(step.title?.ru || step.id); } catch {}

    // Шаг уже сделан? → skip
    if (step.check) {
      try {
        if (await isDone(step.check)) {
          ptyLog(`  [пропущено] ${step.title?.ru || step.id}`);
          try { onStepEnd && onStepEnd(step.id, step, { status: 'skipped' }); } catch {}
          summary.push({ id: step.id, status: 'skipped' });
          continue;
        }
      } catch {}
    }

    // JS-шаги (seed-*, doctor, status, marker) выполняем через JS
    if (typeof step.run === 'function') {
      try {
        const ok = await step.run(ptyLog);
        if (ok === false) {
          try { onStepEnd && onStepEnd(step.id, step, { status: 'failed' }); } catch {}
          summary.push({ id: step.id, status: 'failed' });
          return { ok: false, mode, summary };
        }
        try { onStepEnd && onStepEnd(step.id, step, { status: 'done' }); } catch {}
        summary.push({ id: step.id, status: 'done' });
        if (step.id === 'status') {
          const st = await execute(`cat ${shq(SETUP_STATUS_FILE)} 2>/dev/null`, '/');
          const parsed = parseRaiStatus(st.output || '');
          try { onStatusOutput && onStatusOutput(parsed); } catch {}
          if (!parsed.ok) return { ok: false, mode, summary };
        }
      } catch (e: any) {
        ptyLog(`❌ ${e?.message || e}`);
        try { onStepEnd && onStepEnd(step.id, step, { status: 'failed', output: String(e) }); } catch {}
        summary.push({ id: step.id, status: 'failed' });
        return { ok: false, mode, summary };
      }
      continue;
    }

    // Shell-шаг — отправляем команду в PTY, ждём маркер завершения
    const cmd = ptyStepCommand(step);
    const title = step.title?.ru || step.id;
    const header = shq(`── [${index + 1}/${steps.length}] ${title} ──`);
    const marker = step.id === 'marker' ? NCS_SETUP_MARKER : SETUP_STEP_DONE;
    const endFile = step.id === 'marker'
      ? marker
      : SETUP_STEP_DONE;
    const full =
      `echo ${header}; ` +
      `echo "start:${step.id}" > ${shq(SETUP_STEP_FILE)}; ` +
      `echo "" > ${shq(SETUP_STEP_DONE)}; ` +
      `${cmd}; rc=$?; echo "end:${step.id}:$rc" > ${shq(SETUP_STEP_DONE)}; ` +
      `echo "--> exit=$rc"`;
    terminal.write(full + '\n');

    const end = await waitForMarker(endFile, 2500, ptyStepTimeout(step));
    if (!end) {
      ptyLog(`❌ timeout на шаге ${title}`);
      try { onStepEnd && onStepEnd(step.id, step, { status: 'failed', output: 'timeout' }); } catch {}
      summary.push({ id: step.id, status: 'failed' });
      return { ok: false, mode, summary };
    }

    // Для marker-шага успех = наличие файла маркера
    let stepOk = false;
    if (step.id === 'marker') {
      stepOk = true;
    } else {
      const m = end.match(/^end:([^:]+):(\d+)$/);
      stepOk = !!(m && m[2] === '0');
    }
    if (!stepOk) {
      ptyLog(`❌ шаг ${title} завершился с ошибкой`);
      try { onStepEnd && onStepEnd(step.id, step, { status: 'failed', output: end }); } catch {}
      summary.push({ id: step.id, status: 'failed' });
      return { ok: false, mode, summary };
    }
    try { onStepEnd && onStepEnd(step.id, step, { status: 'done' }); } catch {}
    summary.push({ id: step.id, status: 'done' });
    await markerWrite(SETUP_STEP_DONE, '');
    await sleep(150);
  }

  try { await execute(`rm -f ${shq(SETUP_STEP_FILE)} ${shq(SETUP_STEP_DONE)}`, '/'); } catch {}
  return { ok: true, mode, summary };
};

// ---------------------------------------------------------------------------
// Готовность окружения (NCS или полная)
// ---------------------------------------------------------------------------

export const RAI_READY_SENTINEL = '@@NOVA_RAI_READY@@';
export const RAI_NOT_READY_SENTINEL = '@@NOVA_RAI_NOT_READY@@';

export const isRaiProbeReady = (output = ''): boolean =>
  String(output).split(/\r?\n/).some((l) => l.trim() === RAI_READY_SENTINEL);

/**
 * Проверяет, готово ли любое из окружений:
 *  - NCS Build (приоритет): ncs на месте + aapt2 + android.jar + javac
 *  - Или полный RAI стек: rai status показывает Java+BT+platforms
 */
export const probeRaiReady = async () => {
  try {
    const ncsCheck =
      `test -x ${shq(NCS_BIN)} && ` +
      `test -f ${shq(NCS_SDK)}/build-tools/${NCS_BUILD_TOOLS_VER}/aapt2 && ` +
      `test -f ${shq(NCS_SDK)}/platforms/${NCS_PLATFORM_VER}/android.jar && ` +
      `command -v javac >/dev/null 2>&1 && echo NCS_READY || echo NCS_NOT_READY`;

    const raiCheck =
      'if command -v rai >/dev/null 2>&1; then ' +
      '  out=$(rai status 2>&1); rc=$?; ' +
      `  printf '%s\\n' "$out" > ${shq(SETUP_STATUS_FILE)}; ` +
      '  if [ $rc -eq 0 ] && ' +
      '    echo "$out" | grep -qE "Java[[:space:]]*:[[:space:]]*[0-9]" && ' +
      '    echo "$out" | grep -qE "build-tools[[:space:]]*:[[:space:]]*[0-9]" && ' +
      '    echo "$out" | grep -qE "platforms[[:space:]]*:[[:space:]]*android"; then ' +
      '    echo RAI_READY; else echo RAI_NOT_READY; fi; ' +
      'else echo RAI_MISSING; fi';

    const r = await execute(`mkdir -p /root; ${ncsCheck}; ${raiCheck}`, '/');
    const out = r.output || '';
    if (/NCS_READY/.test(out)) {
      await execute(
        `mkdir -p ${shq(NCS_HOME)}; echo ok > ${shq(NCS_SETUP_MARKER)}; echo ok > ${shq(SETUP_MARKER)}; ` +
        `rm -f ${shq(SETUP_STEP_FILE)} ${shq(SETUP_STEP_DONE)}; echo ${shq(RAI_READY_SENTINEL)}`,
        '/',
      );
      return true;
    }
    if (/RAI_READY/.test(out)) {
      await execute(
        `echo ok > ${shq(SETUP_MARKER)}; rm -f ${shq(SETUP_STEP_FILE)} ${shq(SETUP_STEP_DONE)}; echo ${shq(RAI_READY_SENTINEL)}`,
        '/',
      );
      return true;
    }
    await execute(`rm -f ${shq(SETUP_MARKER)} ${shq(NCS_SETUP_MARKER)}; echo ${shq(RAI_NOT_READY_SENTINEL)}`, '/');
    return false;
  } catch {
    return false;
  }
};

export const getRaiSetupStatus = async (): Promise<string> => {
  try {
    const r = await execute(
      `if [ -f ${shq(NCS_SETUP_MARKER)} ] || [ -f ${shq(SETUP_MARKER)} ]; then echo DONE; exit 0; fi; ` +
      `if [ -f ${shq(SETUP_STEP_FILE)} ]; then echo "STEP:$(cat ${shq(SETUP_STEP_FILE)} 2>/dev/null)"; else echo NONE; fi`,
      '/',
    );
    const out = String(r.output || '').trim();
    if (out === 'DONE') return 'done';
    if (out.startsWith('STEP:')) return `step:${out.slice(5).trim()}`;
    return 'none';
  } catch {
    return 'none';
  }
};

export default {
  SETUP_STEPS: NCS_FAST_STEPS,
  NCS_FAST_STEPS,
  runRaiSetup,
  runRaiSetupPty,
  probeRaiReady,
  getRaiSetupStatus,
  parseRaiStatus,
  stepsFor,
  RAI_BUNDLE_DIR,
  RAI_BUNDLE,
  NCS_HOME,
  NCS_BIN,
  NCS_SDK,
  NCS_SETUP_MARKER,
  SETUP_MARKER,
  SETUP_STEP_FILE,
  ANDROID_HOME,
  ANDROID_HOME_RAI,
  ANDROID_HOME_NCS: NCS_SDK,
  RAI_VERSION,
};
