/**
 * Kotlin source -> Compose Studio component tree.
 *
 * The editor used to keep two parallel sources of truth: a JSON tree in
 * AsyncStorage and a Kotlin project in proot Ubuntu. The user got
 * `Добро пожаловать` even when rai had generated a different default
 * (counter app) because the JSON was being generated independently.
 *
 * This module closes the loop: when a project is created, we call
 * `rai new` first, then read the generated `MainActivity.kt` and
 * `ui/screens/*Screen.kt` files back from proot and turn them into
 * the same JSON model the editor already understands. The editor is
 * now a thin client on top of the rai workspace instead of a parallel
 * authoring tool.
 *
 * Only the subset of Compose the editor actually emits is parsed. If
 * the file contains something we cannot express (custom modifiers,
 * animated values, BoxWithConstraints, ...) we fall back to a Card
 * placeholder with the original Kotlin source as `text` so the user
 * still sees the content.
 */
import { execute } from './shellExecutor';
import { getSourceRoot } from '../config/runtime';

const COMPONENT_BY_KOTLIN = {
  Column: 'Column',
  Row: 'Row',
  Box: 'Box',
  LazyColumn: 'LazyColumn',
  Card: 'Card',
  Text: 'Text',
  Button: 'Button',
  OutlinedTextField: 'OutlinedTextField',
  Image: 'Image',
  Checkbox: 'Checkbox',
  Switch: 'Switch',
  LinearProgressIndicator: 'LinearProgressIndicator',
  CircularProgressIndicator: 'CircularProgressIndicator',
  HorizontalDivider: 'HorizontalDivider',
  Spacer: 'Spacer',
  Icon: 'Icon',
};

const stripQuotes = (value) => {
  if (typeof value !== 'string') return value;
  if (value.length < 2) return value;
  const first = value.charAt(0);
  const last = value.charAt(value.length - 1);
  if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
    return value.slice(1, -1).replace(/\\(["'\\])/g, '$1');
  }
  return value;
};

const splitTopLevelCommas = (input) => {
  const parts = [];
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  let buffer = '';
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const prev = i > 0 ? input[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = ch;
      buffer += ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    else if (ch === ',' && depth === 0 && brace === 0 && bracket === 0) {
      parts.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) parts.push(buffer.trim());
  return parts;
};

const parseNamedArgs = (raw) => {
  const args = {};
  const parts = splitTopLevelCommas(raw);
  for (const part of parts) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    args[key] = value;
  }
  return args;
};

const mapAlignment = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('centerhorizontally')) return 'center';
  if (lower.includes('centervertically')) return 'center';
  if (lower.includes('end') || lower.includes('right')) return 'end';
  if (lower.includes('bottom')) return 'bottom';
  return 'start';
};

const mapArrangement = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('spacebetween')) return 'spaceBetween';
  if (lower.includes('spacearound')) return 'spaceAround';
  if (lower.includes('spaceevenly')) return 'spaceEvenly';
  if (lower.includes('center')) return 'center';
  if (lower.includes('end') || lower.includes('bottom')) return 'end';
  return 'top';
};

const parseNumber = (value) => {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/-?\d+(\.\d+)?/);
  return match ? Number(match[0]) : undefined;
};

const parseSize = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('fillmaxwidth') || lower.includes('matchparent')) return 'match_parent';
  if (lower.includes('wrapcontent')) return 'wrap_content';
  const num = parseNumber(lower);
  if (num !== undefined) return num;
  return undefined;
};

const parseColor = (value) => {
  if (!value) return undefined;
  const match = value.match(/#?[0-9A-Fa-f]{6,8}/);
  return match ? match[0].startsWith('#') ? match[0] : `#${match[0]}` : undefined;
};

const parseModifierChain = (raw) => {
  // Modifier.fillMaxWidth().padding(8.dp).background(...)
  const out = { padding: 0, backgroundColor: undefined, borderRadius: undefined, width: undefined, height: undefined };
  if (!raw) return out;
  const lower = raw.replace(/\s+/g, '');
  const fill = /fillmax(width|height)/g;
  let m;
  while ((m = fill.exec(lower))) {
    if (m[1] === 'width') out.width = 'match_parent';
    else out.height = 'match_parent';
  }
  const padding = lower.match(/padding\(([0-9.]+)\.dp\)/);
  if (padding) out.padding = Number(padding[1]);
  const paddingHV = lower.match(/padding\(([a-zA-Z]+)\s*=\s*([0-9.]+)\.dp\s*,\s*[a-zA-Z]+\s*=\s*([0-9.]+)\.dp\)/);
  if (paddingHV) out.padding = Number(paddingHV[2]) + Number(paddingHV[3]);
  const bg = lower.match(/background\(([A-Za-z(0-9#]+)\)/);
  if (bg) out.backgroundColor = parseColor(bg[1]) || undefined;
  const radius = lower.match(/cliproundedcornershape\(([0-9.]+)\.dp\)/);
  if (radius) out.borderRadius = Number(radius[1]);
  const width = lower.match(/(?:^|[^a-z])width\(([0-9.]+)\.dp\)/);
  if (width && out.width === undefined) out.width = Number(width[1]);
  const height = lower.match(/(?:^|[^a-z])height\(([0-9.]+)\.dp\)/);
  if (height && out.height === undefined) out.height = Number(height[1]);
  return out;
};

const parseProps = (raw, kind) => {
  const named = parseNamedArgs(raw);
  const props = {};
  const modifier = parseModifierChain(named.modifier);
  Object.assign(props, modifier);
  if (named.text) props.text = stripQuotes(named.text);
  if (named.color) props.color = parseColor(named.color) || stripQuotes(named.color);
  if (named.backgroundcolor) props.backgroundColor = parseColor(named.backgroundcolor);
  if (named.textcolor) props.textColor = parseColor(named.textcolor);
  if (named.tint) props.tint = parseColor(named.tint);
  if (named.trackcolor) props.trackColor = parseColor(named.trackcolor);
  if (named.borderradius) props.borderRadius = parseNumber(named.borderradius);
  if (named.elevation) props.elevation = parseNumber(named.elevation);
  if (named.spacing) props.spacing = parseNumber(named.spacing);
  if (named.padding) props.padding = parseNumber(named.padding);
  if (named.size) props.size = parseNumber(named.size);
  if (named.progress) props.progress = parseNumber(named.progress);
  if (named.textsize) props.textSize = parseNumber(named.textsize);
  if (named.url) props.url = stripQuotes(named.url);
  if (named.hint) props.hint = stripQuotes(named.hint);
  if (named.label) props.label = stripQuotes(named.label);
  if (named.checked) props.checked = /true/i.test(named.checked);
  if (named.enabled) props.enabled = !/false/i.test(named.enabled);
  if (named.horizontalalignment) props.horizontalAlignment = mapAlignment(named.horizontalalignment);
  if (named.verticalalignment) props.verticalAlignment = mapAlignment(named.verticalalignment);
  if (named.verticalarrangement) props.verticalArrangement = mapArrangement(named.verticalarrangement);
  if (named.horizontalarrangement) props.horizontalArrangement = mapArrangement(named.horizontalarrangement);
  if (named.fontweight && /bold/i.test(named.fontweight)) props.textStyle = 'bold';
  if (named.textalign) {
    const t = named.textalign.toLowerCase();
    if (t.includes('center')) props.textAlign = 'center';
    else if (t.includes('end')) props.textAlign = 'end';
  }
  return props;
};

const splitBody = (source, openIndex, openChar, closeChar) => {
  let depth = 0;
  let inString = null;
  for (let i = openIndex; i < source.length; i++) {
    const ch = source[i];
    const prev = i > 0 ? source[i - 1] : '';
    if (inString) {
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = ch;
      continue;
    }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) return { body: source.slice(openIndex + 1, i), end: i };
    }
  }
  return { body: '', end: openIndex };
};

const findFunctionCall = (source, name) => {
  const regex = new RegExp(`\\b${name}\\s*\\(`, 'g');
  let match;
  while ((match = regex.exec(source))) {
    const openParen = match.index + match[0].length - 1;
    const parsed = splitBody(source, openParen, '(', ')');
    if (parsed.body) return { args: parsed.body, body: source };
  }
  return null;
};

const parseKotlinBody = (body) => {
  // body is the inside of e.g. Column(...) { ... }. We need both:
  //   1. The top-level argument list (everything before the trailing { ... }).
  //   2. The trailing lambda body (children).
  // Compose always puts the children lambda as the last argument, so the
  // outermost { ... } after the args list is what we parse for children.
  let depth = 0;
  let inString = null;
  let argEndIndex = -1;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    const prev = i > 0 ? body[i - 1] : '';
    if (inString) {
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{' && depth === 0) {
      argEndIndex = i;
      break;
    }
  }
  if (argEndIndex < 0) {
    return { args: body, children: [] };
  }
  const args = body.slice(0, argEndIndex).trim();
  let childrenBody = body.slice(argEndIndex + 1);
  // Trim trailing closing brace.
  if (childrenBody.endsWith('}')) childrenBody = childrenBody.slice(0, -1);
  const children = parseChildrenBlock(childrenBody);
  return { args, children };
};

const parseChildrenBlock = (block) => {
  const children = [];
  // Split into top-level statements separated by newlines that are not
  // inside parens/braces/brackets. Each statement is a Composable call.
  const statements = [];
  let buffer = '';
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  for (let i = 0; i < block.length; i++) {
    const ch = block[i];
    const prev = i > 0 ? block[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = ch;
      buffer += ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    if (ch === '\n' && depth === 0 && brace === 0 && bracket === 0) {
      if (buffer.trim()) statements.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) statements.push(buffer.trim());
  for (const stmt of statements) {
    const child = parseStatement(stmt);
    if (child) children.push(child);
  }
  return children;
};

const parseStatement = (stmt) => {
  // Each statement looks like `ComponentName(...) { ... }` or a comment.
  const commentIndex = stmt.indexOf('//');
  const cleaned = commentIndex >= 0 ? stmt.slice(0, commentIndex).trim() : stmt;
  if (!cleaned) return null;
  const match = cleaned.match(/^([A-Za-z][A-Za-z0-9_.]*)\s*\(/);
  if (!match) {
    // Could be a `if (...) ...` control flow. We can't model it in the
    // editor yet, so skip.
    return null;
  }
  const name = match[1].split('.').pop();
  if (name === 'item') {
    // LazyColumn { item { X } item { Y } } - parse the inner block.
    const { body, end } = splitBody(cleaned, match.index + match[0].length - 1, '(', ')');
    if (end >= 0) {
      const trailing = cleaned.slice(end + 1).trim();
      if (trailing.startsWith('{')) {
        const inner = splitBody(trailing, 0, '{', '}');
        const children = parseChildrenBlock(inner.body);
        if (children[0]) return children[0];
      }
    }
    return null;
  }
  if (name === 'Scaffold' || name === 'ColumnScope' || name === 'RowScope' || name === 'BoxScope') {
    // Scope markers - parse the trailing block.
    const openParen = match.index + match[0].length - 1;
    const parsed = splitBody(cleaned, openParen, '(', ')');
    if (parsed.end >= 0) {
      const trailing = cleaned.slice(parsed.end + 1).trim();
      if (trailing.startsWith('{')) {
        const inner = splitBody(trailing, 0, '{', '}');
        return { id: generateId(), type: name === 'Scaffold' ? 'Box' : name === 'ColumnScope' ? 'Column' : name === 'RowScope' ? 'Row' : 'Box', props: {}, children: parseChildrenBlock(inner.body) };
      }
    }
    return null;
  }
  const openParen = match.index + match[0].length - 1;
  const { args, children } = parseKotlinBody(cleaned.slice(openParen));
  const type = COMPONENT_BY_KOTLIN[name];
  if (!type) {
    // Unknown Composable - represent as a Text containing the original
    // expression so the user can see it.
    return {
      id: generateId(),
      type: 'Text',
      props: { text: cleaned },
      children: [],
    };
  }
  const props = parseProps(args, type);
  return {
    id: generateId(),
    type,
    props,
    children,
  };
};

const generateId = () => `node-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

/**
 * Read a single .kt file from the rai project and turn it into a tree
 * of Compose Studio nodes. Only the public @Composable function is
 * parsed; helper functions are ignored.
 */
export const parseKotlinScreen = (kotlinSource) => {
  if (!kotlinSource) return null;
  // Find the first top-level @Composable fun <Name>(...): { ... }
  const match = kotlinSource.match(/@Composable\s*(?:\n\s*@?[A-Za-z.]+\s*)*\n?\s*(?:private\s+|public\s+|internal\s+)?fun\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*\{/);
  if (!match) return null;
  const openBrace = match.index + match[0].length - 1;
  const parsed = splitBody(kotlinSource, openBrace, '{', '}');
  const statements = parseChildrenBlock(parsed.body);
  if (!statements.length) {
    return {
      id: generateId(),
      type: 'Column',
      props: { width: 'match_parent', height: 'match_parent' },
      children: [],
    };
  }
  // The first non-comment statement is the root.
  return statements[0] || null;
};

/**
 * Read all `ui/screens/*Screen.kt` files from the active rai project
 * and return a list of screens ready to drop into the project model.
 */
export const loadRaiProjectScreens = async (project) => {
  if (!project) return [];
  const sourceRoot = getSourceRoot(project);
  const result = await execute(`cat ${sourceRoot}/ui/screens/*Screen.kt 2>/dev/null || true`, project.projectDir);
  const text = result.output || '';
  // Split on the standard file separator we use in the generator. The
  // simplest reliable split is `// File: <Name>` since each generated
  // screen file starts with that comment.
  const files = text.split(/\/\/ File: /).filter(Boolean);
  if (!files.length) return [];
  const screens = [];
  for (let i = 0; i < files.length; i++) {
    const block = files[i];
    const nameMatch = block.match(/^([A-Za-z0-9_]+Screen)\.kt/);
    if (!nameMatch) continue;
    const fileName = nameMatch[1];
    const className = fileName.replace(/Screen$/, 'Screen');
    const tree = parseKotlinScreen(block);
    if (!tree) continue;
    const humanName = className.replace(/Screen$/, '').replace(/([A-Z])/g, ' $1').trim();
    screens.push({
      id: `screen-${i}`,
      name: humanName || className,
      route: i === 0 ? 'home' : `screen_${i + 1}`,
      orientation: 'portrait',
      backgroundColor: '#F8FAFC',
      showStatusBar: true,
      showActionBar: true,
      actionBarTitle: humanName || className,
      rootComponent: tree,
      blocks: [],
    });
  }
  return screens;
};

/**
 * Read MainActivity.kt and the Theme.kt to detect the project's
 * packageName, namespace and theme colors. Falls back to the values
 * already in the project model if the files cannot be parsed.
 */
export const readRaiProjectMetadata = async (project) => {
  if (!project) return project;
  const sourceRoot = getSourceRoot(project);
  const [manifest, theme] = await Promise.all([
    execute(`cat ${sourceRoot.replace(/app\/src\/main\/java.*/, '')}app/src/main/AndroidManifest.xml 2>/dev/null`, project.projectDir),
    execute(`cat ${sourceRoot}/ui/theme/Theme.kt 2>/dev/null`, project.projectDir),
  ]);
  const manifestText = manifest.output || '';
  const themeText = theme.output || '';
  const metadata = { ...project };
  const packageMatch = manifestText.match(/package\s*=\s*"([^"]+)"/);
  if (packageMatch) metadata.packageName = packageMatch[1];
  const namespaceMatch = manifestText.match(/xmlns:android="[^"]+"\s*package\s*=\s*"([^"]+)"/);
  if (namespaceMatch) metadata.namespace = namespaceMatch[1];
  const primaryMatch = themeText.match(/primary\s*=\s*color\("([^"]+)"\)/);
  if (primaryMatch) metadata.theme = { ...(metadata.theme || {}), primaryColor: primaryMatch[1] };
  const secondaryMatch = themeText.match(/secondary\s*=\s*color\("([^"]+)"\)/);
  if (secondaryMatch) metadata.theme = { ...(metadata.theme || {}), secondaryColor: secondaryMatch[1] };
  const darkMatch = themeText.match(/darkTheme:\s*Boolean\s*=\s*(true|false)/);
  if (darkMatch) metadata.theme = { ...(metadata.theme || {}), isDark: darkMatch[1] === 'true' };
  return metadata;
};
