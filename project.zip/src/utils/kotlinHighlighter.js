/**
 * Lightweight Kotlin syntax highlighter.
 *
 * Returns a flat array of spans: { text, color }. Used by the CodeEditor to
 * render a colorised overlay underneath an editable monospace TextInput.
 * The colour scheme is chosen to be legible on the dark editor background.
 */
const KEYWORDS = new Set([
  'val', 'var', 'fun', 'class', 'object', 'interface', 'enum', 'data', 'sealed',
  'abstract', 'open', 'final', 'override', 'private', 'protected', 'internal',
  'public', 'import', 'package', 'if', 'else', 'when', 'for', 'while', 'do',
  'return', 'break', 'continue', 'throw', 'try', 'catch', 'finally', 'is',
  'in', 'as', 'by', 'this', 'super', 'it', 'true', 'false', 'null', 'typealias',
  'companion', 'init', 'constructor', 'operator', 'infix', 'inline', 'suspend',
  'lateinit', 'const', 'out', 'vararg', 'reified', 'expect', 'actual', 'TODO',
]);

// VS Code Dark+ inspired palette for professional readability.
const COLORS = {
  keyword: '#C586C0',    // purple
  annotation: '#DCDCAA', // yellow
  string: '#CE9178',     // warm orange
  comment: '#6A9955',    // green
  number: '#B5CEA8',     // pale green
  type: '#4EC9B0',       // teal
  function: '#DCDCAA',   // yellow
  template: '#F48771',   // bright interpolation
  operator: '#D4D4D4',   // neutral
  plain: '#D4D4D4',      // default
};

// Standard Compose / Android types to colour as "types".
const KNOWN_TYPES = new Set([
  'Text', 'Column', 'Row', 'Box', 'LazyColumn', 'LazyRow', 'Scaffold', 'Button',
  'OutlinedButton', 'TextButton', 'IconButton', 'ElevatedCard', 'OutlinedCard',
  'Card', 'Surface', 'TopAppBar', 'OutlinedTextField', 'Checkbox', 'Switch',
  'Slider', 'LinearProgressIndicator', 'CircularProgressIndicator',
  'HorizontalDivider', 'VerticalDivider', 'Spacer', 'Icon', 'Image', 'InfoRow',
  'Modifier', 'Alignment', 'Arrangement', 'MaterialTheme', 'Typography',
  'Color', 'RoundedCornerShape', 'CardDefaults', 'ButtonDefaults',
  'FontWeight', 'TextAlign', 'remember', 'mutableStateOf', 'mutableIntStateOf',
  'mutableListOf', 'mutableMapOf', 'derivedStateOf', 'LaunchedEffect',
  'DisposableEffect', 'SideEffect', 'produceState', 'Icons', 'Intent',
  'Uri', 'Build', 'AppTheme', 'ComponentActivity', 'Bundle', 'setContent',
  'ColumnScope', 'RowScope', 'BoxScope',
]);

const isKeyword = (w) => KEYWORDS.has(w);
const isType = (w) => /^[A-Z]/.test(w) && KNOWN_TYPES.has(w);

/**
 * Tokenise Kotlin source into coloured spans.
 * @param {string} source
 * @returns {Array<{text:string, color:string}>}
 */
export const highlightKotlin = (source) => {
  if (!source) return [];
  const spans = [];
  let i = 0;
  const len = source.length;

  const push = (text, color) => {
    if (!text) return;
    spans.push({ text, color });
  };

  while (i < len) {
    const ch = source[i];
    const next = i + 1 < len ? source[i + 1] : '';

    // Line comment
    if (ch === '/' && next === '/') {
      let j = i + 2;
      while (j < len && source[j] !== '\n') j++;
      push(source.slice(i, j), COLORS.comment);
      i = j;
      continue;
    }
    // Block comment
    if (ch === '/' && next === '*') {
      let j = source.indexOf('*/', i + 2);
      j = j < 0 ? len : j + 2;
      push(source.slice(i, j), COLORS.comment);
      i = j;
      continue;
    }
    // String: triple-quoted
    if (ch === '"' && source.slice(i, i + 3) === '"""') {
      const j = source.indexOf('"""', i + 3);
      const end = j < 0 ? len : j + 3;
      push(source.slice(i, end), COLORS.string);
      i = end;
      continue;
    }
    // String: single or double quoted (with ${} interpolation as separate span)
    if (ch === '"' || ch === "'") {
      let j = i + 1;
      let buffer = ch;
      let interpolate = null;
      while (j < len) {
        const c = source[j];
        if (c === '\\') { buffer += c + (j + 1 < len ? source[j + 1] : ''); j += 2; continue; }
        if (c === ch) { buffer += c; j++; break; }
        if (c === '$' && j + 1 < len && source[j + 1] === '{') {
          // close the current string chunk
          push(buffer, COLORS.string);
          buffer = '';
          interpolate = j;
          break;
        }
        buffer += c;
        j++;
      }
      if (interpolate != null) {
        // find matching brace
        let depth = 0;
        let k = interpolate + 1;
        while (k < len) {
          if (source[k] === '{') depth++;
          else if (source[k] === '}') { depth--; if (depth === 0) break; }
          k++;
        }
        push(source.slice(interpolate, k + 1), COLORS.template);
        // continue parsing the rest of the string from k+1
        i = k + 1;
        continue;
      }
      push(buffer, COLORS.string);
      i = j;
      continue;
    }
    // Number
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(next))) {
      let j = i;
      while (j < len && /[0-9._fFLlUuXxAaBbCcDdEe]/.test(source[j])) j++;
      push(source.slice(i, j), COLORS.number);
      i = j;
      continue;
    }
    // Identifier / keyword / type / annotation
    if (/[A-Za-z_]/.test(ch)) {
      let j = i;
      while (j < len && /[A-Za-z0-9_]/.test(source[j])) j++;
      const word = source.slice(i, j);
      // annotation @Word
      if (i > 0 && source[i - 1] === '@') {
        push(word, COLORS.annotation);
      } else if (isKeyword(word)) {
        push(word, COLORS.keyword);
      } else if (isType(word)) {
        push(word, COLORS.type);
      } else {
        // function call: word immediately followed by (
        let k = j;
        while (k < len && /\s/.test(source[k])) k++;
        if (k < len && source[k] === '(') {
          push(word, COLORS.function);
        } else {
          push(word, COLORS.plain);
        }
      }
      i = j;
      continue;
    }
    // Annotation start
    if (ch === '@') {
      push(ch, COLORS.annotation);
      i++;
      continue;
    }
    // Operators
    if ('+-*/%<>=!&|^~?:;,.()[]{}'.includes(ch)) {
      push(ch, COLORS.operator);
      i++;
      continue;
    }
    // Everything else (whitespace etc.)
    push(ch, COLORS.plain);
    i++;
  }
  return spans;
};

export default highlightKotlin;
