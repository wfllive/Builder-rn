import { execute } from './shellExecutor';
const quote = (v = '') => `'${String(v).replace(/'/g, `'\"'\"'`)}'`;
export const raiCommand = (args = []) => ['rai', ...args.map(quote)].join(' ');
// Rai owns project creation and chooses the canonical project directory.
export const raiNew = (name, id) => execute(raiCommand(['new', name, id, '--modern']));
export const raiBuild = (name, variant, cwd) => execute(raiCommand(['build', name, ...(variant ? [variant] : [])]), cwd);
export const raiKeystore = (name, cwd) => execute(raiCommand(['keystore', 'create', name]), cwd);

/**
 * Run the Layoutlib-based preview pipeline exposed by rai. The current
 * implementation in the editor uses the on-device native renderer (real
 * Android Views) for instant previews, while this command is the bridge
 * to the rai side that will eventually use the same Android Studio
 * Layoutlib engine to produce pixel-identical @Preview output inside
 * the proot Ubuntu environment.
 */
export const raiPreview = (name, options = {}) => {
  const args = ['preview', name];
  if (options.screen) args.push('--screen', String(options.screen));
  if (options.widthDp) args.push('--width', String(options.widthDp));
  if (options.heightDp) args.push('--height', String(options.heightDp));
  if (options.out) args.push('--out', String(options.out));
  return execute(raiCommand(args), options.cwd);
};
