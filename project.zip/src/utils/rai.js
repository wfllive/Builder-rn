/** Rai CLI integration. All commands run inside the installed proot rootfs. */
import { execute } from './shellExecutor';

const quote = (value = '') => `'${String(value).replace(/'/g, `'"'"'`)}'`;

export const runRai = async (args = [], workDir) => {
  const command = ['rai', ...args.map(quote)].join(' ');
  return execute(command, workDir);
};

export const raiVersion = () => runRai(['--version']);
export const raiStatus = () => runRai(['status']);
export const raiUpdate = () => runRai(['update']);
export const raiInstallBase = () => runRai(['install', 'base']);
export const raiInstallSdk = () => runRai(['install', 'sdk']);
export const raiNew = (name, applicationId, options = ['--modern']) =>
  runRai(['new', name, applicationId, ...options]);
export const raiBuild = (name, variant) =>
  runRai(['build', name, ...(variant ? [variant] : [])]);
export const raiCreateKeystore = (name) => runRai(['keystore', 'create', name]);

export const inspectRai = async () => {
  const result = await execute(`
set +e
printf 'rai='; command -v rai || true
printf 'version='; rai --version 2>&1 | head -1
printf 'java='; java -version 2>&1 | head -1
printf 'sdkmanager='; command -v sdkmanager || true
printf 'adb='; command -v adb || true
`);
  return { success: result.success, output: result.output || '' };
};

export default { runRai, raiVersion, raiStatus, raiUpdate, raiInstallBase, raiInstallSdk, raiNew, raiBuild, raiCreateKeystore, inspectRai };
