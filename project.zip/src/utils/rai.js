import { execute } from './shellExecutor';
import { syncComposeProject } from './composeProject';

const quote = (v = '') => `'${String(v).replace(/'/g, `'\"'\"'`)}'`;
export const raiCommand = (args = []) => ['rai', ...args.map(quote)].join(' ');
// Rai owns project creation and chooses the canonical project directory.
export const raiNew = (name, id) => execute(raiCommand(['new', name, id, '--modern']));
export const raiKeystore = (name, cwd) => execute(raiCommand(['keystore', 'create', name]), cwd);

/**
 * Build a project through rai.
 *
 * Order matters: the editor's component tree is the source of truth. Before
 * Gradle compiles anything, the Kotlin sources for the active screen(s) must
 * be written into the Rai project directory (`app/src/main/java/.../ui/screens/*.kt`).
 * Otherwise rai would compile the placeholder "counter" template that `rai new`
 * created and the user would install the wrong APK.
 *
 * `rai build` itself only triggers Gradle, so we sync the model first and then
 * delegate to rai. The stdout streams back as a single `output` string; callers
 * split on newlines when they want line-by-line logs.
 */
export const raiBuild = async (project, variant, cwd) => {
  if (!project) return { success: false, output: 'No project' };
  const projectDir = cwd || project.projectDir;
  if (!projectDir) return { success: false, output: 'Project directory is unknown' };

  // 1. Make sure the project exists in proot Ubuntu. If rai new was never
  //    called (e.g. project metadata was restored from a backup), create it
  //    now so the next `rai build` has a real Gradle wrapper to run.
  const exists = await execute(`[ -d ${quote(projectDir)} ] && printf ok || printf missing`, projectDir);
  if (!/ok/i.test(exists.output || '')) {
    const raiResult = await raiNew(project.name, project.packageName || `com.rnstudio.${project.name.toLowerCase()}`);
    if (!raiResult?.success) {
      return {
        success: false,
        output: `rai new ${project.name} failed:\n${raiResult?.output || 'unknown error'}`,
      };
    }
  }

  // 2. Sync the editor's component tree to Kotlin sources inside the project.
  //    This is the step that was missing: without it `rai build` would compile
  //    the rai new template and the user would see the placeholder screen.
  const sync = await syncComposeProject(project);
  if (!sync?.success) {
    return {
      success: false,
      output: `Compose source sync failed:\n${sync?.output || 'unknown error'}`,
    };
  }

  // 3. Hand off to rai for the actual Gradle build.
  const variantArg = variant ? ` ${variant}` : '';
  const result = await execute(raiCommand(['build', project.name, ...(variant ? [variant] : [])]), projectDir);
  if (!result?.success) {
    return {
      success: false,
      output: result?.output || 'rai build failed',
    };
  }
  return {
    success: true,
    output: `${sync.output}\n${result.output || ''}`,
  };
};

/**
 * Run the Layoutlib-based preview pipeline exposed by rai. The current
 * implementation in the editor uses the on-device native renderer (real
 * Android Views) for instant previews, while this command is the bridge
 * to the rai side that will eventually use the same Android Studio
 * Layoutlib engine to produce pixel-identical @Preview output inside
 * the proot Ubuntu environment.
 */
export const raiPreview = (name, options = {}) => {
  const args = ['preview', name];
  if (options.screen) args.push('--screen', String(options.screen));
  if (options.widthDp) args.push('--width', String(options.widthDp));
  if (options.heightDp) args.push('--height', String(options.heightDp));
  if (options.out) args.push('--out', String(options.out));
  return execute(raiCommand(args), options.cwd);
};
