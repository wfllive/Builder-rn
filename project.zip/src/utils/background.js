/**
 * background.js — foreground-service helper.
 *
 * Пока идёт установка среды или сборка APK, приложение держит foreground
 * service (нативное уведомление «NovaCompose Studio — …») + wakelock, чтобы
 * Android не убивал процесс, когда пользователь свернул приложение или
 * заблокировал экран. На web/iOS — безопасный no-op.
 */
import { Platform } from 'react-native';
import * as apt from '../../modules/apt-manager/src/index';

const enabled = Platform.OS === 'android' && apt.isAvailable();

export const startBackground = async (label) => {
  if (!enabled) return { success: false };
  try {
    return await apt.startBackgroundService(label);
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

export const updateBackground = async (label) => {
  if (!enabled) return { success: false };
  try {
    return await apt.updateBackgroundService(label);
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

export const stopBackground = async () => {
  if (!enabled) return { success: false };
  try {
    return await apt.stopBackgroundService();
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

// Shared storage («память»)
export const hasStorageAccess = async () => {
  if (!enabled) return false;
  try {
    return Boolean(await apt.hasAllFilesAccess());
  } catch (e) {
    return false;
  }
};

export const openStorageSettings = async () => {
  if (!enabled) return { success: false, output: 'Not available' };
  try {
    return await apt.openAllFilesAccessSettings();
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

export const requestStoragePermissions = async () => {
  if (!enabled) return { success: false, output: 'Not available' };
  try {
    return await apt.requestStoragePermissions();
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

export const hasNotificationPermission = async () => {
  if (!enabled) return true;
  try {
    const r = await apt.hasNotificationsPermission();
    return r?.granted !== false;
  } catch (e) {
    return true;
  }
};

export const requestNotificationPermission = async () => {
  if (!enabled) return { success: false };
  try {
    return await apt.requestNotificationsPermission();
  } catch (e) {
    return { success: false, output: String(e) };
  }
};

export default {
  startBackground, updateBackground, stopBackground,
  hasStorageAccess, openStorageSettings, requestStoragePermissions,
  hasNotificationPermission, requestNotificationPermission,
};
