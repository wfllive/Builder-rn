/**
 * Instant, offline Kotlin / Jetpack Compose source analyzer.
 *
 * Runs on every keystroke (debounced) and produces VS Code style problems:
 *   { line, col, message, severity, code }
 *
 * severity: 'error'    — the code cannot compile. Structural problems plus
 *                        deterministic semantic checks (type mismatch on
 *                        literals, val reassignment, duplicate declarations).
 *                        Zero false-positives tolerated.
 *           'warning'  — Compose best-practice / likely-mistake heuristics
 *                        (composable context, remember(), deprecations,
 *                        typo hints, unknown named parameters, missing imports)
 *
 * This is NOT a compiler: there is no classpath resolution, so identifier
 * checks are deliberately conservative — an unknown symbol is only reported
 * when it closely matches a well-known Compose/Android symbol (typo hint),
 * and named-argument checks apply only to curated Compose components.
 *
 * For real compiler errors the IDE runs `gradlew compileDebugKotlin`
 * (EditorScreen.runCompilerCheck) — this analyzer is the instant layer.
 */

import { KNOWN_IMPORTS } from './importManager';

/* --------------------------------------------------------------- knowns */

// Well-known Compose / Android symbols with their "kind":
//   composable — a @Composable function (needs @Composable calling context)
//   symbol     — a class/object/type (no context requirement)
//   unit       — lowercase helper (remember, dp, fillMaxWidth…)
const EXTRA_KNOWN = {
  LazyColumn: 'composable', LazyRow: 'composable', LazyVerticalGrid: 'composable',
  items: 'unit', item: 'unit',
  Image: 'composable', Icon: 'composable', NavigationBar: 'composable',
  NavigationBarItem: 'composable', NavigationRail: 'composable',
  FloatingActionButton: 'composable', SnackbarHost: 'composable',
  AlertDialog: 'composable', BasicAlertDialog: 'composable',
  BottomSheetScaffold: 'composable', ModalBottomSheet: 'composable',
  CenterAlignedTopAppBar: 'composable', MediumTopAppBar: 'composable',
  LargeTopAppBar: 'composable', DropdownMenu: 'composable', DropdownMenuItem: 'composable',
  RadioButton: 'composable', RangeSlider: 'composable', TextField: 'composable',
  rememberSaveable: 'unit', rememberCoroutineScope: 'unit',
  rememberScrollState: 'unit', rememberLazyListState: 'unit',
  verticalScroll: 'unit', horizontalScroll: 'unit', clickable: 'unit',
  background: 'unit', border: 'unit', clip: 'unit', offset: 'unit',
  weight: 'unit', animateColorAsState: 'unit', rememberInfiniteTransition: 'unit',
  stringResource: 'unit', painterResource: 'unit', collectAsState: 'unit',
  NavHost: 'composable', composable: 'unit', rememberNavController: 'unit',
  LocalContext: 'symbol', LocalDensity: 'symbol', LocalConfiguration: 'symbol',
  Context: 'symbol', Toast: 'symbol', Intent: 'symbol', Uri: 'symbol',
  Build: 'symbol', Bundle: 'symbol', ComponentActivity: 'symbol',
  AppCompatActivity: 'symbol', ViewModel: 'symbol', State: 'symbol',
  PaddingValues: 'symbol', Dp: 'symbol', TextUnit: 'symbol',
  Brush: 'symbol', Shape: 'symbol', TextStyle: 'symbol', FontFamily: 'symbol',
  FontStyle: 'symbol', TextOverflow: 'symbol', KeyboardOptions: 'symbol',
  KeyboardType: 'symbol', ImeAction: 'symbol', VisualTransformation: 'symbol',
  PasswordVisualTransformation: 'symbol', FocusRequester: 'symbol',
  MutableState: 'symbol', SnapshotStateList: 'symbol', CoroutineScope: 'symbol',
  Unit: 'symbol', String: 'symbol', Int: 'symbol', Long: 'symbol',
  Boolean: 'symbol', Double: 'symbol', Float: 'symbol', List: 'symbol',
  MutableList: 'symbol', Map: 'symbol', Set: 'symbol', Any: 'symbol',
  R: 'symbol', BuildConfig: 'symbol', Color: 'symbol',
};

// Calls whose trailing/content lambda is itself a @Composable scope.
const COMPOSABLE_SCOPE_CALLS = new Set(['setContent']);

// @Composable calls whose content lambda is NOT a composable scope: effect
// APIs take suspend/plain callbacks, so composable invocations inside them
// are a compile error ("@Composable invocations can only happen from the
// context of a @Composable function") — the most common Compose mistake.
// The second group are event-callback parameters (onClick = { … }): plain
// `() -> Unit` callbacks that close the composable context. Content-style
// slots (content/title/icon/…) stay composable and must NOT be listed here.
const NON_COMPOSABLE_LAMBDA_CALLS = new Set([
  'LaunchedEffect', 'DisposableEffect', 'produceState', 'SideEffect',
  'remember', 'rememberSaveable', 'derivedStateOf',
  'onClick', 'onLongClick', 'onValueChange', 'onCheckedChange',
  'onValueChangeFinished', 'onDismissRequest', 'onTextLayout', 'onDispose',
  'onConfirm', 'onSearch', 'onSend', 'onDone', 'onGo', 'onNext',
]);

// Snapshot-state factories that must be wrapped in remember { } during
// composition (official lint: UnrememberedMutableState). Deliberately NOT
// include produceState / collectAsState / *AsState — those are composable
// and manage remembering themselves.
const STATE_CREATORS = new Set([
  'mutableStateOf', 'mutableStateListOf', 'mutableStateMapOf',
  'mutableIntStateOf', 'mutableLongStateOf', 'mutableFloatStateOf',
  'mutableDoubleStateOf', 'derivedStateOf',
]);

const KNOWN = {};
Object.keys(KNOWN_IMPORTS).forEach((name) => {
  const pkg = KNOWN_IMPORTS[name];
  KNOWN[name] = pkg.startsWith('androidx.compose') && /^[A-Z]/.test(name) ? 'composable' : 'unit';
});
Object.entries(EXTRA_KNOWN).forEach(([name, kind]) => { KNOWN[name] = kind; });
// Classes/objects — construction or static access, NOT composables.
['Modifier', 'Alignment', 'Arrangement', 'Color', 'FontWeight', 'TextAlign',
  'RoundedCornerShape', 'MaterialTheme', 'Typography', 'ButtonDefaults',
  'CardDefaults', 'Icons', 'Toast', 'Intent', 'Uri', 'Build', 'Bundle',
  'ComponentActivity', 'AppCompatActivity', 'ViewModel', 'State',
  'PaddingValues', 'Dp', 'TextUnit', 'Brush', 'Shape', 'TextStyle',
  'Unit', 'String', 'Int', 'Long', 'Boolean', 'Double', 'Float', 'List',
  'MutableList', 'Map', 'Set', 'Any', 'R', 'BuildConfig', 'Context',
  'LocalContext', 'LocalDensity', 'LocalConfiguration', 'MutableState',
  'SnapshotStateList', 'CoroutineScope', 'FontFamily', 'FontStyle',
  'TextOverflow', 'KeyboardOptions', 'KeyboardType', 'ImeAction',
  'VisualTransformation', 'PasswordVisualTransformation', 'FocusRequester',
].forEach((n) => { KNOWN[n] = 'symbol'; });

const KNOWN_PASCAL = Object.keys(KNOWN).filter((n) => /^[A-Z]/.test(n) && KNOWN[n] !== 'unit');

const DEPRECATED = {
  Divider: 'Divider is deprecated — use HorizontalDivider (Material 3)',
};

const COMPOSE_ANNOTATIONS = new Set(['Composable', 'Preview']);
const CONTROL_WORDS = new Set(['if', 'else', 'for', 'while', 'when', 'do']);

/* ------------------------------------ named-parameter tables (Material 3) */

// Union-of-overloads named parameters for the most-used Compose components.
// A named argument that is not in the list is a guaranteed compiler error
// ("Cannot find a parameter with this name"), emitted as a warning because a
// same-name local function could theoretically shadow the component — the
// localDecl guard below covers the same-file case.
const NAMED_PARAMS = {};
const addParams = (names, params) => {
  const set = new Set(params.split(' '));
  names.forEach((n) => { NAMED_PARAMS[n] = set; });
};
const TEXT_STYLE_PARAMS = 'modifier color fontSize fontStyle fontWeight fontFamily letterSpacing textDecoration textAlign lineHeight overflow softWrap maxLines minLines onTextLayout style';
const CLICKABLE_CONTENT = 'onClick modifier enabled shape colors elevation border contentPadding interactionSource content';
addParams(['Column'], 'modifier verticalArrangement horizontalAlignment content');
addParams(['Row'], 'modifier horizontalArrangement verticalAlignment content');
addParams(['Box'], 'modifier contentAlignment propagateMinConstraints content');
addParams(['Text'], `text ${TEXT_STYLE_PARAMS} inlineContent`);
addParams(['Button', 'OutlinedButton', 'TextButton'], CLICKABLE_CONTENT);
addParams(['IconButton'], 'onClick modifier enabled colors interactionSource content');
addParams(['Scaffold'], 'modifier topBar bottomBar snackbarHost floatingActionButton floatingActionButtonPosition containerColor contentColor contentWindowInsets content');
addParams(['Card', 'ElevatedCard', 'OutlinedCard'], 'onClick modifier enabled shape colors elevation border interactionSource content');
addParams(['Surface'], 'onClick modifier enabled shape color contentColor tonalElevation shadowElevation border interactionSource content');
addParams(['LazyColumn'], 'modifier state contentPadding reverseLayout verticalArrangement horizontalAlignment flingBehavior userScrollEnabled content');
addParams(['LazyRow'], 'modifier state contentPadding reverseLayout horizontalArrangement verticalAlignment flingBehavior userScrollEnabled content');
addParams(['LazyVerticalGrid'], 'modifier state contentPadding reverseLayout verticalArrangement horizontalArrangement flingBehavior userScrollEnabled content columns');
addParams(['Spacer'], 'modifier');
addParams(['Image'], 'painter bitmap contentDescription modifier alignment contentScale alpha colorFilter filterQuality');
addParams(['Icon'], 'imageVector painter bitmap contentDescription modifier tint');
addParams(['TextField', 'OutlinedTextField'], 'value onValueChange modifier enabled readOnly textStyle label placeholder leadingIcon trailingIcon prefix suffix supportingText isError visualTransformation keyboardOptions keyboardActions singleLine maxLines minLines interactionSource shape colors');
addParams(['TopAppBar', 'CenterAlignedTopAppBar', 'MediumTopAppBar', 'LargeTopAppBar'], 'title modifier navigationIcon actions expandedHeight collapsedHeight windowInsets colors scrollBehavior');
addParams(['Checkbox'], 'checked onCheckedChange modifier enabled colors interactionSource');
addParams(['Switch'], 'checked onCheckedChange modifier enabled thumbContent colors interactionSource');
addParams(['Slider'], 'value onValueChange modifier enabled valueRange steps onValueChangeFinished colors interactionSource thumb track');
addParams(['AlertDialog', 'BasicAlertDialog'], 'onDismissRequest confirmButton dismissButton modifier icon title text shape containerColor iconContentColor titleContentColor textContentColor tonalElevation properties content');
addParams(['FloatingActionButton'], 'onClick modifier shape containerColor contentColor elevation interactionSource content');
addParams(['size'], 'width height size');

/* --------------------------------------------------- edit distance (DL) */

const damerau = (a, b, maxDist) => {
  const al = a.length;
  const bl = b.length;
  if (Math.abs(al - bl) > maxDist) return maxDist + 1;
  const prev = Array.from({ length: bl + 1 }, (_, i) => i);
  const curr = new Array(bl + 1);
  const prev2 = new Array(bl + 1);
  for (let i = 1; i <= al; i++) {
    curr[0] = i;
    let rowMin = curr[0];
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let v = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        v = Math.min(v, prev2[j - 2] + cost);
      }
      curr[j] = v;
      rowMin = Math.min(rowMin, v);
    }
    if (rowMin > maxDist) return maxDist + 1;
    for (let j = 0; j <= bl; j++) { prev2[j] = prev[j]; prev[j] = curr[j]; }
  }
  return prev[bl];
};

/* ------------------------------------------------------------- masking */

/**
 * Replace strings and comments with spaces (positions preserved), so later
 * phases never match inside literals. Returns { masked, lexProblems, literals }
 * where lexProblems are hard ERRORS (unbalanced brackets, unclosed
 * strings/comments) and literals records every quoted literal
 * { line, col, kind: 'string'|'char'|'triple', chars } — chars is the logical
 * character count of the literal content (escapes count once), used to
 * validate character literals and literal type mismatches.
 */
const maskSource = (source) => {
  const out = source.split('');
  const problems = [];
  const literals = [];
  const stack = [];
  const pairs = { ')': '(', ']': '[', '}': '{' };
  const closers = { '(': ')', '[': ']', '{': '}' };
  let line = 1;
  let col = 1;
  const adv = (ch) => { if (ch === '\n') { line++; col = 1; } else col++; };
  const blank = (i) => { if (out[i] !== '\n') out[i] = ' '; };

  let i = 0;
  const len = source.length;
  while (i < len) {
    const ch = source[i];
    const n2 = source[i + 1];
    if (ch === '/' && n2 === '/') {
      while (i < len && source[i] !== '\n') { blank(i); adv(source[i]); i++; }
      continue;
    }
    if (ch === '/' && n2 === '*') {
      const startLine = line;
      const startCol = col;
      blank(i); adv(ch); blank(i + 1); adv(n2);
      i += 2;
      let closed = false;
      while (i < len) {
        if (source[i] === '*' && source[i + 1] === '/') {
          blank(i); adv('*'); blank(i + 1); adv('/');
          i += 2; closed = true; break;
        }
        blank(i); adv(source[i]); i++;
      }
      if (!closed) problems.push({ line: startLine, col: startCol, severity: 'error', code: 'unclosed-comment', message: 'Unclosed block comment "/*"' });
      continue;
    }
    if (ch === '"' && source[i + 1] === '"' && source[i + 2] === '"') {
      const startLine = line;
      const startCol = col;
      blank(i); adv('"'); blank(i + 1); adv('"'); blank(i + 2); adv('"');
      i += 3;
      let chars = 0;
      let closed = false;
      while (i < len) {
        if (source[i] === '"' && source[i + 1] === '"' && source[i + 2] === '"') {
          blank(i); adv('"'); blank(i + 1); adv('"'); blank(i + 2); adv('"');
          i += 3; closed = true; break;
        }
        chars++;
        blank(i); adv(source[i]); i++;
      }
      literals.push({ line: startLine, col: startCol, endLine: line, endCol: col, kind: 'triple', chars });
      if (!closed) problems.push({ line: startLine, col: startCol, severity: 'error', code: 'unclosed-string', message: 'Unclosed triple-quoted string """' });
      continue;
    }
    if (ch === '"' || ch === "'") {
      const quote = ch;
      const startLine = line;
      const startCol = col;
      blank(i); adv(ch); i++;
      let chars = 0;
      let closed = false;
      while (i < len) {
        if (source[i] === '\\') {
          chars++;
          blank(i); adv(source[i]); if (i + 1 < len) { blank(i + 1); adv(source[i + 1]); } i += 2; continue;
        }
        if (source[i] === quote) { blank(i); adv(quote); i++; closed = true; break; }
        if (source[i] === '\n') break;
        chars++;
        blank(i); adv(source[i]); i++;
      }
      literals.push({ line: startLine, col: startCol, endLine: line, endCol: col, kind: quote === "'" ? 'char' : 'string', chars });
      if (!closed) problems.push({ line: startLine, col: startCol, severity: 'error', code: 'unclosed-string', message: `Unclosed string literal ${quote}` });
      continue;
    }
    if (ch === '(' || ch === '[' || ch === '{') stack.push({ char: ch, line, col });
    else if (ch === ')' || ch === ']' || ch === '}') {
      const open = stack.pop();
      if (!open) {
        problems.push({ line, col, severity: 'error', code: 'bracket', message: `Unexpected '${ch}' — no matching opening bracket` });
      } else if (open.char !== pairs[ch]) {
        problems.push({
          line, col, severity: 'error', code: 'bracket',
          message: `Mismatched '${ch}' — '${open.char}' opened at ${open.line}:${open.col} expects '${closers[open.char]}'`,
        });
      }
    }
    adv(ch);
    i++;
  }
  for (const open of stack) {
    problems.push({
      line: open.line, col: open.col, severity: 'error', code: 'bracket',
      message: `Unclosed '${open.char}' — add the matching '${closers[open.char]}'`,
    });
  }
  return { masked: out.join(''), lexProblems: problems, literals };
};

/* ------------------------------------------------- declaration checks */

const MODS = '(?:public|private|internal|protected|open|final|abstract|override|suspend|operator|infix|inline|data|sealed|enum|companion|const|lateinit|tailrec|external|inner|value|annotation|expect|actual)\\s+';
const DECL_PATTERNS = [
  { re: new RegExp(`^\\s*(?:${MODS})*fun\\s*$`), msg: "'fun' needs a name and parameter list, e.g. fun main() { }" },
  { re: new RegExp(`^\\s*(?:${MODS})*(?:val|var)\\s*$`), msg: "'val/var' declaration is missing a name" },
  { re: new RegExp(`^\\s*(?:${MODS})*(?:class|object|interface)\\s*$`), msg: 'Declaration is missing a name (class/object/interface)' },
  { re: /^\s*import\s*$/, msg: "'import' is missing a qualified name" },
];

const checkDeclarations = (maskedLines, problems) => {
  maskedLines.forEach((lineText, idx) => {
    for (const { re, msg } of DECL_PATTERNS) {
      if (re.test(lineText)) {
        const col = lineText.length - lineText.trimStart().length + 1;
        problems.push({ line: idx + 1, col, severity: 'error', code: 'decl', message: msg });
        break;
      }
    }
  });
};

/* ----------------------------------------------- type-literal checking */

// `val x: Int = <literal>` — Kotlin never implicitly converts, so a literal
// of the wrong kind is a guaranteed compiler error. Only single-token values
// (optionally closed by a semicolon) are judged; anything compound is skipped.
const DECL_TYPE_RE = /^\s*(?:(?:public|private|internal|protected|const|lateinit|override|open|final)\s+)*(?:val|var)\s+[A-Za-z_]\w*\s*:\s*(Int|Long|Short|Byte|Double|Float|String|Boolean|Char)\s*=/;
const INT_TOKEN = /^-?(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*)$/;
const LONG_TOKEN = /^-?\d[\d_]*[lL]$/;
const DEC_TOKEN = /^-?\d[\d_]*\.\d[\d_]*(?:[eE][+-]?\d+)?[fFdD]?$/;
const EXP_TOKEN = /^-?\d[\d_]*(?:\.\d[\d_]*)?[eE][+-]?\d+[fFdD]?$/;
const BOOL_TOKEN = /^(?:true|false)$/;

const literalTypeOf = (token) => {
  if (BOOL_TOKEN.test(token)) return 'Boolean';
  if (LONG_TOKEN.test(token)) return 'Long';
  if (INT_TOKEN.test(token)) return 'Int';
  if (DEC_TOKEN.test(token) || EXP_TOKEN.test(token)) return /[fF]$/.test(token) ? 'Float' : 'Double';
  return null;
};

const analyzeTypeLiterals = (masked, literals, problems) => {
  const byLine = new Map();
  literals.forEach((l) => {
    if (!byLine.has(l.line)) byLine.set(l.line, []);
    byLine.get(l.line).push(l);
  });
  const mlines = masked.split('\n');
  mlines.forEach((lineText, idx) => {
    const m = lineText.match(DECL_TYPE_RE);
    if (!m) return;
    const declType = m[1];
    const ln = idx + 1;
    const rhsStart = m[0].length; // 0-based column where the value starts
    const report = (message) => problems.push({
      line: ln, col: rhsStart + 1, severity: 'error', code: 'type-mismatch', message,
    });
    // A quoted literal that IS the value, possibly after some spaces. Its
    // content was masked to spaces, so it cannot be found by regex — match
    // by position: the first literal whose start is reachable from '='
    // through whitespace only.
    const lit = (byLine.get(ln) || [])
      .filter((l) => l.col - 1 >= rhsStart)
      .sort((a, b) => a.col - b.col)
      .find((l) => /^\s*$/.test(lineText.slice(rhsStart, l.col - 1)));
    if (lit) {
      // Only judge when the literal IS the whole value — `"x".length` and
      // `"a" + b` are compound expressions with a different resulting type.
      const tail = (mlines[lit.endLine - 1] || '').slice(lit.endCol - 1).trim().replace(/;+\s*$/, '').trim();
      if (tail !== '') return;
      const isStr = lit.kind !== 'char';
      if (isStr && declType !== 'String') {
        report(`Type mismatch — a String literal cannot be assigned to '${declType}'`);
      } else if (!isStr && declType !== 'Char') {
        report(`Type mismatch — a Char literal cannot be assigned to '${declType}'`);
      } else if (!isStr && lit.chars !== 1) {
        report(lit.chars === 0
          ? "Empty character literal '' — a Char must contain exactly one character"
          : `Too many characters in a character literal ('…' holds ${lit.chars}) — a Char needs exactly one`);
      }
      return;
    }
    const token = lineText.slice(rhsStart).trim().replace(/;+\s*$/, '');
    if (!token) return;
    const litType = literalTypeOf(token);
    if (!litType) return;
    const mismatches =
      (declType === 'Int' || declType === 'Short' || declType === 'Byte') ? litType !== 'Int'
        : declType === 'Long' ? litType !== 'Int' && litType !== 'Long'
          : declType === 'Double' ? litType !== 'Double'
            : declType === 'Float' ? litType !== 'Float'
              : declType === 'Boolean' ? litType !== 'Boolean'
                : true; // String / Char can never take a bare numeric or boolean token
    if (mismatches) report(`Type mismatch — a ${litType} value cannot be assigned to '${declType}'`);
  });
};

/* -------------------------------------------- scope-aware Compose rules */

/**
 * Walk the masked source keeping:
 *   braceStack — { kind, composable, control, symbols }
 *     kind: 'fun' | 'lambda' | 'control' | 'plain' | 'root'
 *     composable: @Composable calls are allowed inside
 *     control: if/for/while/when block (remember() is forbidden inside)
 *     symbols: val/var declarations visible in this frame (reassignment and
 *              duplicate-declaration checks)
 *   parenStack — { callee, braceBase, isFunHeader, params } of open '(' calls,
 *     so trailing lambdas of known composables (Column(...) {) open
 *     @Composable scopes, fun headers donate their parameters, and named
 *     arguments can be validated against NAMED_PARAMS.
 */
const analyzeComposeScopes = (masked, problems) => {
  const lines = masked.split('\n');

  // Pre-pass: names declared / imported, and project-local @Composable funs.
  const localComposable = new Set();
  const localDecl = new Set(); // fun/class/object names — disables curated checks on shadows
  lines.forEach((lineText, idx) => {
    let dm = lineText.match(/\bfun\s*(?:<[^>]+>\s*)?(?:[\w.]+\.)?(\w+)/);
    if (dm) localDecl.add(dm[1]);
    dm = lineText.match(/\b(?:class|object|interface|typealias)\s+(\w+)/);
    if (dm) localDecl.add(dm[1]);
    if (!/\bfun\b/.test(lineText)) return;
    const anns = [];
    for (let j = idx; j >= 0 && j >= idx - 3; j--) {
      const t = lines[j];
      const seg = j === idx ? t.slice(0, Math.max(0, t.indexOf('fun'))) : t.trim();
      (seg.match(/@(\w+)/g) || []).forEach((a) => anns.push(a.slice(1)));
      if (j === idx) continue;
      const tt = seg.trim();
      if (!tt) continue;
      if (tt.startsWith('@')) continue;
      break;
    }
    if (anns.some((a) => COMPOSE_ANNOTATIONS.has(a))) {
      const fm = lineText.match(/\bfun\s*(?:<[^>]+>\s*)?(\w+)/);
      if (fm) localComposable.add(fm[1]);
    }
  });
  // Material 2 imports warning (exact line, no indexOf ambiguity).
  lines.forEach((lineText, idx) => {
    const m = lineText.match(/^\s*import\s+androidx\.compose\.material\.[\w.*]+/);
    if (m) {
      problems.push({
        line: idx + 1, col: lineText.indexOf('import') + 1, severity: 'warning', code: 'material2',
        message: 'Material 2 import (androidx.compose.material.*) — this project is Material 3; mixing them breaks styling',
      });
    }
  });

  const isComposableCallee = (name) => !!name
    && (COMPOSABLE_SCOPE_CALLS.has(name) || localComposable.has(name) || KNOWN[name] === 'composable');

  const braceStack = [{ kind: 'root', composable: false, control: false, symbols: new Map() }];
  const parenStack = [];
  let pendingFun = null; // { composable, params } — fun header seen, body not opened yet
  let controlCandidate = null; // { depth, line, word } — if/for/… seen, block not opened yet
  let trailingCallee = null; // { name } — call just closed or identifier right before '{'
  let linePendingAnn = []; // annotation names accumulated from annotation-only lines
  let prevWord = null; // { word, start, end } — last identifier scanned on this line
  let pendingDecl = null; // { mutable } — val/var keyword awaiting the declared name
  let justDecl = null; // { word, end } — name just declared: its '=' is an initializer
  let pendingForVars = null; // string[] — loop variables awaiting the for-body '{'

  const inComposable = () => {
    for (let i = braceStack.length - 1; i >= 0; i--) {
      const b = braceStack[i];
      if (b.kind === 'fun' || b.kind === 'lambda') return b.composable;
    }
    return false;
  };
  const inControlBlock = () => braceStack.some((b) => b.control);

  // Register a val/var symbol into the innermost scope (after '{': the new one).
  const declareSymbol = (name, mutable, ln, col) => {
    const frame = braceStack[braceStack.length - 1];
    if (!frame.symbols) frame.symbols = new Map();
    if (frame.symbols.has(name)) {
      problems.push({
        line: ln, col, severity: 'error', code: 'duplicate-decl',
        message: `Conflicting declarations — '${name}' is already declared in this scope`,
      });
    }
    frame.symbols.set(name, { mutable });
  };
  const lookupSymbol = (name) => {
    for (let i = braceStack.length - 1; i >= 0; i--) {
      const fr = braceStack[i];
      if (fr.symbols && fr.symbols.has(name)) return fr.symbols.get(name);
    }
    return null;
  };

  const reportedContext = new Set();
  const reportedRemember = new Set();
  const reportedUnremembered = new Set();
  // User-declared names starting with 'Local' — their own CompositionLocals
  // are excluded from the .current rule.
  const declaredLocals = new Set();
  lines.forEach((lineText) => {
    const lm = lineText.match(/\b(?:val|var|fun|class|object)\s+(Local\w+)/);
    if (lm) declaredLocals.add(lm[1]);
  });

  for (let li = 0; li < lines.length; li++) {
    const lineText = lines[li];
    const ln = li + 1;
    if (/^\s*(import|package)\b/.test(lineText)) { pendingFun = null; linePendingAnn = []; continue; }
    // Annotations carried over from annotation-only lines above (the
    // fun-detection below resets linePendingAnn for content lines).
    const annsAtLineStart = linePendingAnn.slice();

    // --- fun header on this line?
    const funM = lineText.match(/\bfun\b/);
    const funIdx = funM ? funM.index : -1;
    if (funIdx >= 0) {
      const before = lineText.slice(0, funIdx);
      const looksDecl = /fun\s*(<|\.|\(|\w)/.test(lineText.slice(funIdx)) || /fun\s*$/.test(lineText);
      if (looksDecl && !/^\s*[\w.]+\s*=/.test(before)) {
        const anns = [...linePendingAnn];
        (before.match(/@(\w+)/g) || []).forEach((a) => anns.push(a.slice(1)));
        pendingFun = { composable: anns.some((a) => COMPOSE_ANNOTATIONS.has(a)), params: [] };
        linePendingAnn = [];
      }
    } else if (/^\s*@/.test(lineText)) {
      (lineText.match(/@(\w+)/g) || []).forEach((a) => linePendingAnn.push(a.slice(1)));
    } else if (/\S/.test(lineText) && !/^\s*(public|private|internal|protected|open|override|suspend|operator|infix|inline)+\s*$/.test(lineText)) {
      linePendingAnn = [];
    }

    prevWord = null;

    // --- char scan of the line
    let ci = 0;
    while (ci < lineText.length) {
      const ch = lineText[ci];
      if (/[A-Za-z_]/.test(ch)) {
        let end = ci;
        while (end < lineText.length && /\w/.test(lineText[end])) end++;
        const word = lineText.slice(ci, end);
        let nx = end;
        while (nx < lineText.length && /\s/.test(lineText[nx])) nx++;
        const nextCh = lineText[nx] || '';

        // --- val/var declarations (registered immediately; the upcoming '='
        //     is the initializer, not a reassignment — tracked via justDecl)
        if (word === 'val' || word === 'var') {
          pendingDecl = { mutable: word === 'var' };
          justDecl = null;
        } else if (pendingDecl) {
          declareSymbol(word, pendingDecl.mutable, ln, ci + 1);
          justDecl = { word, end };
          pendingDecl = null;
        } else {
          justDecl = null;
        }

        // --- @Composable on a property/class — invalid annotation target
        if (word === 'val' || word === 'var' || word === 'class' || word === 'object') {
          const pre = lineText.slice(0, ci);
          const sameLineAnn = /@Composable\s*$/.test(pre)
            || /@Composable\s+(?:(?:public|private|internal|protected|const|lateinit|override|open|final)\s+)*$/.test(pre);
          if (annsAtLineStart.includes('Composable') || sameLineAnn) {
            problems.push({
              line: ln, col: ci + 1, severity: 'error', code: 'composable-target',
              message: `@Composable cannot annotate a '${word}' declaration — it is only valid on functions (fun), lambda types and expressions`,
            });
          }
        }

        // --- snapshot state created during composition without remember()
        if (STATE_CREATORS.has(word) && (nextCh === '(' || nextCh === '{') && inComposable()) {
          const inRemember = parenStack.some((p) => p.callee === 'remember' || p.callee === 'rememberSaveable')
            || braceStack.some((fr) => fr.name === 'remember' || fr.name === 'rememberSaveable');
          if (!inRemember && !reportedUnremembered.has(ln)) {
            reportedUnremembered.add(ln);
            problems.push({
              line: ln, col: ci + 1, severity: 'warning', code: 'state-no-remember',
              message: `'${word}' without remember — the state resets on every recomposition. Use remember { ${word}(…) } (Compose lint: UnrememberedMutableState)`,
            });
          }
        }

        // --- CompositionLocal read without .current
        if (/^Local[A-Z]\w*$/.test(word) && !declaredLocals.has(word)) {
          const after = lineText.slice(end);
          const ok = /^\s*\.\s*(current|provides|providesDefault|defaultValue)\b/.test(after)
            || /^\s+provides\b/.test(after)
            || nextCh === '('
            || nextCh === ':';
          if (!ok) {
            problems.push({
              line: ln, col: ci + 1, severity: 'warning', code: 'composition-local-use',
              message: `'${word}' is a CompositionLocal — read its value with ${word}.current (CompositionLocalProvider keeps the 'provides' form)`,
            });
          }
        }

        // --- fun-header parameter: a bare `name :` inside the header parens
        const topParenNow = parenStack[parenStack.length - 1];
        if (topParenNow && topParenNow.isFunHeader && nextCh === ':') {
          topParenNow.params.push(word);
        }

        // --- for-loop variables: capture names before `in`
        if (word === 'for') {
          const fm = lineText.slice(ci).match(/^for\s*\(([^)]*?)\s+in\s/);
          pendingForVars = fm
            ? fm[1].split(/[\s,()]+/).filter((w) => /^\w+$/.test(w) && w !== 'in')
            : [];
        }

        // Composable call: `Name(` or trailing-lambda form `Name {`.
        if (/^[A-Z]/.test(word) && (nextCh === '(' || nextCh === '{')) {
          if (isComposableCallee(word) && !inComposable() && !pendingFun) {
            if (!reportedContext.has(word)) {
              reportedContext.add(word);
              problems.push({
                line: ln, col: ci + 1, severity: 'warning', code: 'compose-context',
                message: `'${word}' is a @Composable — composable calls are only allowed from a @Composable function, setContent { } or a composable lambda`,
              });
            }
          }
          if (DEPRECATED[word]) {
            problems.push({ line: ln, col: ci + 1, severity: 'warning', code: 'deprecated', message: DEPRECATED[word] });
          }
        }
        if ((word === 'remember' || word === 'rememberSaveable') && (nextCh === '(' || nextCh === '{') && inComposable() && inControlBlock()) {
          if (!reportedRemember.has(ln)) {
            reportedRemember.add(ln);
            problems.push({
              line: ln, col: ci + 1, severity: 'warning', code: 'remember-conditional',
              message: `'${word}' inside a conditional/loop block breaks Compose state — call it unconditionally at the top of the composable`,
            });
          }
        }
        if (CONTROL_WORDS.has(word) && (nextCh === '(' || word === 'else' || nextCh === '{')) {
          controlCandidate = { depth: parenStack.length, line: ln, word };
        }
        prevWord = { word, start: ci, end };
        ci = end;
        continue;
      }
      if (ch === '(') {
        const gap = prevWord ? lineText.slice(prevWord.end, ci) : '';
        const callee = prevWord && gap.trim() === '' ? prevWord.word : null;
        parenStack.push({
          callee,
          braceBase: braceStack.length,
          isFunHeader: !!pendingFun && !!callee,
          params: [],
        });
        prevWord = null;
        justDecl = null;
        pendingDecl = null; // `val (a, b) = …` destructuring — not tracked by name
        ci++;
        continue;
      }
      if (ch === ')') {
        const closed = parenStack.pop();
        if (closed?.isFunHeader && pendingFun) pendingFun.params = closed.params;
        if (closed?.callee && !CONTROL_WORDS.has(closed.callee)) trailingCallee = { name: closed.callee };
        prevWord = null;
        ci++;
        continue;
      }
      if (ch === '{') {
        let kind = 'lambda';
        let composable = inComposable();
        let control = false;
        let funParams = null;
        let braceName = null;
        const isControl = controlCandidate
          && controlCandidate.depth === parenStack.length
          && ln - controlCandidate.line <= 1;
        const controlWord = isControl ? controlCandidate.word : null;
        if (parenStack.length > 0) {
          const top = parenStack[parenStack.length - 1];
          if (isControl) { kind = 'control'; control = true; }
          else {
            // The lambda's owner is the word immediately before '{' when the
            // brace sits inside call parens: `Button(onClick = { … })` belongs
            // to onClick, `Column(…) {` (word-before is ')') to Column.
            let bb = ci - 1;
            while (bb >= 0 && /[\s=]/.test(lineText[bb])) bb--;
            const ee = bb + 1;
            while (bb >= 0 && /\w/.test(lineText[bb])) bb--;
            const owner = lineText.slice(bb + 1, ee) || top.callee;
            braceName = owner;
            // Effect/callback lambdas CLOSE the composable context even when
            // the caller is composable (Text() inside LaunchedEffect/onClick
            // is a compile error).
            if (owner && NON_COMPOSABLE_LAMBDA_CALLS.has(owner)) composable = false;
            else if (owner && isComposableCallee(owner)) composable = true;
          }
        } else if (pendingFun) {
          kind = 'fun';
          composable = pendingFun.composable;
          funParams = pendingFun.params || [];
          pendingFun = null;
        } else if (isControl) {
          kind = 'control';
          control = true;
        } else {
          // trailing lambda without parens: `Column {`, `setContent {`, or
          // right after a closed call on the same line: `Column(...) {`
          let name = null;
          let b = ci - 1;
          while (b >= 0 && /\s/.test(lineText[b])) b--;
          let e = b + 1;
          while (b >= 0 && /\w/.test(lineText[b])) b--;
          const w = lineText.slice(b + 1, e);
          if (w) name = w;
          if (!name && trailingCallee) name = trailingCallee.name;
          braceName = name;
          if (name && NON_COMPOSABLE_LAMBDA_CALLS.has(name)) composable = false;
          else if (name && isComposableCallee(name)) composable = true;
        }
        controlCandidate = null;
        trailingCallee = null;
        prevWord = null;
        justDecl = null;
        braceStack.push({ kind, composable, control, symbols: new Map(), name: braceName || null });
        // The fun body inherits declared parameters as read-only vals.
        if (funParams) funParams.forEach((p) => declareSymbol(p, false, ln, ci + 1));
        // `for (i in …) {` — the loop variable is read-only inside the body.
        if (control && controlWord === 'for' && pendingForVars && pendingForVars.length) {
          pendingForVars.forEach((v) => declareSymbol(v, false, ln, ci + 1));
        }
        pendingForVars = null;
        // Lambda parameters: `{ a, b -> … }` or `{ (a, b) -> … }`.
        if (kind === 'lambda') {
          const lm = lineText.slice(ci + 1).match(/^\s*(?:\(([^)]*)\)|([\w,\s]+?))\s*->/);
          if (lm) {
            (lm[1] ?? lm[2] ?? '').split(',').forEach((part) => {
              const nm = part.trim().split(':')[0].trim();
              if (/[A-Za-z_]/.test(nm) && /^\w+$/.test(nm) && nm !== '_') declareSymbol(nm, false, ln, ci + 1);
            });
          }
        }
        ci++;
        continue;
      }
      if (ch === '}') {
        if (braceStack.length > 1) braceStack.pop();
        trailingCallee = null;
        prevWord = null;
        ci++;
        continue;
      }
      if (ch === '=') {
        if (parenStack.length === 0 && pendingFun) pendingFun = null; // fun x() = ...
        const nxc = lineText[ci + 1] || '';
        const pvc = ci > 0 ? lineText[ci - 1] : '';
        pendingDecl = null;
        // A real single '=': not ==, <=, >=, !=, +=, ===, ...
        const isAssign = nxc !== '=' && !'!<>+-*/%&|='.includes(pvc);
        const pw = prevWord;
        if (isAssign && pw && /^\s*$/.test(lineText.slice(pw.end, ci))) {
          const topCond = parenStack[parenStack.length - 1];
          // if (x = true) — Kotlin forbids assignments in conditions.
          if (topCond && /^(if|while|for)$/.test(topCond.callee || '')) {
            problems.push({
              line: ln, col: pw.start + 1, severity: 'error', code: 'assign-in-condition',
              message: "Assignment inside a condition is a compiler error in Kotlin (assignments are not expressions) — did you mean '=='?",
            });
          } else {
          let b2 = pw.start - 1;
          while (b2 >= 0 && /\s/.test(lineText[b2])) b2--;
          const memberAccess = lineText[b2] === '.'; // obj.prop = … — not a local
          const isInitializer = justDecl && justDecl.word === pw.word && justDecl.end === pw.end;
          if (!memberAccess && !isInitializer) {
            const top = parenStack[parenStack.length - 1];
            // Inside a call argument list without an open lambda → named
            // argument (`callee(arg = value)`); otherwise a statement.
            const inArgList = !!top && braceStack.length <= top.braceBase;
            if (inArgList) {
              const prevCh = lineText[b2];
              if ((prevCh === '(' || prevCh === ',')
                && top.callee && NAMED_PARAMS[top.callee] && !localDecl.has(top.callee)
                && !NAMED_PARAMS[top.callee].has(pw.word)) {
                const valid = [...NAMED_PARAMS[top.callee]].slice(0, 5).join(', ');
                problems.push({
                  line: ln, col: pw.start + 1, severity: 'warning', code: 'named-arg',
                  message: `No parameter named '${pw.word}' in ${top.callee}(...) — compiler error "cannot find a parameter with this name". Valid: ${valid}, …`,
                });
              }
            } else {
              const decl = lookupSymbol(pw.word);
              if (decl && !decl.mutable) {
                problems.push({
                  line: ln, col: pw.start + 1, severity: 'error', code: 'val-reassign',
                  message: `'${pw.word}' is a read-only val and cannot be reassigned — declare it with var (or use mutableStateOf)`,
                });
              }
            }
          }
          }
        }
        prevWord = null;
        justDecl = null;
        ci++;
        continue;
      }
      if (!/\s|,/.test(ch)) { trailingCallee = null; prevWord = null; }
      ci++;
    }
    if (controlCandidate && ln - controlCandidate.line > 1) controlCandidate = null;
    if (!/\)\s*$/.test(lineText) && !/[\w)\]]\s*$/.test(lineText)) trailingCallee = null;
  }
};

/* ---------------------------------------------------- dp / sp mistakes */

/**
 * Dp ↔ TextUnit confusion — extremely common and always a compiler error:
 *   Text(fontSize = 16.dp)           → "inferred type is Dp but TextUnit was expected"
 *   Modifier.size(16.sp)             → "inferred type is TextUnit but Dp was expected"
 * Sized words are distinctive enough to report as errors; the call-form rule
 * is disabled when the callee shadows a local declaration.
 */
const analyzeUnitMismatch = (masked, problems) => {
  const lines = masked.split('\n');
  const declared = new Set();
  lines.forEach((lineText) => {
    let m = lineText.match(/\bfun\s*(?:<[^>]+>\s*)?(?:[\w.]+\.)?(\w+)/);
    if (m) declared.add(m[1]);
    m = lineText.match(/\b(?:class|object|interface)\s+(\w+)/);
    if (m) declared.add(m[1]);
  });
  lines.forEach((lineText, idx) => {
    const ln = idx + 1;
    let m;
    const wantsSp = /\b(fontSize|lineHeight|letterSpacing)\s*=\s*[\d.]+\s*\.\s*dp\b/g;
    while ((m = wantsSp.exec(lineText))) {
      problems.push({
        line: ln, col: m.index + 1, severity: 'error', code: 'unit-mismatch',
        message: `Type mismatch — '${m[1]}' expects TextUnit: use .sp, not .dp (compiler: inferred type is Dp but TextUnit was expected)`,
      });
    }
    const wantsDp = /\b(size|width|height|requiredSize|requiredWidth|requiredHeight|padding|offset|absoluteOffset|spacedBy|elevation|tonalElevation|shadowElevation|RoundedCornerShape)\s*\([^()\n]*[\d.]+\s*\.\s*sp\b/g;
    while ((m = wantsDp.exec(lineText))) {
      if (declared.has(m[1])) continue; // a same-name local function may take anything
      problems.push({
        line: ln, col: m.index + 1, severity: 'error', code: 'unit-mismatch',
        message: `Type mismatch — '${m[1]}(…)' expects Dp: use .dp here, .sp is only for text sizes (compiler: inferred type is TextUnit but Dp was expected)`,
      });
    }
  });
};

/* --------------------------------------- Compose function signature lints */

// Root UI emitters — used to decide that a @Composable function emits UI.
const UI_CALL_RE = /\b(Text|Column|Row|Box|Button|OutlinedButton|TextButton|IconButton|Icon|Image|Spacer|Card|ElevatedCard|OutlinedCard|Scaffold|Surface|LazyColumn|LazyRow|LazyVerticalGrid|OutlinedTextField|TextField|Checkbox|Switch|Slider|TopAppBar|CenterAlignedTopAppBar|MediumTopAppBar|LargeTopAppBar|FloatingActionButton|AlertDialog|NavigationBar|NavigationBarItem|RadioButton|LinearProgressIndicator|CircularProgressIndicator|HorizontalDivider)\s*[({]/;

/** Scan balanced brackets starting at `openIdx` (which holds `openCh`). */
const scanBalanced = (text, openIdx, openCh, closeCh) => {
  let depth = 0;
  for (let i = openIdx; i < text.length; i++) {
    if (text[i] === openCh) depth++;
    else if (text[i] === closeCh) {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
};

/** Split a parameter list at top-level commas (parens/angles safe). */
const splitTopLevel = (text) => {
  const parts = [];
  let depth = 0;
  let cur = '';
  for (const ch of text) {
    if (ch === '(' || ch === '<' || ch === '[' || ch === '{') depth++;
    if (ch === ')' || ch === '>' || ch === ']' || ch === '}') depth--;
    if (ch === ',' && depth === 0) { parts.push(cur); cur = ''; } else cur += ch;
  }
  if (cur.trim()) parts.push(cur);
  return parts;
};

/**
 * Official Compose lint rules for composable signatures:
 *   FunctionNaming    — @Composable fun names start with an uppercase letter
 *   ModifierMissing   — UI-emitting @Composable needs a modifier parameter
 *   ModifierParameter — modifier must be optional (a default) and the first
 *                       optional parameter
 */
const analyzeComposableSignatures = (masked, problems) => {
  const lines = masked.split('\n');
  const lineOffsets = [];
  let acc = 0;
  lines.forEach((t) => { lineOffsets.push(acc); acc += t.length + 1; });

  lines.forEach((lineText, idx) => {
    const fm = lineText.match(/\bfun\s+(\w+)\s*\(/);
    if (!fm) return;
    const name = fm[1];
    const anns = new Set();
    (lineText.slice(0, fm.index).match(/@(\w+)/g) || []).forEach((a) => anns.add(a.slice(1)));
    for (let j = idx - 1; j >= 0 && j >= idx - 4; j--) {
      const t = lines[j].trim();
      if (!t) continue;
      if (/^(public|private|internal|protected)\s*$/.test(t)) continue;
      if (!t.startsWith('@')) break;
      (t.match(/@(\w+)/g) || []).forEach((a) => anns.add(a.slice(1)));
    }
    if (!anns.has('Composable')) return;

    const ln = idx + 1;
    const nameCol = fm.index + fm[0].indexOf(name) + 1;
    if (/^[a-z]/.test(name)) {
      problems.push({
        line: ln, col: nameCol, severity: 'warning', code: 'compose-naming',
        message: `Composable function '${name}' should start with an uppercase letter (Compose lint: FunctionNaming)`,
      });
    }
    if (anns.has('Preview')) return; // previews are just callers — no modifier rules

    // Balanced parameter list + body (multi-line safe, works on masked text).
    const flatIdx = lineOffsets[idx] + fm.index + fm[0].length - 1; // at '('
    const closeP = scanBalanced(masked, flatIdx, '(', ')');
    if (closeP < 0) return;
    const paramsText = masked.slice(flatIdx + 1, closeP);
    const braceIdx = masked.indexOf('{', closeP);
    const eqIdx = masked.indexOf('=', closeP);
    let bodyText = '';
    if (braceIdx >= 0 && (eqIdx < 0 || braceIdx < eqIdx)) {
      const closeB = scanBalanced(masked, braceIdx, '{', '}');
      bodyText = closeB > braceIdx ? masked.slice(braceIdx + 1, closeB) : '';
    } else if (eqIdx >= 0 && eqIdx - closeP < 300) {
      bodyText = masked.slice(eqIdx + 1, eqIdx + 4000); // expression body
    }
    if (!UI_CALL_RE.test(bodyText)) return;

    const params = splitTopLevel(paramsText);
    const modifierIdx = params.findIndex((p) => /\bmodifier\s*:\s*(?:[\w.]+\.)?Modifier\b/.test(p));
    if (modifierIdx === -1) {
      // Zero-parameter composables are screens/roots — lint targets reusable
      // components that take props, so only those are flagged for a missing
      // modifier parameter.
      if (params.length > 0) {
        problems.push({
          line: ln, col: nameCol, severity: 'warning', code: 'modifier-param',
          message: `'${name}' emits UI but has no Modifier parameter — add 'modifier: Modifier = Modifier' and pass it to the root element (Compose lint: ModifierMissing)`,
        });
      }
      return;
    }
    if (!/=/.test(params[modifierIdx])) {
      problems.push({
        line: ln, col: nameCol, severity: 'warning', code: 'modifier-param',
        message: `'modifier' should have a default value: 'modifier: Modifier = Modifier' (Compose lint: ModifierParameter)`,
      });
      return;
    }
    const firstOptional = params.findIndex((p) => /=/.test(p));
    if (firstOptional !== -1 && modifierIdx !== firstOptional) {
      problems.push({
        line: ln, col: nameCol, severity: 'warning', code: 'modifier-param',
        message: "'modifier' should be the first optional parameter of a UI-emitting composable (Compose lint: ModifierParameter)",
      });
    }
  });
};

/* ------------------------------------------------------------ Toast */

// Toast.makeText(...) without .show() — the toast silently never appears.
const analyzeToast = (masked, problems) => {
  const lines = masked.split('\n');
  lines.forEach((lineText, idx) => {
    const m = lineText.match(/\bToast\s*\.\s*makeText\s*\(/);
    if (!m) return;
    const scope = `${lineText.slice(m.index)}\n${lines[idx + 1] || ''}`;
    if (!/\.show\s*\(/.test(scope)) {
      problems.push({
        line: idx + 1, col: m.index + 1, severity: 'warning', code: 'toast-show',
        message: 'Toast.makeText(...) only builds the Toast — nothing is displayed without .show()',
      });
    }
  });
};

/* ----------------------------------------------- missing import hints */

/**
 * Well-known Compose/Android symbols used without any import. Extension
 * functions (padding, size, …) DO require an import in Kotlin, so their call
 * form is checked; list-style properties (list.size) are not calls and never
 * match. Reported as warnings (cross-file shadows are invisible to us).
 */
const analyzeMissingImports = (masked, problems) => {
  const lines = masked.split('\n');
  const importedNames = new Set();
  const wildcardPkgs = new Set();
  const declared = new Set();
  lines.forEach((lineText) => {
    let m = lineText.match(/^\s*import\s+([\w.]+?)(\.\*)?\s*$/);
    if (m) {
      if (m[2]) wildcardPkgs.add(m[1]);
      else importedNames.add(m[1].split('.').pop());
    }
    m = lineText.match(/\bfun\s*(?:<[^>]+>\s*)?(?:[\w.]+\.)?(\w+)/);
    if (m) declared.add(m[1]);
    m = lineText.match(/\b(?:class|object|interface|typealias)\s+(\w+)/);
    if (m) declared.add(m[1]);
    m = lineText.match(/\b(?:val|var)\s+(\w+)/);
    if (m) declared.add(m[1]);
    // lambda parameters used as plain names: `{ size -> … }`
    const lm = /[({]\s*([\w\s,]+?)\s*->/g;
    while ((m = lm.exec(lineText))) {
      m[1].split(',').forEach((part) => {
        const nm = part.replace(/[()]/g, '').trim().split(':')[0].trim();
        if (/^\w+$/.test(nm)) declared.add(nm);
      });
    }
  });

  for (const [name, fq] of Object.entries(KNOWN_IMPORTS)) {
    if (importedNames.has(name) || declared.has(name)) continue;
    const pkg = fq.slice(0, fq.lastIndexOf('.'));
    if (wildcardPkgs.has(pkg)) continue;
    let useRe;
    if (name === 'dp' || name === 'sp') useRe = new RegExp(`\\d\\s*\\.\\s*${name}\\b`);
    else if (/^[A-Z]/.test(name)) useRe = new RegExp(`\\b${name}\\s*(?=[({<.:])`);
    else useRe = new RegExp(`\\b${name}\\s*[({]`); // extension/helper calls only
    let hit = null;
    for (let i = 0; i < lines.length; i++) {
      if (/^\s*(import|package)\b/.test(lines[i])) continue;
      const m = useRe.exec(lines[i]);
      if (m) { hit = { line: i + 1, col: m.index + 1 }; break; }
    }
    if (!hit) continue;
    problems.push({
      line: hit.line, col: hit.col, severity: 'warning', code: 'missing-import',
      message: `Missing import: ${fq} — the imports quick-fix (✨) adds it automatically`,
    });
  }
};

/* ----------------------------------------------- typo / quality hints */

const analyzeTypoHints = (masked, problems) => {
  const lines = masked.split('\n');
  const declared = new Set();
  const imported = new Set();
  let hasWildcardImport = false;
  lines.forEach((lineText) => {
    let m = lineText.match(/^\s*import\s+([\w.]+?)(\.\*)?\s*$/);
    if (m) {
      if (m[2]) hasWildcardImport = true;
      imported.add(m[1].split('.').pop());
    }
    m = lineText.match(/\bfun\s*(?:<[^>]+>\s*)?(\w+)/);
    if (m) declared.add(m[1]);
    m = lineText.match(/\b(?:class|object|interface)\s+(\w+)/);
    if (m) declared.add(m[1]);
    m = lineText.match(/\b(?:val|var)\s+(\w+)\s*=/);
    if (m && /^[A-Z]/.test(m[1])) declared.add(m[1]);
  });
  if (hasWildcardImport) return; // wildcard imports → cannot judge unknown refs

  const seen = new Set();
  lines.forEach((lineText, li) => {
    if (/^\s*(import|package)\b/.test(lineText)) return;
    const ln = li + 1;
    const re = /\b([A-Z][A-Za-z0-9_]{2,})\s*[(]|\b([A-Z][A-Za-z0-9_]{2,})\s*\{/g;
    let m;
    while ((m = re.exec(lineText))) {
      const name = m[1] || m[2];
      if (!name) continue;
      if (KNOWN[name] || declared.has(name) || imported.has(name)) continue;
      if (seen.has(name)) continue;
      seen.add(name);
      let best = null;
      let bestDist = 3;
      for (const cand of KNOWN_PASCAL) {
        if (cand === name || cand[0] !== name[0]) continue;
        const d = damerau(name.toLowerCase(), cand.toLowerCase(), 2);
        if (d < bestDist) { bestDist = d; best = cand; }
      }
      if (best) {
        problems.push({
          line: ln, col: m.index + 1, severity: 'warning', code: 'typo',
          message: `Unresolved reference '${name}' — did you mean '${best}'?`,
        });
      }
    }
    const bang = lineText.indexOf('!!');
    if (bang >= 0) {
      problems.push({
        line: ln, col: bang + 1, severity: 'warning', code: 'force-unwrap',
        message: "'!!' throws NullPointerException on null — prefer ?., ?: or let { }",
      });
    }
  });
};

/* ------------------------------------------------------------ public */

/**
 * Analyze Kotlin source and return the problem list, errors first.
 * @param {string} source
 * @returns {Array<{line:number, col:number, severity:'error'|'warning', code:string, message:string}>}
 */
export const analyzeKotlin = (source = '') => {
  if (!source || typeof source !== 'string') return [];
  const { masked, lexProblems, literals } = maskSource(source);
  const problems = [...lexProblems];
  checkDeclarations(masked.split('\n'), problems);
  // With structural errors, scope analysis becomes unreliable — skip it.
  if (!lexProblems.length) {
    analyzeComposeScopes(masked, problems);
    analyzeTypeLiterals(masked, literals, problems);
    analyzeUnitMismatch(masked, problems);
    analyzeComposableSignatures(masked, problems);
    analyzeToast(masked, problems);
    analyzeMissingImports(masked, problems);
    analyzeTypoHints(masked, problems);
  }
  const rank = { error: 0, warning: 1, info: 2 };
  problems.sort((a, b) => (rank[a.severity] ?? 1) - (rank[b.severity] ?? 1) || a.line - b.line || a.col - b.col);
  const uniq = [];
  const keys = new Set();
  for (const p of problems) {
    const k = `${p.line}:${p.col}:${p.code}`;
    if (!keys.has(k)) { keys.add(k); uniq.push(p); }
  }
  return uniq;
};

/** Count problems by severity. */
export const summarizeProblems = (problems = []) => ({
  errors: problems.filter((p) => p.severity === 'error').length,
  warnings: problems.filter((p) => p.severity === 'warning').length,
});

export default analyzeKotlin;
