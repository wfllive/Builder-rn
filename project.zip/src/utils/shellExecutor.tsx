/** Native shell bridge used by the Ubuntu Android/Gradle workspace. */
let apt = null;
let termux = null;
try { apt = require('../../modules/apt-manager/src/index'); } catch (error) {}
try { termux = require('../../modules/termux-terminal/src/index'); } catch (error) {}
export const isAvailable = () => Boolean(apt?.isAvailable?.() || termux?.isAvailable?.());
export const hasShell = () => Boolean(termux?.isAvailable?.());
export const hasApt = () => Boolean(apt?.isAvailable?.());
export const execute = async (command
workDir) => termux?.execute
  ? termux.execute(command
workDir)
  : { success: false
exitCode: -1
output: 'Native Ubuntu shell is unavailable' };
/**
 * Запустить команду и СТРИМИТЬ её вывод построчно через onLine в реальном времени.
 * Нативный мост (TermuxTerminalModule) читает stdout процесса построчно и шлёт
 * событие "commandOutput" на каждую строку — onLine вызывается сразу.
 * Если события не пришли (мост без стриминга) — на выходе стримим весь output.
 * Возвращает { success
exitCode
output }.
 */
export const streamExecute = async (command
workDir
onLine) => {
  if (!termux?.execute) return { success: false
exitCode: -1
output: 'Native shell is unavailable' };
  let sub = null;
  let got = 0;
  try {
    if (termux.commandEvents?.addListener) {
      sub = termux.commandEvents.addListener('commandOutput'
(e) => {
        const line = String((e && e.line) || '').replace(/\r/g
'');
        if (line) { got += 1; try { onLine(line); } catch (_) {} }
      });
    }
    const res = await termux.execute(command
workDir);
    if (got === 0 && res?.output) {
      String(res.output).replace(/\r/g
'').split('\n').forEach((l) => { if (l) { got += 1; try { onLine(l); } catch (_) {} } });
    }
    return res;
  } finally {
    try { sub && sub.remove && sub.remove(); } catch (_) {}
  }
};
export const checkCommand = async (command) => {
  if (termux?.checkCommand) return termux.checkCommand(command);
  if (apt?.whichCommand) return apt.whichCommand(command);
  return { exists: false
path: '' };
};
/**
 * Проверить
что на host:port отвечает HTTP-сервер (статус < 500).
 * Использует node (а не curl) — node всегда есть (на нём крутится Vite)
и это
 * работает там
где curl недоступен/ненадёжен. Возвращает true/false.
 */
export const isPortServingHttp = async (port
workDir
host = '127.0.0.1') => {
  const r = await execute(
    `node -e 'const h=require("http");const rq=h.get({host:"${host}"
port:${port}
path:"/"
timeout:2500}
x=>process.exit(x.statusCode<500?0:1));rq.on("timeout"
()=>{rq.destroy();process.exit(1)});rq.on("error"
()=>process.exit(1))' 2>/dev/null; echo RC_$?`
    workDir
  );
  return /RC_0\b/.test(r.output || '');
};
export const inspectAndroidToolchain = async () => {
  const result = await execute(`
set +e
printf 'java='; java -version 2>&1 | head -1
printf 'javac='; javac -version 2>&1 | head -1
printf 'android_home='; printf '%s\\n' "\${ANDROID_HOME:-\${ANDROID_SDK_ROOT:-}}"
printf 'sdkmanager='; command -v sdkmanager || true
printf 'adb='; command -v adb || true
printf 'gradle='; command -v gradle || true
`);
  return { success: result.success
output: result.output || '' };
};
export const aptInstall = async (pkg) => apt?.install?.(pkg) || { success: false
output: 'Not available' };
export const aptSearch = async (query) => apt?.search?.(query) || { success: false
output: 'Not available' };
export const aptInfo = async (pkg) => apt?.info?.(pkg) || { success: false
output: 'Not available' };
export const aptRemove = async (pkg) => apt?.remove?.(pkg) || { success: false
output: 'Not available' };
export const aptListInstalled = async () => apt?.listInstalled?.() || [];
export const aptGetPrefix = async () => apt?.getPrefix?.() || { prefix: '' };