/**
 * Native Compose preview bridge.
 *
 * Forwards the active project component tree to the AptManager native module,
 * which renders it with the real Android View framework (FrameLayout,
 * LinearLayout, CardView, TextView, EditText, Button, Switch, ...). The
 * returned base64 PNG is the source of truth for the preview — the same
 * widgets the generated Kotlin @Composable code will use at runtime.
 *
 * The old implementation mimicked Jetpack Compose with React Native <View>
 * shadows. This module replaces that: the editor shows what Android
 * actually draws, not what JavaScript approximates.
 */
import { renderComposePreview as renderNative } from '../../modules/apt-manager/src';

const SCREEN_WIDTH_DP = 360;
const DEFAULT_DENSITY = 2.625; // ~xhdpi
const DEFAULT_DPI = 420;
const PIXEL_RATIO = DEFAULT_DPI / 160;

const screenWidthPx = Math.round(SCREEN_WIDTH_DP * PIXEL_RATIO);

/**
 * Sanitize the component tree for the native preview module.
 * The native module only handles primitive props (strings, numbers,
 * booleans) and basic Android View types. Complex types like Scaffold
 * with nested TopAppBar objects, or ElevatedCard, need to be flattened
 * into simpler types the native renderer understands.
 */
// Older saved visual projects may contain the historical `Scafold` spelling.
// Kotlin source has always used `Scaffold`; accept the old model too so a
// valid screen never fails only in the preview renderer.
const TYPE_ALIASES = {
  Scafold: 'Scaffold',
};

const sanitizeTree = (node) => {
  if (!node) return null;
  let type = TYPE_ALIASES[node.type] || node.type || 'Column';
  let props = { ...(node.props || {}) };
  let children = (node.children || []).map(sanitizeTree).filter(Boolean);

  // Flatten Scaffold: extract TopAppBar title, render as simple Column
  if (type === 'Scaffold') {
    const topBarTitle = props.topBar?.props?.title || 'MyApp';
    delete props.topBar;
    // Insert a fake TopAppBar text at the top
    children = [
      { type: 'Text', props: { text: topBarTitle, textSize: 18, textColor: '#FFFFFF', backgroundColor: '#4F46E5', padding: 12, width: 'match_parent', height: 'wrap_content', fontWeight: '700' }, children: [] },
      ...children,
    ];
  }

  // Flatten ElevatedCard to Card
  if (type === 'ElevatedCard') type = 'Card';

  // Remove non-primitive props that the native module can't handle
  const cleanProps = {};
  for (const [key, value] of Object.entries(props)) {
    if (value === null || value === undefined) continue;
    if (typeof value === 'object' && !Array.isArray(value)) continue; // skip nested objects
    cleanProps[key] = value;
  }

  return {
    type,
    props: cleanProps,
    children,
  };
};

/**
 * Render a project/screen tree to a base64 PNG.
 * @param {object} project  full project (used for theme colors)
 * @param {object} screen   screen object from project.screens
 * @param {object} options  { widthDp, density, isDark, backgroundColor }
 */
export const renderPreviewPng = async (project, screen, options = {}) => {
  if (!screen?.rootComponent) {
    return { success: false, output: 'Screen has no root component', dataUri: null };
  }
  const isDark = Boolean(options.isDark) || Boolean(project?.theme?.isDark);
  const widthPx = Math.round((options.widthDp || SCREEN_WIDTH_DP) * (options.density || PIXEL_RATIO));
  const sanitizedTree = sanitizeTree(screen.rootComponent);
  const tree = JSON.stringify({
    type: sanitizedTree.type,
    props: sanitizedTree.props,
    children: sanitizedTree.children,
  });
  const result = await renderNative({
    tree,
    widthPx,
    heightPx: options.heightPx || 4096,
    isDark,
    backgroundColor: options.backgroundColor || screen.backgroundColor || (isDark ? '#0F172A' : '#F8FAFC'),
  });
  if (!result?.success || !result?.base64) {
    return { success: false, output: result?.output || 'Native preview failed', dataUri: null };
  }
  return {
    success: true,
    output: result.output,
    dataUri: `data:image/png;base64,${result.base64}`,
    widthPx,
  };
};

export const PREVIEW_CONSTANTS = {
  SCREEN_WIDTH_DP,
  DEFAULT_DENSITY,
  DEFAULT_DPI,
  screenWidthPx,
};