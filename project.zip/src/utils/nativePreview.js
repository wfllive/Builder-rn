/**
 * Native Compose preview bridge.
 *
 * Forwards the active project component tree to the AptManager native module,
 * which renders it with the real Android View framework (FrameLayout,
 * LinearLayout, CardView, TextView, EditText, Button, Switch, ...). The
 * returned base64 PNG is the source of truth for the preview — the same
 * widgets the generated Kotlin @Composable code will use at runtime.
 *
 * The old implementation mimicked Jetpack Compose with React Native <View>
 * shadows. This module replaces that: the editor shows what Android
 * actually draws, not what JavaScript approximates.
 */
import { renderComposePreview as renderNative } from '../../modules/apt-manager/src';

const SCREEN_WIDTH_DP = 360;
const DEFAULT_DENSITY = 2.625; // ~xhdpi
const DEFAULT_DPI = 420;
const PIXEL_RATIO = DEFAULT_DPI / 160;

const screenWidthPx = Math.round(SCREEN_WIDTH_DP * PIXEL_RATIO);

/**
 * Render a project/screen tree to a base64 PNG.
 * @param {object} project  full project (used for theme colors)
 * @param {object} screen   screen object from project.screens
 * @param {object} options  { widthDp, density, isDark, backgroundColor }
 */
export const renderPreviewPng = async (project, screen, options = {}) => {
  if (!screen?.rootComponent) {
    return { success: false, output: 'Screen has no root component', dataUri: null };
  }
  const isDark = Boolean(options.isDark) || Boolean(project?.theme?.isDark);
  const widthPx = Math.round((options.widthDp || SCREEN_WIDTH_DP) * (options.density || PIXEL_RATIO));
  const tree = JSON.stringify({
    type: screen.rootComponent.type || 'Column',
    props: screen.rootComponent.props || {},
    children: screen.rootComponent.children || [],
  });
  const result = await renderNative({
    tree,
    widthPx,
    heightPx: options.heightPx || 4096,
    isDark,
    backgroundColor: options.backgroundColor || screen.backgroundColor || (isDark ? '#0F172A' : '#F8FAFC'),
  });
  if (!result?.success || !result?.base64) {
    return { success: false, output: result?.output || 'Native preview failed', dataUri: null };
  }
  return {
    success: true,
    output: result.output,
    dataUri: `data:image/png;base64,${result.base64}`,
    widthPx,
  };
};

export const PREVIEW_CONSTANTS = {
  SCREEN_WIDTH_DP,
  DEFAULT_DENSITY,
  DEFAULT_DPI,
  screenWidthPx,
};
