/**
 * Native Compose preview bridge.
 *
 * Forwards the active project component tree to the AptManager native module,
 * where a real off-screen ComposeView renders Material 3 composables. The
 * returned bitmap is an image of Compose output — not a React Native or
 * Android-View approximation. This keeps design colours, shapes and Material
 * components aligned with the Kotlin project generator.
 */
import { renderComposePreview as renderNative } from '../../modules/apt-manager/src';
import { parseActivitySource, expandUserComposables } from './activityTree';

const SCREEN_WIDTH_DP = 360;
const DEFAULT_DENSITY = 2.625; // ~xhdpi
const DEFAULT_DPI = 420;
const PIXEL_RATIO = DEFAULT_DPI / 160;

const screenWidthPx = Math.round(SCREEN_WIDTH_DP * PIXEL_RATIO);

/**
 * Sanitize the component tree for the native preview module.
 * The native module only handles primitive props (strings, numbers,
 * booleans) and basic Android View types. Complex types like Scaffold
 * with nested TopAppBar objects, or ElevatedCard, need to be flattened
 * into simpler types the native renderer understands.
 */
// Older saved visual projects may contain the historical `Scafold` spelling.
// Kotlin source has always used `Scaffold`; accept the old model too so a
// valid screen never fails only in the preview renderer.
const TYPE_ALIASES = {
  Scafold: 'Scaffold',
};

// Material 3 baseline backgrounds (ColorDarkTokens.background / ColorLightTokens.background).
const M3_BG_DARK = '#141218';
const M3_BG_LIGHT = '#FFFBFE';

/** Balanced-paren body extractor (mirrors activityTree.splitBody). */
const splitBalanced = (source, openIndex, openChar, closeChar) => {
  let depth = 0;
  let inString = null;
  for (let i = openIndex; i < source.length; i++) {
    const ch = source[i];
    const prev = i > 0 ? source[i - 1] : '';
    if (inString) {
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; continue; }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) return { body: source.slice(openIndex + 1, i), end: i };
    }
  }
  return { body: '', end: openIndex };
};

/**
 * Parse the .kt's OWN theme definition(s):
 *   private val LightColors = lightColorScheme(primary = Color(0xFF...), ...)
 *   private val DarkColors  = darkColorScheme(...)
 * and return { role: "#AARRGGBB" } maps. These make the preview match a file
 * that declares a full custom Material 3 color scheme (the most common reason
 * preview colours differ from the built APK).
 */
const extractColorScheme = (source, fnName) => {
  const re = new RegExp(`${fnName}\\s*\\(`, 'g');
  let m = re.exec(source);
  if (!m) return null;
  const open = m.index + m[0].length - 1;
  const { body } = splitBalanced(source, open, '(', ')');
  const roles = {};
  const argRe = /([A-Za-z][A-Za-z0-9]*)\s*=\s*(Color\(\s*0x([0-9A-Fa-f]{6,8})\)|Color\.(White|Black)|0x([0-9A-Fa-f]{6,8}))/g;
  let a;
  while ((a = argRe.exec(body))) {
    let hex = a[3] || a[5];
    if (a[4]) hex = a[4] === 'White' ? 'FFFFFFFF' : '00000000';
    if (!hex) continue;
    roles[a[1]] = `#${hex}`;
  }
  return Object.keys(roles).length ? roles : null;
};

const extractColorSchemes = (source) => ({
  lightScheme: extractColorScheme(source, 'lightColorScheme'),
  darkScheme: extractColorScheme(source, 'darkColorScheme'),
});

/**
 * Find the actual title a code-first TopAppBar declares, so the preview top bar
 * shows the name from the .kt (e.g. `TopAppBar(title = { Text("My App") })`)
 * instead of falling back to the screen/action-bar name. Walks the parsed tree,
 * including a Scaffold's `topBar` slot.
 */
const findTopBarTitle = (node) => {
  if (!node || typeof node !== 'object') return null;
  if (node.type === 'TopAppBar') {
    const p = node.props || {};
    return p.title || p.text || p.actionBarTitle || null;
  }
  if (node.props && node.props.topBar && typeof node.props.topBar === 'object') {
    const t = findTopBarTitle(node.props.topBar);
    if (t) return t;
  }
  for (const child of node.children || []) {
    const t = findTopBarTitle(child);
    if (t) return t;
  }
  return null;
};

const sanitizeTree = (node, vars = {}) => {
  if (!node) return null;
  let type = TYPE_ALIASES[node.type] || node.type || 'Column';
  let props = { ...(node.props || {}) };
  // Replace Kotlin variable references with current project values for preview
  const sub = (s) => typeof s === 'string' ? s.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, name) => String(vars[name] ?? '')).replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (_, name) => String(vars[name] ?? '')) : s;
  for (const k of Object.keys(props)) {
    if (k === 'text' || k === 'label' || k === 'hint' || k === 'title' || k === 'value') props[k] = sub(props[k]);
  }
  let children = (node.children || []).map((c) => sanitizeTree(c, vars)).filter(Boolean);

  // ComposeRuntimePreview understands the complete visual model, including
  // Material 3 Scaffold/ElevatedCard and nested TopAppBar data. Do not flatten
  // those structures into Android View stand-ins: that was the source of the
  // incomplete, colour-inaccurate preview.
  return { type, props, children };
};

/**
 * Render a project/screen tree to a base64 PNG.
 * @param {object} project  full project (used for theme colors)
 * @param {object} screen   screen object from project.screens
 * @param {object} options  { widthDp, density, isDark, backgroundColor }
 */
export const renderPreviewPng = async (project, screen, options = {}) => {
  if (!screen?.rootComponent) {
    return { success: false, output: 'Screen has no root component', dataUri: null };
  }
  // Explicit light/dark override wins; otherwise follow the project's theme.
  const isDark = typeof options.isDark === 'boolean' ? options.isDark : Boolean(project?.theme?.isDark);
  const widthDp = options.widthDp || SCREEN_WIDTH_DP;
  const widthPx = Math.round(widthDp * (options.density || PIXEL_RATIO));
  const heightPx = options.heightPx || Math.round(800 * (options.density || PIXEL_RATIO) * 1.6);

  const vars = {};
  if (project?.variables && Array.isArray(project.variables)) {
    for (const v of project.variables) { if (v && v.name != null) vars[v.name] = v.value; }
  }

  // === CODE-FIRST PREVIEW ===
  // The .kt source the developer is editing is the single source of truth. If a
  // source string is present we parse it into the tree and use it; the stored
  // visual model (rootComponent) is only a fallback for visual-only projects
  // that have no Kotlin source yet.
  const source = (screen?.source && typeof screen.source === 'string') ? screen.source.trim() : '';
  const sourcePresent = source.length > 0;
  let sourceTree = null;
  if (sourcePresent) {
    try {
      const parsed = parseActivitySource(source);
      if (parsed && parsed.tree && parsed.tree.type) {
        sourceTree = parsed.tree;
      }
    } catch (_) { /* fall through to stored model */ }
  }
  if (!sourceTree) {
    sourceTree = screen.rootComponent;
  }

  // Inline user-defined @Composable helpers (HeroCard(), CounterButtons(...),
  // Tag(...), ...) so the preview shows their real content instead of a
  // placeholder, exactly like the compiled app does.
  if (sourcePresent && sourceTree) {
    try {
      sourceTree = expandUserComposables(source, sourceTree);
    } catch (_) { /* keep the unexpanded tree */ }
  }

  const sanitizedTree = sanitizeTree(sourceTree, vars);

  // Custom color scheme from the .kt (lightColorScheme/darkColorScheme).
  const schemes = sourcePresent ? extractColorSchemes(source) : { lightScheme: null, darkScheme: null };

  // Only synthesize a Scaffold/TopAppBar header when the code actually declares
  // one. A plain `Column { … }` screen in the generated app has NO action bar, so
  // inventing one would diverge from the real .kt. For visual-only screens
  // (no source) we keep the historical behaviour.
  const hasAppBar = sourcePresent && /\b(?:Scaffold|TopAppBar)\s*\(/.test(source);
  const showActionBar = screen?.showActionBar !== false && (!sourcePresent || hasAppBar);

  // Code-first top bar title: prefer the actual TopAppBar title in the .kt,
  // then the screen/action-bar name, then fall back to the screen name.
  const codeTitle = sourceTree ? findTopBarTitle(sourceTree) : null;
  const actionBarTitle = codeTitle || screen?.actionBarTitle || screen?.name || '';

  // Inject screen-level metadata so the native renderer can synthesize a correct
  // TopAppBar / Scaffold header when the code declares one.
  const rootProps = {
    ...(sanitizedTree.props || {}),
    actionBarTitle,
    title: actionBarTitle,
    text: actionBarTitle,
    backgroundColor: screen?.backgroundColor || sanitizedTree.props?.backgroundColor || (isDark ? M3_BG_DARK : M3_BG_LIGHT),
    showActionBar,
  };

  // Enrich payload with full project theme + screen metadata for highest fidelity
  const payload = {
    tree: JSON.stringify({
      type: sanitizedTree.type,
      props: rootProps,
      children: sanitizedTree.children,
    }),
    widthPx,
    heightPx,
    isDark,
    backgroundColor: options.backgroundColor || screen.backgroundColor || (isDark ? M3_BG_DARK : M3_BG_LIGHT),

    // Project theme (critical for color matching)
    projectPrimary: project?.theme?.primaryColor,
    projectSecondary: project?.theme?.secondaryColor,
    projectBackground: project?.theme?.backgroundColor,

    // Screen metadata: passed to PreviewConfig so ComposeRuntimePreview can
    // synthesize an accurate TopAppBar / Scaffold header when the code declares one.
    actionBarTitle,
    showActionBar,

    // The file's own lightColorScheme/darkColorScheme roles (if it declares them).
    lightScheme: schemes.lightScheme,
    darkScheme: schemes.darkScheme,

    density: options.density || PIXEL_RATIO,
    simulateState: options.simulateState !== false,
  };

  const result = await renderNative(payload);

  if (!result?.success || !result?.base64) {
    return { success: false, output: result?.output || 'Native preview failed', dataUri: null };
  }

  return {
    success: true,
    output: result.output,
    dataUri: `data:image/png;base64,${result.base64}`,
    widthPx,
    widthDp,
  };
};

export const PREVIEW_CONSTANTS = {
  SCREEN_WIDTH_DP,
  DEFAULT_DENSITY,
  DEFAULT_DPI,
  screenWidthPx,
};