/**
 * Native preview stub for React projects.
 * Compose renderer removed. Preview now is Vite dev server via WebView.
 * This file keeps API compatibility so old callers don't crash.
 * Real preview: src/components/WebPreview.js using react-native-webview.
 */

export const renderPreviewPng = async () => {
  return { success: false, output: 'Используется WebView preview (Vite). Нативный Compose рендер отключён.', dataUri: null };
};

export const PREVIEW_CONSTANTS = {
  SCREEN_WIDTH_DP: 360,
  DEFAULT_DENSITY: 2.625,
  DEFAULT_DPI: 420,
  screenWidthPx: 360*2.625,
};

// keep deprecated export name
export const renderComposePreview = renderPreviewPng;
