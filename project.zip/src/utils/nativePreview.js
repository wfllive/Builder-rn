/**
 * Native Compose preview bridge.
 *
 * Forwards the active project component tree to the AptManager native module,
 * where a real off-screen ComposeView renders Material 3 composables. The
 * returned bitmap is an image of Compose output — not a React Native or
 * Android-View approximation. This keeps design colours, shapes and Material
 * components aligned with the Kotlin project generator.
 */
import { renderComposePreview as renderNative } from '../../modules/apt-manager/src';
import { parseActivitySource } from './activityTree';

const SCREEN_WIDTH_DP = 360;
const DEFAULT_DENSITY = 2.625; // ~xhdpi
const DEFAULT_DPI = 420;
const PIXEL_RATIO = DEFAULT_DPI / 160;

const screenWidthPx = Math.round(SCREEN_WIDTH_DP * PIXEL_RATIO);

/**
 * Sanitize the component tree for the native preview module.
 * The native module only handles primitive props (strings, numbers,
 * booleans) and basic Android View types. Complex types like Scaffold
 * with nested TopAppBar objects, or ElevatedCard, need to be flattened
 * into simpler types the native renderer understands.
 */
// Older saved visual projects may contain the historical `Scafold` spelling.
// Kotlin source has always used `Scaffold`; accept the old model too so a
// valid screen never fails only in the preview renderer.
const TYPE_ALIASES = {
  Scafold: 'Scaffold',
};

const sanitizeTree = (node, vars = {}) => {
  if (!node) return null;
  let type = TYPE_ALIASES[node.type] || node.type || 'Column';
  let props = { ...(node.props || {}) };
  // Replace Kotlin variable references with current project values for preview
  const sub = (s) => typeof s === 'string' ? s.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_, name) => String(vars[name] ?? '')).replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (_, name) => String(vars[name] ?? '')) : s;
  for (const k of Object.keys(props)) {
    if (k === 'text' || k === 'label' || k === 'hint' || k === 'title' || k === 'value') props[k] = sub(props[k]);
  }
  let children = (node.children || []).map((c) => sanitizeTree(c, vars)).filter(Boolean);

  // ComposeRuntimePreview understands the complete visual model, including
  // Material 3 Scaffold/ElevatedCard and nested TopAppBar data. Do not flatten
  // those structures into Android View stand-ins: that was the source of the
  // incomplete, colour-inaccurate preview.
  return { type, props, children };
};

/**
 * Render a project/screen tree to a base64 PNG.
 * @param {object} project  full project (used for theme colors)
 * @param {object} screen   screen object from project.screens
 * @param {object} options  { widthDp, density, isDark, backgroundColor }
 */
export const renderPreviewPng = async (project, screen, options = {}) => {
  if (!screen?.rootComponent) {
    return { success: false, output: 'Screen has no root component', dataUri: null };
  }
  const isDark = Boolean(options.isDark) || Boolean(project?.theme?.isDark);
  const widthDp = options.widthDp || SCREEN_WIDTH_DP;
  const widthPx = Math.round(widthDp * (options.density || PIXEL_RATIO));
  const heightPx = options.heightPx || Math.round(800 * (options.density || PIXEL_RATIO) * 1.6);

  const vars = {};
  if (project?.variables && Array.isArray(project.variables)) {
    for (const v of project.variables) { if (v && v.name != null) vars[v.name] = v.value; }
  }

  // Professional preview: prefer actual Kotlin source if present (more accurate tree)
  let sourceTree = screen.rootComponent;
  if (screen?.source && typeof screen.source === 'string' && screen.source.trim().length > 50) {
    try {
      const parsed = parseActivitySource(screen.source);
      if (parsed && parsed.tree && parsed.tree.type) {
        sourceTree = parsed.tree;
      }
    } catch (_) { /* fall back to stored rootComponent */ }
  }

  const sanitizedTree = sanitizeTree(sourceTree, vars);

  // Enrich payload with full project theme for correct Material3 colors
  const payload = {
    tree: JSON.stringify({
      type: sanitizedTree.type,
      props: sanitizedTree.props,
      children: sanitizedTree.children,
    }),
    widthPx,
    heightPx,
    isDark,
    backgroundColor: options.backgroundColor || screen.backgroundColor || (isDark ? '#0F172A' : '#F8FAFC'),
    // Professional theme pass-through
    projectPrimary: project?.theme?.primaryColor,
    projectSecondary: project?.theme?.secondaryColor,
    projectBackground: project?.theme?.backgroundColor,
    density: options.density || PIXEL_RATIO,
    simulateState: options.simulateState !== false,
    interactive: options.interactive === true,
  };

  const result = await renderNative(payload);

  if (!result?.success || !result?.base64) {
    return { success: false, output: result?.output || 'Native preview failed', dataUri: null };
  }

  return {
    success: true,
    output: result.output,
    dataUri: `data:image/png;base64,${result.base64}`,
    widthPx,
    widthDp,
  };
};

export const PREVIEW_CONSTANTS = {
  SCREEN_WIDTH_DP,
  DEFAULT_DENSITY,
  DEFAULT_DPI,
  screenWidthPx,
};
