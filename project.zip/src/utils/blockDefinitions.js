// Определения блоков для визуального программирования
export const blockCategories = {
  EVENT: { id: 'EVENT', label: 'События', color: '#FFAB19' },
  CONTROL: { id: 'CONTROL', label: 'Управление', color: '#FFBF00' },
  OPERATOR: { id: 'OPERATOR', label: 'Операторы', color: '#59C059' },
  VARIABLE: { id: 'VARIABLE', label: 'Переменные', color: '#FF8C1A' },
  LOGIC: { id: 'LOGIC', label: 'Логика', color: '#5CB1D6' },
  COMPONENT: { id: 'COMPONENT', label: 'Компоненты', color: '#A06CD5' },
  MATH: { id: 'MATH', label: 'Математика', color: '#5AD9D9' },
  TEXT: { id: 'TEXT', label: 'Текст', color: '#78C478' },
  LIST: { id: 'LIST', label: 'Списки', color: '#FF6680' },
};

export const blockDefinitions = [
  // События
  {
    id: 'on_click',
    category: 'EVENT',
    label: 'При нажатии',
    shape: 'hat',
    inputs: [],
    outputs: ['next'],
  },
  {
    id: 'on_create',
    category: 'EVENT',
    label: 'При создании экрана',
    shape: 'hat',
    inputs: [],
    outputs: ['next'],
  },
  {
    id: 'on_back_pressed',
    category: 'EVENT',
    label: 'При нажатии назад',
    shape: 'hat',
    inputs: [],
    outputs: ['next'],
  },
  
  // Управление
  {
    id: 'if_else',
    category: 'CONTROL',
    label: 'если ... иначе',
    shape: 'c-block',
    inputs: [{ type: 'boolean', label: 'условие' }],
    outputs: ['next', 'do', 'else'],
  },
  {
    id: 'repeat',
    category: 'CONTROL',
    label: 'повторять N раз',
    shape: 'c-block',
    inputs: [{ type: 'number', label: 'раз' }],
    outputs: ['next', 'do'],
  },
  {
    id: 'forever',
    category: 'CONTROL',
    label: 'повторять всегда',
    shape: 'c-block',
    inputs: [],
    outputs: ['do'],
  },
  {
    id: 'wait',
    category: 'CONTROL',
    label: 'ждать (мс)',
    shape: 'stack',
    inputs: [{ type: 'number', label: 'мс' }],
    outputs: ['next'],
  },
  
  // Операторы
  {
    id: 'add',
    category: 'OPERATOR',
    label: '+',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'a' }, { type: 'number', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'subtract',
    category: 'OPERATOR',
    label: '-',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'a' }, { type: 'number', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'multiply',
    category: 'OPERATOR',
    label: '×',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'a' }, { type: 'number', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'divide',
    category: 'OPERATOR',
    label: '÷',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'a' }, { type: 'number', label: 'b' }],
    outputs: ['value'],
  },
  
  // Переменные
  {
    id: 'set_var',
    category: 'VARIABLE',
    label: 'установить переменную',
    shape: 'stack',
    inputs: [{ type: 'text', label: 'имя' }, { type: 'any', label: 'значение' }],
    outputs: ['next'],
  },
  {
    id: 'get_var',
    category: 'VARIABLE',
    label: 'получить переменную',
    shape: 'reporter',
    inputs: [{ type: 'text', label: 'имя' }],
    outputs: ['value'],
  },
  {
    id: 'change_var',
    category: 'VARIABLE',
    label: 'изменить переменную на',
    shape: 'stack',
    inputs: [{ type: 'text', label: 'имя' }, { type: 'number', label: 'значение' }],
    outputs: ['next'],
  },
  
  // Логика
  {
    id: 'and',
    category: 'LOGIC',
    label: 'и',
    shape: 'reporter',
    inputs: [{ type: 'boolean', label: 'a' }, { type: 'boolean', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'or',
    category: 'LOGIC',
    label: 'или',
    shape: 'reporter',
    inputs: [{ type: 'boolean', label: 'a' }, { type: 'boolean', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'not',
    category: 'LOGIC',
    label: 'не',
    shape: 'reporter',
    inputs: [{ type: 'boolean', label: 'условие' }],
    outputs: ['value'],
  },
  {
    id: 'equals',
    category: 'LOGIC',
    label: '=',
    shape: 'reporter',
    inputs: [{ type: 'any', label: 'a' }, { type: 'any', label: 'b' }],
    outputs: ['value'],
  },
  
  // Компоненты
  {
    id: 'set_text',
    category: 'COMPONENT',
    label: 'установить текст',
    shape: 'stack',
    inputs: [{ type: 'component', label: 'компонент' }, { type: 'text', label: 'текст' }],
    outputs: ['next'],
  },
  {
    id: 'get_text',
    category: 'COMPONENT',
    label: 'получить текст',
    shape: 'reporter',
    inputs: [{ type: 'component', label: 'компонент' }],
    outputs: ['value'],
  },
  {
    id: 'set_visible',
    category: 'COMPONENT',
    label: 'установить видимость',
    shape: 'stack',
    inputs: [{ type: 'component', label: 'компонент' }, { type: 'boolean', label: 'видимый' }],
    outputs: ['next'],
  },
  {
    id: 'navigate',
    category: 'COMPONENT',
    label: 'перейти на экран',
    shape: 'stack',
    inputs: [{ type: 'text', label: 'экран' }],
    outputs: ['next'],
  },
  {
    id: 'show_toast',
    category: 'COMPONENT',
    label: 'показать уведомление',
    shape: 'stack',
    inputs: [{ type: 'text', label: 'текст' }],
    outputs: ['next'],
  },
  
  // Математика
  {
    id: 'random',
    category: 'MATH',
    label: 'случайное число от ... до',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'мин' }, { type: 'number', label: 'макс' }],
    outputs: ['value'],
  },
  {
    id: 'round',
    category: 'MATH',
    label: 'округлить',
    shape: 'reporter',
    inputs: [{ type: 'number', label: 'число' }],
    outputs: ['value'],
  },
  
  // Текст
  {
    id: 'join',
    category: 'TEXT',
    label: 'объединить',
    shape: 'reporter',
    inputs: [{ type: 'text', label: 'a' }, { type: 'text', label: 'b' }],
    outputs: ['value'],
  },
  {
    id: 'length',
    category: 'TEXT',
    label: 'длина текста',
    shape: 'reporter',
    inputs: [{ type: 'text', label: 'текст' }],
    outputs: ['value'],
  },
  
  // Списки
  {
    id: 'list_add',
    category: 'LIST',
    label: 'добавить в список',
    shape: 'stack',
    inputs: [{ type: 'text', label: 'список' }, { type: 'any', label: 'элемент' }],
    outputs: ['next'],
  },
  {
    id: 'list_get',
    category: 'LIST',
    label: 'получить элемент',
    shape: 'reporter',
    inputs: [{ type: 'text', label: 'список' }, { type: 'number', label: 'индекс' }],
    outputs: ['value'],
  },
];

export default blockDefinitions;
