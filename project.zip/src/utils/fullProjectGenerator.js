import { createComposeProjectFiles } from './composeProject';

/**
 * Generates a complete React + Vite project packaged for Android
 * with WebView (assets folder). No Jetpack Compose.
 */
export const generateFullProject = (project) => createComposeProjectFiles(project);

export default generateFullProject;
