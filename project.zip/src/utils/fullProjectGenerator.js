import { createComposeProjectFiles } from './composeProject';

/**
 * Generates a complete native Android project using Gradle Kotlin DSL,
 * Kotlin 2.x, Material 3 and Jetpack Compose.
 */
export const generateFullProject = (project) => createComposeProjectFiles(project);

export default generateFullProject;
