/*import { generateId } from './generateId';


export const generateFullProject = (project) => {
  const files = {};
  
  // package.json
  files['package.json'] = JSON.stringify({
    name: project.name.toLowerCase().replace(/\s/g, '-'),
    version: project.versionName || '1.0.0',
    main: 'node_modules/expo/AppEntry.js',
    scripts: {
      start: 'expo start',
      android: 'expo start --android',
      ios: 'expo start --ios',
      web: 'expo start --web',
    },
    dependencies: {
      expo: '~52.0.0',
      'expo-status-bar': '~2.0.1',
      'expo-asset': '~11.0.4',
      'expo-font': '~13.0.4',
      'expo-constants': '~17.0.8',
      '@expo/metro-runtime': '~4.0.1',
      'react-dom': '18.3.1',
      'react-native-web': '~0.19.13',
      react: '18.3.1',
      'react-native': '0.76.7',
      '@react-navigation/native': '^7.0.0',
      '@react-navigation/native-stack': '^7.0.0',
      'react-native-screens': '~4.4.0',
      'react-native-safe-area-context': '4.14.1',
    },
    devDependencies: {
      '@babel/core': '^7.25.2',
    },
    private: true,
  }, null, 2);

  // app.json
  files['app.json'] = JSON.stringify({
    expo: {
      name: project.name,
      slug: project.name.toLowerCase().replace(/\s/g, '-'),
      version: project.versionName || '1.0.0',
      orientation: 'portrait',
      icon: './assets/icon.png',
      userInterfaceStyle: project.theme?.isDark ? 'dark' : 'light',
      splash: {
        backgroundColor: project.theme?.primaryColor || '#BB86FC',
      },
      ios: {
        supportsTablet: true,
        bundleIdentifier: project.packageName || 'com.app.default',
      },
      android: {
        adaptiveIcon: {
          backgroundColor: project.theme?.primaryColor || '#BB86FC',
        },
        package: project.packageName || 'com.app.default',
      },
    },
  }, null, 2);

  // eas.json
  files['eas.json'] = JSON.stringify({
    cli: { version: '>= 12.0.0' },
    build: {
      development: {
        developmentClient: true,
        distribution: 'internal',
        android: { buildType: 'apk' },
      },
      preview: {
        distribution: 'internal',
        android: { buildType: 'apk' },
      },
      production: {
        android: { buildType: 'app-bundle' },
      },
    },
  }, null, 2);

  // babel.config.js
  files['babel.config.js'] = `module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
  };
};
`;

  // App.js — главный файл приложения
  files['App.js'] = generateAppJs(project);

  // Генерируем экраны
  project.screens.forEach((screen, index) => {
    files[`src/screens/${screen.name.replace(/\s/g, '')}Screen.js`] = generateScreenJs(screen, project, index);
  });

  return files;
};

const generateAppJs = (project) => {
  const screens = project.screens || [];
  const imports = screens.map((s, i) => 
    `import ${s.name.replace(/\s/g, '')}Screen from './src/screens/${s.name.replace(/\s/g, '')}Screen';`
  ).join('\n');

  const screenDefs = screens.map((s, i) => 
    `          <Stack.Screen name="${s.name.replace(/\s/g, '')}" component={${s.name.replace(/\s/g, '')}Screen} options={{ title: '${s.name}' }} />`
  ).join('\n');

  return `import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

${imports}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <>
      <StatusBar barStyle="${project.theme?.isDark ? 'light' : 'dark'}-content" backgroundColor="${project.theme?.primaryColor || '#BB86FC'}" />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: '${project.theme?.primaryColor || '#BB86FC'}' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        >
${screenDefs}
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}
`;
};

const generateScreenJs = (screen, project, index) => {
  const props = screen.rootComponent?.props || {};
  const bgColor = screen.backgroundColor || project.theme?.backgroundColor || '#121212';

  // Generate imports
  const needsScrollView = hasType(screen.rootComponent, 'ScrollView');
  const needsWebView = hasType(screen.rootComponent, 'WebView');
  
  let rnImports = ['View', 'Text', 'StyleSheet', 'TouchableOpacity', 'Alert'];
  if (needsScrollView) rnImports.push('ScrollView');
  if (hasType(screen.rootComponent, 'EditText')) rnImports.push('TextInput');
  if (hasType(screen.rootComponent, 'Switch')) rnImports.push('Switch');
  if (hasType(screen.rootComponent, 'ProgressBar')) rnImports.push('ActivityIndicator');

  let extraImports = '';
  if (needsWebView) extraImports += "import { WebView } from 'react-native-webview';\n";
  if (hasType(screen.rootComponent, 'ImageView')) extraImports += "import { Ionicons } from '@expo/vector-icons';\n";

  // Generate component JSX
  const jsx = generateJSX(screen.rootComponent, 4);
  
  // Generate styles
  const styles = generateScreenStyles(screen.rootComponent, bgColor);
  
  // Generate state
  const stateVars = (project.variables || []).map(v => {
    const def = v.type === 'number' ? (v.value || 0) : 
                v.type === 'boolean' ? (v.value || false) :
                `'${v.value || ''}'`;
    return `  const [${v.name}, set${v.name.charAt(0).toUpperCase() + v.name.slice(1)}] = useState(${def});`;
  }).join('\n');

  // Generate event handlers from blocks
  const handlers = generateHandlersFromBlocks(screen);

  const screenName = screen.name.replace(/\s/g, '') + 'Screen';

  return `import React, { useState, useEffect } from 'react';
import {
  ${rnImports.join(',\n  ')},
} from 'react-native';
${extraImports}
const ${screenName} = ({ navigation }) => {
${stateVars || '  // State'}
  
${handlers}
  return (
    <View style={styles.container}>
${jsx}
    </View>
  );
};

${styles}

export default ${screenName};
`;
};

const hasType = (comp, type) => {
  if (!comp) return false;
  if (comp.type === type) return true;
  if (comp.children) return comp.children.some(c => hasType(c, type));
  return false;
};

const generateJSX = (component, indent) => {
  if (!component) return '';
  const sp = ' '.repeat(indent);
  const props = component.props || {};
  const styleName = `styles.c_${component.id?.slice(0, 8) || 'root'}`;

  switch (component.type) {
    case 'LinearLayout':
      return `${sp}<View style={${styleName}}>
${(component.children || []).map(c => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;

    case 'ScrollView':
      return `${sp}<ScrollView style={${styleName}} showsVerticalScrollIndicator={false}>
${(component.children || []).map(c => generateJSX(c, indent + 2)).join('\n')}
${sp}</ScrollView>`;

    case 'CardView':
      return `${sp}<View style={${styleName}}>
${(component.children || []).map(c => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;

    case 'TextView':
      return `${sp}<Text style={${styleName}}>${props.text || ''}</Text>`;

    case 'Button':
      return `${sp}<TouchableOpacity style={${styleName}} onPress={() => Alert.alert('${props.text || 'Button'}', 'Нажато!')}>
${sp}  <Text style={${styleName}_text}>${props.text || 'Button'}</Text>
${sp}</TouchableOpacity>`;

    case 'EditText':
      return `${sp}<TextInput style={${styleName}} placeholder="${props.hint || ''}" placeholderTextColor="#888" />`;

    case 'ImageView':
      return `${sp}<View style={${styleName}}>
${sp}  <Ionicons name="image-outline" size={32} color="#64748B" />
${sp}</View>`;

    case 'CheckBox':
      return `${sp}<TouchableOpacity style={${styleName}} onPress={() => {}}>
${sp}  <View style={[${styleName}_box]} />
${sp}  <Text style={{ color: '#fff', marginLeft: 8 }}>${props.text || 'CheckBox'}</Text>
${sp}</TouchableOpacity>`;

    case 'Switch':
      return `${sp}<View style={${styleName}}>
${sp}  <Text style={{ color: '#fff' }}>${props.text || 'Switch'}</Text>
${sp}  <Switch value={false} onValueChange={() => {}} />
${sp}</View>`;

    case 'ProgressBar':
      return `${sp}<View style={${styleName}}>
${sp}  <View style={[${styleName}_fill, { width: '${props.progress || 50}%' }]} />
${sp}</View>`;

    case 'Divider':
      return `${sp}<View style={${styleName}} />`;

    case 'Spacer':
      return `${sp}<View style={${styleName}} />`;

    case 'WebView':
      return `${sp}<WebView source={{ uri: '${props.url || 'https://example.com'}' }} style={${styleName}} />`;

    default:
      return `${sp}<View style={${styleName}} />`;
  }
};

const generateScreenStyles = (rootComponent, bgColor) => {
  const styles = [];
  
  styles.push(`const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '${bgColor}',
    padding: ${rootComponent?.props?.padding || 16},
  },`);

  collectStyles(rootComponent, styles);

  styles.push('});');
  return styles.join('\n');
};

const collectStyles = (comp, styles) => {
  if (!comp) return;
  const props = comp.props || {};
  const key = `  c_${comp.id?.slice(0, 8) || 'root'}`;

  switch (comp.type) {
    case 'LinearLayout':
    case 'CardView':
      styles.push(`${key}: {
    flexDirection: '${props.orientation === 'horizontal' ? 'row' : 'column'}',
    ${dimStyle('width', props.width)}${dimStyle('height', props.height)}padding: ${props.padding || 0},
    backgroundColor: '${props.backgroundColor || 'transparent'}',
    borderRadius: ${props.borderRadius || 0},
    ${props.elevation ? `elevation: ${props.elevation}, shadowColor: '#000', shadowOffset: {width:0,height:2}, shadowOpacity: 0.25, shadowRadius: 4,` : ''}
  },`);
      break;
    case 'ScrollView':
      styles.push(`${key}: { flex: 1 },`);
      break;
    case 'TextView':
      styles.push(`${key}: {
    fontSize: ${props.textSize || 16},
    color: '${props.textColor || '#fff'}',
    fontWeight: '${props.textStyle === 'bold' ? 'bold' : 'normal'}',
    textAlign: '${props.gravity || 'left'}',
    padding: ${props.padding || 0},
  },`);
      break;
    case 'Button':
      styles.push(`${key}: {
    backgroundColor: '${props.backgroundColor || '#BB86FC'}',
    padding: ${props.padding || 14},
    borderRadius: ${props.borderRadius || 8},
    alignItems: 'center',
    marginVertical: 6,
  },
  ${key}_text: {
    color: '${props.textColor || '#fff'}',
    fontSize: ${props.textSize || 16},
    fontWeight: 'bold',
  },`);
      break;
    case 'EditText':
      styles.push(`${key}: {
    backgroundColor: '${props.backgroundColor || '#2C2C2C'}',
    padding: ${props.padding || 12},
    borderRadius: ${props.borderRadius || 8},
    color: '${props.textColor || '#fff'}',
    fontSize: ${props.textSize || 16},
    marginVertical: 6,
    borderWidth: 1,
    borderColor: '#444',
  },`);
      break;
    case 'ImageView':
      styles.push(`${key}: {
    width: ${typeof props.width === 'number' ? props.width : 100},
    height: ${typeof props.height === 'number' ? props.height : 100},
    backgroundColor: '${props.backgroundColor || '#333'}',
    borderRadius: ${props.borderRadius || 0},
    justifyContent: 'center',
    alignItems: 'center',
  },`);
      break;
    case 'CheckBox':
      styles.push(`${key}: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  ${key}_box: {
    width: 20, height: 20, borderWidth: 2, borderColor: '#BB86FC', borderRadius: 4,
  },`);
      break;
    case 'Switch':
      styles.push(`${key}: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 6,
  },`);
      break;
    case 'ProgressBar':
      styles.push(`${key}: {
    height: 8, backgroundColor: '#333', borderRadius: 4, overflow: 'hidden', marginVertical: 8,
  },
  ${key}_fill: {
    height: '100%', backgroundColor: '${props.color || '#BB86FC'}', borderRadius: 4,
  },`);
      break;
    case 'Divider':
      styles.push(`${key}: {
    height: ${props.height || 1}, backgroundColor: '${props.backgroundColor || '#444'}', margin: ${props.margin || 8},
  },`);
      break;
    case 'Spacer':
      styles.push(`${key}: { height: ${props.height || 16} },`);
      break;
    case 'WebView':
      styles.push(`${key}: {
    width: '100%', height: ${props.height || 300}, borderRadius: 8, overflow: 'hidden',
  },`);
      break;
  }

  if (comp.children) comp.children.forEach(c => collectStyles(c, styles));
};

const dimStyle = (key, val) => {
  if (val === 'match_parent') return `${key}: '100%',\n    `;
  if (typeof val === 'number') return `${key}: ${val},\n    `;
  return '';
};

const generateHandlersFromBlocks = (screen) => {
  const blocks = screen.blocks || [];
  let code = '';
  
  const onCreate = blocks.find(b => b.definitionId === 'on_create');
  if (onCreate?.children?.next) {
    code += `  useEffect(() => {\n`;
    onCreate.children.next.forEach(action => {
      if (action.definitionId === 'show_toast') {
        code += `    Alert.alert('Сообщение', '${action.inputs?.text || ''}');\n`;
      }
    });
    code += `  }, []);\n\n`;
  }

  return code;
};

export default generateFullProject;*/

import { generateId } from './generateId';

/**
 * Генератор полного Expo-проекта из визуального проекта конструктора.
 *
 * Обновлено: июль 2026
 *  - Expo SDK 57 (React Native 0.86, React 19.2, RN Web 0.21)
 *  - React Navigation 7.3+
 *  - react-native-screens 4.26, react-native-safe-area-context 5.8
 *  - EAS CLI >= 21
 *  - Добавлены зависимости expo-dev-client (для development-сборки)
 *    и react-native-webview (используется компонентом WebView).
 *  - Исправлено экранирование строк (апострофы, кавычки, спецсимволы).
 *
 * Возвращает объект с файлами проекта.
 */
export const generateFullProject = (project) => {
  const files = {};

  const appName = project.name || 'My App';
  const slug = appName.toLowerCase().replace(/\s/g, '-');
  const primaryColor = project.theme?.primaryColor || '#BB86FC';
  const isDark = !!project.theme?.isDark;

  // package.json
  files['package.json'] = JSON.stringify({
    name: slug,
    version: project.versionName || '1.0.0',
    main: 'node_modules/expo/AppEntry.js',
    scripts: {
      start: 'expo start',
      android: 'expo start --android',
      ios: 'expo start --ios',
      web: 'expo start --web',
    },
    dependencies: {
      // Expo SDK 57 (июль 2026)
      expo: '~57.0.8',
      'expo-status-bar': '~57.0.1',
      'expo-asset': '~57.0.7',
      'expo-font': '~57.0.1',
      'expo-constants': '~57.0.7',
      '@expo/metro-runtime': '~57.0.7',
      '@expo/vector-icons': '^15.0.2',
      'expo-dev-client': '~57.0.8',
      // React / React Native
      react: '19.2.3',
      'react-dom': '19.2.3',
      'react-native': '0.86.0',
      'react-native-web': '~0.21.0',
      'react-native-webview': '~14.0.1',
      // Навигация
      '@react-navigation/native': '^7.3.13',
      '@react-navigation/native-stack': '^7.18.5',
      'react-native-screens': '~4.26.2',
      'react-native-safe-area-context': '5.8.0',
    },
    devDependencies: {
      '@babel/core': '^7.29.7',
    },
    private: true,
  }, null, 2);

  // app.json
  files['app.json'] = JSON.stringify({
    expo: {
      name: appName,
      slug,
      version: project.versionName || '1.0.0',
      orientation: 'portrait',
      icon: './assets/icon.png',
      userInterfaceStyle: isDark ? 'dark' : 'light',
      splash: {
        backgroundColor: primaryColor,
      },
      ios: {
        supportsTablet: true,
        bundleIdentifier: project.packageName || 'com.app.default',
      },
      android: {
        adaptiveIcon: {
          backgroundColor: primaryColor,
        },
        package: project.packageName || 'com.app.default',
      },
    },
  }, null, 2);

  // eas.json
  files['eas.json'] = JSON.stringify({
    cli: { version: '>= 21.0.0' },
    build: {
      development: {
        developmentClient: true,
        distribution: 'internal',
        android: { buildType: 'apk' },
      },
      preview: {
        distribution: 'internal',
        android: { buildType: 'apk' },
      },
      production: {
        android: { buildType: 'app-bundle' },
      },
    },
  }, null, 2);

  // babel.config.js
  files['babel.config.js'] = `module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
  };
};
`;

  // App.js — главный файл приложения
  files['App.js'] = generateAppJs(project);

  // Генерируем экраны
  (project.screens || []).forEach((screen, index) => {
    files[`src/screens/${screen.name.replace(/\s/g, '')}Screen.js`] = generateScreenJs(screen, project, index);
  });

  return files;
};

/**
 * Безопасно превращает любое значение в JS-строковый литерал (в двойных кавычках).
 * Корректно экранирует кавычки, обратные слеши, переносы строк и юникод.
 */
const jsString = (value) => JSON.stringify(String(value ?? ''));

const generateAppJs = (project) => {
  const screens = project.screens || [];
  const primaryColor = project.theme?.primaryColor || '#BB86FC';
  const isDark = !!project.theme?.isDark;

  const imports = screens
    .map((s) => `import ${s.name.replace(/\s/g, '')}Screen from './src/screens/${s.name.replace(/\s/g, '')}Screen';`)
    .join('\n');

  const screenDefs = screens
    .map((s) => `          <Stack.Screen name="${s.name.replace(/\s/g, '')}" component={${s.name.replace(/\s/g, '')}Screen} options={{ title: ${jsString(s.name)} }} />`)
    .join('\n');

  return `import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

${imports}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <>
      <StatusBar barStyle="${isDark ? 'light' : 'dark'}-content" backgroundColor="${primaryColor}" />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: '${primaryColor}' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        >
${screenDefs}
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}
`;
};

const generateScreenJs = (screen, project, index) => {
  const bgColor = screen.backgroundColor || project.theme?.backgroundColor || '#121212';

  // Generate imports
  const needsScrollView = hasType(screen.rootComponent, 'ScrollView');
  const needsWebView = hasType(screen.rootComponent, 'WebView');

  const rnImports = ['View', 'Text', 'StyleSheet', 'TouchableOpacity', 'Alert'];
  if (needsScrollView) rnImports.push('ScrollView');
  if (hasType(screen.rootComponent, 'EditText')) rnImports.push('TextInput');
  if (hasType(screen.rootComponent, 'Switch')) rnImports.push('Switch');

  let extraImports = '';
  if (needsWebView) extraImports += "import { WebView } from 'react-native-webview';\n";
  if (hasType(screen.rootComponent, 'ImageView')) extraImports += "import { Ionicons } from '@expo/vector-icons';\n";

  // Generate component JSX
  const jsx = generateJSX(screen.rootComponent, 4);

  // Generate styles
  const styles = generateScreenStyles(screen.rootComponent, bgColor);

  // Generate state
  const stateVars = (project.variables || [])
    .map((v) => {
      const def =
        v.type === 'number' ? (v.value || 0) :
        v.type === 'boolean' ? (v.value || false) :
        jsString(v.value || '');
      return `  const [${v.name}, set${v.name.charAt(0).toUpperCase() + v.name.slice(1)}] = useState(${def});`;
    })
    .join('\n');

  // Generate event handlers from blocks
  const handlers = generateHandlersFromBlocks(screen);
  const hookImports = handlers ? 'useState, useEffect' : 'useState';

  const screenName = screen.name.replace(/\s/g, '') + 'Screen';

  return `import React, { ${hookImports} } from 'react';
import {
  ${rnImports.join(',\n  ')},
} from 'react-native';
${extraImports}
const ${screenName} = ({ navigation }) => {
${stateVars || '  // State'}

${handlers}  return (
    <View style={styles.container}>
${jsx}
    </View>
  );
};

${styles}

export default ${screenName};
`;
};

const hasType = (comp, type) => {
  if (!comp) return false;
  if (comp.type === type) return true;
  if (comp.children) return comp.children.some((c) => hasType(c, type));
  return false;
};

const generateJSX = (component, indent) => {
  if (!component) return '';
  const sp = ' '.repeat(indent);
  const props = component.props || {};
  const styleName = `styles.c_${component.id?.slice(0, 8) || 'root'}`;

  switch (component.type) {
    case 'LinearLayout':
      return `${sp}<View style={${styleName}}>
${(component.children || []).map((c) => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;

    case 'ScrollView':
      return `${sp}<ScrollView style={${styleName}} showsVerticalScrollIndicator={false}>
${(component.children || []).map((c) => generateJSX(c, indent + 2)).join('\n')}
${sp}</ScrollView>`;

    case 'CardView':
      return `${sp}<View style={${styleName}}>
${(component.children || []).map((c) => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;

    case 'TextView':
      return `${sp}<Text style={${styleName}}>{${jsString(props.text || '')}}</Text>`;

    case 'Button': {
      const label = jsString(props.text || 'Button');
      return `${sp}<TouchableOpacity style={${styleName}} onPress={() => Alert.alert(${label}, 'Нажато!')}>
${sp}  <Text style={${styleName}_text}>{${label}}</Text>
${sp}</TouchableOpacity>`;
    }

    case 'EditText':
      return `${sp}<TextInput style={${styleName}} placeholder={${jsString(props.hint || '')}} placeholderTextColor="#888" />`;

    case 'ImageView':
      return `${sp}<View style={${styleName}}>
${sp}  <Ionicons name="image-outline" size={32} color="#64748B" />
${sp}</View>`;

    case 'CheckBox':
      return `${sp}<TouchableOpacity style={${styleName}} onPress={() => {}}>
${sp}  <View style={[${styleName}_box]} />
${sp}  <Text style={{ color: '#fff', marginLeft: 8 }}>{${jsString(props.text || 'CheckBox')}}</Text>
${sp}</TouchableOpacity>`;

    case 'Switch':
      return `${sp}<View style={${styleName}}>
${sp}  <Text style={{ color: '#fff' }}>{${jsString(props.text || 'Switch')}}</Text>
${sp}  <Switch value={false} onValueChange={() => {}} />
${sp}</View>`;

    case 'ProgressBar':
      return `${sp}<View style={${styleName}}>
${sp}  <View style={[${styleName}_fill, { width: '${props.progress || 50}%' }]} />
${sp}</View>`;

    case 'Divider':
      return `${sp}<View style={${styleName}} />`;

    case 'Spacer':
      return `${sp}<View style={${styleName}} />`;

    case 'WebView':
      return `${sp}<WebView source={{ uri: ${jsString(props.url || 'https://example.com')} }} style={${styleName}} />`;

    default:
      return `${sp}<View style={${styleName}} />`;
  }
};

const generateScreenStyles = (rootComponent, bgColor) => {
  const styles = [];

  styles.push(`const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '${bgColor}',
    padding: ${rootComponent?.props?.padding || 16},
  },`);

  collectStyles(rootComponent, styles);

  styles.push('});');
  return styles.join('\n');
};

const collectStyles = (comp, styles) => {
  if (!comp) return;
  const props = comp.props || {};
  const key = `c_${comp.id?.slice(0, 8) || 'root'}`;

  switch (comp.type) {
    case 'LinearLayout':
    case 'CardView':
      styles.push(`  ${key}: {
    flexDirection: '${props.orientation === 'horizontal' ? 'row' : 'column'}',
    ${dimStyle('width', props.width)}${dimStyle('height', props.height)}padding: ${props.padding || 0},
    backgroundColor: '${props.backgroundColor || 'transparent'}',
    borderRadius: ${props.borderRadius || 0},
${props.elevation ? `    elevation: ${props.elevation},
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
` : ''}  },`);
      break;
    case 'ScrollView':
      styles.push(`  ${key}: { flex: 1 },`);
      break;
    case 'TextView':
      styles.push(`  ${key}: {
    fontSize: ${props.textSize || 16},
    color: '${props.textColor || '#fff'}',
    fontWeight: '${props.textStyle === 'bold' ? 'bold' : 'normal'}',
    textAlign: '${props.gravity || 'left'}',
    padding: ${props.padding || 0},
  },`);
      break;
    case 'Button':
      styles.push(`  ${key}: {
    backgroundColor: '${props.backgroundColor || '#BB86FC'}',
    padding: ${props.padding || 14},
    borderRadius: ${props.borderRadius || 8},
    alignItems: 'center',
    marginVertical: 6,
  },
  ${key}_text: {
    color: '${props.textColor || '#fff'}',
    fontSize: ${props.textSize || 16},
    fontWeight: 'bold',
  },`);
      break;
    case 'EditText':
      styles.push(`  ${key}: {
    backgroundColor: '${props.backgroundColor || '#2C2C2C'}',
    padding: ${props.padding || 12},
    borderRadius: ${props.borderRadius || 8},
    color: '${props.textColor || '#fff'}',
    fontSize: ${props.textSize || 16},
    marginVertical: 6,
    borderWidth: 1,
    borderColor: '#444',
  },`);
      break;
    case 'ImageView':
      styles.push(`  ${key}: {
    width: ${typeof props.width === 'number' ? props.width : 100},
    height: ${typeof props.height === 'number' ? props.height : 100},
    backgroundColor: '${props.backgroundColor || '#333'}',
    borderRadius: ${props.borderRadius || 0},
    justifyContent: 'center',
    alignItems: 'center',
  },`);
      break;
    case 'CheckBox':
      styles.push(`  ${key}: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  ${key}_box: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#BB86FC',
    borderRadius: 4,
  },`);
      break;
    case 'Switch':
      styles.push(`  ${key}: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },`);
      break;
    case 'ProgressBar':
      styles.push(`  ${key}: {
    height: 8,
    backgroundColor: '#333',
    borderRadius: 4,
    overflow: 'hidden',
    marginVertical: 8,
  },
  ${key}_fill: {
    height: '100%',
    backgroundColor: '${props.color || '#BB86FC'}',
    borderRadius: 4,
  },`);
      break;
    case 'Divider':
      styles.push(`  ${key}: {
    height: ${props.height || 1},
    backgroundColor: '${props.backgroundColor || '#444'}',
    margin: ${props.margin || 8},
  },`);
      break;
    case 'Spacer':
      styles.push(`  ${key}: { height: ${props.height || 16} },`);
      break;
    case 'WebView':
      styles.push(`  ${key}: {
    width: '100%',
    height: ${props.height || 300},
    borderRadius: 8,
    overflow: 'hidden',
  },`);
      break;
  }

  if (comp.children) comp.children.forEach((c) => collectStyles(c, styles));
};

const dimStyle = (key, val) => {
  if (val === 'match_parent') return `${key}: '100%',\n    `;
  if (typeof val === 'number') return `${key}: ${val},\n    `;
  return '';
};

const generateHandlersFromBlocks = (screen) => {
  const blocks = screen.blocks || [];
  let code = '';

  const onCreate = blocks.find((b) => b.definitionId === 'on_create');
  if (onCreate?.children?.next) {
    code += `  useEffect(() => {\n`;
    onCreate.children.next.forEach((action) => {
      if (action.definitionId === 'show_toast') {
        code += `    Alert.alert('Сообщение', ${jsString(action.inputs?.text || '')});\n`;
      }
    });
    code += `  }, []);\n\n`;
  }

  return code;
};

export default generateFullProject;

