/**
 * ShellExecutor — bridge к Termux + AptManager.
 */
let apt = null;
let termux = null;

try { apt = require('../../modules/apt-manager/src/index'); } catch (e) {}
try { termux = require('../../modules/termux-terminal/src/index'); } catch (e) {}

// ═══ Совместимость с BuildScreen ═══

export const isAvailable = () => {
  return (apt?.isAvailable?.() || false) || (termux?.isAvailable?.() || false);
};

export const hasShell = () => termux?.isAvailable?.() || false;
export const hasApt = () => apt?.isAvailable?.() || false;

// Execute shell command
export const execute = async (cmd, workDir) => {
  if (termux?.execute) return await termux.execute(cmd, workDir);
  return { success: false, exitCode: -1, output: 'Shell not available (need dev build)' };
};

// Check if command exists
export const checkCommand = async (cmd) => {
  if (apt?.whichCommand) {
    const result = await apt.whichCommand(cmd);
    if (result.exists) return result;
  }
  if (termux?.checkCommand) return await termux.checkCommand(cmd);
  return { exists: false, path: '' };
};

// Get Node.js version
export const getNodeVersion = async () => {
  if (termux?.getNodeVersion) return await termux.getNodeVersion();
  return { version: null, path: '' };
};

// Install Node.js — через AptManager (Termux repo)
export const installNode = async () => {
  const log = [];

  // Способ 1: AptManager (Termux repo)
  if (apt?.install) {
    log.push('Installing via apt (Termux repo)...');
    const result = await apt.install('nodejs');
    if (result.success) {
      // Проверяем версию
      const ver = await getNodeVersion();
      return { success: true, output: (log.join('\n') + '\n' + (result.output || '')), version: ver.version };
    }
    log.push('apt install failed, trying alternatives...');
  }

  // Способ 2: pkg (Termux)
  if (termux?.execute) {
    const pkgCheck = await termux.execute('which pkg 2>/dev/null');
    if (pkgCheck.success && pkgCheck.output.trim()) {
      log.push('Installing via Termux pkg...');
      const result = await termux.execute('pkg install -y nodejs 2>&1');
      const ver = await getNodeVersion();
      if (ver.version) {
        return { success: true, output: log.join('\n') + '\n' + (result.output || ''), version: ver.version };
      }
    }
  }

  // Способ 3: apt-get
  if (termux?.execute) {
    const aptCheck = await termux.execute('which apt-get 2>/dev/null');
    if (aptCheck.success && aptCheck.output.trim()) {
      log.push('Installing via apt-get...');
      const result = await termux.execute('apt-get update -qq && apt-get install -y nodejs npm 2>&1');
      const ver = await getNodeVersion();
      if (ver.version) {
        return { success: true, output: log.join('\n') + '\n' + (result.output || ''), version: ver.version };
      }
    }
  }

  return { success: false, output: log.join('\n') + '\nNode.js installation failed.', version: null };
};

// Install EAS CLI
export const installEas = async () => {
  if (termux?.execute) {
    return await termux.execute('npm install -g eas-cli 2>&1');
  }
  return { success: false, output: 'Shell not available' };
};

// ═══ Apt API ═══
export const aptInstall = async (pkg) => apt?.install?.(pkg) || { success: false, output: 'Not available' };
export const aptSearch = async (q) => apt?.search?.(q) || { success: false, error: 'Not available' };
export const aptInfo = async (pkg) => apt?.info?.(pkg) || { success: false, error: 'Not available' };
export const aptRemove = async (pkg) => apt?.remove?.(pkg) || { success: false, output: 'Not available' };
export const aptListInstalled = async () => apt?.listInstalled?.() || [];
export const aptGetPrefix = async () => apt?.getPrefix?.() || { prefix: '' };
export const aptPatchAll = async () => apt?.patchAll?.() || { success: false, output: 'Not available' };
export const aptReinstall = async (pkg) => {
  if (!apt) return { success: false, output: 'Not available' };
  await apt.reinstall(pkg);
  return await apt.install(pkg);
};
