/** Native shell bridge used by the Ubuntu Android/Gradle workspace. */
let apt = null;
let termux = null;
try { apt = require('../../modules/apt-manager/src/index'); } catch (error) {}
try { termux = require('../../modules/termux-terminal/src/index'); } catch (error) {}

export const isAvailable = () => Boolean(apt?.isAvailable?.() || termux?.isAvailable?.());
export const hasShell = () => Boolean(termux?.isAvailable?.());
export const hasApt = () => Boolean(apt?.isAvailable?.());
export const execute = async (command, workDir) => termux?.execute
  ? termux.execute(command, workDir)
  : { success: false, exitCode: -1, output: 'Native Ubuntu shell is unavailable' };
export const checkCommand = async (command) => {
  if (termux?.checkCommand) return termux.checkCommand(command);
  if (apt?.whichCommand) return apt.whichCommand(command);
  return { exists: false, path: '' };
};

export const inspectAndroidToolchain = async () => {
  const result = await execute(`
set +e
printf 'java='; java -version 2>&1 | head -1
printf 'javac='; javac -version 2>&1 | head -1
printf 'android_home='; printf '%s\\n' "\${ANDROID_HOME:-\${ANDROID_SDK_ROOT:-}}"
printf 'sdkmanager='; command -v sdkmanager || true
printf 'adb='; command -v adb || true
printf 'gradle='; command -v gradle || true
`);
  return { success: result.success, output: result.output || '' };
};

export const aptInstall = async (pkg) => apt?.install?.(pkg) || { success: false, output: 'Not available' };
export const aptSearch = async (query) => apt?.search?.(query) || { success: false, output: 'Not available' };
export const aptInfo = async (pkg) => apt?.info?.(pkg) || { success: false, output: 'Not available' };
export const aptRemove = async (pkg) => apt?.remove?.(pkg) || { success: false, output: 'Not available' };
export const aptListInstalled = async () => apt?.listInstalled?.() || [];
export const aptGetPrefix = async () => apt?.getPrefix?.() || { prefix: '' };
