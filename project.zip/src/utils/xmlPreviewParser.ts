/**
 * XML Layout Preview Parser
 *
 * Парсит XML layout-файлы Android и сопутствующие values/colors.xml,
 * values/strings.xml, чтобы подготовить данные для нативного предпросмотра.
 */

export interface ParsedXmlColors {
  [name: string]: string;
}

export interface ParsedXmlStrings {
  [name: string]: string;
}

export interface XmlPreviewData {
  layoutXml: string;
  colors: ParsedXmlColors;
  strings: ParsedXmlStrings;
  themes: ParsedXmlThemes;
}

export interface ParsedXmlThemes {
  [name: string]: Record<string, string>;
}

/**
 * Простой парсер Android XML-ресурсов (без зависимостей)
 */
export function parseAndroidXml(xmlContent: string): DocumentLike | null {
  try {
    // Убираем XML-декларацию и комментарии
    let content = xmlContent.replace(/<\?xml[^?]*\?>/g, '').trim();
    content = content.replace(/<!--[\s\S]*?-->/g, '');

    const parser = new SimpleXmlParser();
    return parser.parse(content);
  } catch (e) {
    console.warn('XML parse error:', e);
    return null;
  }
}

interface DocumentLike {
  root: XmlNode;
}

interface XmlNode {
  tag: string;
  attrs: Record<string, string>;
  children: XmlNode[];
  text: string;
}

class SimpleXmlParser {
  private pos = 0;
  private xml = '';

  parse(xml: string): DocumentLike {
    this.xml = xml;
    this.pos = 0;
    const root = this.parseNode();
    if (!root) throw new Error('No root element found');
    return { root };
  }

  private skipWhitespace() {
    while (this.pos < this.xml.length && /\s/.test(this.xml[this.pos])) {
      this.pos++;
    }
  }

  private parseNode(): XmlNode | null {
    this.skipWhitespace();
    if (this.pos >= this.xml.length || this.xml[this.pos] !== '<') return null;

    // Пропускаем закрывающий тег
    if (this.xml[this.pos + 1] === '/') return null;

    this.pos++; // consume <
    const tag = this.parseName();
    const attrs = this.parseAttributes();

    this.skipWhitespace();

    // Self-closing tag
    if (this.xml[this.pos] === '/') {
      this.pos++; // consume /
      if (this.xml[this.pos] === '>') this.pos++;
      return { tag, attrs, children: [], text: '' };
    }

    if (this.xml[this.pos] === '>') {
      this.pos++; // consume >
    } else {
      return { tag, attrs, children: [], text: '' };
    }

    const children: XmlNode[] = [];
    let text = '';

    while (this.pos < this.xml.length) {
      this.skipWhitespace();
      if (this.pos >= this.xml.length) break;

      if (this.xml[this.pos] === '<') {
        if (this.xml[this.pos + 1] === '/') {
          // Закрывающий тег
          while (this.pos < this.xml.length && this.xml[this.pos] !== '>') this.pos++;
          if (this.pos < this.xml.length) this.pos++;
          break;
        } else {
          const child = this.parseNode();
          if (child) children.push(child);
        }
      } else {
        // Текст
        const textStart = this.pos;
        while (this.pos < this.xml.length && this.xml[this.pos] !== '<') {
          this.pos++;
        }
        text += this.xml.substring(textStart, this.pos).trim();
      }
    }

    return { tag, attrs, children, text };
  }

  private parseName(): string {
    const start = this.pos;
    while (this.pos < this.xml.length && /[a-zA-Z0-9_:.-]/.test(this.xml[this.pos])) {
      this.pos++;
    }
    return this.xml.substring(start, this.pos);
  }

  private parseAttributes(): Record<string, string> {
    const attrs: Record<string, string> = {};

    while (this.pos < this.xml.length) {
      this.skipWhitespace();

      if (this.xml[this.pos] === '>' || this.xml[this.pos] === '/' || this.pos >= this.xml.length) {
        break;
      }

      const name = this.parseName();
      if (!name) break;

      this.skipWhitespace();
      if (this.xml[this.pos] === '=') {
        this.pos++;
        this.skipWhitespace();
        const quote = this.xml[this.pos];
        if (quote === '"' || quote === "'") {
          this.pos++;
          const valStart = this.pos;
          while (this.pos < this.xml.length && this.xml[this.pos] !== quote) {
            this.pos++;
          }
          attrs[name] = this.xml.substring(valStart, this.pos);
          if (this.pos < this.xml.length) this.pos++;
        }
      }
    }

    return attrs;
  }
}

/**
 * Парсит colors.xml в карту name -> hex color
 */
export function parseColorsXml(xmlContent: string): ParsedXmlColors {
  const colors: ParsedXmlColors = {};
  const doc = parseAndroidXml(xmlContent);
  if (!doc) return colors;

  const resources = doc.root;
  if (resources.tag !== 'resources') return colors;

  function walk(node: XmlNode) {
    if (node.tag === 'color') {
      const name = node.attrs['name'];
      if (name) {
        colors[name] = node.text || '#000000';
      }
    }
    for (const child of node.children) {
      walk(child);
    }
  }

  walk(resources);
  return colors;
}

/**
 * Парсит strings.xml в карту name -> value
 */
export function parseStringsXml(xmlContent: string): ParsedXmlStrings {
  const strings: ParsedXmlStrings = {};
  const doc = parseAndroidXml(xmlContent);
  if (!doc) return strings;

  const resources = doc.root;
  if (resources.tag !== 'resources') return strings;

  function walk(node: XmlNode) {
    if (node.tag === 'string') {
      const name = node.attrs['name'];
      if (name) {
        strings[name] = node.text || '';
      }
    }
    for (const child of node.children) {
      walk(child);
    }
  }

  walk(resources);
  return strings;
}

/**
 * Разрешает ссылки вида @color/primary, @string/app_name
 */
export function resolveXmlReferences(
  value: string,
  colors: ParsedXmlColors,
  strings: ParsedXmlStrings
): string {
  if (value.startsWith('@color/')) {
    const name = value.substring('@color/'.length);
    return colors[name] || value;
  }
  if (value.startsWith('@string/')) {
    const name = value.substring('@string/'.length);
    return strings[name] || value;
  }
  return value;
}

/**
 * Подготавливает полный набор данных для предпросмотра layout
 */
export function prepareLayoutPreview(
  layoutXml: string,
  colorsXml?: string,
  stringsXml?: string,
  themesXml?: string
): XmlPreviewData {
  return {
    layoutXml,
    colors: colorsXml ? parseColorsXml(colorsXml) : defaultColors(),
    strings: stringsXml ? parseStringsXml(stringsXml) : {},
    themes: {}
  };
}

function defaultColors(): ParsedXmlColors {
  return {
    primary: '#6200EE',
    primary_variant: '#3700B3',
    secondary: '#03DAC6',
    background: '#FFFFFF',
    surface: '#FFFFFF',
    on_primary: '#FFFFFF',
    on_surface: '#1C1B1F',
    on_surface_variant: '#49454F',
    error: '#B3261E',
    white: '#FFFFFF',
    black: '#000000',
    transparent: '#00000000'
  };
}

/**
 * Определяет, является ли файл layout XML для предпросмотра
 */
export function isLayoutXmlFile(filename: string): boolean {
  return /res\/layout\/.*\.xml$/.test(filename) ||
    filename.endsWith('.xml') && !/values\//.test(filename);
}

/**
 * Извлекает имя темы из layout корневого элемента
 */
export function extractThemeName(layoutXml: string): string | null {
  const match = layoutXml.match(/android:theme\s*=\s*["']@style\/([^"']+)["']/);
  return match ? match[1] : null;
}
