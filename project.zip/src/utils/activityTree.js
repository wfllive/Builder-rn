/**
 * Per-Activity Kotlin source <-> Compose Studio component tree.
 *
 * The editor is a thin view on top of the rai workspace. The
 * template that rai new writes is the source of truth; the editor
 * never invents AppTheme / Surface / state declarations that are
 * not already in the file. Parsing walks into the @Composable
 * function the Activity's setContent calls into (the standard
 * rai template uses `MainScreen()`) and surfaces that function's
 * body to the editor. Emitting replaces that function's body with
 * the new tree; everything else in the file - imports, the
 * AppTheme wrapper, the `class MainActivity`, the var x by
 * remember declarations that rai put there - is left exactly as
 * the user (or rai) wrote it.
 *
 * If a project has no MainScreen yet (e.g. a brand-new project
 * where the user only added a few components), the editor falls
 * back to emitting a minimal Activity with `setContent { <tree> }`
 * and no extra wrapping.
 */
import { execute } from './shellExecutor';
import { getSourceRoot } from '../config/runtime';
import { generateId } from './generateId';

const escape = (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

const COMPONENT_BY_KOTLIN = {
  Column: 'Column',
  Row: 'Row',
  Box: 'Box',
  LazyColumn: 'LazyColumn',
  Card: 'Card',
  ElevatedCard: 'ElevatedCard',
  Surface: 'Box',
  Text: 'Text',
  Button: 'Button',
  OutlinedButton: 'OutlinedButton',
  OutlinedTextField: 'OutlinedTextField',
  Image: 'Image',
  Checkbox: 'Checkbox',
  Switch: 'Switch',
  LinearProgressIndicator: 'LinearProgressIndicator',
  CircularProgressIndicator: 'CircularProgressIndicator',
  HorizontalDivider: 'HorizontalDivider',
  VerticalDivider: 'HorizontalDivider',
  Spacer: 'Spacer',
  Icon: 'Icon',
  TopAppBar: 'TopAppBar',
  Scaffold: 'Scaffold',
};

// Standard wrappers rai puts around the user function. We
// consider anything in this set a "transparent" call when
// resolving the user-visible root. We never emit any of these
// ourselves - if the file has them we keep them, if it does not
// we don't add them.
const WRAPPER_NAMES = new Set([
  'AppTheme',
  'MaterialTheme',
  'Surface',
  'Crossfade',
  'AnimatedVisibility',
  'BackHandler',
  'Theme',
  'ProvideWindowInsets',
]);

const splitBody = (source, openIndex, openChar, closeChar) => {
  let depth = 0;
  let inString = null;
  for (let i = openIndex; i < source.length; i++) {
    const ch = source[i];
    const prev = i > 0 ? source[i - 1] : '';
    if (inString) {
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; continue; }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) return { body: source.slice(openIndex + 1, i), start: openIndex, end: i };
    }
  }
  return { body: '', start: openIndex, end: openIndex };
};

const splitTopLevelCommas = (input) => {
  const parts = [];
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  let buffer = '';
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const prev = i > 0 ? input[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; buffer += ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    else if (ch === ',' && depth === 0 && brace === 0 && bracket === 0) {
      parts.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) parts.push(buffer.trim());
  return parts;
};

const parseNamedArgs = (raw) => {
  const args = {};
  for (const part of splitTopLevelCommas(raw)) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    args[key] = value;
  }
  return args;
};

const mapAlignment = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('centerhorizontally')) return 'center';
  if (lower.includes('centervertically')) return 'center';
  if (lower.includes('end') || lower.includes('right')) return 'end';
  if (lower.includes('bottom')) return 'bottom';
  return 'start';
};

const mapArrangement = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('spacebetween')) return 'spaceBetween';
  if (lower.includes('spacearound')) return 'spaceAround';
  if (lower.includes('spaceevenly')) return 'spaceEvenly';
  if (lower.includes('center')) return 'center';
  if (lower.includes('end') || lower.includes('bottom')) return 'end';
  return 'top';
};

const parseNumber = (value) => {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/-?\d+(\.\d+)?/);
  return match ? Number(match[0]) : undefined;
};

const parseColor = (value) => {
  if (!value) return undefined;
  const match = value.match(/#?[0-9A-Fa-f]{6,8}/);
  return match ? (match[0].startsWith('#') ? match[0] : `#${match[0]}`) : undefined;
};

const stripQuotes = (value) => {
  if (typeof value !== 'string') return value;
  if (value.length < 2) return value;
  const first = value.charAt(0);
  const last = value.charAt(value.length - 1);
  if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
    return value.slice(1, -1).replace(/\\(["'\\])/g, '$1');
  }
  return value;
};

const parseModifierChain = (raw) => {
  const out = { padding: 0, backgroundColor: undefined, borderRadius: undefined, width: undefined, height: undefined };
  if (!raw) return out;
  const lower = raw.replace(/\s+/g, '');
  const fill = /fillmax(width|height)/g;
  let m;
  while ((m = fill.exec(lower))) {
    if (m[1] === 'width') out.width = 'match_parent';
    else out.height = 'match_parent';
  }
  const padding = lower.match(/padding\(([0-9.]+)\.dp\)/);
  if (padding) out.padding = Number(padding[1]);
  const paddingHV = lower.match(/padding\(horizontal\s*=\s*([0-9.]+)\.dp\s*,\s*vertical\s*=\s*([0-9.]+)\.dp\)/);
  if (paddingHV) out.padding = Number(paddingHV[1]) + Number(paddingHV[2]);
  const paddingAll = lower.match(/padding\(all\s*=\s*([0-9.]+)\.dp\)/);
  if (paddingAll) out.padding = Number(paddingAll[1]);
  const bg = lower.match(/background\(([A-Za-z(0-9#]+)\)/);
  if (bg) out.backgroundColor = parseColor(bg[1]) || undefined;
  const radius = lower.match(/cliproundedcornershape\(([0-9.]+)\.dp\)/);
  if (radius) out.borderRadius = Number(radius[1]);
  const width = lower.match(/(?:^|[^a-z])width\(([0-9.]+)\.dp\)/);
  if (width && out.width === undefined) out.width = Number(width[1]);
  const height = lower.match(/(?:^|[^a-z])height\(([0-9.]+)\.dp\)/);
  if (height && out.height === undefined) out.height = Number(height[1]);
  const fillWidth = /fillmaxwidth\(\)/.test(lower);
  const fillHeight = /fillmaxheight\(\)/.test(lower);
  if (fillWidth) out.width = 'match_parent';
  if (fillHeight) out.height = 'match_parent';
  return out;
};

const parseProps = (raw) => {
  const named = parseNamedArgs(raw);
  const props = {};
  const modifier = parseModifierChain(named.modifier);
  Object.assign(props, modifier);
  if (named.text) props.text = stripQuotes(named.text);
  if (named.title) props.title = stripQuotes(named.title);
  if (named.label) props.label = stripQuotes(named.label);
  if (named.color) props.color = parseColor(named.color) || stripQuotes(named.color);
  if (named.backgroundcolor) props.backgroundColor = parseColor(named.backgroundcolor);
  if (named.textcolor) props.textColor = parseColor(named.textcolor);
  if (named.tint) props.tint = parseColor(named.tint);
  if (named.trackcolor) props.trackColor = parseColor(named.trackcolor);
  if (named.borderradius) props.borderRadius = parseNumber(named.borderradius);
  if (named.elevation) props.elevation = parseNumber(named.elevation);
  if (named.spacing) props.spacing = parseNumber(named.spacing);
  if (named.padding) props.padding = parseNumber(named.padding);
  if (named.size) props.size = parseNumber(named.size);
  if (named.progress) props.progress = parseNumber(named.progress);
  if (named.textsize) props.textSize = parseNumber(named.textsize);
  if (named.fontsize) props.textSize = parseNumber(named.fontsize);
  if (named.url) props.url = stripQuotes(named.url);
  if (named.hint) props.hint = stripQuotes(named.hint);
  if (named.checked) props.checked = /true/i.test(named.checked);
  if (named.enabled) props.enabled = !/false/i.test(named.enabled);
  if (named.horizontalalignment) props.horizontalAlignment = mapAlignment(named.horizontalalignment);
  if (named.verticalalignment) props.verticalAlignment = mapAlignment(named.verticalalignment);
  if (named.verticalarrangement) props.verticalArrangement = mapArrangement(named.verticalarrangement);
  if (named.horizontalarrangement) props.horizontalArrangement = mapArrangement(named.horizontalarrangement);
  if ((named.fontweight && /bold/i.test(named.fontweight)) || /bold/i.test(named.style || '')) props.textStyle = 'bold';
  if (named.textalign) {
    const t = named.textalign.toLowerCase();
    if (t.includes('center')) props.textAlign = 'center';
    else if (t.includes('end')) props.textAlign = 'end';
  }
  if (named.style && /headline/i.test(named.style)) props.textStyle = 'headline';
  return props;
};

const parseStatement = (stmt) => {
  const commentIndex = stmt.indexOf('//');
  const cleaned = commentIndex >= 0 ? stmt.slice(0, commentIndex).trim() : stmt;
  if (!cleaned) return null;
  const match = cleaned.match(/^([A-Za-z][A-Za-z0-9_.]*)\s*\(/);
  if (!match) return null;
  const simpleName = match[1].split('.').pop();
  if (['item', 'forEach', 'repeat', 'ColumnScope', 'RowScope', 'BoxScope'].includes(simpleName)) return null;
  const open = match.index + match[0].length - 1;
  const { body, end } = splitBody(cleaned, open, '(', ')');
  if (end <= open) return null;
  let argEnd = -1;
  let d = 0;
  let inStr = null;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    const prev = i > 0 ? body[i - 1] : '';
    if (inStr) { if (ch === inStr && prev !== '\\') inStr = null; continue; }
    if (ch === '"' || ch === "'") { inStr = ch; continue; }
    if (ch === '(') d++;
    else if (ch === ')') d--;
    else if (ch === '{' && d === 0) { argEnd = i; break; }
  }
  let args;
  let childrenBody;
  if (argEnd < 0) {
    args = body.trim();
    childrenBody = '';
  } else {
    args = body.slice(0, argEnd).trim();
    childrenBody = body.slice(argEnd + 1);
    if (childrenBody.endsWith('}')) childrenBody = childrenBody.slice(0, -1);
  }
  const type = COMPONENT_BY_KOTLIN[simpleName];
  if (!type) {
    return { id: generateId(), type: 'Text', props: { text: cleaned }, children: [] };
  }
  const props = parseProps(args);
  const children = parseChildrenBlock(childrenBody);
  return { id: generateId(), type, props, children };
};

const parseChildrenBlock = (block) => {
  if (!block) return [];
  const statements = [];
  let buffer = '';
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  for (let i = 0; i < block.length; i++) {
    const ch = block[i];
    const prev = i > 0 ? block[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; buffer += ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    if (ch === '\n' && depth === 0 && brace === 0 && bracket === 0) {
      if (buffer.trim()) statements.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) statements.push(buffer.trim());
  const children = [];
  for (const stmt of statements) {
    const child = parseStatement(stmt);
    if (child) children.push(child);
  }
  return children;
};

const emptyTree = () => ({
  id: generateId(),
  type: 'Column',
  props: { width: 'match_parent', height: 'match_parent', padding: 0, spacing: 0, backgroundColor: 'transparent' },
  children: [],
});

/**
 * Find the body of a top-level @Composable fun <Name>(...) { ... }.
 * Returns { name, params, body, bodyStart, bodyEnd, sigStart } or null.
 * `bodyStart` and `bodyEnd` are indices in `source` of the opening
 * and closing braces of the body, so the caller can splice a new
 * body in place without re-emitting the rest of the file.
 */
const findComposableFunction = (source, name) => {
  const sig = new RegExp(`@Composable(?:\\s+@?[A-Za-z.()]+)*\\s*(?:public\\s+|private\\s+|internal\\s+)?fun\\s+${name}\\s*\\(`, 'g');
  let m;
  while ((m = sig.exec(source))) {
    const open = m.index + m[0].length - 1;
    const parsed = splitBody(source, open, '(', ')');
    if (parsed.end > open) {
      let idx = parsed.end + 1;
      while (idx < source.length && /\s/.test(source[idx])) idx++;
      if (source[idx] === ':') {
        const colonIdx = idx;
        let depth = 0;
        for (let i = colonIdx + 1; i < source.length; i++) {
          const ch = source[i];
          if (ch === '{' || ch === '(' || ch === '[') depth++;
          else if (ch === '}' || ch === ')' || ch === ']') depth--;
          else if (ch === '{' && depth === 0) { idx = i; break; }
          if (ch === '\n' && i - colonIdx > 200) { idx = -1; break; }
        }
        if (idx < 0) continue;
      }
      if (source[idx] !== '{') continue;
      const bodyParsed = splitBody(source, idx, '{', '}');
      if (bodyParsed.end > idx) {
        return {
          name,
          params: parsed.body,
          body: bodyParsed.body,
          bodyStart: idx,
          bodyEnd: bodyParsed.end,
          sigStart: m.index,
        };
      }
    }
  }
  return null;
};

const findSetContent = (source) => {
  const re = /\bsetContent\s*\(/g;
  let m;
  while ((m = re.exec(source))) {
    const open = m.index + m[0].length - 1;
    const parsed = splitBody(source, open, '(', ')');
    if (parsed.end > open) return { body: parsed.body, start: open, end: parsed.end };
  }
  return null;
};

const findFirstCallInBody = (body) => {
  const trimmed = body.trim();
  if (!trimmed) return null;
  const match = trimmed.match(/^([A-Za-z][A-Za-z0-9_.]*)\s*\(/);
  if (!match) return null;
  const name = match[1].split('.').pop();
  const open = match.index + match[0].length - 1;
  const parsed = splitBody(trimmed, open, '(', ')');
  if (parsed.end <= open) return null;
  let idx = parsed.end + 1;
  while (idx < trimmed.length && /\s/.test(trimmed[idx])) idx++;
  let lambdaBody = '';
  if (trimmed[idx] === '{') {
    const lambda = splitBody(trimmed, idx, '{', '}');
    if (lambda.end > idx) lambdaBody = lambda.body;
  }
  return { kind: 'call', name, lambdaBody };
};

/**
 * Walk the setContent body, peeling off wrapper calls (AppTheme,
 * Surface, ...) until we either hit a call to a top-level
 * @Composable function defined in the same file (return
 * { kind: 'user-function', name }) or a built-in Composable call
 * (return { kind: 'root-call', name, lambdaBody, callText }).
 * `user-function` is the standard rai template shape; `root-call`
 * is the fallback when the file has nothing but a Column { ... }
 * inside setContent.
 */
const resolveRoot = (source, setContentBody) => {
  let currentBody = setContentBody;
  for (let depth = 0; depth < 8; depth++) {
    const first = findFirstCallInBody(currentBody);
    if (!first) return null;
    if (WRAPPER_NAMES.has(first.name)) {
      if (!first.lambdaBody) return null;
      currentBody = first.lambdaBody;
      continue;
    }
    if (/^[A-Z]/.test(first.name)) {
      const def = findComposableFunction(source, first.name);
      if (def) return { kind: 'user-function', name: first.name, def };
      return { kind: 'root-call', name: first.name, callText: currentBody };
    }
    return { kind: 'root-call', name: first.name, callText: currentBody };
  }
  return null;
};

/**
 * Parse a *Activity.kt file. Returns the editor tree that
 * corresponds to the user-visible content of the Activity. If
 * the file has a MainScreen / AuthScreen / ... function that
 * setContent calls into, that function's body is the tree. If
 * not, the children of setContent are the tree.
 */
export const parseActivitySource = (source) => {
  if (!source) return { tree: emptyTree(), rootName: null, hasUserFunction: false };
  const setContent = findSetContent(source);
  if (!setContent) return { tree: emptyTree(), rootName: null, hasUserFunction: false };
  const resolved = resolveRoot(source, setContent.body);
  if (!resolved) return { tree: emptyTree(), rootName: null, hasUserFunction: false };
  if (resolved.kind === 'user-function') {
    const children = parseChildrenBlock(resolved.def.body);
    let tree;
    if (children.length === 1) tree = children[0];
    else if (children.length > 1) {
      tree = {
        id: generateId(),
        type: 'Column',
        props: { width: 'match_parent', height: 'wrap_content', padding: 0, spacing: 0, backgroundColor: 'transparent' },
        children,
      };
    } else tree = emptyTree();
    return { tree, rootName: resolved.def.name, hasUserFunction: true };
  }
  const children = parseChildrenBlock(setContent.body);
  let tree;
  if (children.length === 1) tree = children[0];
  else if (children.length > 1) {
    tree = {
      id: generateId(),
      type: 'Column',
      props: { width: 'match_parent', height: 'wrap_content', padding: 0, spacing: 0, backgroundColor: 'transparent' },
      children,
    };
  } else tree = emptyTree();
  return { tree, rootName: resolved.name || null, hasUserFunction: false };
};

const propToModifier = (key, value) => {
  switch (key) {
    case 'width':
      if (value === 'match_parent') return 'fillMaxWidth()';
      if (value === 'wrap_content') return null;
      return `width(${value}.dp)`;
    case 'height':
      if (value === 'match_parent') return 'fillMaxHeight()';
      if (value === 'wrap_content') return null;
      return `height(${value}.dp)`;
    case 'padding': return `padding(${value}.dp)`;
    case 'backgroundColor': return `background(composeColor("${escape(value)}"))`;
    case 'borderRadius': return `clip(RoundedCornerShape(${value}.dp))`;
    default: return null;
  }
};

const buildModifier = (props = {}) => {
  const calls = [];
  for (const [key, value] of Object.entries(props)) {
    if (key === 'children' || value === undefined || value === null) continue;
    const expr = propToModifier(key, value);
    if (expr) calls.push(expr);
  }
  if (!calls.length) return 'Modifier';
  return `Modifier.${calls.join('.')}`;
};

const componentToKotlin = (node, depth) => {
  if (!node) return '';
  const indent = '    '.repeat(depth);
  const props = node.props || {};
  const children = node.children || [];
  switch (node.type) {
    case 'Column': {
      const hAlign = props.horizontalAlignment === 'center' ? 'Alignment.CenterHorizontally'
        : props.horizontalAlignment === 'end' ? 'Alignment.End' : 'Alignment.Start';
      const vArrange = props.spacing ? `Arrangement.spacedBy(${props.spacing}.dp)` : 'Arrangement.Top';
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Column(modifier = ${buildModifier(props)}, horizontalAlignment = ${hAlign}, verticalArrangement = ${vArrange}) {\n${inner}\n${indent}}`;
    }
    case 'Row': {
      const hArrange = props.spacing ? `Arrangement.spacedBy(${props.spacing}.dp)` : 'Arrangement.Start';
      const vAlign = props.verticalAlignment === 'center' ? 'Alignment.CenterVertically'
        : props.verticalAlignment === 'bottom' ? 'Alignment.Bottom' : 'Alignment.Top';
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Row(modifier = ${buildModifier(props)}, horizontalArrangement = ${hArrange}, verticalAlignment = ${vAlign}) {\n${inner}\n${indent}}`;
    }
    case 'Box': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Box(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'LazyColumn': {
      const items = children.map((c) => `${indent}    item {\n${componentToKotlin(c, depth + 2)}\n${indent}    }`).join('\n');
      return `${indent}LazyColumn(modifier = ${buildModifier(props)}) {\n${items}\n${indent}}`;
    }
    case 'Card': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Card(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'ElevatedCard': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}ElevatedCard(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'Scaffold': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Scaffold(modifier = ${buildModifier(props)}) { padding ->\n${inner}\n${indent}}`;
    }
    case 'TopAppBar': {
      const title = escape(props.title || 'MyApp');
      return `${indent}TopAppBar(title = { Text("${title}") })`;
    }
    case 'Text': {
      const text = escape(props.text || '');
      const size = props.textSize ? `, fontSize = ${props.textSize}.sp` : '';
      const weight = props.textStyle === 'bold' ? ', fontWeight = FontWeight.Bold' : '';
      const color = props.textColor ? `, color = composeColor("${escape(props.textColor)}")` : '';
      const align = props.textAlign === 'center' ? ', textAlign = TextAlign.Center'
        : props.textAlign === 'end' ? ', textAlign = TextAlign.End' : '';
      const style = props.textStyle === 'headline' ? ', style = MaterialTheme.typography.headlineSmall' : '';
      return `${indent}Text(text = "${text}"${size}${weight}${color}${align}${style})`;
    }
    case 'Button': {
      const text = escape(props.text || '');
      const bg = props.backgroundColor ? `, colors = ButtonDefaults.buttonColors(containerColor = composeColor("${escape(props.backgroundColor)}"))` : '';
      return `${indent}Button(onClick = {}, modifier = ${buildModifier(props)}${bg}) { Text("${text}") }`;
    }
    case 'OutlinedButton': {
      const text = escape(props.text || '');
      return `${indent}OutlinedButton(onClick = {}, modifier = ${buildModifier(props)}) { Text("${text}") }`;
    }
    case 'OutlinedTextField': {
      const label = props.label ? `, label = { Text("${escape(props.label)}") }` : '';
      const hint = props.hint ? `, placeholder = { Text("${escape(props.hint)}") }` : '';
      const value = escape(props.text || '');
      return `${indent}OutlinedTextField(value = "${value}", onValueChange = {}, modifier = ${buildModifier(props)}${label}${hint})`;
    }
    case 'Image': {
      const w = props.width || 120;
      const h = props.height || 120;
      return `${indent}Box(modifier = Modifier.size(${w}.dp, ${h}.dp).background(composeColor("${escape(props.backgroundColor || '#E5E7EB')}")), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, contentDescription = null) }`;
    }
    case 'Checkbox': {
      const text = escape(props.text || '');
      return `${indent}Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = ${Boolean(props.checked)}, onCheckedChange = {}); Text("${text}") }`;
    }
    case 'Switch': {
      const text = escape(props.text || '');
      return `${indent}Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("${text}"); Switch(checked = ${Boolean(props.checked)}, onCheckedChange = {}) }`;
    }
    case 'LinearProgressIndicator': {
      const value = Number(props.progress) || 0.5;
      return `${indent}LinearProgressIndicator(progress = ${value.toFixed(2)}f, modifier = ${buildModifier(props)})`;
    }
    case 'CircularProgressIndicator': {
      return `${indent}CircularProgressIndicator(modifier = ${buildModifier(props)})`;
    }
    case 'HorizontalDivider': {
      return `${indent}HorizontalDivider(thickness = ${(props.height || 1)}.dp${props.color ? `, color = composeColor("${escape(props.color)}")` : ''})`;
    }
    case 'Spacer': {
      return `${indent}Spacer(modifier = Modifier.height(${props.height || 16}.dp))`;
    }
    case 'Icon': {
      return `${indent}Icon(Icons.Default.${props.iconName || 'Favorite'}, contentDescription = null, modifier = Modifier.size(${props.size || 28}.dp), tint = composeColor("${escape(props.tint || '#4F46E5')}"))`;
    }
    default:
      return `${indent}Text("${escape(node.type || 'Unknown')}")`;
  }
};

/**
 * The editor never invents boilerplate. The rai template (or the
 * user) decides what the *Activity.kt file looks like. The editor
 * reads the file, finds the user-visible Composable, and replaces
 * only that body. If the file has no Composable yet (a fresh,
 * empty Activity created by the + button), the editor emits a
 * minimal Activity with setContent { <tree> } and nothing else -
 * no AppTheme wrapper, no remember state, no var counter.
 *
 * Returns { source, replaced, rootName }. If `replaced` is true
 * the source has been updated in place; the caller can just write
 * it back to disk. If `replaced` is false the file was not in a
 * shape the editor can edit (e.g. no setContent at all) and the
 * caller should leave the file alone.
 */
export const updateActivitySource = (originalSource, screen) => {
  if (!originalSource) return { source: originalSource, replaced: false, rootName: null };
  const tree = screen.rootComponent || emptyTree();
  const setContent = findSetContent(originalSource);
  if (!setContent) return { source: originalSource, replaced: false, rootName: null };
  const resolved = resolveRoot(originalSource, setContent.body);
  if (resolved && resolved.kind === 'user-function') {
    const def = resolved.def;
    const newBody = componentToKotlin(tree, 1);
    const newSource = originalSource.slice(0, def.bodyStart + 1)
      + '\n' + newBody + '\n'
      + originalSource.slice(def.bodyEnd);
    return { source: newSource, replaced: true, rootName: def.name };
  }
  // No user function: replace the entire body of setContent with
  // a single call to the tree. The wrapper code around setContent
  // (the AppTheme / Surface boilerplate, the class declaration,
  // imports) is left untouched.
  const inner = componentToKotlin(tree, 4);
  const newBody = ` {\n${inner}\n        }`;
  const newSource = originalSource.slice(0, setContent.start)
    + 'setContent' + newBody
    + originalSource.slice(setContent.end + 1);
  return { source: newSource, replaced: true, rootName: null };
};

/**
 * Compatibility shim: callers that want a brand-new *Activity.kt
 * file (e.g. the + button in the editor) can still get one.
 * The result is intentionally minimal: just the class, the
 * onCreate, and a setContent { <tree> } - no AppTheme, no Surface,
 * no MainScreen, no var counter. The rai template that the user
 * actually wants lives in their first project; subsequent edits
 * patch it, not this stub.
 */
export const buildActivitySource = (screen, project) => {
  const pkg = project?.packageName || 'com.example.app';
  const activityName = screen.name;
  const tree = screen.rootComponent || emptyTree();
  const inner = componentToKotlin(tree, 3);
  return `package ${pkg}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

class ${activityName}Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
${inner}
        }
    }
}
`;
};

/**
 * Add or update an `<activity>` entry in AndroidManifest.xml.
 */
export const upsertActivityInManifest = (manifestText, packageName, activityNames) => {
  if (!manifestText) return manifestText;
  const applicationStart = manifestText.indexOf('<application');
  if (applicationStart < 0) return manifestText;
  const applicationEnd = manifestText.lastIndexOf('</application>');
  if (applicationEnd < 0) return manifestText;
  const openTagMatch = manifestText.slice(applicationStart).match(/<application[^>]*>/);
  if (!openTagMatch) return manifestText;
  const openTag = openTagMatch[0];
  const inner = manifestText.slice(applicationStart + openTag.length, applicationEnd);
  const stripped = inner.replace(/<activity[\s\S]*?<\/activity>|<activity[^>]*\/>/g, '');
  const newActivities = activityNames.map((name, index) => {
    const isMain = index === 0;
    const filter = isMain
      ? `\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>`
      : '';
    return `        <activity\n            android:name=".${name}Activity"${filter}\n            android:exported="true" />`;
  }).join('\n');
  const newApplication = `${openTag}\n${stripped.trim() ? stripped + '\n' : ''}${newActivities}\n    </application>`;
  return manifestText.slice(0, applicationStart) + newApplication + manifestText.slice(applicationEnd + '</application>'.length);
};

/**
 * Pull the current list of `*Activity.kt` files from the rai
 * project and parse each into an editor screen record.
 */
export const loadRaiActivities = async (project) => {
  if (!project) return [];
  const sourceRoot = getSourceRoot(project);
  const result = await execute(
    `find ${sourceRoot} -maxdepth 1 -name '*Activity.kt' -type f 2>/dev/null | sort`,
    project.projectDir,
  );
  const files = (result.output || '').split('\n').map((line) => line.trim()).filter(Boolean);
  const activities = [];
  const { readWorkspaceFile } = await import('./workspace');
  for (const filePath of files) {
    const nameMatch = filePath.match(/\/([A-Za-z0-9_]+)Activity\.kt$/);
    if (!nameMatch) continue;
    const activityName = nameMatch[1];
    const relative = filePath.startsWith(sourceRoot) ? filePath : filePath;
    const read = await readWorkspaceFile(project, relative);
    if (!read.success) continue;
    const parsed = parseActivitySource(read.output);
    activities.push({
      id: `act-${activityName.toLowerCase()}`,
      name: activityName,
      fileName: `${activityName}Activity.kt`,
      packagePath: '',
      rootComponent: parsed.tree,
      source: read.output,
      blocks: [],
    });
  }
  return activities;
};
