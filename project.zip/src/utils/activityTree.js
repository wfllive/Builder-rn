/**
 * Per-Activity Kotlin source <-> Compose Studio component tree.
 *
 * The editor is a view on top of the rai workspace. For every
 * `*Activity.kt` file we read, we find the @Composable function the
 * Activity's `setContent { ... }` calls into, parse that function's
 * body into the editor's tree, and on sync regenerate the same
 * file from the tree. The function's `var x by remember { ... }`
 * state declarations are kept as a side table; the editor shows the
 * tree and stores the state in the screen record, so that adding a
 * "counter" to the screen and renaming the variable in the code
 * round-trips correctly.
 *
 * The standard rai new template (MainActivity.kt with a MainScreen
 * composable wrapping a Scaffold + Column + Text/Rows) parses into
 * a single Column tree, which is exactly what the editor wants to
 * show. Anything more exotic - arbitrary @Composable calls, raw
 * expressions like `Build.SUPPORTED_ABIS.joinToString(", ")` - is
 * surfaced as a Text node carrying the original Kotlin so the user
 * can still see it; the editor does not silently drop information.
 */
import { execute } from './shellExecutor';
import { getSourceRoot } from '../config/runtime';
import { generateId } from './generateId';

const escape = (value) => String(value ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

const COMPONENT_BY_KOTLIN = {
  Column: 'Column',
  Row: 'Row',
  Box: 'Box',
  LazyColumn: 'LazyColumn',
  Card: 'Card',
  ElevatedCard: 'ElevatedCard',
  Surface: 'Box',
  Text: 'Text',
  Button: 'Button',
  OutlinedButton: 'OutlinedButton',
  OutlinedTextField: 'OutlinedTextField',
  Image: 'Image',
  Checkbox: 'Checkbox',
  Switch: 'Switch',
  LinearProgressIndicator: 'LinearProgressIndicator',
  CircularProgressIndicator: 'CircularProgressIndicator',
  HorizontalDivider: 'HorizontalDivider',
  VerticalDivider: 'HorizontalDivider',
  Spacer: 'Spacer',
  Icon: 'Icon',
  TopAppBar: 'TopAppBar',
  Scaffold: 'Scaffold',
};

// Statements we always skip when extracting the root call. These
// wrap the user's screen in boilerplate we want to peel away.
const WRAPPER_NAMES = new Set([
  'AppTheme',
  'MaterialTheme',
  'Surface',
  'Crossfade',
  'AnimatedVisibility',
  'BackHandler',
  'Theme',
  'ProvideWindowInsets',
]);

const splitBody = (source, openIndex, openChar, closeChar) => {
  let depth = 0;
  let inString = null;
  for (let i = openIndex; i < source.length; i++) {
    const ch = source[i];
    const prev = i > 0 ? source[i - 1] : '';
    if (inString) {
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; continue; }
    if (ch === openChar) depth++;
    else if (ch === closeChar) {
      depth--;
      if (depth === 0) return { body: source.slice(openIndex + 1, i), start: openIndex, end: i };
    }
  }
  return { body: '', start: openIndex, end: openIndex };
};

const splitTopLevelCommas = (input) => {
  const parts = [];
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  let buffer = '';
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const prev = i > 0 ? input[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; buffer += ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    else if (ch === ',' && depth === 0 && brace === 0 && bracket === 0) {
      parts.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) parts.push(buffer.trim());
  return parts;
};

const parseNamedArgs = (raw) => {
  const args = {};
  for (const part of splitTopLevelCommas(raw)) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    args[key] = value;
  }
  return args;
};

const mapAlignment = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('centerhorizontally')) return 'center';
  if (lower.includes('centervertically')) return 'center';
  if (lower.includes('end') || lower.includes('right')) return 'end';
  if (lower.includes('bottom')) return 'bottom';
  return 'start';
};

const mapArrangement = (value) => {
  if (!value) return undefined;
  const lower = value.toLowerCase();
  if (lower.includes('spacebetween')) return 'spaceBetween';
  if (lower.includes('spacearound')) return 'spaceAround';
  if (lower.includes('spaceevenly')) return 'spaceEvenly';
  if (lower.includes('center')) return 'center';
  if (lower.includes('end') || lower.includes('bottom')) return 'end';
  return 'top';
};

const parseNumber = (value) => {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/-?\d+(\.\d+)?/);
  return match ? Number(match[0]) : undefined;
};

const parseColor = (value) => {
  if (!value) return undefined;
  const match = value.match(/#?[0-9A-Fa-f]{6,8}/);
  return match ? (match[0].startsWith('#') ? match[0] : `#${match[0]}`) : undefined;
};

const stripQuotes = (value) => {
  if (typeof value !== 'string') return value;
  if (value.length < 2) return value;
  const first = value.charAt(0);
  const last = value.charAt(value.length - 1);
  if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
    return value.slice(1, -1).replace(/\\(["'\\])/g, '$1');
  }
  return value;
};

const parseModifierChain = (raw) => {
  const out = { padding: 0, backgroundColor: undefined, borderRadius: undefined, width: undefined, height: undefined };
  if (!raw) return out;
  const lower = raw.replace(/\s+/g, '');
  const fill = /fillmax(width|height)/g;
  let m;
  while ((m = fill.exec(lower))) {
    if (m[1] === 'width') out.width = 'match_parent';
    else out.height = 'match_parent';
  }
  const padding = lower.match(/padding\(([0-9.]+)\.dp\)/);
  if (padding) out.padding = Number(padding[1]);
  const paddingHV = lower.match(/padding\(horizontal\s*=\s*([0-9.]+)\.dp\s*,\s*vertical\s*=\s*([0-9.]+)\.dp\)/);
  if (paddingHV) out.padding = Number(paddingHV[1]) + Number(paddingHV[2]);
  const paddingAll = lower.match(/padding\(all\s*=\s*([0-9.]+)\.dp\)/);
  if (paddingAll) out.padding = Number(paddingAll[1]);
  const bg = lower.match(/background\(([A-Za-z(0-9#]+)\)/);
  if (bg) out.backgroundColor = parseColor(bg[1]) || undefined;
  const radius = lower.match(/cliproundedcornershape\(([0-9.]+)\.dp\)/);
  if (radius) out.borderRadius = Number(radius[1]);
  const width = lower.match(/(?:^|[^a-z])width\(([0-9.]+)\.dp\)/);
  if (width && out.width === undefined) out.width = Number(width[1]);
  const height = lower.match(/(?:^|[^a-z])height\(([0-9.]+)\.dp\)/);
  if (height && out.height === undefined) out.height = Number(height[1]);
  const fillWidth = /fillmaxwidth\(\)/.test(lower);
  const fillHeight = /fillmaxheight\(\)/.test(lower);
  if (fillWidth) out.width = 'match_parent';
  if (fillHeight) out.height = 'match_parent';
  return out;
};

const parseProps = (raw) => {
  const named = parseNamedArgs(raw);
  const props = {};
  const modifier = parseModifierChain(named.modifier);
  Object.assign(props, modifier);
  if (named.text) props.text = stripQuotes(named.text);
  if (named.title) props.title = stripQuotes(named.title);
  if (named.label) props.label = stripQuotes(named.label);
  if (named.color) props.color = parseColor(named.color) || stripQuotes(named.color);
  if (named.backgroundcolor) props.backgroundColor = parseColor(named.backgroundcolor);
  if (named.textcolor) props.textColor = parseColor(named.textcolor);
  if (named.tint) props.tint = parseColor(named.tint);
  if (named.trackcolor) props.trackColor = parseColor(named.trackcolor);
  if (named.borderradius) props.borderRadius = parseNumber(named.borderradius);
  if (named.elevation) props.elevation = parseNumber(named.elevation);
  if (named.spacing) props.spacing = parseNumber(named.spacing);
  if (named.padding) props.padding = parseNumber(named.padding);
  if (named.size) props.size = parseNumber(named.size);
  if (named.progress) props.progress = parseNumber(named.progress);
  if (named.textsize) props.textSize = parseNumber(named.textsize);
  if (named.fontsize) props.textSize = parseNumber(named.fontsize);
  if (named.url) props.url = stripQuotes(named.url);
  if (named.hint) props.hint = stripQuotes(named.hint);
  if (named.checked) props.checked = /true/i.test(named.checked);
  if (named.enabled) props.enabled = !/false/i.test(named.enabled);
  if (named.horizontalalignment) props.horizontalAlignment = mapAlignment(named.horizontalalignment);
  if (named.verticalalignment) props.verticalAlignment = mapAlignment(named.verticalalignment);
  if (named.verticalarrangement) props.verticalArrangement = mapArrangement(named.verticalarrangement);
  if (named.horizontalarrangement) props.horizontalArrangement = mapArrangement(named.horizontalarrangement);
  if ((named.fontweight && /bold/i.test(named.fontweight)) || /bold/i.test(named.style || '')) props.textStyle = 'bold';
  if (named.textalign) {
    const t = named.textalign.toLowerCase();
    if (t.includes('center')) props.textAlign = 'center';
    else if (t.includes('end')) props.textAlign = 'end';
  }
  if (named.style && /headline/i.test(named.style)) props.textStyle = 'headline';
  return props;
};

const parseStatement = (stmt) => {
  const commentIndex = stmt.indexOf('//');
  const cleaned = commentIndex >= 0 ? stmt.slice(0, commentIndex).trim() : stmt;
  if (!cleaned) return null;
  const match = cleaned.match(/^([A-Za-z][A-Za-z0-9_.]*)\s*\(/);
  if (!match) return null;
  const simpleName = match[1].split('.').pop();
  if (['item', 'forEach', 'repeat', 'Scaffold', 'ColumnScope', 'RowScope', 'BoxScope'].includes(simpleName)) return null;
  const open = match.index + match[0].length - 1;
  const { body, end } = splitBody(cleaned, open, '(', ')');
  if (end <= open) return null;
  let argEnd = -1;
  let d = 0;
  let inStr = null;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    const prev = i > 0 ? body[i - 1] : '';
    if (inStr) { if (ch === inStr && prev !== '\\') inStr = null; continue; }
    if (ch === '"' || ch === "'") { inStr = ch; continue; }
    if (ch === '(') d++;
    else if (ch === ')') d--;
    else if (ch === '{' && d === 0) { argEnd = i; break; }
  }
  let args;
  let childrenBody;
  if (argEnd < 0) {
    args = body.trim();
    childrenBody = '';
  } else {
    args = body.slice(0, argEnd).trim();
    childrenBody = body.slice(argEnd + 1);
    if (childrenBody.endsWith('}')) childrenBody = childrenBody.slice(0, -1);
  }
  const type = COMPONENT_BY_KOTLIN[simpleName];
  if (!type) {
    return { id: generateId(), type: 'Text', props: { text: cleaned }, children: [] };
  }
  const props = parseProps(args);
  const children = parseChildrenBlock(childrenBody);
  return { id: generateId(), type, props, children };
};

const parseChildrenBlock = (block) => {
  if (!block) return [];
  const statements = [];
  let buffer = '';
  let depth = 0;
  let brace = 0;
  let bracket = 0;
  let inString = null;
  for (let i = 0; i < block.length; i++) {
    const ch = block[i];
    const prev = i > 0 ? block[i - 1] : '';
    if (inString) {
      buffer += ch;
      if (ch === inString && prev !== '\\') inString = null;
      continue;
    }
    if (ch === '"' || ch === "'") { inString = ch; buffer += ch; continue; }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === '{') brace++;
    else if (ch === '}') brace--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    if (ch === '\n' && depth === 0 && brace === 0 && bracket === 0) {
      if (buffer.trim()) statements.push(buffer.trim());
      buffer = '';
      continue;
    }
    buffer += ch;
  }
  if (buffer.trim()) statements.push(buffer.trim());
  const children = [];
  for (const stmt of statements) {
    const child = parseStatement(stmt);
    if (child) children.push(child);
  }
  return children;
};

const emptyTree = () => ({
  id: generateId(),
  type: 'Column',
  props: { width: 'match_parent', height: 'match_parent', padding: 0, spacing: 0, backgroundColor: 'transparent' },
  children: [],
});

/**
 * Find the body of a top-level @Composable fun <Name>(...) { ... }.
 * Returns { name, params, body } or null.
 */
const findComposableFunction = (source, name) => {
  // Match @Composable ... fun Name ( ... ) { ... } allowing the
  // body to be a brace-matched block.
  const sig = new RegExp(`@Composable(?:\\s+@?[A-Za-z.()]+)*\\s*(?:public\\s+|private\\s+|internal\\s+)?fun\\s+${name}\\s*\\(`, 'g');
  let m;
  while ((m = sig.exec(source))) {
    const open = m.index + m[0].length - 1;
    const parsed = splitBody(source, open, '(', ')');
    if (parsed.end > open) {
      // Find the opening brace of the body - skip past any return
      // type annotation that may sit between the parameter list
      // and the brace.
      let idx = parsed.end + 1;
      while (idx < source.length && /\s/.test(source[idx])) idx++;
      if (source[idx] === ':') {
        // return type annotation
        const colonIdx = idx;
        let depth = 0;
        for (let i = colonIdx + 1; i < source.length; i++) {
          const ch = source[i];
          if (ch === '{' || ch === '(' || ch === '[') depth++;
          else if (ch === '}' || ch === ')' || ch === ']') depth--;
          else if (ch === '{' && depth === 0) { idx = i; break; }
          if (ch === '\n' && i - colonIdx > 200) { idx = -1; break; }
        }
        if (idx < 0) continue;
      }
      if (source[idx] !== '{') continue;
      const bodyParsed = splitBody(source, idx, '{', '}');
      if (bodyParsed.end > idx) {
        return { name, params: parsed.body, body: bodyParsed.body, start: m.index, end: bodyParsed.end };
      }
    }
  }
  return null;
};

/**
 * Strip `var x by remember { ... }` declarations and any other
 * top-level property declarations from a function body, returning
 * the remaining statement list. Each removed declaration is also
 * returned as a `{ name, initial, type }` record so the caller can
 * surface it as state in the editor.
 */
const extractState = (body) => {
  const state = [];
  const cleaned = body.replace(
    /^[ \t]*var\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([A-Za-z<>?]+)\s*by\s+remember\s*\{?\s*mutableStateOf\(([^)]*)\)\s*\}?\s*$/gm,
    (match, name, type, initialRaw) => {
      const initial = initialRaw.trim();
      const typeName = type.replace(/<.*>/, '');
      state.push({
        name,
        type: typeName.includes('Int') ? 'number' : typeName.includes('Boolean') ? 'boolean' : 'text',
        initial,
      });
      return '';
    },
  ).replace(
    /^[ \t]*var\s+([A-Za-z_][A-Za-z0-9_]*)\s*by\s+remember\s*\{?\s*mutableIntStateOf\(([^)]*)\)\s*\}?\s*$/gm,
    (match, name, initialRaw) => {
      state.push({ name, type: 'number', initial: initialRaw.trim() });
      return '';
    },
  ).replace(
    /^[ \t]*val\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*remember[^\n]*$/gm,
    () => '',
  );
  return { cleaned, state };
};

/**
 * Extract the body of `setContent { ... }` and walk into it to find
 * the user-visible Composable call. We do this iteratively: start
 * with the top-level body, then if its first/innermost call is
 * a wrapper (AppTheme/MaterialTheme/Surface), unwrap into that
 * call's body and repeat. We also recognise a single call to a
 * user-defined function (MainScreen(), AuthScreen(), ...) and
 * resolve that to the @Composable fun definition in the same file.
 */
const resolveRootCall = (source, setContentBody) => {
  let currentBody = setContentBody;
  let state = [];
  for (let depth = 0; depth < 8; depth++) {
    const first = findFirstCallInBody(currentBody);
    if (!first) break;
    if (first.kind === 'call' && WRAPPER_NAMES.has(first.name)) {
      currentBody = first.lambdaBody;
      continue;
    }
    if (first.kind === 'call' && /^[A-Z]/.test(first.name)) {
      // Could be a user-defined Composable (MainScreen) or a
      // built-in (Column, Row, Box). Look up the user function
      // definition; if found, parse its body as the new current.
      const def = findComposableFunction(source, first.name);
      if (def) {
        const extracted = extractState(def.body);
        state = extracted.state;
        currentBody = extracted.cleaned;
        continue;
      }
      // No definition found - the call is the root itself.
      break;
    }
    break;
  }
  return { body: currentBody, state };
};

const findFirstCallInBody = (body) => {
  const trimmed = body.trim();
  if (!trimmed) return null;
  const match = trimmed.match(/^([A-Za-z][A-Za-z0-9_.]*)\s*\(/);
  if (!match) return null;
  const name = match[1].split('.').pop();
  const open = match.index + match[0].length - 1;
  const parsed = splitBody(trimmed, open, '(', ')');
  if (parsed.end <= open) return null;
  // Find the trailing lambda.
  let idx = parsed.end + 1;
  while (idx < trimmed.length && /\s/.test(trimmed[idx])) idx++;
  let lambdaBody = '';
  if (trimmed[idx] === '{') {
    const lambda = splitBody(trimmed, idx, '{', '}');
    if (lambda.end > idx) lambdaBody = lambda.body;
  }
  return { kind: 'call', name, lambdaBody };
};

const findSetContent = (source) => {
  const re = /\bsetContent\s*\(/g;
  let m;
  while ((m = re.exec(source))) {
    const open = m.index + m[0].length - 1;
    const parsed = splitBody(source, open, '(', ')');
    if (parsed.end > open) return { body: parsed.body, start: open, end: parsed.end };
  }
  return null;
};

/**
 * Parse a *Activity.kt file and return:
 *   { tree, state, rootName }
 * where `tree` is the editor component tree (the body of the
 * @Composable fun the Activity's setContent calls into), `state`
 * is the list of `var x by remember { ... }` declarations, and
 * `rootName` is the name of that Composable function.
 */
export const parseActivitySource = (source) => {
  if (!source) return { tree: emptyTree(), state: [], rootName: null };
  const setContent = findSetContent(source);
  if (!setContent) return { tree: emptyTree(), state: [], rootName: null };
  const resolved = resolveRootCall(source, setContent.body);
  const treeChildren = parseChildrenBlock(resolved.body);
  let tree;
  if (treeChildren.length === 1) {
    tree = treeChildren[0];
  } else if (treeChildren.length > 1) {
    tree = {
      id: generateId(),
      type: 'Column',
      props: { width: 'match_parent', height: 'wrap_content', padding: 0, spacing: 0, backgroundColor: 'transparent' },
      children: treeChildren,
    };
  } else {
    tree = emptyTree();
  }
  return { tree, state: resolved.state, rootName: null };
};

const propToModifier = (key, value) => {
  switch (key) {
    case 'width':
      if (value === 'match_parent') return 'fillMaxWidth()';
      if (value === 'wrap_content') return null;
      return `width(${value}.dp)`;
    case 'height':
      if (value === 'match_parent') return 'fillMaxHeight()';
      if (value === 'wrap_content') return null;
      return `height(${value}.dp)`;
    case 'padding': return `padding(${value}.dp)`;
    case 'backgroundColor': return `background(composeColor("${escape(value)}"))`;
    case 'borderRadius': return `clip(RoundedCornerShape(${value}.dp))`;
    default: return null;
  }
};

const buildModifier = (props = {}) => {
  const calls = [];
  for (const [key, value] of Object.entries(props)) {
    if (key === 'children' || value === undefined || value === null) continue;
    const expr = propToModifier(key, value);
    if (expr) calls.push(expr);
  }
  if (!calls.length) return 'Modifier';
  return `Modifier.${calls.join('.')}`;
};

const componentToKotlin = (node, depth) => {
  if (!node) return '';
  const indent = '    '.repeat(depth);
  const props = node.props || {};
  const children = node.children || [];
  switch (node.type) {
    case 'Column': {
      const hAlign = props.horizontalAlignment === 'center' ? 'Alignment.CenterHorizontally'
        : props.horizontalAlignment === 'end' ? 'Alignment.End' : 'Alignment.Start';
      const vArrange = props.spacing ? `Arrangement.spacedBy(${props.spacing}.dp)` : 'Arrangement.Top';
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Column(modifier = ${buildModifier(props)}, horizontalAlignment = ${hAlign}, verticalArrangement = ${vArrange}) {\n${inner}\n${indent}}`;
    }
    case 'Row': {
      const hArrange = props.spacing ? `Arrangement.spacedBy(${props.spacing}.dp)` : 'Arrangement.Start';
      const vAlign = props.verticalAlignment === 'center' ? 'Alignment.CenterVertically'
        : props.verticalAlignment === 'bottom' ? 'Alignment.Bottom' : 'Alignment.Top';
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Row(modifier = ${buildModifier(props)}, horizontalArrangement = ${hArrange}, verticalAlignment = ${vAlign}) {\n${inner}\n${indent}}`;
    }
    case 'Box': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Box(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'LazyColumn': {
      const items = children.map((c) => `${indent}    item {\n${componentToKotlin(c, depth + 2)}\n${indent}    }`).join('\n');
      return `${indent}LazyColumn(modifier = ${buildModifier(props)}) {\n${items}\n${indent}}`;
    }
    case 'Card': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}Card(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'ElevatedCard': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      return `${indent}ElevatedCard(modifier = ${buildModifier(props)}) {\n${inner}\n${indent}}`;
    }
    case 'Scaffold': {
      const inner = children.map((c) => componentToKotlin(c, depth + 1)).filter(Boolean).join('\n');
      const padding = props.padding ? `, contentPadding = PaddingValues(${props.padding}.dp)` : '';
      return `${indent}Scaffold(modifier = ${buildModifier(props)}${padding}) { padding ->\n${inner.replace(/\$/g, '\\$')}\n${indent}}`;
    }
    case 'TopAppBar': {
      const title = escape(props.title || 'MyApp');
      return `${indent}TopAppBar(title = { Text("${title}") })`;
    }
    case 'Text': {
      const text = escape(props.text || '');
      const size = props.textSize ? `, fontSize = ${props.textSize}.sp` : '';
      const weight = props.textStyle === 'bold' ? ', fontWeight = FontWeight.Bold' : '';
      const color = props.textColor ? `, color = composeColor("${escape(props.textColor)}")` : '';
      const align = props.textAlign === 'center' ? ', textAlign = TextAlign.Center'
        : props.textAlign === 'end' ? ', textAlign = TextAlign.End' : '';
      const style = props.textStyle === 'headline' ? ', style = MaterialTheme.typography.headlineSmall' : '';
      return `${indent}Text(text = "${text}"${size}${weight}${color}${align}${style})`;
    }
    case 'Button': {
      const text = escape(props.text || '');
      const bg = props.backgroundColor ? `, colors = ButtonDefaults.buttonColors(containerColor = composeColor("${escape(props.backgroundColor)}"))` : '';
      return `${indent}Button(onClick = {}, modifier = ${buildModifier(props)}${bg}) { Text("${text}") }`;
    }
    case 'OutlinedButton': {
      const text = escape(props.text || '');
      return `${indent}OutlinedButton(onClick = {}, modifier = ${buildModifier(props)}) { Text("${text}") }`;
    }
    case 'OutlinedTextField': {
      const label = props.label ? `, label = { Text("${escape(props.label)}") }` : '';
      const hint = props.hint ? `, placeholder = { Text("${escape(props.hint)}") }` : '';
      const value = escape(props.text || '');
      return `${indent}OutlinedTextField(value = "${value}", onValueChange = {}, modifier = ${buildModifier(props)}${label}${hint})`;
    }
    case 'Image': {
      const w = props.width || 120;
      const h = props.height || 120;
      return `${indent}Box(modifier = Modifier.size(${w}.dp, ${h}.dp).background(composeColor("${escape(props.backgroundColor || '#E5E7EB')}")), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, contentDescription = null) }`;
    }
    case 'Checkbox': {
      const text = escape(props.text || '');
      return `${indent}Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = ${Boolean(props.checked)}, onCheckedChange = {}); Text("${text}") }`;
    }
    case 'Switch': {
      const text = escape(props.text || '');
      return `${indent}Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("${text}"); Switch(checked = ${Boolean(props.checked)}, onCheckedChange = {}) }`;
    }
    case 'LinearProgressIndicator': {
      const value = Number(props.progress) || 0.5;
      return `${indent}LinearProgressIndicator(progress = ${value.toFixed(2)}f, modifier = ${buildModifier(props)})`;
    }
    case 'CircularProgressIndicator': {
      return `${indent}CircularProgressIndicator(modifier = ${buildModifier(props)})`;
    }
    case 'HorizontalDivider': {
      return `${indent}HorizontalDivider(thickness = ${(props.height || 1)}.dp${props.color ? `, color = composeColor("${escape(props.color)}")` : ''})`;
    }
    case 'Spacer': {
      return `${indent}Spacer(modifier = Modifier.height(${props.height || 16}.dp))`;
    }
    case 'Icon': {
      return `${indent}Icon(Icons.Default.${props.iconName || 'Favorite'}, contentDescription = null, modifier = Modifier.size(${props.size || 28}.dp), tint = composeColor("${escape(props.tint || '#4F46E5')}"))`;
    }
    default:
      return `${indent}Text("${escape(node.type || 'Unknown')}")`;
  }
};

const stateDeclaration = (variable) => {
  if (variable.type === 'number') return `    var ${variable.name} by remember { mutableIntStateOf(${variable.initial || '0'}) }`;
  if (variable.type === 'boolean') return `    var ${variable.name} by remember { mutableStateOf(${variable.initial || 'false'}) }`;
  return `    var ${variable.name} by remember { mutableStateOf(${variable.initial || '""'}) }`;
};

/**
 * Build a complete `*Activity.kt` source from a screen record.
 * The output is what rai build will compile: a ComponentActivity
 * subclass plus a top-level @Composable fun <Name>() that holds
 * the user's design. State declarations from screen.state are
 * spliced into the top of that function.
 */
export const buildActivitySource = (screen, project) => {
  const pkg = project?.packageName || 'com.example.app';
  const activityName = screen.name;
  const funName = activityName === 'Main' ? 'MainScreen' : `${activityName}Screen`;
  const state = Array.isArray(screen.state) ? screen.state : [];
  const stateDecls = state.map(stateDeclaration).join('\n');
  const body = componentToKotlin(screen.rootComponent || emptyTree(), 2);
  return `package ${pkg}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

class ${activityName}Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ${funName}()
                }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme() else lightColorScheme(),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${funName}() {
${stateDecls ? stateDecls + '\n' : ''}${body}
}
`;
};

/**
 * Add or update an `<activity>` entry in AndroidManifest.xml.
 * Returns the new manifest text. Only the activities listed in
 * `desiredActivityNames` are kept; everything else (including the
 * auto-generated MainActivity stub, if any) is preserved.
 */
export const upsertActivityInManifest = (manifestText, packageName, activityNames) => {
  if (!manifestText) return manifestText;
  const applicationStart = manifestText.indexOf('<application');
  if (applicationStart < 0) return manifestText;
  const applicationEnd = manifestText.lastIndexOf('</application>');
  if (applicationEnd < 0) return manifestText;
  const openTagMatch = manifestText.slice(applicationStart).match(/<application[^>]*>/);
  if (!openTagMatch) return manifestText;
  const openTag = openTagMatch[0];
  const inner = manifestText.slice(applicationStart + openTag.length, applicationEnd);
  const stripped = inner.replace(/<activity[\s\S]*?<\/activity>|<activity[^>]*\/>/g, '');
  const newActivities = activityNames.map((name, index) => {
    const isMain = index === 0;
    const filter = isMain
      ? `\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>`
      : '';
    return `        <activity\n            android:name=".${name}Activity"${filter}\n            android:exported="true" />`;
  }).join('\n');
  const newApplication = `${openTag}\n${stripped.trim() ? stripped + '\n' : ''}${newActivities}\n    </application>`;
  return manifestText.slice(0, applicationStart) + newApplication + manifestText.slice(applicationEnd + '</application>'.length);
};

/**
 * Pull the current list of `*Activity.kt` files from the rai
 * project. Returns [{ name, fileName, packagePath, rootComponent,
 * state, source }]. The MainActivity (the first file) is treated
 * the same as any other screen in the editor.
 */
export const loadRaiActivities = async (project) => {
  if (!project) return [];
  const sourceRoot = getSourceRoot(project);
  const result = await execute(
    `find ${sourceRoot} -maxdepth 1 -name '*Activity.kt' -type f 2>/dev/null | sort`,
    project.projectDir,
  );
  const files = (result.output || '').split('\n').map((line) => line.trim()).filter(Boolean);
  const activities = [];
  const { readWorkspaceFile } = await import('./workspace');
  for (const filePath of files) {
    const nameMatch = filePath.match(/\/([A-Za-z0-9_]+)Activity\.kt$/);
    if (!nameMatch) continue;
    const activityName = nameMatch[1];
    const relative = filePath.startsWith(sourceRoot) ? filePath : filePath;
    const read = await readWorkspaceFile(project, relative);
    if (!read.success) continue;
    const parsed = parseActivitySource(read.output);
    activities.push({
      id: `act-${activityName.toLowerCase()}`,
      name: activityName,
      fileName: `${activityName}Activity.kt`,
      packagePath: '',
      rootComponent: parsed.tree,
      state: parsed.state,
      source: read.output,
      blocks: [],
    });
  }
  return activities;
};
