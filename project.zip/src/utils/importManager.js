/**
 * Basic import management for the Kotlin editor.
 *
 * Given the current source, find usages of common Jetpack Compose / Android
 * types that are not yet imported, and offer the missing `import` lines. This
 * is deliberately a conservative, regex/name-based checker (not a full Kotlin
 * compiler): it only suggests well-known identifiers and never removes or
 * rewrites the user's own imports.
 */

// Common Compose/Android types -> the import needed to use them.
// Exported so the Kotlin analyzer can reuse the same symbol table.
export const KNOWN_IMPORTS = {
  Column: 'androidx.compose.foundation.layout.Column',
  Row: 'androidx.compose.foundation.layout.Row',
  Box: 'androidx.compose.foundation.layout.Box',
  Spacer: 'androidx.compose.foundation.layout.Spacer',
  fillMaxSize: 'androidx.compose.foundation.layout.fillMaxSize',
  fillMaxWidth: 'androidx.compose.foundation.layout.fillMaxWidth',
  fillMaxHeight: 'androidx.compose.foundation.layout.fillMaxHeight',
  padding: 'androidx.compose.foundation.layout.padding',
  size: 'androidx.compose.foundation.layout.size',
  width: 'androidx.compose.foundation.layout.width',
  height: 'androidx.compose.foundation.layout.height',
  Arrangement: 'androidx.compose.foundation.layout.Arrangement',
  Alignment: 'androidx.compose.ui.Alignment',
  Modifier: 'androidx.compose.ui.Modifier',
  Text: 'androidx.compose.material3.Text',
  Button: 'androidx.compose.material3.Button',
  OutlinedButton: 'androidx.compose.material3.OutlinedButton',
  TextButton: 'androidx.compose.material3.TextButton',
  IconButton: 'androidx.compose.material3.IconButton',
  Scaffold: 'androidx.compose.material3.Scaffold',
  TopAppBar: 'androidx.compose.material3.TopAppBar',
  Card: 'androidx.compose.material3.Card',
  ElevatedCard: 'androidx.compose.material3.ElevatedCard',
  OutlinedCard: 'androidx.compose.material3.OutlinedCard',
  Surface: 'androidx.compose.material3.Surface',
  OutlinedTextField: 'androidx.compose.material3.OutlinedTextField',
  Checkbox: 'androidx.compose.material3.Checkbox',
  Switch: 'androidx.compose.material3.Switch',
  Slider: 'androidx.compose.material3.Slider',
  LinearProgressIndicator: 'androidx.compose.material3.LinearProgressIndicator',
  CircularProgressIndicator: 'androidx.compose.material3.CircularProgressIndicator',
  HorizontalDivider: 'androidx.compose.material3.HorizontalDivider',
  VerticalDivider: 'androidx.compose.material3.VerticalDivider',
  MaterialTheme: 'androidx.compose.material3.MaterialTheme',
  Typography: 'androidx.compose.material3.Typography',
  ButtonDefaults: 'androidx.compose.material3.ButtonDefaults',
  CardDefaults: 'androidx.compose.material3.CardDefaults',
  remember: 'androidx.compose.runtime.remember',
  mutableStateOf: 'androidx.compose.runtime.mutableStateOf',
  mutableIntStateOf: 'androidx.compose.runtime.mutableIntStateOf',
  mutableListOf: 'androidx.compose.runtime.mutableListOf',
  mutableMapOf: 'androidx.compose.runtime.mutableMapOf',
  derivedStateOf: 'androidx.compose.runtime.derivedStateOf',
  LaunchedEffect: 'androidx.compose.runtime.LaunchedEffect',
  DisposableEffect: 'androidx.compose.runtime.DisposableEffect',
  SideEffect: 'androidx.compose.runtime.SideEffect',
  produceState: 'androidx.compose.runtime.produceState',
  FontWeight: 'androidx.compose.ui.text.font.FontWeight',
  TextAlign: 'androidx.compose.ui.text.style.TextAlign',
  Color: 'androidx.compose.ui.graphics.Color',
  RoundedCornerShape: 'androidx.compose.foundation.shape.RoundedCornerShape',
  Icons: 'androidx.compose.material.icons.Icons',
  dp: 'androidx.compose.ui.unit.dp',
  sp: 'androidx.compose.ui.unit.sp',
  ComponentActivity: 'androidx.activity.ComponentActivity',
  Bundle: 'android.os.Bundle',
  setContent: 'androidx.activity.compose.setContent',
};

/**
 * Return a sorted list of `import ...` lines that the source uses but does not
 * yet import. Also returns a count so the UI can show "N missing imports".
 */
export const findMissingImports = (source = '') => {
  if (!source) return { missing: [], count: 0 };
  const imported = new Set();
  const importRe = /^import\s+([^\s;]+)/gm;
  let m;
  while ((m = importRe.exec(source))) {
    imported.add(m[1]);
  }
  const missing = [];
  const seen = new Set();
  for (const [name, full] of Object.entries(KNOWN_IMPORTS)) {
    if (seen.has(full)) continue;
    seen.add(full);
    if (imported.has(full)) continue;
    // Does the source use this identifier (as a word)?
    const re = new RegExp(`\\b${name}\\b`);
    if (re.test(source)) missing.push(full);
  }
  missing.sort();
  return { missing, count: missing.length };
};

/**
 * Insert missing imports at the top (after the `package` line). Never touches
 * existing import lines or any other code.
 */
export const addMissingImports = (source = '', missing = []) => {
  if (!source || !missing.length) return source;
  const lines = source.split('\n');
  // Find insertion index: after package line, or at the very start.
  let idx = 0;
  for (let i = 0; i < lines.length; i++) {
    if (/^\s*package\b/.test(lines[i])) { idx = i + 1; break; }
  }
  // Skip existing blank lines so imports cluster right after package/header.
  while (idx < lines.length && lines[idx].trim() === '') idx++;
  const importLines = missing.map((full) => `import ${full}`);
  const block = `${importLines.join('\n')}\n`;
  lines.splice(idx, 0, block);
  return lines.join('\n');
};

/**
 * Format / file statistics for the status display: lines, non-empty lines,
 * characters, bytes, and detected indentation (spaces vs tabs).
 */
export const fileStats = (source = '') => {
  const text = source || '';
  const linesArr = text ? text.split('\n') : [];
  // A trailing newline terminates the last line rather than opening an empty one.
  const lineCount = linesArr.length ? (text.endsWith('\n') ? linesArr.length - 1 : linesArr.length) : 0;
  const nonEmpty = linesArr.filter((l) => l.trim().length > 0).length;
  const chars = text.length;
  let byteCount = 0;
  try { byteCount = new TextEncoder().encode(text).length; } catch (e) { byteCount = chars; }
  const tabIndented = /(^|\n)\t/.test(text);
  const spaceIndented = /(^|\n) {2,}/.test(text);
  const indentation = tabIndented && !spaceIndented ? 'tabs' : spaceIndented ? 'spaces' : 'mixed';
  return { lineCount, nonEmpty, chars, bytes: byteCount, indentation };
};

export default findMissingImports;
