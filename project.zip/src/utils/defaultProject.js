import { generateId } from './generateId';

// Определения доступных компонентов для UI
export const componentTypes = {
  // Layouts
  LinearLayout: {
    type: 'LinearLayout',
    label: 'Linear Layout',
    icon: '☰',
    isContainer: true,
    defaultProps: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'wrap_content',
      padding: 8,
      backgroundColor: 'transparent',
      gravity: 'left',
    },
  },
  ScrollView: {
    type: 'ScrollView',
    label: 'Scroll View',
    icon: '↕',
    isContainer: true,
    defaultProps: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'match_parent',
      backgroundColor: 'transparent',
    },
  },
  // Basic Widgets
  TextView: {
    type: 'TextView',
    label: 'Text',
    icon: 'T',
    isContainer: false,
    defaultProps: {
      text: 'Текст',
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#FFFFFF',
      textStyle: 'normal',
      gravity: 'left',
      padding: 4,
    },
  },
  Button: {
    type: 'Button',
    label: 'Button',
    icon: '▭',
    isContainer: false,
    defaultProps: {
      text: 'Кнопка',
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#FFFFFF',
      backgroundColor: '#BB86FC',
      padding: 12,
      borderRadius: 8,
    },
  },
  EditText: {
    type: 'EditText',
    label: 'Input',
    icon: '✎',
    isContainer: false,
    defaultProps: {
      hint: 'Введите текст...',
      text: '',
      width: 'match_parent',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#FFFFFF',
      backgroundColor: '#2C2C2C',
      padding: 12,
      borderRadius: 8,
      inputType: 'text',
    },
  },
  ImageView: {
    type: 'ImageView',
    label: 'Image',
    icon: '🖼',
    isContainer: false,
    defaultProps: {
      width: 100,
      height: 100,
      scaleType: 'centerCrop',
      borderRadius: 0,
      backgroundColor: '#333333',
    },
  },
  CheckBox: {
    type: 'CheckBox',
    label: 'CheckBox',
    icon: '☑',
    isContainer: false,
    defaultProps: {
      text: 'Флажок',
      checked: false,
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#FFFFFF',
    },
  },
  Switch: {
    type: 'Switch',
    label: 'Switch',
    icon: '⊘',
    isContainer: false,
    defaultProps: {
      text: 'Переключатель',
      checked: false,
      width: 'wrap_content',
      height: 'wrap_content',
    },
  },
  ProgressBar: {
    type: 'ProgressBar',
    label: 'Progress',
    icon: '◔',
    isContainer: false,
    defaultProps: {
      progress: 50,
      max: 100,
      width: 'match_parent',
      height: 'wrap_content',
      color: '#BB86FC',
    },
  },
  CardView: {
    type: 'CardView',
    label: 'Card',
    icon: '▢',
    isContainer: true,
    defaultProps: {
      width: 'match_parent',
      height: 'wrap_content',
      backgroundColor: '#2C2C2C',
      borderRadius: 12,
      padding: 16,
      elevation: 4,
    },
  },
  Divider: {
    type: 'Divider',
    label: 'Divider',
    icon: '—',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 1,
      backgroundColor: '#444444',
      margin: 8,
    },
  },
  Spacer: {
    type: 'Spacer',
    label: 'Spacer',
    icon: '⬜',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 16,
    },
  },
  WebView: {
    type: 'WebView',
    label: 'WebView',
    icon: '🌐',
    isContainer: false,
    defaultProps: {
      url: 'https://example.com',
      width: 'match_parent',
      height: 300,
    },
  },
  MapView: {
    type: 'MapView',
    label: 'Map',
    icon: '🗺',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 300,
      latitude: 55.7558,
      longitude: 37.6173,
    },
  },
};

export const createDefaultScreen = (id, name) => ({
  id: id || generateId(),
  name,
  orientation: 'portrait',
  statusBarColor: '#121212',
  backgroundColor: '#121212',
  showStatusBar: true,
  showActionBar: true,
  actionBarTitle: name,
  rootComponent: {
    id: generateId(),
    type: 'LinearLayout',
    props: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'match_parent',
      padding: 16,
      backgroundColor: '#121212',
      gravity: 'left',
    },
    children: [
      {
        id: generateId(),
        type: 'TextView',
        props: {
          text: 'Добро пожаловать!',
          width: 'match_parent',
          height: 'wrap_content',
          textSize: 24,
          textColor: '#FFFFFF',
          textStyle: 'bold',
          gravity: 'center',
          padding: 16,
        },
        children: [],
      },
      {
        id: generateId(),
        type: 'Button',
        props: {
          text: 'Нажми меня',
          width: 'match_parent',
          height: 'wrap_content',
          textSize: 16,
          textColor: '#000000',
          backgroundColor: '#BB86FC',
          padding: 16,
          borderRadius: 8,
        },
        children: [],
      },
    ],
  },
  blocks: [
    {
      id: generateId(),
      definitionId: 'on_create',
      category: 'EVENT',
      position: { x: 20, y: 20 },
      inputs: {},
      children: {
        next: [
          {
            id: generateId(),
            definitionId: 'show_toast',
            category: 'COMPONENT',
            inputs: { text: 'Экран создан!' },
            children: {},
          },
        ],
      },
    },
  ],
});

// Шаблон проекта по умолчанию
export const createDefaultProject = (name = 'Новый проект') => ({
  id: generateId(),
  name,
  packageName: `com.app.${name.toLowerCase().replace(/\s/g, '')}`,
  versionName: '1.0.0',
  versionCode: 1,
  createdAt: Date.now(),
  updatedAt: Date.now(),
  icon: '📱',
  theme: {
    primaryColor: '#BB86FC',
    secondaryColor: '#03DAC6',
    backgroundColor: '#121212',
    isDark: true,
  },
  screens: [
    createDefaultScreen('main', 'Главный экран'),
  ],
  variables: [
    { id: generateId(), name: 'counter', type: 'number', value: 0 },
    { id: generateId(), name: 'username', type: 'text', value: '' },
  ],
  lists: [],
  components: [], // non-visual components (Timer, Dialog, etc.)
});

export default createDefaultProject;
