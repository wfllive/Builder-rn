import { generateId } from './generateId';
import {
  ANDROID_GRADLE_PLUGIN, COMPILE_SDK, COMPOSE_BOM, GRADLE_VERSION,
  JAVA_VERSION, KOTLIN_VERSION, MIN_SDK, PROJECTS_ROOT, TARGET_SDK,
  packageSegment, slugifyProject,
} from '../config/runtime';

/** Jetpack Compose elements available in the visual editor. */
export const componentTypes = {
  Column: {
    type: 'Column', label: 'Column', icon: 'reorder-four-outline', isContainer: true,
    defaultProps: { width: 'match_parent', height: 'wrap_content', padding: 8, spacing: 8, backgroundColor: 'transparent', horizontalAlignment: 'start', verticalArrangement: 'top' },
  },
  Row: {
    type: 'Row', label: 'Row', icon: 'reorder-three-outline', isContainer: true,
    defaultProps: { width: 'match_parent', height: 'wrap_content', padding: 8, spacing: 8, backgroundColor: 'transparent', horizontalArrangement: 'start', verticalAlignment: 'center' },
  },
  Box: {
    type: 'Box', label: 'Box', icon: 'square-outline', isContainer: true,
    defaultProps: { width: 'match_parent', height: 'wrap_content', padding: 8, backgroundColor: 'transparent', contentAlignment: 'topStart' },
  },
  LazyColumn: {
    type: 'LazyColumn', label: 'LazyColumn', icon: 'list-outline', isContainer: true,
    defaultProps: { width: 'match_parent', height: 'match_parent', padding: 8, spacing: 8, backgroundColor: 'transparent' },
  },
  Card: {
    type: 'Card', label: 'Material Card', icon: 'card-outline', isContainer: true,
    defaultProps: { width: 'match_parent', height: 'wrap_content', padding: 16, backgroundColor: '#FFFFFF', borderRadius: 16, elevation: 2 },
  },
  Text: {
    type: 'Text', label: 'Text', icon: 'text-outline', isContainer: false,
    defaultProps: { text: 'Текст', width: 'wrap_content', height: 'wrap_content', textSize: 16, textColor: '#111827', textStyle: 'normal', textAlign: 'start', padding: 4 },
  },
  Button: {
    type: 'Button', label: 'Button', icon: 'radio-button-on-outline', isContainer: false,
    defaultProps: { text: 'Кнопка', width: 'wrap_content', height: 'wrap_content', textSize: 15, textColor: '#FFFFFF', backgroundColor: '#4F46E5', padding: 12, borderRadius: 12, enabled: true },
  },
  OutlinedTextField: {
    type: 'OutlinedTextField', label: 'Outlined TextField', icon: 'create-outline', isContainer: false,
    defaultProps: { label: 'Поле', hint: 'Введите текст', text: '', width: 'match_parent', height: 'wrap_content', textSize: 16, textColor: '#111827', singleLine: true },
  },
  Image: {
    type: 'Image', label: 'Image', icon: 'image-outline', isContainer: false,
    defaultProps: { width: 120, height: 120, contentDescription: 'Image', contentScale: 'crop', borderRadius: 12, backgroundColor: '#E5E7EB' },
  },
  Checkbox: {
    type: 'Checkbox', label: 'Checkbox', icon: 'checkbox-outline', isContainer: false,
    defaultProps: { text: 'Флажок', checked: false, width: 'wrap_content', height: 'wrap_content', textSize: 16, textColor: '#111827', enabled: true },
  },
  Switch: {
    type: 'Switch', label: 'Switch', icon: 'toggle-outline', isContainer: false,
    defaultProps: { text: 'Переключатель', checked: false, width: 'match_parent', height: 'wrap_content', enabled: true },
  },
  LinearProgressIndicator: {
    type: 'LinearProgressIndicator', label: 'Linear Progress', icon: 'remove-outline', isContainer: false,
    defaultProps: { progress: 0.5, width: 'match_parent', height: 8, color: '#4F46E5', trackColor: '#E5E7EB' },
  },
  CircularProgressIndicator: {
    type: 'CircularProgressIndicator', label: 'Circular Progress', icon: 'sync-outline', isContainer: false,
    defaultProps: { progress: 0.7, width: 48, height: 48, color: '#4F46E5', strokeWidth: 4 },
  },
  HorizontalDivider: {
    type: 'HorizontalDivider', label: 'Divider', icon: 'remove-outline', isContainer: false,
    defaultProps: { width: 'match_parent', height: 1, color: '#D1D5DB', padding: 8 },
  },
  Spacer: {
    type: 'Spacer', label: 'Spacer', icon: 'expand-outline', isContainer: false,
    defaultProps: { width: 'match_parent', height: 16 },
  },
  Icon: {
    type: 'Icon', label: 'Material Icon', icon: 'star-outline', isContainer: false,
    defaultProps: { iconName: 'Favorite', contentDescription: 'Icon', size: 28, tint: '#4F46E5' },
  },
  WebView: {
    type: 'WebView', label: 'AndroidView WebView', icon: 'globe-outline', isContainer: false,
    defaultProps: { url: 'https://example.com', width: 'match_parent', height: 300 },
  },
};

// Empty seed screen. The editor used to populate a "Добро пожаловать /
// Продолжить" placeholder here, but the rai new template that the editor
// also runs creates an entirely different app (a counter). Two
// independent defaults were confusing users who thought they were
// seeing the project they had just created. Now the screen starts
// empty and the project is hydrated from the actual rai sources
// via `loadRaiProjectScreens`.
export const createDefaultScreen = (id, name) => ({
  id: id || generateId(),
  name,
  route: id === 'main' ? 'home' : slugifyProject(name),
  orientation: 'portrait',
  statusBarColor: '#FFFFFF',
  backgroundColor: '#F8FAFC',
  showStatusBar: true,
  showActionBar: true,
  actionBarTitle: name,
  rootComponent: {
    id: generateId(), type: 'Column',
    props: { width: 'match_parent', height: 'match_parent', padding: 16, spacing: 8, backgroundColor: '#F8FAFC', horizontalAlignment: 'start', verticalArrangement: 'top' },
    children: [],
  },
  blocks: [],
});

export const createDefaultProject = (nameOrOptions = 'Новый проект') => {
  const options = typeof nameOrOptions === 'string' ? { name: nameOrOptions } : (nameOrOptions || {});
  const name = options.name || 'Новый проект';
  const slug = options.slug || slugifyProject(name);
  return {
    id: options.id || generateId(),
    platform: 'android-compose',
    name,
    slug,
    projectDir: options.projectDir || `${PROJECTS_ROOT}/${slug}`,
    createdWith: options.createdWith || 'Compose Studio Jetpack Compose template',
    packageName: options.packageName || `com.rnstudio.${packageSegment(slug)}`,
    namespace: options.namespace || options.packageName || `com.rnstudio.${packageSegment(slug)}`,
    versionName: options.versionName || '1.0.0',
    versionCode: options.versionCode || 1,
    minSdk: options.minSdk || MIN_SDK,
    targetSdk: options.targetSdk || TARGET_SDK,
    compileSdk: options.compileSdk || COMPILE_SDK,
    javaVersion: options.javaVersion || JAVA_VERSION,
    agpVersion: options.agpVersion || ANDROID_GRADLE_PLUGIN,
    gradleVersion: options.gradleVersion || GRADLE_VERSION,
    kotlinVersion: options.kotlinVersion || KOTLIN_VERSION,
    composeBom: options.composeBom || COMPOSE_BOM,
    gradleDependencies: options.gradleDependencies || [],
    signing: options.signing || { keystorePath: '', keyAlias: '', storePasswordEnv: 'KEYSTORE_PASSWORD', keyPasswordEnv: 'KEY_PASSWORD' },
    createdAt: options.createdAt || Date.now(),
    updatedAt: Date.now(),
    icon: 'logo-android',
    theme: { primaryColor: '#4F46E5', secondaryColor: '#0E7490', backgroundColor: '#F8FAFC', isDark: false, dynamicColor: true, ...(options.theme || {}) },
    screens: options.screens || [createDefaultScreen('main', 'Главный экран')],
    variables: options.variables || [
      { id: generateId(), name: 'counter', type: 'number', value: 0 },
      { id: generateId(), name: 'username', type: 'text', value: '' },
    ],
    lists: options.lists || [],
    components: options.components || [],
  };
};

const legacyTypes = {
  ScrollView: 'LazyColumn', CardView: 'Card', TextView: 'Text', EditText: 'OutlinedTextField',
  ImageView: 'Image', CheckBox: 'Checkbox', ProgressBar: 'LinearProgressIndicator', Divider: 'HorizontalDivider',
  MapView: 'Box',
};
const migrateNode = (node) => {
  if (!node) return node;
  const type = node.type === 'LinearLayout'
    ? (node.props?.orientation === 'horizontal' ? 'Row' : 'Column')
    : (legacyTypes[node.type] || node.type);
  const props = { ...(componentTypes[type]?.defaultProps || {}), ...(node.props || {}) };
  if (type === 'Text' && props.gravity) props.textAlign = props.gravity === 'right' ? 'end' : props.gravity;
  if (type === 'HorizontalDivider' && props.backgroundColor) props.color = props.backgroundColor;
  if (type === 'LinearProgressIndicator' && Number(props.progress) > 1) props.progress = Number(props.progress) / (Number(props.max) || 100);
  return { ...node, type, props, children: (node.children || []).map(migrateNode) };
};

export const migrateToComposeProject = (project) => {
  if (project?.platform === 'android-compose') return project;
  const base = createDefaultProject({
    ...project,
    name: project?.name || 'Android App',
    projectDir: `${PROJECTS_ROOT}/${project?.slug || slugifyProject(project?.name || 'android-app')}`,
    packageName: project?.packageName || `com.rnstudio.${packageSegment(project?.slug || project?.name)}`,
    screens: (project?.screens || []).map((screen, index) => ({
      ...screen,
      route: routeForMigration(screen, index),
      rootComponent: migrateNode(screen.rootComponent),
    })),
  });
  return { ...base, id: project.id || base.id, createdAt: project.createdAt || base.createdAt, updatedAt: Date.now() };
};

const routeForMigration = (screen, index) => index === 0 ? 'home' : (screen.route || slugifyProject(screen.name).replace(/-/g, '_'));

export default createDefaultProject;
