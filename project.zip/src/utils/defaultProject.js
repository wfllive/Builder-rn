import { generateId } from './generateId';

// Определения доступных компонентов для UI
export const componentTypes = {
  // Layouts
  LinearLayout: {
    type: 'LinearLayout',
    label: 'Linear Layout',
    icon: 'layers-outline',
    isContainer: true,
    defaultProps: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'wrap_content',
      padding: 8,
      backgroundColor: 'transparent',
      gravity: 'left',
    },
  },
  ScrollView: {
    type: 'ScrollView',
    label: 'Scroll View',
    icon: 'swap-vertical-outline',
    isContainer: true,
    defaultProps: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'match_parent',
      backgroundColor: 'transparent',
    },
  },
  // Basic Widgets
  TextView: {
    type: 'TextView',
    label: 'Text',
    icon: 'text-outline',
    isContainer: false,
    defaultProps: {
      text: 'Текст',
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#111827',
      textStyle: 'normal',
      gravity: 'left',
      padding: 4,
    },
  },
  Button: {
    type: 'Button',
    label: 'Button',
    icon: 'radio-button-on-outline',
    isContainer: false,
    defaultProps: {
      text: 'Кнопка',
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#FFFFFF',
      backgroundColor: '#4F46E5',
      padding: 12,
      borderRadius: 8,
    },
  },
  EditText: {
    type: 'EditText',
    label: 'Input',
    icon: 'create-outline',
    isContainer: false,
    defaultProps: {
      hint: 'Введите текст...',
      text: '',
      width: 'match_parent',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#111827',
      backgroundColor: '#FFFFFF',
      padding: 12,
      borderRadius: 8,
      inputType: 'text',
    },
  },
  ImageView: {
    type: 'ImageView',
    label: 'Image',
    icon: 'image-outline',
    isContainer: false,
    defaultProps: {
      width: 100,
      height: 100,
      scaleType: 'centerCrop',
      borderRadius: 0,
      backgroundColor: '#E5E7EB',
    },
  },
  CheckBox: {
    type: 'CheckBox',
    label: 'CheckBox',
    icon: 'checkbox-outline',
    isContainer: false,
    defaultProps: {
      text: 'Флажок',
      checked: false,
      width: 'wrap_content',
      height: 'wrap_content',
      textSize: 16,
      textColor: '#111827',
    },
  },
  Switch: {
    type: 'Switch',
    label: 'Switch',
    icon: 'toggle-outline',
    isContainer: false,
    defaultProps: {
      text: 'Переключатель',
      checked: false,
      width: 'wrap_content',
      height: 'wrap_content',
    },
  },
  ProgressBar: {
    type: 'ProgressBar',
    label: 'Progress',
    icon: 'speedometer-outline',
    isContainer: false,
    defaultProps: {
      progress: 50,
      max: 100,
      width: 'match_parent',
      height: 'wrap_content',
      color: '#4F46E5',
    },
  },
  CardView: {
    type: 'CardView',
    label: 'Card',
    icon: 'card-outline',
    isContainer: true,
    defaultProps: {
      width: 'match_parent',
      height: 'wrap_content',
      backgroundColor: '#FFFFFF',
      borderRadius: 12,
      padding: 16,
      elevation: 4,
    },
  },
  Divider: {
    type: 'Divider',
    label: 'Divider',
    icon: 'remove-outline',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 1,
      backgroundColor: '#D1D5DB',
      margin: 8,
    },
  },
  Spacer: {
    type: 'Spacer',
    label: 'Spacer',
    icon: 'expand-outline',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 16,
    },
  },
  WebView: {
    type: 'WebView',
    label: 'WebView',
    icon: 'globe-outline',
    isContainer: false,
    defaultProps: {
      url: 'https://example.com',
      width: 'match_parent',
      height: 300,
    },
  },
  MapView: {
    type: 'MapView',
    label: 'Map',
    icon: 'map-outline',
    isContainer: false,
    defaultProps: {
      width: 'match_parent',
      height: 300,
      latitude: 55.7558,
      longitude: 37.6173,
    },
  },
};

export const createDefaultScreen = (id, name) => ({
  id: id || generateId(),
  name,
  orientation: 'portrait',
  statusBarColor: '#FFFFFF',
  backgroundColor: '#F8FAFC',
  showStatusBar: true,
  showActionBar: true,
  actionBarTitle: name,
  rootComponent: {
    id: generateId(),
    type: 'LinearLayout',
    props: {
      orientation: 'vertical',
      width: 'match_parent',
      height: 'match_parent',
      padding: 16,
      backgroundColor: '#F8FAFC',
      gravity: 'left',
    },
    children: [
      {
        id: generateId(),
        type: 'TextView',
        props: {
          text: 'Добро пожаловать!',
          width: 'match_parent',
          height: 'wrap_content',
          textSize: 24,
          textColor: '#111827',
          textStyle: 'bold',
          gravity: 'center',
          padding: 16,
        },
        children: [],
      },
      {
        id: generateId(),
        type: 'Button',
        props: {
          text: 'Нажми меня',
          width: 'match_parent',
          height: 'wrap_content',
          textSize: 16,
          textColor: '#FFFFFF',
          backgroundColor: '#4F46E5',
          padding: 16,
          borderRadius: 8,
        },
        children: [],
      },
    ],
  },
  blocks: [
    {
      id: generateId(),
      definitionId: 'on_create',
      category: 'EVENT',
      position: { x: 20, y: 20 },
      inputs: {},
      children: {
        next: [
          {
            id: generateId(),
            definitionId: 'show_toast',
            category: 'COMPONENT',
            inputs: { text: 'Экран создан!' },
            children: {},
          },
        ],
      },
    },
  ],
});

// Шаблон проекта по умолчанию
export const createDefaultProject = (nameOrOptions = 'Новый проект') => {
  const options = typeof nameOrOptions === 'string' ? { name: nameOrOptions } : (nameOrOptions || {});
  const name = options.name || 'Новый проект';
  const slug = options.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `expo-app-${Date.now().toString(36)}`;
  return {
    id: generateId(),
    name,
    slug,
    projectDir: options.projectDir || `/root/projects/${slug}`,
    createdWith: options.createdWith || 'yarn create expo-app --template default@sdk-57',
    packageName: options.packageName || `com.app.${slug.replace(/-/g, '')}`,
    scheme: options.scheme || slug,
    sdkVersion: options.sdkVersion || '57.0.0',
    expoVersion: options.expoVersion || '~57.0.6',
    runtimeVersion: options.runtimeVersion || '1.0.0',
    versionName: options.versionName || '1.0.0',
    versionCode: options.versionCode || 1,
    dependencies: options.dependencies || {},
    devDependencies: options.devDependencies || {},
    createdAt: Date.now(),
    updatedAt: Date.now(),
    icon: 'phone-portrait-outline',
    theme: {
      primaryColor: '#4F46E5',
      secondaryColor: '#0E7490',
      backgroundColor: '#F8FAFC',
      isDark: false,
    },
    screens: [createDefaultScreen('main', 'Главный экран')],
    variables: [
      { id: generateId(), name: 'counter', type: 'number', value: 0 },
      { id: generateId(), name: 'username', type: 'text', value: '' },
    ],
    lists: [],
    components: [],
  };
};

export default createDefaultProject;
