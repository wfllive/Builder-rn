/**
 * raiSetup.js — первый запуск RAI-окружения (страница после установки Ubuntu).
 *
 * RAI — вендоренный в этот репозиторий (папка rai/): исходники + собранный
 * бандл rai.sh лежат в проекте и в APK (assets модуля apt-manager, путь
 * assets/rai/rai.sh — переживает expo prebuild --clean). GitHub-репозиторий
 * RAI не используется: нативный модуль копирует бандл в rootfs
 * (/root/rai/rai.sh), и установка запускается локально.
 *
 *   1. apt update && apt upgrade -y
 *   2. apt install curl wget zip unzip -y
 *   3. Node.js 24 (nodesource; запасной вариант — apt nodejs)
 *   4. bash /root/rai/rai.sh        (локальный бандл из APK)
 *   5. rai install base             (apt, JDK 17, утилиты)
 *   6. rai install sdk              (нативный ARM Android SDK)
 *   7. rai status                   (проверка) → marker /root/.rai-setup.done
 *
 * Каждый шаг идемпотентен: при повторном входе (после обрыва/фонового
 * сворачивания) уже выполненные шаги быстро пропускаются, установка
 * продолжается с места обрыва.
 */
import * as apt from '../../modules/apt-manager/src/index';
import { execute, streamExecute } from './shellExecutor';
import { updateBackground } from './background';

export const RAI_BUNDLE_DIR = '/root/rai';
export const RAI_BUNDLE = `${RAI_BUNDLE_DIR}/rai.sh`;
export const SETUP_MARKER = '/root/.rai-setup.done';
export const SETUP_LOG = '/root/.rai-setup.log';
export const ANDROID_HOME = '/root/android-sdk';
export const RAI_VERSION = '0.0.1'; // версия вендоренного RAI (rai/version.json)

const shq = (v = '') => `'${String(v).replace(/'/g, `'\\''`)}'`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Быстрая проверка «шаг уже сделан»: вывод DONE → пропустить.
const isDone = async (cmd) => {
  try {
    const r = await execute(`${cmd}; echo RC_$?`, '/');
    return /DONE/.test(r.output || '') && /RC_0\b/.test(r.output || '');
  } catch (e) {
    return false;
  }
};

/** Запустить команду со стримингом вывода; вернуть { success, output } (output полный). */
const streamRun = async (command, onLine, workDir = '/') => {
  const res = await streamExecute(command, workDir, (line) => { try { onLine && onLine(line); } catch (_) {} });
  return { success: res?.success === true && (res?.exitCode ?? 0) === 0, output: res?.output || '' };
};

/** Выполнить шаг: check (skip?) → cmd/run. */
const runStep = async (step, onLine) => {
  const startedAt = Date.now();
  const lines = [];
  const emit = (line) => { lines.push(line); try { onLine && onLine(line); } catch (_) {} };

  // 0) Проверка «уже сделано»
  if (step.check) {
    try {
      if (await isDone(step.check)) {
        return { id: step.id, status: 'skipped', output: lines.join('\n'), ms: Date.now() - startedAt };
      }
    } catch (_) {}
  }

  // 1) Кастомный раннер (seed бандла, rai status, финиш)
  if (typeof step.run === 'function') {
    const out = await step.run(emit);
    if (out === false) {
      return { id: step.id, status: 'failed', output: lines.join('\n'), ms: Date.now() - startedAt };
    }
    return { id: step.id, status: 'done', output: lines.join('\n'), ms: Date.now() - startedAt, extra: out };
  }

  // 2) Обычная shell-команда со стримингом
  const res = await streamRun(`${step.cmd} 2>&1; echo STEP_EXIT:$?`, emit);
  const ok = /STEP_EXIT:0\b/.test(res.output || '');
  if (!ok) {
    emit(`\n❌ Шаг не завершился (exit != 0)`);
    return { id: step.id, status: 'failed', output: lines.join('\n'), ms: Date.now() - startedAt };
  }
  return { id: step.id, status: 'done', output: lines.join('\n'), ms: Date.now() - startedAt };
};

// ---------------------------------------------------------------------------
// Шаги
// ---------------------------------------------------------------------------

export const SETUP_STEPS = [
  {
    id: 'apt',
    title: { ru: 'apt update && apt upgrade', en: 'apt update && apt upgrade' },
    cmd: 'export DEBIAN_FRONTEND=noninteractive; apt-get update -y && apt-get upgrade -y',
    check: 'command -v curl >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1 && [ -n "$(ls /var/lib/apt/lists/ 2>/dev/null | head -1)" ] && echo DONE || echo TODO',
  },
  {
    id: 'tools',
    title: { ru: 'Утилиты: curl, wget, zip, unzip', en: 'Utilities: curl, wget, zip, unzip' },
    cmd: 'export DEBIAN_FRONTEND=noninteractive; apt-get install -y curl wget zip unzip ca-certificates',
    check: 'command -v curl >/dev/null 2>&1 && command -v wget >/dev/null 2>&1 && command -v unzip >/dev/null 2>&1 && command -v zip >/dev/null 2>&1 && echo DONE || echo TODO',
  },
  {
    id: 'node',
    title: { ru: 'Node.js 24 (nodesource)', en: 'Node.js 24 (nodesource)' },
    // Уже есть node 24+? → пропускаем. Иначе nodesource setup_24.x, при сбое — apt nodejs.
    cmd:
      'if node -v 2>/dev/null | grep -qE "^v(2[0-9]|[0-9]{3,})"; then echo "node $(node -v) уже установлен"; ' +
      'elif curl -fsSL https://deb.nodesource.com/setup_24.x | bash - && apt-get install -y nodejs; then echo "node $(node -v) (nodesource 24.x)"; ' +
      'else apt-get install -y nodejs && echo "node $(node -v) (apt fallback)"; fi',
    check: 'node -v 2>/dev/null | grep -qE "^v(1[89]|[2-9][0-9])" && echo DONE || echo TODO',
  },
  {
    id: 'rai',
    title: { ru: 'Установка RAI (локальный бандл)', en: 'Install RAI (local bundle)' },
    // Спец-шаг: бандл из APK (assets/rai/rai.sh) копируется нативным модулем
    // в rootfs (/root/rai/rai.sh) и запускается локально — GitHub не нужен.
    // Первый запуск bash rai.sh сам ставит CLI в ~/.rai и лаунчер `rai`.
    check: `command -v rai >/dev/null 2>&1 && echo DONE || echo TODO`,
    run: async (emit) => {
      emit('$ seed RAI bundle (assets/rai/rai.sh → /root/rai/rai.sh)');
      let seeded = { success: false };
      try { seeded = await apt.seedRaiBundle(); } catch (e) { seeded = { success: false, output: String(e) }; }
      if (!seeded?.success) {
        // Файл мог быть засеян ранее напрямую — проверяем перед тем как падать.
        const probe = await execute(`[ -s ${shq(RAI_BUNDLE)} ] && echo YES || echo NO`, '/');
        if (!/YES/.test(probe.output || '')) {
          emit(`❌ ${seeded?.output || 'seedRaiBundle failed'}`);
          return false;
        }
        emit('⚠ бандл уже есть в rootfs — продолжаем');
      } else {
        emit(`✓ ${seeded.output} (${Math.round((seeded.bytes || 0) / 1024)} KB)`);
      }
      emit('');
      emit(`$ bash ${RAI_BUNDLE}  (локально, без GitHub)`);
      const res = await streamRun(`bash ${shq(RAI_BUNDLE)} 2>&1`, emit);
      const check = await execute('command -v rai >/dev/null 2>&1 && echo RAI_OK || echo RAI_MISSING', '/');
      if (!/RAI_OK/.test(check.output || '')) {
        emit('❌ команда rai не найдена после установки');
        return false;
      }
      return res;
    },
  },
  {
    id: 'base',
    title: { ru: 'rai install base (apt, JDK 17)', en: 'rai install base (apt, JDK 17)' },
    cmd: 'rai install base',
    check: 'command -v javac >/dev/null 2>&1 && command -v java >/dev/null 2>&1 && echo DONE || echo TODO',
  },
  {
    id: 'sdk',
    title: { ru: 'rai install sdk (нативный ARM SDK)', en: 'rai install sdk (native ARM SDK)' },
    cmd: 'rai install sdk',
    check: `[ -d ${ANDROID_HOME}/build-tools ] && [ -d ${ANDROID_HOME}/platforms ] && [ -d ${ANDROID_HOME}/platform-tools ] && echo DONE || echo TODO`,
  },
  {
    id: 'status',
    title: { ru: 'rai status — проверка компонентов', en: 'rai status — verify components' },
    always: true,
    run: async (emit) => {
      const res = await streamRun('rai status 2>&1', emit);
      const parsed = parseRaiStatus(res.output);
      emit('');
      emit(parsed.ok
        ? '✓ Java + build-tools + platforms на месте'
        : '❌ компоненты неполные: Java/сборка/платформы не найдены');
      return parsed.ok;
    },
  },
  {
    id: 'marker',
    title: { ru: 'Завершение установки', en: 'Finish setup' },
    always: true,
    run: async (emit) => {
      await execute(`mkdir -p /root && echo ok > ${shq(SETUP_MARKER)} && echo done > ${shq(SETUP_LOG)}`, '/');
      emit('✓ среда готова — переходим к проектам');
      return true;
    },
  },
];

// ---------------------------------------------------------------------------
// Парсер вывода `rai status`
// ---------------------------------------------------------------------------

export const parseRaiStatus = (output = '') => {
  const java = /Java\s*:\s*([^\n]+)/.exec(output);
  const bt = /build-tools\s*:\s*([^\n]+)/.exec(output);
  const pl = /platforms\s*:\s*([^\n]+)/.exec(output);
  const no = /нет|none/i;
  const ok = Boolean(
    java && bt && pl &&
    /\d/.test(java[1]) && !no.test(java[1]) &&
    /\d/.test(bt[1]) && !no.test(bt[1]) &&
    /android/i.test(pl[1]) && !no.test(pl[1]),
  );
  return {
    ok,
    java: java ? java[1].trim() : '',
    buildTools: bt ? bt[1].trim() : '',
    platforms: pl ? pl[1].trim() : '',
    output,
  };
};

// ---------------------------------------------------------------------------
// Прогон всей установки с пропуском готовых шагов
// ---------------------------------------------------------------------------

export const runRaiSetup = async ({ onStepStart, onStepEnd, onLine }) => {
  const summary = [];
  for (const step of SETUP_STEPS) {
    try { onStepStart && onStepStart(step.id, step); } catch (_) {}
    try { await updateBackground(step.title?.ru || step.id); } catch (_) {}
    const result = await runStep(step, onLine);
    summary.push(result);
    try { onStepEnd && onStepEnd(step.id, step, result); } catch (_) {}
    if (result.status === 'failed') {
      return { ok: false, summary };
    }
    await sleep(120);
  }
  return { ok: true, summary };
};

/**
 * Готова ли RAI-среда (для гейта в App.js): маркер ИЛИ полный `rai status`.
 * Быстрый шелл-прогон — не блокирует запуск приложения надолго.
 */
export const probeRaiReady = async () => {
  try {
    const r = await execute(
      `if [ -f ${shq(SETUP_MARKER)} ]; then echo READY; exit 0; fi; ` +
      'if command -v rai >/dev/null 2>&1; then ' +
      '  out=$(rai status 2>&1); ' +
      '  echo "$out" | grep -qE "Java[[:space:]]*:[[:space:]]*[0-9]" && ' +
      '  echo "$out" | grep -qE "build-tools[[:space:]]*:[[:space:]]*[0-9]" && ' +
      '  echo "$out" | grep -qE "platforms[[:space:]]*:[[:space:]]*android" && echo READY || echo NOT_READY; ' +
      'else echo NOT_READY; fi',
      '/',
    );
    return /READY/.test(r.output || '');
  } catch (e) {
    return false;
  }
};

export default { SETUP_STEPS, runRaiSetup, probeRaiReady, parseRaiStatus, RAI_BUNDLE_DIR, RAI_BUNDLE, SETUP_MARKER, ANDROID_HOME, RAI_VERSION };
