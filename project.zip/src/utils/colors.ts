export function getColor(ageMin: number) {
  if (ageMin < 2) return '#ff1744';
  if (ageMin < 5) return '#ff9100';
  if (ageMin < 10) return '#ffeb3b';
  if (ageMin < 20) return '#00e5ff';
  if (ageMin < 40) return '#7c4dff';
  if (ageMin < 90) return '#9e9e9e';
  return '#455a64';
}

// maplibre expression color by age
export function strikeColorExpression(nowSec: number) {
  // feature properties: ts (seconds)
  return [
    'case',
    ['<', ['-', nowSec, ['get', 'ts']], 120], '#ff1744',
    ['<', ['-', nowSec, ['get', 'ts']], 300], '#ff9100',
    ['<', ['-', nowSec, ['get', 'ts']], 600], '#ffeb3b',
    ['<', ['-', nowSec, ['get', 'ts']], 1200], '#00e5ff',
    ['<', ['-', nowSec, ['get', 'ts']], 2400], '#7c4dff',
    ['<', ['-', nowSec, ['get', 'ts']], 5400], '#9e9e9e',
    '#455a64'
  ];
}
