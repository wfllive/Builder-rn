/**
 * Compose project generator/synchroniser.
 *
 * The editor and rai work on the same disk image: rai new creates
 * the Gradle skeleton (build.gradle.kts, settings.gradle.kts, Theme.kt,
 * ...) and the editor owns every *Activity.kt file under
 * app/src/main/java/<package>/. The AndroidManifest is rewritten to
 * register every screen as its own Activity with the MAIN/LAUNCHER
 * intent filter on the first one.
 *
 * The full per-screen Kotlin source is produced by `buildActivitySource`
 * in activityTree.js, which knows how to splice the editor's component
 * tree, state declarations, and Block-Editor event code into the
 * standard MainActivity / <Name>Screen layout.
 *
 * `syncComposeProject` is the only function the editor needs to call
 * to push changes to the project: it writes every screen's *Activity.kt
 * and updates the manifest in one pass.
 */
import { writeWorkspaceFile, readWorkspaceFile } from './workspace';
import {
  ANDROID_GRADLE_PLUGIN, COMPILE_SDK, COMPOSE_BOM, GRADLE_VERSION,
  JAVA_VERSION, KOTLIN_VERSION, MIN_SDK, TARGET_SDK, getSourceRoot,
} from '../config/runtime';
import { buildActivitySource, updateActivitySource, upsertActivityInManifest } from './activityTree';

const kt = (value) => JSON.stringify(String(value ?? ''));
const hex = (value, fallback = '#000000') => /^#[0-9a-f]{6,8}$/i.test(String(value || '')) ? String(value) : fallback;

const baseDependencies = (project) => [
  'androidx.core:core-ktx:1.19.0',
  'androidx.activity:activity-compose:1.13.0',
  'androidx.lifecycle:lifecycle-runtime-ktx:2.10.0',
  ...(project.gradleDependencies || []),
];

export const generateAppGradle = (project) => {
  const dependencies = baseDependencies(project).map((d) => `    implementation(${kt(d)})`).join('\n');
  const hasSigning = Boolean(project.signing?.keystorePath && project.signing?.keyAlias);
  const signingBlock = hasSigning ? `
    signingConfigs {
        create("release") {
            storeFile = file(${kt(project.signing.keystorePath)})
            storePassword = System.getenv(${kt(project.signing.storePasswordEnv || 'KEYSTORE_PASSWORD')})
            keyAlias = ${kt(project.signing.keyAlias)}
            keyPassword = System.getenv(${kt(project.signing.keyPasswordEnv || 'KEY_PASSWORD')})
        }
    }
` : '';
  const releaseSigning = hasSigning ? 'signingConfig = signingConfigs.getByName("release"); ' : '';
  return `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = ${kt(project.namespace || project.packageName)}
    compileSdk = ${Number(project.compileSdk) || COMPILE_SDK}

    defaultConfig {
        applicationId = ${kt(project.packageName)}
        minSdk = ${Number(project.minSdk) || MIN_SDK}
        targetSdk = ${Number(project.targetSdk) || TARGET_SDK}
        versionCode = ${Number(project.versionCode) || 1}
        versionName = ${kt(project.versionName || '1.0.0')}
    }

${signingBlock}
    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release { ${releaseSigning}isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_${project.javaVersion || JAVA_VERSION}; targetCompatibility = JavaVersion.VERSION_${project.javaVersion || JAVA_VERSION} }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:${project.composeBom || COMPOSE_BOM}")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
${dependencies}
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
`;
};

const rootGradle = (project) => `plugins {
    id("com.android.application") version "${project.agpVersion || ANDROID_GRADLE_PLUGIN}" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "${project.kotlinVersion || KOTLIN_VERSION}" apply false
}
`;
const settingsGradle = (project) => `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = ${kt(project.name)}
include(":app")
`;

export const generateTheme = (project) => `package ${project.packageName}.ui.theme

import android.app.Activity
import android.graphics.Color as AndroidColor
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private fun color(value: String) = Color(AndroidColor.parseColor(value))
private val LightColors = lightColorScheme(
    primary = color("${hex(project.theme?.primaryColor, '#4F46E5')}"),
    secondary = color("${hex(project.theme?.secondaryColor, '#0E7490')}"),
    background = color("${hex(project.theme?.backgroundColor, '#F8FAFC')}")
)
private val DarkColors = darkColorScheme(primary = color("${hex(project.theme?.primaryColor, '#818CF8')}"))

@Composable
fun AppTheme(darkTheme: Boolean = ${project.theme?.isDark ? 'true' : 'isSystemInDarkTheme()'}, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val colors = if (${project.theme?.dynamicColor !== false} && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
`;

const buildManifest = (project, originalManifest) => {
  const activityNames = (project.screens || []).map((s) => s.name);
  if (!activityNames.length) return originalManifest;
  if (!originalManifest) {
    return [
      '<?xml version="1.0" encoding="utf-8"?>',
      '<manifest xmlns:android="http://schemas.android.com/apk/res/android">',
      '    <uses-permission android:name="android.permission.INTERNET" />',
      '    <application android:label="@string/app_name" android:theme="@style/Theme.RNStudio" android:allowBackup="true" android:supportsRtl="true">',
      ...activityNames.map((name, index) => {
        const filter = index === 0
          ? `\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>`
          : '';
        return `        <activity\n            android:name=".${name}Activity"${filter}\n            android:exported="true" />`;
      }),
      '    </application>',
      '</manifest>',
    ].join('\n');
  }
  return upsertActivityInManifest(originalManifest, project.packageName, activityNames);
};

/**
 * Write every screen's *Activity.kt and refresh the AndroidManifest.
 * Other files (Gradle build, Theme.kt, settings.gradle.kts, ...) are
 * owned by rai and are never touched.
 *
 * If the *Activity.kt file already exists with a user-defined
 * Composable (the standard rai template shape), the editor splices
 * the new tree into that function's body without touching the
 * rest of the file. Only brand-new screens fall back to a full
 * source emission.
 */
export const syncComposeProject = async (project) => {
  if (!project) return { success: false, output: 'No project' };
  const screens = project.screens || [];
  if (!screens.length) {
    return { success: false, output: 'Project has no screens. Add a screen with the + button first.' };
  }
  const sourceRoot = getSourceRoot(project);
  const { readWorkspaceFile } = await import('./workspace');
  const results = [];
  for (const screen of screens) {
    const fileName = `${sourceRoot}/${screen.name}Activity.kt`;
    const read = await readWorkspaceFile(project, fileName);
    let source;
    if (read.success) {
      const update = updateActivitySource(read.output, screen);
      if (update.replaced) {
        source = update.source;
      } else {
        // File is in a shape we can't edit (e.g. no setContent).
        // Don't clobber it - just record the issue.
        results.push(`${fileName} (unchanged - unsupported template)`);
        continue;
      }
    } else {
      // Brand-new screen, no file yet. Emit a minimal Activity.
      source = buildActivitySource(screen, project);
    }
    const r = await writeWorkspaceFile(project, fileName, source);
    if (!r?.success) return { success: false, output: `Failed to write ${fileName}: ${r?.output}` };
    results.push(fileName);
  }
  // AndroidManifest.xml
  const manifestRelative = 'app/src/main/AndroidManifest.xml';
  const manifestRead = await readWorkspaceFile(project, manifestRelative);
  const newManifest = buildManifest(project, manifestRead.output);
  const w = await writeWorkspaceFile(project, manifestRelative, newManifest);
  if (!w?.success) return { success: false, output: `Failed to write ${manifestRelative}: ${w?.output}` };
  await writeWorkspaceFile(project, '.rnstudio/model.json', `${JSON.stringify(project, null, 2)}\n`);
  return { success: true, output: `Synchronized ${results.length} *Activity.kt files and AndroidManifest.xml` };
};

export const createComposeProjectFiles = (project) => {
  const sourceRoot = getSourceRoot(project);
  const files = {
    'settings.gradle.kts': settingsGradle(project),
    'build.gradle.kts': rootGradle(project),
    'gradle.properties': 'org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nkotlin.code.style=official\nandroid.nonTransitiveRClass=true\n',
    'app/build.gradle.kts': generateAppGradle(project),
    'app/proguard-rules.pro': '# Add project-specific R8 rules here.\n',
    'app/src/main/res/values/strings.xml': `<?xml version="1.0" encoding="utf-8"?><resources><string name="app_name">${String(project.name).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</string></resources>\n`,
    [`${sourceRoot}/ui/theme/Theme.kt`]: generateTheme(project),
    '.gitignore': '.gradle/\n.idea/\nlocal.properties\nbuild/\n**/build/\n*.jks\n*.keystore\n',
    'README.md': `# ${project.name}\n\nGenerated by Compose Studio for Jetpack Compose.\n\n## Build\n\n\`\`\`sh\n./gradlew assembleDebug\n./gradlew assembleRelease\n./gradlew bundleRelease\n\`\`\`\n`,
  };
  (project.screens || []).forEach((screen) => {
    files[`${sourceRoot}/${screen.name}Activity.kt`] = buildActivitySource(screen, project);
  });
  files['app/src/main/AndroidManifest.xml'] = buildManifest(project, null);
  return files;
};

export const writeComposeProject = async (project) => {
  const entries = Object.entries(createComposeProjectFiles(project));
  const results = [];
  for (const [fileName, content] of entries) results.push(await writeWorkspaceFile(project, fileName, content));
  const failed = results.find((r) => !r?.success);
  if (failed) return failed;
  await writeWorkspaceFile(project, '.rnstudio/model.json', `${JSON.stringify(project, null, 2)}\n`);
  return { success: true, output: `Generated ${entries.length + 1} Jetpack Compose files` };
};

// Backwards-compat shims so existing callers still work.
export const buildScreenActivitySource = buildActivitySource;
export const generateComposeScreen = (project, screen) => buildActivitySource(screen, project);
export const generateComposePreviewSource = generateComposeScreen;
export const getComposeScreenClass = (screen) => `${screen.name}Activity`;
export const getComposeRoute = () => 'home';
export const getBaseGradleDependencies = baseDependencies;

export const runGradleCommand = (task) => `chmod +x ./gradlew && ./gradlew ${task} --console=plain --stacktrace`;
