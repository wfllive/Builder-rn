import { writeWorkspaceFile } from './workspace';
import {
  ANDROID_GRADLE_PLUGIN, COMPILE_SDK, COMPOSE_BOM, GRADLE_VERSION,
  JAVA_VERSION, KOTLIN_VERSION, MIN_SDK, TARGET_SDK, getSourceRoot,
} from '../config/runtime';

const kt = (value) => JSON.stringify(String(value ?? ''));
const safeIdentifier = (value, fallback = 'value') => {
  const raw = String(value || '').replace(/[^A-Za-z0-9_]/g, '_');
  const prefixed = /^[A-Za-z_]/.test(raw) ? raw : `_${raw}`;
  return prefixed || fallback;
};
const pascal = (value, fallback = 'Screen') => {
  const parts = String(value || '').replace(/[^A-Za-zА-Яа-я0-9]+/g, ' ').trim().split(/\s+/).filter(Boolean);
  const ascii = parts.map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join('').replace(/[^A-Za-z0-9_]/g, '');
  return (/^[A-Za-z_]/.test(ascii) ? ascii : `Screen${ascii}`) || fallback;
};
const routeFor = (screen, index) => index === 0 ? 'home' : (screen.route || `screen_${index + 1}`).replace(/[^A-Za-z0-9_]/g, '_').toLowerCase();
const hex = (value, fallback = '#000000') => /^#[0-9a-f]{6,8}$/i.test(String(value || '')) ? String(value) : fallback;
const dp = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

const inputValue = (block, ...names) => {
  for (const name of names) {
    const value = block.inputs?.[name];
    if (value !== undefined && value !== '') return value;
  }
  return '';
};

const literal = (value, variables = []) => {
  const text = String(value ?? '').trim();
  if (!text) return '""';
  if (/^-?\d+(\.\d+)?$/.test(text) || ['true', 'false', 'null'].includes(text)) return text;
  if (variables.includes(text)) return safeIdentifier(text);
  return kt(text);
};
const boolExpression = (value, variables = []) => {
  const text = String(value ?? '').trim();
  if (['true', 'false'].includes(text)) return text;
  if (variables.includes(text)) return safeIdentifier(text);
  return text ? `${literal(text, variables)}.toString().toBoolean()` : 'false';
};

const compileActions = (blocks, context, indent = '            ') => (blocks || []).map((block) => {
  const following = () => compileActions(block.children?.next || [], context, indent);
  const append = (line) => [line, following()].filter(Boolean).join('\n');
  const variables = context.variables;
  switch (block.definitionId) {
    case 'show_toast':
      return append(`${indent}Toast.makeText(context, ${literal(inputValue(block, 'text', 'текст'), variables)}, Toast.LENGTH_SHORT).show()`);
    case 'navigate': {
      const requested = String(inputValue(block, 'screen', 'экран')).trim();
      const route = context.routes.find((item) => item.name === requested || item.route === requested)?.route || requested || 'home';
      return append(`${indent}navController.navigate(${kt(route)})`);
    }
    case 'wait':
      return append(`${indent}delay(${Math.max(0, Number(inputValue(block, 'ms', 'мс')) || 0)}L)`);
    case 'set_var': {
      const name = String(inputValue(block, 'name', 'имя')).trim();
      if (!variables.includes(name)) return append(`${indent}// Unknown state: ${name}`);
      const expression = literal(inputValue(block, 'value', 'значение'), variables);
      const type = context.variableTypes?.[name];
      const converted = type === 'number' ? `(${expression}).toString().toIntOrNull().orZero()` : type === 'boolean' ? `(${expression}).toString().toBoolean()` : `(${expression}).toString()`;
      return append(`${indent}${safeIdentifier(name)} = ${converted}`);
    }
    case 'change_var': {
      const name = String(inputValue(block, 'name', 'имя')).trim();
      return append(variables.includes(name) ? `${indent}${safeIdentifier(name)} = ${safeIdentifier(name)} + (${literal(inputValue(block, 'value', 'значение'), variables)}).toString().toIntOrNull().orZero()` : `${indent}// Unknown state: ${name}`);
    }
    case 'set_text':
      return append(`${indent}componentText[${kt(inputValue(block, 'component', 'компонент'))}] = ${literal(inputValue(block, 'text', 'текст'), variables)}.toString()`);
    case 'set_visible':
      return append(`${indent}componentVisible[${kt(inputValue(block, 'component', 'компонент'))}] = ${boolExpression(inputValue(block, 'visible', 'видимый'), variables)}`);
    case 'if_else': {
      const yes = compileActions(block.children?.do || [], context, `${indent}    `) || `${indent}    // Add actions`;
      const no = compileActions(block.children?.else || [], context, `${indent}    `);
      const code = no
        ? `${indent}if (${boolExpression(inputValue(block, 'condition', 'условие'), variables)}) {\n${yes}\n${indent}} else {\n${no}\n${indent}}`
        : `${indent}if (${boolExpression(inputValue(block, 'condition', 'условие'), variables)}) {\n${yes}\n${indent}}`;
      return append(code);
    }
    case 'repeat': {
      const body = compileActions(block.children?.do || [], context, `${indent}    `) || `${indent}    // Add repeated actions`;
      const count = Math.max(0, Number(inputValue(block, 'times', 'раз')) || 0);
      return append(`${indent}repeat(${count}) {\n${body}\n${indent}}`);
    }
    default:
      return append(`${indent}// ${block.definitionId} is available as an expression block`);
  }
}).filter(Boolean).join('\n');

const modifier = (props = {}, options = {}) => {
  const calls = ['Modifier'];
  if (props.width === 'match_parent') calls.push('fillMaxWidth()');
  else if (Number.isFinite(Number(props.width))) calls.push(`width(${dp(props.width)}.dp)`);
  if (props.height === 'match_parent') calls.push('fillMaxHeight()');
  else if (Number.isFinite(Number(props.height))) calls.push(`height(${dp(props.height)}.dp)`);
  if (options.weight) calls.push(`weight(${options.weight}f)`);
  if (props.padding) calls.push(`padding(${dp(props.padding)}.dp)`);
  if (props.backgroundColor && props.backgroundColor !== 'transparent') calls.push(`background(composeColor(${kt(hex(props.backgroundColor, '#FFFFFF'))}))`);
  if (props.borderRadius) calls.push(`clip(RoundedCornerShape(${dp(props.borderRadius)}.dp))`);
  return calls.join('.');
};

const alignment = (value, axis) => {
  const key = String(value || '').toLowerCase();
  if (axis === 'horizontal') return key.includes('center') ? 'Alignment.CenterHorizontally' : key.includes('end') || key.includes('right') ? 'Alignment.End' : 'Alignment.Start';
  return key.includes('bottom') || key.includes('end') ? 'Alignment.Bottom' : key.includes('center') ? 'Alignment.CenterVertically' : 'Alignment.Top';
};
const arrangement = (value, axis) => {
  const key = String(value || '').toLowerCase();
  const prefix = axis === 'horizontal' ? 'Arrangement' : 'Arrangement';
  if (key.includes('spacebetween')) return `${prefix}.SpaceBetween`;
  if (key.includes('spacearound')) return `${prefix}.SpaceAround`;
  if (key.includes('spaceevenly')) return `${prefix}.SpaceEvenly`;
  if (key.includes('center')) return `${prefix}.Center`;
  if (key.includes('end') || key.includes('bottom')) return `${prefix}.Bottom`;
  return `${prefix}.Top`;
};

const composeNode = (component, context, indent = '        ') => {
  if (!component) return `${indent}Spacer(Modifier)`;
  const p = component.props || {};
  const id = String(component.id);
  const visibleStart = `${indent}if (componentVisible[${kt(id)}] != false) {`;
  const inner = `${indent}    `;
  const visibleEnd = `${indent}}`;
  const children = (component.children || []).map((child) => composeNode(child, context, `${inner}    `)).join('\n');
  let body = '';
  switch (component.type) {
    case 'Column':
      body = `${inner}Column(modifier = ${modifier(p)}, horizontalAlignment = ${alignment(p.horizontalAlignment, 'horizontal')}, verticalArrangement = Arrangement.spacedBy(${dp(p.spacing, 0)}.dp)) {\n${children}\n${inner}}`;
      break;
    case 'Row':
      body = `${inner}Row(modifier = ${modifier(p)}, horizontalArrangement = Arrangement.spacedBy(${dp(p.spacing, 0)}.dp), verticalAlignment = ${alignment(p.verticalAlignment, 'vertical')}) {\n${children}\n${inner}}`;
      break;
    case 'Box':
      body = `${inner}Box(modifier = ${modifier(p)}, contentAlignment = Alignment.TopStart) {\n${children}\n${inner}}`;
      break;
    case 'LazyColumn': {
      const items = (component.children || []).map((child) => `${inner}        item(key = ${kt(child.id)}) {\n${composeNode(child, context, `${inner}            `)}\n${inner}        }`).join('\n');
      body = `${inner}LazyColumn(modifier = ${modifier(p)}, contentPadding = PaddingValues(${dp(p.padding, 0)}.dp), verticalArrangement = Arrangement.spacedBy(${dp(p.spacing, 0)}.dp)) {\n${items}\n${inner}}`;
      break;
    }
    case 'Card':
      body = `${inner}Card(modifier = ${modifier({ ...p, padding: 0, backgroundColor: 'transparent', borderRadius: 0 })}, shape = RoundedCornerShape(${dp(p.borderRadius, 16)}.dp), colors = CardDefaults.cardColors(containerColor = composeColor(${kt(hex(p.backgroundColor, '#FFFFFF'))})), elevation = CardDefaults.cardElevation(${dp(p.elevation, 2)}.dp)) {\n${inner}    Column(Modifier.padding(${dp(p.padding, 16)}.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {\n${children}\n${inner}    }\n${inner}}`;
      break;
    case 'Text':
      body = `${inner}Text(text = componentText[${kt(id)}] ?: ${kt(p.text || '')}, modifier = ${modifier(p)}, color = composeColor(${kt(hex(p.textColor, '#111827'))}), fontSize = ${dp(p.textSize, 16)}.sp, fontWeight = ${p.textStyle === 'bold' ? 'FontWeight.Bold' : 'FontWeight.Normal'}, fontStyle = ${p.textStyle === 'italic' ? 'FontStyle.Italic' : 'FontStyle.Normal'}, textAlign = ${String(p.textAlign).toLowerCase().includes('center') ? 'TextAlign.Center' : String(p.textAlign).toLowerCase().includes('end') ? 'TextAlign.End' : 'TextAlign.Start'})`;
      break;
    case 'Button': {
      const handler = context.clickHandlers[id] || context.defaultClick || '{}';
      body = `${inner}Button(onClick = ${handler}, enabled = ${p.enabled !== false}, modifier = ${modifier({ ...p, padding: 0, backgroundColor: 'transparent', borderRadius: 0 })}, shape = RoundedCornerShape(${dp(p.borderRadius, 12)}.dp), colors = ButtonDefaults.buttonColors(containerColor = composeColor(${kt(hex(p.backgroundColor, '#4F46E5'))}))) { Text(componentText[${kt(id)}] ?: ${kt(p.text || 'Button')}, color = composeColor(${kt(hex(p.textColor, '#FFFFFF'))}), fontSize = ${dp(p.textSize, 15)}.sp) }`;
      break;
    }
    case 'OutlinedTextField':
      body = `${inner}OutlinedTextField(value = componentText[${kt(id)}] ?: ${kt(p.text || '')}, onValueChange = { componentText[${kt(id)}] = it }, modifier = ${modifier(p)}, label = { Text(${kt(p.label || 'Field')}) }, placeholder = { Text(${kt(p.hint || '')}) }, singleLine = ${p.singleLine !== false})`;
      break;
    case 'Image':
      body = `${inner}Box(modifier = ${modifier({ ...p, padding: 0 })}.background(composeColor(${kt(hex(p.backgroundColor, '#E5E7EB'))})), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, contentDescription = ${kt(p.contentDescription || 'Image')}, tint = Color.Gray, modifier = Modifier.size(40.dp)) }`;
      break;
    case 'Checkbox':
      body = `${inner}Row(modifier = ${modifier(p)}, verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = componentChecked[${kt(id)}] ?: ${Boolean(p.checked)}, onCheckedChange = { componentChecked[${kt(id)}] = it }, enabled = ${p.enabled !== false}); Text(componentText[${kt(id)}] ?: ${kt(p.text || 'Checkbox')}, color = composeColor(${kt(hex(p.textColor, '#111827'))}), fontSize = ${dp(p.textSize, 16)}.sp) }`;
      break;
    case 'Switch':
      body = `${inner}Row(modifier = ${modifier(p)}, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text(componentText[${kt(id)}] ?: ${kt(p.text || 'Switch')}); Switch(checked = componentChecked[${kt(id)}] ?: ${Boolean(p.checked)}, onCheckedChange = { componentChecked[${kt(id)}] = it }, enabled = ${p.enabled !== false}) }`;
      break;
    case 'LinearProgressIndicator':
      body = `${inner}LinearProgressIndicator(progress = { ${(Number(p.progress) || 0.5).toFixed(2)}f }, modifier = ${modifier(p)}, color = composeColor(${kt(hex(p.color, '#4F46E5'))}), trackColor = composeColor(${kt(hex(p.trackColor, '#E5E7EB'))}))`;
      break;
    case 'CircularProgressIndicator':
      body = `${inner}CircularProgressIndicator(progress = { ${(Number(p.progress) || 0.7).toFixed(2)}f }, modifier = ${modifier(p)}, color = composeColor(${kt(hex(p.color, '#4F46E5'))}), strokeWidth = ${dp(p.strokeWidth, 4)}.dp)`;
      break;
    case 'HorizontalDivider':
      body = `${inner}HorizontalDivider(modifier = ${modifier(p)}, thickness = ${dp(p.height, 1)}.dp, color = composeColor(${kt(hex(p.color, '#D1D5DB'))}))`;
      break;
    case 'Spacer':
      body = `${inner}Spacer(modifier = ${modifier(p)})`;
      break;
    case 'Icon': {
      const supportedIcons = new Set(['Favorite', 'Home', 'Settings', 'Person', 'Search', 'Add', 'Delete', 'Edit', 'Check', 'Close', 'Menu', 'Info', 'Warning', 'Star', 'Email', 'Phone', 'LocationOn']);
      const iconName = supportedIcons.has(String(p.iconName)) ? String(p.iconName) : 'Favorite';
      body = `${inner}Icon(imageVector = Icons.Default.${iconName}, contentDescription = ${kt(p.contentDescription || 'Icon')}, tint = composeColor(${kt(hex(p.tint, '#4F46E5'))}), modifier = Modifier.size(${dp(p.size, 28)}.dp))`;
      break;
    }
    case 'WebView':
      body = `${inner}AndroidView(factory = { context -> WebView(context).apply { settings.javaScriptEnabled = true; loadUrl(${kt(p.url || 'https://example.com')}) } }, modifier = ${modifier(p)})`;
      break;
    default:
      body = `${inner}Text(${kt(`Unsupported: ${component.type}`)}, color = Color.Red)`;
  }
  return `${visibleStart}\n${body}\n${visibleEnd}`;
};

const screenClass = (screen, index) => `${pascal(screen.name, `Screen${index + 1}`)}Screen`;

export const generateComposeScreen = (project, screen, index = 0) => {
  const routes = (project.screens || []).map((item, routeIndex) => ({ name: item.name, route: routeFor(item, routeIndex) }));
  const variables = (project.variables || []).map((item) => item.name);
  const variableTypes = Object.fromEntries((project.variables || []).map((item) => [item.name, item.type]));
  const clickEvents = (screen.blocks || []).filter((block) => block.definitionId === 'on_click');
  const clickHandlers = {};
  let defaultClick = null;
  clickEvents.forEach((event, eventIndex) => {
    const handler = `{ scope.launch { handleClick${eventIndex + 1}() } }`;
    const componentId = String(inputValue(event, 'component', 'компонент')).trim();
    if (componentId) clickHandlers[componentId] = handler;
    else if (!defaultClick) defaultClick = handler;
  });
  const context = { variables, variableTypes, routes, clickHandlers, defaultClick };
  const state = (project.variables || []).map((variable) => {
    const initial = variable.type === 'number' ? Number(variable.value) || 0 : variable.type === 'boolean' ? Boolean(variable.value) : kt(variable.value || '');
    return `    var ${safeIdentifier(variable.name)} by rememberSaveable { mutableStateOf(${initial}) }`;
  }).join('\n');
  const handlers = clickEvents.map((event, eventIndex) => `    suspend fun handleClick${eventIndex + 1}() {\n${compileActions(event.children?.next || [], context, '        ') || '        // Add click actions in Compose Studio'}\n    }`).join('\n\n');
  const createEvents = (screen.blocks || []).filter((block) => block.definitionId === 'on_create');
  const loose = (screen.blocks || []).filter((block) => !['on_create', 'on_click', 'on_back_pressed'].includes(block.definitionId));
  const createActions = [...createEvents.map((event) => compileActions(event.children?.next || [], context, '        ')), compileActions(loose, context, '        ')].filter(Boolean).join('\n');
  const backEvents = (screen.blocks || []).filter((block) => block.definitionId === 'on_back_pressed');
  const backActions = backEvents.map((event) => compileActions(event.children?.next || [], context, '            ')).filter(Boolean).join('\n');
  const content = composeNode(screen.rootComponent, context, '            ');
  const name = screenClass(screen, index);

  return `package ${project.packageName}.ui.screens

import android.graphics.Color as AndroidColor
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${name}(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val componentText = remember { mutableStateMapOf<String, String>() }
    val componentVisible = remember { mutableStateMapOf<String, Boolean>() }
    val componentChecked = remember { mutableStateMapOf<String, Boolean>() }
${state || '    // Project state appears here.'}

${handlers || '    // Click handlers appear here.'}

    LaunchedEffect(Unit) {
${createActions || '        // Screen start actions appear here.'}
    }
${backEvents.length ? `
    BackHandler {
        scope.launch {
${backActions || '            navController.popBackStack()'}
        }
    }
` : ''}
    Scaffold(
        topBar = {
            ${screen.showActionBar === false ? '{}' : `TopAppBar(title = { Text(${kt(screen.actionBarTitle || screen.name)}) }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } })`}
        },
        containerColor = composeColor(${kt(hex(screen.backgroundColor, '#F8FAFC'))})
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
${content}
        }
    }
}

@Preview(name = ${kt(screen.name)}, showBackground = true, showSystemUi = true, widthDp = 360, heightDp = 800)
@Composable
private fun ${name}Preview() {
    MaterialTheme { ${name}(rememberNavController()) }
}

private fun composeColor(hex: String): Color = Color(AndroidColor.parseColor(hex))
private fun Int?.orZero(): Int = this ?: 0
`;
};

export const generateMainActivity = (project) => {
  const imports = (project.screens || []).map((screen, index) => `import ${project.packageName}.ui.screens.${screenClass(screen, index)}`).join('\n');
  const routes = (project.screens || []).map((screen, index) => `                composable(${kt(routeFor(screen, index))}) { ${screenClass(screen, index)}(navController) }`).join('\n');
  return `package ${project.packageName}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import ${project.packageName}.ui.theme.AppTheme
${imports}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "home") {
${routes}
                    }
                }
            }
        }
    }
}
`;
};

export const generateTheme = (project) => `package ${project.packageName}.ui.theme

import android.app.Activity
import android.graphics.Color as AndroidColor
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private fun color(value: String) = Color(AndroidColor.parseColor(value))
private val LightColors = lightColorScheme(
    primary = color("${hex(project.theme?.primaryColor, '#4F46E5')}"),
    secondary = color("${hex(project.theme?.secondaryColor, '#0E7490')}"),
    background = color("${hex(project.theme?.backgroundColor, '#F8FAFC')}")
)
private val DarkColors = darkColorScheme(primary = color("${hex(project.theme?.primaryColor, '#818CF8')}"))

@Composable
fun AppTheme(darkTheme: Boolean = ${project.theme?.isDark ? 'true' : 'isSystemInDarkTheme()'}, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val colors = if (${project.theme?.dynamicColor !== false} && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
`;

const baseDependencies = (project) => [
  'androidx.core:core-ktx:1.19.0',
  'androidx.activity:activity-compose:1.13.0',
  'androidx.lifecycle:lifecycle-runtime-ktx:2.10.0',
  'androidx.navigation:navigation-compose:2.9.8',
  ...(project.gradleDependencies || []),
];

export const generateAppGradle = (project) => {
  const dependencies = baseDependencies(project).map((dependency) => `    implementation(${kt(dependency)})`).join('\n');
  const hasSigning = Boolean(project.signing?.keystorePath && project.signing?.keyAlias);
  const signingBlock = hasSigning ? `
    signingConfigs {
        create("release") {
            storeFile = file(${kt(project.signing.keystorePath)})
            storePassword = System.getenv(${kt(project.signing.storePasswordEnv || 'KEYSTORE_PASSWORD')})
            keyAlias = ${kt(project.signing.keyAlias)}
            keyPassword = System.getenv(${kt(project.signing.keyPasswordEnv || 'KEY_PASSWORD')})
        }
    }
` : '';
  const releaseSigning = hasSigning ? 'signingConfig = signingConfigs.getByName("release"); ' : '';
  return `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = ${kt(project.namespace || project.packageName)}
    compileSdk = ${Number(project.compileSdk) || COMPILE_SDK}

    defaultConfig {
        applicationId = ${kt(project.packageName)}
        minSdk = ${Number(project.minSdk) || MIN_SDK}
        targetSdk = ${Number(project.targetSdk) || TARGET_SDK}
        versionCode = ${Number(project.versionCode) || 1}
        versionName = ${kt(project.versionName || '1.0.0')}
    }

${signingBlock}
    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release { ${releaseSigning}isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_${project.javaVersion || JAVA_VERSION}; targetCompatibility = JavaVersion.VERSION_${project.javaVersion || JAVA_VERSION} }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:${project.composeBom || COMPOSE_BOM}")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
${dependencies}
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
`;
};

const rootGradle = (project) => `plugins {
    id("com.android.application") version "${project.agpVersion || ANDROID_GRADLE_PLUGIN}" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "${project.kotlinVersion || KOTLIN_VERSION}" apply false
}
`;
const settingsGradle = (project) => `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = ${kt(project.name)}
include(":app")
`;
const manifest = () => `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application android:theme="@style/Theme.RNStudio" android:label="@string/app_name" android:allowBackup="true" android:supportsRtl="true">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
const stylesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources><style name="Theme.RNStudio" parent="android:style/Theme.Material.Light.NoActionBar"><item name="android:fontFamily">sans</item><item name="android:windowLightStatusBar">true</item><item name="android:navigationBarColor">#FFFFFF</item><item name="android:statusBarColor">#FFFFFF</item></style></resources>
`;
const gradlew = (version) => `#!/usr/bin/env sh
set -eu
VERSION="${version || GRADLE_VERSION}"
BASE="\${HOME}/.rn-studio/gradle"
HOME_DIR="\${BASE}/gradle-\${VERSION}"
ZIP="\${BASE}/gradle-\${VERSION}-bin.zip"
if [ ! -x "\${HOME_DIR}/bin/gradle" ]; then
  mkdir -p "\${BASE}"
  URL="https://services.gradle.org/distributions/gradle-\${VERSION}-bin.zip"
  echo "Downloading Gradle \${VERSION}..."
  if command -v curl >/dev/null 2>&1; then curl -fL "\${URL}" -o "\${ZIP}"; else wget -O "\${ZIP}" "\${URL}"; fi
  command -v unzip >/dev/null 2>&1 || { echo "unzip is required"; exit 1; }
  unzip -qo "\${ZIP}" -d "\${BASE}"
fi
exec "\${HOME_DIR}/bin/gradle" "$@"
`;

export const createComposeProjectFiles = (project) => {
  const sourceRoot = getSourceRoot(project);
  const files = {
    'settings.gradle.kts': settingsGradle(project),
    'build.gradle.kts': rootGradle(project),
    'gradle.properties': 'org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nkotlin.code.style=official\nandroid.nonTransitiveRClass=true\n',
    'gradle/wrapper/gradle-wrapper.properties': `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-${project.gradleVersion || GRADLE_VERSION}-bin.zip\nnetworkTimeout=10000\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists\n`,
    gradlew: gradlew(project.gradleVersion),
    'gradlew.bat': `@echo off\r\nset VERSION=${project.gradleVersion || GRADLE_VERSION}\r\nset BASE=%USERPROFILE%\\.rn-studio\\gradle\r\nset GRADLE_HOME=%BASE%\\gradle-%VERSION%\r\nif not exist "%GRADLE_HOME%\\bin\\gradle.bat" (\r\n  if not exist "%BASE%" mkdir "%BASE%"\r\n  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\\gradle.zip'; Expand-Archive -Force '%BASE%\\gradle.zip' '%BASE%'"\r\n)\r\ncall "%GRADLE_HOME%\\bin\\gradle.bat" %*\r\n`,
    'app/build.gradle.kts': generateAppGradle(project),
    'app/proguard-rules.pro': '# Add project-specific R8 rules here.\n',
    'app/src/main/AndroidManifest.xml': manifest(),
    'app/src/main/res/values/styles.xml': stylesXml,
    'app/src/main/res/values/strings.xml': `<?xml version="1.0" encoding="utf-8"?><resources><string name="app_name">${String(project.name).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</string></resources>\n`,
    [`${sourceRoot}/MainActivity.kt`]: generateMainActivity(project),
    [`${sourceRoot}/ui/theme/Theme.kt`]: generateTheme(project),
    '.gitignore': '.gradle/\n.idea/\nlocal.properties\nbuild/\n**/build/\n*.jks\n*.keystore\n',
    'README.md': `# ${project.name}\n\nGenerated by Compose Studio for Jetpack Compose.\n\n## Build\n\n\`\`\`sh\n./gradlew assembleDebug\n./gradlew assembleRelease\n./gradlew bundleRelease\n\`\`\`\n`,
  };
  (project.screens || []).forEach((screen, index) => {
    files[`${sourceRoot}/ui/screens/${screenClass(screen, index)}.kt`] = generateComposeScreen(project, screen, index);
  });
  files['.rnstudio/project.json'] = `${JSON.stringify({ platform: 'android-compose', projectId: project.id, updatedAt: project.updatedAt }, null, 2)}\n`;
  return files;
};

export const writeComposeProject = async (project) => {
  const entries = Object.entries(createComposeProjectFiles(project));
  const results = [];
  for (const [fileName, content] of entries) results.push(await writeWorkspaceFile(project, fileName, content));
  const failed = results.find((result) => !result?.success);
  if (failed) return failed;
  await writeWorkspaceFile(project, '.rnstudio/model.json', `${JSON.stringify(project, null, 2)}\n`);
  return { success: true, output: `Generated ${entries.length + 1} Jetpack Compose files` };
};

// Rai owns Gradle/settings/build files. Compose Studio only synchronizes Kotlin UI sources.
export const syncComposeProject = async (project) => {
  const files = createComposeProjectFiles(project);
  const sourceEntries = Object.entries(files).filter(([fileName]) => fileName.endsWith('.kt'));
  const results = [];
  for (const [fileName, content] of sourceEntries) results.push(await writeWorkspaceFile(project, fileName, content));
  const failed = results.find((result) => !result?.success);
  if (failed) return failed;
  await writeWorkspaceFile(project, '.rnstudio/model.json', `${JSON.stringify(project, null, 2)}\\n`);
  return { success: true, output: `Synchronized ${sourceEntries.length} Rai Kotlin sources` };
};
export const generateComposePreviewSource = generateComposeScreen;
export const getComposeScreenClass = screenClass;
export const getComposeRoute = routeFor;
export const getBaseGradleDependencies = baseDependencies;

export const runGradleCommand = (task) => `chmod +x ./gradlew && ./gradlew ${task} --console=plain --stacktrace`;
