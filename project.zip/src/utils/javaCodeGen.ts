/**
 * Java + XML Code Generator
 *
 * Генерирует Java код активити и XML layout из дерева компонентов.
 * Замена старому Kotlin/Compose генератору.
 */

export interface JavaProjectConfig {
  appName: string;
  packageName: string;
  minSdk: number;
  targetSdk: number;
  versionCode: number;
  versionName: string;
}

export interface JavaFile {
  path: string;
  content: string;
}

/**
 * Генерирует все файлы Java+XML проекта из конфигурации
 */
export function generateJavaProject(config: JavaProjectConfig): JavaFile[] {
  const { appName, packageName } = config;
  const pkgPath = packageName.replace(/\./g, '/');
  const files: JavaFile[] = [];

  // 1. Конфиг проекта ncs-project.toml
  files.push({
    path: 'ncs-project.toml',
    content: `name = "${appName}"
package = "${packageName}"
min_sdk = ${config.minSdk}
target_sdk = ${config.targetSdk}
compile_sdk = ${config.targetSdk}
version_code = ${config.versionCode}
version_name = "${config.versionName}"
main_activity = ".MainActivity"
language = "java"
ui = "xml"
`
  });

  // 2. AndroidManifest.xml
  files.push({
    path: 'app/src/main/AndroidManifest.xml',
    generateManifest(config)
  });

  // 3. MainActivity.java
  files.push({
    path: `app/src/main/java/${pkgPath}/MainActivity.java`,
    content: generateMainActivity(config)
  });

  // 4. Layout
  files.push({
    path: 'app/src/main/res/layout/activity_main.xml',
    content: generateDefaultLayout(appName)
  });

  // 5. Цвета
  files.push({
    path: 'app/src/main/res/values/colors.xml',
    content: generateColorsXml()
  });

  // 6. Строки
  files.push({
    path: 'app/src/main/res/values/strings.xml',
    content: generateStringsXml(appName)
  });

  // 7. Темы
  files.push({
    path: 'app/src/main/res/values/themes.xml',
    content: generateThemesXml()
  });

  return files;
}

export function generateManifest(config: JavaProjectConfig): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.App">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.App">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>

</manifest>
`;
}

export function generateMainActivity(config: JavaProjectConfig): string {
  return `package ${config.packageName};

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Главная активность приложения ${config.appName}.
 * Сгенерировано NCS Build.
 */
public class MainActivity extends Activity {

    private int counter = 0;
    private TextView counterText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        counterText = findViewById(R.id.counter_text);
        Button plusButton = findViewById(R.id.button_plus);
        Button resetButton = findViewById(R.id.button_reset);

        plusButton.setOnClickListener(v -> {
            counter++;
            updateCounter();
        });

        resetButton.setOnClickListener(v -> {
            counter = 0;
            updateCounter();
            Toast.makeText(this, "Сброшено", Toast.LENGTH_SHORT).show();
        });

        updateCounter();
    }

    private void updateCounter() {
        counterText.setText("Нажато: " + counter);
    }
}
`;
}

export function generateDefaultLayout(appName: string): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="24dp"
    android:background="@color/background">

    <TextView
        android:id="@+id/title_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="${appName}"
        android:textSize="28sp"
        android:textStyle="bold"
        android:textColor="@color/primary"
        android:layout_marginBottom="32dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Собрано через NCS Build"
        android:textSize="16sp"
        android:textColor="@color/on_surface"
        android:layout_marginBottom="8dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Java + XML Views без Gradle"
        android:textSize="14sp"
        android:textColor="@color/on_surface_variant"
        android:layout_marginBottom="24dp" />

    <TextView
        android:id="@+id/counter_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Нажато: 0"
        android:textSize="24sp"
        android:textStyle="bold"
        android:layout_marginBottom="24dp" />

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:layout_marginStart="12dp"
        android:layout_marginEnd="12dp">

        <Button
            android:id="@+id/button_plus"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="+1"
            android:textSize="16sp"
            android:minWidth="120dp" />

        <Button
            android:id="@+id/button_reset"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Сброс"
            android:textSize="16sp"
            android:minWidth="120dp"
            android:layout_marginStart="12dp" />

    </LinearLayout>

</LinearLayout>
`;
}

export function generateColorsXml(): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#6200EE</color>
    <color name="primary_variant">#3700B3</color>
    <color name="secondary">#03DAC6</color>
    <color name="background">#FFFFFF</color>
    <color name="surface">#FFFFFF</color>
    <color name="on_primary">#FFFFFF</color>
    <color name="on_surface">#1C1B1F</color>
    <color name="on_surface_variant">#49454F</color>
    <color name="error">#B3261E</color>
</resources>
`;
}

export function generateStringsXml(appName: string): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appName}</string>
</resources>
`;
}

export function generateThemesXml(): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.App" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">@color/primary</item>
        <item name="android:colorPrimaryDark">@color/primary_variant</item>
        <item name="android:colorAccent">@color/secondary</item>
        <item name="android:windowBackground">@color/background</item>
        <item name="android:statusBarColor">@color/primary_variant</item>
    </style>
</resources>
`;
}

/**
 * Генерация XML layout из внутреннего дерева компонентов
 */
export interface LayoutComponent {
  type: string;
  props: Record<string, any>;
  children?: LayoutComponent[];
}

export function generateLayoutXml(root: LayoutComponent, indent = 0): string {
  const pad = '    '.repeat(indent);
  const innerPad = '    '.repeat(indent + 1);

  const { type, props = {}, children = [] } = root;
  const selfClosing = children.length === 0 && !hasTextContent(props);

  const attrs = buildAttrsString(props);

  if (selfClosing) {
    return `${pad}<${type}${attrs ? ' ' + attrs : ''} />`;
  }

  let result = `${pad}<${type}${attrs ? ' ' + attrs : ''}>\n`;

  if (props.text) {
    result += `${innerPad}${escapeXml(props.text)}\n`;
  }

  for (const child of children) {
    result += generateLayoutXml(child, indent + 1) + '\n';
  }

  result += `${pad}</${type}>`;
  return result;
}

function hasTextContent(props: Record<string, any>): boolean {
  return !!props.text && !['Button', 'TextView', 'EditText'].includes(props.text);
}

function buildAttrsString(props: Record<string, any>): string {
  const attrs: string[] = [];
  const androidNs = 'android:';

  for (const [key, value] of Object.entries(props)) {
    if (key === 'children' || key === 'text' && !['Button', 'TextView', 'EditText'].includes(key)) continue;
    if (value === undefined || value === null || value === false) continue;

    let attrValue: string;
    const attrKey = getAndroidAttrName(key);

    switch (typeof value) {
      case 'boolean':
        attrValue = value ? 'true' : 'false';
        break;
      case 'number':
        if (key.endsWith('Sp') || key === 'textSize') {
          attrValue = `${value}sp`;
        } else if (key.endsWith('Dp') || /margin|padding|width|height|size|radius|elevation/i.test(key)) {
          attrValue = `${value}dp`;
        } else if (key === 'weight' || key === 'maxLines') {
          attrValue = String(value);
        } else {
          attrValue = `${value}dp`;
        }
        break;
      case 'string':
        attrValue = String(value);
        break;
      default:
        attrValue = String(value);
    }

    // Конвертация специальных значений
    attrValue = convertValue(attrValue, key);

    attrs.push(`${androidNs}${attrKey}="${escapeXml(attrValue)}"`);
  }

  return attrs.join('\n' + '    ');
}

function getAndroidAttrName(propKey: string): string {
  const mappings: Record<string, string> = {
    width: 'layout_width',
    height: 'layout_height',
    w: 'layout_width',
    h: 'layout_height',
    backgroundColor: 'background',
    textColor: 'textColor',
    textSize: 'textSize',
    fontSize: 'textSize',
    textStyle: 'textStyle',
    padding: 'padding',
    paddingHorizontal: 'paddingHorizontal',
    paddingVertical: 'paddingVertical',
    marginTop: 'layout_marginTop',
    marginBottom: 'layout_marginBottom',
    marginStart: 'layout_marginStart',
    marginEnd: 'layout_marginEnd',
    weight: 'layout_weight',
    gravity: 'gravity',
    layoutGravity: 'layout_gravity',
    orientation: 'orientation',
    hint: 'hint',
    src: 'src',
    id: 'id',
    checked: 'checked',
    maxLines: 'maxLines',
    singleLine: 'singleLine',
    elevation: 'elevation',
    borderRadius: 'radius',
  };

  return mappings[propKey] || propKey;
}

function convertValue(value: string, key: string): string {
  if (value === 'match' || value === 'match_parent' || value === 'fill') return 'match_parent';
  if (value === 'wrap' || value === 'wrap_content') return 'wrap_content';

  // Цвета
  if (/^#[0-9A-Fa-f]{6}$/.test(value) || /^#[0-9A-Fa-f]{8}$/.test(value)) {
    return value;
  }

  return value;
}

function escapeXml(str: string): string {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Генерация Java-кода для нахождения View и настройки обработчиков
 */
export function generateViewBindings(
  activityName: string,
  views: Array<{ id: string; type: string; hasOnClick?: boolean }>
): string {
  const fields = views.map(v => `    private ${v.type} ${toCamelCase(v.id)};`).join('\n');

  const bindings = views.map(v =>
    `        ${toCamelCase(v.id)} = findViewById(R.id.${v.id});`
  ).join('\n');

  const clickListeners = views.filter(v => v.hasOnClick).map(v =>
    `        ${toCamelCase(v.id)}.setOnClickListener(v -> {\n            // TODO: обработать нажатие\n        });`
  ).join('\n\n');

  return `public class ${activityName} extends Activity {

${fields}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

${bindings}
${clickListeners ? '\n' + clickListeners : ''}
    }
}
`;
}

function toCamelCase(str: string): string {
  return str.replace(/[-_]([a-z])/g, (_, char) => char.toUpperCase())
    .replace(/^([A-Z])/, (_, char) => char.toLowerCase());
}
