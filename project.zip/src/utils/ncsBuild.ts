/**
 * NCS Build API - быстрая сборка Java+XML без Gradle
 */
import * as apt from '../../modules/apt-manager/src/index';
import { execute, executeProot } from './shellExecutor';

let ncsSetupDone = false;

/**
 * Проверяет готовность окружения NCS Build
 */
export async function isNcsReady(): Promise<boolean> {
  try {
    const result = await execute('test -f ~/.ncs/bin/ncs && echo "yes" || echo "no"');
    return result.trim() === 'yes';
  } catch {
    return false;
  }
}

/**
 * Запускает быструю установку NCS Build
 */
export async function installNcsFast(onLog?: (line: string) => void): Promise<boolean> {
  const cmd = `
    set -e
    echo "=== Установка NCS Build (минимальное окружение) ==="
    
    # 1. Установка базовых пакетов без рекомендаций
    export DEBIAN_FRONTEND=noninteractive
    
    if ! command -v javac >/dev/null 2>&1; then
      echo "→ Устанавливаю JDK 17 (headless)..."
      apt-get update -qq
      apt-get install -y --no-install-recommends openjdk-17-jdk-headless unzip zip curl
    else
      echo "✓ JDK уже установлен"
    fi
    
    # 2. Создаём директории
    mkdir -p ~/.ncs/bin ~/.ncs/sdk ~/.ncs/cache ~/projects
    
    # 3. Установка Android SDK cmdline-tools
    SDK_ROOT=~/.ncs/sdk
    CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
    BUILD_TOOLS_VER="35.0.0"
    PLATFORM_VER="35"
    
    if [ ! -f "$SDK_ROOT/build-tools/$BUILD_TOOLS_VER/aapt2" ]; then
      echo "→ Скачиваю Android SDK command-line-tools..."
      mkdir -p "$SDK_ROOT/cmdline-tools"
      curl -fL --retry 3 -o /tmp/cmdline-tools.zip "$CMDLINE_TOOLS_URL"
      unzip -qo /tmp/cmdline-tools.zip -d "$SDK_ROOT/cmdline-tools/"
      mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
      rm -f /tmp/cmdline-tools.zip
      
      # Принимаем лицензии
      yes | "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_ROOT" --licenses >/dev/null 2>&1 || true
      
      echo "→ Устанавливаю build-tools и platform..."
      "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK_ROOT" \
        "build-tools;$BUILD_TOOLS_VER" \
        "platforms;android-$PLATFORM_VER" 2>&1
      
      echo "✓ Android SDK установлен"
    else
      echo "✓ Android SDK уже установлен"
    fi
    
    # 4. Копируем скрипт ncs-build
    echo "→ Устанавливаю ncs сборщик..."
    
    cat > ~/.ncs/bin/ncs << 'NCS_EOF'
#!/usr/bin/env bash
set -euo pipefail
export NCS_HOME="$HOME/.ncs"
export ANDROID_HOME="$NCS_HOME/sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which javac))))
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/build-tools/35.0.0:$ANDROID_HOME/platform-tools:$NCS_HOME/bin:$PATH"

CMD="${1:-help}"
PROJ_PATH="${2:-$(pwd)}"
VARIANT="${3:-debug}"

case "$CMD" in
  build|b)
    echo "=== NCS Build → $VARIANT APK ==="
    echo "Проект: $PROJ_PATH"
    
    cd "$PROJ_PATH"
    
    # Загружаем конфиг
    [ -f ncs-project.toml ] || { echo "Ошибка: нет ncs-project.toml"; exit 1; }
    
    PKG=$(grep '^package' ncs-project.toml | cut -d'"' -f2)
    APP_NAME=$(grep '^name' ncs-project.toml | cut -d'"' -f2)
    MIN_SDK=$(grep '^min_sdk' ncs-project.toml | grep -o '[0-9]*')
    TARGET_SDK=$(grep '^target_sdk' ncs-project.toml | grep -o '[0-9]*')
    
    BUILD_DIR="build"
    GEN_DIR="$BUILD_DIR/gen"
    OBJ_DIR="$BUILD_DIR/obj"
    OUT_DIR="$BUILD_DIR/outputs"
    RES_FLAT="$BUILD_DIR/res-flat"
    
    rm -rf "$BUILD_DIR"
    mkdir -p "$GEN_DIR" "$OBJ_DIR" "$OUT_DIR" "$RES_FLAT"
    
    # Компилируем ресурсы
    echo "→ Компиляция ресурсов..."
    if [ -d "app/src/main/res" ]; then
      find app/src/main/res -type f \( -name "*.xml" -o -name "*.png" -o -name "*.jpg" \) | while read f; do
        aapt2 compile -o "$RES_FLAT/" "$f" 2>/dev/null || true
      done
    fi
    
    # Линкуем ресурсы
    echo "→ Линковка ресурсов..."
    RES_APKS=$(find "$RES_FLAT" -name "*.flat" 2>/dev/null | tr '\n' ' ')
    
    aapt2 link \
      --proto-format \
      -o "$BUILD_DIR/res.apk" \
      -I "$ANDROID_HOME/platforms/android-$TARGET_SDK/android.jar" \
      --manifest app/src/main/AndroidManifest.xml \
      --java "$GEN_DIR" \
      --auto-add-overlay \
      $RES_APKS 2>&1 | grep -v "note:" || true
    
    # Генерируем BuildConfig
    PKG_PATH=$(echo "$PKG" | tr '.' '/')
    mkdir -p "$GEN_DIR/$PKG_PATH"
    cat > "$GEN_DIR/$PKG_PATH/BuildConfig.java" << JAVA_EOF
package $PKG;
public final class BuildConfig {
  public static final boolean DEBUG = $([ "$VARIANT" = "debug" ] && echo "true" || echo "false");
  public static final String APPLICATION_ID = "$PKG";
  public static final String BUILD_TYPE = "$VARIANT";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
}
JAVA_EOF
    
    # Компилируем Java
    echo "→ Компиляция Java..."
    JAVA_FILES=$(find app/src/main/java "$GEN_DIR" -name "*.java" 2>/dev/null)
    
    JARS=""
    if [ -d "app/libs" ]; then
      for j in app/libs/*.jar; do
        [ -f "$j" ] && JARS="$JARS:$j"
      done
    fi
    
    javac \
      -source 17 -target 17 \
      -encoding UTF-8 \
      -bootclasspath "$ANDROID_HOME/platforms/android-$TARGET_SDK/android.jar" \
      -classpath "$GEN_DIR:$JARS" \
      -d "$OBJ_DIR" \
      -proc:none -Xlint:none \
      $JAVA_FILES 2>&1
    
    # DEX
    echo "→ Конвертация в DEX..."
    D8_JAR=$(find "$ANDROID_HOME/build-tools" -name "d8.jar" | head -1)
    [ -z "$D8_JAR" ] && D8_JAR=$(find "$ANDROID_HOME/build-tools" -name "r8.jar" | head -1)
    
    java -cp "$D8_JAR" com.android.tools.r8.D8 \
      --min-api "$MIN_SDK" \
      --output "$BUILD_DIR" \
      --lib "$ANDROID_HOME/platforms/android-$TARGET_SDK/android.jar" \
      $(find "$OBJ_DIR" -name "*.class") 2>&1 | tail -5
    
    # Упаковка APK
    echo "→ Упаковка APK..."
    cp "$BUILD_DIR/res.apk" "$BUILD_DIR/unsigned.apk"
    cd "$BUILD_DIR"
    zip -j unsigned.apk classes.dex >/dev/null 2>&1 || true
    
    # Добавляем нативные либы если есть
    if [ -d "../app/src/main/jniLibs" ]; then
      cd ../app/src/main
      find jniLibs -type f -name "*.so" -exec zip -0 "../../../build/unsigned.apk" {} \; 2>/dev/null || true
      cd ../../../build
    fi
    
    # zipalign
    zipalign -f -p 4 unsigned.apk aligned.apk
    
    # Подпись debug ключом
    if [ ! -f "$NCS_HOME/debug.keystore" ]; then
      keytool -genkeypair -v \
        -keystore "$NCS_HOME/debug.keystore" \
        -storepass android -keypass android \
        -alias androiddebugkey \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
    fi
    
    apksigner sign \
      --ks "$NCS_HOME/debug.keystore" \
      --ks-pass pass:android \
      --key-pass pass:android \
      --ks-key-alias androiddebugkey \
      --v1-signing-enabled true --v2-signing-enabled true \
      --out "$OUT_DIR/$APP_NAME-$VARIANT.apk" \
      aligned.apk
    
    rm -f unsigned.apk aligned.apk
    cd ..
    
    SIZE=$(du -h "$OUT_DIR/$APP_NAME-$VARIANT.apk" | cut -f1)
    echo ""
    echo "=== Сборка завершена! ==="
    echo "APK: $OUT_DIR/$APP_NAME-$VARIANT.apk"
    echo "Размер: $SIZE"
    ;;
    
  new|create)
    APP_NAME="${PROJ_PATH:-MyApp}"
    PKG="${3:-com.example.$(echo "$APP_NAME" | tr '[:upper:]' '[:lower:]' | tr -cd '[:alnum:]')}"
    
    PROJ_DIR="$HOME/projects/$APP_NAME"
    echo "=== Создаю проект $APP_NAME ($PKG) ==="
    
    PKG_PATH=$(echo "$PKG" | tr '.' '/')
    
    mkdir -p "$PROJ_DIR/app/src/main/java/$PKG_PATH"
    mkdir -p "$PROJ_DIR/app/src/main/res/layout"
    mkdir -p "$PROJ_DIR/app/src/main/res/values"
    mkdir -p "$PROJ_DIR/app/src/main/res/drawable"
    mkdir -p "$PROJ_DIR/app/libs"
    mkdir -p "$PROJ_DIR/build"
    
    # Конфиг
    cat > "$PROJ_DIR/ncs-project.toml" << TOML_EOF
name = "$APP_NAME"
package = "$PKG"
min_sdk = 24
target_sdk = 35
compile_sdk = 35
version_code = 1
version_name = "1.0"
main_activity = ".MainActivity"
language = "java"
ui = "xml"
TOML_EOF
    
    # AndroidManifest
    cat > "$PROJ_DIR/app/src/main/AndroidManifest.xml" << XML_EOF
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.App">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.App">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
XML_EOF
    
    # MainActivity.java
    cat > "$PROJ_DIR/app/src/main/java/$PKG_PATH/MainActivity.java" << JAVA_EOF
package $PKG;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int counter = 0;
    private TextView counterText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        counterText = findViewById(R.id.counter_text);
        Button plusButton = findViewById(R.id.button_plus);
        Button resetButton = findViewById(R.id.button_reset);

        plusButton.setOnClickListener(v -> {
            counter++;
            updateCounter();
        });

        resetButton.setOnClickListener(v -> {
            counter = 0;
            updateCounter();
            Toast.makeText(this, "Сброшено", Toast.LENGTH_SHORT).show();
        });

        updateCounter();
    }

    private void updateCounter() {
        counterText.setText("Нажато: " + counter);
    }
}
JAVA_EOF
    
    # activity_main.xml
    cat > "$PROJ_DIR/app/src/main/res/layout/activity_main.xml" << LAYOUT_EOF
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="24dp"
    android:background="@color/background">

    <TextView
        android:id="@+id/title_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="$APP_NAME"
        android:textSize="28sp"
        android:textStyle="bold"
        android:textColor="@color/primary"
        android:layout_marginBottom="32dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Собрано через NCS Build"
        android:textSize="16sp"
        android:textColor="@color/on_surface"
        android:layout_marginBottom="8dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Java + XML Views без Gradle"
        android:textSize="14sp"
        android:textColor="@color/on_surface_variant"
        android:layout_marginBottom="24dp" />

    <TextView
        android:id="@+id/counter_text"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Нажато: 0"
        android:textSize="24sp"
        android:textStyle="bold"
        android:layout_marginBottom="24dp" />

    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:layout_marginStart="12dp"
        android:layout_marginEnd="12dp">

        <Button
            android:id="@+id/button_plus"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="+1"
            android:textSize="16sp"
            android:minWidth="120dp" />

        <Button
            android:id="@+id/button_reset"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Сброс"
            android:textSize="16sp"
            android:minWidth="120dp"
            android:layout_marginStart="12dp" />
    </LinearLayout>
</LinearLayout>
LAYOUT_EOF
    
    # colors.xml
    cat > "$PROJ_DIR/app/src/main/res/values/colors.xml" << COLORS_EOF
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#6200EE</color>
    <color name="primary_variant">#3700B3</color>
    <color name="secondary">#03DAC6</color>
    <color name="background">#FFFFFF</color>
    <color name="surface">#FFFFFF</color>
    <color name="on_primary">#FFFFFF</color>
    <color name="on_surface">#1C1B1F</color>
    <color name="on_surface_variant">#49454F</color>
    <color name="error">#B3261E</color>
</resources>
COLORS_EOF
    
    # strings.xml
    cat > "$PROJ_DIR/app/src/main/res/values/strings.xml" << STRINGS_EOF
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">$APP_NAME</string>
</resources>
STRINGS_EOF
    
    # themes.xml
    cat > "$PROJ_DIR/app/src/main/res/values/themes.xml" << THEMES_EOF
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.App" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">@color/primary</item>
        <item name="android:colorPrimaryDark">@color/primary_variant</item>
        <item name="android:colorAccent">@color/secondary</item>
        <item name="android:windowBackground">@color/background</item>
        <item name="android:statusBarColor">@color/primary_variant</item>
    </style>
</resources>
THEMES_EOF
    
    # .gitignore
    cat > "$PROJ_DIR/.gitignore" << GIT_EOF
build/
*.iml
.idea/
local.properties
*.apk
*.aab
*.keystore
*.jks
GIT_EOF
    
    echo ""
    echo "=== Проект создан! ==="
    echo "Путь: $PROJ_DIR"
    echo ""
    echo "Собрать: cd $PROJ_DIR && ncs build debug"
    echo "Установить: cd $PROJ_DIR && ncs install"
    ;;
    
  install|i)
    ncs build "$PROJ_PATH" "$VARIANT"
    APK=$(find "$PROJ_PATH/build/outputs" -name "*.apk" | head -1)
    echo "Устанавливаю $APK..."
    if command -v pm >/dev/null 2>&1; then
      pm install -r "$APK" && echo "✓ Установлено"
    else
      echo "APK: $APK"
    fi
    ;;
    
  run|r)
    ncs install "$PROJ_PATH"
    PKG=$(grep '^package' "$PROJ_PATH/ncs-project.toml" | cut -d'"' -f2)
    am start -n "$PKG/$PKG.MainActivity" 2>/dev/null || true
    ;;
    
  clean)
    rm -rf "$PROJ_PATH/build"
    echo "✓ Очищено"
    ;;
    
  doctor|status)
    echo "=== NCS Build Status ==="
    echo "JAVA_HOME: $JAVA_HOME"
    echo "ANDROID_HOME: $ANDROID_HOME"
    javac -version 2>&1
    aapt2 version 2>&1 | head -1
    [ -f "$ANDROID_HOME/platforms/android-$TARGET_SDK/android.jar" ] && echo "✓ android.jar найден" || echo "⚠ android.jar не найден"
    ;;
    
  help|*)
    echo "NCS Build — быстрая сборка Android Java+XML без Gradle"
    echo ""
    echo "Использование:"
    echo "  ncs new <Имя> [пакет]    Создать Java+XML проект"
    echo "  ncs build [debug|release] Собрать APK"
    echo "  ncs install               Собрать и установить"
    echo "  ncs run                   Собрать, установить и запустить"
    echo "  ncs clean                 Очистить артефакты"
    echo "  ncs doctor                Проверить окружение"
    ;;
esac
NCS_EOF
    chmod +x ~/.ncs/bin/ncs
    
    # Добавляем в PATH
    grep -q 'NCS_HOME' ~/.bashrc || cat >> ~/.bashrc << 'EOF'

# NCS Build
export NCS_HOME="$HOME/.ncs"
export ANDROID_HOME="$NCS_HOME/sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$NCS_HOME/bin:$JAVA_HOME/bin:$ANDROID_HOME/build-tools/35.0.0:$PATH"
export JAVA_TOOL_OPTIONS="-Djava.security.egd=file:/dev/./urandom"
EOF
    
    echo ""
    echo "=== ✅ NCS Build установлен! ==="
    echo "Команда ncs доступна в терминале"
    echo "Создать проект: ncs new MyApp ru.example.myapp"
  `;

  // Выполняем в proot
  try {
    // Используем PTY для отображения логов
    if (onLog) {
      const lines = cmd.split('\n');
      for (const line of lines) {
        onLog(line);
      }
    }
    await execute(cmd);
    ncsSetupDone = true;
    return true;
  } catch (e) {
    onLog?.(`Ошибка: ${e}`);
    return false;
  }
}

/**
 * Создаёт новый Java+XML проект
 */
export async function createJavaProject(name: string, packageName: string, onLog?: (line: string) => void): Promise<boolean> {
  const safeName = name.replace(/[^a-zA-Z0-9_-]/g, '');
  const safePkg = packageName || `com.example.${safeName.toLowerCase()}`;
  
  try {
    await execute(`source ~/.bashrc 2>/dev/null; ncs new "${safeName}" "${safePkg}"`);
    return true;
  } catch (e) {
    onLog?.(`Ошибка создания проекта: ${e}`);
    return false;
  }
}

/**
 * Быстрая сборка Java+XML проекта
 */
export async function buildProjectFast(projectPath: string, variant: 'debug' | 'release' = 'debug', onLog?: (line: string) => void): Promise<{success: boolean, apkPath?: string}> {
  try {
    const result = await execute(`source ~/.bashrc 2>/dev/null; cd "${projectPath}" && ncs build ${variant}`);
    if (onLog) onLog(result);
    
    // Ищем APK
    const apkMatch = result.match(/APK:\s*(.+build\/outputs\/[^\n]+)/);
    const apkPath = apkMatch ? apkMatch[1].trim() : null;
    
    return {
      success: result.includes('Сборка завершена') || (apkPath && require('fs').existsSync?.(apkPath)),
      apkPath,
    };
  } catch (e) {
    onLog?.(`Ошибка: ${e}`);
    return { success: false };
  }
}
