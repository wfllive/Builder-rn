export function distanceKm(a: [number, number], b: [number, number]) {
  const R = 6371;
  const dLat = (b[0] - a[0]) * Math.PI / 180;
  const dLon = (b[1] - a[1]) * Math.PI / 180;
  const lat1 = a[0] * Math.PI / 180;
  const lat2 = b[0] * Math.PI / 180;
  const x = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}

export function formatDistance(km: number) {
  if (km < 1) return `${Math.round(km*1000)} м`;
  return `${km.toFixed(1)} км`;
}

const DIRS = ['С','ССВ','СВ','ВСВ','В','ВЮВ','ЮВ','ЮЮВ','Ю','ЮЮЗ','ЮЗ','ЗЮЗ','З','ЗСЗ','СЗ','ССЗ'];
export function getDirection(from: [number, number], to: [number, number]) {
  const dLon = (to[1]-from[1]) * Math.PI/180;
  const y = Math.sin(dLon) * Math.cos(to[0]*Math.PI/180);
  const x = Math.cos(from[0]*Math.PI/180)*Math.sin(to[0]*Math.PI/180) -
            Math.sin(from[0]*Math.PI/180)*Math.cos(to[0]*Math.PI/180)*Math.cos(dLon);
  const brng = (Math.atan2(y, x) * 180/Math.PI + 360) % 360;
  return DIRS[Math.round(brng / 22.5) % 16];
}
