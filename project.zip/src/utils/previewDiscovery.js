/**
 * Kotlin Compose preview source discovery.
 *
 * This module deliberately operates on Kotlin declarations, not the visual
 * component model. It is the first stage of the code-preview pipeline: a
 * runner receives an exact composable FQN and @Preview configuration and never
 * invents a Scaffold, title, button text, or theme.
 */
const skipSpace = (text, index) => {
  let i = index;
  while (i < text.length && /\s/.test(text[i])) i += 1;
  return i;
};

const balanced = (text, start, open = '(', close = ')') => {
  let depth = 0;
  let quote = null;
  for (let i = start; i < text.length; i += 1) {
    const ch = text[i];
    const previous = text[i - 1];
    if (quote) {
      if (ch === quote && previous !== '\\') quote = null;
      continue;
    }
    if (ch === '"' || ch === '\'') { quote = ch; continue; }
    if (ch === open) depth += 1;
    if (ch === close && --depth === 0) return { value: text.slice(start + 1, i), end: i };
  }
  return null;
};

const argumentValue = (args, key) => {
  const found = args.match(new RegExp(`(?:^|,)\\s*${key}\\s*=\\s*("(?:[^"\\\\]|\\\\.)*"|[^,]+)`, 's'));
  return found ? found[1].trim().replace(/^"|"$/g, '') : null;
};

const numberValue = (args, key, fallback) => {
  const raw = argumentValue(args, key);
  const value = raw == null ? NaN : Number(raw.replace(/[fFL]$/, ''));
  return Number.isFinite(value) ? value : fallback;
};

const readAnnotations = (source, start) => {
  const annotations = [];
  let cursor = start;
  while (true) {
    cursor = skipSpace(source, cursor);
    if (source[cursor] !== '@') break;
    const match = source.slice(cursor).match(/^@([A-Za-z_][\w.]*)/);
    if (!match) break;
    const name = match[1].split('.').pop();
    cursor += match[0].length;
    cursor = skipSpace(source, cursor);
    let args = '';
    if (source[cursor] === '(') {
      const call = balanced(source, cursor);
      if (!call) break;
      args = call.value;
      cursor = call.end + 1;
    }
    annotations.push({ name, args });
  }
  return { annotations, end: cursor };
};

/** Returns source-defined @Preview entry points in declaration order. */
export const discoverComposePreviews = (source, fallbackPackage = '') => {
  const packageName = source.match(/^\s*package\s+([\w.]+)/m)?.[1] || fallbackPackage;
  const previews = [];
  let cursor = 0;
  while (cursor < source.length) {
    const at = source.indexOf('@', cursor);
    if (at < 0) break;
    const annotationBlock = readAnnotations(source, at);
    const previewAnnotations = annotationBlock.annotations.filter((item) => item.name === 'Preview');
    if (!previewAnnotations.length) { cursor = at + 1; continue; }
    const declaration = source.slice(annotationBlock.end).match(/^\s*(?:public\s+|private\s+|internal\s+)?(?:inline\s+)?fun\s+([A-Za-z_]\w*)\s*\(([^)]*)\)/);
    if (!declaration) { cursor = annotationBlock.end + 1; continue; }
    const functionName = declaration[1];
    const parameters = declaration[2].trim();
    // Every @Preview annotation produces a separate render configuration.
    previewAnnotations.forEach((annotation, index) => {
      const args = annotation.args;
      previews.push({
        id: `${packageName}.${functionName}:${at}:${index}`,
        packageName,
        functionName,
        fqn: packageName ? `${packageName}.${functionName}` : functionName,
        displayName: argumentValue(args, 'name') || functionName,
        group: argumentValue(args, 'group') || '',
        widthDp: numberValue(args, 'widthDp', -1),
        heightDp: numberValue(args, 'heightDp', -1),
        fontScale: numberValue(args, 'fontScale', 1),
        locale: argumentValue(args, 'locale') || '',
        device: argumentValue(args, 'device') || '',
        uiMode: argumentValue(args, 'uiMode') || '',
        showSystemUi: argumentValue(args, 'showSystemUi') === 'true',
        showBackground: argumentValue(args, 'showBackground') === 'true',
        parameterized: parameters.length > 0,
      });
    });
    cursor = annotationBlock.end + declaration[0].length;
  }
  return previews;
};

export const selectDefaultPreview = (previews) => previews.find((item) => !item.parameterized) || previews[0] || null;
