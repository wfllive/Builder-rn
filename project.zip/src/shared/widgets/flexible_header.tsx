/**
 * FlexibleHeader — десктопный верхний хедер.
 * На телефоне Layout его скрывает; на планшете / web-Expo остаётся.
 */
import React from "react";
import { Text, View } from "react-native";
import TButton from "@/shared/ui/buttons/tbutton";
import { useAppNavigation } from "@/adapters/navigation";
import { cn } from "@/adapters/cn";

export interface FlexibleHeaderProps {
  selected?: string;
  noFillOnSelectIds?: string[];
  className?: string;
}

export default function FlexibleHeader({ className }: FlexibleHeaderProps) {
  const nav = useAppNavigation();

  return (
    <View className={cn("flex-row items-center justify-between px-4 py-3", className)}>
      <Text className="text-xl font-extrabold italic text-primary">twitblit</Text>
      <View className="flex-row gap-2">
        <TButton.Text onPress={() => nav.push("/search")}>Поиск</TButton.Text>
        <TButton.Solid onPress={() => nav.push("/create")}>Написать</TButton.Solid>
      </View>
    </View>
  );
}
