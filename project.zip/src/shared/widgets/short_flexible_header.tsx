/**
 * Компактная шапка внутренних экранов: назад + заголовок.
 * safeTop — стекло под статус-бар, когда Layout рисует шапку поверх.
 */
import React from "react";
import { Text, View } from "react-native";
import TButton from "@/shared/ui/buttons/tbutton";
import GlassBar from "@/shared/ui/layout/glass_bar";
import { Left } from "@/shared/ui/icons/mingcute/arrow/left_line";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { cn } from "@/adapters/cn";

export default function ShortFlexibleHeader({
  title,
  className,
}: {
  title: string;
  className?: string;
}) {
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");

  return (
    <GlassBar edge="bottom" dock="top" safeTop className={cn(className)}>
      <View className="flex-row items-center px-2 py-2">
        <TButton.Text onPress={nav.back} centerImage={<Left size={22} color={ink} />} />
        <Text className="ml-2 text-lg font-semibold" style={{ color: ink }}>
          {title}
        </Text>
      </View>
    </GlassBar>
  );
}
