/**
 * FlexibleHeaderMobile — нижний таббар.
 *
 * Вкладки переключаются через replace (не push):
 * иначе Expo Router копит стек и «Назад» прыгает между табами.
 * Иконка: обычная / selected (цвет primary + filled).
 */
import React from "react";
import { Pressable, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Home4 } from "@/shared/ui/icons/mingcute/building/home_4_line";
import { Search } from "@/shared/ui/icons/mingcute/file/search_line";
import { Add } from "@/shared/ui/icons/mingcute/system/add_line";
import { Heart } from "@/shared/ui/icons/mingcute/shape/heart_line";
import { Comment2 } from "@/shared/ui/icons/mingcute/contact/comment_2_line";
import { useHolidayDecor } from "@/shared/ui/decorations/utils/useHolidayDecor";
import { Gift2 } from "@/shared/ui/icons/mingcute/business/gift_2_line";
import { Glove } from "@/shared/ui/icons/mingcute/part/glove_line";
import { Snowman } from "@/shared/ui/icons/mingcute/weather/snowman_line";
import { Magic2 } from "@/shared/ui/icons/mingcute/design/magic_2_line";
import { ChristmasHat } from "@/shared/ui/icons/mingcute/part/christmas_hat_line";
import { useNotifications } from "@/adapters/notifications";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { cn } from "@/adapters/cn";
import GlassBar from "@/shared/ui/layout/glass_bar";

export type HeaderButton = {
  id?: string;
  href?: string;
  onClick?: () => void;
  icon: (opts: { color: string; filled: boolean }) => React.ReactNode;
  indicatorNotification?: boolean;
  countNotification?: number;
  /** Центральная кнопка «+» — кружок primary */
  emphasized?: boolean;
};

export interface FlexibleHeaderMobileProps {
  centerButtons?: HeaderButton[];
  className?: string;
  selected?: string;
  noFillOnSelectIds?: string[];
}

export default function FlexibleHeaderMobile({
  centerButtons,
  className = "",
  selected = "",
  noFillOnSelectIds = [],
}: FlexibleHeaderMobileProps) {
  const insets = useSafeAreaInsets();
  const nav = useAppNavigation();
  const { unreadCount } = useNotifications();
  const { isDark } = useAppTheme();
  const iconColor = resolveToken(isDark, "textMuted");
  const primary = resolveToken(isDark, "primary");

  const activeHolidays = useHolidayDecor();
  const showNewYear = activeHolidays.includes("newYear");

  const defaultCenterButtons: HeaderButton[] = [
    {
      id: "home",
      href: "/",
      icon: ({ color, filled }) =>
        showNewYear ? <Glove size={24} color={color} filled={filled} /> : <Home4 size={24} color={color} filled={filled} />,
    },
    {
      id: "search",
      href: "/search",
      icon: ({ color, filled }) =>
        showNewYear ? <Snowman size={24} color={color} filled={filled} /> : <Search size={24} color={color} filled={filled} />,
    },
    {
      id: "create",
      href: "/create",
      emphasized: true,
      icon: ({ color }) =>
        showNewYear ? <Magic2 size={22} color={color} /> : <Add size={22} color={color} />,
    },
    {
      id: "notifications",
      href: "/notifications",
      indicatorNotification: unreadCount > 0,
      countNotification: unreadCount,
      icon: ({ color, filled }) =>
        showNewYear ? <Gift2 size={24} color={color} filled={filled} /> : <Heart size={24} color={color} filled={filled} />,
    },
    {
      id: "messages",
      href: "/messenger",
      icon: ({ color, filled }) =>
        showNewYear ? (
          <ChristmasHat size={24} color={color} filled={filled} />
        ) : (
          <Comment2 size={24} color={color} filled={filled} />
        ),
    },
  ];

  const buttonsToRender = centerButtons ?? defaultCenterButtons;

  const go = (btn: HeaderButton) => {
    if (btn.onClick) {
      btn.onClick();
      return;
    }
    if (!btn.href) return;
    if (btn.href === nav.pathname) return;
    nav.replace(btn.href);
  };

  return (
    <GlassBar edge="top" dock="bottom" className={cn(className)}>
    <View
      style={{
        paddingBottom: Math.max(insets.bottom, 6),
      }}
    >
      <View className="flex-row items-end justify-around px-3 pt-1.5">
        {buttonsToRender.map((btn) => {
          const isSelected = btn.id === selected;
          const disableFill = btn.id ? noFillOnSelectIds.includes(btn.id) : false;
          const color = isSelected || btn.emphasized ? primary : iconColor;
          const filled = isSelected && !disableFill;

          return (
            <Pressable
              key={btn.id}
              onPress={() => go(btn)}
              accessibilityRole="tab"
              accessibilityState={{ selected: isSelected }}
              accessibilityLabel={btn.id}
              className="items-center justify-center"
              style={{ minWidth: 52, height: 44 }}
            >
              <View
                className={cn(
                  "items-center justify-center",
                  btn.emphasized && "w-11 h-11 rounded-2xl bg-primary/15"
                )}
              >
                {btn.icon({ color, filled })}
                {btn.indicatorNotification ? (
                  <View className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-danger" />
                ) : null}
              </View>
              {isSelected && !btn.emphasized ? (
                <View className="mt-1 w-1 h-1 rounded-full bg-primary" />
              ) : (
                <View className="mt-1 w-1 h-1" />
              )}
            </Pressable>
          );
        })}
      </View>
    </View>
    </GlassBar>
  );
}
