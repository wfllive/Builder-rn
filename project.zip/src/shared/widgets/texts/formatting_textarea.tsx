/**
 * FormattingTextarea — textarea с счётчиком графем (редактор треда).
 */
import React from "react";
import FlyTextarea from "@/shared/ui/data_entry/flytextarea";

export default function FormattingTextarea({
  value,
  onChange,
  maxLength = 1000,
}: {
  value?: string;
  onChange?: (v: string) => void;
  maxLength?: number;
}) {
  return (
    <FlyTextarea
      value={value}
      onChange={onChange}
      maxLength={maxLength}
      showCount
      placeholder="Что нового?"
    />
  );
}
