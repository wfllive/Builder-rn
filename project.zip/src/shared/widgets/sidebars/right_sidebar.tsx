/**
 * RightSidebar — правая колонка (тренды / рекомендации).
 * На телефоне скрыта Layout'ом.
 */
import React from "react";
import { Text, View } from "react-native";
import { cn } from "@/adapters/cn";

export default function RightSidebar({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <View className={cn("p-4", className)}>
      {children ?? (
        <Text className="text-sm text-muted">Рекомендации появятся здесь</Text>
      )}
    </View>
  );
}
