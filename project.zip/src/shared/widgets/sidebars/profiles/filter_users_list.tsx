/**
 * FilterUsersList — список профилей в левом меню.
 * На вебе ходил в API. Здесь items снаружи, тап открывает профиль.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export interface FilterUser {
  id: number;
  username: string;
  user_id?: string;
  avatar?: string | null;
}

export default function FilterUsersList({
  title,
  items = [],
  onPressUser,
}: {
  filterType?: string;
  title: string;
  limit?: number;
  openDefault?: boolean;
  items?: FilterUser[];
  onPressUser?: (user: FilterUser) => void;
}) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");

  return (
    <View className="mb-4">
      <Text className="mb-2 font-semibold" style={{ color: ink }}>
        {title}
      </Text>
      {items.map((u) => (
        <Pressable
          key={u.id}
          onPress={() => onPressUser?.(u)}
          className="flex-row items-center gap-2 py-2"
        >
          <FlyAvatar src={u.avatar ?? undefined} alt={u.username} size="xs" />
          <View className="flex-1">
            <Text className="text-sm" style={{ color: ink }}>
              {u.username}
            </Text>
            {u.user_id ? <Text className="text-xs text-muted">@{u.user_id}</Text> : null}
          </View>
        </Pressable>
      ))}
    </View>
  );
}
