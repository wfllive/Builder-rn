/**
 * LeftSidebar — содержимое левого меню.
 * На вебе это колонка. На телефоне открывается шторкой: списки + пункты.
 */
import React from "react";
import { ScrollView, Text, View } from "react-native";
import TButton from "@/shared/ui/buttons/tbutton";
import FilterUsersList from "./profiles/filter_users_list";
import { Palette } from "@/shared/ui/icons/mingcute/design/palette_line";
import { Question } from "@/shared/ui/icons/mingcute/system/question_line";
import { Settings3 } from "@/shared/ui/icons/mingcute/system/settings_3_line";
import { User3 } from "@/shared/ui/icons/mingcute/user/user_3_line";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { cn } from "@/adapters/cn";
import { MOCK_USERS } from "@/example/mock_threads";
import { useDemoSession } from "@/example/demo_session";

export interface LeftSidebarProps {
  children?: React.ReactNode;
  className?: string;
  onNavigate?: () => void;
}

const LeftSidebar: React.FC<LeftSidebarProps> = ({ children, className = "", onNavigate }) => {
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const demo = useDemoSession();
  const icon = resolveToken(isDark, "text");
  const ink = resolveToken(isDark, "text");

  const go = (href: string) => {
    onNavigate?.();
    nav.push(href);
  };

  const people = Object.values(MOCK_USERS).filter((u) => u.user_id !== "you");
  const official = people.filter((u) => u.verify).slice(0, 5);
  const fresh = people.slice(0, 5);

  return (
    <ScrollView className={cn("flex-1", className)} contentContainerStyle={{ paddingHorizontal: 16 }}>
      {children ?? (
        <>
          <Text className="text-xl font-extrabold italic text-primary mb-4">twitblit</Text>

          <FilterUsersList
            title="Официальные бабочки"
            items={official.map((u) => ({
              id: u.id,
              username: u.username,
              user_id: u.user_id,
              avatar: u.avatar,
            }))}
            onPressUser={(u) => u.user_id && go(`/tb/${u.user_id}`)}
          />

          <FilterUsersList
            title="Новые бабочки"
            items={fresh.map((u) => ({
              id: u.id,
              username: u.username,
              user_id: u.user_id,
              avatar: u.avatar,
            }))}
            onPressUser={(u) => u.user_id && go(`/tb/${u.user_id}`)}
          />

          <View className="h-px bg-primary/10 my-2" />

          <TButton.Text
            leftIcon={<Palette size={18} color={icon} />}
            contentAlign="justify-start"
            className="w-full"
            onPress={() => go("/settings")}
          >
            Настроить красоту
          </TButton.Text>
          <TButton.Text
            leftIcon={<Settings3 size={18} color={icon} />}
            contentAlign="justify-start"
            className="w-full"
            onPress={() => go("/settings")}
          >
            Настройки
          </TButton.Text>
          <TButton.Text
            onPress={() => go("/about")}
            leftIcon={<Question size={18} color={icon} />}
            contentAlign="justify-start"
            className="w-full"
          >
            О нас
          </TButton.Text>
          <TButton.Text
            onPress={() => go(demo.isAuth && demo.user ? `/tb/${demo.user.user_id}` : "/auth/login")}
            leftIcon={<User3 size={18} color={icon} />}
            contentAlign="justify-start"
            className="w-full"
          >
            {demo.isAuth ? "Мой профиль" : "Войти"}
          </TButton.Text>

          <Text className="text-xs text-muted mt-6" style={{ color: resolveToken(isDark, "textMuted") }}>
            Списки демо. На вебе это живые рекомендации.
          </Text>
          <Text className="text-[11px] mt-1" style={{ color: ink, opacity: 0.35 }}>
            twb://core.shell?v=1.26
          </Text>
        </>
      )}
    </ScrollView>
  );
};

export default LeftSidebar;
