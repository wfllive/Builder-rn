/**
 * DailyThreadInfoModal — справка по номинации «Тред дня».
 */
import React from "react";
import FlyBottomSheetModal from "@/shared/ui/feedback/flybottom_sheet_modal";

export default function DailyThreadInfoModal({
  open,
  onCancel,
  isLoading,
}: {
  open: boolean;
  onChange?: (v: boolean) => void;
  onCancel?: () => void;
  onSubmit?: () => void;
  isLoading?: boolean;
}) {
  return (
    <FlyBottomSheetModal
      open={open}
      onCancel={onCancel}
      isLoading={isLoading}
      title="Номинация #ТредДня"
      message="Каждый день сообщество выбирает лучший тред. Попасть сюда можно только живыми откликами, не накрутками."
    />
  );
}
