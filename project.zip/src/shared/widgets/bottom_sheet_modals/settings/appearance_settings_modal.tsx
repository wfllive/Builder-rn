/**
 * Шторка «Внешний вид».
 * Тема — три плитки ThemeChoiceRow (все варианты на экране).
 */
import React from "react";
import { Text, View } from "react-native";
import FlyBottomSheetModal from "@/shared/ui/feedback/flybottom_sheet_modal";
import TSwitch from "@/shared/ui/data_entry/tswitch";
import TButton from "@/shared/ui/buttons/tbutton";
import ThemeChoiceRow from "@/shared/ui/buttons/theme_choice_row";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { useUISettings } from "@/shared/templates/providers/ui_settings_provider";
import { resolveToken } from "@/theme/tokens";

export default function AppearanceSettingsModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { theme, resolvedTheme, isDark } = useAppTheme();
  const { animations, setAnimationsDisabled } = useUISettings();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");

  const now =
    theme === "system"
      ? `система → сейчас ${resolvedTheme === "dark" ? "тёмная" : "светлая"}`
      : theme === "dark"
        ? "тёмная"
        : "светлая";

  return (
    <FlyBottomSheetModal
      open={open}
      onCancel={onClose}
      title="Внешний вид"
      actions={
        <TButton.Filled className="w-full" onPress={onClose}>
          Готово
        </TButton.Filled>
      }
    >
      <View className="mt-4 gap-4">
        <Text className="text-sm font-medium" style={{ color: ink }}>
          Тема приложения
        </Text>
        <ThemeChoiceRow />
        <Text className="text-xs" style={{ color: muted }}>
          Сейчас: {now}
        </Text>

        <View className="flex-row items-center justify-between mt-2">
          <View className="flex-1 pr-3">
            <Text style={{ color: ink }}>Убрать анимации фона</Text>
            <Text className="text-xs mt-0.5" style={{ color: muted }}>
              Уменьшает нагрузку и делает интерфейс быстрее
            </Text>
          </View>
          <TSwitch checked={animations.disabled} onChange={setAnimationsDisabled} />
        </View>
      </View>
    </FlyBottomSheetModal>
  );
}
