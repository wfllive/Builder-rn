/**
 * AuthRequiredModal — «войди, чтобы продолжить».
 */
import React from "react";
import FlyBottomSheetModal from "@/shared/ui/feedback/flybottom_sheet_modal";
import TButton from "@/shared/ui/buttons/tbutton";
import { useAppNavigation } from "@/adapters/navigation";
import { View } from "react-native";

export default function AuthRequiredModal({
  open,
  onClose,
  title = "Нужна авторизация",
  message = "Войди, чтобы пользоваться этой функцией",
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  message?: string;
}) {
  const nav = useAppNavigation();

  return (
    <FlyBottomSheetModal
      open={open}
      onCancel={onClose}
      title={title}
      message={message}
      actions={
        <View className="flex-row gap-3 w-full">
          <View className="flex-1">
            <TButton.Outline onPress={onClose}>Позже</TButton.Outline>
          </View>
          <View className="flex-1">
            <TButton.Solid
              onPress={() => {
                onClose();
                nav.push("/auth/login");
              }}
            >
              Войти
            </TButton.Solid>
          </View>
        </View>
      }
    />
  );
}
