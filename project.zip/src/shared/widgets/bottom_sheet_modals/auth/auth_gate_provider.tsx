/**
 * AuthGateProvider — слот для глобальной модалки авторизации.
 * На вебе держал состояние «открыть шторку».
 * В native реальную сессию подключает оболочка через setAuthAdapter.
 */
import React from "react";

export default function AuthGateProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
