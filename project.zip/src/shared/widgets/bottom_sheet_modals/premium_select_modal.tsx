/**
 * PremiumSelectModal — выбор тарифа.
 */
import React from "react";
import { View } from "react-native";
import FlyBottomSheetModal from "@/shared/ui/feedback/flybottom_sheet_modal";
import FlyPremiumTariff from "@/shared/ui/data_display/flypremium_tariff";

export default function PremiumSelectModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  return (
    <FlyBottomSheetModal open={open} onCancel={onClose} title="Twitblit Universe" actions={null}>
      <View className="mt-4 gap-3">
        <FlyPremiumTariff title="Lite" price="0 ₽" features={["Лента", "Треды"]} onSelect={onClose} />
        <FlyPremiumTariff
          title="Universe"
          price="299 ₽"
          features={["Без рекламы", "Темы", "Значок"]}
          onSelect={onClose}
        />
      </View>
    </FlyBottomSheetModal>
  );
}
