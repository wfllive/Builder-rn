/**
 * NotificationsSnackbar — обёртка FlySnackbar под пуш/in-app уведомления.
 */
import React from "react";
import FlySnackbar, { type FlySnackbarProps } from "@/shared/ui/feedback/flysnackbar";

export default function NotificationsSnackbar(props: FlySnackbarProps) {
  return <FlySnackbar {...props} position="topCenter" />;
}
