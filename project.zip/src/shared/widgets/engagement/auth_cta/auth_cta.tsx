/**
 * AuthCta — призыв войти / зарегистрироваться в ленте.
 */
import React from "react";
import { Text, View } from "react-native";
import TButton from "@/shared/ui/buttons/tbutton";
import { useAppNavigation } from "@/adapters/navigation";

export default function AuthCta() {
  const nav = useAppNavigation();

  return (
    <View className="p-4 rounded-2xl bg-primary/8">
      <Text className="text-base font-semibold text-ink">
        Присоединяйся к Twitblit
      </Text>
      <Text className="mt-1 text-sm text-muted">
        Публикуй треды и общайся с авторами
      </Text>
      <View className="mt-3">
        <TButton.Solid onPress={() => nav.push("/auth/create-account")}>Создать аккаунт</TButton.Solid>
      </View>
    </View>
  );
}
