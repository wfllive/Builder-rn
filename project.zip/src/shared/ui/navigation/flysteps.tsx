/**
 * FlySteps — шаги регистрации / онбординга.
 * Поддерживает и простой total, и items с иконкой как на вебе.
 */
import React from "react";
import { Text, View } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export type FlyStepItem = {
  title: string;
  description?: string;
  icon?: React.ReactNode;
};

export interface FlyStepsProps {
  current: number;
  total?: number;
  labels?: string[];
  items?: FlyStepItem[];
  className?: string;
}

export default function FlySteps({ current, total, labels, items, className }: FlyStepsProps) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const count = items?.length ?? total ?? labels?.length ?? 0;

  return (
    <View className={cn("w-full", className)}>
      <View className="flex-row items-start">
        {Array.from({ length: count }).map((_, i) => {
          const active = i <= current;
          const item = items?.[i];
          return (
            <View key={i} className="flex-1 items-center px-1">
              <View
                className={cn(
                  "w-8 h-8 rounded-full items-center justify-center mb-1",
                  active ? "bg-primary/20" : "bg-primary/10"
                )}
              >
                {item?.icon ?? (
                  <View className={cn("w-2 h-2 rounded-full", active ? "bg-primary" : "bg-primary/30")} />
                )}
              </View>
              <Text
                className="text-[10px] text-center"
                style={{ color: active ? ink : muted }}
                numberOfLines={2}
              >
                {item?.title ?? labels?.[i] ?? ""}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}
