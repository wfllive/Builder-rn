/**
 * FlyDropdown
 * ---------------------------------------------------------------
 * На вебе — абсолютный popover.
 * На native — bottom sheet со списком пунктов (удобнее пальцем).
 * Цвет текста всегда из темы — без системного белого на белой шторке.
 */
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import FlyBottomSheetModal from "../feedback/flybottom_sheet_modal";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export interface DropdownItem {
  label: string;
  prefix?: React.ReactNode;
  type?: "default" | "warning" | "danger";
  onClick?: () => void;
}

export interface FlyDropdownProps {
  items: DropdownItem[];
  trigger: React.ReactNode;
  placement?: string;
  className?: string;
}

export default function FlyDropdown({ items, trigger, className }: FlyDropdownProps) {
  const [open, setOpen] = useState(false);
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");

  return (
    <View className={cn(className)}>
      <Pressable onPress={() => setOpen(true)} hitSlop={10}>
        <View pointerEvents="none">{trigger}</View>
      </Pressable>
      <FlyBottomSheetModal open={open} onCancel={() => setOpen(false)} actions={null}>
        <View className="gap-1 mt-2">
          {items.map((item) => (
            <Pressable
              key={item.label}
              className="flex-row items-center px-2 py-3 rounded-xl"
              onPress={() => {
                item.onClick?.();
                setOpen(false);
              }}
            >
              {item.prefix ? <View className="mr-3">{item.prefix}</View> : null}
              <Text
                className="text-base"
                style={{
                  color:
                    item.type === "warning"
                      ? resolveToken(isDark, "warning")
                      : item.type === "danger"
                        ? resolveToken(isDark, "red")
                        : ink,
                }}
              >
                {item.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </FlyBottomSheetModal>
    </View>
  );
}
