/**
 * FlyTabs
 * ---------------------------------------------------------------
 * Порт web `shared/ui/navigation/flytabs.tsx`.
 *
 * Отличия native:
 * - ResizeObserver / scrollIntoView → ScrollView + onLayout
 * - индикатор активной вкладки — View с динамической шириной/left
 */
import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export type FlyTabsActiveType = "primary" | "danger" | "warning" | "info";
export type FlyTabsAlign = "start" | "center" | "end" | "between" | "stretch";
export type FlyTabsSize = "xs" | "sm" | "lg" | "xl";

export interface FlyTabsExtraContent {
  left?: React.ReactNode;
  right?: React.ReactNode;
}

export interface FlyTabOption<T extends string = string> {
  key: T;
  label: React.ReactNode;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  centerIcon?: React.ReactNode;
  typeActive?: FlyTabsActiveType;
  disabled?: boolean;
  className?: string;
}

export interface FlyTabsProps<T extends string = string> {
  activeKey: T;
  options: FlyTabOption<T>[];
  extraContent?: FlyTabsExtraContent;
  onChange?: (key: T, option: FlyTabOption<T>) => void;
  size?: FlyTabsSize;
  tabsAlign?: FlyTabsAlign;
  className?: string;
}

const ACTIVE_TYPE_COLORS: Record<FlyTabsActiveType, "primary" | "error" | "warning" | "success"> = {
  primary: "primary",
  danger: "error",
  warning: "warning",
  info: "success",
};

const SIZE_MAP: Record<FlyTabsSize, { tab: string; text: string; indicator: number }> = {
  xs: { tab: "px-3 py-2", text: "text-xs", indicator: 2 },
  sm: { tab: "px-4 py-2.5", text: "text-sm", indicator: 2 },
  lg: { tab: "px-5 py-3", text: "text-base", indicator: 3 },
  xl: { tab: "px-6 py-3.5", text: "text-lg", indicator: 3 },
};

export default function FlyTabs<T extends string = string>({
  activeKey,
  options,
  extraContent,
  onChange,
  size = "sm",
  className,
}: FlyTabsProps<T>) {
  const { isDark } = useAppTheme();
  const sizeCfg = SIZE_MAP[size];
  const activeOption = useMemo(
    () => options.find((o) => o.key === activeKey),
    [activeKey, options]
  );
  const activeColor = resolveToken(isDark, ACTIVE_TYPE_COLORS[activeOption?.typeActive ?? "primary"]);
  const idleColor = resolveToken(isDark, "textMuted");
  const [layouts, setLayouts] = useState<Record<string, { x: number; w: number }>>({});

  const indicator = layouts[String(activeKey)];

  return (
    <View className={cn("flex-row w-full items-center gap-2", className)}>
      {extraContent?.left ? <View>{extraContent.left}</View> : null}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        className="flex-1"
        contentContainerClassName="flex-row"
      >
        <View className="relative flex-row">
          {options.map((option) => {
            const isActive = option.key === activeKey;
            const color = isActive
              ? resolveToken(isDark, ACTIVE_TYPE_COLORS[option.typeActive ?? "primary"])
              : idleColor;

            return (
              <Pressable
                key={option.key}
                disabled={option.disabled}
                onPress={() => {
                  if (option.disabled) return;
                  onChange?.(option.key, option);
                }}
                onLayout={(e) => {
                  const { x, width } = e.nativeEvent.layout;
                  setLayouts((prev) => ({ ...prev, [String(option.key)]: { x, w: width } }));
                }}
                className={cn(
                  "flex-row items-center justify-center",
                  sizeCfg.tab,
                  option.disabled && "opacity-50",
                  option.className
                )}
              >
                {option.leftIcon ? <View className="mr-1.5">{option.leftIcon}</View> : null}
                {typeof option.label === "string" ? (
                  <Text
                    className={cn(sizeCfg.text, "font-medium")}
                    style={{ color, opacity: isActive ? 1 : 0.75 }}
                  >
                    {option.label}
                  </Text>
                ) : (
                  option.label
                )}
                {option.rightIcon ? <View className="ml-1.5">{option.rightIcon}</View> : null}
              </Pressable>
            );
          })}

          {indicator ? (
            <View
              className="absolute bottom-0 rounded-full"
              style={{
                left: indicator.x,
                width: indicator.w,
                height: sizeCfg.indicator,
                backgroundColor: activeColor,
              }}
            />
          ) : null}
        </View>
      </ScrollView>

      {extraContent?.right ? <View>{extraContent.right}</View> : null}
    </View>
  );
}
