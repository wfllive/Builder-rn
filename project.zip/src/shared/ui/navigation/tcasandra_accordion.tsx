/**
 * TCasandraAccordion — аккордеон секций.
 */
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { cn } from "@/adapters/cn";

export interface AccordionItem {
  key: string;
  title: string;
  content: React.ReactNode;
}

export interface TCasandraAccordionProps {
  items: AccordionItem[];
  defaultOpenKey?: string;
  className?: string;
}

export default function TCasandraAccordion({
  items,
  defaultOpenKey,
  className,
}: TCasandraAccordionProps) {
  const [open, setOpen] = useState(defaultOpenKey ?? items[0]?.key);

  return (
    <View className={cn("gap-2", className)}>
      {items.map((item) => {
        const isOpen = open === item.key;
        return (
          <View key={item.key} className="rounded-xl bg-primary/5 overflow-hidden">
            <Pressable className="px-4 py-3" onPress={() => setOpen(isOpen ? "" : item.key)}>
              <Text className="font-semibold text-ink">{item.title}</Text>
            </Pressable>
            {isOpen ? <View className="px-4 pb-3">{item.content}</View> : null}
          </View>
        );
      })}
    </View>
  );
}
