/**
 * TColorPicker — выбор из палитры бренда (упрощённый native-порт).
 * Полноценный color-wheel на web остаётся web-only.
 */
import React from "react";
import { Pressable, View } from "react-native";
import { lightTokens } from "@/theme/tokens";
import { cn } from "@/adapters/cn";

const PALETTE = [
  lightTokens.primary,
  lightTokens.secondary,
  lightTokens.seaBreeze,
  lightTokens.orange,
  lightTokens.red,
  lightTokens.blue,
  lightTokens.success,
];

export interface TColorPickerProps {
  value?: string;
  onChange?: (color: string) => void;
  className?: string;
}

export default function TColorPicker({ value, onChange, className }: TColorPickerProps) {
  return (
    <View className={cn("flex-row flex-wrap gap-2", className)}>
      {PALETTE.map((color) => (
        <Pressable
          key={color}
          onPress={() => onChange?.(color)}
          className="w-8 h-8 rounded-full"
          style={{
            backgroundColor: color,
            borderWidth: value === color ? 3 : 0,
            borderColor: lightTokens.text,
          }}
        />
      ))}
    </View>
  );
}
