/**
 * FlyInput
 * ---------------------------------------------------------------
 * Порт web `shared/ui/data_entry/flyinput.tsx`.
 *
 * Отличия native:
 * - <input>/<textarea> → TextInput (multiline для textarea)
 * - prefix/suffix/clear — поверх TextInput через абсолютное позиционирование
 * - onPressEnter → onSubmitEditing
 */
import React, {
  forwardRef,
  useCallback,
  useMemo,
  useState,
} from "react";
import {
  Pressable,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type TextStyle,
} from "react-native";
import { Close } from "../icons/mingcute/system/close_line";
import { countGraphemes } from "@/shared/utils/strings/count_graphemes";
import { cn } from "@/adapters/cn";
import { lightTokens, resolveToken } from "@/theme/tokens";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";

export type FlyInputSize = "xs" | "sm" | "lg" | "xl";
export type FlyInputVariant = "outlined" | "filled" | "borderless" | "underlined";
export type FlyInputAS = "input" | "textarea";

export interface FlyInputProps
  extends Omit<TextInputProps, "value" | "onChange" | "onChangeText"> {
  size?: FlyInputSize;
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  preTab?: React.ReactNode;
  postTab?: React.ReactNode;
  variant?: FlyInputVariant;
  viewClearButton?: boolean;
  clearIcon?: React.ReactNode;
  maxLength?: number;
  showCount?: boolean | { short?: boolean };
  value?: string;
  onChange?: (value: string) => void;
  onPressEnter?: () => void;
  onClear?: () => void;
  as?: FlyInputAS;
  textColor?: string;
  className?: string;
}

const SIZE_STYLES: Record<
  FlyInputSize,
  { heightClass: string; textClass: string; paddingY: string }
> = {
  xs: { heightClass: "h-7", textClass: "text-xs", paddingY: "py-1" },
  sm: { heightClass: "h-10", textClass: "text-sm", paddingY: "py-2" },
  lg: { heightClass: "h-12", textClass: "text-base", paddingY: "py-3" },
  xl: { heightClass: "h-12", textClass: "text-lg", paddingY: "py-3" },
};

function variantClasses(variant: FlyInputVariant): string {
  switch (variant) {
    case "outlined":
      return "bg-transparent rounded-lg border border-primary/10";
    case "filled":
      return "rounded-lg bg-primary/5 border border-primary/10";
    case "borderless":
      return "rounded-lg border-0 bg-transparent";
    case "underlined":
      return "border-0 border-b-2 border-primary/10 rounded-none bg-transparent";
    default:
      return "";
  }
}

const FlyInput = forwardRef<TextInput, FlyInputProps>((props, ref) => {
  const {
    size = "sm",
    prefix,
    suffix,
    preTab,
    postTab,
    variant = "outlined",
    viewClearButton = false,
    clearIcon,
    maxLength,
    showCount,
    value: controlledValue,
    onChange,
    onPressEnter,
    onClear,
    as = "input",
    textColor,
    className = "",
    style,
    placeholder,
    ...rest
  } = props;

  const [innerValue, setInnerValue] = useState(controlledValue ?? "");
  const { isDark } = useAppTheme();
  const sizeStyle = SIZE_STYLES[size];
  const valueToRender = controlledValue !== undefined ? controlledValue : innerValue;
  const hasPrefix = !!prefix;
  const hasSuffix = !!suffix || (viewClearButton && valueToRender.length > 0);
  const isTextarea = as === "textarea";

  const handleChange = useCallback(
    (raw: string) => {
      let v = raw;
      if (typeof maxLength === "number") {
        while (countGraphemes(v) > maxLength) v = v.slice(0, -1);
      }
      if (controlledValue === undefined) setInnerValue(v);
      onChange?.(v);
    },
    [controlledValue, maxLength, onChange]
  );

  const handleClear = useCallback(() => {
    if (controlledValue === undefined) setInnerValue("");
    onChange?.("");
    onClear?.();
  }, [controlledValue, onChange, onClear]);

  const currentCount = countGraphemes(valueToRender);
  const counterText = useMemo(() => {
    if (!showCount) return null;
    const short = typeof showCount === "object" ? !!showCount.short : false;
    if (short) return String(currentCount);
    if (typeof maxLength === "number") return `${currentCount}/${maxLength}`;
    return String(currentCount);
  }, [showCount, currentCount, maxLength]);

  const inputStyle: TextStyle = {
    color: textColor ?? lightTokens.text,
    flex: 1,
    paddingLeft: hasPrefix ? 36 : 12,
    paddingRight: hasSuffix || showCount ? 36 : 12,
  };

  return (
    <View className="flex-row items-center gap-2">
      {preTab ? <View>{preTab}</View> : null}

      <View
        className={cn(
          "relative flex-1 flex-row items-center",
          !isTextarea && sizeStyle.heightClass,
          sizeStyle.textClass
        )}
      >
        {hasPrefix ? (
          <View className="absolute left-3 z-10">{prefix}</View>
        ) : null}

        <TextInput
          ref={ref}
          value={valueToRender}
          onChangeText={handleChange}
          onSubmitEditing={onPressEnter}
          maxLength={maxLength}
          placeholder={placeholder}
          placeholderTextColor={resolveToken(isDark, "placeholder")}
          multiline={isTextarea}
          className={cn(
            "w-full",
            sizeStyle.paddingY,
            variantClasses(variant),
            isTextarea && "min-h-[96px]",
            className
          )}
          style={[inputStyle, style]}
          {...rest}
        />

        {hasSuffix ? (
          <View className="absolute right-2">
            {viewClearButton && valueToRender.length > 0 ? (
              <Pressable onPress={handleClear} hitSlop={8}>
                {clearIcon ?? <Close size={16} color={lightTokens.textMuted} />}
              </Pressable>
            ) : (
              suffix
            )}
          </View>
        ) : null}
      </View>

      {postTab ? <View>{postTab}</View> : null}

      {showCount ? (
        <Text className="text-xs text-ink/60">{counterText}</Text>
      ) : null}
    </View>
  );
});

FlyInput.displayName = "FlyInput";

export const AS = { INPUT: "input", TEXTAREA: "textarea" } as const;

export default FlyInput;
