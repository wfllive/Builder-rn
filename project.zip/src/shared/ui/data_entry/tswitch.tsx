/**
 * TSwitch — iOS-подобный переключатель.
 * Порт web-компонента: <button> → Pressable, анимация через NativeWind + style.
 */
import React from "react";
import { Pressable, View } from "react-native";
import { cn } from "@/adapters/cn";
import { lightTokens } from "@/theme/tokens";

export interface TSwitchProps {
  /** Включён / выключен */
  checked: boolean;
  /** Колбэк нового значения */
  onChange: (checked: boolean) => void;
  /** Неактивен */
  disabled?: boolean;
  /** Цвет активного трека */
  activeColor?: string;
  className?: string;
  /** a11y */
  ariaLabel?: string;
  size?: "xs" | "sm" | "lg" | "xl";
}

const sizeMap = {
  xs: { track: "w-8 h-4", knob: 12, onX: 16, offX: 2 },
  sm: { track: "w-11 h-6", knob: 20, onX: 22, offX: 2 },
  lg: { track: "w-14 h-8", knob: 28, onX: 26, offX: 2 },
  xl: { track: "w-16 h-10", knob: 32, onX: 30, offX: 2 },
} as const;

const TSwitch: React.FC<TSwitchProps> = ({
  checked,
  onChange,
  disabled = false,
  activeColor = lightTokens.primary,
  className = "",
  ariaLabel,
  size = "sm",
}) => {
  const s = sizeMap[size];

  return (
    <Pressable
      accessibilityRole="switch"
      accessibilityState={{ checked, disabled }}
      accessibilityLabel={ariaLabel}
      disabled={disabled}
      onPress={() => !disabled && onChange(!checked)}
      className={cn(
        "relative rounded-full justify-center",
        s.track,
        disabled && "opacity-50",
        className
      )}
      style={{ backgroundColor: checked ? activeColor : lightTokens.input }}
    >
      <View
        className="absolute bg-white rounded-full"
        style={{
          width: s.knob,
          height: s.knob,
          transform: [{ translateX: checked ? s.onX : s.offX }],
        }}
      />
    </Pressable>
  );
};

export default TSwitch;
