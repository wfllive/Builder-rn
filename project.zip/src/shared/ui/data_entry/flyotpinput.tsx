/**
 * FlyOtpInput — ввод кода подтверждения (ячейки).
 * Порт web-компонента на набор TextInput.
 */
import React, { useRef, useState } from "react";
import { TextInput, View } from "react-native";
import { cn } from "@/adapters/cn";
import { resolveToken } from "@/theme/tokens";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";

export interface FlyOtpInputProps {
  length?: number;
  value?: string;
  onChange?: (value: string) => void;
  className?: string;
}

const FlyOtpInput: React.FC<FlyOtpInputProps> = ({
  length = 6,
  value,
  onChange,
  className,
}) => {
  const [inner, setInner] = useState(value ?? "");
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const code = value ?? inner;
  const refs = useRef<Array<TextInput | null>>([]);

  const setAt = (index: number, char: string) => {
    const next = (code + " ".repeat(length)).slice(0, length).split("");
    next[index] = char.slice(-1);
    const joined = next.join("").replace(/ /g, "");
    if (value === undefined) setInner(joined);
    onChange?.(joined);
    if (char && index < length - 1) refs.current[index + 1]?.focus();
  };

  return (
    <View className={cn("flex-row justify-between gap-2", className)}>
      {Array.from({ length }).map((_, i) => (
        <TextInput
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
          value={code[i] ?? ""}
          onChangeText={(t) => setAt(i, t)}
          keyboardType="number-pad"
          maxLength={1}
          className="w-10 h-12 rounded-xl border border-primary/20 text-center text-lg"
          style={{ color: ink }}
          placeholderTextColor={resolveToken(isDark, "placeholder")}
        />
      ))}
    </View>
  );
};

export default FlyOtpInput;
