/**
 * FlyTagInput — ввод тегов (Enter добавляет чип).
 */
import React, { useState } from "react";
import { Text, View } from "react-native";
import FlyInput from "./flyinput";
import FlyTag from "../data_display/flytag";

export interface FlyTagInputProps {
  value?: string[];
  onChange?: (tags: string[]) => void;
  placeholder?: string;
}

export default function FlyTagInput({
  value,
  onChange,
  placeholder = "Добавить тег",
}: FlyTagInputProps) {
  const [inner, setInner] = useState<string[]>(value ?? []);
  const [draft, setDraft] = useState("");
  const tags = value ?? inner;

  const commit = () => {
    const next = draft.trim();
    if (!next || tags.includes(next)) return;
    const updated = [...tags, next];
    if (value === undefined) setInner(updated);
    onChange?.(updated);
    setDraft("");
  };

  const remove = (tag: string) => {
    const updated = tags.filter((t) => t !== tag);
    if (value === undefined) setInner(updated);
    onChange?.(updated);
  };

  return (
    <View>
      <View className="flex-row flex-wrap gap-2 mb-2">
        {tags.map((tag) => (
          <FlyTag key={tag} content={tag} hideCircle onPress={() => remove(tag)} />
        ))}
      </View>
      <FlyInput
        value={draft}
        onChange={setDraft}
        onPressEnter={commit}
        placeholder={placeholder}
      />
      <Text className="mt-1 text-xs text-muted">
        Enter — добавить, тап по тегу — удалить
      </Text>
    </View>
  );
}
