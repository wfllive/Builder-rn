/**
 * FlyCropImage
 * На вебе — react-easy-crop.
 * Кроп картинки в native делается через expo-image-manipulator в app-слое.
 * Shared хранит только слот API.
 */
import React from "react";
import { Text, View } from "react-native";

export default function FlyCropImage({ src }: { src?: string }) {
  return (
    <View className="h-48 rounded-xl bg-input items-center justify-center">
      <Text className="text-sm text-muted">
        Кроп изображения (expo-image-manipulator)
      </Text>
      {src ? (
        <Text className="text-xs text-muted mt-1" numberOfLines={1}>
          {src}
        </Text>
      ) : null}
    </View>
  );
}
