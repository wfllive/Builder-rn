/**
 * TCheckbox — три состояния: false / true / "mixed".
 * Порт web-компонента на Pressable + react-native-svg.
 */
import React from "react";
import { Pressable, View } from "react-native";
import Svg, { Path, Rect } from "react-native-svg";
import { cn } from "@/adapters/cn";
import { lightTokens } from "@/theme/tokens";

type CheckboxState = boolean | "mixed";

export interface TCheckboxProps {
  checked: CheckboxState;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
  activeColor?: string;
  className?: string;
  ariaLabel?: string;
  size?: "xs" | "sm" | "lg" | "xl";
}

const sizeMap = {
  xs: "w-4 h-4",
  sm: "w-5 h-5",
  lg: "w-7 h-7",
  xl: "w-8 h-8",
};

const TCheckbox: React.FC<TCheckboxProps> = ({
  checked,
  onChange,
  disabled = false,
  activeColor = lightTokens.primary,
  className = "",
  ariaLabel,
  size = "sm",
}) => {
  const handleToggle = () => {
    if (disabled) return;
    onChange(checked === "mixed" ? true : !checked);
  };

  const active = checked === true || checked === "mixed";

  return (
    <Pressable
      accessibilityRole="checkbox"
      accessibilityState={{ checked: checked === "mixed" ? "mixed" : !!checked, disabled }}
      accessibilityLabel={ariaLabel}
      onPress={handleToggle}
      disabled={disabled}
      className={cn(
        "items-center justify-center rounded-md border",
        sizeMap[size],
        disabled && "opacity-50",
        className
      )}
      style={{
        borderColor: active ? activeColor : lightTokens.grey0,
        backgroundColor: active ? `${activeColor}1A` : "transparent",
      }}
    >
      {checked === true && (
        <Svg width="70%" height="70%" viewBox="0 0 24 24">
          <Path
            d="M20.285 6.709a1 1 0 0 0-1.414-1.418l-9.12 9.121-4.243-4.243a1 1 0 1 0-1.414 1.414l5 5a1 1 0 0 0 1.414 0l10-10z"
            fill={activeColor}
          />
        </Svg>
      )}
      {checked === "mixed" && (
        <Svg width="70%" height="70%" viewBox="0 0 24 24">
          <Rect x="5" y="11" width="14" height="2" rx="1" fill={activeColor} />
        </Svg>
      )}
      {!active && <View />}
    </Pressable>
  );
};

export default TCheckbox;
