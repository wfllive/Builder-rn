/**
 * TSlider — горизонтальный слайдер.
 * На вебе был кастомный input[type=range].
 * На native используем встроенный Slider из RN (через простой Pressable-трек),
 * чтобы не тянуть @react-native-community/slider в shared.
 *
 * Для продакшена команда может заменить реализацию на community-slider,
 * сохранив эти же пропсы.
 */
import React from "react";
import { LayoutChangeEvent, PanResponder, View } from "react-native";
import { cn } from "@/adapters/cn";
import { lightTokens } from "@/theme/tokens";

export interface TSliderProps {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  disabled?: boolean;
  className?: string;
  activeColor?: string;
}

const TSlider: React.FC<TSliderProps> = ({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  disabled = false,
  className,
  activeColor = lightTokens.primary,
}) => {
  const [width, setWidth] = React.useState(1);
  const ratio = (value - min) / (max - min || 1);

  const setFromX = (x: number) => {
    if (disabled) return;
    const raw = min + (Math.min(Math.max(x, 0), width) / width) * (max - min);
    const stepped = Math.round(raw / step) * step;
    onChange(Math.min(max, Math.max(min, stepped)));
  };

  const pan = React.useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !disabled,
      onMoveShouldSetPanResponder: () => !disabled,
      onPanResponderGrant: (e) => setFromX(e.nativeEvent.locationX),
      onPanResponderMove: (e) => setFromX(e.nativeEvent.locationX),
    })
  ).current;

  const onLayout = (e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width);

  return (
    <View
      onLayout={onLayout}
      className={cn("h-8 justify-center", disabled && "opacity-50", className)}
      {...pan.panHandlers}
    >
      <View className="h-1.5 rounded-full bg-primary/15 overflow-hidden">
        <View
          className="h-full rounded-full"
          style={{ width: `${ratio * 100}%`, backgroundColor: activeColor }}
        />
      </View>
      <View
        className="absolute w-5 h-5 rounded-full bg-white"
        style={{
          left: Math.max(0, ratio * width - 10),
          borderWidth: 2,
          borderColor: activeColor,
        }}
      />
    </View>
  );
};

export default TSlider;
