/**
 * FlySelectMenu — выбор из списка.
 * На native открывается как bottom sheet (вместо HTML select).
 */
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import FlyBottomSheetModal from "../feedback/flybottom_sheet_modal";
import { cn } from "@/adapters/cn";

export interface FlySelectOption {
  value: string;
  label: string;
}

export interface FlySelectMenuProps {
  options: FlySelectOption[];
  value?: string;
  placeholder?: string;
  onChange?: (value: string) => void;
  className?: string;
}

export default function FlySelectMenu({
  options,
  value,
  placeholder = "Выберите",
  onChange,
  className,
}: FlySelectMenuProps) {
  const [open, setOpen] = useState(false);
  const current = options.find((o) => o.value === value);

  return (
    <View className={cn(className)}>
      <Pressable
        onPress={() => setOpen(true)}
        className="h-10 px-3 rounded-lg border border-primary/10 justify-center"
      >
        <Text className="text-ink">
          {current?.label ?? placeholder}
        </Text>
      </Pressable>
      <FlyBottomSheetModal open={open} onCancel={() => setOpen(false)} actions={null}>
        <View className="gap-1 mt-2">
          {options.map((opt) => (
            <Pressable
              key={opt.value}
              className="py-3"
              onPress={() => {
                onChange?.(opt.value);
                setOpen(false);
              }}
            >
              <Text className="text-base text-ink">{opt.label}</Text>
            </Pressable>
          ))}
        </View>
      </FlyBottomSheetModal>
    </View>
  );
}
