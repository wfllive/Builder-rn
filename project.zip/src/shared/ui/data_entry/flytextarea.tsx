/**
 * FlyTextarea — многострочный ввод.
 * Обёртка над FlyInput as="textarea" (как на вебе отдельный файл).
 */
import React, { forwardRef } from "react";
import { type TextInput } from "react-native";
import FlyInput, { type FlyInputProps } from "./flyinput";

const FlyTextarea = forwardRef<TextInput, Omit<FlyInputProps, "as">>((props, ref) => {
  return <FlyInput ref={ref} {...props} as="textarea" />;
});

FlyTextarea.displayName = "FlyTextarea";
export default FlyTextarea;
