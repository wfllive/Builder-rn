/**
 * TRadio + TRadio.Group
 * Порт web-компонента. Скрытый <input> убран — a11y через accessibilityRole.
 */
import React, { createContext, useContext } from "react";
import { Pressable, Text, View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";
import { lightTokens } from "@/theme/tokens";

interface TRadioGroupContextType {
  value?: string;
  onChange?: (value: string) => void;
  name?: string;
}

const TRadioGroupContext = createContext<TRadioGroupContextType | null>(null);

export type TRadioSize = "xs" | "sm" | "lg" | "xl";

const sizeMap: Record<TRadioSize, { wrapperGap: string; circle: number; dot: number }> = {
  xs: { wrapperGap: "gap-2", circle: 12, dot: 6 },
  sm: { wrapperGap: "gap-3", circle: 16, dot: 8 },
  lg: { wrapperGap: "gap-4", circle: 20, dot: 10 },
  xl: { wrapperGap: "gap-4", circle: 24, dot: 12 },
};

export interface TRadioProps {
  value: string;
  checked?: boolean;
  size?: TRadioSize;
  children?: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
  onChange?: (value: string) => void;
}

const TRadioComponent: React.FC<TRadioProps> = ({
  value,
  checked,
  size = "sm",
  children,
  className,
  style,
  disabled,
  onChange,
}) => {
  const group = useContext(TRadioGroupContext);
  const isChecked = group?.value !== undefined ? group.value === value : checked;
  const s = sizeMap[size];

  const handlePress = () => {
    if (disabled) return;
    group?.onChange?.(value);
    onChange?.(value);
  };

  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ checked: !!isChecked, disabled: !!disabled }}
      onPress={handlePress}
      disabled={disabled}
      className={cn("flex-row items-center", s.wrapperGap, disabled && "opacity-50", className)}
      style={style}
    >
      <View
        className="items-center justify-center rounded-full"
        style={{
          width: s.circle,
          height: s.circle,
          borderWidth: isChecked ? 2 : 1,
          borderColor: isChecked ? lightTokens.primary : lightTokens.grey0,
        }}
      >
        {isChecked ? (
          <View
            className="rounded-full"
            style={{
              width: s.dot,
              height: s.dot,
              backgroundColor: lightTokens.primary,
            }}
          />
        ) : null}
      </View>
      {children ? (
        <View className="flex-1">
          {typeof children === "string" ? (
            <Text className="text-ink">{children}</Text>
          ) : (
            children
          )}
        </View>
      ) : null}
    </Pressable>
  );
};

export interface TRadioGroupProps {
  value: string;
  onChange: (value: string) => void;
  name: string;
  children: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
}

const TRadioGroup: React.FC<TRadioGroupProps> = ({
  value,
  onChange,
  name,
  children,
  className,
  style,
}) => (
  <TRadioGroupContext.Provider value={{ value, onChange, name }}>
    <View className={cn("flex-col gap-3", className)} style={style}>
      {children}
    </View>
  </TRadioGroupContext.Provider>
);

export const TRadio = Object.assign(TRadioComponent, { Group: TRadioGroup });
