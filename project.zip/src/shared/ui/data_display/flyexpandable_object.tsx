/**
 * FlyExpandableObject — «показать ещё».
 */
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";

export default function FlyExpandableObject({
  children,
  collapsedHeight = 72,
}: {
  children?: React.ReactNode;
  collapsedHeight?: number;
}) {
  const [open, setOpen] = useState(false);

  return (
    <View>
      <View style={open ? undefined : { maxHeight: collapsedHeight, overflow: "hidden" }}>
        {children}
      </View>
      <Pressable onPress={() => setOpen((v) => !v)} className="mt-1">
        <Text className="text-sm text-primary">
          {open ? "Свернуть" : "Показать ещё"}
        </Text>
      </Pressable>
    </View>
  );
}
