/**
 * TInfiniteMarquee — бегущая строка (упрощённый native-порт).
 */
import React from "react";
import { ScrollView, View } from "react-native";

export default function TInfiniteMarquee({ children }: { children?: React.ReactNode }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View className="flex-row items-center gap-6 py-2">{children}</View>
    </ScrollView>
  );
}
