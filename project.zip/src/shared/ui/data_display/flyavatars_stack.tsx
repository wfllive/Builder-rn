/**
 * FlyAvatarsStack — стопка аватаров со смещением.
 */
import React from "react";
import { View } from "react-native";
import FlyAvatar, { type FlyAvatarProps } from "./flyavatar";
import { cn } from "@/adapters/cn";

export interface FlyAvatarsStackProps {
  items: FlyAvatarProps[];
  max?: number;
  className?: string;
}

const FlyAvatarsStack: React.FC<FlyAvatarsStackProps> = ({
  items,
  max = 4,
  className,
}) => {
  const shown = items.slice(0, max);
  return (
    <View className={cn("flex-row items-center", className)}>
      {shown.map((item, i) => (
        <View key={i} style={{ marginLeft: i === 0 ? 0 : -10, zIndex: shown.length - i }}>
          <FlyAvatar {...item} size="xs" stroke={2} strokeColor="#ffffff" />
        </View>
      ))}
    </View>
  );
};

export default FlyAvatarsStack;
