/**
 * FlyFileItemHolder — строка файла (имя + размер).
 */
import React from "react";
import { Text, View } from "react-native";
import { formatFileSize } from "@/shared/utils/format_file_size";
import { cn } from "@/adapters/cn";

export default function FlyFileItemHolder({
  name,
  size,
  className,
}: {
  name: string;
  size?: number;
  className?: string;
}) {
  return (
    <View className={cn("flex-row items-center justify-between rounded-xl px-3 py-2 bg-primary/5", className)}>
      <Text className="flex-1 text-sm text-ink" numberOfLines={1}>
        {name}
      </Text>
      <Text className="ml-2 text-xs text-muted">
        {formatFileSize(size)}
      </Text>
    </View>
  );
}
