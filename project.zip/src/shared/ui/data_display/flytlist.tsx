/**
 * FlyTList — вертикальный список слотов.
 * На вебе мог быть виртуальный список; здесь обычный map
 * (виртуализация — FlatList в экране, не в shared).
 */
import React from "react";
import { View } from "react-native";
import { cn } from "@/adapters/cn";

export interface FlyTListProps<T> {
  items: T[];
  renderItem: (item: T, index: number) => React.ReactNode;
  keyExtractor?: (item: T, index: number) => string;
  className?: string;
}

export default function FlyTList<T>({
  items,
  renderItem,
  keyExtractor,
  className,
}: FlyTListProps<T>) {
  return (
    <View className={cn("gap-2", className)}>
      {items.map((item, index) => (
        <View key={keyExtractor ? keyExtractor(item, index) : String(index)}>
          {renderItem(item, index)}
        </View>
      ))}
    </View>
  );
}
