/**
 * FlyTag — компактный тег с опциональным счётчиком.
 * Порт web-компонента. <button> → Pressable.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import { cn } from "@/adapters/cn";

export type FlyTagEffect = "scale-up" | "scale-down" | undefined;

export interface FlyTagProps {
  content: React.ReactNode;
  count?: number;
  hideCircle?: boolean;
  circleContent?: React.ReactNode;
  effect?: FlyTagEffect;
  isAgario?: boolean;
  size?: "xs" | "sm" | "lg" | "xl";
  className?: string;
  onPress?: () => void;
  onClick?: () => void;
}

const baseTagSizes: Record<NonNullable<FlyTagProps["size"]>, string> = {
  xs: "px-2 py-1.5",
  sm: "px-3 py-1.5",
  lg: "px-4 py-2",
  xl: "px-5 py-2.5",
};

const textSizes: Record<NonNullable<FlyTagProps["size"]>, string> = {
  xs: "text-xs",
  sm: "text-sm",
  lg: "text-base",
  xl: "text-lg",
};

export const FlyTag = React.forwardRef<View, FlyTagProps>(
  (
    {
      content,
      count = 0,
      hideCircle = false,
      circleContent,
      effect,
      size = "sm",
      className = "",
      onPress,
      onClick,
    },
    _ref
  ) => {
    const normalizedCount = Math.abs(Math.trunc(count));
    const pressScale = effect === "scale-up" ? 1.05 : effect === "scale-down" ? 0.95 : 1;

    return (
      <Pressable
        onPress={onPress ?? onClick}
        className={cn(
          "flex-row items-center rounded-full bg-input",
          baseTagSizes[size],
          className
        )}
        style={({ pressed }) => (pressed && effect ? { transform: [{ scale: pressScale }] } : undefined)}
      >
        {typeof content === "string" ? (
          <Text
            className={cn(
              textSizes[size],
              className.includes("text-") ? "" : "text-primary"
            )}
          >
            {content}
          </Text>
        ) : (
          content
        )}

        {circleContent ? (
          <View className="ml-1">{circleContent}</View>
        ) : (
          !hideCircle && (
            <View className="ml-1 min-w-[20px] h-5 px-1 rounded-full bg-placeholder items-center justify-center">
              <Text className="text-xs text-white">{normalizedCount}</Text>
            </View>
          )
        )}
      </Pressable>
    );
  }
);

FlyTag.displayName = "FlyTag";
export default FlyTag;
