/**
 * FlyPremiumTariff — карточка тарифа.
 */
import React from "react";
import { Text, View } from "react-native";
import TButton from "../buttons/tbutton";
import { cn } from "@/adapters/cn";

export interface FlyPremiumTariffProps {
  title: string;
  price: string;
  features?: string[];
  onSelect?: () => void;
  className?: string;
}

export default function FlyPremiumTariff({
  title,
  price,
  features = [],
  onSelect,
  className,
}: FlyPremiumTariffProps) {
  return (
    <View className={cn("p-4 rounded-2xl bg-primary/8", className)}>
      <Text className="text-lg font-bold text-ink">{title}</Text>
      <Text className="mt-1 text-2xl font-extrabold text-primary">{price}</Text>
      <View className="mt-3 gap-1">
        {features.map((f) => (
          <Text key={f} className="text-sm text-ink">
            • {f}
          </Text>
        ))}
      </View>
      <View className="mt-4">
        <TButton.Solid onPress={onSelect}>Выбрать</TButton.Solid>
      </View>
    </View>
  );
}
