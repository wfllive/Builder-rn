/**
 * TQrCode
 * На вебе — пакет qrcode.
 * В shared native не тянем нативную генерацию: слот для app-слоя.
 */
import React from "react";
import { Text, View } from "react-native";

export default function TQrCode({ value }: { value?: string }) {
  return (
    <View className="w-40 h-40 rounded-xl bg-input items-center justify-center">
      <Text className="text-xs text-muted text-center px-2">
        QR: {value ?? "—"}
      </Text>
    </View>
  );
}
