/**
 * FlyVideoPlayer
 * На вебе — кастомный HTML5 player.
 * В shared native видео не встраиваем: нужен expo-av / expo-video в app-слое.
 * Здесь — превью-заглушка с тем же публичным пропом `src`.
 */
import React from "react";
import { Text, View } from "react-native";

export default function FlyVideoPlayer({ src }: { src?: string }) {
  return (
    <View className="w-full h-48 rounded-xl bg-black items-center justify-center">
      <Text className="text-white/80 text-sm">Видео (подключить expo-video)</Text>
      {src ? (
        <Text className="text-white/40 text-xs mt-1" numberOfLines={1}>
          {src}
        </Text>
      ) : null}
    </View>
  );
}
