/**
 * FlyColdStartProfilesModal
 * На вебе тянул рекомендации профилей.
 * Здесь — оболочка шторки; список профилей приходит пропсом (app-слой ходит в API).
 */
import React from "react";
import { Text, View } from "react-native";
import FlyBottomSheetModal from "../feedback/flybottom_sheet_modal";
import FlyAvatar from "./flyavatar";

export const COLD_START_USERS_DONE_KEY = "COLD_START_USERS_DONE_KEY";

export interface ColdStartProfile {
  id: number;
  username: string;
  avatar?: string | null;
}

export interface FlyColdStartProfilesModalProps {
  open: boolean;
  onClose?: () => void;
  currentUserId?: number;
  limit?: number;
  profiles?: ColdStartProfile[];
}

export default function FlyColdStartProfilesModal({
  open,
  onClose,
  profiles = [],
}: FlyColdStartProfilesModalProps) {
  return (
    <FlyBottomSheetModal
      open={open}
      onCancel={onClose}
      title="Кого почитать"
      message="Выбери нескольких авторов, чтобы лента ожила"
    >
      <View className="mt-4 gap-3">
        {profiles.map((p) => (
          <View key={p.id} className="flex-row items-center gap-3">
            <FlyAvatar src={p.avatar ?? undefined} alt={p.username} size="sm" />
            <Text className="text-ink font-medium">{p.username}</Text>
          </View>
        ))}
      </View>
    </FlyBottomSheetModal>
  );
}
