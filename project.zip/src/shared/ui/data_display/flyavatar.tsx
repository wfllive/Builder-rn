/**
 * FlyAvatar
 * ---------------------------------------------------------------
 * Порт web-аватара: Image + fallback на первую букву alt.
 * badges позиционируются абсолютно, как на вебе.
 */
import React, { useState } from "react";
import { Image, Text, View } from "react-native";
import { cn } from "@/adapters/cn";

type AvatarSize = "xs" | "sm" | "lg" | "xl" | number | string;
type Shape = "circle" | "rounded";
type BadgePosition =
  | "top-left"
  | "top-center"
  | "top-right"
  | "center-left"
  | "center-right"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

export interface FlyAvatarProps {
  src?: string;
  alt?: string;
  size?: AvatarSize;
  shape?: Shape;
  stroke?: number;
  strokeColor?: string;
  zoom?: number;
  className?: string;
  strokePadding?: number;
  badges?: { position: BadgePosition; content: React.ReactNode }[];
}

const sizeMap: Record<string, { box: string; px: number }> = {
  xs: { box: "w-8 h-8", px: 32 },
  sm: { box: "w-12 h-12", px: 48 },
  lg: { box: "w-24 h-24", px: 96 },
  xl: { box: "w-32 h-32", px: 128 },
};

const badgePos: Record<BadgePosition, string> = {
  "top-left": "top-0 left-0",
  "top-center": "top-0 left-1/2",
  "top-right": "top-0 right-0",
  "center-left": "top-1/2 left-0",
  "center-right": "top-1/2 right-0",
  "bottom-left": "bottom-0 left-0",
  "bottom-center": "bottom-0 left-1/2",
  "bottom-right": "bottom-0 right-0",
};

const FlyAvatar: React.FC<FlyAvatarProps> = ({
  src,
  alt = "?",
  size = "sm",
  shape = "circle",
  stroke = 0,
  strokeColor = "#5F18DA",
  zoom = 1,
  className = "",
  strokePadding = 0,
  badges = [],
}) => {
  const [imgError, setImgError] = useState(false);
  const preset = typeof size === "string" ? sizeMap[size] : undefined;
  const px = typeof size === "number" ? size : preset?.px;
  const radius = shape === "circle" ? 999 : 16;

  return (
    <View
      className={cn("relative shrink-0", preset?.box, className)}
      style={px && !preset ? { width: px, height: px } : undefined}
    >
      <View
        className="w-full h-full overflow-hidden items-center justify-center"
        style={{
          borderRadius: radius,
          borderWidth: stroke,
          borderColor: strokeColor,
          padding: strokePadding,
        }}
      >
        {src && !imgError ? (
          <Image
            source={{ uri: src }}
            style={{
              width: "100%",
              height: "100%",
              transform: [{ scale: zoom }],
              borderRadius: radius,
            }}
            onError={() => setImgError(true)}
          />
        ) : (
          <View
            className="w-full h-full bg-ink/20 items-center justify-center"
            style={{ borderRadius: radius }}
          >
            <Text className="text-white font-semibold">
              {alt.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
      </View>

      {badges.map((badge, index) => (
        <View key={index} className={cn("absolute z-10", badgePos[badge.position])}>
          {badge.content}
        </View>
      ))}
    </View>
  );
};

export default FlyAvatar;
