/**
 * FlyAttachmentBox — контейнер вложений треда (сетка превью).
 */
import React from "react";
import { View } from "react-native";
import { cn } from "@/adapters/cn";

export default function FlyAttachmentBox({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return <View className={cn("flex-row flex-wrap gap-2", className)}>{children}</View>;
}
