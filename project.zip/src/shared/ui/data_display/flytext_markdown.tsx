/**
 * FlyTextMarkdown
 * ---------------------------------------------------------------
 * На вебе — react-markdown + remark-gfm.
 * В shared native не тянем тяжёлый парсер: рендерим plain-text
 * с простым выделением **жирного** и #заголовков.
 * Полноценный markdown — задача app-слоя (если понадобится).
 */
import React from "react";
import { Text, View } from "react-native";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function FlyTextMarkdown({ children }: { children?: string }) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const text = children ?? "";
  const lines = text.split("\n");

  return (
    <View>
      {lines.map((line, i) => {
        if (line.startsWith("# ")) {
          return (
            <Text key={i} className="text-lg font-bold mb-1" style={{ color: ink }}>
              {line.slice(2)}
            </Text>
          );
        }
        const parts = line.split(/(\*\*[^*]+\*\*)/g);
        return (
          <Text key={i} className="text-[15px] leading-6" style={{ color: ink }}>
            {parts.map((p, j) =>
              p.startsWith("**") && p.endsWith("**") ? (
                <Text key={j} className="font-bold" style={{ color: ink }}>
                  {p.slice(2, -2)}
                </Text>
              ) : (
                <Text key={j} style={{ color: ink }}>
                  {p}
                </Text>
              )
            )}
          </Text>
        );
      })}
    </View>
  );
}
