/**
 * FlyTextMarkdown
 * ---------------------------------------------------------------
 * На вебе — react-markdown + remark-gfm.
 * В shared native не тянем тяжёлый парсер: рендерим plain-text
 * с простым выделением **жирного** и #заголовков.
 * Полноценный markdown — задача app-слоя (если понадобится).
 */
import React from "react";
import { Text, View } from "react-native";

export default function FlyTextMarkdown({ children }: { children?: string }) {
  const text = children ?? "";
  const lines = text.split("\n");

  return (
    <View>
      {lines.map((line, i) => {
        if (line.startsWith("# ")) {
          return (
            <Text key={i} className="text-lg font-bold text-ink dark:text-[#F3F5F7] mb-1">
              {line.slice(2)}
            </Text>
          );
        }
        const parts = line.split(/(\*\*[^*]+\*\*)/g);
        return (
          <Text key={i} className="text-ink dark:text-[#F3F5F7] text-[15px] leading-6">
            {parts.map((p, j) =>
              p.startsWith("**") && p.endsWith("**") ? (
                <Text key={j} className="font-bold">
                  {p.slice(2, -2)}
                </Text>
              ) : (
                <Text key={j}>{p}</Text>
              )
            )}
          </Text>
        );
      })}
    </View>
  );
}
