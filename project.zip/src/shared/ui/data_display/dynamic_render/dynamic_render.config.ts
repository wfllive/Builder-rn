/**
 * Конфиг DynamicRender. На native оставлен пустым — антибот-DOM не нужен.
 */
export const DYNAMIC_RENDER_ENABLED = false;
