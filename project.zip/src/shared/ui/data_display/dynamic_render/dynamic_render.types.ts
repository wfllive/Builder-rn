/**
 * Типы DynamicRender (web-антибот). На native не используются.
 */
export type DynamicRenderNode = {
  tag: string;
  className?: string;
  children?: DynamicRenderNode[];
};
