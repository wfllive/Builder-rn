/**
 * DynamicRender
 * На вебе — антибот-обёртка со случайными DOM-узлами.
 * На native антибот-DOM не нужен: компонент прозрачно рендерит children.
 */
import React from "react";

export default function DynamicRender({ children }: { children?: React.ReactNode }) {
  return <>{children}</>;
}
