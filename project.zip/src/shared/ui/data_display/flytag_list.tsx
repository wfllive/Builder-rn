/**
 * FlyTagList — горизонтальный список тегов.
 */
import React from "react";
import { ScrollView, View } from "react-native";
import FlyTag, { type FlyTagProps } from "./flytag";
import { cn } from "@/adapters/cn";

export interface FlyTagListProps {
  tags: Array<FlyTagProps & { key?: string }>;
  className?: string;
}

const FlyTagList: React.FC<FlyTagListProps> = ({ tags, className }) => {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      className={cn(className)}
      contentContainerClassName="flex-row gap-2"
    >
      {tags.map((tag, i) => (
        <View key={tag.key ?? String(i)}>
          <FlyTag {...tag} />
        </View>
      ))}
    </ScrollView>
  );
};

export default FlyTagList;
