/**
 * FlyAttachmentItemHolder — превью одного медиа-вложения.
 * На вебе это миниатюра в сетке. Здесь Image + запасной цветной блок.
 */
import React, { useState } from "react";
import { Image, Text, View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";

export default function FlyAttachmentItemHolder({
  uri,
  className,
  style,
  height = 196,
}: {
  uri: string;
  className?: string;
  style?: StyleProp<ViewStyle>;
  height?: number;
}) {
  const [failed, setFailed] = useState(false);

  return (
    <View
      className={cn("w-full rounded-2xl overflow-hidden bg-input", className)}
      style={[{ height }, style]}
    >
      {uri && !failed ? (
        <Image
          source={{ uri }}
          style={{ width: "100%", height: "100%" }}
          resizeMode="cover"
          onError={() => setFailed(true)}
        />
      ) : (
        <View className="flex-1 items-center justify-center bg-primary/15">
          <Text className="text-sm text-primary">фото</Text>
        </View>
      )}
    </View>
  );
}
