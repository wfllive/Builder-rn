/**
 * FlyAttachmentItemHolder — превью одного медиа-вложения.
 * source: require() или { uri }. require надёжнее в release, чем localhost-uri.
 */
import React, { useState } from "react";
import {
  Image,
  Text,
  View,
  type ImageSourcePropType,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { cn } from "@/adapters/cn";
import { photoSource } from "@/example/demo_media";

export default function FlyAttachmentItemHolder({
  uri,
  source,
  className,
  style,
  height = 196,
}: {
  uri?: string;
  source?: ImageSourcePropType;
  className?: string;
  style?: StyleProp<ViewStyle>;
  height?: number;
}) {
  const [failed, setFailed] = useState(false);
  const resolved = source ?? photoSource(uri);

  return (
    <View
      className={cn("w-full rounded-2xl overflow-hidden bg-input", className)}
      style={[{ height }, style]}
    >
      {resolved && !failed ? (
        <Image
          source={resolved}
          style={{ width: "100%", height: "100%" }}
          resizeMode="cover"
          onError={() => setFailed(true)}
        />
      ) : (
        <View className="flex-1 items-center justify-center bg-primary/15">
          <Text className="text-sm text-primary">фото</Text>
        </View>
      )}
    </View>
  );
}
