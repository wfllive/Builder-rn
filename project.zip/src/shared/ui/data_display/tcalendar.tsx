/**
 * TCalendar — компактный календарь месяца (выбор дня).
 */
import React, { useMemo, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { cn } from "@/adapters/cn";

export interface TCalendarProps {
  value?: Date;
  onChange?: (date: Date) => void;
  className?: string;
}

export default function TCalendar({ value, onChange, className }: TCalendarProps) {
  const [cursor, setCursor] = useState(value ?? new Date());
  const year = cursor.getFullYear();
  const month = cursor.getMonth();

  const days = useMemo(() => {
    const first = new Date(year, month, 1).getDay();
    const count = new Date(year, month + 1, 0).getDate();
    const pad = (first + 6) % 7; // понедельник первым
    return [...Array(pad).fill(null), ...Array.from({ length: count }, (_, i) => i + 1)];
  }, [year, month]);

  const selected = value?.getDate();

  return (
    <View className={cn("p-3", className)}>
      <View className="flex-row justify-between mb-3">
        <Pressable onPress={() => setCursor(new Date(year, month - 1, 1))}>
          <Text className="text-primary">‹</Text>
        </Pressable>
        <Text className="font-semibold text-ink">
          {cursor.toLocaleDateString("ru-RU", { month: "long", year: "numeric" })}
        </Text>
        <Pressable onPress={() => setCursor(new Date(year, month + 1, 1))}>
          <Text className="text-primary">›</Text>
        </Pressable>
      </View>
      <View className="flex-row flex-wrap">
        {days.map((d, i) => (
          <Pressable
            key={i}
            className="w-[14.28%] aspect-square items-center justify-center"
            disabled={!d}
            onPress={() => d && onChange?.(new Date(year, month, d))}
          >
            <View
              className={cn(
                "w-8 h-8 rounded-full items-center justify-center",
                d === selected && "bg-primary"
              )}
            >
              <Text className={d === selected ? "text-white" : "text-ink"}>
                {d ?? ""}
              </Text>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
