/**
 * LockedLoaderImage
 * ---------------------------------------------------------------
 * На вебе — next/image с лоадером.
 * На native — Image + скелетон до onLoad.
 */
import React, { useState } from "react";
import { Image, View } from "react-native";
import TSkeleton from "../feedback/tskeleton";
import { cn } from "@/adapters/cn";

export interface LockedLoaderImageProps {
  src: string;
  alt?: string;
  width?: number;
  height?: number;
  className?: string;
}

const LockedLoaderImage: React.FC<LockedLoaderImageProps> = ({
  src,
  alt,
  width = 48,
  height = 48,
  className,
}) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <View className={cn("overflow-hidden", className)} style={{ width, height }}>
      {!loaded && <TSkeleton className="absolute inset-0 w-full h-full" />}
      <Image
        source={{ uri: src }}
        accessibilityLabel={alt}
        onLoad={() => setLoaded(true)}
        style={{ width, height }}
      />
    </View>
  );
};

export default LockedLoaderImage;
