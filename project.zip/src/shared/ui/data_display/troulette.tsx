/**
 * TRoulette — декоративный рулеточный слот (web-анимация упрощена).
 */
import React from "react";
import { Text, View } from "react-native";

export default function TRoulette({ items = [] }: { items?: string[] }) {
  return (
    <View className="h-10 overflow-hidden items-center justify-center rounded-xl bg-primary/10">
      <Text className="text-primary font-semibold">
        {items[0] ?? "—"}
      </Text>
    </View>
  );
}
