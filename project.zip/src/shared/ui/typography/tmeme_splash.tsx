/**
 * TMemeSplash — крупный акцентный текст (мемные заставки / empty-state).
 */
import React from "react";
import { Text, View } from "react-native";
import { cn } from "@/adapters/cn";

export default function TMemeSplash({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <View className={cn("items-center py-8", className)}>
      <Text className="text-2xl font-extrabold italic text-primary text-center">
        {children}
      </Text>
    </View>
  );
}
