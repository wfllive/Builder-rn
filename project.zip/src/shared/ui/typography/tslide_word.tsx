/**
 * TSlideWord — слово с лёгкой пульсацией (web: CSS animation).
 */
import React, { useEffect, useRef } from "react";
import { Animated, Text } from "react-native";

export default function TSlideWord({ children }: { children?: React.ReactNode }) {
  const opacity = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.4, duration: 700, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);

  return (
    <Animated.View style={{ opacity }}>
      <Text className="text-primary font-bold">{children}</Text>
    </Animated.View>
  );
}
