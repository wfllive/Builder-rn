/**
 * FlyTextMarker — выделение фрагмента текста фирменным цветом.
 */
import React from "react";
import { Text } from "react-native";
import { cn } from "@/adapters/cn";

export default function FlyTextMarker({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <Text className={cn("text-primary font-semibold", className)}>
      {children}
    </Text>
  );
}
