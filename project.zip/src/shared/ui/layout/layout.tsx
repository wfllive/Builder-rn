/**
 * Layout — мобильный каркас: лента + стекло-шапка + стекло-таббар.
 *
 * Для Liquid Glass (react-native-android-liquid-glass):
 * стекло и контент — дети ОДНОГО родителя, collapsable={false}.
 * Обёртка вокруг стекла ломает захват фона.
 */
import React from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export interface LayoutProps {
  header?: React.ReactNode;
  children?: React.ReactNode;
  tabBar?: React.ReactNode;
  hideHeader?: boolean;
  hideTabBar?: boolean;
  className?: string;
  headerClassName?: string;
  contentClassName?: string;
  tabBarClassName?: string;
  style?: StyleProp<ViewStyle>;
}

export default function Layout({
  header,
  children,
  tabBar,
  hideHeader = false,
  hideTabBar = false,
  className = "",
  contentClassName = "",
  style,
}: LayoutProps) {
  const { isDark } = useAppTheme();
  const showHeader = Boolean(header) && !hideHeader;
  const showTabBar = Boolean(tabBar) && !hideTabBar;

  return (
    <View
      collapsable={false}
      className={cn("flex-1", className)}
      style={[{ backgroundColor: resolveToken(isDark, "background") }, style]}
    >
      <View className={cn("flex-1", contentClassName)}>{children}</View>
      {showHeader ? header : null}
      {showTabBar ? tabBar : null}
    </View>
  );
}
