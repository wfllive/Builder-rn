/**
 * Layout — мобильный каркас: лента + стекло-шапка + стекло-таббар.
 *
 * Контент завёрнут в `GlassTargetArea` (expo-blur `BlurTargetView`) —
 * именно его Android размывает под барами. Бары рендерятся ПОСЛЕ
 * контента: BlurView должен идти после динамических списков,
 * иначе размытие не обновляется.
 */
import React from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { GlassTargetArea, GlassTargetProvider } from "@/shared/ui/layout/glass_target";

export interface LayoutProps {
  header?: React.ReactNode;
  children?: React.ReactNode;
  tabBar?: React.ReactNode;
  hideHeader?: boolean;
  hideTabBar?: boolean;
  className?: string;
  headerClassName?: string;
  contentClassName?: string;
  tabBarClassName?: string;
  style?: StyleProp<ViewStyle>;
}

export default function Layout({
  header,
  children,
  tabBar,
  hideHeader = false,
  hideTabBar = false,
  className = "",
  contentClassName = "",
  style,
}: LayoutProps) {
  const { isDark } = useAppTheme();
  const showHeader = Boolean(header) && !hideHeader;
  const showTabBar = Boolean(tabBar) && !hideTabBar;

  return (
    <GlassTargetProvider>
      <View
        collapsable={false}
        className={cn("flex-1", className)}
        style={[{ backgroundColor: resolveToken(isDark, "background") }, style]}
      >
        <GlassTargetArea>
          <View className={cn("flex-1", contentClassName)}>{children}</View>
        </GlassTargetArea>
        {showHeader ? header : null}
        {showTabBar ? tabBar : null}
      </View>
    </GlassTargetProvider>
  );
}
