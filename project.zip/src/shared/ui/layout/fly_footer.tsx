/**
 * FlyFooter — компактный футер приложения.
 * На native обычно прячется (контент и так упирается в tab-bar),
 * но слот Layout.footer остаётся для планшетов / web.
 */
import React from "react";
import { Text, View } from "react-native";
import { currentDate } from "@/shared/utils/datetime/get_current_date";
import { cn } from "@/adapters/cn";

export interface FlyFooterProps {
  className?: string;
}

const FlyFooter: React.FC<FlyFooterProps> = ({ className }) => {
  return (
    <View className={cn("w-full py-4 items-center", className)}>
      <Text className="text-xs text-muted">
        © {currentDate.year()} Twitblit
      </Text>
    </View>
  );
};

export default FlyFooter;
