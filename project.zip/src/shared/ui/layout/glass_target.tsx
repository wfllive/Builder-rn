/**
 * Цель размытия для expo-blur.
 *
 * Android (SDK 55+): `BlurView` не умеет сам «видеть» фон — контент,
 * который нужно размывать, оборачивают в `BlurTargetView`, а его ref
 * передают в `BlurView.blurTarget`. iOS/Web ref игнорируют.
 *
 * Правило Dimezis BlurView: цель не может содержать BlurView, который
 * её же размывает, поэтому бары всегда рисуются СИБЛИНГАМИ цели и
 * ПОСЛЕ неё (иначе размытие не обновляется над списками).
 *
 * Использование:
 *   <GlassTargetProvider>
 *     <GlassTargetArea>{content}</GlassTargetArea>
 *     <GlassBar dock="top">…</GlassBar>
 *   </GlassTargetProvider>
 */
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import { BlurTargetView } from "expo-blur";

type GlassTargetValue = {
  /** Ref для `BlurView.blurTarget`. */
  target: React.RefObject<View | null>;
  /** Стало ли известно, куда указывает ref (нода смонтирована). */
  ready: boolean;
};

const fallbackRef: React.RefObject<View | null> = { current: null };

const GlassTargetContext = createContext<GlassTargetValue | null>(null);

export function GlassTargetProvider({ children }: { children: ReactNode }) {
  const target = useRef<View | null>(null);
  const [ready, setReady] = useState(false);

  // Ref заполняется при монтировании детей — эффект уже видит ноду.
  // Один ре-рендер нужен, чтобы BlurView получил blurTarget.current.
  useEffect(() => {
    if (target.current) setReady(true);
  }, []);

  const value = useMemo<GlassTargetValue>(() => ({ target, ready }), [ready]);

  return (
    <GlassTargetContext.Provider value={value}>{children}</GlassTargetContext.Provider>
  );
}

/** Область, которую размывают бары. Рендерится ДО баров. */
export function GlassTargetArea({
  children,
  style,
}: {
  children?: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const ctx = useContext(GlassTargetContext);
  return (
    <BlurTargetView
      ref={ctx?.target ?? fallbackRef}
      style={[{ flex: 1 }, style]}
      collapsable={false}
    >
      {children}
    </BlurTargetView>
  );
}

/** Ref цели размытия для `BlurView.blurTarget`; undefined — цели ещё нет. */
export function useGlassTarget(): React.RefObject<View | null> | undefined {
  const ctx = useContext(GlassTargetContext);
  if (!ctx || !ctx.ready) return undefined;
  return ctx.target;
}
