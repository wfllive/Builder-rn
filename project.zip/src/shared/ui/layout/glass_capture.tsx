/**
 * Пересъёмка Liquid Glass (legacy API).
 *
 * Native-модуль сам обновляет фон ~6 fps. Хуки оставлены no-op,
 * чтобы старые экраны не падали, если кто-то вызовет recapture.
 */
import React, { createContext, useCallback, useContext, useMemo } from "react";

type GlassCaptureValue = {
  generation: number;
  recapture: () => void;
};

const GlassCaptureContext = createContext<GlassCaptureValue>({
  generation: 0,
  recapture: () => undefined,
});

export function GlassCaptureProvider({ children }: { children: React.ReactNode }) {
  const recapture = useCallback(() => undefined, []);
  const value = useMemo(() => ({ generation: 0, recapture }), [recapture]);
  return <GlassCaptureContext.Provider value={value}>{children}</GlassCaptureContext.Provider>;
}

export function useGlassRecapture() {
  return useContext(GlassCaptureContext).recapture;
}

export function useGlassGeneration() {
  return useContext(GlassCaptureContext).generation;
}
