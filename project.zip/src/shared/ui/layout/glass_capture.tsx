/**
 * Пересъёмка Liquid Glass.
 *
 * Шейдер с enableDynamicBackground=false замораживает фон.
 * При скролле в шапке остаётся старое фото — «пририсовался скрин».
 * После остановки скролла бампим generation → GlassBar монтируется заново
 * и снимает то, что СЕЙЧАС под баром.
 */
import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

type GlassCaptureValue = {
  generation: number;
  recapture: () => void;
};

const GlassCaptureContext = createContext<GlassCaptureValue>({
  generation: 0,
  recapture: () => undefined,
});

export function GlassCaptureProvider({ children }: { children: React.ReactNode }) {
  const [generation, setGeneration] = useState(0);
  const recapture = useCallback(() => {
    setGeneration((n) => n + 1);
  }, []);
  const value = useMemo(() => ({ generation, recapture }), [generation, recapture]);
  return <GlassCaptureContext.Provider value={value}>{children}</GlassCaptureContext.Provider>;
}

export function useGlassRecapture() {
  return useContext(GlassCaptureContext).recapture;
}

export function useGlassGeneration() {
  return useContext(GlassCaptureContext).generation;
}
