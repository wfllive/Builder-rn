/**
 * Высоты стеклянных баров.
 * Контент сам добавляет padding, чтобы карточки не прятались
 * под абсолютную шапку / таббар, но при скролле уезжали ПОД blur.
 */
export const CHROME_HEADER_BODY = 52;
export const CHROME_TAB_BODY = 52;
