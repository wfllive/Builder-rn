/**
 * Native blur для верхней панели и таббара.
 *
 * @sbaiahmed1/react-native-blur использует UIVisualEffectView на iOS и
 * QmBlurView на Android. Android сам захватывает ближайший Screen/ReactRoot,
 * поэтому отдельные BlurTargetView и ручная пересъёмка не нужны.
 */
import React from "react";
import {
  Platform,
  StyleSheet,
  View,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import {
  BlurView,
  type BlurType,
} from "@sbaiahmed1/react-native-blur";
import { cssInterop } from "nativewind";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { cn } from "@/adapters/cn";

type Dock = "top" | "bottom" | "none";
type ThemeName = "light" | "dark";

type GlassTheme = {
  iosBlurType: BlurType;
  androidBlurType: BlurType;
  fallbackColor: string;
  borderColor: string;
};

const StyledBlurView = cssInterop(BlurView, { className: "style" });

/**
 * Системный chrome material на iOS; более прозрачный thin material на Android,
 * чтобы основным эффектом оставалось размытие, а не цветная заливка.
 */
const GLASS_THEME: Record<ThemeName, GlassTheme> = {
  light: {
    iosBlurType: "systemChromeMaterialLight",
    androidBlurType: "systemThinMaterialLight",
    fallbackColor: "#F7F7FA",
    borderColor: "rgba(0, 0, 0, 0.06)",
  },
  dark: {
    iosBlurType: "systemChromeMaterialDark",
    androidBlurType: "systemThinMaterialDark",
    fallbackColor: "#111014",
    borderColor: "rgba(255, 255, 255, 0.13)",
  },
};

function dockStyleOf(dock: Dock): ViewStyle | undefined {
  if (dock === "top") {
    return { position: "absolute", top: 0, left: 0, right: 0, zIndex: 30 };
  }
  if (dock === "bottom") {
    return { position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 30 };
  }
  return undefined;
}

export default function GlassBar({
  children,
  className,
  style,
  edge = "bottom",
  dock = "none",
  safeTop = false,
  safeBottom = false,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
  edge?: "top" | "bottom" | "none";
  dock?: Dock;
  safeTop?: boolean;
  safeBottom?: boolean;
}) {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const glass = GLASS_THEME[isDark ? "dark" : "light"];

  const hairline = edge === "none" ? 0 : StyleSheet.hairlineWidth;
  const border: ViewStyle = {
    borderColor: glass.borderColor,
    borderTopWidth: edge === "top" ? hairline : 0,
    borderBottomWidth: edge === "bottom" ? hairline : 0,
  };
  const padding: ViewStyle = {
    paddingTop: safeTop ? insets.top : 0,
    paddingBottom: safeBottom ? Math.max(insets.bottom, 6) : 0,
  };

  return (
    <StyledBlurView
      blurType={Platform.OS === "ios" ? glass.iosBlurType : glass.androidBlurType}
      blurAmount={24}
      blurRounds={5}
      ignoreSafeArea
      reducedTransparencyFallbackColor={glass.fallbackColor}
      className={cn(className)}
      style={[dockStyleOf(dock), border, style]}
    >
      <View style={padding}>{children}</View>
    </StyledBlurView>
  );
}
