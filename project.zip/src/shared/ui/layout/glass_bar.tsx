/**
 * GlassBar — шапка и таббар.
 *
 * Native: наш модуль `expo-liquid-glass` (modules/expo-liquid-glass).
 * Android: блюр фона под баром. iOS: UIVisualEffectView.
 * Expo Go: модуль не слинкован — полупрозрачный слой, без краша.
 *
 * Сторонний react-native-android-liquid-glass убран:
 * blurScale-скрины и лаги enableDynamicBackground.
 */
import React from "react";
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Constants from "expo-constants";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { cn } from "@/adapters/cn";

type Dock = "top" | "bottom" | "none";

function isExpoGo(): boolean {
  return (
    Constants.appOwnership === "expo" ||
    Constants.executionEnvironment === "storeClient"
  );
}

function loadOurGlass(): React.ComponentType<{
  intensity?: number;
  tint?: "dark" | "light";
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}> | null {
  if (isExpoGo()) return null;
  if (Platform.OS !== "ios" && Platform.OS !== "android") return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    return require("expo-liquid-glass").LiquidGlassView;
  } catch {
    return null;
  }
}

const NativeGlass = loadOurGlass();

function dockStyleOf(dock: Dock): ViewStyle | undefined {
  if (dock === "top") return { position: "absolute", top: 0, left: 0, right: 0, zIndex: 30 };
  if (dock === "bottom") return { position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 30 };
  return undefined;
}

export default function GlassBar({
  children,
  className,
  style,
  edge = "bottom",
  dock = "none",
  safeTop = false,
  safeBottom = false,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
  edge?: "top" | "bottom" | "none";
  dock?: Dock;
  safeTop?: boolean;
  safeBottom?: boolean;
}) {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const dockStyle = dockStyleOf(dock);
  const pad = {
    paddingTop: safeTop ? insets.top : 0,
    paddingBottom: safeBottom ? Math.max(insets.bottom, 6) : 0,
  };
  const content = <View style={pad}>{children}</View>;

  if (NativeGlass) {
    return (
      <NativeGlass
        intensity={14}
        tint={isDark ? "dark" : "light"}
        style={[dockStyle, style]}
      >
        {content}
      </NativeGlass>
    );
  }

  const hair = edge === "none" ? 0 : StyleSheet.hairlineWidth;
  return (
    <View
      className={cn(className)}
      style={[
        dockStyle,
        {
          backgroundColor: isDark ? "rgba(12, 10, 16, 0.38)" : "rgba(252, 252, 255, 0.4)",
          borderColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)",
          borderTopWidth: edge === "top" ? hair : 0,
          borderBottomWidth: edge === "bottom" ? hair : 0,
        },
        style,
      ]}
    >
      {content}
    </View>
  );
}
