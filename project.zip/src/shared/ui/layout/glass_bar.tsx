/**
 * GlassBar — Liquid Glass на шапке и таббаре.
 *
 * Настоящий эффект (как sssajjad007/react-native-liquid-glass-android):
 * AGSL-рефракция, не градиент и не «блик». Пакет:
 * `react-native-android-liquid-glass`.
 *
 * Expo Go этого native-модуля НЕ содержит. Если импортировать на Go —
 * тот же краш, что был у expo-blur. Поэтому:
 * - в Expo Go / не-Android → полупрозрачный слой БЕЗ градиента и блика
 * - в dev-сборке (`npx expo prebuild && npx expo run:android`) + New Arch
 *   → настоящий Liquid Glass
 *
 * Правило библиотеки: стекло и лента — СИБЛИНГИ одного родителя
 * с collapsable={false}. Поэтому GlassBar сам position:absolute,
 * без обёртки-посредника.
 */
import React from "react";
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Constants from "expo-constants";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { cn } from "@/adapters/cn";

type Dock = "top" | "bottom" | "none";

function isExpoGo(): boolean {
  return (
    Constants.appOwnership === "expo" ||
    Constants.executionEnvironment === "storeClient"
  );
}

/**
 * Native-view грузим только вне Expo Go.
 * require внутри функции: Metro не выполняет модуль, пока мы сами не вызовем.
 */
function loadNativeLiquidGlass(): React.ComponentType<Record<string, unknown>> | null {
  if (isExpoGo()) return null;
  if (Platform.OS !== "android") return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    return require("react-native-android-liquid-glass").LiquidGlassAndroidView;
  } catch {
    return null;
  }
}

const NativeLiquidGlass = loadNativeLiquidGlass();

export default function GlassBar({
  children,
  className,
  style,
  edge = "bottom",
  dock = "none",
  safeTop = false,
  safeBottom = false,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
  /** Совместимость: верхняя/нижняя кромка запасного слоя. */
  edge?: "top" | "bottom" | "none";
  /**
   * Приклеить бар к краю экрана (шапка / таббар).
   * Без отдельного wrapper — иначе Liquid Glass не видит ленту.
   */
  dock?: Dock;
  safeTop?: boolean;
  safeBottom?: boolean;
}) {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();

  const dockStyle: ViewStyle | undefined =
    dock === "top"
      ? { position: "absolute", top: 0, left: 0, right: 0, zIndex: 30 }
      : dock === "bottom"
        ? { position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 30 }
        : undefined;

  const pad = {
    paddingTop: safeTop ? insets.top : 0,
    paddingBottom: safeBottom ? Math.max(insets.bottom, 6) : 0,
  };

  const content = <View style={pad}>{children}</View>;

  // Настоящий Liquid Glass: рефракция фона, без градиентов.
  if (NativeLiquidGlass) {
    return (
      <NativeLiquidGlass
        style={[dockStyle, style]}
        cornerRadius={0}
        material={isDark ? "regular" : "thin"}
        enableDynamicBackground
        refractionHeight={48}
      >
        {content}
      </NativeLiquidGlass>
    );
  }

  // Expo Go: тот же контракт (absolute sibling), без шейдера.
  // Никаких градиентов и бликов — только scrim, как fallback у библиотеки.
  const scrim = isDark ? "rgba(10, 10, 12, 0.55)" : "rgba(255, 255, 255, 0.52)";
  const hair =
    edge === "none"
      ? 0
      : StyleSheet.hairlineWidth;

  return (
    <View
      className={cn(className)}
      style={[
        dockStyle,
        {
          backgroundColor: scrim,
          borderColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)",
          borderTopWidth: edge === "top" ? hair : 0,
          borderBottomWidth: edge === "bottom" ? hair : 0,
        },
        style,
      ]}
    >
      {content}
    </View>
  );
}
