/**
 * GlassBar — стеклянная шапка и таббар.
 *
 * Реализация: официальный `expo-blur` (BlurView).
 * - iOS: UIVisualEffectView, настоящий системный материал.
 * - Android: `blurMethod="dimezisBlurView"` + `blurTarget` (см. glass_target).
 *   Работает только в собранном приложении/дев-клиенте; если цель размытия
 *   ещё не смонтирована, BlurView сам рисует полупрозрачную подложку.
 * - Web: CSS backdrop-filter.
 *
 * Своего нативного модуля больше нет — правим только этот файл.
 */
import React from "react";
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { BlurView, type BlurTint } from "expo-blur";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { useGlassTarget } from "@/shared/ui/layout/glass_target";
import { cn } from "@/adapters/cn";

type Dock = "top" | "bottom" | "none";

function dockStyleOf(dock: Dock): ViewStyle | undefined {
  if (dock === "top") return { position: "absolute", top: 0, left: 0, right: 0, zIndex: 30 };
  if (dock === "bottom") return { position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 30 };
  return undefined;
}

function tintOf(isDark: boolean): BlurTint {
  if (Platform.OS === "ios") {
    return isDark ? "systemChromeMaterialDark" : "systemChromeMaterialLight";
  }
  return isDark ? "dark" : "light";
}

export default function GlassBar({
  children,
  className,
  style,
  edge = "bottom",
  dock = "none",
  safeTop = false,
  safeBottom = false,
  intensity,
}: {
  children?: React.ReactNode;
  className?: string;
  style?: StyleProp<ViewStyle>;
  edge?: "top" | "bottom" | "none";
  dock?: Dock;
  safeTop?: boolean;
  safeBottom?: boolean;
  /** 1–100. По умолчанию 60 — заметное стекло без «молока». */
  intensity?: number;
}) {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const blurTarget = useGlassTarget();

  const dockStyle = dockStyleOf(dock);
  const hair = edge === "none" ? 0 : StyleSheet.hairlineWidth;
  const borderStyle: ViewStyle = {
    borderColor: isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.06)",
    borderTopWidth: edge === "top" ? hair : 0,
    borderBottomWidth: edge === "bottom" ? hair : 0,
  };

  const content = (
    <View
      className={cn(className)}
      style={{
        paddingTop: safeTop ? insets.top : 0,
        paddingBottom: safeBottom ? Math.max(insets.bottom, 6) : 0,
      }}
    >
      {children}
    </View>
  );

  // На Android без цели размытия blurMethod не задаём:
  // BlurView предупреждает в консоли и всё равно падает в "none".
  const blurMethod =
    Platform.OS === "android" ? (blurTarget ? ("dimezisBlurView" as const) : undefined) : undefined;

  return (
    <BlurView
      blurTarget={blurTarget}
      blurMethod={blurMethod}
      intensity={intensity ?? 60}
      tint={tintOf(isDark)}
      style={[dockStyle, borderStyle, style]}
    >
      {content}
    </BlurView>
  );
}
