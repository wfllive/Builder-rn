/**
 * useHolidayDecor
 * Порт web-хука 1:1 — чистая дата, без DOM.
 */
import { useMemo } from "react";

const MONTH = {
  JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4,
  JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11,
};

type Holiday = {
  id: string;
  label?: string;
  check: (date: Date) => boolean;
};

function isMonthInRange(date: Date, start: number, end: number) {
  const month = date.getMonth();
  return start <= end ? month >= start && month <= end : month >= start || month <= end;
}

const holidays: Holiday[] = [
  { id: "winter", check: (d) => isMonthInRange(d, MONTH.DEC, MONTH.FEB) },
  { id: "spring", check: (d) => isMonthInRange(d, MONTH.MAR, MONTH.MAY) },
  { id: "summer", check: (d) => isMonthInRange(d, MONTH.JUN, MONTH.AUG) },
  { id: "autumn", check: (d) => isMonthInRange(d, MONTH.SEP, MONTH.NOV) },
  {
    id: "newYear",
    check: (d) =>
      (d.getMonth() === MONTH.DEC && d.getDate() >= 1) || d.getMonth() === MONTH.JAN,
  },
];

/**
 * Возвращает id активных праздников/сезонов на дату.
 */
export function useHolidayDecor(date: Date = new Date(), extraHolidays: Holiday[] = []): string[] {
  return useMemo(
    () => [...holidays, ...extraHolidays].filter((h) => h.check(date)).map((h) => h.id),
    [date, extraHolidays]
  );
}
