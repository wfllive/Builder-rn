/**
 * TObjectTo3d
 * ---------------------------------------------------------------
 * На вебе — CSS 3D-трансформация объекта.
 * На native полноценный 3D в shared не тащим (это app-слой / reanimated).
 * Компонент сохранён как прозрачная обёртка, чтобы импорты не ломались.
 */
import React from "react";
import { View } from "react-native";

export default function TObjectTo3d({ children }: { children?: React.ReactNode }) {
  return <View>{children}</View>;
}
