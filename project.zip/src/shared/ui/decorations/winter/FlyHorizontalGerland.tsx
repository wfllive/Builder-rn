/**
 * FlyHorizontalGerland — новогодняя гирлянда.
 * На native — ряд цветных «лампочек» без SVG-нити (производительность списков).
 */
import React from "react";
import { View } from "react-native";
import { lightTokens } from "@/theme/tokens";

const COLORS = [
  lightTokens.warning,
  lightTokens.orange,
  lightTokens.red,
  lightTokens.lightRed,
  lightTokens.primary,
  lightTokens.seaBreeze,
];

export default function FlyHorizontalGerland({ count = 12 }: { count?: number }) {
  return (
    <View className="flex-row items-center justify-between px-2 py-1">
      {Array.from({ length: count }).map((_, i) => (
        <View
          key={i}
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: COLORS[i % COLORS.length], opacity: 0.85 }}
        />
      ))}
    </View>
  );
}
