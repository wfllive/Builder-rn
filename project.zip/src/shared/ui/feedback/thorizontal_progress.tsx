/**
 * THorizontalProgress — горизонтальный прогресс-бар.
 * Порт web-компонента, API сохранён.
 */
import React, { useEffect, useState } from "react";
import { Text, View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";

type Size = "xs" | "sm" | "lg" | "xl";
type Type = "primary" | "warning" | "error" | "success";

export interface THorizontalProgressProps {
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  title?: string;
  value: number;
  max?: number;
  type?: Type;
  size?: Size;
  showPercent?: boolean;
  className?: string;
  style?: StyleProp<ViewStyle>;
}

const sizeMap: Record<Size, string> = {
  xs: "h-2",
  sm: "h-3",
  lg: "h-5",
  xl: "h-7",
};

const typeColor: Record<Type, string> = {
  primary: "bg-primary",
  warning: "bg-warning",
  error: "bg-danger",
  success: "bg-success",
};

const typeBg: Record<Type, string> = {
  primary: "bg-primary/10",
  warning: "bg-warning/10",
  error: "bg-danger/10",
  success: "bg-success/10",
};

const THorizontalProgress: React.FC<THorizontalProgressProps> = ({
  prefix,
  suffix,
  title,
  value,
  max = 100,
  type = "primary",
  size = "sm",
  showPercent = true,
  className = "",
  style,
}) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    setProgress(Math.min(Math.max(0, value), max));
  }, [value, max]);

  const percent = (progress / max) * 100;

  return (
    <View className={cn("flex-col", className)} style={style}>
      <View className="flex-row justify-between items-center mb-1">
        {title ? (
          <Text className="text-sm font-semibold text-ink">{title}</Text>
        ) : (
          <View />
        )}
        <Text className="text-sm text-ink">
          {showPercent ? `${Math.round(percent)}%` : `${Math.round(progress)} из ${max}`}
        </Text>
      </View>

      <View className="flex-row items-center gap-2">
        {prefix}
        <View className={cn("flex-1 rounded-full overflow-hidden", sizeMap[size], typeBg[type])}>
          <View className={cn("h-full", typeColor[type])} style={{ width: `${percent}%` }} />
        </View>
        {suffix}
      </View>
    </View>
  );
};

export default THorizontalProgress;
