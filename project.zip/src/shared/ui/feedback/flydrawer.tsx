/**
 * FlyDrawer — левая шторка со списком.
 * Фон и текст из темы: иначе в dark Android рисует белые буквы на белом.
 */
import React, { useEffect, useRef } from "react";
import { Animated, Dimensions, Modal, Pressable, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import { cn } from "@/adapters/cn";

export interface FlyDrawerProps {
  open: boolean;
  onClose?: () => void;
  side?: "left" | "right";
  children?: React.ReactNode;
  className?: string;
}

const FlyDrawer: React.FC<FlyDrawerProps> = ({
  open,
  onClose,
  side = "left",
  children,
  className,
}) => {
  const { isDark } = useAppTheme();
  const insets = useSafeAreaInsets();
  const width = Math.min(320, Math.round(Dimensions.get("window").width * 0.82));
  const translateX = useRef(new Animated.Value(side === "left" ? -width : width)).current;

  useEffect(() => {
    Animated.spring(translateX, {
      toValue: open ? 0 : side === "left" ? -width : width,
      useNativeDriver: true,
      damping: 22,
      stiffness: 180,
    }).start();
  }, [open, side, translateX, width]);

  if (!open) return null;

  const panel = (
    <Animated.View
      className={cn("h-full", className)}
      style={{
        width,
        transform: [{ translateX }],
        backgroundColor: resolveToken(isDark, "modal"),
        paddingTop: insets.top + 8,
        paddingBottom: insets.bottom + 8,
      }}
    >
      {children}
    </Animated.View>
  );

  return (
    <Modal transparent visible={open} animationType="fade" onRequestClose={onClose}>
      <View className="flex-1 flex-row">
        {side === "right" ? <Pressable className="flex-1 bg-black/45" onPress={onClose} /> : null}
        {panel}
        {side === "left" ? <Pressable className="flex-1 bg-black/45" onPress={onClose} /> : null}
      </View>
    </Modal>
  );
};

export default FlyDrawer;
