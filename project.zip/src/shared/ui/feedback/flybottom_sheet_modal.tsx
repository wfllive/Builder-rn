/**
 * FlyBottomSheetModal
 * ---------------------------------------------------------------
 * Порт web-шторки. createPortal / pointer events заменены на RN Modal
 * + PanResponder (свайп вниз закрывает).
 */
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Modal,
  PanResponder,
  Pressable,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import TButton from "../buttons/tbutton";
import TCircleProgress from "./tcircle_progress";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export interface FlyBottomSheetModalProps {
  open: boolean;
  closable?: boolean;
  closeIcon?: React.ReactNode;
  centerIcon?: React.ReactNode;
  title?: React.ReactNode;
  message?: React.ReactNode;
  actions?: React.ReactNode | React.ReactNode[] | null;
  isLoading?: boolean;
  onCancel?: () => void;
  onSuccess?: () => void;
  className?: string;
  /** Игнорируется на native: шторка всегда на всю ширину с боковыми отступами */
  maxWidth?: string;
  children?: React.ReactNode;
}

const FlyBottomSheetModal: React.FC<FlyBottomSheetModalProps> = ({
  open,
  closable = true,
  closeIcon,
  centerIcon,
  title,
  message,
  actions,
  isLoading = false,
  onCancel,
  onSuccess,
  className = "",
  children,
}) => {
  const insets = useSafeAreaInsets();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const modalBg = resolveToken(isDark, "modal");
  const [visible, setVisible] = useState(open);
  const translateY = useRef(new Animated.Value(400)).current;

  useEffect(() => {
    if (open) {
      setVisible(true);
      Animated.spring(translateY, {
        toValue: 0,
        useNativeDriver: true,
        damping: 22,
        stiffness: 180,
      }).start();
    } else {
      Animated.timing(translateY, {
        toValue: 400,
        duration: 220,
        useNativeDriver: true,
      }).start(() => setVisible(false));
    }
  }, [open, translateY]);

  const pan = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => closable && g.dy > 6,
      onPanResponderMove: (_, g) => {
        if (g.dy > 0) translateY.setValue(g.dy);
      },
      onPanResponderRelease: (_, g) => {
        if (g.dy > 120 || g.vy > 1.1) {
          onCancel?.();
        } else {
          Animated.spring(translateY, {
            toValue: 0,
            useNativeDriver: true,
          }).start();
        }
      },
    })
  ).current;

  if (!visible) return null;

  return (
    <Modal transparent visible={visible} animationType="none" onRequestClose={onCancel}>
      <View className="flex-1 justify-end">
        <Pressable
          className="absolute inset-0 bg-black/50"
          onPress={() => closable && onCancel?.()}
        />

        <Animated.View
          className={cn("mx-3 mb-3 rounded-2xl overflow-hidden", className)}
          style={{
            transform: [{ translateY }],
            paddingBottom: insets.bottom + 8,
            backgroundColor: modalBg,
          }}
        >
          <View className="items-center pt-3 pb-2" {...pan.panHandlers}>
            <View className="w-12 h-1 rounded-full bg-placeholder" />
            {closeIcon ? <View className="mt-2">{closeIcon}</View> : null}
          </View>

          <View className="px-6 pb-6">
            {isLoading ? (
              <View className="h-[280px] items-center justify-center">
                <TCircleProgress indeterminateOnly size={60} strokeWidth={6} type="primary" />
              </View>
            ) : (
              <>
                {centerIcon ? (
                  <View className="items-center mb-4">{centerIcon}</View>
                ) : null}

                {title ? (
                  typeof title === "string" ? (
                    <Text className="text-ink text-center text-lg font-semibold mb-2">
                      {title}
                    </Text>
                  ) : (
                    title
                  )
                ) : null}

                {message ? (
                  typeof message === "string" ? (
                    <Text className="text-center text-sm opacity-80" style={{ color: ink }}>
                      {message}
                    </Text>
                  ) : (
                    message
                  )
                ) : null}

                {children}

                {actions !== null && (
                  <View className="mt-6">
                    {actions === undefined ? (
                      <View className="flex-row gap-3">
                        <View className="flex-1">
                          <TButton.Outline onPress={onCancel}>Отмена</TButton.Outline>
                        </View>
                        <View className="flex-1">
                          <TButton.Filled onPress={onSuccess}>Ок</TButton.Filled>
                        </View>
                      </View>
                    ) : Array.isArray(actions) ? (
                      <View className="flex-row gap-3 justify-center">{actions}</View>
                    ) : (
                      <View className="items-center">{actions}</View>
                    )}
                  </View>
                )}
              </>
            )}
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
};

export default FlyBottomSheetModal;
