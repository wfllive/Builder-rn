/**
 * TFullModalViewer — полноэкранная модалка (просмотр медиа / детали).
 */
import React from "react";
import { Modal, Pressable, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Close } from "../icons/mingcute/system/close_line";
import { lightTokens } from "@/theme/tokens";

export interface TFullModalViewerProps {
  open: boolean;
  onClose?: () => void;
  children?: React.ReactNode;
}

const TFullModalViewer: React.FC<TFullModalViewerProps> = ({
  open,
  onClose,
  children,
}) => {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={open} animationType="slide" onRequestClose={onClose}>
      <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
        <Pressable onPress={onClose} className="absolute right-4 top-12 z-10 p-2">
          <Close size={24} color={lightTokens.text} />
        </Pressable>
        {children}
      </View>
    </Modal>
  );
};

export default TFullModalViewer;
