/**
 * TSkeleton — скелетон загрузки (block / button / input / avatar).
 * Web-shimmer через CSS keyframes заменён на  NativeWind.
 */
import React from "react";
import { View } from "react-native";
import { cn } from "@/adapters/cn";

type SkeletonSize = "xs" | "sm" | "lg" | "xl";
type SkeletonShape = "block" | "button" | "input" | "avatar";

export interface TSkeletonProps {
  size?: SkeletonSize;
  shape?: SkeletonShape;
  className?: string;
  children?: React.ReactNode;
}

const sizeClasses: Record<SkeletonSize, string> = {
  xs: "w-4 h-4",
  sm: "w-6 h-6",
  lg: "w-10 h-10",
  xl: "w-16 h-16",
};

const shapeClasses: Record<SkeletonShape, string> = {
  block: "rounded-md",
  button: "rounded-lg",
  input: "rounded-md",
  avatar: "rounded-full",
};

const TSkeleton: React.FC<TSkeletonProps> = ({
  size = "sm",
  shape = "block",
  className = "",
  children,
}) => {
  return (
    <View
      className={cn(
        "overflow-hidden bg-input ",
        sizeClasses[size],
        shapeClasses[shape],
        className
      )}
    >
      {shape === "block" ? children : null}
    </View>
  );
};

export default TSkeleton;
