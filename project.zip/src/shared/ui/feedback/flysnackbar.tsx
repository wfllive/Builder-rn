/**
 * FlySnackbar — тост снизу.
 * Таймер не зависит от remaining/onClose: иначе Expo ловит
 * «Maximum update depth» (onClose внутри setState + effect).
 */
import React, { useEffect, useRef, useState } from "react";
import { Animated, Text, View } from "react-native";
import TCircleProgress from "./tcircle_progress";
import TButton from "../buttons/tbutton";
import { Close } from "../icons/mingcute/system/close_line";
import { cn } from "@/adapters/cn";
import { lightTokens, resolveToken } from "@/theme/tokens";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";

export type FlySnackbarPosition =
  | "bottomCenter"
  | "bottomLeft"
  | "bottomRight"
  | "topLeft"
  | "topRight"
  | "topCenter";

export type FlySnackbarSize = "xs" | "sm" | "lg" | "xl";

export interface FlySnackbarProps {
  open: boolean;
  backgroundColor?: string;
  timeSeconds?: number;
  closable?: boolean;
  title?: string;
  message: string;
  size?: FlySnackbarSize;
  position?: FlySnackbarPosition;
  icon?: React.ReactNode;
  onClose?: () => void;
  className?: string;
}

const SIZE_MAP: Record<FlySnackbarSize, string> = {
  xs: "py-2 px-3",
  sm: "py-3 px-4",
  lg: "py-4 px-5",
  xl: "py-5 px-6",
};

export default function FlySnackbar({
  open,
  timeSeconds,
  closable = true,
  title,
  message,
  size = "sm",
  position = "bottomCenter",
  icon,
  onClose,
  className = "",
}: FlySnackbarProps) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const [visible, setVisible] = useState(false);
  const opacity = useRef(new Animated.Value(0)).current;
  const [remaining, setRemaining] = useState<number | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (open) {
      setVisible(true);
      setRemaining(typeof timeSeconds === "number" ? timeSeconds : null);
      Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }).start();
      return;
    }
    Animated.timing(opacity, { toValue: 0, duration: 180, useNativeDriver: true }).start(() => {
      setVisible(false);
    });
  }, [open, opacity, timeSeconds]);

  useEffect(() => {
    if (!open || typeof timeSeconds !== "number") return;
    const startedAt = Date.now();
    const totalMs = timeSeconds * 1000;
    const id = setInterval(() => {
      const left = Math.max(0, totalMs - (Date.now() - startedAt));
      setRemaining(left / 1000);
      if (left <= 0) {
        clearInterval(id);
        onCloseRef.current?.();
      }
    }, 120);
    return () => clearInterval(id);
  }, [open, timeSeconds]);

  if (!visible && !open) return null;

  const isTop = position.startsWith("top");
  const progress =
    typeof timeSeconds === "number" && remaining != null
      ? Math.max(0, Math.min(1, remaining / timeSeconds))
      : null;

  return (
    <Animated.View
      className={cn("absolute left-4 right-4 z-50", isTop ? "top-10" : "bottom-24")}
      style={{ opacity }}
      pointerEvents="box-none"
    >
      <View
        className={cn(
          "flex-row items-center rounded-2xl bg-primary/15 border border-primary/20",
          SIZE_MAP[size],
          className
        )}
      >
        {icon ? <View className="mr-3">{icon}</View> : null}
        <View className="flex-1">
          {title ? (
            <Text className="font-semibold" style={{ color: ink }}>
              {title}
            </Text>
          ) : null}
          <Text className="text-sm opacity-80" style={{ color: ink }}>
            {message}
          </Text>
        </View>
        {progress !== null ? (
          <View className="ml-3">
            <TCircleProgress
              progress={Math.round(progress * 100)}
              size={28}
              strokeWidth={3}
              colorProgress={lightTokens.primary}
            />
          </View>
        ) : closable ? (
          <TButton.Text onPress={() => onCloseRef.current?.()} className="ml-2">
            <Close size={18} />
          </TButton.Text>
        ) : null}
      </View>
    </Animated.View>
  );
}
