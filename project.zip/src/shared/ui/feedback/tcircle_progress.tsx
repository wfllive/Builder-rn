import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

interface TCircleProgressProps {
  /** Текущий прогресс (0 - max). Игнорируется, если indeterminateOnly=true */
  progress?: number;
  /** Максимальное значение прогресса. По умолчанию 100 */
  max?: number;
  /** Режим индетерминированного прогресса */
  indeterminateOnly?: boolean;
  /** Цветовая тема */
  type?: 'default' | 'primary' | 'danger';
  /** Пользовательский цвет прогресса */
  colorProgress?: string;
  /** Пользовательский цвет фона */
  colorBackground?: string;
  /** Диаметр кружка в пикселях */
  size?: number;
  /** Толщина линии круга */
  strokeWidth?: number;
  /** Синтаксический сахар для strokeWidth */
  strokeSize?: number;
}

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

const TCircleProgress: React.FC<TCircleProgressProps> = ({
  progress = 0,
  max = 100,
  indeterminateOnly = false,
  type = 'default',
  colorProgress,
  colorBackground,
  size = 50,
  strokeWidth = 6,
  strokeSize,
}) => {
  const stroke = strokeSize || strokeWidth;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;

  const rotateAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  // Цвета
  const progressColor =
    colorProgress ||
    (type === 'default'
      ? '#ffffff'
      : type === 'primary'
      ? '#5F18DA'
      : '#de5567');

  const backgroundColor =
    colorBackground ||
    (type === 'default'
      ? '#C8C8C8'
      : type === 'primary'
      ? 'rgba(95, 24, 218, 0.1)'
      : 'rgba(222, 85, 103, 0.1)');

  // Анимация вращения для indeterminate
  useEffect(() => {
    if (indeterminateOnly) {
      const rotation = Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 1000,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      rotation.start();
      return () => rotation.stop();
    }
  }, [indeterminateOnly, rotateAnim]);

  // Анимация прогресса
  useEffect(() => {
    if (!indeterminateOnly) {
      Animated.timing(progressAnim, {
        toValue: progress,
        duration: 500,
        easing: Easing.out(Easing.ease),
        useNativeDriver: false,
      }).start();
    }
  }, [progress, indeterminateOnly, progressAnim]);

  const rotation = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const strokeDashoffset = indeterminateOnly
    ? circumference * 0.8
    : progressAnim.interpolate({
        inputRange: [0, max],
        outputRange: [circumference, 0],
      });

  return (
    <Animated.View
      style={[
        { width: size, height: size },
        indeterminateOnly && { transform: [{ rotate: rotation }] },
      ]}
    >
      <Svg width={size} height={size}>
        {/* Фоновый круг */}
        <Circle
          stroke={backgroundColor}
          fill="transparent"
          strokeWidth={stroke}
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        {/* Круг прогресса */}
        <AnimatedCircle
          stroke={progressColor}
          fill="transparent"
          strokeWidth={stroke}
          strokeLinecap="round"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          rotation={-90}
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
    </Animated.View>
  );
};

export default TCircleProgress;