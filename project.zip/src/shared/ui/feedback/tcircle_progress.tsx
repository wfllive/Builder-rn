/**
 * TCircleProgress
 * ---------------------------------------------------------------
 * Порт web-компонента: круговой прогресс / indeterminate-спиннер.
 * SVG заменён на react-native-svg. API пропсов сохранён 1:1.
 */
import React, { useEffect, useRef } from "react";
import { Animated, Easing, View } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { lightTokens } from "@/theme/tokens";

export interface TCircleProgressProps {
  /** Текущий прогресс (0 - max). Игнорируется, если indeterminateOnly=true */
  progress?: number;
  /** Максимальное значение. По умолчанию 100 */
  max?: number;
  /** Режим спиннера: progress игнорируется, крутится сегмент ~20% */
  indeterminateOnly?: boolean;
  /** Цветовая тема кружка */
  type?: "default" | "primary" | "danger";
  /** Пользовательский цвет прогресса. Перекрывает type */
  colorProgress?: string;
  /** Пользовательский цвет фона. Перекрывает type */
  colorBackground?: string;
  /** Диаметр в пикселях. По умолчанию 50 */
  size?: number;
  /** Толщина линии. По умолчанию 6 */
  strokeWidth?: number;
  /** Синтаксический сахар для strokeWidth */
  strokeSize?: number;
}

const AnimatedView = Animated.View;

const TCircleProgress: React.FC<TCircleProgressProps> = ({
  progress = 0,
  max = 100,
  indeterminateOnly = false,
  type = "default",
  colorProgress,
  colorBackground,
  size = 50,
  strokeWidth = 6,
  strokeSize,
}) => {
  const stroke = strokeSize || strokeWidth;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;

  const progressColor =
    colorProgress ||
    (type === "default"
      ? lightTokens.white
      : type === "primary"
        ? lightTokens.primary
        : lightTokens.red);

  const backgroundColor =
    colorBackground ||
    (type === "default"
      ? lightTokens.placeholder
      : type === "primary"
        ? "rgba(95, 24, 218, 0.12)"
        : "rgba(222, 85, 103, 0.12)");

  const offset = indeterminateOnly
    ? circumference * 0.8
    : ((max - progress) / max) * circumference;

  const spin = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!indeterminateOnly) {
      spin.stopAnimation();
      return;
    }
    const loop = Animated.loop(
      Animated.timing(spin, {
        toValue: 1,
        duration: 900,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [indeterminateOnly, spin]);

  const rotate = spin.interpolate({
    inputRange: [0, 1],
    outputRange: ["-90deg", "270deg"],
  });

  return (
    <AnimatedView
      style={{
        width: size,
        height: size,
        transform: indeterminateOnly ? [{ rotate }] : [{ rotate: "-90deg" }],
      }}
    >
      <View>
        <Svg width={size} height={size}>
          <Circle
            stroke={backgroundColor}
            fill="transparent"
            strokeWidth={stroke}
            r={radius}
            cx={size / 2}
            cy={size / 2}
          />
          <Circle
            stroke={progressColor}
            fill="transparent"
            strokeWidth={stroke}
            strokeLinecap="round"
            r={radius}
            cx={size / 2}
            cy={size / 2}
            strokeDasharray={`${circumference} ${circumference}`}
            strokeDashoffset={offset}
          />
        </Svg>
      </View>
    </AnimatedView>
  );
};

export default TCircleProgress;
