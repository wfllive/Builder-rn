/**
 * FlyStatusView — пустое / ошибочное / загрузочное состояние экрана.
 */
import React from "react";
import { Text, View } from "react-native";
import TCircleProgress from "./tcircle_progress";
import { cn } from "@/adapters/cn";

export interface FlyStatusViewProps {
  status?: "loading" | "empty" | "error";
  title?: string;
  message?: string;
  icon?: React.ReactNode;
  className?: string;
}

const FlyStatusView: React.FC<FlyStatusViewProps> = ({
  status = "empty",
  title,
  message,
  icon,
  className,
}) => {
  return (
    <View className={cn("items-center justify-center py-10 px-6", className)}>
      {status === "loading" ? (
        <TCircleProgress indeterminateOnly type="primary" size={42} />
      ) : (
        icon
      )}
      {title ? (
        <Text className="mt-4 text-base font-semibold text-ink text-center">
          {title}
        </Text>
      ) : null}
      {message ? (
        <Text className="mt-1 text-sm text-muted text-center">
          {message}
        </Text>
      ) : null}
    </View>
  );
};

export default FlyStatusView;
