/**
 * Типы SVG-иконок (порт web `shared/ui/icons/types.ts`).
 *
 * На вебе это были SVGProps<SVGSVGElement>.
 * В RN иконка рисуется через react-native-svg, поэтому
 * оставляем только те пропсы, которые реально нужны UI-киту.
 */
import type { StyleProp, ViewStyle } from "react-native";

export type SvgIconProps = {
  /** Цвет заливки/обводки path (прокидывается в render). */
  color?: string;
  /** true — filled-вариант MingCute, false — outline. */
  filled?: boolean;
  /** Квадратный размер. Если задан — перекрывает width/height. */
  size?: number;
  /** Ширина viewBox-контейнера. */
  width?: number;
  /** Высота viewBox-контейнера. */
  height?: number;
  /** Доп. стиль обёртки. */
  style?: StyleProp<ViewStyle>;
  /** Тестовый идентификатор (Detox / Maestro). */
  testID?: string;
};
