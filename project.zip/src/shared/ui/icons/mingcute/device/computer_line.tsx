/**
 * SVG-иконка MingCute, порт web → React Native (react-native-svg).
 * Не редактировать руками: пересобрать через scripts/convert_icons.mjs
 */
import * as React from "react";
import { G, Path, Circle, Rect, Line, Polyline, Polygon, Defs, ClipPath, Mask } from "react-native-svg";
import { createSvgIcon } from "@/shared/ui/icons/create_svg_icon";

const render = ({ filled, color }: { filled: boolean; color?: string }) =>
  !filled ? (
    <G id="computer_line" fill="none" fillRule="evenodd">
      <Path d="M24 0v24H0V0zM12.593 23.258l-.011.002-.071.035-.02.004-.014-.004-.071-.035q-.016-.005-.024.005l-.004.01-.017.428.005.02.01.013.104.074.015.004.012-.004.104-.074.012-.016.004-.017-.017-.427q-.004-.016-.017-.018m.265-.113-.013.002-.185.093-.01.01-.003.011.018.43.005.012.008.007.201.093q.019.005.029-.008l.004-.014-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014-.034.614q.001.018.017.024l.015-.002.201-.093.01-.008.004-.011.017-.43-.003-.012-.01-.01z"></Path>
      <Path
        fill={color}
        fillRule="nonzero"
        d="M19 3a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-4v1h1a1 1 0 1 1 0 2H8a1 1 0 1 1 0-2h1v-1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm-6 15h-2v1h2zm6-13H5v11h14z"
      ></Path>
    </G>
  ) : (
    <G id="computer_fill" fill="none" fillRule="evenodd">
      <Path d="M24 0v24H0V0zM12.593 23.258l-.011.002-.071.035-.02.004-.014-.004-.071-.035q-.016-.005-.024.005l-.004.01-.017.428.005.02.01.013.104.074.015.004.012-.004.104-.074.012-.016.004-.017-.017-.427q-.004-.016-.017-.018m.265-.113-.013.002-.185.093-.01.01-.003.011.018.43.005.012.008.007.201.093q.019.005.029-.008l.004-.014-.034-.614q-.005-.018-.02-.022m-.715.002a.02.02 0 0 0-.027.006l-.006.014-.034.614q.001.018.017.024l.015-.002.201-.093.01-.008.004-.011.017-.43-.003-.012-.01-.01z"></Path>
      <Path
        fill={color}
        d="M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-4v1h1a1 1 0 1 1 0 2H8a1 1 0 1 1 0-2h1v-1H5a2 2 0 0 1-2-2zm10 14v-1h-2v1z"
      ></Path>
    </G>
  );

export const Computer = createSvgIcon("Computer", render);
