/**
 * Фабрика SVG-иконок для React Native.
 *
 * Порт web `create_svg_icon.tsx`:
 * - web: <svg> + children
 * - native: <Svg> из react-native-svg
 *
 * Сами path-файлы (mingcute/*) почти не меняются:
 * конвертер заменяет <g>/<path> на <G>/<Path>.
 */
import * as React from "react";
import Svg from "react-native-svg";
import type { SvgIconProps } from "@/shared/ui/icons/types";
import { lightTokens } from "@/theme/tokens";

type RenderFn = (opts: { filled: boolean; color?: string }) => React.ReactNode;

/**
 * Создаёт мемоизированный компонент иконки.
 *
 * @param displayName — имя для DevTools (Home4, Close, ...)
 * @param render — функция, возвращающая G/Path в зависимости от filled
 */
export function createSvgIcon(displayName: string, render: RenderFn) {
  const Component = React.forwardRef<React.ComponentRef<typeof Svg>, SvgIconProps>(
    (
      {
        size,
        width = size ?? 24,
        height = size ?? 24,
        color = lightTokens.text,
        filled = false,
        style,
        testID,
      },
      ref
    ) => {
      return (
        <Svg
          ref={ref}
          width={width}
          height={height}
          viewBox="0 0 24 24"
          style={style}
          testID={testID}
        >
          {render({ filled, color })}
        </Svg>
      );
    }
  );

  Component.displayName = displayName;
  return React.memo(Component);
}
