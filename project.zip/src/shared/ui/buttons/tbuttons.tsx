"use client";

import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  View, 
  Image,
  ActivityIndicator,
  TouchableOpacityProps,
  ImageSourcePropType,
  Animated,
  Pressable
} from 'react-native';
import TCircleProgress from '../feedback/tcircle_progress';

/**
 * Варианты отображения кнопки
 */
type ButtonVariant =
  | 'solid'
  | 'outline'
  | 'dashed'
  | 'filled'
  | 'text'
  | 'link'
  | 'danger'
  | 'ghost';

/**
 * Возможные эффекты при наведении/нажатии
 */
type PressEffect = 'brightness' | 'scale-up' | 'scale-down';

/**
 * Допустимые размеры кнопки
 */
type ButtonSize = 'xs' | 'sm' | 'lg' | 'xl';

/**
 * Базовые пропсы кнопки
 */
export interface TButtonProps extends Omit<TouchableOpacityProps, 'children'> {
  /** Размер кнопки */
  size?: ButtonSize;
  /** Закругление кнопки в пикселях */
  radius?: number;
  /** Вариант внешнего вида */
  variant?: ButtonVariant;
  /** Показывать индикатор загрузки */
  isLoading?: boolean;
  /** Эффект при нажатии */
  pressEffect?: PressEffect;
  /** Дополнительные классы NativeWind */
  className?: string;
  /** Иконка слева */
  leftIcon?: React.ReactNode;
  /** Иконка справа */
  rightIcon?: React.ReactNode;
  /** Кастомный цвет текста */
  textColor?: string;
  /** Содержимое кнопки (текст или компоненты) */
  children?: React.ReactNode;
  /** Выравнивание контента */
  contentAlign?: 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly';
  /** Центральное изображение */
  centerImage?: React.ReactNode | { source: ImageSourcePropType; width?: number; height?: number };
  /** Показывать точку уведомления */
  indicatorNotification?: boolean;
  /** Число уведомлений */
  countNotification?: number;
  /** Текст кнопки (альтернатива children для простого текста) */
  title?: string;
}

/**
 * Маппинг размеров
 */
const sizeStyles: Record<ButtonSize, string> = {
  xs: 'text-xs px-1 py-1',
  sm: 'text-sm px-4 py-2.5',
  lg: 'text-lg px-6 py-3',
  xl: 'text-xl px-8 py-4',
};

const squareSizeStyles: Record<ButtonSize, string> = {
  xs: 'w-6 h-6',
  sm: 'w-9 h-9',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
};

const textSizeStyles: Record<ButtonSize, string> = {
  xs: 'text-xs',
  sm: 'text-sm',
  lg: 'text-lg',
  xl: 'text-xl',
};

/**
 * Маппинг вариантов - используем CSS переменные через NativeWind
 */
const variantStyles: Record<ButtonVariant, { container: string; text: string }> = {
  solid: {
    container: 'bg-[#5F18DA] border border-transparent',
    text: 'text-white',
  },
  outline: {
    container: 'border-2 border-[#5F18DA]/30 bg-transparent',
    text: 'text-[#5F18DA]/70',
  },
  dashed: {
    container: 'border border-dashed border-[#5F18DA] bg-transparent',
    text: 'text-[#5F18DA]',
  },
  filled: {
    container: 'bg-[#5F18DA]/10 border border-transparent',
    text: 'text-[#5F18DA]',
  },
  text: {
    container: 'p-1 px-2 bg-transparent',
    text: 'text-black dark:text-[#F3F5F7]',
  },
  link: {
    container: 'p-0 bg-transparent',
    text: 'text-[#5F18DA]',
  },
  danger: {
    container: 'bg-[#de5567]/30 border border-transparent',
    text: 'text-[#de5567]',
  },
  ghost: {
    container: 'bg-transparent border border-transparent',
    text: 'text-black dark:text-[#F3F5F7]',
  },
};

const contentAlignStyles: Record<string, string> = {
  start: 'justify-start',
  center: 'justify-center',
  end: 'justify-end',
  between: 'justify-between',
  around: 'justify-around',
  evenly: 'justify-evenly',
};

/**
 * Компонент TButton для React Native с NativeWind
 */
const TButton: React.FC<TButtonProps> & {
  Solid: React.FC<TButtonProps>;
  Outline: React.FC<TButtonProps>;
  Dashed: React.FC<TButtonProps>;
  Filled: React.FC<TButtonProps>;
  Text: React.FC<TButtonProps>;
  Link: React.FC<TButtonProps>;
  Danger: React.FC<TButtonProps>;
  Ghost: React.FC<TButtonProps>;
} = ({
  size = 'sm',
  variant = 'solid',
  isLoading = false,
  pressEffect = 'scale-down',
  className = '',
  leftIcon,
  rightIcon,
  textColor,
  children,
  centerImage,
  contentAlign = 'center',
  indicatorNotification = false,
  countNotification = 0,
  radius = 12,
  title,
  disabled,
  style,
  ...restProps
}) => {
  const scaleAnim = React.useRef(new Animated.Value(1)).current;

  // Определяем, является ли кнопка icon-only
  const hasChildren = React.Children.count(children) > 0 || !!title;
  const isIconOnlyCenter =
    (variant === 'text' || variant === 'filled') &&
    !!centerImage &&
    !hasChildren &&
    !leftIcon &&
    !rightIcon;

  // Получаем стили
  const variantStyle = variantStyles[variant];
  const actualSizeStyle = isIconOnlyCenter ? squareSizeStyles[size] : sizeStyles[size];
  const alignStyle = contentAlignStyles[contentAlign];

  // Анимации нажатия
  const handlePressIn = () => {
    if (pressEffect === 'scale-down') {
      Animated.spring(scaleAnim, {
        toValue: 0.98,
        useNativeDriver: true,
      }).start();
    } else if (pressEffect === 'scale-up') {
      Animated.spring(scaleAnim, {
        toValue: 1.05,
        useNativeDriver: true,
      }).start();
    }
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };

  // Проверка объекта изображения
  const isCenterImageObject = (x: unknown): x is { source: ImageSourcePropType; width?: number; height?: number } =>
    !!x && typeof x === 'object' && 'source' in x;

  // Рендер содержимого
  const renderContent = () => (
    <View className={`relative flex-row items-center ${alignStyle} w-full h-full`}>
      {/* Индикатор уведомления */}
      {indicatorNotification && (
        <View className="absolute -top-1 -right-1 z-10">
          {countNotification ? (
            <View className="bg-[#de5567] rounded-full min-w-[16px] h-4 px-1 items-center justify-center">
              <Text className="text-[10px] text-white font-medium">
                {countNotification > 99 ? '99+' : countNotification}
              </Text>
            </View>
          ) : (
            <View className="w-2 h-2 bg-[#de5567] rounded-full" />
          )}
        </View>
      )}

      {/* Основной контент */}
      <View className={`flex-row items-center justify-center ${isLoading ? 'opacity-40' : 'opacity-100'}`}>
        {leftIcon && (
          <View className="mr-2 items-center justify-center">
            {leftIcon}
          </View>
        )}
        
        {typeof children === 'string' || title ? (
          <Text 
            className={`${variantStyle.text} ${textSizeStyles[size]} font-sans`}
            style={textColor ? { color: textColor } : undefined}
          >
            {title || children}
          </Text>
        ) : (
          children
        )}
        
        {rightIcon && (
          <View className="ml-2 items-center justify-center">
            {rightIcon}
          </View>
        )}
      </View>

      {/* Центральное изображение */}
      {centerImage && (
        <View 
          className={`absolute inset-0 items-center justify-center ${isLoading ? 'opacity-40' : ''}`}
          pointerEvents="none"
        >
          {isCenterImageObject(centerImage) ? (
            <Image
              source={centerImage.source}
              style={{
                width: centerImage.width ?? 32,
                height: centerImage.height ?? 32,
              }}
              resizeMode="contain"
            />
          ) : (
            centerImage
          )}
        </View>
      )}

      {/* Индикатор загрузки */}
      {isLoading && (
        <View className="absolute inset-0 items-center justify-center">
          <TCircleProgress
            indeterminateOnly
            colorProgress="#5F18DA"
            size={20}
            strokeWidth={3}
          />
        </View>
      )}
    </View>
  );

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <TouchableOpacity
        activeOpacity={pressEffect === 'brightness' ? 0.7 : 1}
        disabled={isLoading || disabled}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        className={`
          flex-row items-center
          ${variantStyle.container}
          ${actualSizeStyle}
          ${disabled || isLoading ? 'opacity-60' : ''}
          ${className}
        `}
        style={[
          { borderRadius: radius },
          style,
        ]}
        {...restProps}
      >
        {renderContent()}
      </TouchableOpacity>
    </Animated.View>
  );
};

// Подкомпоненты
const makeVariant = (variant: ButtonVariant): React.FC<TButtonProps> => {
  const VariantComponent: React.FC<TButtonProps> = (props) => (
    <TButton {...props} variant={variant} />
  );
  VariantComponent.displayName = `TButton.${variant.charAt(0).toUpperCase() + variant.slice(1)}`;
  return VariantComponent;
};

TButton.Solid = makeVariant('solid');
TButton.Outline = makeVariant('outline');
TButton.Dashed = makeVariant('dashed');
TButton.Filled = makeVariant('filled');
TButton.Text = makeVariant('text');
TButton.Link = makeVariant('link');
TButton.Danger = makeVariant('danger');
TButton.Ghost = makeVariant('ghost');

TButton.displayName = 'TButton';

export default TButton;