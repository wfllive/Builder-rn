/**
 * TCollapseButtonsGroup — выдвижная горизонтальная группа кнопок.
 * framer-motion заменён на условный рендер (без лишней зависимости).
 */
import React, { useState } from "react";
import { View } from "react-native";
import type { BaseButtonProps } from "./tbutton";
import { cn } from "@/adapters/cn";

export type TCollapseSize = "xs" | "sm" | "lg" | "xl";

export interface TCollapseButtonsGroupProps {
  openButton: React.ReactElement<BaseButtonProps>;
  openIcon: React.ReactNode;
  closeIcon: React.ReactNode;
  initialOpen?: boolean;
  size?: TCollapseSize;
  className?: string;
  children: React.ReactNode;
}

const TCollapseButtonsGroup: React.FC<TCollapseButtonsGroupProps> = ({
  openButton,
  openIcon,
  closeIcon,
  initialOpen = false,
  className = "",
  children,
}) => {
  const [isOpen, setIsOpen] = useState(initialOpen);

  const cloned = React.cloneElement(openButton, {
    centerImage: isOpen ? closeIcon : openIcon,
    onPress: () => setIsOpen((v) => !v),
  });

  return (
    <View className={cn("flex-row items-center", className)}>
      {cloned}
      {isOpen ? <View className="flex-row items-center ml-2 gap-2">{children}</View> : null}
    </View>
  );
};

export default TCollapseButtonsGroup;
