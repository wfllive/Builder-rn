/**
 * TContainerButton — полноширинная кнопка-контейнер.
 * Порт web-компонента. <button> → Pressable.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export type TContainerButtonSize = "xs" | "sm" | "lg" | "xl";
export type TContainerButtonTextAlign = "left" | "center" | "right";

export interface TContainerButtonProps {
  label: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  size?: TContainerButtonSize;
  textAlign?: TContainerButtonTextAlign;
  className?: string;
  onClick?: () => void;
  onPress?: () => void;
  disabled?: boolean;
}

const sizeClasses: Record<TContainerButtonSize, string> = {
  xs: "h-8 px-3",
  sm: "h-10 px-4",
  lg: "h-12 px-5",
  xl: "h-14 px-6",
};

const textSize: Record<TContainerButtonSize, string> = {
  xs: "text-sm",
  sm: "text-sm",
  lg: "text-lg",
  xl: "text-xl",
};

const TContainerButton: React.FC<TContainerButtonProps> = ({
  label,
  leftIcon,
  rightIcon,
  size = "sm",
  textAlign = "left",
  onClick,
  onPress,
  className = "",
  disabled = false,
}) => {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const align =
    textAlign === "center"
      ? "justify-center text-center"
      : textAlign === "right"
        ? "justify-end text-right"
        : "justify-start text-left";

  return (
    <Pressable
      onPress={onPress ?? onClick}
      disabled={disabled}
      className={cn(
        "w-full flex-row items-center rounded-xl bg-primary/5",
        sizeClasses[size],
        disabled && "opacity-40",
        className
      )}
    >
      {leftIcon ? <View className="mr-3">{leftIcon}</View> : null}
      <View className={cn("flex-1 flex-row", align)}>
        <Text className={cn(textSize[size])} style={{ color: ink }}>
          {label}
        </Text>
      </View>
      {rightIcon ? <View className="ml-3">{rightIcon}</View> : null}
    </Pressable>
  );
};

export default TContainerButton;
