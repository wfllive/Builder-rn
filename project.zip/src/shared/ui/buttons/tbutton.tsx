/**
 * TButton
 * ---------------------------------------------------------------
 * Порт web `shared/ui/buttons/tbutton.tsx` на React Native + NativeWind.
 *
 * Отличия native:
 * - <button>/<a> → Pressable (полиморфный `as` убран: в RN нет якорей)
 * - next/image → Image из react-native
 * - hoverEffect работает как press-эффект (hover на телефоне нет)
 *
 * API variant / size / leftIcon / rightIcon / centerImage / isLoading
 * сохранён, чтобы экраны писались так же, как на вебе.
 */
import React from "react";
import {
  Image,
  Pressable,
  Text,
  View,
  type GestureResponderEvent,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import TCircleProgress from "../feedback/tcircle_progress";
import { cn } from "@/adapters/cn";
import { lightTokens, resolveToken } from "@/theme/tokens";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";

/** Варианты отображения кнопки — те же, что на вебе */
export type ButtonVariant =
  | "solid"
  | "outline"
  | "dashed"
  | "filled"
  | "text"
  | "link"
  | "danger"
  | "ghost";

/** Эффект при нажатии (на вебе это был hover) */
export type HoverEffect = "brightness" | "scale-up" | "scale-down";

/** Допустимые размеры кнопки */
export type ButtonSize = "xs" | "sm" | "lg" | "xl";

export interface BaseButtonProps {
  /** Размер кнопки */
  size?: ButtonSize;
  /** Закругление: number → px, string → Tailwind-класс `rounded-*` */
  radius?: number | string;
  /** Вариант внешнего вида */
  variant?: ButtonVariant;
  /** Показывать индикатор загрузки вместо содержимого */
  isLoading?: boolean;
  /** Эффект при нажатии */
  hoverEffect?: HoverEffect;
  /** Дополнительные классы NativeWind */
  className?: string;
  /** Иконка слева */
  leftIcon?: React.ReactNode;
  /** Иконка справа */
  rightIcon?: React.ReactNode;
  /** Кастомный цвет текста */
  textColor?: string;
  /** Содержимое кнопки */
  children?: React.ReactNode;
  /** Горизонтальное выравнивание контента */
  contentAlign?:
    | "justify-start"
    | "justify-center"
    | "justify-end"
    | "justify-between"
    | "justify-around"
    | "justify-evenly";
  /** Центральное изображение / иконка поверх контента */
  centerImage?:
    | React.ReactNode
    | { src: string; alt?: string; width?: number; height?: number };
  /** Клик */
  onClick?: (e: GestureResponderEvent) => void;
  /** Алиас onClick для RN-привычки */
  onPress?: (e: GestureResponderEvent) => void;
  /** Точка уведомления */
  indicatorNotification?: boolean;
  /** Число уведомлений */
  countNotification?: number;
  /** Отключена ли кнопка */
  disabled?: boolean;
  /** Inline-стиль (радиус, ширина и т.д.) */
  style?: StyleProp<ViewStyle>;
  /** a11y-лейбл */
  accessibilityLabel?: string;
  /** Тестовый id */
  testID?: string;
}

const sizeClasses: Record<ButtonSize, string> = {
  xs: "px-1 py-1",
  sm: "px-4 py-2.5",
  lg: "px-6 py-3",
  xl: "px-8 py-4",
};

const textSizeClasses: Record<ButtonSize, string> = {
  xs: "text-xs",
  sm: "text-sm",
  lg: "text-lg",
  xl: "text-xl",
};

const squareSizeClasses: Record<ButtonSize, string> = {
  xs: "w-6 h-6",
  sm: "w-9 h-9",
  lg: "w-12 h-12",
  xl: "w-16 h-16",
};

/** NativeWind иногда не даёт Pressable ширину — иконка видна, тап нет. */
const squareSizePx: Record<ButtonSize, number> = {
  xs: 28,
  sm: 40,
  lg: 48,
  xl: 64,
};

const variantClasses: Record<ButtonVariant, string> = {
  solid: "bg-primary border border-transparent",
  outline: "bg-transparent border-2 border-primary/30",
  dashed: "bg-transparent border border-dashed border-primary",
  filled: "bg-primary/10 border border-transparent",
  text: "bg-transparent px-2 py-1",
  link: "bg-transparent p-0",
  danger: "bg-danger/30 border border-transparent",
  ghost: "bg-transparent border border-transparent",
};

const variantTextColor: Record<ButtonVariant, string> = {
  solid: "text-white",
  outline: "text-primary",
  dashed: "text-primary",
  filled: "text-primary",
  text: "text-ink",
  link: "text-primary",
  danger: "text-danger",
  ghost: "text-ink",
};

function isCenterImageObject(
  x: BaseButtonProps["centerImage"]
): x is { src: string; alt?: string; width?: number; height?: number } {
  return Boolean(x && typeof x === "object" && "src" in x);
}

const TButtonInner: React.FC<BaseButtonProps> = (props) => {
  const {
    size = "sm",
    variant = "solid",
    isLoading = false,
    hoverEffect = "brightness",
    className = "",
    leftIcon,
    rightIcon,
    textColor,
    children,
    centerImage,
    contentAlign = "justify-center",
    indicatorNotification = false,
    countNotification = 0,
    onClick,
    onPress,
    disabled,
    style,
    radius,
    accessibilityLabel,
    testID,
  } = props;

  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const hasChildren = React.Children.count(children) > 0;
  const isIconOnlyCenter =
    (variant === "text" || variant === "filled") &&
    !!centerImage &&
    !hasChildren &&
    !leftIcon &&
    !rightIcon;

  const radiusClass =
    typeof radius === "string" && radius.startsWith("rounded")
      ? radius
      : "rounded-xl";

  const radiusStyle =
    typeof radius === "number"
      ? { borderRadius: radius }
      : typeof radius === "string" && !radius.startsWith("rounded")
        ? { borderRadius: radius as unknown as number }
        : undefined;

  const computedClasses = cn(
    "flex-row items-center overflow-hidden",
    contentAlign,
    isIconOnlyCenter ? squareSizeClasses[size] : sizeClasses[size],
    variantClasses[variant],
    radiusClass,
    (disabled || isLoading) && "opacity-60",
    className
  );

  const handlePress = (e: GestureResponderEvent) => {
    if (disabled || isLoading) return;
    onPress?.(e);
    onClick?.(e);
  };

  const pressScale =
    hoverEffect === "scale-up" ? 1.05 : hoverEffect === "scale-down" ? 0.95 : 0.98;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      testID={testID}
      disabled={disabled || isLoading}
      onPress={handlePress}
      className={computedClasses}
      hitSlop={isIconOnlyCenter ? 8 : undefined}
      style={({ pressed }) => [
        radiusStyle,
        isIconOnlyCenter
          ? { width: squareSizePx[size], height: squareSizePx[size] }
          : undefined,
        style,
        pressed && { transform: [{ scale: pressScale }] },
      ]}
    >
      <View className={cn("relative flex-row items-center w-full", contentAlign)}>
        {/* Индикатор уведомления (точка / бейдж) */}
        {indicatorNotification && (
          <View className="absolute -top-1 left-7 z-10">
            {countNotification ? (
              <View className="bg-danger rounded-full min-w-[16px] h-4 px-1 items-center justify-center">
                <Text className="text-[10px] text-white">
                  {countNotification > 99 ? "99+" : countNotification}
                </Text>
              </View>
            ) : (
              <View className="w-2 h-2 bg-danger rounded-full" />
            )}
          </View>
        )}

        <View className="flex-row items-center justify-center">
          {leftIcon ? <View className="mr-2">{leftIcon}</View> : null}

          {typeof children === "string" || typeof children === "number" ? (
            <Text
              className={cn(textSizeClasses[size], variantTextColor[variant])}
              style={
                textColor
                  ? { color: textColor }
                  : variant === "text" || variant === "ghost"
                    ? { color: ink }
                    : undefined
              }
            >
              {children}
            </Text>
          ) : (
            children
          )}

          {rightIcon ? <View className="ml-2">{rightIcon}</View> : null}
        </View>

        {centerImage ? (
          <View
            className="absolute left-0 right-0 top-0 bottom-0 items-center justify-center"
            pointerEvents="none"
          >
            {isCenterImageObject(centerImage) ? (
              <Image
                source={{ uri: centerImage.src }}
                style={{
                  width: centerImage.width ?? 32,
                  height: centerImage.height ?? 32,
                }}
                accessibilityLabel={centerImage.alt}
              />
            ) : (
              centerImage
            )}
          </View>
        ) : null}

        {isLoading ? (
          <View className="absolute left-0 right-0 top-0 bottom-0 items-center justify-center">
            <TCircleProgress
              indeterminateOnly
              colorProgress={lightTokens.primary}
              size={20}
              strokeWidth={3}
            />
          </View>
        ) : null}
      </View>
    </Pressable>
  );
};

type Subcomponent = React.FC<BaseButtonProps>;

const makeVariant =
  (variant: ButtonVariant): Subcomponent =>
  (props) => <TButtonInner {...props} variant={variant} />;

type TButtonType = React.FC<BaseButtonProps> & {
  Solid: Subcomponent;
  Outline: Subcomponent;
  Dashed: Subcomponent;
  Filled: Subcomponent;
  Text: Subcomponent;
  Link: Subcomponent;
  Danger: Subcomponent;
  Ghost: Subcomponent;
};

const TButton = TButtonInner as TButtonType;
TButton.displayName = "TButton";
TButton.Solid = makeVariant("solid");
TButton.Outline = makeVariant("outline");
TButton.Dashed = makeVariant("dashed");
TButton.Filled = makeVariant("filled");
TButton.Text = makeVariant("text");
TButton.Link = makeVariant("link");
TButton.Danger = makeVariant("danger");
TButton.Ghost = makeVariant("ghost");

export default TButton;
