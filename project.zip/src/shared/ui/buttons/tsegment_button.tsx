/**
 * TSegmentButton — сегменты в один ряд (flex).
 *
 * Раньше был горизонтальный ScrollView: на телефоне видна одна кнопка,
 * остальные «уезжали». Для 2–4 пунктов скролл не нужен.
 */
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { cn } from "@/adapters/cn";
import type { ButtonSize } from "./tbutton";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export type SegmentSize = ButtonSize;
export type ActiveType = "primary" | "danger" | "warning" | "info";

export interface SegmentOption {
  key: string;
  label?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  centerIcon?: React.ReactNode;
  activeColor?: string;
  typeActive?: ActiveType;
  className?: string;
}

export interface TSegmentButtonProps {
  size?: SegmentSize;
  radius?: number | string;
  options: SegmentOption[];
  defaultKey?: string;
  onChange?: (key: string) => void;
  activeKey?: string;
  className?: string;
}

const TSegmentButton: React.FC<TSegmentButtonProps> = ({
  options,
  defaultKey,
  onChange,
  activeKey: controlledKey,
  className = "",
}) => {
  const [internalKey, setInternalKey] = useState(defaultKey || options[0]?.key);
  const activeKey = controlledKey ?? internalKey;
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const primary = resolveToken(isDark, "primary");

  const handleSelect = (key: string) => {
    if (controlledKey === undefined) setInternalKey(key);
    onChange?.(key);
  };

  return (
    <View className={cn("flex-row rounded-2xl p-1 bg-primary/10", className)}>
      {options.map((opt) => {
        const isActive = activeKey === opt.key;
        return (
          <Pressable
            key={opt.key}
            onPress={() => handleSelect(opt.key)}
            className={cn("flex-1 flex-row items-center justify-center py-2.5 px-1 rounded-xl", opt.className)}
            style={{ backgroundColor: isActive ? `${primary}2E` : "transparent" }}
          >
            {opt.leftIcon ? <View className="mr-1">{opt.leftIcon}</View> : null}
            {opt.label ? (
              <Text
                className="text-xs font-medium"
                numberOfLines={1}
                style={{ color: isActive ? primary : ink }}
              >
                {opt.label}
              </Text>
            ) : null}
            {opt.rightIcon ? <View className="ml-1">{opt.rightIcon}</View> : null}
          </Pressable>
        );
      })}
    </View>
  );
};

TSegmentButton.displayName = "TSegmentButton";
export default TSegmentButton;
