/**
 * Выбор темы: три плитки в ряд.
 *
 * TSegmentButton на узком экране прятал «Светлая/Тёмная» в ScrollView —
 * казалось, что тему нельзя сменить. Здесь все три варианта всегда видны.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import { Bling } from "@/shared/ui/icons/mingcute/design/bling_line";
import { Sun } from "@/shared/ui/icons/mingcute/weather/sun_line";
import { MoonStars } from "@/shared/ui/icons/mingcute/weather/moon_stars_line";
import { useAppTheme, type AppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

const OPTIONS: { key: AppTheme; label: string; Icon: typeof Sun }[] = [
  { key: "system", label: "Система", Icon: Bling },
  { key: "light", label: "Светлая", Icon: Sun },
  { key: "dark", label: "Тёмная", Icon: MoonStars },
];

export default function ThemeChoiceRow() {
  const { theme, setTheme, isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");
  const primary = resolveToken(isDark, "primary");

  return (
    <View className="flex-row gap-2">
      {OPTIONS.map(({ key, label, Icon }) => {
        const active = theme === key;
        return (
          <Pressable
            key={key}
            onPress={() => setTheme(key)}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            className="flex-1 items-center py-3 px-1 rounded-2xl"
            style={{
              backgroundColor: active ? `${primary}33` : isDark ? "rgba(255,255,255,0.06)" : "rgba(95,24,218,0.06)",
              borderWidth: 1,
              borderColor: active ? primary : "transparent",
            }}
          >
            <Icon size={20} color={active ? primary : ink} />
            <Text
              className="text-xs mt-1.5 font-medium"
              style={{ color: active ? primary : muted }}
            >
              {label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
