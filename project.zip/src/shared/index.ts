/**
 * Публичный баррель shared-слоя.
 *
 * Правило команды:
 * - экраны приложения импортируют из `@/shared` или `@/shared/...`
 * - Layout брать ТОЛЬКО из `@/shared/ui/layout/layout`
 * - навигацию / storage / auth — через `@/adapters/*`
 */

// Обычный мобильный layout (не веб-сетка)
export { default as Layout } from "./ui/layout/layout";
export type { LayoutProps } from "./ui/layout/layout";

// Провайдеры
export { ThemeProvider, useAppTheme } from "./templates/providers/theme_provider";
export { UISettingsProvider, useUISettings } from "./templates/providers/ui_settings_provider";

// Кнопки
export { default as TButton } from "./ui/buttons/tbutton";
export { default as TContainerButton } from "./ui/buttons/tcontainer_button";
export { default as TSegmentButton } from "./ui/buttons/tsegment_button";

// Ввод
export { default as FlyInput } from "./ui/data_entry/flyinput";
export { default as TSwitch } from "./ui/data_entry/tswitch";
export { default as TCheckbox } from "./ui/data_entry/tcheckbox";
export { TRadio } from "./ui/data_entry/tradio";

// Отображение
export { default as FlyAvatar } from "./ui/data_display/flyavatar";
export { default as FlyTag } from "./ui/data_display/flytag";
export { default as FlyTabs } from "./ui/navigation/flytabs";

// Фидбек
export { default as FlyBottomSheetModal } from "./ui/feedback/flybottom_sheet_modal";
export { default as FlySnackbar } from "./ui/feedback/flysnackbar";
export { default as TSkeleton } from "./ui/feedback/tskeleton";
export { default as TCircleProgress } from "./ui/feedback/tcircle_progress";

// Виджеты
export { default as FlexibleHeaderMobile } from "./widgets/flexible_header_mobile";
export { default as FlexibleHeader } from "./widgets/flexible_header";
