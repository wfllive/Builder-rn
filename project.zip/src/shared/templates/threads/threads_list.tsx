/**
 * ThreadsList — список тредов.
 * На вебе ходил в /api/v2/threads. Здесь принимает items (app-слой фетчит).
 */
import React from "react";
import { View } from "react-native";
import ThreadItemPlaceholder from "./thread_item_placeholder";
import FlyStatusView from "@/shared/ui/feedback/flystatus_view";
import type { ThreadData } from "./types/thread_data.types";

export type SortType =
  | "new"
  | "recommendations"
  | "popular"
  | "following"
  | "bots"
  | "daily_threads"
  | "daily_replies";

export default function ThreadsList({
  items = [],
  isLoading,
  sortType,
}: {
  items?: ThreadData[];
  isLoading?: boolean;
  sortType?: SortType;
}) {
  if (isLoading) {
    return (
      <View className="gap-3">
        <ThreadItemPlaceholder isLoading />
        <ThreadItemPlaceholder isLoading />
      </View>
    );
  }

  if (!items.length) {
    return (
      <FlyStatusView
        status="empty"
        title="А где все?"
        message="Здесь пусто, но это легко исправить"
      />
    );
  }

  return (
    <View className="gap-3">
      {items.map((item) => (
        <ThreadItemPlaceholder key={item.id} data={item} />
      ))}
    </View>
  );
}
