/**
 * Пропсы карточки треда (порт web-типов).
 */
import type { ThreadData } from "./thread_data.types";

export interface ThreadItemProps {
  data: ThreadData;
  size?: "xs" | "sm" | "lg" | "xl";
  className?: string;
  isLoading?: boolean;
  onPress?: () => void;
}
