/**
 * Типы треда — порт web `thread_data.types.ts` 1:1.
 * Контракт API не меняется между web и native.
 */

export interface ThreadData {
  id: number;
  created_by: number;
  topic_by: string;
  text_twit: string;
  age_category: string | null;
  blocked: boolean;
  is_pinned: boolean;
  is_deleted: boolean;
  deleted_at: string | null;
  created_at: string;
  attachments: ThreadAttachment[];
  user_info: ThreadUserInfo;
  nominations?: ThreadNominations;
  is_can_edit: boolean;
  is_liked: boolean;
  likes_count: number;
  views_count: number;
  comments_count: number;
  rethread_data?: ThreadData | null;
  preview_comments: ThreadPreviewComment[];
}

export interface ThreadAttachment {
  id: number;
  twit_id: number;
  file_url: string;
  file_type: string;
  file_original_name: string;
  file_unique_name: string;
  file_size: number;
  created_at: string;
}

export interface ThreadUserInfo {
  id: number;
  user_id: string;
  aliases_user_id: string[];
  username: string;
  description: string | null;
  avatar: string | null;
  banner: string | null;
  verify_icon: string | null;
  status_icon: string | null;
  online_status_icon: string | null;
  blocked: boolean;
  is_fake: boolean | null;
  is_spam: boolean | null;
  is_scam: boolean | null;
  verify: boolean;
  is_premium: boolean;
  verify_icon_type: "official" | "service" | string | null;
  followers_count: number;
  following_count: number;
  followed: boolean;
}

export interface ThreadNominations {
  is_daily_thread: boolean;
  is_reply_daily_thread: boolean;
}

export interface ThreadPreviewComment {
  username: string;
  avatar: string | null;
}
