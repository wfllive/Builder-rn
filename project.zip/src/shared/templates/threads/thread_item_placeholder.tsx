/**
 * Карточка треда — композиция как на вебе + демо-функции примера.
 * Тап по тексту/фото открывает тред. Лайк и комментарии — отдельные кнопки.
 */
import React from "react";
import { Text, View } from "react-native";
import TSkeleton from "@/shared/ui/feedback/tskeleton";
import LayoutThreadRoot from "./ui/layout/layout_thread_root";
import SidebarThreadRoot from "./ui/sidebar/sidebar_thread_root";
import HeaderThreadRoot from "./ui/header/header_thread_root";
import ContentThreadText from "./ui/content/content_thread_text";
import ContentThreadMediaAttachments from "./ui/content/content_thread_media_attachments";
import ContentThreadFileAttachments from "./ui/content/content_thread_file_attachments";
import ActionsThreadRoot from "./ui/actions/actions_thread_root";
import type { ThreadData } from "./types/thread_data.types";
import { useDemoSession } from "@/example/demo_session";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ThreadItemPlaceholder({
  data,
  isLoading,
  className,
  onPress,
}: {
  data?: ThreadData;
  isLoading?: boolean;
  className?: string;
  onPress?: () => void;
}) {
  if (isLoading || !data) {
    return (
      <LayoutThreadRoot className={className}>
        <View className="flex-row gap-2 mb-2">
          <TSkeleton shape="avatar" size="lg" />
          <View className="flex-1 gap-2">
            <TSkeleton className="w-32 h-4" />
            <TSkeleton className="w-20 h-3" />
          </View>
        </View>
        <TSkeleton className="w-full h-16" />
      </LayoutThreadRoot>
    );
  }

  return <ThreadItemLive data={data} className={className} onPress={onPress} />;
}

function ThreadItemLive({
  data,
  className,
  onPress,
}: {
  data: ThreadData;
  className?: string;
  onPress?: () => void;
}) {
  const demo = useDemoSession();
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const extra = demo.comments[data.id]?.length ?? 0;
  const shown = Math.max(data.comments_count, extra);
  const translated = Boolean(demo.translated[data.id]);
  const href = `/tb/${data.user_info.user_id}/${data.id}`;

  const openThread = () => {
    if (onPress) {
      onPress();
      return;
    }
    nav.push(href);
  };

  return (
    <LayoutThreadRoot
      className={className}
      onPress={openThread}
      sidebar={
        <SidebarThreadRoot
          data={data}
          onPress={() => nav.push(`/tb/${data.user_info.user_id}`)}
        />
      }
      header={
        <HeaderThreadRoot
          data={data}
          onOpenThread={openThread}
          onShare={() =>
            demo.showSnack("Ссылка скопирована", `Тред /tb/${data.user_info.user_id}/${data.id}`)
          }
        />
      }
      actions={
        <ActionsThreadRoot
          data={data}
          commentsCount={shown}
          onLike={() => demo.toggleLike(data.id)}
          onComments={() => demo.openComments(data.id)}
          onShare={() =>
            demo.showSnack("Ссылка скопирована", `Тред /tb/${data.user_info.user_id}/${data.id}`)
          }
          onTranslate={() => demo.toggleTranslate(data.id)}
        />
      }
    >
      {translated ? (
        <Text style={{ color: ink, fontSize: 15, lineHeight: 22 }}>
          [EN] Demo translation of this thread. Tap translate again to return.
        </Text>
      ) : (
        <ContentThreadText data={data} />
      )}
      <ContentThreadMediaAttachments data={data} />
      <ContentThreadFileAttachments data={data} />
    </LayoutThreadRoot>
  );
}
