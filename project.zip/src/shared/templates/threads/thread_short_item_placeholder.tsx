/**
 * Компактная карточка #ТредДня — высота только по тексту.
 */
import React from "react";
import { Text, View } from "react-native";
import LayoutThreadRoot from "./ui/layout/layout_thread_root";
import TSkeleton from "@/shared/ui/feedback/tskeleton";
import FlyAttachmentItemHolder from "@/shared/ui/data_display/flyattachment_item_holder";
import type { ThreadData } from "./types/thread_data.types";
import { cn } from "@/adapters/cn";
import { useAppNavigation } from "@/adapters/navigation";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ThreadShortItemPlaceholder({
  data,
  isLoading,
  leftPrefixIcon,
  className,
}: {
  data?: ThreadData;
  isLoading?: boolean;
  leftPrefixIcon?: React.ReactNode;
  className?: string;
  buttonClassName?: string;
  size?: "xs" | "sm" | "lg" | "xl";
}) {
  const nav = useAppNavigation();
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const primary = resolveToken(isDark, "primary");
  const open = () => {
    if (!data) return;
    nav.push(`/tb/${data.user_info.user_id}/${data.id}`);
  };

  return (
    <LayoutThreadRoot className={cn(className)} sidebar={leftPrefixIcon} onPress={open}>
      {isLoading || !data ? (
        <TSkeleton className="h-10 w-full" />
      ) : (
        <View className="py-1">
          <Text className="font-semibold" numberOfLines={1} style={{ color: primary }}>
            {data.user_info.username}
          </Text>
          <Text className="text-sm mt-1" numberOfLines={4} style={{ color: ink }}>
            {data.text_twit}
          </Text>
          {data.attachments[0]?.file_type.startsWith("image") ? (
            <View className="mt-2">
              <FlyAttachmentItemHolder uri={data.attachments[0].file_url} height={120} />
            </View>
          ) : null}
        </View>
      )}
    </LayoutThreadRoot>
  );
}
