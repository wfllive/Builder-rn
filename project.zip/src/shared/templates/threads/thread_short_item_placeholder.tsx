/**
 * Компактная карточка #ТредДня — высота только по тексту.
 */
import React from "react";
import { Text, View } from "react-native";
import LayoutThreadRoot from "./ui/layout/layout_thread_root";
import TSkeleton from "@/shared/ui/feedback/tskeleton";
import FlyAttachmentItemHolder from "@/shared/ui/data_display/flyattachment_item_holder";
import type { ThreadData } from "./types/thread_data.types";
import { cn } from "@/adapters/cn";
import { useAppNavigation } from "@/adapters/navigation";

export default function ThreadShortItemPlaceholder({
  data,
  isLoading,
  leftPrefixIcon,
  className,
}: {
  data?: ThreadData;
  isLoading?: boolean;
  leftPrefixIcon?: React.ReactNode;
  className?: string;
  buttonClassName?: string;
  size?: "xs" | "sm" | "lg" | "xl";
}) {
  const nav = useAppNavigation();
  const open = () => {
    if (!data) return;
    nav.push(`/tb/${data.user_info.user_id}/${data.id}`);
  };

  return (
    <LayoutThreadRoot className={cn(className)} sidebar={leftPrefixIcon} onPress={open}>
      {isLoading || !data ? (
        <TSkeleton className="h-10 w-full" />
      ) : (
        <View className="py-1">
          <Text className="font-semibold text-primary" numberOfLines={1}>
            {data.user_info.username}
          </Text>
          <Text className="text-sm mt-1 text-ink dark:text-[#F3F5F7]" numberOfLines={4}>
            {data.text_twit}
          </Text>
          {data.attachments[0]?.file_type.startsWith("image") ? (
            <View className="mt-2">
              <FlyAttachmentItemHolder uri={data.attachments[0].file_url} height={120} />
            </View>
          ) : null}
        </View>
      )}
    </LayoutThreadRoot>
  );
}
