/**
 * ThreadCreatePreview — превью создаваемого треда.
 * Цвет текста из темы (text-ink / text-muted статичны и ломают тёмную).
 */
import React from "react";
import { Text, View } from "react-native";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ThreadCreatePreview({ text }: { text?: string }) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");

  return (
    <View className="p-3 rounded-2xl border border-dashed border-primary/30">
      <Text className="text-xs mb-1" style={{ color: muted }}>
        Превью
      </Text>
      <Text style={{ color: ink }}>{text || "Начни писать…"}</Text>
    </View>
  );
}
