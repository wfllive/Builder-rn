/**
 * ThreadCreatePreview — превью создаваемого треда.
 */
import React from "react";
import { Text, View } from "react-native";

export default function ThreadCreatePreview({ text }: { text?: string }) {
  return (
    <View className="p-3 rounded-2xl border border-dashed border-primary/30">
      <Text className="text-xs text-muted mb-1">Превью</Text>
      <Text className="text-ink">{text || "Начни писать…"}</Text>
    </View>
  );
}
