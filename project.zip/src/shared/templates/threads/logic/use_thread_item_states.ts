/**
 * Локальные UI-состояния карточки треда (лайк-оптимизм и т.п.).
 */
import { useState } from "react";
import type { ThreadData } from "../types/thread_data.types";

export function useThreadItemStates(data: ThreadData) {
  const [liked, setLiked] = useState(data.is_liked);
  const [likes, setLikes] = useState(data.likes_count);

  const toggleLike = () => {
    setLiked((v) => !v);
    setLikes((n) => n + (liked ? -1 : 1));
  };

  return { liked, likes, toggleLike };
}
