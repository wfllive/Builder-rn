/**
 * Оркестратор карточки треда.
 * На вебе ходил в API like/view. Здесь — колбэки из app-слоя.
 */
import type { ThreadData } from "../types/thread_data.types";
import { useThreadItemStates } from "./use_thread_item_states";

export function useThreadItemLogic(data: ThreadData, onLike?: (id: number) => void) {
  const states = useThreadItemStates(data);

  const handleLike = () => {
    states.toggleLike();
    onLike?.(data.id);
  };

  return { ...states, handleLike };
}
