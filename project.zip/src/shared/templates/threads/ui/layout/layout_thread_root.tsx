/**
 * Карточка треда как на вебе: две колонки, высота по контенту.
 * Без flex-1 / stretch на весь ScrollView.
 */
import React from "react";
import { Pressable, View, type StyleProp, type ViewStyle } from "react-native";
import { cn } from "@/adapters/cn";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function LayoutThreadRoot({
  sidebar,
  header,
  actions,
  children,
  className,
  onPress,
  style,
}: {
  sidebar?: React.ReactNode;
  header?: React.ReactNode;
  actions?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) {
  const { isDark } = useAppTheme();
  const primary = resolveToken(isDark, "primary");

  return (
    <View
      className={cn("w-full flex-row items-start gap-2 p-2.5 rounded-xl border", className)}
      style={[
        {
          borderColor: `${primary}22`,
          backgroundColor: isDark ? `${primary}14` : `${primary}0A`,
        },
        style,
      ]}
    >
      {sidebar ? <View className="w-11">{sidebar}</View> : null}
      <View className="flex-1 min-w-0">
        {/*
          Карточка и экшены — разные Pressable.
          Вложенный Pressable на Android глотает лайк/комментарий.
        */}
        <Pressable onPress={onPress} disabled={!onPress}>
          {header}
          {children}
        </Pressable>
        {actions}
      </View>
    </View>
  );
}
