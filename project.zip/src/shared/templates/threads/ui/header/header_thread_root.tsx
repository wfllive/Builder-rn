/**
 * HeaderThreadRoot — как на вебе:
 * ник primary, чип /tb/user_id, справа «ещё».
 */
import React from "react";
import { Text, View } from "react-native";
import FlyTag from "@/shared/ui/data_display/flytag";
import TButton from "@/shared/ui/buttons/tbutton";
import FlyDropdown from "@/shared/ui/navigation/flydropdown";
import { More1 } from "@/shared/ui/icons/mingcute/system/more_1_line";
import { Pin } from "@/shared/ui/icons/mingcute/file/pin_line";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import type { ThreadData } from "../../types/thread_data.types";

export default function HeaderThreadRoot({
  data,
  onOpenThread,
  onShare,
}: {
  data: ThreadData;
  onOpenThread?: () => void;
  onShare?: () => void;
}) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");

  return (
    <View className="flex-row items-start justify-between w-full pb-1.5 pt-1">
      <View className="flex-1 min-w-0 pr-2">
        <Text className="text-base text-primary" numberOfLines={1}>
          {data.user_info.username}
        </Text>
        <View className="mt-1 self-start">
          <FlyTag
            content={`/tb/${data.user_info.user_id}`}
            hideCircle
            size="xs"
            className="bg-primary/10"
          />
        </View>
      </View>

      <View className="flex-row items-center">
        {data.is_pinned ? (
          <View className="px-2 py-1 mr-1 rounded-xl bg-primary/10">
            <Pin size={18} color={resolveToken(isDark, "primary")} filled />
          </View>
        ) : null}
        <FlyDropdown
          items={[
            { label: "Открыть ветку", onClick: onOpenThread },
            { label: "Поделиться тредом", onClick: onShare },
            { label: "Пожаловаться", type: "danger", onClick: onShare },
          ]}
          trigger={<TButton.Text size="sm" centerImage={<More1 size={20} color={ink} />} />}
        />
      </View>
    </View>
  );
}
