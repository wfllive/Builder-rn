/**
 * ContentThreadTranslate — слот кнопки перевода (API живёт в app-слое).
 */
import React from "react";
import { Pressable, Text } from "react-native";

export default function ContentThreadTranslate({ onPress }: { onPress?: () => void }) {
  return (
    <Pressable onPress={onPress} className="mt-2">
      <Text className="text-sm text-primary">Перевести</Text>
    </Pressable>
  );
}
