/**
 * ContentThreadTranslate — слот кнопки перевода (API живёт в app-слое).
 */
import React from "react";
import { Pressable, Text } from "react-native";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";

export default function ContentThreadTranslate({ onPress }: { onPress?: () => void }) {
  const { isDark } = useAppTheme();
  const primary = resolveToken(isDark, "primary");
  return (
    <Pressable onPress={onPress} className="mt-2">
      <Text className="text-sm" style={{ color: primary }}>
        Перевести
      </Text>
    </Pressable>
  );
}
