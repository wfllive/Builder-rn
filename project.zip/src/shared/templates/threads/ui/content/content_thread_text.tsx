/**
 * ContentThreadText — текст треда.
 * Цвет берём из темы style'ом: text-ink в NativeWind всегда светлый HEX.
 */
import React from "react";
import { Text } from "react-native";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import type { ThreadData } from "../../types/thread_data.types";

export default function ContentThreadText({ data }: { data: ThreadData }) {
  const { isDark } = useAppTheme();
  const color = resolveToken(isDark, "text");
  const text = data.text_twit?.trim() ?? "";
  if (!text) return null;

  return (
    <Text style={{ color, fontSize: 15, lineHeight: 22 }}>{text}</Text>
  );
}
