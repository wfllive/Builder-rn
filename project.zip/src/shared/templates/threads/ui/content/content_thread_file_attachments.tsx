/**
 * ContentThreadFileAttachments — файловые вложения треда.
 */
import React from "react";
import { View } from "react-native";
import FlyFileItemHolder from "@/shared/ui/data_display/flyfile_item_holder";
import type { ThreadData } from "../../types/thread_data.types";

export default function ContentThreadFileAttachments({ data }: { data: ThreadData }) {
  const files = data.attachments.filter(
    (a) => !a.file_type.startsWith("image") && !a.file_type.startsWith("video")
  );
  if (!files.length) return null;
  return (
    <View className="mt-2 gap-1">
      {files.map((f) => (
        <FlyFileItemHolder key={f.id} name={f.file_original_name} size={f.file_size} />
      ))}
    </View>
  );
}
