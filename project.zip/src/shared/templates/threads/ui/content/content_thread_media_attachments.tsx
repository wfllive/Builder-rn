/**
 * ContentThreadMediaAttachments — превью картинок/видео треда.
 * Одно фото — широкая карточка. Несколько — сетка 2 колонки.
 */
import React from "react";
import { View } from "react-native";
import FlyAttachmentItemHolder from "@/shared/ui/data_display/flyattachment_item_holder";
import type { ThreadData } from "../../types/thread_data.types";

export default function ContentThreadMediaAttachments({ data }: { data: ThreadData }) {
  const media = data.attachments.filter(
    (a) => a.file_type.startsWith("image") || a.file_type.startsWith("video")
  );
  if (!media.length) return null;

  if (media.length === 1) {
    return (
      <View className="mt-2">
        <FlyAttachmentItemHolder uri={media[0].file_url} height={200} />
      </View>
    );
  }

  return (
    <View className="mt-2 flex-row flex-wrap gap-2">
      {media.map((a) => (
        <View key={a.id} style={{ width: "48%" }}>
          <FlyAttachmentItemHolder uri={a.file_url} height={132} />
        </View>
      ))}
    </View>
  );
}
