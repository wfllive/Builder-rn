/**
 * ActionsThreadRoot — как на вебе: лайк / ответы / шаринг / перевод.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import { Heart } from "@/shared/ui/icons/mingcute/shape/heart_line";
import { Chat1 } from "@/shared/ui/icons/mingcute/contact/chat_1_line";
import { Share2 } from "@/shared/ui/icons/mingcute/system/share_2_line";
import { Translate2AI } from "@/shared/ui/icons/mingcute/editor/translate_2_ai_line";
import { formatShortNumber } from "@/shared/utils/format_short_number";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import type { ThreadData } from "../../types/thread_data.types";

function Action({
  icon,
  label,
  onPress,
}: {
  icon: React.ReactNode;
  label?: string;
  onPress?: () => void;
}) {
  return (
    <Pressable onPress={onPress} className="flex-row items-center mr-1 px-1 py-1">
      {icon}
      {label != null ? <Text className="ml-1 text-sm text-primary">{label}</Text> : null}
    </Pressable>
  );
}

export default function ActionsThreadRoot({
  data,
  commentsCount,
  onLike,
  onComments,
  onShare,
  onTranslate,
}: {
  data: ThreadData;
  commentsCount?: number;
  onLike?: () => void;
  onComments?: () => void;
  onShare?: () => void;
  onTranslate?: () => void;
}) {
  const { isDark } = useAppTheme();
  const primary = resolveToken(isDark, "primary");

  return (
    <View className="flex-row items-center mt-2 mb-1">
      <Action
        onPress={onLike}
        icon={<Heart size={22} color={primary} filled={data.is_liked} />}
        label={formatShortNumber(data.likes_count)}
      />
      <Action
        onPress={onComments}
        icon={<Chat1 size={22} color={primary} />}
        label={formatShortNumber(commentsCount ?? data.comments_count)}
      />
      <Action onPress={onShare} icon={<Share2 size={22} color={primary} />} />
      {data.text_twit ? (
        <Action onPress={onTranslate} icon={<Translate2AI size={22} color={primary} />} />
      ) : null}
    </View>
  );
}
