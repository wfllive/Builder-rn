/**
 * SidebarThreadRoot — аватар слева.
 * Линия короткой фиксированной высоты: flex-1 растягивал карточку.
 * Тап по аватару открывает профиль (не весь тред).
 */
import React from "react";
import { Pressable, View } from "react-native";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import type { ThreadData } from "../../types/thread_data.types";

export default function SidebarThreadRoot({
  data,
  onPress,
}: {
  data?: ThreadData;
  children?: React.ReactNode;
  onPress?: () => void;
}) {
  const author = data?.user_info;
  if (!author) return <View className="w-10" />;

  return (
    <View className="items-center pt-1">
      <Pressable onPress={onPress} disabled={!onPress} hitSlop={6}>
        <FlyAvatar src={author.avatar ?? undefined} alt={author.username} size={40} />
      </Pressable>
      {data?.preview_comments?.length ? (
        <View className="w-0.5 h-8 mt-2 rounded-full bg-primary" />
      ) : null}
    </View>
  );
}
