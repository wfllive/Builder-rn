/**
 * TrendsProfilesList — список трендовых профилей.
 */
import React from "react";
import { View } from "react-native";
import ShortProfileHeader from "../profile/short_profile_header";
import type { ThreadUserInfo } from "../threads/types/thread_data.types";

export default function TrendsProfilesList({ items = [] }: { items?: ThreadUserInfo[] }) {
  return (
    <View>
      {items.map((u) => (
        <ShortProfileHeader key={u.id} user={u} />
      ))}
    </View>
  );
}
