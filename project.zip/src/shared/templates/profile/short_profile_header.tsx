/**
 * ShortProfileHeader — компактная строка профиля в поиске.
 */
import React from "react";
import { Pressable, Text, View } from "react-native";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import type { ThreadUserInfo } from "../threads/types/thread_data.types";

export default function ShortProfileHeader({
  user,
  onPress,
}: {
  user: ThreadUserInfo;
  onPress?: () => void;
}) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");

  return (
    <Pressable onPress={onPress} className="flex-row items-center gap-3 p-3">
      <FlyAvatar src={user.avatar ?? undefined} alt={user.username} size="sm" />
      <View className="flex-1">
        <Text className="font-semibold" style={{ color: ink }}>
          {user.username}
        </Text>
        <Text className="text-xs" style={{ color: muted }}>
          @{user.user_id}
        </Text>
      </View>
    </Pressable>
  );
}
