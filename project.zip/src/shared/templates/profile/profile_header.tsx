/**
 * ProfileHeader — шапка профиля для native.
 * Баннер, аватар, имя, описание, статистика, подписка.
 * Не копия web-шапки (там QR, алиасы, 3D) — обычный мобильный блок.
 */
import React from "react";
import { Image, Text, View } from "react-native";
import FlyAvatar from "@/shared/ui/data_display/flyavatar";
import FlyTag from "@/shared/ui/data_display/flytag";
import TButton from "@/shared/ui/buttons/tbutton";
import { formatShortNumber } from "@/shared/utils/format_short_number";
import { useAppTheme } from "@/shared/templates/providers/theme_provider";
import { resolveToken } from "@/theme/tokens";
import type { ThreadUserInfo } from "../threads/types/thread_data.types";
import { photoSource } from "@/example/demo_media";

export default function ProfileHeader({
  user,
  isOwn,
  threadsCount = 0,
  onToggleFollow,
}: {
  user: ThreadUserInfo;
  isOwn?: boolean;
  threadsCount?: number;
  onToggleFollow?: () => void;
}) {
  const { isDark } = useAppTheme();
  const ink = resolveToken(isDark, "text");
  const muted = resolveToken(isDark, "textMuted");

  return (
    <View>
      {user.banner ? (
        <Image source={{ uri: user.banner }} className="w-full h-32" resizeMode="cover" />
      ) : (
        <View className="w-full h-32 bg-primary/20" />
      )}

      <View className="px-4 -mt-10">
        <View className="flex-row items-end justify-between">
          <FlyAvatar
            src={user.avatar ?? undefined}
            alt={user.username}
            size="lg"
            stroke={3}
            strokeColor={resolveToken(isDark, "background")}
          />
          {isOwn ? (
            <TButton.Outline>Это вы</TButton.Outline>
          ) : (
            <TButton.Filled onPress={onToggleFollow}>
              {user.followed ? "Не нравится" : "Нравится"}
            </TButton.Filled>
          )}
        </View>

        <Text className="mt-3 text-xl font-bold" style={{ color: ink }}>
          {user.username}
        </Text>
        <View className="mt-1 self-start">
          <FlyTag content={`/tb/${user.user_id}`} hideCircle size="xs" className="bg-primary/10" />
        </View>
        {user.description ? (
          <Text className="mt-2 text-sm" style={{ color: ink }}>
            {user.description}
          </Text>
        ) : null}

        <View className="flex-row gap-4 mt-3 mb-2">
          <Text style={{ color: ink }}>
            <Text className="font-bold">{formatShortNumber(threadsCount)}</Text>
            <Text style={{ color: muted }}> тредов</Text>
          </Text>
          <Text style={{ color: ink }}>
            <Text className="font-bold">{formatShortNumber(user.followers_count)}</Text>
            <Text style={{ color: muted }}> я нравлюсь</Text>
          </Text>
          <Text style={{ color: ink }}>
            <Text className="font-bold">{formatShortNumber(user.following_count)}</Text>
            <Text style={{ color: muted }}> мне нравятся</Text>
          </Text>
        </View>
      </View>
    </View>
  );
}
