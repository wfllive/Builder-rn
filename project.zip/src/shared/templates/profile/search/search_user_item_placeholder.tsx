/**
 * SearchUserItemPlaceholder — скелетон пользователя в поиске.
 */
import React from "react";
import { View } from "react-native";
import TSkeleton from "@/shared/ui/feedback/tskeleton";

export default function SearchUserItemPlaceholder() {
  return (
    <View className="flex-row items-center gap-3 p-3">
      <TSkeleton shape="avatar" size="lg" />
      <View className="flex-1 gap-2">
        <TSkeleton className="w-36 h-4" />
        <TSkeleton className="w-24 h-3" />
      </View>
    </View>
  );
}
