/**
 * LikesItemPlaceholder — скелетон/строка лайка.
 */
import React from "react";
import { View } from "react-native";
import TSkeleton from "@/shared/ui/feedback/tskeleton";

export default function LikesItemPlaceholder({ isLoading = true }: { isLoading?: boolean }) {
  if (!isLoading) return null;
  return (
    <View className="flex-row items-center gap-3 p-3">
      <TSkeleton shape="avatar" size="lg" />
      <TSkeleton className="flex-1 h-4" />
    </View>
  );
}
