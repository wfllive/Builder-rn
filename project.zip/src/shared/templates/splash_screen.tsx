/**
 * SplashScreen — сплэш при холодном старте.
 */
import React from "react";
import { Text, View } from "react-native";
import TCircleProgress from "@/shared/ui/feedback/tcircle_progress";

export default function SplashScreen({
  minDuration: _minDuration,
}: {
  minDuration?: number;
  reloadDelay?: number;
}) {
  return (
    <View className="flex-1 items-center justify-center bg-paper">
      <Text className="text-3xl font-extrabold italic text-primary mb-6">
        twitblit
      </Text>
      <TCircleProgress indeterminateOnly type="primary" size={36} />
    </View>
  );
}
