/**
 * UISettingsProvider
 * ---------------------------------------------------------------
 * Порт web `shared/templates/providers/ui_settings_provider.tsx`.
 *
 * Отличия native:
 * - localStorage → AsyncStorage (через adapters/storage)
 * - document.documentElement.dataset → React-контекст
 * - prefers-reduced-motion → AccessibilityInfo
 */
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { AccessibilityInfo } from "react-native";
import { storageGet, storageSet } from "@/adapters/storage";

/** Настройки анимаций интерфейса */
interface AnimationsSettings {
  /** true — всё статично, false — анимации включены */
  disabled: boolean;
}

/** Полный контракт UI настроек */
interface UISettingsValue {
  animations: AnimationsSettings;
  setAnimationsDisabled: (value: boolean) => void;
}

/** Ключи хранения — совпадают с вебом, чтобы делиться настройками через бэкенд */
export const UI_SETTINGS_KEYS = {
  theme: "twb-ui-theme",
  animations: "twb-ui-animations",
} as const;

const UISettingsContext = createContext<UISettingsValue | undefined>(undefined);

/**
 * Провайдер UI-настроек. Оборачивать корень приложения.
 */
export function UISettingsProvider({ children }: { children: React.ReactNode }) {
  const [animationsDisabled, setAnimationsDisabledState] = useState(false);

  useEffect(() => {
    let mounted = true;

    (async () => {
      const stored = await storageGet(UI_SETTINGS_KEYS.animations);
      if (!mounted) return;

      if (stored !== null) {
        setAnimationsDisabledState(stored === "1");
        return;
      }

      // Системное «уменьшить движение»
      const reduce = await AccessibilityInfo.isReduceMotionEnabled();
      if (mounted) setAnimationsDisabledState(reduce);
    })();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    void storageSet(
      UI_SETTINGS_KEYS.animations,
      animationsDisabled ? "1" : "0"
    );
  }, [animationsDisabled]);

  const value = useMemo<UISettingsValue>(
    () => ({
      animations: { disabled: animationsDisabled },
      setAnimationsDisabled: setAnimationsDisabledState,
    }),
    [animationsDisabled]
  );

  return (
    <UISettingsContext.Provider value={value}>
      {children}
    </UISettingsContext.Provider>
  );
}

/** Хук доступа к UI-настройкам. Кидает, если провайдера нет. */
export function useUISettings() {
  const ctx = useContext(UISettingsContext);
  if (!ctx) {
    throw new Error("useUISettings must be used inside UISettingsProvider");
  }
  return ctx;
}
