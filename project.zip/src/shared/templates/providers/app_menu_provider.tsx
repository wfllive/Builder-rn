/**
 * Состояние левого меню.
 * Шапка открывает, FlyDrawer рисует список.
 */
import React, { createContext, useCallback, useContext, useMemo, useState } from "react";

type AppMenuValue = {
  menuOpen: boolean;
  openMenu: () => void;
  closeMenu: () => void;
  toggleMenu: () => void;
};

const AppMenuContext = createContext<AppMenuValue | null>(null);

export function AppMenuProvider({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const openMenu = useCallback(() => setMenuOpen(true), []);
  const closeMenu = useCallback(() => setMenuOpen(false), []);
  const toggleMenu = useCallback(() => setMenuOpen((v) => !v), []);
  const value = useMemo(
    () => ({ menuOpen, openMenu, closeMenu, toggleMenu }),
    [closeMenu, menuOpen, openMenu, toggleMenu]
  );
  return <AppMenuContext.Provider value={value}>{children}</AppMenuContext.Provider>;
}

export function useAppMenu() {
  const ctx = useContext(AppMenuContext);
  if (!ctx) throw new Error("useAppMenu must be used inside AppMenuProvider");
  return ctx;
}
