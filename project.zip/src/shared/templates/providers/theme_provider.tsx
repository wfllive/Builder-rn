/**
 * ThemeProvider
 * ---------------------------------------------------------------
 * Тема без NativeWind vars() — в Expo Go vars() может закрыть процесс.
 * Цвета экранов идут через Tailwind HEX (bg-primary, text-ink, bg-paper).
 */
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Appearance, View, useColorScheme } from "react-native";
import { UI_SETTINGS_KEYS } from "./ui_settings_provider";
import { storageGet, storageSet } from "@/adapters/storage";
import { darkTokens, lightTokens } from "@/theme/tokens";

export type AppTheme = "system" | "light" | "dark";
export type ResolvedTheme = "light" | "dark";

interface ThemeContextValue {
  theme: AppTheme;
  resolvedTheme: ResolvedTheme;
  setTheme: (theme: AppTheme) => void;
  toggleTheme: () => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function isValidTheme(value: string | null): value is AppTheme {
  return value === "system" || value === "light" || value === "dark";
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const systemScheme = useColorScheme();
  const [theme, setThemeState] = useState<AppTheme>("system");

  useEffect(() => {
    const sub = Appearance.addChangeListener(() => {
      // useColorScheme обновится сам; форсим ререндер через setThemeState identity
      setThemeState((current) => current);
    });
    return () => sub.remove();
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const stored = await storageGet(UI_SETTINGS_KEYS.theme);
      if (mounted && isValidTheme(stored)) setThemeState(stored);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    void storageSet(UI_SETTINGS_KEYS.theme, theme);
  }, [theme]);

  const resolvedTheme: ResolvedTheme =
    theme === "system" ? (systemScheme === "dark" ? "dark" : "light") : theme;

  /** Светлая / тёмная / система. Пишется в AsyncStorage, читается при старте. */
  const setTheme = (nextTheme: AppTheme) => setThemeState(nextTheme);
  const toggleTheme = () =>
    setThemeState((current) => (current === "dark" ? "light" : "dark"));

  const value = useMemo<ThemeContextValue>(
    () => ({
      theme,
      resolvedTheme,
      setTheme,
      toggleTheme,
      isDark: resolvedTheme === "dark",
    }),
    [theme, resolvedTheme]
  );

  const tokens = resolvedTheme === "dark" ? darkTokens : lightTokens;

  return (
    <ThemeContext.Provider value={value}>
      <View
        style={{ flex: 1, backgroundColor: tokens.background }}
        className={resolvedTheme === "dark" ? "dark bg-paper" : "bg-paper"}
      >
        {children}
      </View>
    </ThemeContext.Provider>
  );
}

export function useAppTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useAppTheme must be used inside ThemeProvider");
  }
  return ctx;
}

export { Appearance };
