/**
 * CurrentUserProvider
 * ---------------------------------------------------------------
 * На вебе тянул сессию с /api/v2/users/current-user.
 * В native сессия живёт в app-слое — провайдер просто прокидывает
 * адаптер авторизации вниз по дереву.
 */
import React from "react";
import { useAuth } from "@/adapters/auth";

export default function CurrentUserProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  // Хук нужен, чтобы подписчики адаптера обновляли дерево.
  useAuth();
  return <>{children}</>;
}
