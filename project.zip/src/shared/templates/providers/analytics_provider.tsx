/**
 * AnalyticsProvider
 * ---------------------------------------------------------------
 * На вебе подключал Umami.
 * В native аналитика (Amplitude / AppMetrica / свой SDK)
 * подключается в оболочке приложения. Shared только держит слот.
 */
import React from "react";

export default function AnalyticsProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
