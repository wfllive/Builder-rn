/**
 * Универсальная утилита текущей даты/времени.
 * Порт web `currentDate` — без сторонних библиотек.
 */
function now(): Date {
  return new Date();
}

export const currentDate = {
  now,
  year: () => now().getFullYear(),
  month: () => now().getMonth() + 1,
  day: () => now().getDate(),
  hours: () => now().getHours(),
  minutes: () => now().getMinutes(),
  seconds: () => now().getSeconds(),
  iso: () => now().toISOString(),
  timestamp: () => Date.now(),
  locale: (locale = "ru-RU") => now().toLocaleDateString(locale),
  localeTime: (locale = "ru-RU") => now().toLocaleTimeString(locale),
  localeDateTime: (locale = "ru-RU") => now().toLocaleString(locale),
};
