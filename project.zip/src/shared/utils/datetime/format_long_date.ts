/**
 * Длинная дата на русском: «11:40, 09 сентября, 2025».
 * Порт web-утилиты.
 */
export interface FormatDateOptions {
  order?: Array<"hours" | "minutes" | "day" | "month" | "year">;
  timeSeparator?: string;
  dateSeparator?: string;
}

export function formatLongDate(
  isoDate: string,
  options?: FormatDateOptions
): string {
  const date = new Date(isoDate);

  const months = [
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря",
  ];

  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const monthName = months[date.getMonth()];
  const year = date.getFullYear();

  const {
    order = ["hours", "minutes", "day", "month", "year"],
    timeSeparator = ":",
    dateSeparator = ", ",
  } = options || {};

  const components: string[] = [];

  for (const key of order) {
    switch (key) {
      case "hours":
        components.push(
          order.includes("minutes") ? `${hours}${timeSeparator}${minutes}` : hours
        );
        break;
      case "minutes":
        if (!order.includes("hours")) components.push(minutes);
        break;
      case "day":
        components.push(day);
        break;
      case "month":
        components.push(monthName);
        break;
      case "year":
        components.push(String(year));
        break;
    }
  }

  const timePart = components[0]?.includes(timeSeparator) ? components[0] : "";
  const rest = components.slice(timePart ? 1 : 0).join(" ");
  return timePart ? `${timePart}${dateSeparator}${rest}` : rest;
}
