/**
 * Короткое относительное время: "1с", "5м", "2ч", "3д", "1мес", "2г".
 * Порт web-утилиты (логика 1:1).
 */
export function formatShortDate(
  isoDate: string,
  relativeTo: Date = new Date()
): string {
  const date = new Date(isoDate);
  const diffMs = relativeTo.getTime() - date.getTime();

  if (diffMs < 0) return "Сейчас";

  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return `${diffSec}s`;

  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}м`;

  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}ч`;

  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 30) return `${diffDays}д`;

  const diffMonths = Math.floor(diffDays / 30);
  if (diffMonths < 12) return `${diffMonths}мес`;

  return `${Math.floor(diffMonths / 12)}г`;
}
