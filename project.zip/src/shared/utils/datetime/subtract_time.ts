/**
 * Сдвиг даты вперёд/назад (аналог timedelta).
 * Порт web-утилиты. months/years/centuries — приближённо.
 */
export interface TimeDelta {
  days?: number;
  hours?: number;
  minutes?: number;
  seconds?: number;
  months?: number;
  years?: number;
  centuries?: number;
}

function deltaToMs(delta: TimeDelta): number {
  return (
    (delta.seconds ?? 0) * 1000 +
    (delta.minutes ?? 0) * 60 * 1000 +
    (delta.hours ?? 0) * 60 * 60 * 1000 +
    (delta.days ?? 0) * 24 * 60 * 60 * 1000 +
    (delta.months ?? 0) * 30 * 24 * 60 * 60 * 1000 +
    (delta.years ?? 0) * 365 * 24 * 60 * 60 * 1000 +
    (delta.centuries ?? 0) * 100 * 365 * 24 * 60 * 60 * 1000
  );
}

function applyTimeDelta(
  from: Date | number,
  delta: TimeDelta,
  operation: "add" | "subtract"
): number {
  const base = typeof from === "number" ? from : from.getTime();
  const ms = deltaToMs(delta);
  return operation === "add" ? base + ms : base - ms;
}

export function subtractTime(from: Date | number, delta: TimeDelta): number {
  return applyTimeDelta(from, delta, "subtract");
}

export function addTime(from: Date | number, delta: TimeDelta): number {
  return applyTimeDelta(from, delta, "add");
}
