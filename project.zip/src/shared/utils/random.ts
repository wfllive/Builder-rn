/**
 * Утилиты случайных чисел и выборок.
 * Порт web `shared/utils/random.ts`.
 */

/** Случайное целое от min до max включительно. */
export const getRandomInt = (min: number, max: number): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

/** n случайных элементов массива (без повторов, если n ≤ length). */
export const getRandomElements = <T,>(arr: T[], n: number): T[] => {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, n);
};

/** С шансом chance дописывает пасхалку к тексту. */
export const addEasterEgg = (
  text: string,
  easterEgg: string,
  chance: number = 0.2
): string => {
  return Math.random() < chance ? `${text} ${easterEgg}` : text;
};
