/**
 * Градиент по краям изображения.
 * На native без canvas возвращаем фирменный фиолетовый градиент.
 * API сохранён для совместимости с web-шаблонами профиля.
 */
import { useMemo } from "react";

export function useImageEdgeGradient(_src?: string): string {
  return useMemo(
    () => "linear-gradient(180deg, rgba(95,24,218,0.35) 0%, rgba(10,10,10,0) 100%)",
    []
  );
}
