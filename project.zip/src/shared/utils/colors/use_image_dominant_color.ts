/**
 * Доминантный цвет изображения.
 *
 * WEB: считался через canvas + Image.
 * NATIVE: canvas недоступен, поэтому:
 * 1) если цвет уже в кэше — отдаём его;
 * 2) иначе возвращаем безопасный fallback.
 *
 * Оболочка приложения может прогреть кэш через `primeDominantColor`.
 */
import { useEffect, useState } from "react";

const colorCache: Record<string, string> = {};

/** Положить заранее вычисленный цвет в кэш (вызывать из app-слоя). */
export function primeDominantColor(src: string, rgba: string): void {
  colorCache[src] = rgba;
}

export function useImageDominantColor(src?: string) {
  const [color, setColor] = useState<string>("rgba(0,0,0,0.3)");

  useEffect(() => {
    if (!src) return;
    if (colorCache[src]) {
      setColor(colorCache[src]);
      return;
    }
    // На native без native-модуля пикселей честный average недоступен.
    setColor("rgba(95,24,218,0.35)");
  }, [src]);

  return color;
}
