/**
 * «Красивая» ссылка: https://www.example.com/blog/ → example.com/blog
 */
export function formatPrettyUrl(url: string): string {
  if (!url || typeof url !== "string") return "";

  try {
    const parsed = new URL(url);
    const hostname = parsed.hostname.replace(/^www\./, "");
    const pathname =
      parsed.pathname && parsed.pathname !== "/"
        ? parsed.pathname.replace(/\/$/, "")
        : "";
    return `${hostname}${pathname}`;
  } catch {
    return url
      .replace(/^(https?:\/\/|ftp:\/\/)/i, "")
      .replace(/^www\./i, "")
      .replace(/\/$/, "");
  }
}
