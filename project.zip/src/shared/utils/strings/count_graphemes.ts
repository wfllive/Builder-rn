/**
 * Считает графемы (видимые символы), включая составные эмодзи.
 * Hermes / Hermes-less: Intl.Segmenter может отсутствовать — есть fallback.
 */
export const countGraphemes = (text: string): number => {
  if (!text) return 0;

  if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
    return Array.from(
      new (Intl as unknown as { Segmenter: typeof Intl.Segmenter }).Segmenter(
        undefined,
        { granularity: "grapheme" }
      ).segment(text)
    ).length;
  }

  return Array.from(text).length;
};
