/**
 * Возвращает случайный элемент из массива строк.
 * @throws если массив пустой
 */
export function getRandomString(items: string[]): string {
  if (!items.length) {
    throw new Error("Невозможно выбрать элемент из пустого массива");
  }
  return items[Math.floor(Math.random() * items.length)];
}
