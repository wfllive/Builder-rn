/**
 * Возвращает правильную форму слова в зависимости от числа (русская морфология).
 * @param n - число
 * @param forms - [«1 форма», «2 форма», «5 форма»]
 * @example pluralizeWord(5, ["просмотр", "просмотра", "просмотров"])
 */
export const pluralizeWord = (
  n: number,
  forms: [string, string, string]
): string => {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return forms[0];
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return forms[1];
  return forms[2];
};
