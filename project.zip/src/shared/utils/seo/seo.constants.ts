/**
 * SEO-константы веб-версии.
 *
 * На native SEO не применяется (нет crawler / meta-тегов).
 * Файл оставлен, чтобы импорты из shared не ломались,
 * если команда шарит типы между web и mobile.
 */
export const SEO_SITE_URL = "https://twitblit.ru";
export const SEO_SITE_NAME = "Twitblit";
export const SEO_DEFAULT_TITLE = "Twitblit - Сеть для микроблогинга";
