/**
 * Баррель утилит shared-слоя.
 * Импортировать отсюда, а не из глубоких путей — так проще рефакторить.
 */
export { formatShortNumber } from "./format_short_number";
export { pluralizeWord } from "./pluralize_word";
export { formatFileSize } from "./format_file_size";
export { getRandomString } from "./get_random_string";
export { getRandomInt, getRandomElements, addEasterEgg } from "./random";
export { formatShortDate } from "./datetime/format_short_date";
export { formatLongDate } from "./datetime/format_long_date";
export { currentDate } from "./datetime/get_current_date";
export { subtractTime, addTime } from "./datetime/subtract_time";
export { countGraphemes } from "./strings/count_graphemes";
export { formatPrettyUrl } from "./strings/format_pretty_url";
export { useImageDominantColor } from "./colors/use_image_dominant_color";
export { useImageEdgeGradient } from "./colors/use_image_edge_gradient";
