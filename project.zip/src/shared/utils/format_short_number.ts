/**
 * formatShortNumber
 * ---------------------------------------------------------------
 * Преобразует большое число в короткий читаемый формат:
 * - 1_000 → "1K"
 * - 1_500 → "1.5K"
 * - 1_000_000 → "1M"
 *
 * Порт web-утилиты 1:1 — платформенно независима.
 */
export function formatShortNumber(value: number): string {
  if (value >= 1_000_000_000) {
    return `${(value / 1_000_000_000).toFixed(1).replace(/\.0$/, "")}B`;
  } else if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  } else if (value >= 1_000) {
    return `${(value / 1_000).toFixed(1).replace(/\.0$/, "")}K`;
  }
  return value.toString();
}
