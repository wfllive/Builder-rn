/**
 * Форматирует размер файла в B / KB / MB / GB / TB.
 * Порт web-утилиты, без изменений логики.
 */
export const formatFileSize = (bytes?: string | number): string => {
  if (!bytes) return "0 B";

  const num = typeof bytes === "string" ? parseInt(bytes, 10) : bytes;
  if (isNaN(num) || num <= 0) return "0 B";

  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = num === 0 ? 0 : Math.floor(Math.log(num) / Math.log(1024));
  const value = num / Math.pow(1024, index);

  return `${value.toFixed(2)} ${units[index]}`;
};
