/**
 * Демо-медиа.
 *
 * Локальные jpg отдаём как require()-модуль (число), не как uri.
 * Image.resolveAssetSource в release/EAS часто даёт
 * http://localhost:8081/... — картинка не грузится, белый прямоугольник.
 */
import type { ImageSourcePropType } from "react-native";

export const DEMO_PHOTO_SOURCES = {
  city: require("./assets/demo_city.jpg") as number,
  cat: require("./assets/demo_cat.jpg") as number,
  app: require("./assets/demo_app.jpg") as number,
  park: require("./assets/demo_park.jpg") as number,
  banner: require("./assets/demo_banner.jpg") as number,
};

/** Ключи вложений в моках: demo://city → require. */
export function photoSource(url: string | null | undefined): ImageSourcePropType | undefined {
  if (!url) return undefined;
  if (url.startsWith("demo://")) {
    const key = url.slice("demo://".length) as keyof typeof DEMO_PHOTO_SOURCES;
    return DEMO_PHOTO_SOURCES[key];
  }
  return { uri: url };
}

export const DEMO_PHOTOS = {
  city: "demo://city",
  cat: "demo://cat",
  app: "demo://app",
  park: "demo://park",
  banner: "demo://banner",
};

export const DEMO_AVATARS = {
  twitblit: "https://i.pravatar.cc/200?u=twitblit",
  anya: "https://i.pravatar.cc/200?u=anya-twitblit",
  lesha: "https://i.pravatar.cc/200?u=lesha-twitblit",
  masha: "https://i.pravatar.cc/200?u=masha-twitblit",
  igor: "https://i.pravatar.cc/200?u=igor-twitblit",
  you: "https://i.pravatar.cc/200?u=you-twitblit",
};
