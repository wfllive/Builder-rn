/**
 * Локальные демо-фото для ленты.
 * Shared ждёт строковый file_url — resolveAssetSource даёт uri,
 * который Image в RN открывает без сети.
 */
import { Image } from "react-native";

function uri(mod: number): string {
  return Image.resolveAssetSource(mod).uri;
}

export const DEMO_PHOTOS = {
  city: uri(require("./assets/demo_city.jpg")),
  cat: uri(require("./assets/demo_cat.jpg")),
  app: uri(require("./assets/demo_app.jpg")),
  park: uri(require("./assets/demo_park.jpg")),
  banner: uri(require("./assets/demo_banner.jpg")),
};

export const DEMO_AVATARS = {
  twitblit: "https://i.pravatar.cc/200?u=twitblit",
  anya: "https://i.pravatar.cc/200?u=anya-twitblit",
  lesha: "https://i.pravatar.cc/200?u=lesha-twitblit",
  masha: "https://i.pravatar.cc/200?u=masha-twitblit",
  igor: "https://i.pravatar.cc/200?u=igor-twitblit",
  you: "https://i.pravatar.cc/200?u=you-twitblit",
};
