/**
 * Демо-сессия примера.
 * Не бэкенд: вход, лента, лайки, комментарии, подписки и публикация
 * живут в памяти, чтобы на устройстве всё нажималось.
 */
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { setAuthAdapter, type AuthUser } from "@/adapters/auth";
import { storageGet, storageRemove, storageSet } from "@/adapters/storage";
import type { ThreadData, ThreadUserInfo } from "@/shared/templates/threads/types/thread_data.types";
import { DEMO_AVATARS } from "@/example/demo_media";
import { MOCK_THREADS, MOCK_USERS, findMockUser } from "@/example/mock_threads";

/** Ключ локальной демо-сессии. Не API — только AsyncStorage. */
const DEMO_AUTH_KEY = "twitblit.demo.auth";

export const DEMO_USER: AuthUser = {
  id: 99,
  user_id: "you",
  username: "Вы",
  avatar: DEMO_AVATARS.you,
};

export type DemoComment = {
  id: number;
  author: string;
  authorId: string;
  avatar: string | null;
  text: string;
  createdAt: string;
};

type LikeState = { liked: boolean; count: number };

type DemoSessionValue = {
  isAuth: boolean;
  user: AuthUser | null;
  login: () => void;
  logout: () => void;
  threads: ThreadData[];
  getThread: (id: number) => ThreadData | undefined;
  getUser: (userId: string) => ThreadUserInfo | undefined;
  getUserThreads: (userId: string) => ThreadData[];
  toggleLike: (threadId: number) => void;
  toggleFollow: (userId: string) => void;
  publishThread: (text: string) => ThreadData | null;
  commentsFor: number | null;
  openComments: (threadId: number) => void;
  closeComments: () => void;
  comments: Record<number, DemoComment[]>;
  addComment: (threadId: number, text: string) => void;
  snack: { open: boolean; title: string; message: string };
  showSnack: (title: string, message: string) => void;
  hideSnack: () => void;
  translated: Record<number, boolean>;
  toggleTranslate: (threadId: number) => void;
  authOpen: boolean;
  openAuth: (title?: string, message?: string) => void;
  closeAuth: () => void;
  authCopy: { title: string; message: string };
};

const DemoSessionContext = createContext<DemoSessionValue | null>(null);

const SEED_COMMENTS: Record<number, DemoComment[]> = {
  101: [
    {
      id: 1,
      author: "Аня",
      authorId: "anya",
      avatar: DEMO_AVATARS.anya,
      text: "Красиво легло на native. Таббар уже как на сайте.",
      createdAt: new Date().toISOString(),
    },
    {
      id: 2,
      author: "Лёша",
      authorId: "lesha",
      avatar: DEMO_AVATARS.lesha,
      text: "Аватар справа сверху и вход — то что просили.",
      createdAt: new Date().toISOString(),
    },
  ],
  102: [
    {
      id: 3,
      author: "Twitblit",
      authorId: "twitblit",
      avatar: DEMO_AVATARS.twitblit,
      text: "Shared не должен знать про конкретный экран.",
      createdAt: new Date().toISOString(),
    },
  ],
  103: [
    {
      id: 4,
      author: "Аня",
      authorId: "anya",
      avatar: DEMO_AVATARS.anya,
      text: "replace по табам — правильно.",
      createdAt: new Date().toISOString(),
    },
  ],
};

function seedLikes(items: ThreadData[]): Record<number, LikeState> {
  return Object.fromEntries(items.map((t) => [t.id, { liked: t.is_liked, count: t.likes_count }]));
}

function seedFollows(users: Record<string, ThreadUserInfo>): Record<string, boolean> {
  return Object.fromEntries(Object.values(users).map((u) => [u.user_id, u.followed]));
}

function decorateThread(
  thread: ThreadData,
  likes: Record<number, LikeState>,
  comments: Record<number, DemoComment[]>,
  follows: Record<string, boolean>
): ThreadData {
  const like = likes[thread.id];
  const list = comments[thread.id] ?? [];
  return {
    ...thread,
    is_liked: like?.liked ?? thread.is_liked,
    likes_count: like?.count ?? thread.likes_count,
    comments_count: Math.max(thread.comments_count, list.length),
    preview_comments: list.slice(0, 3).map((c) => ({ username: c.author, avatar: c.avatar })),
    user_info: {
      ...thread.user_info,
      followed: follows[thread.user_info.user_id] ?? thread.user_info.followed,
    },
  };
}

export function DemoSessionProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [rawThreads, setRawThreads] = useState<ThreadData[]>(MOCK_THREADS);
  const [likes, setLikes] = useState<Record<number, LikeState>>(() => seedLikes(MOCK_THREADS));
  const [follows, setFollows] = useState<Record<string, boolean>>(() => seedFollows(MOCK_USERS));
  const [authOpen, setAuthOpen] = useState(false);
  const [authCopy, setAuthCopy] = useState({
    title: "Нужна авторизация",
    message: "Войди, чтобы пользоваться этой функцией",
  });
  const [commentsFor, setCommentsFor] = useState<number | null>(null);
  const [comments, setComments] = useState(SEED_COMMENTS);
  const [snack, setSnack] = useState({ open: false, title: "", message: "" });
  const [translated, setTranslated] = useState<Record<number, boolean>>({});

  const threads = useMemo(
    () => rawThreads.map((t) => decorateThread(t, likes, comments, follows)),
    [comments, follows, likes, rawThreads]
  );

  // После перезапуска приложения гость остаётся «Вы», пока не выйдет.
  useEffect(() => {
    let live = true;
    void storageGet(DEMO_AUTH_KEY).then((raw) => {
      if (!live || raw !== "1") return;
      setUser(DEMO_USER);
    });
    return () => {
      live = false;
    };
  }, []);

  const login = useCallback(() => {
    setUser(DEMO_USER);
    setAuthOpen(false);
    void storageSet(DEMO_AUTH_KEY, "1");
    setSnack({ open: true, title: "Готово", message: "Демо-вход без API. Это Вы." });
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    void storageRemove(DEMO_AUTH_KEY);
    setSnack({ open: true, title: "Вышли", message: "Демо-сессия сброшена." });
  }, []);

  const openAuth = useCallback((title?: string, message?: string) => {
    setAuthCopy({
      title: title ?? "Нужна авторизация",
      message: message ?? "Войди, чтобы пользоваться этой функцией",
    });
    setAuthOpen(true);
  }, []);

  const runWithAuth = useCallback(
    (action: () => void, payload?: { title?: string; message?: string }) => {
      if (user) {
        action();
        return;
      }
      openAuth(payload?.title, payload?.message);
    },
    [openAuth, user]
  );

  useEffect(() => {
    setAuthAdapter({
      isAuth: Boolean(user),
      user,
      runWithAuth,
    });
  }, [runWithAuth, user]);

  const hideSnack = useCallback(() => {
    setSnack((s) => (s.open ? { ...s, open: false } : s));
  }, []);

  const showSnack = useCallback((title: string, message: string) => {
    setSnack({ open: true, title, message });
  }, []);

  const getThread = useCallback((id: number) => threads.find((t) => t.id === id), [threads]);

  const getUser = useCallback(
    (userId: string) => {
      const base = findMockUser(userId);
      if (!base) {
        const fromFeed = threads.find((t) => t.user_info.user_id === userId)?.user_info;
        return fromFeed;
      }
      return { ...base, followed: follows[userId] ?? base.followed };
    },
    [follows, threads]
  );

  const getUserThreads = useCallback(
    (userId: string) => threads.filter((t) => t.user_info.user_id === userId),
    [threads]
  );

  const toggleLike = useCallback(
    (threadId: number) => {
      if (!user) {
        openAuth("Войди, чтобы лайкать", "Демо-лайк доступен после входа.");
        return;
      }
      setLikes((prev) => {
        const cur = prev[threadId] ?? { liked: false, count: 0 };
        const liked = !cur.liked;
        return { ...prev, [threadId]: { liked, count: Math.max(0, cur.count + (liked ? 1 : -1)) } };
      });
    },
    [openAuth, user]
  );

  const toggleFollow = useCallback(
    (userId: string) => {
      if (!user) {
        openAuth("Войди, чтобы подписаться", "Подписка в демо включается после входа.");
        return;
      }
      if (userId === user.user_id) return;
      setFollows((prev) => ({ ...prev, [userId]: !prev[userId] }));
    },
    [openAuth, user]
  );

  const publishThread = useCallback(
    (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || !user) return null;
      const id = Date.now();
      const created: ThreadData = {
        id,
        created_by: user.id,
        topic_by: user.user_id,
        text_twit: trimmed,
        age_category: null,
        blocked: false,
        is_pinned: false,
        is_deleted: false,
        deleted_at: null,
        created_at: new Date().toISOString(),
        attachments: [],
        user_info: {
          ...(findMockUser("you") ?? MOCK_USERS.you),
          username: user.username,
          user_id: user.user_id,
          avatar: user.avatar ?? DEMO_AVATARS.you,
        },
        is_can_edit: true,
        is_liked: false,
        likes_count: 0,
        views_count: 1,
        comments_count: 0,
        preview_comments: [],
      };
      setRawThreads((prev) => [created, ...prev]);
      setLikes((prev) => ({ ...prev, [id]: { liked: false, count: 0 } }));
      setSnack({ open: true, title: "Опубликовано", message: "Тред появился в ленте «Новые»." });
      return created;
    },
    [user]
  );

  const addComment = useCallback(
    (threadId: number, text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;
      if (!user) {
        openAuth("Войди, чтобы комментировать");
        return;
      }
      setComments((prev) => ({
        ...prev,
        [threadId]: [
          ...(prev[threadId] ?? []),
          {
            id: Date.now(),
            author: user.username,
            authorId: user.user_id,
            avatar: user.avatar ?? null,
            text: trimmed,
            createdAt: new Date().toISOString(),
          },
        ],
      }));
    },
    [openAuth, user]
  );

  const value = useMemo<DemoSessionValue>(
    () => ({
      isAuth: Boolean(user),
      user,
      login,
      logout,
      threads,
      getThread,
      getUser,
      getUserThreads,
      toggleLike,
      toggleFollow,
      publishThread,
      commentsFor,
      openComments: (id) => setCommentsFor(id),
      closeComments: () => setCommentsFor(null),
      comments,
      addComment,
      snack,
      showSnack,
      hideSnack,
      translated,
      toggleTranslate: (id) => setTranslated((prev) => ({ ...prev, [id]: !prev[id] })),
      authOpen,
      openAuth,
      closeAuth: () => setAuthOpen(false),
      authCopy,
    }),
    [
      addComment,
      authCopy,
      authOpen,
      comments,
      commentsFor,
      getThread,
      getUser,
      getUserThreads,
      hideSnack,
      login,
      logout,
      openAuth,
      publishThread,
      showSnack,
      snack,
      threads,
      toggleFollow,
      toggleLike,
      translated,
      user,
    ]
  );

  return <DemoSessionContext.Provider value={value}>{children}</DemoSessionContext.Provider>;
}

export function useDemoSession() {
  const ctx = useContext(DemoSessionContext);
  if (!ctx) throw new Error("useDemoSession must be used inside DemoSessionProvider");
  return ctx;
}
