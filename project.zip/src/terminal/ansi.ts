/**
 * ANSI-парсер для терминала
 * Поддерживает:
 *  - SGR (цвет, жирный, italic, подчёркивание, инверсия)
 *  - cursor movement
 *  - clear screen / line
 *  - scroll regions
 *
 * Вывод — плоский массив "ячеек" ScreenCell[] для рендеринга
 */

export type CellAttr = {
  fg?: number;       // 0-15 стандартные, 16-255 палитра, 0xRRGGBB
  bg?: number;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  inverse?: boolean;
  dim?: boolean;
};

export const DEFAULT_ATTR: CellAttr = { fg: 0xe6e6e6, bg: 0x000000 };

export type ScreenCell = {
  ch: string;
  attr: CellAttr;
};

export const COLS_DEFAULT = 100;
export const ROWS_DEFAULT = 40;

const PALETTE_16 = [
  0x000000, 0xcd0000, 0x00cd00, 0xcdcd00,
  0x0000ee, 0xcd00cd, 0x00cdcd, 0xe5e5e5,
  0x7f7f7f, 0xff0000, 0x00ff00, 0xffff00,
  0x5c5cff, 0xff00ff, 0x00ffff, 0xffffff,
];

function build256(rgb: number): number {
  return rgb;
}

function ansiToColor(n: number, isBg = false): number {
  if (n < 16) {
    return isBg ? PALETTE_16[n] : PALETTE_16[n];
  }
  if (n >= 16 && n <= 231) {
    const i = n - 16;
    const r = Math.floor(i / 36);
    const g = Math.floor((i % 36) / 6);
    const b = i % 6;
    const conv = (v: number) => (v === 0 ? 0 : 55 + v * 40);
    return (conv(r) << 16) | (conv(g) << 8) | conv(b);
  }
  // grayscale
  const v = 8 + (n - 232) * 10;
  return (v << 16) | (v << 8) | v;
}

/**
 * ScreenBuffer — двумерный буфер символов с курсором
 */
export class ScreenBuffer {
  cols: number;
  rows: number;
  cells: ScreenCell[][];
  cursor = { row: 0, col: 0 };
  savedCursor = { row: 0, col: 0 };
  currentAttr: CellAttr = { ...DEFAULT_ATTR };
  scrollTop = 0;
  scrollBottom: number;
  // Ответы на запросы терминала (DSR, etc.)
  writeBack: (data: string) => void = () => {};

  constructor(cols = COLS_DEFAULT, rows = ROWS_DEFAULT) {
    this.cols = cols;
    this.rows = rows;
    this.scrollBottom = rows - 1;
    this.cells = Array.from({ length: rows }, () =>
      Array.from({ length: cols }, () => ({ ch: ' ', attr: { ...DEFAULT_ATTR } }))
    );
  }

  resize(cols: number, rows: number) {
    if (cols === this.cols && rows === this.rows) return;
    const newCells: ScreenCell[][] = Array.from({ length: rows }, () =>
      Array.from({ length: cols }, () => ({ ch: ' ', attr: { ...DEFAULT_ATTR } }))
    );
    for (let r = 0; r < Math.min(rows, this.rows); r++) {
      for (let c = 0; c < Math.min(cols, this.cols); c++) {
        newCells[r][c] = this.cells[r][c];
      }
    }
    this.cells = newCells;
    this.cols = cols;
    this.rows = rows;
    this.scrollBottom = rows - 1;
    if (this.cursor.row >= rows) this.cursor.row = rows - 1;
    if (this.cursor.col >= cols) this.cursor.col = cols - 1;
  }

  reset() {
    for (let r = 0; r < this.rows; r++)
      for (let c = 0; c < this.cols; c++)
        this.cells[r][c] = { ch: ' ', attr: { ...DEFAULT_ATTR } };
    this.cursor = { row: 0, col: 0 };
    this.currentAttr = { ...DEFAULT_ATTR };
  }

  private at(row: number, col: number): ScreenCell {
    return this.cells[row][col];
  }

  scrollUp(n = 1) {
    for (let i = 0; i < n; i++) {
      const removed = this.cells.splice(this.scrollTop, 1)[0];
      const empty = Array.from({ length: this.cols }, () => ({
        ch: ' ',
        attr: { ...this.currentAttr, bg: this.currentAttr.bg ?? 0 },
      }));
      this.cells.splice(this.scrollBottom, 0, empty);
      removed; // suppress unused
    }
  }

  scrollDown(n = 1) {
    for (let i = 0; i < n; i++) {
      const empty = Array.from({ length: this.cols }, () => ({
        ch: ' ',
        attr: { ...this.currentAttr, bg: this.currentAttr.bg ?? 0 },
      }));
      this.cells.splice(this.scrollTop, 0, empty);
      this.cells.splice(this.rows, 1);
    }
  }

  putChar(ch: string) {
    if (ch === '\r') {
      this.cursor.col = 0;
      return;
    }
    if (ch === '\n') {
      this.cursor.col = 0;
      this.cursor.row++;
      if (this.cursor.row > this.scrollBottom) {
        this.scrollUp(1);
        this.cursor.row = this.scrollBottom;
      }
      return;
    }
    if (ch === '\b') {
      if (this.cursor.col > 0) this.cursor.col--;
      return;
    }
    if (ch === '\t') {
      const next = Math.floor((this.cursor.col + 8) / 8) * 8;
      this.cursor.col = Math.min(next, this.cols - 1);
      return;
    }
    if (ch === '\x07') return; // bell
    if (ch.charCodeAt(0) < 32) return;

    const cell = this.at(this.cursor.row, this.cursor.col);
    cell.ch = ch;
    cell.attr = { ...this.currentAttr };
    this.cursor.col++;
    if (this.cursor.col >= this.cols) {
      this.cursor.col = 0;
      this.cursor.row++;
      if (this.cursor.row > this.scrollBottom) {
        this.scrollUp(1);
        this.cursor.row = this.scrollBottom;
      }
    }
  }

  clearScreen() {
    for (let r = 0; r < this.rows; r++)
      for (let c = 0; c < this.cols; c++)
        this.cells[r][c] = { ch: ' ', attr: { ...this.currentAttr } };
  }

  clearLine() {
    const r = this.cursor.row;
    for (let c = 0; c < this.cols; c++)
      this.cells[r][c] = { ch: ' ', attr: { ...this.currentAttr } };
  }

  clearLineToEnd() {
    const r = this.cursor.row;
    for (let c = this.cursor.col; c < this.cols; c++)
      this.cells[r][c] = { ch: ' ', attr: { ...this.currentAttr } };
  }

  moveCursor(row: number, col: number) {
    this.cursor.row = Math.max(0, Math.min(this.rows - 1, row));
    this.cursor.col = Math.max(0, Math.min(this.cols - 1, col));
  }

  /**
   * Применить SGR-параметры
   */
  applySGR(params: number[]) {
    let i = 0;
    while (i < params.length) {
      const p = params[i] ?? 0;
      switch (p) {
        case 0: this.currentAttr = { ...DEFAULT_ATTR }; break;
        case 1: this.currentAttr.bold = true; break;
        case 2: this.currentAttr.dim = true; break;
        case 3: this.currentAttr.italic = true; break;
        case 4: this.currentAttr.underline = true; break;
        case 7: this.currentAttr.inverse = true; break;
        case 22: this.currentAttr.bold = false; this.currentAttr.dim = false; break;
        case 23: this.currentAttr.italic = false; break;
        case 24: this.currentAttr.underline = false; break;
        case 27: this.currentAttr.inverse = false; break;
        case 30: case 31: case 32: case 33:
        case 34: case 35: case 36: case 37:
          this.currentAttr.fg = PALETTE_16[p - 30]; break;
        case 39: this.currentAttr.fg = DEFAULT_ATTR.fg; break;
        case 40: case 41: case 42: case 43:
        case 44: case 45: case 46: case 47:
          this.currentAttr.bg = PALETTE_16[p - 40]; break;
        case 49: this.currentAttr.bg = DEFAULT_ATTR.bg; break;
        case 90: case 91: case 92: case 93:
        case 94: case 95: case 96: case 97:
          this.currentAttr.fg = PALETTE_16[p - 90 + 8]; break;
        case 38: {
          // 38;5;N или 38;2;R;G;B
          if (params[i + 1] === 5 && i + 2 < params.length) {
            this.currentAttr.fg = ansiToColor(params[i + 2]);
            i += 2;
          } else if (params[i + 1] === 2 && i + 4 < params.length) {
            const r = params[i + 2];
            const g = params[i + 3];
            const b = params[i + 4];
            this.currentAttr.fg = (r << 16) | (g << 8) | b;
            i += 4;
          }
          break;
        }
        case 48: {
          if (params[i + 1] === 5 && i + 2 < params.length) {
            this.currentAttr.bg = ansiToColor(params[i + 2]);
            i += 2;
          } else if (params[i + 1] === 2 && i + 4 < params.length) {
            const r = params[i + 2];
            const g = params[i + 3];
            const b = params[i + 4];
            this.currentAttr.bg = (r << 16) | (g << 8) | b;
            i += 4;
          }
          break;
        }
      }
      i++;
    }
  }

  /**
   * Обработка CSI-последовательности
   * CSI = ESC [
   * params — массив чисел между [ и конечным символом
   * final — конечный символ (A, B, C, D, H, J, K, m, ...)
   */
  applyCSI(params: number[], final: string) {
    const p = (idx: number, dflt = 1) => params[idx] ?? dflt;
    switch (final) {
      case 'A': this.moveCursor(this.cursor.row - p(0), this.cursor.col); break;
      case 'B': this.moveCursor(this.cursor.row + p(0), this.cursor.col); break;
      case 'C': this.moveCursor(this.cursor.row, this.cursor.col + p(0)); break;
      case 'D': this.moveCursor(this.cursor.row, this.cursor.col - p(0)); break;
      case 'H':
      case 'f': this.moveCursor(p(0) - 1, p(1) - 1); break;
      case 'J':
        if (p(0, 0) === 2) this.clearScreen();
        else if (p(0, 0) === 0) this.clearLineToEnd();
        break;
      case 'K':
        if (p(0, 0) === 0) this.clearLineToEnd();
        else if (p(0, 0) === 2) this.clearLine();
        break;
      case 'm': this.applySGR(params); break;
      case 'r': // DECSTBM — scroll region
        this.scrollTop = Math.max(0, p(0) - 1);
        this.scrollBottom = Math.min(this.rows - 1, p(1) - 1);
        this.moveCursor(0, 0);
        break;
      case 's': this.savedCursor = { ...this.cursor }; break;
      case 'u': this.moveCursor(this.savedCursor.row, this.savedCursor.col); break;
      case 'L': // IL — insert lines
        for (let i = 0; i < p(0); i++) {
          this.cells.splice(this.cursor.row, 0,
            Array.from({ length: this.cols }, () => ({ ch: ' ', attr: { ...this.currentAttr } })));
          this.cells.splice(this.rows, 1);
        }
        break;
      case 'M': // DL — delete lines
        for (let i = 0; i < p(0); i++) {
          this.cells.splice(this.cursor.row, 1);
          this.cells.push(Array.from({ length: this.cols }, () => ({ ch: ' ', attr: { ...this.currentAttr } })));
        }
        break;
      case 'P': // DCH — delete chars
        for (let i = 0; i < p(0); i++) {
          this.cells[this.cursor.row].splice(this.cursor.col, 1);
          this.cells[this.cursor.row].push({ ch: ' ', attr: { ...this.currentAttr } });
        }
        break;
      case 'n': // DSR
        if (p(0) === 5) this.writeBack('\x1b[0n');
        else if (p(0) === 6) this.writeBack(`\x1b[${this.cursor.row + 1};${this.cursor.col + 1}R`);
        break;
    }
  }
}

/**
 * Потоковый ANSI-парсер на вход принимает base64-чанки от нативного моста
 */
export class AnsiParser {
  buffer = '';
  state: 'NORMAL' | 'ESC' | 'CSI' = 'NORMAL';
  csiParams: number[] = [];
  csiCur = '';
  screen: ScreenBuffer;

  constructor(screen: ScreenBuffer) {
    this.screen = screen;
  }

  feed(text: string) {
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      const code = text.charCodeAt(i);

      if (this.state === 'NORMAL') {
        if (ch === '\x1b') {
          this.state = 'ESC';
        } else {
          this.screen.putChar(ch);
        }
      } else if (this.state === 'ESC') {
        if (ch === '[') {
          this.state = 'CSI';
          this.csiParams = [];
          this.csiCur = '';
        } else if (ch === ']') {
          // OSC, skip to BEL or ST
          this.state = 'NORMAL';
          while (i < text.length && text[i] !== '\x07' && text[i] !== '\x1b') i++;
        } else {
          this.state = 'NORMAL';
        }
      } else if (this.state === 'CSI') {
        if (code >= 0x30 && code <= 0x3f) {
          // параметры и промежуточные
          if (ch === ';' || ch === ':') {
            this.csiParams.push(parseInt(this.csiCur) || 0);
            this.csiCur = '';
          } else {
            this.csiCur += ch;
          }
        } else if (code >= 0x40 && code <= 0x7e) {
          // final
          if (this.csiCur) this.csiParams.push(parseInt(this.csiCur) || 0);
          this.screen.applyCSI(this.csiParams, ch);
          this.state = 'NORMAL';
          this.csiParams = [];
          this.csiCur = '';
        }
      }
    }
  }
}
