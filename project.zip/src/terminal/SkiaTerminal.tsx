/**
 * SkiaTerminal — высокопроизводительный рендерер терминала на react-native-skia
 *
 * Оптимизации:
 *  - один Skia Canvas на весь экран
 *  - шрифт monospace, кешируется через Skia.Font
 *  - повторное использование Paint для fg/bg
 *  - используем Group+TextBlob для каждой строки
 *  - skip-optimization: грязные регионы (но пока перерисовываем всё)
 */
import React, { useMemo, useRef, useEffect, useState, useCallback } from 'react';
import { View, StyleSheet, LayoutChangeEvent, Pressable, TextInput } from 'react-native';
import {
  Canvas,
  Group,
  Rect,
  Text,
  useFont,
  matchFont,
  Skia,
  PaintStyle,
  StrokeCap,
} from '@shopify/react-native-skia';
import type { ScreenBuffer, ScreenCell } from './ansi';
import { COLS_DEFAULT, ROWS_DEFAULT } from './ansi';

interface SkiaTerminalProps {
  screen: ScreenBuffer;
  onInput: (text: string) => void;
  onResize: (rows: number, cols: number) => void;
  fontSize?: number;
  padding?: number;
  showCursor?: boolean;
}

const MONO_FONT = {
  fontFamily: 'monospace',
  fontSize: 14,
  fontWeight: 'normal' as const,
};

const PADDING = 8;
const FONT_SIZE_DEFAULT = 14;

export function SkiaTerminal({
  screen,
  onInput,
  onResize,
  fontSize = FONT_SIZE_DEFAULT,
  padding = PADDING,
  showCursor = true,
}: SkiaTerminalProps) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [cursorVisible, setCursorVisible] = useState(true);
  const [tick, setTick] = useState(0); // для cursor blink
  const [selection, setSelection] = useState<{
    startR: number; startC: number; endR: number; endC: number;
  } | null>(null);
  const [imeText, setImeText] = useState('');

  const font = useFont(
    require('../../assets/fonts/JetBrainsMono-Regular.ttf'),
    fontSize
  );

  // Измеряем ширину символа для расчёта cols
  const charWidth = useMemo(() => {
    if (!font) return 0;
    const m = font.measureText('M');
    return m.width;
  }, [font]);

  const lineHeight = useMemo(() => {
    if (!font) return 0;
    return fontSize * 1.2;
  }, [font]);

  // Вычисляем cols/rows при изменении размеров
  useEffect(() => {
    if (!charWidth || !lineHeight) return;
    const usableW = Math.max(0, size.w - padding * 2);
    const usableH = Math.max(0, size.h - padding * 2);
    const cols = Math.max(20, Math.floor(usableW / charWidth));
    const rows = Math.max(10, Math.floor(usableH / lineHeight));
    if (cols !== screen.cols || rows !== screen.rows) {
      screen.resize(cols, rows);
      onResize(rows, cols);
      setTick(t => t + 1);
    }
  }, [size, charWidth, lineHeight]);

  // Cursor blink
  useEffect(() => {
    const id = setInterval(() => setCursorVisible(v => !v), 530);
    return () => clearInterval(id);
  }, []);

  const onLayout = useCallback((e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    setSize({ w: width, h: height });
  }, []);

  // Convert ScreenCell to Skia text runs grouped by attribute
  const renderRows = useMemo(() => {
    if (!font) return null;
    const runs: React.ReactNode[] = [];

    for (let r = 0; r < screen.rows; r++) {
      // Сгруппируем соседние ячейки с одинаковыми атрибутами
      let c = 0;
      while (c < screen.cols) {
        const cell = screen.cells[r][c];
        if (cell.ch === ' ') {
          c++;
          continue;
        }
        // Найдём конец группы с одинаковым атрибутом
        let end = c;
        while (
          end < screen.cols &&
          screen.cells[r][end].attr.fg === cell.attr.fg &&
          screen.cells[r][end].attr.bg === cell.attr.bg &&
          screen.cells[r][end].attr.bold === cell.attr.bold &&
          screen.cells[r][end].ch !== ' '
        ) {
          end++;
        }
        const text = screen.cells[r].slice(c, end).map(x => x.ch).join('');
        const fg = (cell.attr.fg ?? 0xe6e6e6) & 0xffffff;
        const y = padding + (r + 1) * lineHeight - 2;
        const x = padding + c * charWidth;

        // Selection highlight
        let bgPaintColor: number | null = null;
        if (selection) {
          const inSel = isInSelection(r, c, end - 1, selection);
          if (inSel) bgPaintColor = 0x4477cc;
        }
        if (bgPaintColor != null) {
          runs.push(
            <Rect
              key={`bg-${r}-${c}-${tick}`}
              x={x}
              y={padding + r * lineHeight}
              width={(end - c) * charWidth}
              height={lineHeight}
              color={bgPaintColor}
            />
          );
        }

        runs.push(
          <Text
            key={`t-${r}-${c}-${tick}`}
            x={x}
            y={y}
            text={text}
            font={font}
            color={Skia.Color(fg)}
          />
        );
        c = end;
      }
    }
    return runs;
  }, [screen, font, charWidth, lineHeight, padding, tick, selection]);

  // Cursor
  const cursorRect = useMemo(() => {
    if (!showCursor || !cursorVisible) return null;
    return {
      x: padding + screen.cursor.col * charWidth,
      y: padding + screen.cursor.row * lineHeight,
      w: charWidth,
      h: lineHeight,
    };
  }, [screen.cursor, showCursor, cursorVisible, charWidth, lineHeight, padding]);

  // Send key handler
  const sendKey = (data: string) => {
    onInput(data);
  };

  // Touch → calculate cell under finger, then translate to text
  const onTouchText = useCallback(
    (e: any) => {
      const x = e.nativeEvent.locationX;
      const y = e.nativeEvent.locationY;
      const c = Math.floor((x - padding) / charWidth);
      const r = Math.floor((y - padding) / lineHeight);
      if (r < 0 || r >= screen.rows || c < 0 || c >= screen.cols) return;
      setSelection({ startR: r, startC: c, endR: r, endC: c });
    },
    [charWidth, lineHeight, screen.rows, screen.cols]
  );

  return (
    <View style={styles.root} onLayout={onLayout}>
      <Canvas style={StyleSheet.absoluteFill}>
        {/* Background */}
        <Rect x={0} y={0} width={size.w} height={size.h} color={0x0a0a0a} />
        {renderRows}
        {cursorRect && (
          <Rect
            x={cursorRect.x}
            y={cursorRect.y}
            width={cursorRect.w}
            height={cursorRect.h}
            color={0xa0ffa0}
            opacity={0.5}
          />
        )}
      </Canvas>

      {/* Touch overlay (invisible) */}
      <Pressable
        style={StyleSheet.absoluteFill}
        onPress={(e) => onTouchText(e)}
        onLongPress={() => {
          // TODO: выделение текста
        }}
      />

      {/* Скрытый input для IME (для ввода с системной клавиатуры) */}
      <TextInput
        value={imeText}
        onChangeText={(t) => {
          if (t.length > imeText.length) {
            const added = t.slice(imeText.length);
            onInput(added);
          } else if (t.length < imeText.length) {
            const removed = imeText.length - t.length;
            onInput('\b'.repeat(removed));
          }
          setImeText('');
        }}
        autoFocus
        showSoftInputOnFocus
        style={styles.hiddenInput}
        blurOnSubmit={false}
        keyboardAppearance="dark"
        autoCorrect={false}
        autoCapitalize="none"
        caretHidden
      />

      {/* Плавающая клавиатура (опционально) */}
      <VirtualKeyboard onKey={sendKey} />
    </View>
  );
}

function isInSelection(
  r: number, c1: number, c2: number,
  sel: { startR: number; startC: number; endR: number; endC: number }
): boolean {
  if (r < sel.startR || r > sel.endR) return false;
  if (r === sel.startR && r === sel.endR) {
    return c1 <= sel.endC && c2 >= sel.startC;
  }
  if (r === sel.startR) return c2 >= sel.startC;
  if (r === sel.endR) return c1 <= sel.endC;
  return true;
}

/**
 * Виртуальная клавиатура с управляющими клавишами
 * Удобно для ввода Ctrl+C, Esc, стрелок
 */
function VirtualKeyboard({ onKey }: { onKey: (data: string) => void }) {
  const k = (label: string, data: string, wide = false) => (
    <Pressable
      key={label}
      onPress={() => onKey(data)}
      style={({ pressed }) => [
        styles.key,
        wide && styles.keyWide,
        pressed && { backgroundColor: '#3a3a3a' },
      ]}
    >
      <Text style={styles.keyText}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.keyboard} pointerEvents="box-none">
      <View style={styles.kbRow}>
        {k('ESC', '\x1b')}
        {k('TAB', '\t')}
        {k('↑', '\x1b[A')}
        {k('↓', '\x1b[B')}
        {k('←', '\x1b[D')}
        {k('→', '\x1b[C')}
      </View>
      <View style={styles.kbRow}>
        {k('Ctrl+C', '\x03')}
        {k('Ctrl+D', '\x04')}
        {k('Ctrl+L', '\x0c')}
        {k('Ctrl+Z', '\x1a')}
        {k('Enter', '\r', true)}
      </View>
    </View>
  );
}

// Импорт для VirtualKeyboard
import { Text } from 'react-native';

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  hiddenInput: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
    bottom: 0,
    left: 0,
  },
  keyboard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(20,20,20,0.95)',
    paddingVertical: 6,
    borderTopWidth: 1,
    borderTopColor: '#262626',
  },
  kbRow: {
    flexDirection: 'row',
    paddingHorizontal: 4,
  },
  key: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    margin: 2,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#333',
  },
  keyWide: {
    flex: 1.4,
  },
  keyText: {
    color: '#e6e6e6',
    fontFamily: 'monospace',
    fontSize: 12,
    fontWeight: '600',
  },
});
