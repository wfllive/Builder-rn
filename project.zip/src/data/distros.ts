/**
 * Каталог proot-дистрибутивов с прямыми ссылками на GitHub releases
 */

export interface DistroInfo {
  id: string;
  name: string;
  version?: string;
  family: 'debian' | 'ubuntu' | 'arch' | 'fedora' | 'alpine' | 'kali' | 'manjaro' | 'other';
  sizeMB: number;
  description: string;
  /** Прямая ссылка на tar.xz */
  tarballUrl: string;
  arch: Array<'arm64' | 'arm' | 'x86_64' | 'x86'>;
  popularity: number;
  beginnerFriendly: boolean;
  iconEmoji: string;
  postInstall?: string[];
}

const BASE = 'https://github.com/termux/proot-distro/releases/download';

// Хелпер для генерации arm64/arm/x86_64/x86 ссылок
const ub = (id: string) => ({
  arm64: `${BASE}/v4.7.0/${id}-arm64.tar.xz`,
  arm: `${BASE}/v4.7.0/${id}-arm.tar.xz`,
  x86_64: `${BASE}/v4.7.0/${id}-x86_64.tar.xz`,
  x86: `${BASE}/v4.7.0/${id}-i686.tar.xz`,
});

export const DISTROS: DistroInfo[] = [
  {
    id: 'ubuntu',
    name: 'Ubuntu',
    version: '24.04 LTS',
    family: 'ubuntu',
    sizeMB: 380,
    description: 'Самая популярная ОС для разработки. Стабильная, понятная, огромный репозиторий.',
    tarballUrl: ub('ubuntu').arm64,
    arch: ['arm64', 'arm', 'x86_64', 'x86'],
    popularity: 5,
    beginnerFriendly: true,
    iconEmoji: '🟠',
    postInstall: ['apt update', 'apt upgrade -y', 'apt install -y build-essential git curl'],
  },
  {
    id: 'debian',
    name: 'Debian',
    version: '12 (Bookworm)',
    family: 'debian',
    sizeMB: 360,
    description: 'Стабильная классика. Идеальна для серверов, продакшена и обучения.',
    tarballUrl: ub('debian-bookworm').arm64,
    arch: ['arm64', 'arm', 'x86_64', 'x86'],
    popularity: 5,
    beginnerFriendly: true,
    iconEmoji: '🟥',
    postInstall: ['apt update', 'apt upgrade -y'],
  },
  {
    id: 'alpine',
    name: 'Alpine Linux',
    version: '3.20',
    family: 'alpine',
    sizeMB: 45,
    description: 'Минималистичный и быстрый. Отличен для изучения Linux.',
    tarballUrl: ub('alpine').arm64,
    arch: ['arm64', 'arm', 'x86_64', 'x86'],
    popularity: 5,
    beginnerFriendly: true,
    iconEmoji: '🏔️',
    postInstall: ['apk update', 'apk upgrade'],
  },
  {
    id: 'kali',
    name: 'Kali Linux',
    version: 'rolling',
    family: 'kali',
    sizeMB: 850,
    description: 'Пентест, информационная безопасность. Сотни утилит для аудита.',
    tarballUrl: ub('kali').arm64,
    arch: ['arm64', 'arm', 'x86_64', 'x86'],
    popularity: 4,
    beginnerFriendly: false,
    iconEmoji: '🐉',
    postInstall: ['apt update', 'apt upgrade -y'],
  },
  {
    id: 'archlinux',
    name: 'Arch Linux',
    version: 'rolling',
    family: 'arch',
    sizeMB: 290,
    description: 'Bleeding edge. pacman, AUR, минимализм. Для опытных.',
    tarballUrl: ub('archlinux').arm64,
    arch: ['arm64', 'arm'],
    popularity: 3,
    beginnerFriendly: false,
    iconEmoji: '🔵',
    postInstall: ['pacman -Syu --noconfirm'],
  },
  {
    id: 'fedora',
    name: 'Fedora',
    version: '40',
    family: 'fedora',
    sizeMB: 420,
    description: 'Свежие пакеты от Red Hat. dnf, RPM. Современно.',
    tarballUrl: ub('fedora').arm64,
    arch: ['arm64', 'arm', 'x86_64', 'x86'],
    popularity: 3,
    beginnerFriendly: false,
    iconEmoji: '🔷',
    postInstall: ['dnf update -y'],
  },
  {
    id: 'manjaro',
    name: 'Manjaro',
    version: 'rolling',
    family: 'manjaro',
    sizeMB: 410,
    description: 'Arch, но дружелюбный. Хороший баланс новизны и стабильности.',
    tarballUrl: ub('manjaro').arm64,
    arch: ['arm64', 'arm'],
    popularity: 2,
    beginnerFriendly: true,
    iconEmoji: '🟢',
    postInstall: ['pacman -Syu --noconfirm'],
  },
];
