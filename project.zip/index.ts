/**
 * Точка входа Android / iOS (Expo Go).
 * CSS NativeWind, затем Expo Router.
 * gesture-handler / reanimated здесь не импортируем —
 * их ранний init в Expo Go роняет процесс без ошибки.
 */
import "./global.css";
import "expo-router/entry";
