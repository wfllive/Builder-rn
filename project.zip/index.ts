/**
 * Точка входа Android / iOS (собственная сборка, не Expo Go).
 * Порядок важен: gesture-handler → CSS NativeWind → Expo Router.
 */
import "react-native-gesture-handler";
import "./global.css";
import "expo-router/entry";
