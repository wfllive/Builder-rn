/**
 * Точка входа собственной Android / iOS сборки.
 * CSS NativeWind, затем Expo Router.
 * gesture-handler / reanimated здесь не импортируем, чтобы не выполнять
 * их native init до загрузки корневого layout.
 */
import "./global.css";
import "expo-router/entry";
