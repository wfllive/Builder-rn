// это tailwindcss подключиние глобал стиле, чтобы работало
import "./global.css"
/*
тут добавил кастом, чтобы не измнмять там из package.json
main": "expo-router/entry"
*/
import 'expo-router/entry';

 