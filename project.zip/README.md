src/
│
├── app/                      # приложение (сборка всего вместе)
│   ├── navigation/
│   ├── providers/           # redux, query client, theme provider
│   ├── screens/             # экраны
│   └── bootstrap/           # инициализация (fonts, cache, config)
│
├── core/                    # мозг приложения
│   ├── api/                 # работа с сервером
│   │   ├── client.ts
│   │   ├── endpoints/
│   │   └── interceptors/
│   │
│   ├── domain/             # бизнес-сущности
│   │   ├── user/
│   │   ├── post/
│   │   ├── comment/
│   │   └── feed/
│   │
│   ├── services/           # бизнес-логика (feed, auth, etc.)
│   ├── store/              # глобальное состояние (redux/zustand)
│   ├── hooks/              # бизнес-хуки (useFeed, useAuth)
│   └── utils/              # утилиты (formatters, helpers)
│
├── ui/                      # 💥 будущая библиотека компонентов
│   ├── components/
│   │   ├── Button/
│   │   ├── Avatar/
│   │   ├── PostCard/
│   │   └── Input/
│   │
│   ├── layout/
│   ├── theme/
│   ├── icons/
│   └── tokens/
│
├── features/                # фичи (социальная логика)
│   ├── auth/
│   ├── feed/
│   ├── post/
│   ├── profile/
│   └── notifications/
│
└── shared/                  # общее низкоуровневое
    ├── constants/
    ├── types/
    └── config/