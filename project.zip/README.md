# Twitblit Native — Expo 57 + Expo Router + NativeWind

Порт **только** `frontend_twitblit_web/src/shared` в React Native.
Оболочка: **Expo SDK 57** и **Expo Router** (файловый роутинг в `src/app/`).

## Что внутри

```
frontend_twitblit_native/
├── index.ts                         # entry: global.css + expo-router
├── src/
│   ├── app/                         # Expo Router (файлы = маршруты)
│   │   ├── _layout.tsx              # провайдеры + Stack
│   │   ├── index.tsx                # /
│   │   ├── search.tsx               # /search
│   │   ├── create.tsx               # /create
│   │   └── auth/                    # /auth/login, /auth/create-account
│   ├── adapters/                    # storage / navigation (expo-router) / auth
│   ├── example/                     # моки ленты
│   ├── theme/tokens.ts              # JS-зеркало CSS-переменных
│   └── shared/                      # ПОРТ WEB SHARED
│       ├── ui/layout/layout.tsx     # ← ЕДИНСТВЕННЫЙ Layout
│       ├── ui/buttons|data_*|feedback|icons|navigation|typography
│       ├── widgets/                 # хедер, сайдбары, шторки
│       ├── templates/               # провайдеры, треды, профиль
│       └── utils/
```

## Обязательные правила команды

1. **Layout — обычный мобильный, не из web**
   Веб-сетку (колонки, кляксы, сайдбары) не используем.
   ```tsx
   import Layout from "@/shared/ui/layout/layout";
   import FlexibleHeaderMobile from "@/shared/widgets/flexible_header_mobile";

   <Layout
     header={<ScreenHeader />}
     tabBar={<FlexibleHeaderMobile selected="home" />}
   >
     {children}
   </Layout>
   ```
   Слоты: `header` сверху, `children` по центру, `tabBar` снизу. Safe-area учитывается внутри.

2. **Комментарии обязательны.** Каждый файл shared содержит шапку:
   что это, чем отличается от web, как пользоваться.

3. **Никакого `next/navigation`, `localStorage`, `document`.**
   Только адаптеры:
   - `@/adapters/storage`
   - `@/adapters/navigation` (`setAppNavigator`)
   - `@/adapters/auth` (`setAuthAdapter`)

4. **Стили — NativeWind `className` + CSS-переменные темы**
   (`bg-[var(--primary-color)]`), как на вебе.

## Native blur

Шапка и таббар используют `@sbaiahmed1/react-native-blur`:

- iOS — системный `UIVisualEffectView`;
- Android — аппаратный QmBlurView;
- код интеграции — `src/shared/ui/layout/glass_bar.tsx`.

Библиотека работает только с **New Architecture (Fabric)**. Expo Go её не
содержит, поэтому нужен собственный development/release build. После установки
или обновления native-зависимостей пересоберите приложение:

```bash
cd frontend_twitblit_native
npm install
npx expo prebuild --clean
npm run android
# или npm run ios
```

Для iOS после ручной работы с папкой `ios/` выполните `pod install`.
Android требует API 24+ и Android Gradle Plugin 8.9.1+.

Android `applicationId` / namespace: **`ru.twitblit.app`**
(`native` — keyword Java, `ru.twitblit.native` Gradle не соберёт).

## Запуск development build

Веб не поддерживается. Запустите Metro для установленной собственной сборки:

```bash
cd frontend_twitblit_native
npm install
npm start
```

## Иконки

180 MingCute-иконок конвертируются скриптом:

```bash
node scripts/convert_icons.mjs
```

Не править `mingcute/**` руками.

## Что намеренно упрощено

Эти web-виджеты в native — слоты (тяжёлые DOM/canvas/пакеты):

- `FlyVideoPlayer` → подключать `expo-video` в app-слое
- `FlyCropImage` → `expo-image-manipulator`
- `TQrCode` → нативный QR-генератор
- `FlyTextMarkdown` → упрощённый парсер (`**`, `#`)
- `DynamicRender` — антибот-DOM, на native no-op
- `utils/seo/*` — web-only, константы оставлены для совместимости импортов
