# ProotShell

> **Linux-дистрибутивы на Android без Termux.** Самостоятельное приложение
> с встроенным proot-бинарником, настоящим PTY-терминалом и установкой
> rootfs из GitHub.

## 🎯 Что это

Обычный Termux Manager использует `termux://` URL-scheme и требует
установки Termux как отдельного приложения. **ProotShell** идёт
дальше — он упаковывает всё необходимое в свой APK:

| Компонент | Где |
|---|---|
| `proot` (статический бинарь) | `android/app/src/main/assets/proot/proot` |
| `busybox` (для tar и утилит) | `.../proot/busybox` |
| `libtermux-exec.so` (bypass Android 10+ linker) | `.../proot/libtermux-exec.so` |
| RootFS дистрибутивов | `/data/data/com.prootshell.app/files/rootfs/<id>/` |

При старте приложения:
1. **ProotSession.setup()** — извлекает бинарники из assets в `files/proot/`, делает их executable.
2. **ProotSession.installDistro()** — скачивает tar.xz с GitHub releases `termux/proot-distro`, распаковывает через busybox tar.
3. **ProotSession.startSession()** — запускает `proot` через forkpty (native JNI), внутри — `/bin/bash --login`.
4. **Skia-терминал** — рендерит ANSI-вывод 60 FPS, шлёт ввод обратно в PTY.

## 📦 Стек

| Пакет | Версия | Дата |
|---|---|---|
| **Expo SDK** | `57.0.7` | июль 2026 ✅ актуальный |
| **React Native** | `0.86.0` | июнь 2026 |
| **React** | `19.2.3` | — |
| **TypeScript** | `5.9.2` | — |
| **react-native-skia** | `2.9.0` | — |
| **react-native-reanimated** | `4.5.2` | — |
| **react-native-worklets** | `0.11.1` | — |
| **react-navigation** | `7.3.13` | — |
| **zustand** | `5.0.14` | — |
| **New Architecture (Fabric/TurboModules)** | ✅ enabled | — |
| **Android compileSdk** | 36 | — |
| **Android targetSdk** | 36 | — |
| **Android edge-to-edge** | ✅ enabled | — |
| **Min Node.js** | 22.13.x | — |

> **Expo SDK 57** вышел **30 июня 2026** — это «лёгкий» релиз,
> который просто обновляет RN 0.85 → 0.86 (без breaking changes).
> React остался на 19.2.3. Апгрейд с SDK 56 → 57 — одна команда.

## 🏗 Архитектура

```
┌────────────────────────────────────────────────────────┐
│              React Native (JS, RN 0.86)                │
│  HomeScreen / CatalogScreen / DistroListScreen        │
│  TerminalScreen (рендерит SkiaTerminal)                │
│  Zustand store + NativeEventEmitter подписки           │
└────────────────────┬───────────────────────────────────┘
                     │ ProotSession.ts (TypeScript)
                     ▼
┌────────────────────────────────────────────────────────┐
│  ProotSessionModule.java (TurboModule / Classic)      │
│   • setup / startSession / write / resize / kill      │
│   • installDistro (Downloader + busybox tar)          │
│   • listInstalled / removeDistro                      │
│   События: ProotShell:output / exit / installProgress │
└────────────────────┬───────────────────────────────────┘
                     │ использует
                     ▼
┌────────────────────────────────────────────────────────┐
│   ProotExecutor.java — собирает argv                  │
│   proot --link2symlink -b /system -b /dev ...         │
│           -r files/rootfs/ubuntu -w /root -0          │
│           LD_PRELOAD=libtermux-exec.so /bin/bash      │
└────────────────────┬───────────────────────────────────┘
                     │
                     ▼
┌────────────────────────────────────────────────────────┐
│   PtyProcess.java → prootshell-pty.c (JNI)            │
│   openpty() / forkpty() / ioctl(TIOCSWINSZ)           │
└────────────────────┬───────────────────────────────────┘
                     │
                     ▼
┌────────────────────────────────────────────────────────┐
│  /data/data/com.prootshell.app/files/rootfs/ubuntu/   │
│  ├── bin/sh, bin/bash, usr/bin/apt, ...               │
│  └── /etc, /var, /home                                │
└────────────────────────────────────────────────────────┘
```

## 🚀 Сборка

### 1. Подготовка бинарников

```bash
bash scripts/fetch-proot.sh
# Скачивает proot, busybox, libtermux-exec.so
# → android/app/src/main/assets/proot/{proot,busybox,libtermux-exec.so}
```

### 2. Установка зависимостей

```bash
npm install --legacy-peer-deps
# или
npm install
```

### 3. Prebuild (генерация android/)

```bash
npx expo prebuild --platform android --clean
```

### 4. Сборка APK

```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
# → получаете URL, скачиваете .apk, ставите на телефон
```

### Локальная разработка

```bash
npx expo start
# отсканируйте QR в Expo Go (только Android)
# или 'a' для эмулятора
```

## 🖥 Возможности

- 🐧 **Запуск Linux без Termux** — внутри нашего APK
- 📦 **Каталог дистрибутивов** — Ubuntu, Debian, Alpine, Kali, Arch, Manjaro, Fedora
- ⬇ **Установка в 1 клик** — скачивание с GitHub + распаковка через busybox tar
- ▶ **Интерактивный shell** — настоящий PTY с forkpty, без эмуляции
- 🎨 **Skia-терминал** — 60 FPS, ANSI-цвета, 256-цветная палитра, truecolor
- ⌨ **Виртуальная клавиатура** — Ctrl+C/D/Z, Esc, стрелки
- 💾 **Сохранение в песочнице** — `/data/data/com.prootshell.app/files/`
- 🔒 **Без root** — proot с LD_PRELOAD termux-exec

## 📋 Требования к устройству

- Android 7.0+ (API 24+)
- ARM64 / ARM / x86_64
- ~200 МБ свободного места (под rootfs дистрибутивов)
- Интернет для скачивания tar.xz (один раз на дистрибутив)

## 🐛 Известные ограничения

- ❌ Не работает на устройствах с блокировкой exec в `/data/data/...`
- ⚠️ На Android 11+ может потребоваться `pkg install proot` внутри rootfs
- ⚠️ Некоторые syscall-ы (mount, setns) могут не работать

## 📜 Лицензия

MIT
