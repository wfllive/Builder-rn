# MeteoStudio – React Native (Expo SDK 56)

Порт веб-версии MeteoStudio (Vite + Leaflet) → React Native Expo, **без WebView, без Google Maps**.

- **Карта:** `@maplibre/maplibre-react-native` 10.x (MapLibre Native, New Architecture, Expo SDK 56)
- **RN:** 0.85 • **React:** 19.2 • **Expo:** ~56
- **Стили тайлов:** MapTiler (ключ в `constants/config.ts`) + fallback OpenFreeMap (бесплатно, без ключа)
- **Молнии:** HTTP polling `https://meteolive.h1n.ru/strikes.php`
- **Rain radar:** **rainradar.ru** primary (`https://rainradar.ru/composite/manifest.json`) → React Native Skia color-remap (как в web), + RainViewer fallback
- **Alerts:** каркас, готов к подключению реального API
- **AdvRadar (NowCast):** каркас WMS RasterSource, таймлайн готов
- **Wind:** отдельный MapLibre слой + UI панель. Частицы ветра — TODO (требует кастомный native GL / Skia). Без WebView, без MapTiler Weather JS.

## Установка

```bash
cd mobile
npm install
# или yarn / pnpm / bun

# prebuild для нативных модулей (MapLibre требует dev build)
npx expo prebuild

# iOS
npx expo run:ios

# Android
npx expo run:android
```

Expo Go **не поддерживается** (MapLibre Native).

## Структура

```
app/
  _layout.tsx      // MapLibre init, expo-router
  index.tsx        // главный экран
src/
  components/map/LightningMap.tsx
  components/rain/RainTimeline.tsx
  components/advradar/AdvRadarTimeline.tsx
  components/wind/WindOverlay.tsx
  components/ui/*
  components/settings/*
  hooks/
    useLightningStream.ts
    useStrikes.ts
    useRainRadar.ts
    useMeteoAlerts.ts
    useAdvRadar.ts
    useLocation.ts
  store/config.ts  // zustand + SecureStore
  constants/config.ts
  utils/geo.ts
  utils/colors.ts
```

## Фичи

- Молнии на MapLibre (CircleLayer, цвет по возрасту)
- RainViewer радар, таймлайн, прозрачность
- Метеоалерты (маркеры)
- NowCast таймлайн
- Темы карты (dark / light / streets / satellite / topo)
- Геолокация, keep-awake, haptics
- Настройки (life, звук, nearby и т.д.) persist в SecureStore

## Отличия от web

- Rain radar: вместо `rainradar.ru` (canvas color-remap) используется **RainViewer** — готовые цветные тайлы, нативно в MapLibre RasterSource.
- Wind: MapTiler Weather JS SDK не портируется в RN без WebView → показан базовый MapLibre + инфо-панель. Готов хук + UI для будущей интеграции (react-native-skia particles или нативный MapLibre custom layer).
- Google Maps: **нет**. Только MapLibre / OSM / MapTiler.
- WebView: **нет**.

## TODO / идеи

- Wind particles через `react-native-skia` + WebGL / Worklets
- Push-уведомления о близких молниях (expo-notifications настроен)
- Звук грозы (expo-av готов)
- Offline кэш тайлов
- Кластеризация молний при большом зуме-out

MIT
