# Compose Studio — конструктор Android-приложений

Compose Studio создаёт **нативные Android-проекты** на Kotlin, Material 3 и Jetpack Compose. Сам конструктор запускается как Android development build и использует Ubuntu arm64 для Gradle-сборки.

## Возможности

- создание полноценного Gradle Kotlin DSL проекта;
- **код является источником истины**: вы пишете Kotlin-код экрана напрямую в коде-редакторе, и он сохраняется на диск как есть — ничего не перегенерируется и не искажается;
- **профессиональная IDE в стиле VS Code** на движке CodeMirror 6 (офлайн, встроен в приложение): точные темы VS Code Dark+/Light+, подсветка синтаксиса Kotlin, номера строк, подсветка активной строки, сворачивание кода, автозакрытие и подсветка парных скобок;
- **вкладки открытых файлов**, хлебные крошки пути, «грязные» точки несохранённых изменений и синяя строка состояния VS Code (Ln/Col, Spaces, UTF-8, Kotlin) с живым счётчиком проблем;
- **автодополнение**: ключевые слова Kotlin, сниппеты Compose (`Column`, `Scaffold`, `remember`…), слова из документа; поиск/замена по файлу; переход к строке; undo/redo; комментирование строк; панель символов над клавиатурой;
- **проводник файлов проекта** слева (как в VS Code): дерево файлов, открытие и редактирование любого файла проекта — экранов, темы, Gradle, манифеста, строк;
- вкладка **«Редактор»** — код-редактор, вкладка **«Дизайн»** — предпросмотр активного экрана;
- настройка редактора «на лету»: размер шрифта, табуляция и «пробелы вместо табуляции», перенос длинных строк, автосохранение, автодополнение, панель символов, строка состояния;
- управление импортами: редактор находит недостающие `import` и предлагает добавить их одной кнопкой;
- **двухуровневая проверка кода**: мгновенный Compose-aware анализатор (109 проверок в тестовом наборе): баланс скобок и строк с точными позициями; битые объявления; несоответствие типов литералов (`val x: Int = "текст"`, `val f: Float = 1.5`, битые char-литералы); переприсваивание `val` с учётом областей видимости, параметров функций/лямбд и переменных циклов; конфликтующие объявления; путаница **dp/sp** (`fontSize = 16.dp`, `Modifier.size(16.sp)`); присваивание в условии `if (x = true)`; `@Composable` не на функции; вызов composable вне `@Composable`-контекста — включая composable-код внутри `LaunchedEffect`/`onClick` (эффективные и callback-лямбды закрывают composable-контекст, контентные слоты — нет); `remember` внутри условий/циклов; `mutableStateOf` без `remember` (lint UnrememberedMutableState); именование composable-функций (lint FunctionNaming); параметр `modifier` у UI-компонентов (lint ModifierMissing/ModifierParameter); несуществующие именованные параметры у компонентов Material 3; `CompositionLocal` без `.current`; `Toast` без `.show()`; забытые импорты; устаревшие API; опечатки с подсказками «did you mean»; `!!`; импорты Material 2 — подчёркивает ошибки красным, предупреждения жёлтым прямо при наборе;
- **проверка настоящим компилятором**: кнопка «Проверить» запускает `gradlew compileDebugKotlin` в рабочей области proot, разбирает ошибки/предупреждения K2, показывает их как squiggles и в панели «Проблемы» с группировкой по файлам — нажатие открывает файл и ведёт к строке; при включённой автопроверке компилятор также запускается сам после сохранения и в фоне во время редактирования (не чаще раза в 45 с);
- вкладка **«Дизайн»** — живой предпросмотр экрана, отрисовываемый из кода;
- несколько экранов через Navigation Compose;
- Maven/Gradle библиотеки: подключение, разрешение и удаление;
- `assembleDebug`, `assembleRelease`, `bundleRelease`, unit tests и Android Lint;
- установка Debug APK и запуск собранного приложения;
- светлая/тёмная тема интерфейса, русский и английский язык.

## Сгенерированный проект

```text
/root/compose-projects/my-app/
├── settings.gradle.kts
├── build.gradle.kts
├── gradlew
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/app/
            ├── MainActivity.kt
            └── ui/
                ├── screens/*Screen.kt
                └── theme/Theme.kt
```

## Сборка проекта

```bash
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
./gradlew testDebugUnitTest
./gradlew lintDebug
```

Debug APK создаётся в `app/build/outputs/apk/debug/app-debug.apk`.

## Технологии сгенерированных приложений

- Android Gradle Plugin 9.2
- Gradle 9.4.1
- Kotlin / Compose Compiler 2.3.21
- Jetpack Compose BOM 2026.06.00
- Material 3
- Navigation Compose 2.9.8
- compileSdk 37 / targetSdk 36
- JDK 17+

> `@Preview` рендерится Android Studio через Layoutlib. Внутри конструктора макет рендерится **нативно** — теми же Android-виджетами (FrameLayout, LinearLayout, CardView, Material), что и сгенерированный APK, через модуль `apt-manager` (`renderComposePreview`). Это мгновенный preview, который показывает, как именно Android отрендерит дерево компонентов. Для финальной валидации и проверки `@Preview` соберите Debug APK и установите его.

## Запуск самого конструктора

```bash
npm install
npx expo run:android
```

Expo используется только как оболочка **самого конструктора**. Создаваемые пользователем проекты являются обычными нативными Android/Jetpack Compose проектами и не содержат React Native или Expo.
