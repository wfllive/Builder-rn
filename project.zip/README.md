# Twitblit Native — Expo 57 + Expo Router + NativeWind

Порт **только** `frontend_twitblit_web/src/shared` в React Native.
Оболочка: **Expo SDK 57** и **Expo Router** (файловый роутинг в `src/app/`).

## Что внутри

```
frontend_twitblit_native/
├── index.ts                         # entry: gesture-handler + global.css + expo-router
├── src/
│   ├── app/                         # Expo Router (файлы = маршруты)
│   │   ├── _layout.tsx              # провайдеры + Stack
│   │   ├── index.tsx                # /
│   │   ├── search.tsx               # /search
│   │   ├── create.tsx               # /create
│   │   └── auth/                    # /auth/login, /auth/create-account
│   ├── adapters/                    # storage / navigation (expo-router) / auth
│   ├── example/                     # моки ленты
│   ├── theme/tokens.ts              # JS-зеркало CSS-переменных
│   └── shared/                      # ПОРТ WEB SHARED
│       ├── ui/layout/layout.tsx     # ← ЕДИНСТВЕННЫЙ Layout
│       ├── ui/buttons|data_*|feedback|icons|navigation|typography
│       ├── widgets/                 # хедер, сайдбары, шторки
│       ├── templates/               # провайдеры, треды, профиль
│       └── utils/
```

## Обязательные правила команды

1. **Layout — обычный мобильный, не из web**
   Веб-сетку (колонки, кляксы, сайдбары) не используем.
   ```tsx
   import Layout from "@/shared/ui/layout/layout";
   import FlexibleHeaderMobile from "@/shared/widgets/flexible_header_mobile";

   <Layout
     header={<ScreenHeader />}
     tabBar={<FlexibleHeaderMobile selected="home" />}
   >
     {children}
   </Layout>
   ```
   Слоты: `header` сверху, `children` по центру, `tabBar` снизу. Safe-area учитывается внутри.

2. **Комментарии обязательны.** Каждый файл shared содержит шапку:
   что это, чем отличается от web, как пользоваться.

3. **Никакого `next/navigation`, `localStorage`, `document`.**
   Только адаптеры:
   - `@/adapters/storage`
   - `@/adapters/navigation` (`setAppNavigator`)
   - `@/adapters/auth` (`setAuthAdapter`)

4. **Стили — NativeWind `className` + CSS-переменные темы**
   (`bg-[var(--primary-color)]`), как на вебе.

## Стекло — expo-blur

Официальный пакет `expo-blur` (SDK 57). Своего нативного модуля нет.

- iOS: `UIVisualEffectView` (материалы `systemChromeMaterial*`).
- Android: `blurMethod="dimezisBlurView"` + `blurTarget` — контент, который
  размывается, обёрнут в `BlurTargetView`.
- Работает **только в собранном приложении / dev-client**. Внутри Expo Go
  Android-блюра не будет, останется полупрозрачная подложка.

Файлы:

- `src/shared/ui/layout/glass_bar.tsx` — сам бар (шапка / таббар).
- `src/shared/ui/layout/glass_target.tsx` — цель размытия
  (`GlassTargetProvider` + `GlassTargetArea`).

Правила, которые нельзя нарушать:

1. `BlurView` рендерится **после** контента (иначе блюр не обновляется
   над списками — известное ограничение expo-blur).
2. `BlurTarget` не может содержать `BlurView`, который его же размывает —
   бар всегда сиблинг `GlassTargetArea`, а не её ребёнок.
   Вложенные цели разрешены (так сделан `TabScaffold`).

## Сборка APK (без Expo Go)

```bash
cd frontend_twitblit_native
npm install
npx expo prebuild --clean --platform android   # генерирует ./android
cd android && ./gradlew assembleRelease         # APK
```

APK: `android/app/build/outputs/apk/release/app-release.apk`
Отладочный вариант: `./gradlew assembleDebug`.

Через EAS:

```bash
npx eas build -p android --profile preview   # APK
```

Дев-цикл на устройстве:

```bash
npm run android   # expo run:android — ставит dev-client и запускает Metro
npm start         # expo start --dev-client
```

Требуется JDK 17+ и Android SDK (`ANDROID_HOME`). Каталоги `android/` и
`ios/` в git не хранятся — их пересоздаёт `expo prebuild`.

Android `applicationId` / namespace: **`ru.twitblit.app`**
(`native` — keyword Java, `ru.twitblit.native` Gradle не соберёт).

## Иконки

180 MingCute-иконок конвертируются скриптом:

```bash
node scripts/convert_icons.mjs
```

Не править `mingcute/**` руками.

## Что намеренно упрощено

Эти web-виджеты в native — слоты (тяжёлые DOM/canvas/пакеты):

- `FlyVideoPlayer` → подключать `expo-video` в app-слое
- `FlyCropImage` → `expo-image-manipulator`
- `TQrCode` → нативный QR-генератор
- `FlyTextMarkdown` → упрощённый парсер (`**`, `#`)
- `DynamicRender` — антибот-DOM, на native no-op
- `utils/seo/*` — web-only, константы оставлены для совместимости импортов
