# Neon Tic Tac Toe — Expo + React Native + NativeWind

Мобильная версия игры «Неоновые крестики-нолики» на **Expo SDK 56**, **React Native 0.85**, **React 19**, **TypeScript** и **NativeWind**.

## Что внутри

- Главное меню.
- Игра с другом.
- Игра с ИИ:
  - Новичок;
  - Любитель;
  - Эксперт;
  - Невозможный — на поле 3×3 использует minimax.
- Настройки:
  - цвет неона;
  - дневная / ночная / неоновая тема;
  - первый ход;
  - символы;
  - размер поля 3×3, 4×4, 5×5;
  - звук вкл/выкл.
- Современные SVG-иконки через `lucide-react-native`.
- Звуки ходов, победы, ничьей и ошибки через `expo-audio`.
- Haptic feedback через `expo-haptics`.
- Сохранение настроек и счёта через `AsyncStorage`.
- Стилизация через `NativeWind`.

## Запуск

```bash
cd neon-tictactoe-expo
npm install
npm start
```

Дальше можно открыть приложение через Expo Go или запустить на эмуляторе:

```bash
npm run android
npm run ios
```

## Важное

В проекте нет VK Bridge и рекламы. Это чистая Expo-версия. Если нужно, можно следующим шагом добавить рекламу через подходящий SDK под Android/iOS или сделать отдельную WebView/VK Mini Apps-версию.

## Если был Metro 500 / transformFile

В актуальной версии исправлены причины этой ошибки:

- добавлен `babel-preset-expo`;
- добавлен `@babel/core`;
- `nativewind/babel` перенесён в `presets` в `babel.config.js`;
- добавлен `buffer`, который нужен цепочке `lucide-react-native` → `react-native-svg`.

После замены файлов лучше запустить чисто:

```bash
rm -rf node_modules .expo
npm install
npx expo start -c
```

## Основные файлы

- `App.tsx` — вся логика игры и интерфейс.
- `global.css` — подключение Tailwind/NativeWind.
- `tailwind.config.js` — конфигурация NativeWind.
- `babel.config.js` — Babel с `nativewind/babel`.
- `metro.config.js` — Metro с `withNativeWind`.
- `assets/sounds/` — короткие WAV-звуки интерфейса.
