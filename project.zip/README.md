# Compose Studio — визуальный конструктор Jetpack Compose

Compose Studio создаёт **нативные Android-проекты** на Kotlin, Material 3 и Jetpack Compose. Сам конструктор запускается как Android development build и использует Ubuntu arm64 для Gradle-сборки.

## Возможности

- создание полноценного Gradle Kotlin DSL проекта;
- визуальные компоненты `Column`, `Row`, `Box`, `LazyColumn`, `Card`, Material 3;
- перенос компонентов между Compose-контейнерами;
- свойства размеров, цветов, отступов и Material-параметров;
- блочная логика с генерацией настоящего Kotlin-кода;
- автоматическая генерация `@Composable` и `@Preview` функций;
- несколько экранов через Navigation Compose;
- Maven/Gradle библиотеки: подключение, разрешение и удаление;
- `assembleDebug`, `assembleRelease`, `bundleRelease`, unit tests и Android Lint;
- установка Debug APK и запуск собранного приложения;
- светлая/тёмная тема интерфейса, русский и английский язык.

## Сгенерированный проект

```text
/root/compose-projects/my-app/
├── settings.gradle.kts
├── build.gradle.kts
├── gradlew
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/app/
            ├── MainActivity.kt
            └── ui/
                ├── screens/*Screen.kt
                └── theme/Theme.kt
```

## Сборка проекта

```bash
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
./gradlew testDebugUnitTest
./gradlew lintDebug
```

Debug APK создаётся в `app/build/outputs/apk/debug/app-debug.apk`.

## Технологии сгенерированных приложений

- Android Gradle Plugin 9.2
- Gradle 9.4.1
- Kotlin / Compose Compiler 2.3.21
- Jetpack Compose BOM 2026.06.00
- Material 3
- Navigation Compose 2.9.8
- compileSdk 37 / targetSdk 36
- JDK 17+

> `@Preview` рендерится Android Studio через Layoutlib. Внутри конструктора доступен эквивалентный интерактивный макет и исходный Kotlin `@Preview`; для настоящей нативной проверки используется сборка и установка Debug APK.

## Запуск самого конструктора

```bash
npm install
npx expo run:android
```

Expo используется только как оболочка **самого конструктора**. Создаваемые пользователем проекты являются обычными нативными Android/Jetpack Compose проектами и не содержат React Native или Expo.
