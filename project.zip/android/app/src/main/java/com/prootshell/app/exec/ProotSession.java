package com.prootshell.app.exec;

import android.content.Context;
import android.util.Log;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import com.prootshell.app.proot.ProotExecutor;
import com.prootshell.app.pty.PtyProcess;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ProotSessionModule — нативный мост к React Native.
 * Публикует методы:
 *   - setup()                  : инициализация proot
 *   - startSession(id, args)   : запуск сессии в дистрибутиве
 *   - write(id, data)          : записать байты в stdin
 *   - resize(id, rows, cols)   : SIGWINCH
 *   - kill(id)                 : послать сигнал
 *   - listInstalled()          : установленные дистрибутивы
 *   - installDistro(id, url)   : скачать и распаковать
 *   - removeDistro(id)         : удалить
 *
 * События (DeviceEventEmitter):
 *   - ProotShell:output  { sessionId, data: base64 }
 *   - ProotShell:exit    { sessionId, code }
 *   - ProotShell:installProgress { distroId, percent, message }
 */
public class ProotSessionModule extends ReactContextBaseJavaModule {
    private static final String TAG = "ProotSession";
    private static final String NAME = "ProotSession";

    private final ReactApplicationContext reactCtx;
    private final ProotExecutor proot;
    private final ExecutorService ioPool = Executors.newCachedThreadPool();
    private final Map<String, PtyProcess> sessions = new ConcurrentHashMap<>();

    public ProotSessionModule(ReactApplicationContext ctx) {
        super(ctx);
        this.reactCtx = ctx;
        this.proot = new ProotExecutor(ctx);
    }

    @Override
    public String getName() { return NAME; }

    private void emit(String event, WritableMap params) {
        reactCtx.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(event, params);
    }

    // ───────── SETUP ─────────
    @ReactMethod
    public void setup(Promise promise) {
        ioPool.submit(() -> {
            try {
                boolean ok = proot.setup();
                WritableMap res = Arguments.createMap();
                res.putBoolean("ok", ok);
                res.putString("prootDir", proot.getProotDir().getAbsolutePath());
                res.putString("rootfsDir", proot.getRootfsDir().getAbsolutePath());
                promise.resolve(res);
            } catch (Exception e) {
                promise.reject("SETUP_FAIL", e);
            }
        });
    }

    // ───────── START SESSION ─────────
    @ReactMethod
    public void startSession(String sessionId, String distroId, ReadableArray command, int rows, int cols, Promise promise) {
        ioPool.submit(() -> {
            try {
                File rootfs = new File(proot.getRootfsDir(), distroId);
                if (!rootfs.exists() || !new File(rootfs, "bin/sh").exists()) {
                    promise.reject("NOROOTFS", "Rootfs not found: " + rootfs);
                    return;
                }

                // Build command через ProotExecutor
                List<String> argvList = proot.buildCommand(rootfs, null);
                String[] argv = argvList.toArray(new String[0]);

                String[] envv = new String[] {
                    "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                    "HOME=/root",
                    "LANG=C.UTF-8",
                    "TERM=xterm-256color",
                    "USER=root",
                    "SHELL=/bin/bash"
                };

                PtyProcess pty = new PtyProcess();
                pty.start(argv, envv, "/root", rows, cols);
                sessions.put(sessionId, pty);

                WritableMap res = Arguments.createMap();
                res.putInt("pid", pty.getPid());
                res.putString("argv0", argv[0]);
                promise.resolve(res);

                // Запускаем reader в отдельном потоке
                startReader(sessionId, pty);
            } catch (Exception e) {
                Log.e(TAG, "startSession", e);
                promise.reject("START_FAIL", e);
            }
        });
    }

    private void startReader(String sessionId, PtyProcess pty) {
        ioPool.submit(() -> {
            byte[] buf = new byte[8192];
            try {
                int n;
                while ((n = pty.read(buf)) >= 0) {
                    if (n == 0) continue;
                    final byte[] chunk = new byte[n];
                    System.arraycopy(buf, 0, chunk, 0, n);

                    WritableMap params = Arguments.createMap();
                    params.putString("sessionId", sessionId);
                    // base64 для надёжной передачи бинарных данных
                    params.putString("data", android.util.Base64.encodeToString(chunk, android.util.Base64.NO_WRAP));
                    emit("ProotShell:output", params);
                }
            } catch (IOException e) {
                Log.i(TAG, "read closed: " + e.getMessage());
            }
            int code = pty.waitFor();
            sessions.remove(sessionId);
            pty.close();

            WritableMap exitParams = Arguments.createMap();
            exitParams.putString("sessionId", sessionId);
            exitParams.putInt("code", code);
            emit("ProotShell:exit", exitParams);
        });
    }

    // ───────── WRITE ─────────
    @ReactMethod
    public void write(String sessionId, String dataBase64) {
        PtyProcess pty = sessions.get(sessionId);
        if (pty == null) return;
        try {
            byte[] data = android.util.Base64.decode(dataBase64, android.util.Base64.NO_WRAP);
            pty.write(data);
        } catch (Exception e) {
            Log.w(TAG, "write fail: " + e);
        }
    }

    @ReactMethod
    public void writeText(String sessionId, String text) {
        write(sessionId, android.util.Base64.encodeToString(
            text.getBytes(java.nio.charset.StandardCharsets.UTF_8),
            android.util.Base64.NO_WRAP));
    }

    // ───────── RESIZE ─────────
    @ReactMethod
    public void resize(String sessionId, int rows, int cols) {
        PtyProcess pty = sessions.get(sessionId);
        if (pty != null) pty.resize(rows, cols);
    }

    // ───────── SIGNAL ─────────
    @ReactMethod
    public void signal(String sessionId, int sig) {
        PtyProcess pty = sessions.get(sessionId);
        if (pty != null) pty.signal(sig);
    }

    @ReactMethod
    public void kill(String sessionId) {
        PtyProcess pty = sessions.remove(sessionId);
        if (pty != null) {
            pty.signal(15); // SIGTERM
        }
    }

    // ───────── LIST INSTALLED ─────────
    @ReactMethod
    public void listInstalled(Promise promise) {
        ioPool.submit(() -> {
            WritableArray arr = Arguments.createArray();
            File rootfs = proot.getRootfsDir();
            if (rootfs.exists()) {
                File[] children = rootfs.listFiles();
                if (children != null) {
                    for (File d : children) {
                        if (d.isDirectory() && new File(d, "bin/sh").exists()) {
                            WritableMap m = Arguments.createMap();
                            m.putString("id", d.getName());
                            // Размер папки
                            long size = folderSize(d);
                            m.putDouble("sizeMB", size / 1024.0 / 1024.0);
                            m.putString("path", d.getAbsolutePath());
                            m.putDouble("installedAt", 0); // можно хранить в .installed
                            arr.pushMap(m);
                        }
                    }
                }
            }
            promise.resolve(arr);
        });
    }

    private long folderSize(File f) {
        if (f.isFile()) return f.length();
        long s = 0;
        File[] list = f.listFiles();
        if (list == null) return 0;
        for (File c : list) s += folderSize(c);
        return s;
    }

    // ───────── INSTALL DISTRO ─────────
    @ReactMethod
    public void installDistro(String distroId, String tarballUrl, Promise promise) {
        ioPool.submit(() -> {
            try {
                File rootfsDir = proot.getRootfsDir();
                File target = new File(rootfsDir, distroId);
                if (target.exists()) {
                    promise.reject("ALREADY_EXISTS", "Already installed: " + distroId);
                    return;
                }
                target.mkdirs();

                WritableMap p = Arguments.createMap();
                p.putString("distroId", distroId);
                p.putInt("percent", 0);
                p.putString("message", "Скачиваю tar.xz…");
                emit("ProotShell:installProgress", p);

                // 1) Скачиваем во временный файл
                File tmpTar = new File(ctx().getCacheDir(), distroId + ".tar.xz");
                Downloader d = new Downloader();
                File downloaded = d.downloadWithProgress(tarballUrl, tmpTar, (read, total) -> {
                    WritableMap pp = Arguments.createMap();
                    pp.putString("distroId", distroId);
                    int pct = total > 0 ? (int) (read * 100 / total) : 0;
                    pp.putInt("percent", pct);
                    pp.putString("message", "Скачиваю… " + (read / 1024 / 1024) + " МБ");
                    emit("ProotShell:installProgress", pp);
                });

                WritableMap p2 = Arguments.createMap();
                p2.putString("distroId", distroId);
                p2.putInt("percent", 0);
                p2.putString("message", "Распаковываю…");
                emit("ProotShell:installProgress", p2);

                // 2) Распаковываем через нативный tar (или busybox tar)
                File tarBin = new File(proot.getProotDir(), "busybox");
                ProcessBuilder pb = new ProcessBuilder(
                    tarBin.getAbsolutePath(), "tar", "-xJf", downloaded.getAbsolutePath(),
                    "-C", target.getAbsolutePath());
                pb.redirectErrorStream(true);
                Process proc = pb.start();
                proc.waitFor();

                downloaded.delete();

                WritableMap p3 = Arguments.createMap();
                p3.putString("distroId", distroId);
                p3.putInt("percent", 100);
                p3.putString("message", "Готово ✓");
                emit("ProotShell:installProgress", p3);

                // Записываем метаданные
                File meta = new File(target, ".prootshell-meta");
                try (java.io.FileWriter w = new java.io.FileWriter(meta)) {
                    w.write("installedAt=" + System.currentTimeMillis() + "\n");
                    w.write("tarball=" + tarballUrl + "\n");
                }

                WritableMap res = Arguments.createMap();
                res.putBoolean("ok", true);
                res.putString("path", target.getAbsolutePath());
                promise.resolve(res);
            } catch (Exception e) {
                Log.e(TAG, "installDistro", e);
                promise.reject("INSTALL_FAIL", e);
            }
        });
    }

    // ───────── REMOVE ─────────
    @ReactMethod
    public void removeDistro(String distroId, Promise promise) {
        ioPool.submit(() -> {
            File target = new File(proot.getRootfsDir(), distroId);
            if (!target.exists()) {
                promise.reject("NOT_FOUND", "Not installed: " + distroId);
                return;
            }
            // Рекурсивное удаление
            deleteRecursive(target);
            WritableMap r = Arguments.createMap();
            r.putBoolean("ok", true);
            promise.resolve(r);
        });
    }

    private void deleteRecursive(File f) {
        if (f.isDirectory()) {
            File[] list = f.listFiles();
            if (list != null) for (File c : list) deleteRecursive(c);
        }
        f.delete();
    }

    private ReactApplicationContext ctx() { return getReactApplicationContext(); }
}
