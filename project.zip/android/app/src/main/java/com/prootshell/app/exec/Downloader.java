
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Downloader — простой загрузчик файлов с прогрессом
 */
public class Downloader {
    public interface Progress {
        void onProgress(long read, long total);
    }

    public File downloadWithProgress(String urlStr, File target, Progress cb) throws Exception {
        URL u = new URL(urlStr);
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "ProotShell/1.0");
        c.connect();

        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String loc = c.getHeaderField("Location");
            if (loc != null) {
                c.disconnect();
                return downloadWithProgress(loc, target, cb);
            }
        }
        if (code != 200) throw new RuntimeException("HTTP " + code + " for " + urlStr);

        long total = c.getContentLengthLong();
        try (InputStream in = c.getInputStream();
             FileOutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[64 * 1024];
            long read = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                read += n;
                if (cb != null) cb.onProgress(read, total);
            }
        }
        c.disconnect();
        return target;
    }
}
