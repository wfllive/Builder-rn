
import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * ProotExecutor — загрузка и извлечение proot-бинарника из assets
 *
 * Стратегия:
 *  1. Извлекаем proot, libtermux-exec.so, busybox из assets/proot/ в files/proot/
 *  2. Делаем их исполняемыми
 *  3. При вызове setup() кладём LD_PRELOAD с termux-exec, чтобы обойти
 *     Android 10+ linker restrictions (allow executable bionic).
 *
 * Этот подход повторяет внутренности Termux:TermuxApplication, но
 * без зависимости от пакета com.termux.
 */
public class ProotExecutor {
    private static final String TAG = "ProotExecutor";
    private static final String PROOT_DIR = "proot";
    private static final String BIN_PROOT = "proot";
    private static final String LIB_EXEC = "libtermux-exec.so";
    private static final String BIN_BUSYBOX = "busybox";

    private final Context ctx;
    private File prootDir;
    private File prootBin;
    private File busyboxBin;
    private File termuxExecLib;
    private boolean initialized = false;

    public ProotExecutor(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public synchronized boolean setup() throws IOException {
        if (initialized) return true;

        prootDir = new File(ctx.getFilesDir(), PROOT_DIR);
        if (!prootDir.exists()) prootDir.mkdirs();

        prootBin = new File(prootDir, BIN_PROOT);
        busyboxBin = new File(prootDir, BIN_BUSYBOX);
        termuxExecLib = new File(prootDir, LIB_EXEC);

        // Извлекаем из assets если их нет
        extractIfMissing("proot/proot", prootBin);
        extractIfMissing("proot/busybox", busyboxBin);
        extractIfMissing("proot/" + LIB_EXEC, termuxExecLib);

        // Делаем исполняемыми
        setExecutable(prootBin);
        setExecutable(busyboxBin);
        // .so не делаем executable (это библиотека)

        initialized = true;
        Log.i(TAG, "proot dir: " + prootDir.getAbsolutePath());
        return true;
    }

    private void extractIfMissing(String assetPath, File target) throws IOException {
        if (target.exists() && target.length() > 0) return;
        try (InputStream in = ctx.getAssets().open(assetPath);
             OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        Log.i(TAG, "extracted: " + assetPath + " -> " + target.getAbsolutePath());
    }

    private void setExecutable(File f) {
        if (!f.setExecutable(true, false)) {
            Log.w(TAG, "setExecutable failed for " + f);
        }
    }

    /**
     * Строит команду запуска proot-distro-style сессии
     * @param rootfs путь к корневой ФС дистрибутива (например files/rootfs/ubuntu)
     * @param command команда (например "/bin/bash", или null для login shell)
     */
    public List<String> buildCommand(File rootfs, String command) {
        List<String> cmd = new ArrayList<>();
        cmd.add(prootBin.getAbsolutePath());

        // Linker bypass: подгружаем termux-exec.so через LD_PRELOAD
        // Это эквивалент того, что делает Termux, чтобы обойти
        // Android 10+ restrictions on non-system linker.
        cmd.add("--link2symlink");

        // Bind /system, /dev, /proc из реальной системы
        cmd.add("-b");
        cmd.add("/system");
        cmd.add("-b");
        cmd.add("/dev");
        cmd.add("-b");
        cmd.add("/proc");
        cmd.add("-b");
        cmd.add("/sys");
        cmd.add("-b");
        cmd.add("/data/data/com.prootshell.app/files/rootfs");
        cmd.add("-b");
        cmd.add("/sdcard");

        // Env
        cmd.add("-r");
        cmd.add(rootfs.getAbsolutePath());

        // Wait for debian/ubuntu multiarch mounts
        cmd.add("-w");
        cmd.add("/root");

        // PATH внутри rootfs
        cmd.add("-0");

        // env vars
        cmd.add("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");
        cmd.add("HOME=/root");
        cmd.add("LANG=C.UTF-8");
        cmd.add("TERM=xterm-256color");
        cmd.add("USER=root");
        cmd.add("SHELL=/bin/bash");

        // ld preload for proc
        cmd.add("LD_PRELOAD=" + termuxExecLib.getAbsolutePath());

        if (command != null && !command.isEmpty()) {
            cmd.add("--");
            cmd.add(command);
        } else {
            cmd.add("--");
            cmd.add("/bin/bash");
            cmd.add("--login");
        }
        return cmd;
    }

    public File getRootfsDir() {
        return new File(ctx.getFilesDir(), "rootfs");
    }

    public File getProotDir() {
        return prootDir;
    }
}
