package com.prootshell.app.pty;

import android.util.Log;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

/**
 * PtyProcess — обёртка над UNIX PTY (pseudo-terminal) для запуска
 * произвольного процесса с интерактивным вводом/выводом.
 *
 * Использует нативные вызовы через JNI (openpty, forkpty из util.h).
 * На Android ≥ 5 эти вызовы доступны в libutil.so, но termux-exec
 * (LD_PRELOAD) перехватывает fork/exec и позволяет корректно
 * работать в песочнице.
 */
public class PtyProcess {
    private static final String TAG = "PtyProcess";

    static {
        // Наша JNI-библиотека
        System.loadLibrary("prootshell-pty");
    }

    // Нативные методы (объявлены в prootshell-pty.c)
    private native int nativeOpenPty(int rows, int cols);
    private native int nativeForkExec(String[] argv, String[] envv, String cwd, int ptyFd);
    private native int nativeSetPtySize(int ptyFd, int rows, int cols);
    private native void nativeClosePty(int ptyFd);
    private native int nativeWaitPid(int pid);

    private int masterFd = -1;
    private int pid = -1;
    private InputStream inputStream;
    private OutputStream outputStream;

    /**
     * Запускает процесс под PTY
     * @param argv  argv[0] — путь к бинарю
     * @param envv  переменные окружения
     * @param cwd   рабочая директория
     * @param rows  строки
     * @param cols  колонки
     */
    public void start(String[] argv, String[] envv, String cwd, int rows, int cols) throws IOException {
        if (masterFd != -1) {
            throw new IllegalStateException("Pty already started");
        }
        // Открываем master-сторону PTY
        masterFd = nativeOpenPty(rows, cols);
        if (masterFd < 0) {
            throw new IOException("openpty failed: " + masterFd);
        }
        // fork+execve в child со slave-стороной PTY как stdin/stdout/stderr
        pid = nativeForkExec(argv, envv, cwd, masterFd);
        if (pid < 0) {
            nativeClosePty(masterFd);
            masterFd = -1;
            throw new IOException("forkpty failed: " + pid);
        }
        FileDescriptor fd = new FileDescriptor();
        // Установим descriptor (используем reflection)
        try {
            java.lang.reflect.Field f = FileDescriptor.class.getDeclaredField("fd");
            f.setAccessible(true);
            f.set(fd, masterFd);
        } catch (Throwable t) {
            Log.w(TAG, "fd reflection failed: " + t);
        }
        inputStream = new FileInputStream(fd);
        outputStream = new FileOutputStream(fd);
    }

    public InputStream getInputStream() { return inputStream; }
    public OutputStream getOutputStream() { return outputStream; }
    public int getPid() { return pid; }

    public void resize(int rows, int cols) {
        if (masterFd >= 0) {
            nativeSetPtySize(masterFd, rows, cols);
        }
    }

    /**
     * Читает сырые байты из PTY. Неблокирующий — если данных нет, вернёт -1.
     */
    public int read(byte[] buf) throws IOException {
        if (inputStream == null) return -1;
        return inputStream.read(buf);
    }

    public void write(byte[] data) throws IOException {
        if (outputStream == null) return;
        outputStream.write(data);
        outputStream.flush();
    }

    /**
     * Отправляет сигнал процессу
     */
    public void signal(int sig) {
        if (pid > 0) {
            android.os.Process.sendSignal(pid, sig);
        }
    }

    /**
     * Ожидание завершения процесса
     */
    public int waitFor() {
        if (pid <= 0) return -1;
        return nativeWaitPid(pid);
    }

    public void close() {
        try { if (inputStream != null) inputStream.close(); } catch (Exception ignored) {}
        try { if (outputStream != null) outputStream.close(); } catch (Exception ignored) {}
        if (masterFd >= 0) {
            nativeClosePty(masterFd);
            masterFd = -1;
        }
        pid = -1;
    }
}
