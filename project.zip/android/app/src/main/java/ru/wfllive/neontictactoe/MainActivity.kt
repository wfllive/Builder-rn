package ru.wfllive.neontictactoe

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager

import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

import expo.modules.ReactActivityDelegateWrapper

class MainActivity : ReactActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    setTheme(R.style.AppTheme)
    super.onCreate(null)
    applySystemBars()
  }

  private fun applySystemBars() {
    val color = Color.parseColor("#0f172a")

    // Убираем флаги прозрачности
    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)

    // Включаем рисование системных баров
    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)

    // Ставим цвет
    window.statusBarColor = color
    window.navigationBarColor = color

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      // Android 11+ — светлые иконки на тёмном фоне
      window.insetsController?.let { ctrl ->
        ctrl.setSystemBarsAppearance(0,
          android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS)
        ctrl.setSystemBarsAppearance(0,
          android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS)
      }
    } else {
      // Android 6-10
      @Suppress("DEPRECATION")
      window.decorView.systemUiVisibility = 0
    }
  }

  override fun getMainComponentName(): String = "main"

  override fun createReactActivityDelegate(): ReactActivityDelegate {
    return ReactActivityDelegateWrapper(
      this,
      BuildConfig.IS_NEW_ARCHITECTURE_ENABLED,
      object : DefaultReactActivityDelegate(
        this,
        mainComponentName,
        fabricEnabled
      ) {}
    )
  }

  override fun invokeDefaultOnBackPressed() {
    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
      if (!moveTaskToBack(false)) {
        super.invokeDefaultOnBackPressed()
      }
      return
    }
    super.invokeDefaultOnBackPressed()
  }
}