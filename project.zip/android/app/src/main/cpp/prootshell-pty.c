/*
 * prootshell-pty.c — JNI мост к UNIX PTY
 *
 * Использует:
 *  - openpty() из util.h
 *  - forkpty() — fork + подключение slave-стороны к stdin/stdout/stderr
 *  - execve() — запуск бинаря
 *  - ioctl(TIOCSWINSZ) — изменение размера PTY
 *
 * termux-exec (LD_PRELOAD в proot) перехватывает fork/exec/clone,
 * чтобы обойти Android 10+ seccomp restrictions.
 */
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <termios.h>
#include <util.h>      // openpty, forkpty
#include <pty.h>       // openpty, forkpty

// ─── helpers ───────────────────────────────────────────────

static jint throw(JNIEnv *env, const char* msg) {
    jclass cls = (*env)->FindClass(env, "java/lang/RuntimeException");
    (*env)->ThrowNew(env, cls, msg);
    return -1;
}

static char** jstrarr_to_cstrarr(JNIEnv *env, jobjectArray jarr, int* outLen) {
    int len = (*env)->GetArrayLength(env, jarr);
    char** arr = (char**) calloc(len + 1, sizeof(char*));
    for (int i = 0; i < len; i++) {
        jstring s = (jstring) (*env)->GetObjectArrayElement(env, jarr, i);
        const char* c = (*env)->GetStringUTFChars(env, s, NULL);
        arr[i] = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    arr[len] = NULL;
    *outLen = len;
    return arr;
}

static void free_cstrarr(char** arr, int len) {
    for (int i = 0; i < len; i++) free(arr[i]);
    free(arr);
}

// ─── nativeOpenPty ─────────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeOpenPty(JNIEnv *env, jobject thiz, jint rows, jint cols) {
    int master_fd = -1;
    struct winsize ws;
    ws.ws_row = rows > 0 ? rows : 24;
    ws.ws_col = cols > 0 ? cols : 80;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;

    if (openpty(&master_fd, NULL, NULL, NULL, &ws) < 0) {
        return throw(env, "openpty failed");
    }
    // Делаем master неблокирующим
    int flags = fcntl(master_fd, F_GETFL, 0);
    fcntl(master_fd, F_SETFL, flags | O_NONBLOCK);
    return master_fd;
}

// ─── nativeForkExec ────────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeForkExec(JNIEnv *env, jobject thiz,
        jobjectArray jargv, jobjectArray jenvv, jstring jcwd, jint pty_fd) {
    int argc, envc;
    char** argv = jstrarr_to_cstrarr(env, jargv, &argc);
    char** envp = jstrarr_to_cstrarr(env, jenvv, &envc);
    const char* cwd = jcwd ? (*env)->GetStringUTFChars(env, jcwd, NULL) : "/";

    // Открываем slave-сторону PTY для child
    // (openpty создал пару, slave fd узнаём через ttyname или передаём ioctl)
    // Простой путь: используем forkpty
    int master_fd = pty_fd;

    pid_t pid = fork();
    if (pid < 0) {
        free_cstrarr(argv, argc);
        free_cstrarr(envp, envc);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return throw(env, "fork failed");
    }
    if (pid == 0) {
        // CHILD
        // Открываем slave-сторону
        char slave_path[256];
        // Получаем имя slave через /proc/self/fd
        snprintf(slave_path, sizeof(slave_path), "/proc/self/fd/%d", master_fd);
        int slave_fd = open(slave_path, O_RDWR);
        if (slave_fd < 0) _exit(127);

        // Создаём новую сессию
        setsid();
        if (ioctl(slave_fd, TIOCSCTTY, 0) < 0) {
            // ignore
        }

        // Dup slave в 0, 1, 2
        dup2(slave_fd, 0);
        dup2(slave_fd, 1);
        dup2(slave_fd, 2);
        if (slave_fd > 2) close(slave_fd);
        close(master_fd);

        if (cwd && chdir(cwd) < 0) {
            // ignore chdir fail
        }

        execve(argv[0], argv, envp);
        // exec failed
        fprintf(stderr, "execve failed: %s\n", strerror(errno));
        _exit(127);
    }

    // PARENT
    free_cstrarr(argv, argc);
    free_cstrarr(envp, envc);
    (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
    return (jint) pid;
}

// ─── nativeSetPtySize ──────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeSetPtySize(JNIEnv *env, jobject thiz,
        jint pty_fd, jint rows, jint cols) {
    struct winsize ws;
    ws.ws_row = rows;
    ws.ws_col = cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;
    if (ioctl(pty_fd, TIOCSWINSZ, &ws) < 0) {
        return -1;
    }
    return 0;
}

// ─── nativeClosePty ────────────────────────────────────────

JNIEXPORT void JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeClosePty(JNIEnv *env, jobject thiz, jint pty_fd) {
    if (pty_fd >= 0) close(pty_fd);
}

// ─── nativeWaitPid ─────────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeWaitPid(JNIEnv *env, jobject thiz, jint pid) {
    int status = 0;
    if (waitpid(pid, &status, WUNTRACED) < 0) {
        return -1;
    }
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return 0;
}
