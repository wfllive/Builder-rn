/*
 * prootshell-pty.c — JNI мост к UNIX PTY
 *
 * Реализация НЕ использует openpty()/forkpty() (которые требуют libutil,
 * отсутствующий в Android NDK 27+).
 *
 * Вместо этого используем стандартный для Android подход:
 *   1. Открываем /dev/ptmx (master side псевдо-терминала)
 *   2. Через grantpt/unlockpt/ptsname получаем slave-имя
 *   3. Открываем slave как обычный файл
 *   4. В child-процессе: dup2 slave в 0,1,2 + setsid + ioctl(TIOCSCTTY)
 *   5. execve() запускает процесс
 *
 * Термиос-операции (ioctl TCGETS/TCSETS/TIOCSWINSZ) работают напрямую.
 */
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <termios.h>

#ifndef HAVE_PTSNAME_R
// На некоторых NDK ptsname_r может отсутствовать, но ptsname() есть всегда
#endif

// ─── helpers ───────────────────────────────────────────────

static jint throw(JNIEnv *env, const char* msg) {
    jclass cls = (*env)->FindClass(env, "java/lang/RuntimeException");
    (*env)->ThrowNew(env, cls, msg);
    return -1;
}

static char** jstrarr_to_cstrarr(JNIEnv *env, jobjectArray jarr, int* outLen) {
    int len = (*env)->GetArrayLength(env, jarr);
    char** arr = (char**) calloc(len + 1, sizeof(char*));
    for (int i = 0; i < len; i++) {
        jstring s = (jstring) (*env)->GetObjectArrayElement(env, jarr, i);
        const char* c = (*env)->GetStringUTFChars(env, s, NULL);
        arr[i] = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    arr[len] = NULL;
    *outLen = len;
    return arr;
}

static void free_cstrarr(char** arr, int len) {
    for (int i = 0; i < len; i++) free(arr[i]);
    free(arr);
}

// ─── nativeOpenPty ─────────────────────────────────────────

/*
 * Открывает master-сторону псевдо-терминала.
 * Возвращает fd или -1 при ошибке.
 */
JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeOpenPty(JNIEnv *env, jobject thiz, jint rows, jint cols) {
    int master_fd = -1;

    // Открываем /dev/ptmx — это master-сторона любого PTY в Linux/Android
    master_fd = open("/dev/ptmx", O_RDWR | O_NOCTTY);
    if (master_fd < 0) {
        return throw(env, "open /dev/ptmx failed");
    }

    // Устанавливаем размер окна
    struct winsize ws;
    ws.ws_row = rows > 0 ? rows : 24;
    ws.ws_col = cols > 0 ? cols : 80;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;
    if (ioctl(master_fd, TIOCSWINSZ, &ws) < 0) {
        // Не критично, продолжаем
    }

    // Делаем master неблокирующим
    int flags = fcntl(master_fd, F_GETFL, 0);
    fcntl(master_fd, F_SETFL, flags | O_NONBLOCK);

    return master_fd;
}

// ─── nativeForkExec ────────────────────────────────────────

/*
 * Вспомогательная функция: открывает slave-сторону PTY по имени.
 */
static int open_slave_by_pty_name(int master_fd) {
    // Получаем имя slave-стороны (например /dev/pts/0)
    char slave_name[256];
    if (ptsname_r(master_fd, slave_name, sizeof(slave_name)) != 0) {
        // Fallback на не-thread-safe версию
        const char* name = ptsname(master_fd);
        if (name == NULL) return -1;
        strncpy(slave_name, name, sizeof(slave_name) - 1);
        slave_name[sizeof(slave_name) - 1] = '\0';
    }

    // Разблокируем slave (стандартная процедура для Unix98 PTY)
    if (unlockpt(master_fd) < 0) return -1;
    if (grantpt(master_fd) < 0) return -1;

    // Открываем slave
    int slave_fd = open(slave_name, O_RDWR);
    return slave_fd;
}

/*
 * Создаёт child-процесс и подключает slave-сторону PTY к его stdin/stdout/stderr.
 * @param argv    argv[0] — путь к бинарю
 * @param envv    переменные окружения
 * @param cwd     рабочая директория
 * @param pty_fd  master-сторона PTY (уже открытая)
 * Возвращает PID child-процесса или -1 при ошибке.
 */
JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeForkExec(JNIEnv *env, jobject thiz,
        jobjectArray jargv, jobjectArray jenvv, jstring jcwd, jint pty_fd) {
    int argc, envc;
    char** argv = jstrarr_to_cstrarr(env, jargv, &argc);
    char** envp = jstrarr_to_cstrarr(env, jenvv, &envc);
    const char* cwd = jcwd ? (*env)->GetStringUTFChars(env, jcwd, NULL) : "/";

    // Открываем slave-сторону ДО fork
    int slave_fd = open_slave_by_pty_name(pty_fd);
    if (slave_fd < 0) {
        free_cstrarr(argv, argc);
        free_cstrarr(envp, envc);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return throw(env, "open slave PTY failed");
    }

    pid_t pid = fork();
    if (pid < 0) {
        close(slave_fd);
        free_cstrarr(argv, argc);
        free_cstrarr(envp, envc);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return throw(env, "fork failed");
    }

    if (pid == 0) {
        // CHILD PROCESS
        // Создаём новую сессию (отсоединяем от controlling terminal родителя)
        setsid();

        // Устанавливаем slave как controlling terminal
        if (ioctl(slave_fd, TIOCSCTTY, 0) < 0) {
            // Игнорируем — для некоторых PTY это OK
        }

        // Dup slave в 0, 1, 2
        dup2(slave_fd, 0);
        dup2(slave_fd, 1);
        dup2(slave_fd, 2);
        if (slave_fd > 2) close(slave_fd);
        // Master в child не нужен
        close(pty_fd);

        if (cwd && chdir(cwd) < 0) {
            // Не критично
        }

        // Запускаем процесс
        execve(argv[0], argv, envp);
        // Если execve вернулся — ошибка
        fprintf(stderr, "execve failed: %s\n", strerror(errno));
        _exit(127);
    }

    // PARENT
    // Закрываем slave в родителе — у нас есть только master
    close(slave_fd);

    free_cstrarr(argv, argc);
    free_cstrarr(envp, envc);
    (*env)->ReleaseStringUTFChars(env, jcwd, cwd);

    return (jint) pid;
}

// ─── nativeSetPtySize ──────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeSetPtySize(JNIEnv *env, jobject thiz,
        jint pty_fd, jint rows, jint cols) {
    struct winsize ws;
    ws.ws_row = rows;
    ws.ws_col = cols;
    ws.ws_xpixel = 0;
    ws.ws_ypixel = 0;
    if (ioctl(pty_fd, TIOCSWINSZ, &ws) < 0) {
        return -1;
    }
    return 0;
}

// ─── nativeClosePty ────────────────────────────────────────

JNIEXPORT void JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeClosePty(JNIEnv *env, jobject thiz, jint pty_fd) {
    if (pty_fd >= 0) close(pty_fd);
}

// ─── nativeWaitPid ─────────────────────────────────────────

JNIEXPORT jint JNICALL
Java_com_prootshell_app_pty_PtyProcess_nativeWaitPid(JNIEnv *env, jobject thiz, jint pid) {
    int status = 0;
    if (waitpid(pid, &status, WUNTRACED) < 0) {
        return -1;
    }
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return 0;
}
