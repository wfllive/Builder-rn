# Терминал (Termux engine) — переделка по образцу AndroidIDE

Терминал в приложении полностью переделан. Использован тот же движок, что и в
[AndroidIDE](https://github.com/AndroidIDEOfficial/AndroidIDE) / Termux
(`terminal-emulator` + `terminal-view`), но вокруг него построена правильная обёртка,
которой раньше не хватало.

## Что было не так раньше

- Нативный `TerminalView` подключался «голым», без строки специальных клавиш.
- Клиенты (`TerminalViewClient` / `TerminalSessionClient`) были заглушками:
  `readControlKey()/readAltKey()` всегда возвращали `false`, не было обработки
  `Ctrl+C`, `Tab`, стрелок, `Esc`.
- `getTerminalCursorStyle()` возвращал `null`, не было clipboard / bell.
- Сессия жёстко запускала `/system/bin/sh` с хрупким копированием бинарников.
- Не было связи JS ↔ сессия (нельзя послать текст/клавишу, получить код выхода).

## Что сделано

Движок (`com.termux.terminal`, `com.termux.view`) оставлен — он идентичен движку AndroidIDE.
Добавлено/переписано:

- **ExtraKeys** — строка спец-клавиш из AndroidIDE/Termux (`ESC / TAB / CTRL / ALT / ←↑→↓ /
  HOME / END / PGUP / PGDN / BKSP / DEL`, свайп вверх по клавише даёт popup, например `-` → `|`).
  Портованы `ExtraKeysView`, `ExtraKeysInfo`, `ExtraKeyButton`, `SpecialButton(State)`,
  `ExtraKeysConstants`, `TerminalExtraKeys`, `BellHandler`.
- **Правильный `TerminalViewClient`**: модификаторы читаются из строки ExtraKeys
  (`readControlKey/readAltKey/readShiftKey/readFnKey`), ввод в char-based режиме,
  масштаб шрифта жестом (pinch), показ клавиатуры по тапу.
- **Правильный `TerminalSessionClient`**: курсор (block), bell (вибро), copy/paste в системный
  буфер, события смены заголовка и завершения сессии (с кодом выхода).
- **Нормальная сессия** (`TerminalEnvironment.kt`): запуск `bash --login` из bootstrap
  (`files/usr/bin/bash`), фолбэк на `files/usr/bin/sh` → Termux (`/data/data/com.termux`) →
  `/system/bin/sh`; корректное окружение (`HOME`, `PREFIX`, `PATH`, `TMPDIR`, `TERM`,
  `LANG`, `LD_LIBRARY_PATH`, `BOOTCLASSPATH`, ...).
- **JS-мост**: события (`started`/`title`/`exit`) и методы через ref
  (`writeText`, `sendKey`, `restart`, `toggleKeyboard`), пропсы (`fontSize`,
  `workingDirectory`, `initialCommand`, `extraKeys`).

## Использование в JS

```jsx
import { TerminalView } from '../modules/termux-terminal/src/index';

const ref = useRef(null);

<TerminalView
  ref={ref}
  style={{ flex: 1 }}
  fontSize={13}
  extraKeys={EXTRA_KEYS}                 // опционально, свой layout
  onTerminalEvent={(e) => {
    const ev = e.nativeEvent;            // {type:'started'|'title'|'exit', ...}
  }}
/>;

ref.current.run('ls -la');               // выполнить команду
ref.current.sendKey('ENTER');
ref.current.toggleKeyboard();
ref.current.restart();
```

Готовый экран: `src/screens/TerminalScreen.js` (кнопки A−/A+, клавиатура, рестарт).

## Пересборка

Терминал — нативный модуль, поэтому изменения требуют **dev-сборки**:

```bash
npm install
npm run pr      # expo prebuild --platform android
npm run bd      # eas build --platform android --profile development
```

После установки новой dev-сборки на устройство терминал подхватится автоматически.
