# Терминал (Termux engine) — переделка по образцу AndroidIDE

Терминал в приложении полностью переделан. Использован тот же движок, что и в
[AndroidIDE](https://github.com/AndroidIDEOfficial/AndroidIDE) / Termux
(`terminal-emulator` + `terminal-view`), но вокруг него построена правильная обёртка,
которой раньше не хватало.

## Что было не так раньше

- Нативный `TerminalView` подключался «голым», без строки специальных клавиш.
- Клиенты (`TerminalViewClient` / `TerminalSessionClient`) были заглушками:
  `readControlKey()/readAltKey()` всегда возвращали `false`, не было обработки
  `Ctrl+C`, `Tab`, стрелок, `Esc`.
- `getTerminalCursorStyle()` возвращал `null`, не было clipboard / bell.
- Сессия жёстко запускала `/system/bin/sh` с хрупким копированием бинарников.
- Не было связи JS ↔ сессия (нельзя послать текст/клавишу, получить код выхода).

## Что сделано

Движок (`com.termux.terminal`, `com.termux.view`) оставлен — он идентичен движку AndroidIDE.
Добавлено/переписано:

- **ExtraKeys** — строка спец-клавиш из AndroidIDE/Termux (`ESC / TAB / CTRL / ALT / ←↑→↓ /
  HOME / END / PGUP / PGDN / BKSP / DEL`, свайп вверх по клавише даёт popup, например `-` → `|`).
  Портованы `ExtraKeysView`, `ExtraKeysInfo`, `ExtraKeyButton`, `SpecialButton(State)`,
  `ExtraKeysConstants`, `TerminalExtraKeys`, `BellHandler`.
- **Правильный `TerminalViewClient`**: модификаторы читаются из строки ExtraKeys
  (`readControlKey/readAltKey/readShiftKey/readFnKey`), ввод в char-based режиме,
  масштаб шрифта жестом (pinch), показ клавиатуры по тапу.
- **Правильный `TerminalSessionClient`**: курсор (block), bell (вибро), copy/paste в системный
  буфер, события смены заголовка и завершения сессии (с кодом выхода).
- **Нормальная сессия** (`TerminalEnvironment.kt`): запуск `bash --login` из bootstrap
  (`files/usr/bin/bash`), фолбэк на `files/usr/bin/sh` → Termux (`/data/data/com.termux`) →
  `/system/bin/sh`; корректное окружение (`HOME`, `PREFIX`, `PATH`, `TMPDIR`, `TERM`,
  `LANG`, `LD_LIBRARY_PATH`, `BOOTCLASSPATH`, ...).
- **JS-мост**: события (`started`/`title`/`exit`) и методы через ref
  (`writeText`, `sendKey`, `restart`, `toggleKeyboard`), пропсы (`fontSize`,
  `workingDirectory`, `initialCommand`, `extraKeys`).

## Использование в JS

```jsx
import { TerminalView } from '../modules/termux-terminal/src/index';

const ref = useRef(null);

<TerminalView
  ref={ref}
  style={{ flex: 1 }}
  fontSize={13}
  extraKeys={EXTRA_KEYS}                 // опционально, свой layout
  onTerminalEvent={(e) => {
    const ev = e.nativeEvent;            // {type:'started'|'title'|'exit', ...}
  }}
/>;

ref.current.run('ls -la');               // выполнить команду
ref.current.sendKey('ENTER');
ref.current.toggleKeyboard();
ref.current.restart();
```

Готовый экран: `src/screens/TerminalScreen.js` (кнопки A−/A+, клавиатура, рестарт).

## Пересборка

Терминал — нативный модуль, поэтому изменения требуют **dev-сборки**:

```bash
npm install
npm run pr      # expo prebuild --platform android
npm run bd      # eas build --platform android --profile development
```

После установки новой dev-сборки на устройство терминал подхватится автоматически.

## ⚠️ «Permission denied» и выбор shell (Android 10+ / Huawei)

На Android 10+ раздел с данными приложения смонтирован как `noexec`, а SELinux
запрещает запуск файлов из `<filesDir>/usr/bin` (поэтому на Huawei и др. бывает
`exec(".../files/usr/bin/bash"): Permission denied`). Обычное приложение не может
это обойти — так устроен Android. Termux/AndroidIDE решают это, исполняя shell из
своей native-lib директории / при низком `targetSdk`.

Чтобы терминал **всегда** работал, `TerminalEnvironment` реально проверяет каждый
shell на запуск (`sh -c true`) и берёт первый рабочий по приоритету:

1. `files/usr/bin/bash` (bootstrap)
2. `files/usr/bin/sh`
3. `/data/data/com.termux/files/usr/bin/bash` (если установлен Termux)
4. `/system/bin/sh` — системный shell, запускается всегда (mksh)

Если видите в шапке `sh · pid …` — это значит, что на устройстве сработал фолбэк
на системный shell (bootstrap исполнить нельзя). Такой терминал полностью рабочий
(ввод, Ctrl+C, стрелки, ExtraKeys), но без пакетов `pkg`/`node`.

## 🐧 Полноценный Linux с apt через proot

Чтобы `apt`/`dpkg`/пакеты реально работали **без Termux и без root**, используется
**proot + Linux rootfs**:

- `proot` (хост-бинарник) упаковывается как нативная библиотека `libproot.so` в `jniLibs`
  → извлекается в **исполняемую** `nativeLibraryDir` (обходит noexec данных приложения).
- proot через свой `loader` (`libloader.so`) запускает бинарники гостевого rootfs прямо
  из данных приложения (не через `execve` ядра), поэтому noexec им не мешает.
- rootfs (Debian/Ubuntu с `apt`) скачивается в рантайме в `files/proot/rootfs/`.

### Шаги

1. **Положить бинарники proot** (на ПК, в корне проекта):
   ```bash
   npm run proot
   # или со своими URL:
   node scripts/setup-proot.js --proot <URL> --loader <URL> --abi arm64-v8a
   ```
   Скрипт кладёт `libproot.so` и `libloader.so` в
   `modules/termux-terminal/android/src/main/jniLibs/arm64-v8a/`.
   По умолчанию берётся статический proot из Termux (`ZhymabekRoman/proot-static`,
   armhf, работает и на arm64). Если устройство строго 64-битное — укажите aarch64-static
   proot + подходящий loader (URL-кандидаты в шапке скрипта).

2. **Пересобрать dev-client:**
   ```bash
   npm run pr && npm run bd
   ```
   (В `app.json` подключён плагин `with-extract-native-libs.js` → `extractNativeLibs="true"`,
   чтобы `libproot.so` извлекался реальным исполняемым файлом.)

3. **В приложении:** Terminal → кнопка **«Установить Linux»** (скачает rootfs, ~30-200 МБ).
   После этого терминал сам перезапустится **внутрь Linux** (в шапке будет `Linux (proot)`),
   и будут работать `apt update`, `apt install ...`, `bash`, и т.д.

### Если что-то не так (смотреть logcat, тег `TermuxProot`)

- `apt`/`dpkg` ругаются на hard links → нужен Termux-патченый proot с `--link2symlink`
  (по умолчанию включён; если ваш proot его не поддерживает — выключите в `ProotEnvironment.build`).
- proot падает по seccomp → уже выставлен `PROOT_NO_SECCOMP=1`.
- «loader not found» → не скачался/не тот `libloader.so`; без него гостевые бинарники не запустятся.
- 64-бит-only устройство не запускает armhf proot → возьмите aarch64-static proot.

> ⚠️ Я не могу протестировать proot-бинарники и rootfs в этой среде (нет устройства/загрузки),
> поэтому первый запуск, вероятно, потребует итерации по logcat. Код написан с подробным
> логированием именно для этого.

