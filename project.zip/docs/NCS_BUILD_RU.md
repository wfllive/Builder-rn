# NCS Build — новая быстрая система сборки

Замена Gradle для быстрой разработки Java + XML Android-приложений на устройстве.

## Преимущества перед Gradle

| Параметр | Gradle | NCS Build |
|----------|--------|-----------|
| Время сборки debug APK | 30-90 сек | **2-8 сек** |
| Скачивание при установке | ~1.5 ГБ | **~300 МБ** |
| Память для сборки | 2-4 ГБ | 512 МБ |
| Зависимости | Интернет для wrapper/зависимостей | Встроенные в SDK |
| Hot Reload | Нет | Есть (инкрементальный dex) |
| Мгновенный предпросмотр | Только в Android Studio | Есть (нативный XML рендер) |

## Установка окружения

```bash
# Быстрая установка минимального окружения
rai ncs setup
```

Устанавливает только необходимое:
- OpenJDK 17 (headless, без GUI)
- Android SDK build-tools 35.0.0
- Android platform 35
- Небольшой набор системных утилит

**Размер после установки: ~300 МБ** (против 1.2-1.5 ГБ у старой установки с Gradle).

## Создание проекта

```bash
# Новый Java + XML проект (рекомендуется)
rai new-java MyApp com.example.myapp

# Или старый вариант Kotlin + Compose
rai new MyApp com.example.myapp --modern
```

Структура Java+XML проекта:
```
MyApp/
├── ncs-project.toml          # Конфигурация проекта
├── app/
│   ├── proguard-rules.pro
│   ├── libs/                 # Локальные JAR/AAR библиотеки
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/myapp/
│       │   └── MainActivity.java
│       └── res/
│           ├── layout/
│           │   └── activity_main.xml
│           ├── values/
│           │   ├── colors.xml
│           │   ├── strings.xml
│           │   └── themes.xml
│           ├── drawable/
│           └── mipmap-*/
└── build/                    # Артефакты сборки
    └── outputs/
        ├── app-debug.apk
        └── app-release.apk
```

## Сборка

```bash
# Debug APK (2-8 сек)
rai ncs build MyApp
# или из папки проекта
ncs build debug

# Release APK с подписью
rai ncs build MyApp release
ncs build release

# Собрать и установить на устройство
rai ncs install MyApp
ncs install
```

## Hot Reload

Новый предпросмотр работает на двух уровнях:

### 1. Мгновенный визуальный предпросмотр (мгновенно)
- При редактировании XML layout файлов IDE рендерит нативные Android View прямо на устройстве
- Никакой компиляции не требуется, задержка 10-50 мс
- Учитываются цвета, строки, темы, padding/margin, gravity
- Поддерживаются LinearLayout, FrameLayout, RelativeLayout, TextView, Button, EditText, ImageView, CheckBox, Switch и другие

### 2. Инкрементальная компиляция Java (500-2000 мс)
- При изменении Java-кода компилируются только изменённые файлы
- Только эти файлы конвертируются в DEX
- Готовый DEX можно загрузить в запущенное приложение через DexClassLoader (hot swap)
- Нет полной пересборки, нет перезапуска приложения

## Конфигурация ncs-project.toml

```toml
name = "MyApp"
package = "com.example.myapp"
min_sdk = 24
target_sdk = 35
compile_sdk = 35
version_code = 1
version_name = "1.0"
main_activity = ".MainActivity"
language = "java"
ui = "xml"
```

## Поддерживаемые компоненты XML

| Категория | Компоненты |
|-----------|------------|
| Layouts | LinearLayout, RelativeLayout, FrameLayout, ScrollView, HorizontalScrollView |
| Widgets | TextView, Button, EditText, ImageView, CheckBox, Switch, RadioButton, ProgressBar |
| Атрибуты | layout_width/height, padding, margin, orientation, gravity, text, textColor, textSize, background, src, weight |
| Ресурсы | @color/..., @string/..., @drawable/... |

## Сравнение времени сборки

| Действие | Gradle | NCS Build | Ускорение |
|----------|--------|-----------|-----------|
| Первая сборка | 45-120 сек | 5-12 сек | **~10x** |
| Повторная сборка (без изменений) | 10-20 сек | <0.1 сек | **>100x** |
| Изменение layout.xml | 30-60 сек | 0.5-1 сек | **~60x** |
| Изменение Java-кода | 30-60 сек | 1-3 сек | **~20x** |
| Изменение цвета/строки | 25-45 сек | 0.3-0.8 сек | **~50x** |
| Полная пересборка clean | 60-150 сек | 8-15 сек | **~8x** |

## Переход с Gradle проектов

Gradle-проекты продолжают работать как раньше:
- `rai build MyApp` — старая сборка Gradle
- `rai ncs build MyJavaApp` — новая быстрая сборка

В списке проектов (`rai list`) тип проекта отображается отдельно.

## Минимальный rootfs

Установка через `rai ncs setup` скачивает и настраивает **только необходимое**:

1. Ubuntu base rootfs (~50 МБ)
2. OpenJDK 17 headless (~80 МБ)
3. Android SDK platform 35 (~60 МБ)
4. Android build-tools 35 (~50 МБ)
5. Утилиты zip/unzip/curl (~10 МБ)

Итого: **~250-300 МБ** вместо 1.2-1.5 ГБ у полного Gradle-окружения.

Компоненты устанавливаются по требованию:
- platform-tools (adb) — не ставится по умолчанию, ставится при `ncs install`
- Дополнительные версии SDK — ставятся при создании проекта с другим compileSdk
