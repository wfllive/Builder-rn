import { Stack } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { Platform } from 'react-native';

MapLibreGL.setAccessToken(null);
if (Platform.OS === 'android') {
  MapLibreGL.setTelemetryEnabled(false);
}

export default function RootLayout() {
  useEffect(() => {
    // MapLibre setup
    MapLibreGL.setConnected(true);
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#080d1a' }}>
      <StatusBar style="light" translucent backgroundColor="transparent" />
      <Stack screenOptions={{ headerShown: false, animation: 'fade' }}>
        <Stack.Screen name="index" />
      </Stack>
    </GestureHandlerRootView>
  );
}
