import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { View, StyleSheet, AppState, AppStateStatus } from 'react-native';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LightningMap } from '@/components/map/LightningMap';
import { TopBar } from '@/components/ui/TopBar';
import { SideButtons } from '@/components/ui/SideButtons';
import { Legend } from '@/components/ui/Legend';
import { RainTimeline } from '@/components/rain/RainTimeline';
import { AdvRadarTimeline } from '@/components/advradar/AdvRadarTimeline';
import { SettingsSheet } from '@/components/settings/SettingsSheet';
import { ThemeSheet } from '@/components/settings/ThemeSheet';
import { AlertDetailSheet } from '@/components/alerts/AlertDetailSheet';
import { WindOverlay } from '@/components/wind/WindOverlay';
import { RainRadarSkiaOverlay } from '@/components/rain/RainRadarSkiaOverlay';
import { useStrikes } from '@/hooks/useStrikes';
import { useLightningStream } from '@/hooks/useLightningStream';
import { useRainRadar } from '@/hooks/useRainRadar';
import { useRainRadarRR } from '@/hooks/useRainRadarRR';
import { useMeteoAlerts } from '@/hooks/useMeteoAlerts';
import { useAdvRadar } from '@/hooks/useAdvRadar';
import { useConfigStore } from '@/store/config';
import { useLocation } from '@/hooks/useLocation';
import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';

export default function IndexScreen() {
  const insets = useSafeAreaInsets();
  const config = useConfigStore(s => s.config);
  const toggle = useConfigStore(s => s.toggle);
  const update = useConfigStore(s => s.update);

  const mapRef = useRef<MapLibreGL.MapView>(null);
  const cameraRef = useRef<MapLibreGL.Camera>(null);

  const { position } = useLocation();
  const strikes = useStrikes(config, position);
  const { isConnected } = useLightningStream(strikes.addStrike, config, strikes.reset, strikes.replaceAll);

  // RainViewer (fallback) + rainradar.ru (основной)
  const rainRV = useRainRadar(config.rain);
  const rainRR = useRainRadarRR(config.rain);
  // используем rainradar.ru как primary
  const rain = rainRR.frames.length ? rainRR : rainRV;
  const alerts = useMeteoAlerts(config.alerts && !config.wind);
  const advRadar = useAdvRadar(config.advRadar);

  const [showSettings, setShowSettings] = useState(false);
  const [showTheme, setShowTheme] = useState(false);
  const [legendHidden, setLegendHidden] = useState(false);

  useKeepAwake(config.wake ? 'meteostudio' : undefined);

  // Handle app state for background pause
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state: AppStateStatus) => {
      // stream hook handles pause internally
    });
    return () => sub.remove();
  }, []);

  const handleLocate = useCallback(() => {
    Haptics.selectionAsync();
    if (position && cameraRef.current) {
      cameraRef.current.flyTo([position[1], position[0]], 800);
      cameraRef.current.setCamera({
        zoomLevel: 9,
        animationDuration: 800,
      });
    }
  }, [position]);

  const toast = useCallback((msg: string) => {
    // simple haptic as feedback - real toast can be added
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    console.log('[toast]', msg);
  }, []);

  const handleToggleRain = useCallback(() => {
    if (config.wind) { toast('⚠️ Недоступно в режиме ветра'); return; }
    toggle('rain');
    toast(config.rain ? '🌧️ Радар выключен' : '🌧️ Радар включён');
  }, [config.rain, config.wind, toggle, toast]);

  const handleToggleAlerts = useCallback(() => {
    if (config.wind) { toast('⚠️ Недоступно в режиме ветра'); return; }
    toggle('alerts');
    toast(config.alerts ? '⚠️ Предупреждения выключены' : '⚠️ Предупреждения включены');
  }, [config.alerts, config.wind, toggle, toast]);

  const handleToggleWind = useCallback(() => {
    toggle('wind');
    toast(config.wind ? '🌬️ Ветер выключен' : '🌬️ Ветер включён');
  }, [config.wind, toggle, toast]);

  const handleToggleAdv = useCallback(() => {
    if (config.wind) { toast('⚠️ Недоступно в режиме ветра'); return; }
    toggle('advRadar');
    toast(config.advRadar ? '📡 NowCast выключен' : '📡 NowCast включён');
  }, [config.advRadar, config.wind, toggle, toast]);

  const offsets = useMemo(() => {
    const legendBase = legendHidden ? 48 : 56;
    return {
      rain: legendBase + 8,
      adv: config.rain ? legendBase + 8 + 100 + 8 : legendBase + 8,
    };
  }, [legendHidden, config.rain]);

  return (
    <View style={styles.container}>
      {/* Main Map */}
      <View style={[styles.mapWrap, config.wind && styles.mapHidden]}>
        <LightningMap
          mapRef={mapRef}
          cameraRef={cameraRef}
          strikes={strikes.list}
          theme={config.theme}
          myPos={position}
          advRadar={advRadar}
          rain={rain}
          alerts={alerts}
          config={config}
        />
      </View>

      {/* Wind Mode Overlay (MapLibre with wind particles placeholder) */}
      {config.wind && (
        <WindOverlay
          position={position}
          config={config}
          updateConfig={update}
        />
      )}

      {/* Rain radar – rainradar.ru via Skia */}
      {!config.wind && config.rain && rainRR.currentFrame && (
        <RainRadarSkiaOverlay
          frame={rainRR.currentFrame}
          mapRef={mapRef}
          opacity={config.rainOpacity/100}
        />
      )}

      {/* Rain timeline */}
      {!config.wind && config.rain && rain.frames.length > 0 && (
        <RainTimeline
          frames={rain.frames}
          current={rain.currentIndex}
          onChange={rain.setFrame}
          bottomOffset={offsets.rain}
          visible={!legendHidden}
        />
      )}

      {/* AdvRadar timeline */}
      {!config.wind && config.advRadar && advRadar.times.length > 0 && (
        <AdvRadarTimeline
          times={advRadar.times}
          currentIndex={advRadar.timeIndex}
          isPlaying={advRadar.isPlaying}
          onPrev={advRadar.prev}
          onNext={advRadar.next}
          onTogglePlay={advRadar.togglePlay}
          onSeek={advRadar.seek}
          bottomOffset={offsets.adv}
          visible={!legendHidden}
        />
      )}

      {/* Legend */}
      {!config.wind && (
        <Legend
          showRain={config.rain}
          showAlerts={config.alerts}
          showAdvRadar={config.advRadar}
          advRadarLayer={config.advRadarLayer}
          hidden={legendHidden}
          setHidden={setLegendHidden}
          insets={insets}
        />
      )}

      <TopBar
        total={strikes.total}
        count={strikes.list.length}
        perMin={strikes.perMin}
        isConnected={isConnected}
        insets={insets}
        advClickInfo={advRadar.clickInfo}
        isAdvRadar={config.advRadar}
      />

      <SideButtons
        config={config}
        onTheme={() => !config.wind && setShowTheme(true)}
        onSettings={() => setShowSettings(true)}
        onLocate={handleLocate}
        onToggleRain={handleToggleRain}
        onToggleAlerts={handleToggleAlerts}
        onToggleWind={handleToggleWind}
        onToggleAdvRadar={handleToggleAdv}
        insets={insets}
      />

      <ThemeSheet
        visible={showTheme}
        current={config.theme}
        onClose={() => setShowTheme(false)}
        onSelect={(t) => { update('theme', t); setShowTheme(false); }}
      />

      <SettingsSheet
        visible={showSettings}
        onClose={() => setShowSettings(false)}
        config={config}
        updateConfig={update}
        toggle={toggle}
        rain={rain}
        alerts={alerts}
        advRadar={advRadar}
      />

      <AlertDetailSheet
        region={alerts.selected}
        alerts={alerts.regionAlerts}
        loading={alerts.detailLoading}
        onClose={alerts.closeDetail}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#080d1a' },
  mapWrap: { ...StyleSheet.absoluteFillObject, zIndex: 1 },
  mapHidden: { opacity: 0, zIndex: 0 },
});
