import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { ProjectProvider } from './src/store/projectStore';
import ProjectsScreen from './src/screens/ProjectsScreen';
import EditorScreen from './src/screens/EditorScreen';
import BlockEditorScreen from './src/screens/BlockEditorScreen';
import BuildScreen from './src/screens/BuildScreen';
import LibrariesScreen from './src/screens/LibrariesScreen';
import ProjectSettingsScreen from './src/screens/ProjectSettingsScreen';
import LivePreviewScreen from './src/screens/LivePreviewScreen';
import TerminalScreen from './src/screens/TerminalScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ProjectProvider>
        <StatusBar barStyle="light-content" backgroundColor="#0F0F14" />
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName="Projects"
            screenOptions={{
              headerShown: false,
              animation: 'slide_from_right',
              contentStyle: { backgroundColor: '#0F0F14' },
            }}
          >
            <Stack.Screen name="Projects" component={ProjectsScreen} />
            <Stack.Screen name="Editor" component={EditorScreen} />
            <Stack.Screen name="BlockEditor" component={BlockEditorScreen} />
            <Stack.Screen name="Build" component={BuildScreen} />
            <Stack.Screen name="Libraries" component={LibrariesScreen} />
            <Stack.Screen name="ProjectSettings" component={ProjectSettingsScreen} />
            <Stack.Screen name="LivePreview" component={LivePreviewScreen} />
            <Stack.Screen name="Terminal" component={TerminalScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </ProjectProvider>
    </GestureHandlerRootView>
  );
}
