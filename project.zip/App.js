import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationBar } from 'expo-navigation-bar';
import * as SystemUI from 'expo-system-ui';

import { ProjectProvider } from './src/store/projectStore';
import { AppSettingsProvider, useAppSettings } from './src/store/appSettings';
import InstallerScreen from './src/screens/InstallerScreen';
import ProjectsScreen from './src/screens/ProjectsScreen';
import EditorScreen from './src/screens/EditorScreen';
import BlockEditorScreen from './src/screens/BlockEditorScreen';
import BuildScreen from './src/screens/BuildScreen';
import LibrariesScreen from './src/screens/LibrariesScreen';
import ProjectSettingsScreen from './src/screens/ProjectSettingsScreen';
import AppSettingsScreen from './src/screens/AppSettingsScreen';
import LivePreviewScreen from './src/screens/LivePreviewScreen';
import TerminalScreen from './src/screens/TerminalScreen';

const Stack = createNativeStackNavigator();

const AppRoot = () => {
  const { loaded, colors, resolvedTheme } = useAppSettings();
  const [workspaceReady, setWorkspaceReady] = useState(false);
  const onInstalled = useCallback(() => setWorkspaceReady(true), []);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(colors.bg).catch(() => {});
  }, [colors.bg]);

  const navigationTheme = useMemo(() => ({
    dark: resolvedTheme === 'dark',
    colors: {
      primary: colors.primary,
      background: colors.bg,
      card: colors.bgCard,
      text: colors.text,
      border: colors.border,
      notification: colors.error,
    },
    fonts: {
      regular: { fontFamily: 'System', fontWeight: '400' },
      medium: { fontFamily: 'System', fontWeight: '500' },
      bold: { fontFamily: 'System', fontWeight: '700' },
      heavy: { fontFamily: 'System', fontWeight: '800' },
    },
  }), [colors, resolvedTheme]);

  if (!loaded) {
    return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <>
      <StatusBar
        hidden={false}
        style={resolvedTheme === 'dark' ? 'light' : 'dark'}
      />
      <NavigationBar hidden={false} style={resolvedTheme === 'dark' ? 'light' : 'dark'} />
      {!workspaceReady ? (
        <InstallerScreen onInstalled={onInstalled} />
      ) : (
        <ProjectProvider>
          <NavigationContainer theme={navigationTheme}>
            <Stack.Navigator
              initialRouteName="Projects"
              screenOptions={{
                headerShown: false,
                animation: 'slide_from_right',
                contentStyle: { backgroundColor: colors.bg },
                navigationBarColor: colors.systemBar,
                statusBarColor: colors.systemBar,
                statusBarStyle: resolvedTheme === 'dark' ? 'light' : 'dark',
                statusBarTranslucent: false,
              }}
            >
              <Stack.Screen name="Projects" component={ProjectsScreen} />
              <Stack.Screen name="Editor" component={EditorScreen} />
              <Stack.Screen name="BlockEditor" component={BlockEditorScreen} />
              <Stack.Screen name="Build" component={BuildScreen} />
              <Stack.Screen name="Libraries" component={LibrariesScreen} />
              <Stack.Screen name="ProjectSettings" component={ProjectSettingsScreen} />
              <Stack.Screen name="AppSettings" component={AppSettingsScreen} />
              <Stack.Screen name="LivePreview" component={LivePreviewScreen} />
              <Stack.Screen name="Terminal" component={TerminalScreen} />
            </Stack.Navigator>
          </NavigationContainer>
        </ProjectProvider>
      )}
    </>
  );
};

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppSettingsProvider>
          <AppRoot />
        </AppSettingsProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
