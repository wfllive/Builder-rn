import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Appearance,
  TouchableOpacity,
  StatusBar,
  ScrollView,
} from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

const API_URL = 'https://www.cbr-xml-daily.ru/daily_json.js';
const STORAGE_KEY = '@currency_data';
const MANUAL_RATE_KEY = '@manual_rate';

const CURRENCIES = ['GEL', 'RUB', 'USD'];

function CurrencyConverter() {
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(true);
  const [lastUpdated, setLastUpdated] = useState('');
  const [rates, setRates] = useState({ GEL: null, USD: null }); // rates in RUB
  const [inputValue, setInputValue] = useState('');
  const [fromCurrency, setFromCurrency] = useState('GEL');
  const [toCurrency, setToCurrency] = useState('RUB');
  const [colorScheme, setColorScheme] = useState(Appearance.getColorScheme());
  const [manualRate, setManualRate] = useState('');
  const [showManualInput, setShowManualInput] = useState(false);
  const [activeRateSource, setActiveRateSource] = useState('auto');

  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setColorScheme(colorScheme);
    });
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    loadInitialData();
    const interval = setInterval(() => {
      if (activeRateSource === 'auto') loadCurrencyData(false);
    }, 3600000);
    return () => clearInterval(interval);
  }, [activeRateSource]);

  const loadInitialData = async () => {
    try {
      const saved = await AsyncStorage.getItem(MANUAL_RATE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.rate) setManualRate(parsed.rate.toString());
        if (parsed.active) {
          setActiveRateSource('manual');
          // Для ручного курса используем только GEL
          setRates({ GEL: parseFloat(parsed.rate), USD: null });
          setLastUpdated('Вручную установленный курс');
          setIsLoading(false);
          return;
        }
      }
      await loadCurrencyData();
    } catch {
      setIsLoading(false);
    }
  };

  const loadCurrencyData = async (showLoading = true) => {
    if (showLoading) setIsLoading(true);
    try {
      const res = await axios.get(API_URL, { timeout: 8000 });
      const data = res.data;

      const gelRate = data.Valute.GEL.Value / data.Valute.GEL.Nominal;
      const usdRate = data.Valute.USD.Value / data.Valute.USD.Nominal;

      const newRates = { GEL: gelRate, USD: usdRate };

      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({
        rates: newRates,
        lastUpdated: data.Date,
        timestamp: Date.now()
      }));

      if (activeRateSource === 'auto') {
        setRates(newRates);
        setLastUpdated(data.Date);
      }
      setIsOnline(true);
    } catch {
      const saved = await AsyncStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (activeRateSource === 'auto') {
          setRates(parsed.rates);
          setLastUpdated(parsed.lastUpdated);
        }
        setIsOnline(false);
      }
    } finally {
      if (showLoading) setIsLoading(false);
    }
  };

  // ================== РАСЧЁТ КУРСА ==================
  const getRate = (from, to) => {
    if (from === to) return 1;

    // Все курсы хранятся относительно RUB
    const fromRate = from === 'RUB' ? 1 : rates[from];
    const toRate = to === 'RUB' ? 1 : rates[to];

    if (!fromRate || !toRate) return null;

    return fromRate / toRate;
  };

  const getConvertedValue = () => {
    if (!inputValue) return null;
    const value = parseFloat(inputValue.replace(',', '.'));
    if (isNaN(value)) return null;

    const rate = getRate(fromCurrency, toCurrency);
    if (!rate) return null;

    const result = (value * rate).toFixed(2);
    return `${value} ${fromCurrency} = ${result} ${toCurrency}`;
  };

  const convertedValue = getConvertedValue();

  // ================== РУЧНОЙ КУРС (только для GEL) ==================
  const saveManualRate = async () => {
    const num = parseFloat(manualRate.replace(',', '.'));
    if (!num || num <= 0) return Alert.alert('Ошибка', 'Введите корректный курс');

    try {
      await AsyncStorage.setItem(MANUAL_RATE_KEY, JSON.stringify({
        rate: num, active: true, timestamp: Date.now()
      }));
      setRates({ GEL: num, USD: rates.USD });
      setActiveRateSource('manual');
      setLastUpdated('Вручную установленный курс');
      setShowManualInput(false);
      Alert.alert('Успешно', `Курс 1 GEL = ${num} RUB сохранён`);
    } catch {
      Alert.alert('Ошибка', 'Не удалось сохранить');
    }
  };

  const toggleRateSource = async () => {
    if (activeRateSource === 'auto') {
      const saved = await AsyncStorage.getItem(MANUAL_RATE_KEY);
      if (!saved) {
        setShowManualInput(true);
        setActiveRateSource('manual');
        return;
      }
      const parsed = JSON.parse(saved);
      await AsyncStorage.setItem(MANUAL_RATE_KEY, JSON.stringify({ ...parsed, active: true }));
      setActiveRateSource('manual');
      setRates({ GEL: parseFloat(parsed.rate), USD: rates.USD });
      setLastUpdated('Вручную установленный курс');
    } else {
      const saved = await AsyncStorage.getItem(MANUAL_RATE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        await AsyncStorage.setItem(MANUAL_RATE_KEY, JSON.stringify({ ...parsed, active: false }));
      }
      setActiveRateSource('auto');
      setIsLoading(true);
      await loadCurrencyData();
    }
  };

  const handleInputChange = (text) => {
    const cleaned = text.replace(/[^0-9.,]/g, '');
    setInputValue(cleaned);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Неизвестно';
    if (dateString === 'Вручную установленный курс') return dateString;
    try {
      return new Date(dateString).toLocaleDateString('ru-RU', {
        day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
      });
    } catch { return dateString; }
  };

  const isDarkMode = colorScheme === 'dark';
  const styles = createStyles(isDarkMode);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3B82F6" />
          <Text style={styles.loadingText}>Загрузка...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">

        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Валюта</Text>
            <Text style={styles.subtitle}>Конвертер валют • 2026</Text>
          </View>
          <TouchableOpacity style={styles.refreshBtn} onPress={() => loadCurrencyData(true)}>
            <Text style={styles.refreshText}>↻</Text>
          </TouchableOpacity>
        </View>

        {/* Rate Card */}
        <View style={styles.rateCard}>
          <View style={styles.rateHeader}>
            <Text style={styles.rateLabel}>Текущие курсы</Text>
            <View style={[styles.badge, activeRateSource === 'manual' ? styles.badgeManual : styles.badgeAuto]}>
              <Text style={styles.badgeText}>{activeRateSource === 'manual' ? 'Ручной' : 'Авто'}</Text>
            </View>
          </View>

          <Text style={styles.rateMain}>
            1 GEL = {rates.GEL ? rates.GEL.toFixed(4) : '...'} RUB
          </Text>
          <Text style={styles.rateMain}>
            1 USD = {rates.USD ? rates.USD.toFixed(4) : '...'} RUB
          </Text>

          <Text style={styles.dateText}>Обновлено: {formatDate(lastUpdated)}</Text>

          <TouchableOpacity style={styles.sourceBtn} onPress={toggleRateSource}>
            <Text style={styles.sourceBtnText}>
              {activeRateSource === 'auto' ? 'Переключить на ручной курс' : 'Вернуться к автоматическому'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Manual Rate */}
        {activeRateSource === 'manual' && (
          <View style={styles.manualSection}>
            <TouchableOpacity style={styles.manualBtn} onPress={() => setShowManualInput(!showManualInput)}>
              <Text style={styles.manualBtnText}>
                {showManualInput ? 'Скрыть ввод' : 'Изменить ручной курс GEL'}
              </Text>
            </TouchableOpacity>

            {showManualInput && (
              <View style={styles.manualInputCard}>
                <TextInput
                  style={styles.input}
                  keyboardType="numeric"
                  placeholder="Введите курс 1 GEL в RUB"
                  placeholderTextColor={isDarkMode ? '#64748B' : '#94A3B8'}
                  value={manualRate}
                  onChangeText={(text) => setManualRate(text.replace(/[^0-9.,]/g, ''))}
                />
                <TouchableOpacity style={styles.primaryBtn} onPress={saveManualRate}>
                  <Text style={styles.primaryBtnText}>Сохранить курс</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        {/* Conversion Card */}
        <View style={styles.conversionCard}>
          <Text style={styles.sectionTitle}>Конвертация</Text>

          {/* From Currency */}
          <Text style={styles.currencyLabel}>Из</Text>
          <View style={styles.currencyRow}>
            {CURRENCIES.map((cur) => (
              <TouchableOpacity
                key={cur}
                style={[styles.currencyBtn, fromCurrency === cur && styles.currencyBtnActive]}
                onPress={() => setFromCurrency(cur)}
              >
                <Text style={[styles.currencyBtnText, fromCurrency === cur && styles.currencyBtnTextActive]}>
                  {cur}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* To Currency */}
          <Text style={styles.currencyLabel}>В</Text>
          <View style={styles.currencyRow}>
            {CURRENCIES.map((cur) => (
              <TouchableOpacity
                key={cur}
                style={[styles.currencyBtn, toCurrency === cur && styles.currencyBtnActive]}
                onPress={() => setToCurrency(cur)}
              >
                <Text style={[styles.currencyBtnText, toCurrency === cur && styles.currencyBtnTextActive]}>
                  {cur}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Результат перед вводом */}
          {convertedValue && (
            <View style={styles.resultAboveInput}>
              <Text style={styles.resultAboveLabel}>Результат</Text>
              <Text style={styles.resultAboveValue}>{convertedValue}</Text>
            </View>
          )}

          <Text style={styles.inputLabel}>Сумма</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            placeholder="0"
            placeholderTextColor={isDarkMode ? '#64748B' : '#94A3B8'}
            value={inputValue}
            onChangeText={handleInputChange}
          />
        </View>

        {/* Status */}
        <View style={styles.statusContainer}>
          <View style={[styles.statusDot, { backgroundColor: isOnline ? '#22C55E' : '#EF4444' }]} />
          <Text style={styles.statusText}>
            {isOnline ? 'Онлайн • ЦБ РФ' : 'Офлайн • Кэш'}
          </Text>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <CurrencyConverter />
    </SafeAreaProvider>
  );
}

const createStyles = (isDarkMode) => StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: isDarkMode ? '#0B1120' : '#F1F5F9',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    color: isDarkMode ? '#F8FAFC' : '#0F172A',
    letterSpacing: -1,
  },
  subtitle: {
    fontSize: 15,
    color: isDarkMode ? '#64748B' : '#64748B',
    marginTop: 4,
  },
  refreshBtn: {
    backgroundColor: isDarkMode ? '#1E293B' : '#E0E7FF',
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  refreshText: {
    fontSize: 20,
    color: isDarkMode ? '#60A5FA' : '#2563EB',
  },

  rateCard: {
    backgroundColor: isDarkMode ? '#1E293B' : '#FFFFFF',
    borderRadius: 24,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: isDarkMode ? 0.4 : 0.12,
    shadowRadius: 20,
    elevation: 12,
  },
  rateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  rateLabel: {
    fontSize: 14,
    color: isDarkMode ? '#94A3B8' : '#64748B',
    fontWeight: '600',
  },
  badge: {
    paddingHorizontal: 14,
    paddingVertical: 5,
    borderRadius: 20,
  },
  badgeAuto: { backgroundColor: isDarkMode ? '#166534' : '#DCFCE7' },
  badgeManual: { backgroundColor: isDarkMode ? '#1E3A8A' : '#DBEAFE' },
  badgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: isDarkMode ? '#fff' : '#1E40AF',
  },
  rateMain: {
    fontSize: 20,
    fontWeight: '700',
    color: isDarkMode ? '#fff' : '#0F172A',
    marginBottom: 4,
  },
  dateText: {
    marginTop: 16,
    fontSize: 13,
    color: isDarkMode ? '#64748B' : '#94A3B8',
  },
  sourceBtn: {
    marginTop: 18,
    backgroundColor: isDarkMode ? '#334155' : '#F1F5F9',
    paddingVertical: 13,
    borderRadius: 16,
    alignItems: 'center',
  },
  sourceBtnText: {
    color: isDarkMode ? '#60A5FA' : '#2563EB',
    fontWeight: '700',
    fontSize: 15,
  },

  manualSection: {
    marginBottom: 20,
  },
  manualBtn: {
    backgroundColor: isDarkMode ? '#1E293B' : '#E0E7FF',
    padding: 15,
    borderRadius: 18,
    alignItems: 'center',
  },
  manualBtnText: {
    color: isDarkMode ? '#60A5FA' : '#2563EB',
    fontWeight: '600',
    fontSize: 15,
  },
  manualInputCard: {
    marginTop: 12,
    backgroundColor: isDarkMode ? '#1E293B' : '#fff',
    padding: 18,
    borderRadius: 20,
  },

  conversionCard: {
    backgroundColor: isDarkMode ? '#1E293B' : '#FFFFFF',
    borderRadius: 24,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: isDarkMode ? 0.35 : 0.1,
    shadowRadius: 20,
    elevation: 10,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: isDarkMode ? '#F1F5F9' : '#0F172A',
    marginBottom: 18,
  },
  currencyLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: isDarkMode ? '#94A3B8' : '#64748B',
    marginBottom: 8,
    marginTop: 12,
  },
  currencyRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 8,
  },
  currencyBtn: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: isDarkMode ? '#334155' : '#F1F5F9',
    borderRadius: 14,
    alignItems: 'center',
  },
  currencyBtnActive: {
    backgroundColor: isDarkMode ? '#1E40AF' : '#2563EB',
  },
  currencyBtnText: {
    fontSize: 16,
    fontWeight: '700',
    color: isDarkMode ? '#94A3B8' : '#64748B',
  },
  currencyBtnTextActive: {
    color: '#fff',
  },

  resultAboveInput: {
    backgroundColor: isDarkMode ? '#1E3A8A' : '#DBEAFE',
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: isDarkMode ? '#3B82F6' : '#60A5FA',
  },
  resultAboveLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: isDarkMode ? '#93C5FD' : '#1E40AF',
    marginBottom: 4,
  },
  resultAboveValue: {
    fontSize: 20,
    fontWeight: '800',
    color: isDarkMode ? '#60A5FA' : '#1E40AF',
    textAlign: 'center',
  },

  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: isDarkMode ? '#94A3B8' : '#64748B',
    marginBottom: 8,
  },
  input: {
    height: 58,
    backgroundColor: isDarkMode ? '#0F172A' : '#F8FAFC',
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: isDarkMode ? '#475569' : '#CBD5E1',
    paddingHorizontal: 20,
    fontSize: 20,
    fontWeight: '600',
    color: isDarkMode ? '#F1F5F9' : '#0F172A',
  },

  primaryBtn: {
    backgroundColor: isDarkMode ? '#1E40AF' : '#2563EB',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 14,
  },
  primaryBtnText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },

  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 10,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 13,
    color: isDarkMode ? '#64748B' : '#64748B',
    fontWeight: '500',
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: isDarkMode ? '#0B1120' : '#F1F5F9',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: isDarkMode ? '#94A3B8' : '#64748B',
  },
});