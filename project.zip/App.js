import App from './src/App.tsx'; // ссылаешься на реальный файл
export default App;