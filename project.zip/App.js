import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationBar } from 'expo-navigation-bar';
import * as SystemUI from 'expo-system-ui';

import { ProjectProvider } from './src/store/projectStore';
import { AppSettingsProvider, useAppSettings } from './src/store/appSettings';
import PrivacyGate from './src/components/PrivacyGate';
import InstallerScreen from './src/screens/InstallerScreen';
import RaiSetupScreen from './src/screens/RaiSetupScreen';
import ProjectsScreen from './src/screens/ProjectsScreen';
import EditorScreen from './src/screens/EditorScreen';
import BuildScreen from './src/screens/BuildScreen';
import LibrariesScreen from './src/screens/LibrariesScreen';
import ProjectSettingsScreen from './src/screens/ProjectSettingsScreen';
import AppSettingsScreen from './src/screens/AppSettingsScreen';
import LivePreviewScreen from './src/screens/LivePreviewScreen';
import TerminalScreen from './src/screens/TerminalScreen';
import { getProotStatus, isAvailable as terminalAvailable } from './modules/termux-terminal/src/index';
import * as apt from './modules/apt-manager/src/index';
import { getRaiSetupStatus, probeRaiReady } from './src/utils/raiSetup';

const Stack = createNativeStackNavigator();

const AppRoot = () => {
  const { loaded, colors, resolvedTheme } = useAppSettings();
  const nativeReady = terminalAvailable() && apt.isAvailable();
  // checking → installer (Ubuntu rootfs) → setup (RAI: base + sdk) → ready (проекты)
  const [stage, setStage] = useState('checking');
  const [resumeStep, setResumeStep] = useState(null);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(colors.bg).catch(() => {});
  }, [colors.bg]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!nativeReady) {
          if (!cancelled) setStage('unavailable');
          return;
        }
        const status = await getProotStatus();
        if (!status?.rootfsInstalled) {
          if (!cancelled) setStage('installer');
          return;
        }
        // rootfs есть → определяем стадию RAI-среды.
        // ПОРЯДОК ВАЖЕН: сначала незавершённая установка (файл шага),
        // потом явный маркер готовности, и только в конце запасной probe.
        const setupStatus = await getRaiSetupStatus();

        // 1) Установка прервана (приложение закрыли на середине) — всегда
        //    возвращаемся в установщик, даже если rai status уже выглядит
        //    полным (Java/build-tools могут стоять с прошлого шага).
        if (setupStatus && setupStatus.startsWith('step:')) {
          const m = setupStatus.match(/^step:(.+)$/);
          if (!cancelled) setResumeStep(m ? m[1] : null);
          if (!cancelled) setStage('setup-resume');
          return;
        }

        // 2) Явный маркер «среда готова» → сразу список проектов.
        if (setupStatus === 'done') {
          if (!cancelled) setStage('ready');
          return;
        }

        // 3) Ни маркера, ни шага — либо установка ещё не начиналась, либо
        //    среда готова из старой версии (без маркера). Проверяем probe.
        const ready = await probeRaiReady();
        if (!cancelled) setStage(ready ? 'ready' : 'setup');
      } catch (e) {
        if (!cancelled) setStage('installer');
      }
    })();
    return () => { cancelled = true; };
  }, [nativeReady]);

  const onUbuntuInstalled = useCallback(() => setStage('setup'), []);
  const onRaiReady = useCallback(() => setStage('ready'), []);

  const navigationTheme = useMemo(() => ({
    dark: resolvedTheme === 'dark',
    colors: {
      primary: colors.primary,
      background: colors.bg,
      card: colors.bgCard,
      text: colors.text,
      border: colors.border,
      notification: colors.error,
    },
    fonts: {
      regular: { fontFamily: 'System', fontWeight: '400' },
      medium: { fontFamily: 'System', fontWeight: '500' },
      bold: { fontFamily: 'System', fontWeight: '700' },
      heavy: { fontFamily: 'System', fontWeight: '800' },
    },
  }), [colors, resolvedTheme]);

  if (!loaded) {
    return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <PrivacyGate>
      <StatusBar
        hidden={false}
        style={resolvedTheme === 'dark' ? 'light' : 'dark'}
      />
      <NavigationBar hidden={false} style={resolvedTheme === 'dark' ? 'light' : 'dark'} />
      {stage === 'checking' ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : stage === 'setup' || stage === 'setup-resume' ? (
        <RaiSetupScreen onComplete={onRaiReady} resume={stage === 'setup-resume'} resumeStep={resumeStep} />
      ) : stage === 'ready' ? (
        <ProjectProvider>
          <NavigationContainer theme={navigationTheme}>
            <Stack.Navigator
              initialRouteName="Projects"
              screenOptions={{
                headerShown: false,
                animation: 'slide_from_right',
                contentStyle: { backgroundColor: colors.bg },
                navigationBarColor: colors.systemBar,
                statusBarColor: colors.systemBar,
                statusBarStyle: resolvedTheme === 'dark' ? 'light' : 'dark',
              }}
            >
              <Stack.Screen name="Projects" component={ProjectsScreen} />
              <Stack.Screen name="Editor" component={EditorScreen} />
              <Stack.Screen name="Build" component={BuildScreen} />
              <Stack.Screen name="Libraries" component={LibrariesScreen} />
              <Stack.Screen name="ProjectSettings" component={ProjectSettingsScreen} />
              <Stack.Screen name="AppSettings" component={AppSettingsScreen} />
              <Stack.Screen name="LivePreview" component={LivePreviewScreen} />
              <Stack.Screen name="Terminal" component={TerminalScreen} />
            </Stack.Navigator>
          </NavigationContainer>
        </ProjectProvider>
      ) : (
        // installer | unavailable — корневой экран ставит Ubuntu (или показывает
        // «нужна нативная сборка»), затем onInstalled переводит на RAI setup.
        <InstallerScreen onInstalled={onUbuntuInstalled} />
      )}
    </PrivacyGate>
  );
};

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppSettingsProvider>
          <AppRoot />
        </AppSettingsProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
