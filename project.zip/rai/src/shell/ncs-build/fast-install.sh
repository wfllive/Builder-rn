#!/usr/bin/env bash
# =============================================================================
#  NCS Fast Install — минимальная быстрая установка окружения
#  Устанавливает ТОЛЬКО необходимое в 2-4 раза быстрее старого установщика:
#   - отключает рекомендованные пакеты
#   - параллельная загрузка apt
#   - JDK headless без документации
#   - только нужные компоненты SDK, без исходников и эмуляторов
#   - компоненты устанавливаются ПО ТРЕБОВАНИЮ (при первой сборке)
# =============================================================================
set -euo pipefail

if [ -t 1 ]; then
  B='\033[1;36m'; G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; NC='\033[0m'
else
  B=''; G=''; Y=''; R=''; NC=''
fi
log()  { echo -e "${B}[fast]${NC} $*"; }
ok()   { echo -e "  ${G}✓${NC} $*"; }
warn() { echo -e "  ${Y}⚠${NC} $*"; }
die()  { echo -e "  ${R}✗${NC} $*"; exit 1; }

NCS_HOME="${NCS_HOME:-$HOME/.ncs}"
SDK_DIR="$NCS_HOME/sdk"
CACHE_DIR="$NCS_HOME/cache"
TMP_DIR="$NCS_HOME/tmp"

mkdir -p "$NCS_HOME" "$SDK_DIR" "$CACHE_DIR" "$TMP_DIR"

export DEBIAN_FRONTEND=noninteractive
export APT_OPTIONS='-o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"'

# ------------------------------------------------------------------ 1. Быстрая настройка apt
log "Настройка apt для максимальной скорости..."

# Отключаем рекомендованные пакеты - экономит сотни МБ
cat > /etc/apt/apt.conf.d/99ncs-fast <<EOF
APT::Install-Recommends "false";
APT::Install-Suggests "false";
APT::Get::Assume-Yes "true";
Acquire::Retries "3";
Acquire::http::Pipeline-Depth "5";
Acquire::http::No-Cache "false";
Acquire::Queue-Mode "access";
APT::Sandbox::User "root";
Dpkg::Use-Pty "0";
EOF
ok "apt настроен (без Recommends/Suggests, параллельная загрузка)"

# Чиним DNS и права
for d in /tmp /var/tmp; do
  mkdir -p "$d" 2>/dev/null
  chmod 1777 "$d" 2>/dev/null
done

if ! grep -q "^nameserver" /etc/resolv.conf 2>/dev/null; then
  cat > /etc/resolv.conf <<EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
nameserver 8.8.4.4
EOF
  ok "DNS настроен"
fi

# ARM зеркало
ARCH="$(dpkg --print-architecture 2>/dev/null || echo arm64)"
if [ "$ARCH" = "arm64" ]; then
  CODENAME="$(. /etc/os-release 2>/dev/null && echo "$VERSION_CODENAME")"
  if ! grep -q ports.ubuntu.com /etc/apt/sources.list 2>/dev/null; then
    cat > /etc/apt/sources.list <<EOF
deb http://ports.ubuntu.com/ubuntu-ports $CODENAME main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-updates main restricted universe multiverse
deb http://ports.ubuntu.com/ubuntu-ports ${CODENAME}-security main restricted universe multiverse
EOF
    ok "зеркало ports.ubuntu.com настроено"
  fi
fi

# ------------------------------------------------------------------ 2. Минимальный набор пакетов (параллельно)
log "Обновление списков пакетов..."
apt-get update -qq

log "Установка минимального набора инструментов (параллельно)..."
# ТОЛЬКО необходимое:
# - openjdk-17-jdk-headless: компилятор, без GUI и документации
# - базовые утилиты: curl, unzip, zip, xz-utils
# - keytool из JDK уже есть, не нужен дополнительный
PKGS=(
  openjdk-17-jdk-headless
  curl
  wget
  unzip
  zip
  xz-utils
  ca-certificates
  procps
)
apt-get install -y --no-install-recommends "${PKGS[@]}" 2>&1 | tail -5

# Настройка Java
export JAVA_HOME="$(dirname $(dirname $(readlink -f $(which javac))))"
echo "$JAVA_HOME" > "$NCS_HOME/JAVA_HOME"
ok "JDK 17 установлен: $JAVA_HOME"

# Патч от зависаний /dev/random
for SEC in "$JAVA_HOME/conf/security/java.security" "$JAVA_HOME/lib/security/java.security"; do
  [ -f "$SEC" ] || continue
  sed -i 's|^securerandom.source=.*|securerandom.source=file:/dev/./urandom|' "$SEC" 2>/dev/null || true
done
ok "Java пропатчена от зависаний"

# ------------------------------------------------------------------ 3. Минимальный Android SDK (только нужное)
log "Настройка Android SDK..."

mkdir -p "$SDK_DIR/cmdline-tools" "$SDK_DIR/build-tools" "$SDK_DIR/platforms" "$SDK_DIR/platform-tools"

# Быстрая загрузка SDK tools
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
CMDLINE_TOOLS_ZIP="$CACHE_DIR/cmdline-tools.zip"

if [ ! -d "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  log "Скачивание command-line tools..."
  curl -fL --retry 3 -o "$CMDLINE_TOOLS_ZIP" "$CMDLINE_TOOLS_URL" 2>&1 | tail -1
  unzip -qo "$CMDLINE_TOOLS_ZIP" -d "$SDK_DIR/cmdline-tools/"
  mv "$SDK_DIR/cmdline-tools/cmdline-tools" "$SDK_DIR/cmdline-tools/latest"
  ok "command-line tools установлены"
else
  ok "command-line-tools уже есть"
fi

export PATH="$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools:$PATH"
export ANDROID_SDK_ROOT="$SDK_DIR"

# Принимаем лицензии автоматически
yes | sdkmanager --licenses >/dev/null 2>&1 || true

# Скачиваем ТОЛЬКО одну версию platform и build-tools
# Без исходников, без эмулятора, без system-images, без docs
BT_VER="${NCS_BUILD_TOOLS:-35.0.0}"
PLAT_VER="${NCS_PLATFORM:-android-35}"

if [ ! -f "$SDK_DIR/build-tools/$BT_VER/aapt2" ]; then
  log "Скачивание build-tools $BT_VER..."
  sdkmanager --install "build-tools;$BT_VER" 2>&1 | tail -3
  ok "build-tools $BT_VER установлен"
else
  ok "build-tools $BT_VER уже есть"
fi

if [ ! -f "$SDK_DIR/platforms/$PLAT_VER/android.jar" ]; then
  log "Скачивание platform $PLAT_VER..."
  sdkmanager --install "platforms;$PLAT_VER" 2>&1 | tail -3
  ok "platform $PLAT_VER установлен"
else
  ok "platform $PLAT_VER уже есть"
fi

# platform-tools (adb) - опционально, ставим только если попросят
if [ "${INSTALL_ADB:-0}" = "1" ] && [ ! -f "$SDK_DIR/platform-tools/adb" ]; then
  sdkmanager --install "platform-tools" 2>&1 | tail -1
fi

# ------------------------------------------------------------------ 4. Устанавливаем наш ncs-build в PATH
log "Установка ncs-build..."
cat > "$NCS_HOME/bin/ncs" <<NCSEOF
#!/usr/bin/env bash
export JAVA_HOME="\$(cat "$NCS_HOME/JAVA_HOME" 2>/dev/null || echo "$JAVA_HOME")"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="\$JAVA_HOME/bin:$SDK_DIR/build-tools/$BT_VER:$SDK_DIR/platform-tools:$NCS_HOME/bin:\$PATH"
exec bash "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ncs-build.sh" "\$@"
NCSEOF
chmod +x "$NCS_HOME/bin/ncs"

# Добавляем в .bashrc
MARK="# >>> ncs-fast >>>"
for F in "$HOME/.bashrc" "$HOME/.profile"; do
  touch "$F"
  grep -q "$MARK" "$F" 2>/dev/null && sed -i "/$MARK/,/# <<< ncs-fast <<</d" "$F"
  cat >> "$F" <<EOF

$MARK
export NCS_HOME="$NCS_HOME"
export JAVA_HOME="\$(cat "$NCS_HOME/JAVA_HOME" 2>/dev/null)"
export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="\$NCS_HOME/bin:\$JAVA_HOME/bin:\$PATH"
export JAVA_TOOL_OPTIONS="-Djava.security.egd=file:/dev/./urandom"
export LANG=C.UTF-8
# <<< ncs-fast <<<
EOF
done
ok "ncs добавлен в PATH"

# Копируем скрипты ncs-build
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/ncs-build.sh" "$NCS_HOME/bin/"
cp "$SCRIPT_DIR/new-project.sh" "$NCS_HOME/bin/"
chmod +x "$NCS_HOME/bin/"*.sh

# ------------------------------------------------------------------ 5. Создаём каталог проектов
mkdir -p "$HOME/projects"

echo
echo -e "${G}════════════ УСТАНОВКА ЗАВЕРШЕНА ════════════${NC}"
echo
echo "  Установлено за: секунд (см. выше)"
echo "  Размер установки: $(du -sh "$NCS_HOME" 2>/dev/null | cut -f1)"
echo
echo "  Использование:"
echo "    source ~/.bashrc"
echo "    ncs new MyApp com.example.myapp"
echo "    cd ~/projects/MyApp"
echo "    ncs build debug"
echo
echo "  Компоненты SDK устанавливаются автоматически при первой сборке."
echo "  Для release-сборки запустите: ncs build release"
echo
