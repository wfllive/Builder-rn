/**
 * Тест: Визуальный проект → Генерация → Сборка
 * Проверяет что pipeline конструктора реально работает
 */

const fs = require('fs');
const path = require('path');

// === 1. Тестовый визуальный проект (как в конструкторе) ===
const testProject = {
  id: 'test-project-123',
  name: 'Тестовое приложение',
  packageName: 'com.test.myapp',
  versionName: '1.0.0',
  versionCode: 1,
  icon: '📱',
  theme: {
    primaryColor: '#6200EE',
    secondaryColor: '#03DAC6',
    backgroundColor: '#121212',
    isDark: true,
  },
  variables: [
    { id: 'var1', name: 'counter', type: 'number', value: 0 },
    { id: 'var2', name: 'username', type: 'text', value: 'User' },
  ],
  screens: [
    {
      id: 'screen1',
      name: 'Главный',
      backgroundColor: '#121212',
      showActionBar: true,
      actionBarTitle: 'Главный экран',
      rootComponent: {
        id: 'root1',
        type: 'LinearLayout',
        props: {
          orientation: 'vertical',
          width: 'match_parent',
          height: 'match_parent',
          padding: 16,
          backgroundColor: '#121212',
          gravity: 'left',
        },
        children: [
          {
            id: 'txt1',
            type: 'TextView',
            props: {
              text: 'Привет, мир!',
              width: 'match_parent',
              height: 'wrap_content',
              textSize: 24,
              textColor: '#FFFFFF',
              textStyle: 'bold',
              gravity: 'center',
              padding: 16,
            },
            children: [],
          },
          {
            id: 'txt2',
            type: 'TextView',
            props: {
              text: 'Это приложение создано в Sketchware Pro',
              width: 'match_parent',
              height: 'wrap_content',
              textSize: 14,
              textColor: '#AAAAAA',
              textStyle: 'normal',
              gravity: 'center',
              padding: 8,
            },
            children: [],
          },
          {
            id: 'spacer1',
            type: 'Spacer',
            props: { width: 'match_parent', height: 24 },
            children: [],
          },
          {
            id: 'btn1',
            type: 'Button',
            props: {
              text: 'Нажми меня',
              width: 'match_parent',
              height: 'wrap_content',
              textSize: 16,
              textColor: '#FFFFFF',
              backgroundColor: '#6200EE',
              padding: 16,
              borderRadius: 12,
            },
            children: [],
          },
          {
            id: 'input1',
            type: 'EditText',
            props: {
              hint: 'Введите имя...',
              text: '',
              width: 'match_parent',
              height: 'wrap_content',
              textSize: 16,
              textColor: '#FFFFFF',
              backgroundColor: '#2C2C2C',
              padding: 14,
              borderRadius: 8,
            },
            children: [],
          },
          {
            id: 'divider1',
            type: 'Divider',
            props: {
              width: 'match_parent',
              height: 1,
              backgroundColor: '#333333',
              margin: 16,
            },
            children: [],
          },
          {
            id: 'card1',
            type: 'CardView',
            props: {
              width: 'match_parent',
              height: 'wrap_content',
              backgroundColor: '#1E1E1E',
              borderRadius: 12,
              padding: 16,
              elevation: 4,
            },
            children: [
              {
                id: 'card_txt',
                type: 'TextView',
                props: {
                  text: 'Это карточка с информацией',
                  textSize: 14,
                  textColor: '#CCCCCC',
                  textStyle: 'normal',
                  gravity: 'left',
                  padding: 0,
                },
                children: [],
              },
              {
                id: 'progress1',
                type: 'ProgressBar',
                props: {
                  progress: 75,
                  max: 100,
                  width: 'match_parent',
                  height: 'wrap_content',
                  color: '#03DAC6',
                },
                children: [],
              },
            ],
          },
        ],
      },
      blocks: [
        {
          id: 'block1',
          definitionId: 'on_create',
          category: 'EVENT',
          position: { x: 20, y: 20 },
          inputs: {},
          children: {
            next: [
              {
                id: 'block2',
                definitionId: 'show_toast',
                category: 'COMPONENT',
                inputs: { text: 'Добро пожаловать!' },
                children: {},
              },
            ],
          },
        },
      ],
    },
    {
      id: 'screen2',
      name: 'Второй',
      backgroundColor: '#1A1A2E',
      showActionBar: true,
      actionBarTitle: 'Второй экран',
      rootComponent: {
        id: 'root2',
        type: 'LinearLayout',
        props: {
          orientation: 'vertical',
          width: 'match_parent',
          height: 'match_parent',
          padding: 16,
          backgroundColor: '#1A1A2E',
          gravity: 'center',
        },
        children: [
          {
            id: 'txt3',
            type: 'TextView',
            props: {
              text: 'Второй экран',
              textSize: 28,
              textColor: '#FFFFFF',
              textStyle: 'bold',
              gravity: 'center',
              padding: 20,
            },
            children: [],
          },
          {
            id: 'btn2',
            type: 'Button',
            props: {
              text: 'Назад',
              width: 'match_parent',
              height: 'wrap_content',
              textSize: 16,
              textColor: '#000000',
              backgroundColor: '#03DAC6',
              padding: 14,
              borderRadius: 8,
            },
            children: [],
          },
        ],
      },
      blocks: [],
    },
  ],
};

// === 2. Генератор проекта (копия fullProjectGenerator.js в CommonJS) ===
function generateFullProject(project) {
  const files = {};
  
  files['package.json'] = JSON.stringify({
    name: project.name.toLowerCase().replace(/\s/g, '-'),
    version: project.versionName || '1.0.0',
    main: 'node_modules/expo/AppEntry.js',
    scripts: {
      start: 'expo start',
      android: 'expo start --android',
      ios: 'expo start --ios',
      web: 'expo start --web',
    },
    dependencies: {
      expo: '~52.0.0',
      'expo-status-bar': '~2.0.1',
      'expo-asset': '~11.0.4',
      'expo-font': '~13.0.4',
      'expo-constants': '~17.0.8',
      '@expo/metro-runtime': '~4.0.1',
      'react-dom': '18.3.1',
      'react-native-web': '~0.19.13',
      react: '18.3.1',
      'react-native': '0.76.7',
      '@react-navigation/native': '^7.0.0',
      '@react-navigation/native-stack': '^7.0.0',
      'react-native-screens': '~4.4.0',
      'react-native-safe-area-context': '4.14.1',
    },
    devDependencies: {
      '@babel/core': '^7.25.2',
    },
    private: true,
  }, null, 2);

  files['app.json'] = JSON.stringify({
    expo: {
      name: project.name,
      slug: project.name.toLowerCase().replace(/\s/g, '-'),
      version: project.versionName || '1.0.0',
      orientation: 'portrait',
      userInterfaceStyle: project.theme?.isDark ? 'dark' : 'light',
      splash: { backgroundColor: project.theme?.primaryColor || '#BB86FC' },
      ios: {
        supportsTablet: true,
        bundleIdentifier: project.packageName || 'com.app.default',
      },
      android: {
        adaptiveIcon: { backgroundColor: project.theme?.primaryColor || '#BB86FC' },
        package: project.packageName || 'com.app.default',
      },
    },
  }, null, 2);

  files['eas.json'] = JSON.stringify({
    cli: { version: '>= 12.0.0' },
    build: {
      development: { developmentClient: true, distribution: 'internal', android: { buildType: 'apk' } },
      preview: { distribution: 'internal', android: { buildType: 'apk' } },
      production: { android: { buildType: 'app-bundle' } },
    },
  }, null, 2);

  files['babel.config.js'] = `module.exports = function(api) {
  api.cache(true);
  return { presets: ['babel-preset-expo'] };
};
`;

  files['App.js'] = generateAppJs(project);
  
  project.screens.forEach((screen, i) => {
    const dir = 'src/screens';
    files[`${dir}/${screen.name.replace(/\s/g, '')}Screen.js`] = generateScreenJs(screen, project);
  });

  return files;
}

function generateAppJs(project) {
  const screens = project.screens || [];
  const imports = screens.map(s => 
    `import ${s.name.replace(/\s/g, '')}Screen from './src/screens/${s.name.replace(/\s/g, '')}Screen';`
  ).join('\n');
  const screenDefs = screens.map(s => 
    `          <Stack.Screen name="${s.name.replace(/\s/g, '')}" component={${s.name.replace(/\s/g, '')}Screen} options={{ title: '${s.name}' }} />`
  ).join('\n');

  return `import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

${imports}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <>
      <StatusBar barStyle="${project.theme?.isDark ? 'light' : 'dark'}-content" backgroundColor="${project.theme?.primaryColor || '#6200EE'}" />
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: '${project.theme?.primaryColor || '#6200EE'}' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: 'bold' },
          }}
        >
${screenDefs}
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}
`;
}

function generateScreenJs(screen, project) {
  const bgColor = screen.backgroundColor || project.theme?.backgroundColor || '#121212';
  let rnImports = ['View', 'Text', 'StyleSheet', 'TouchableOpacity', 'Alert'];
  if (hasType(screen.rootComponent, 'EditText')) rnImports.push('TextInput');
  if (hasType(screen.rootComponent, 'Switch')) rnImports.push('Switch');

  const jsx = generateJSX(screen.rootComponent, 4);
  const stylesStr = generateScreenStyles(screen.rootComponent, bgColor);
  
  const stateVars = (project.variables || []).map(v => {
    const def = v.type === 'number' ? (v.value || 0) : 
                v.type === 'boolean' ? (v.value || false) :
                `'${v.value || ''}'`;
    return `  const [${v.name}, set${v.name.charAt(0).toUpperCase() + v.name.slice(1)}] = useState(${def});`;
  }).join('\n');

  let handlers = '';
  const onCreate = (screen.blocks || []).find(b => b.definitionId === 'on_create');
  if (onCreate?.children?.next) {
    handlers += `  useEffect(() => {\n`;
    onCreate.children.next.forEach(action => {
      if (action.definitionId === 'show_toast') {
        handlers += `    Alert.alert('Сообщение', '${action.inputs?.text || ''}');\n`;
      }
    });
    handlers += `  }, []);\n\n`;
  }

  const screenName = screen.name.replace(/\s/g, '') + 'Screen';
  return `import React, { useState, useEffect } from 'react';
import {
  ${rnImports.join(',\n  ')},
} from 'react-native';

const ${screenName} = ({ navigation }) => {
${stateVars || '  // State'}
  
${handlers}
  return (
    <View style={styles.container}>
${jsx}
    </View>
  );
};

${stylesStr}

export default ${screenName};
`;
}

function hasType(comp, type) {
  if (!comp) return false;
  if (comp.type === type) return true;
  if (comp.children) return comp.children.some(c => hasType(c, type));
  return false;
}

function generateJSX(component, indent) {
  if (!component) return '';
  const sp = ' '.repeat(indent);
  const props = component.props || {};
  const sk = `styles.c_${component.id?.slice(0, 8)}`;

  switch (component.type) {
    case 'LinearLayout':
      return `${sp}<View style={${sk}}>
${(component.children || []).map(c => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;
    case 'CardView':
      return `${sp}<View style={${sk}}>
${(component.children || []).map(c => generateJSX(c, indent + 2)).join('\n')}
${sp}</View>`;
    case 'TextView':
      return `${sp}<Text style={${sk}}>${props.text || ''}</Text>`;
    case 'Button':
      return `${sp}<TouchableOpacity style={${sk}} onPress={() => Alert.alert('${(props.text || 'Button').replace(/'/g, "\\'")}', 'Нажато!')}>
${sp}  <Text style={${sk}_text}>${props.text || 'Button'}</Text>
${sp}</TouchableOpacity>`;
    case 'EditText':
      return `${sp}<TextInput style={${sk}} placeholder="${props.hint || ''}" placeholderTextColor="#888" />`;
    case 'ProgressBar':
      return `${sp}<View style={${sk}}>
${sp}  <View style={[${sk}_fill, { width: '${props.progress || 50}%' }]} />
${sp}</View>`;
    case 'Divider':
      return `${sp}<View style={${sk}} />`;
    case 'Spacer':
      return `${sp}<View style={${sk}} />`;
    default:
      return `${sp}<View style={${sk}} />`;
  }
}

function generateScreenStyles(rootComponent, bgColor) {
  const styles = [];
  styles.push(`const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '${bgColor}',
    padding: ${rootComponent?.props?.padding || 16},
  },`);
  collectStyles(rootComponent, styles);
  styles.push('});');
  return styles.join('\n');
}

function collectStyles(comp, styles) {
  if (!comp) return;
  const p = comp.props || {};
  const k = `  c_${comp.id?.slice(0, 8)}`;

  switch (comp.type) {
    case 'LinearLayout':
    case 'CardView':
      styles.push(`${k}: {
    flexDirection: '${p.orientation === 'horizontal' ? 'row' : 'column'}',
    ${dimS('width', p.width)}${dimS('height', p.height)}padding: ${p.padding || 0},
    backgroundColor: '${p.backgroundColor || 'transparent'}',
    borderRadius: ${p.borderRadius || 0},
    ${p.elevation ? `elevation: ${p.elevation}, shadowColor: '#000', shadowOffset: {width:0,height:2}, shadowOpacity: 0.25, shadowRadius: 4,` : ''}
  },`);
      break;
    case 'TextView':
      styles.push(`${k}: {
    fontSize: ${p.textSize || 16},
    color: '${p.textColor || '#fff'}',
    fontWeight: '${p.textStyle === 'bold' ? 'bold' : 'normal'}',
    textAlign: '${p.gravity || 'left'}',
    padding: ${p.padding || 0},
  },`);
      break;
    case 'Button':
      styles.push(`${k}: {
    backgroundColor: '${p.backgroundColor || '#6200EE'}',
    padding: ${p.padding || 14},
    borderRadius: ${p.borderRadius || 8},
    alignItems: 'center',
    marginVertical: 6,
  },
  ${k}_text: {
    color: '${p.textColor || '#fff'}',
    fontSize: ${p.textSize || 16},
    fontWeight: 'bold',
  },`);
      break;
    case 'EditText':
      styles.push(`${k}: {
    backgroundColor: '${p.backgroundColor || '#2C2C2C'}',
    padding: ${p.padding || 12},
    borderRadius: ${p.borderRadius || 8},
    color: '${p.textColor || '#fff'}',
    fontSize: ${p.textSize || 16},
    marginVertical: 6,
    borderWidth: 1,
    borderColor: '#444',
  },`);
      break;
    case 'ProgressBar':
      styles.push(`${k}: {
    height: 8, backgroundColor: '#333', borderRadius: 4, overflow: 'hidden', marginVertical: 8,
  },
  ${k}_fill: {
    height: '100%', backgroundColor: '${p.color || '#6200EE'}', borderRadius: 4,
  },`);
      break;
    case 'Divider':
      styles.push(`${k}: {
    height: ${p.height || 1}, backgroundColor: '${p.backgroundColor || '#444'}', margin: ${p.margin || 8},
  },`);
      break;
    case 'Spacer':
      styles.push(`${k}: { height: ${p.height || 16} },`);
      break;
  }
  if (comp.children) comp.children.forEach(c => collectStyles(c, styles));
}

function dimS(key, val) {
  if (val === 'match_parent') return `${key}: '100%',\n    `;
  if (typeof val === 'number') return `${key}: ${val},\n    `;
  return '';
}

// === 3. ТЕСТ: Генерация ===
console.log('═══════════════════════════════════════════');
console.log('  ТЕСТ: Визуальный проект → Expo проект');
console.log('═══════════════════════════════════════════\n');

const OUTPUT_DIR = path.join(__dirname, 'test-generated-app');

// Clean up
if (fs.existsSync(OUTPUT_DIR)) {
  fs.rmSync(OUTPUT_DIR, { recursive: true });
}

console.log('📦 Генерация файлов из визуального проекта...');
const files = generateFullProject(testProject);

const fileNames = Object.keys(files);
console.log(`✅ Сгенерировано ${fileNames.length} файлов:\n`);

fileNames.forEach(name => {
  const lines = files[name].split('\n').length;
  const size = Buffer.byteLength(files[name], 'utf8');
  console.log(`  📄 ${name} (${lines} строк, ${(size/1024).toFixed(1)} KB)`);
});

// === 4. Запись на диск ===
console.log('\n💾 Запись файлов на диск...');
fileNames.forEach(name => {
  const fullPath = path.join(OUTPUT_DIR, name);
  const dir = path.dirname(fullPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(fullPath, files[name], 'utf8');
});
console.log(`✅ Файлы записаны в: ${OUTPUT_DIR}\n`);

console.log('═══════════════════════════════════════════');
console.log('  Генерация завершена. Далее: npm install');
console.log('═══════════════════════════════════════════');
