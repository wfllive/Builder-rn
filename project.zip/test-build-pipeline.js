#!/usr/bin/env node
/** Validate the visual model -> native Jetpack Compose project pipeline. */
const path = require('path');
const Module = require('module');
const babel = require('@babel/core');

function load(file, mocks = {}) {
  const absolute = path.resolve(file);
  const code = babel.transformFileSync(absolute, { plugins: ['@babel/plugin-transform-modules-commonjs'] }).code;
  const instance = new Module(absolute, module);
  instance.filename = absolute;
  instance.paths = Module._nodeModulePaths(path.dirname(absolute));
  const originalRequire = instance.require.bind(instance);
  instance.require = (id) => Object.prototype.hasOwnProperty.call(mocks, id) ? mocks[id] : originalRequire(id);
  instance._compile(code, absolute);
  return instance.exports;
}

const runtime = load('src/config/runtime.js');
const compose = load('src/utils/composeProject.js', {
  '../config/runtime': runtime,
  './workspace': { writeWorkspaceFile: async () => ({ success: true }) },
});

const project = {
  id: 'pipeline-test', platform: 'android-compose', name: 'Pipeline Test', slug: 'pipeline-test',
  projectDir: '/root/compose-projects/pipeline-test', packageName: 'com.test.pipeline', namespace: 'com.test.pipeline',
  versionName: '1.0.0', versionCode: 1, minSdk: 24, targetSdk: 36, compileSdk: 37, javaVersion: 17,
  agpVersion: '9.2.0', gradleVersion: '9.4.1', kotlinVersion: '2.3.21', composeBom: '2026.06.00',
  gradleDependencies: ['io.coil-kt.coil3:coil-compose:3.3.0'],
  theme: { primaryColor: '#4F46E5', secondaryColor: '#0E7490', backgroundColor: '#F8FAFC', dynamicColor: true },
  variables: [{ name: 'counter', type: 'number', value: 0 }],
  screens: [{
    id: 'main', name: 'Home', actionBarTitle: 'Home', showActionBar: true, backgroundColor: '#F8FAFC',
    rootComponent: { id: 'root', type: 'Column', props: { width: 'match_parent', height: 'match_parent', padding: 16, spacing: 8 }, children: [
      { id: 'title', type: 'Text', props: { text: 'Jetpack Compose', textSize: 24, textColor: '#111827', textStyle: 'bold' }, children: [] },
      { id: 'button', type: 'Button', props: { text: 'Run', width: 'match_parent', backgroundColor: '#4F46E5' }, children: [] },
    ] },
    blocks: [{ id: 'click', definitionId: 'on_click', inputs: { 'компонент': 'button' }, children: { next: [{ id: 'toast', definitionId: 'show_toast', inputs: { text: 'Works' }, children: {} }] } }],
  }],
};

const files = compose.createComposeProjectFiles(project);
const required = [
  'settings.gradle.kts', 'build.gradle.kts', 'gradlew', 'app/build.gradle.kts',
  'app/src/main/AndroidManifest.xml',
  'app/src/main/java/com/test/pipeline/MainActivity.kt',
  'app/src/main/java/com/test/pipeline/ui/screens/HomeScreen.kt',
  'app/src/main/java/com/test/pipeline/ui/theme/Theme.kt',
];
for (const name of required) {
  if (!files[name]) throw new Error(`Missing generated file: ${name}`);
}
const screen = files['app/src/main/java/com/test/pipeline/ui/screens/HomeScreen.kt'];
const assertions = [
  [files['app/build.gradle.kts'].includes('org.jetbrains.kotlin.plugin.compose'), 'Compose compiler plugin'],
  [files['app/build.gradle.kts'].includes('compose-bom:2026.06.00'), 'Compose BOM'],
  [files['app/build.gradle.kts'].includes('coil-compose:3.3.0'), 'Gradle library'],
  [screen.includes('@Preview'), '@Preview'],
  [screen.includes('@Composable'), '@Composable'],
  [screen.includes('Toast.makeText'), 'compiled visual block'],
  [screen.includes('Button(onClick'), 'Compose Button'],
  [files.gradlew.includes('VERSION="9.4.1"') && files.gradlew.includes('services.gradle.org/distributions'), 'Gradle wrapper'],
];
for (const [condition, label] of assertions) if (!condition) throw new Error(`Failed assertion: ${label}`);
for (const [name, value] of Object.entries(files)) if (/\bundefined\b/.test(value)) throw new Error(`undefined emitted in ${name}`);

console.log(`PASS: generated ${Object.keys(files).length} native Jetpack Compose files`);
console.log('PASS: Kotlin @Composable, @Preview, Gradle tasks and block logic are present');
