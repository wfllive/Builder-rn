# Чистое обновление в Termux

Не копируйте только `App.tsx`: версия 1.1 содержит также `app.json`, `package.json` и папку `patches`.

```bash
cd ~/pura-c
rm -rf node_modules android .expo
# распакуйте сюда все файлы PuraProVideo-Pro-v3.zip с заменой
ls patches/react-native-vision-camera+5.2.2.patch
yarn install
```

В выводе обязательно должно быть:

```text
Applying patches...
react-native-vision-camera@5.2.2 ✔
```

В `app.json` нельзя добавлять `react-native-vision-camera` в массив `plugins`: у версии 5.2.2 нет Expo config plugin. Разрешения уже указаны напрямую в `android.permissions`.

Далее обязательна новая нативная сборка:

```bash
npx expo prebuild --platform android --clean
npx expo run:android
npx expo start --dev-client --clear
```

После изменения `orientation` и нативного Camera2-патча старый APK использовать нельзя.
