/// <reference types="nativewind/types" />

/**
 * Типы NativeWind: добавляют `className` ко всем RN-компонентам.
 * Не удалять — без этого TypeScript будет ругаться на className.
 */
