/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./App.{js,jsx,ts,tsx}",
    "./src/**/*.{js,jsx,ts,tsx}",
    "./modules/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // NativeWind + theme colors mapped to the app's design system
        primary: '#4F46E5',
        bg: '#F4F6FA',
        bgCard: '#FFFFFF',
        text: '#0F172A',
        textSecondary: '#64748B',
        textTertiary: '#94A3B8',
        border: '#E2E8F0',
        borderLight: '#F1F5F9',
        info: '#3B82F6',
        infoBg: '#EFF6FF',
        infoText: '#1D4ED8',
        success: '#10B981',
        successBg: '#ECFDF5',
        successText: '#047857',
        warning: '#F59E0B',
        warningBg: '#FFFBEB',
        warningText: '#B45309',
        error: '#EF4444',
        errorBg: '#FEF2F2',
        errorText: '#B91C1C',
        terminal: '#0D1117',
        terminalRaised: '#161B22',
        bgElevated: '#1E293B',
        bgInput: '#0F172A',
        primarySurface: '#EEF2FF',
      },
    },
  },
  plugins: [],
  corePlugins: {
    // NativeWind handles React Native-specific utilities
    preflight: false,
  },
};
