/**
 * Tailwind для NativeWind.
 * Цвета — HEX, не CSS-переменные.
 * `bg-primary/10` на Android безопасен; `bg-[var(--x)]/10` — нет
 * (color-mix роняет Yoga без JS-ошибки).
 */
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.ts",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  presets: [require("nativewind/preset")],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: "#5F18DA",
        ink: "#111111",
        muted: "#A9A9A9",
        paper: "#ffffff",
        modal: "#ffffff",
        input: "#F0F0F0",
        placeholder: "#C8C8C8",
        danger: "#de5567",
        warning: "#e07436",
        success: "#5bbb50",
      },
    },
  },
  plugins: [],
};
