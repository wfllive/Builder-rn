/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#5F18DA',
          light: '#701dff',
        },
        secondary: '#a36eff',
        tertiary: '#510082',
        danger: '#de5567',
        success: '#5bbb50',
        warning: '#e07436',
        neutral: {
          white: '#ffffff',
          black: '#000000',
          grey: {
            0: '#cacaca',
            1: '#6D6B6B',
          },
        },
      },
      fontFamily: {
        sans: ['Nunito', 'sans-serif'],
      },
    },
  },
  plugins: [],
  darkMode: 'class',
};