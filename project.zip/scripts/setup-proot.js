#!/usr/bin/env node
/**
 * setup-proot.js
 * --------------
 * Скачивает статический proot и кладёт его в нативные библиотеки модуля termux-terminal
 * как libproot.so. После пересборки dev-client этот файл извлекается в ИСПОЛНЯЕМУЮ директорию
 * nativeLibraryDir, и приложение сможет запускать полноценный Linux (rootfs) через proot даже
 * на Android 10+/Huawei (где данные приложения noexec).
 *
 * Использование (в корне проекта; на ПК ИЛИ прямо на телефоне в Termux — нужен интернет):
 *   node scripts/setup-proot.js            # РЕКОМЕНДУЕТСЯ: 64-бит (aarch64) proot -> работает apt
 *   node scripts/setup-proot.js --armhf    # 32-бит (armhf) proot (старый вариант, apt ломается)
 *
 * По умолчанию (aarch64): loader НЕ нужен отдельно — у ванильного proot v5.3.0 loader ВСТРОЕН
 * в бинарник и извлекается во временную папку (PROOT_TMP_DIR, её задаёт приложение). Поэтому
 * скрипт удаляет старый libloader.so, если он есть.
 *
 * ВАЖНО: aarch64 proot запускается только на 64-битных устройствах (почти все современные).
 * Если устройство строго 32-битное — используйте --armhf.
 *
 * EAS-сборка: скрипт вызывается автоматически хуком eas-build-post-install (см. package.json),
 * поэтому при `npm run bd` бинарник подтянется на сервере сборки сам — вручную качать не надо.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ---- CONFIG -----------------------------------------------------------------
const CONFIG = {
  abi: 'arm64-v8a',
  mode: 'aarch64', // 'aarch64' (default, apt works) | 'armhf' (legacy)
  prootUrl: '',    // filled from mode below
  loaderUrl: '',   // only for armhf
};

const AARCH64_PROOT_URL =
  'https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static';
const ARMHF_PROOT_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/proot';
const ARMHF_LOADER_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/loader';

function applyMode(mode) {
  CONFIG.mode = mode;
  if (mode === 'armhf') {
    CONFIG.prootUrl = ARMHF_PROOT_URL;
    CONFIG.loaderUrl = ARMHF_LOADER_URL;
  } else {
    CONFIG.prootUrl = AARCH64_PROOT_URL;
    CONFIG.loaderUrl = ''; // embedded loader, no external file
  }
}
applyMode('aarch64');

// ---- parse args -------------------------------------------------------------
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--proot' && args[i + 1]) CONFIG.prootUrl = args[++i];
  else if (args[i] === '--loader' && args[i + 1]) CONFIG.loaderUrl = args[++i];
  else if (args[i] === '--abi' && args[i + 1]) CONFIG.abi = args[++i];
  else if (args[i] === '--aarch64') applyMode('aarch64');
  else if (args[i] === '--armhf') applyMode('armhf');
}

const DEST_DIR = path.join(
  __dirname,
  '..',
  'modules',
  'termux-terminal',
  'android',
  'src',
  'main',
  'jniLibs',
  CONFIG.abi
);

function download(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 12) return reject(new Error('Too many redirects for ' + url));
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'sk-pro-setup' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        const loc = res.headers.location;
        if (!loc) return reject(new Error('Redirect without Location for ' + url));
        const next = new URL(loc, url).toString();
        return resolve(download(next, dest, redirects + 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const file = fs.createWriteStream(dest);
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve(dest)));
      file.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(90000, () => req.destroy(new Error('Timeout downloading ' + url)));
  });
}

function looksLikeElf(file) {
  try {
    const fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(20);
    fs.readSync(fd, buf, 0, 20, 0);
    fs.closeSync(fd);
    const isElf = buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46;
    if (!isElf) return { elf: false };
    const bits = buf[4] === 2 ? 64 : buf[4] === 1 ? 32 : 0;
    const machine = buf.readUInt16LE(18);
    const machName = { 40: 'ARM/armhf', 183: 'AArch64/arm64', 3: 'x86', 62: 'x86_64' }[machine] || ('machine=' + machine);
    return { elf: true, bits, machine, machName };
  } catch (e) {
    return { elf: false };
  }
}

(async () => {
  console.log('setup-proot: mode =', CONFIG.mode, '| ABI =', CONFIG.abi);
  console.log('dest dir   :', DEST_DIR);
  fs.mkdirSync(DEST_DIR, { recursive: true });

  const targets = [{ name: 'libproot.so', url: CONFIG.prootUrl }];
  if (CONFIG.loaderUrl) targets.push({ name: 'libloader.so', url: CONFIG.loaderUrl });

  let ok = true;
  for (const t of targets) {
    const dest = path.join(DEST_DIR, t.name);
    process.stdout.write(`Downloading ${t.name} ... `);
    try {
      await download(t.url, dest);
      const size = fs.statSync(dest).size;
      const info = looksLikeElf(dest);
      if (info.elf && size > 50000) {
        console.log(`${(size / 1024).toFixed(0)} KB (ELF ✓, ${info.bits}-bit ${info.machName})`);
      } else if (info.elf) {
        console.log(`${(size / 1024).toFixed(0)} KB (ELF, но подозрительно мал — возможно не тот файл)`);
        ok = false;
      } else {
        console.log(`${(size / 1024).toFixed(0)} KB (NOT an ELF ✗ — wrong URL / redirect?)`);
        ok = false;
      }
      try { fs.chmodSync(dest, 0o755); } catch (e) {}
    } catch (e) {
      console.log('FAILED:', e.message);
      ok = false;
    }
  }

  // aarch64 proot has the loader embedded -> remove any stale external loader (which would be the
  // wrong arch and break things if PROOT_LOADER pointed to it).
  if (ok && CONFIG.mode === 'aarch64') {
    const staleLoader = path.join(DEST_DIR, 'libloader.so');
    if (fs.existsSync(staleLoader)) {
      try { fs.unlinkSync(staleLoader); console.log('Removed stale libloader.so (aarch64 proot uses embedded loader).'); } catch (e) {}
    }
  }

  console.log('');
  if (ok) {
    console.log('✓ proot помещён в jniLibs (' + CONFIG.mode + ').');
  } else {
    console.log('⚠ Скачивание не удалось. Проверьте интернет/URL.');
    console.log('  aarch64 источник: ' + AARCH64_PROOT_URL);
  }
  console.log('');
  console.log('Дальше (если качали вручную): закоммитьте jniLibs и пересоберите:');
  console.log('  git add -A && git commit -m "proot ' + CONFIG.mode + '" && git push');
  console.log('  npm run pr && npm run bd');
  console.log('В приложении: Terminal -> "Установить Linux" (образ подберётся под разрядность proot).');
  process.exit(ok ? 0 : 1);
})();
