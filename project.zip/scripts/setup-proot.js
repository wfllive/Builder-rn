#!/usr/bin/env node
/**
 * setup-proot.js
 * --------------
 * Скачивает статический proot (+ его loader) и кладёт их в нативные библиотеки модуля
 * termux-terminal как libproot.so / libloader.so. После пересборки dev-client эти файлы
 * извлекаются в ИСПОЛНЯЕМУЮ директорию nativeLibraryDir, и приложение сможет запускать
 * полноценный Linux (rootfs) через proot даже на Android 10+/Huawei (где данные приложения noexec).
 *
 * Использование (на ПК, в корне проекта):
 *   node scripts/setup-proot.js
 *
 * Затем:
 *   npm run pr && npm run bd      # пересобрать dev-client
 *   (в приложении: Terminal -> "Установить Linux" для загрузки rootfs с apt)
 *
 * ВАЖНО про источники бинарников:
 *  - По умолчанию используется ZhymabekRoman/proot-static (статический proot из Termux,
 *    armhf; по заверению автора работает и на arm64). Полностью статический, без зависимостей.
 *  - Если ваше устройство ТОЛЬКО 64-битное (без поддержки 32-бит), нужен aarch64-статик proot.
 *    Укажите свои URL через переменные ниже или аргументы:
 *      node scripts/setup-proot.js --proot <URL> --loader <URL> --abi arm64-v8a
 *    Кандидаты (проверяйте актуальность, я не могу их протестировать отсюда):
 *      aarch64 static proot: https://sourceforge.net/projects/proot.mirror/files/v5.3.0/proot-v5.3.0-aarch64-static/download
 *      GitLab CI (proot+loader): https://proot-me.github.io/  (артефакты пайплайнов proot-me/proot)
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ---- CONFIG (можно переопределить аргументами) ------------------------------
const CONFIG = {
  // ABI, в который кладём бинарники. arm64-v8a для современных телефонов.
  abi: 'arm64-v8a',
  // Статический proot из Termux (armhf/32-bit; по заверению автора работает и на arm64,
  // ЕСЛИ у устройства есть 32-битная поддержка). Патченый под Termux: есть --link2symlink,
  // нужный для apt/dpkg. Полностью статический, без зависимостей.
  prootUrl:
    'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/proot',
  // loader, который proot читает через PROOT_LOADER (нужен для запуска гостевых бинарников).
  // Архитектурно совпадает с proot выше (armhf).
  loaderUrl:
    'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/loader',
};

// ---- parse args -------------------------------------------------------------
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--proot' && args[i + 1]) CONFIG.prootUrl = args[++i];
  else if (args[i] === '--loader' && args[i + 1]) CONFIG.loaderUrl = args[++i];
  else if (args[i] === '--abi' && args[i + 1]) CONFIG.abi = args[++i];
  else if (args[i] === '--aarch64') {
    // 64-битный вариант (для устройств БЕЗ 32-битной поддержки). ВНИМАНИЕ: это ванильный proot
    // (без Termux-патча --link2symlink) — apt/dpkg могут ругаться на hard links; и к нему нужен
    // СВОЙ aarch64 loader. Проверяйте актуальность URL; источник может быть нестабильным.
    CONFIG.prootUrl =
      'https://sourceforge.net/projects/proot.mirror/files/v5.3.0/proot-v5.3.0-aarch64-static/download';
    console.log('⚠ --aarch64: используется ванильный aarch64 proot (без --link2symlink).');
    console.log('  Для apt может понадобиться aarch64 loader и обход hard-links.');
  }
}

const DEST_DIR = path.join(
  __dirname,
  '..',
  'modules',
  'termux-terminal',
  'android',
  'src',
  'main',
  'jniLibs',
  CONFIG.abi
);

function download(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 10) return reject(new Error('Too many redirects for ' + url));
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'sk-pro-setup' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        const loc = res.headers.location;
        const next = new URL(loc, url).toString();
        return resolve(download(next, dest, redirects + 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const file = fs.createWriteStream(dest);
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve(dest)));
      file.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(60000, () => req.destroy(new Error('Timeout downloading ' + url)));
  });
}

function looksLikeElf(file) {
  try {
    const fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(20);
    fs.readSync(fd, buf, 0, 20, 0);
    fs.closeSync(fd);
    const isElf = buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46;
    if (!isElf) return { elf: false };
    const bits = buf[4] === 2 ? 64 : buf[4] === 1 ? 32 : 0;
    const machine = buf.readUInt16LE(18);
    const machName = { 40: 'ARM/armhf', 183: 'AArch64/arm64', 3: 'x86', 62: 'x86_64' }[machine] || ('machine=' + machine);
    return { elf: true, bits, machine, machName };
  } catch (e) {
    return { elf: false };
  }
}

(async () => {
  console.log('setup-proot: ABI =', CONFIG.abi);
  console.log('dest dir   :', DEST_DIR);
  fs.mkdirSync(DEST_DIR, { recursive: true });

  const targets = [
    { name: 'libproot.so', url: CONFIG.prootUrl },
    { name: 'libloader.so', url: CONFIG.loaderUrl },
  ];

  let ok = true;
  for (const t of targets) {
    const dest = path.join(DEST_DIR, t.name);
    process.stdout.write(`Downloading ${t.name} ... `);
    try {
      await download(t.url, dest);
      const size = fs.statSync(dest).size;
      const info = looksLikeElf(dest);
      if (info.elf) {
        console.log(`${(size / 1024).toFixed(0)} KB (ELF ✓, ${info.bits}-bit ${info.machName})`);
        if (info.bits === 32) {
          console.log('   ⚠ 32-битный бинарник: запустится только если у устройства есть 32-битная поддержка.');
          console.log('     Если proot не стартует (см. диагностику в приложении) — попробуйте --aarch64.');
        }
      } else {
        console.log(`${(size / 1024).toFixed(0)} KB (NOT an ELF ✗ — wrong URL?)`);
        ok = false;
      }
      // make sure it's marked executable in the repo checkout (harmless; APK packaging decides)
      try { fs.chmodSync(dest, 0o755); } catch (e) {}
    } catch (e) {
      console.log('FAILED:', e.message);
      ok = false;
    }
  }

  console.log('');
  if (ok) {
    console.log('✓ proot + loader помещены в jniLibs.');
  } else {
    console.log('⚠ Не все бинарники скачались/корректны. Проверьте URL в CONFIG или через --proot/--loader.');
    console.log('  loader обязателен: без него proot не сможет запускать бинарники rootfs.');
  }
  console.log('');
  console.log('Дальше:');
  console.log('  1) npm run pr && npm run bd   # пересобрать dev-client');
  console.log('  2) В приложении: Terminal -> "Установить Linux" (скачает rootfs с apt).');
  console.log('     Если стандартный URL rootfs устарел, задайте свой в modules/apt-manager');
  console.log('     (DEFAULT_ROOTFS_URL) или передайте в apt.installProotRootfs(url).');
  process.exit(ok ? 0 : 1);
})();
