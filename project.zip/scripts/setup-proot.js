#!/usr/bin/env node
/**
 * setup-proot.js
 * --------------
 * Скачивает статический proot и кладёт его в нативные библиотеки модуля termux-terminal
 * как libproot.so. После пересборки dev-client этот файл извлекается в ИСПОЛНЯЕМУЮ директорию
 * nativeLibraryDir, и приложение сможет запускать полноценный Linux (rootfs) через proot даже
 * на Android 10+/Huawei (где данные приложения noexec).
 *
 * Использование (в корне проекта; на ПК ИЛИ прямо на телефоне в Termux — нужен интернет):
 *   node scripts/setup-proot.js            # ДЕФОЛТ: armhf proot, патченый под Termux/Android
 *                                          #   (ЗАПУСКАЕТ гостей на строгих устройствах вроде Huawei;
 *                                          #    это 32-битный proot, гостевой образ нужен armhf)
 *   node scripts/setup-proot.js --aarch64  # ванильный 64-бит proot-me v5.3.0 (ЭКСПЕРИМЕНТАЛЬНО:
 *                                          #   на обычных Linux-устройствах ок, но на Huawei/строгом
 *                                          #   Android гости НЕ стартуют — нет Android-патчей)
 *
 * ПОЧЕМУ ДЕФОЛТ armhf: ванильный proot-me собран для обычного Linux и на строгом Android/Huawei
 * молча падает (code 255) при запуске гостей. Termux-патченый proot (источник ZhymabekRoman,
 * статическая сборка Termux-форка) содержит Android-патчи ptrace/seccomp и РЕАЛЬНО запускает
 * гостей. Он 32-битный, поэтому гостевой образ по умолчанию тоже armhf (выбирается в приложении).
 *
 * Для armhf proot loader идёт из того же источника (libloader.so, совместимый) — извлекать его
 * из бинарника НЕ нужно (извлечение --aarch64-специфично).
 *
 * Если хочешь подсунуть свой loader вручную (редко нужно):
 *   node scripts/setup-proot.js --loader /путь/к/loader
 *
 * EAS-сборка: скрипт вызывается автоматически хуком eas-build-post-install (см. package.json),
 * поэтому при `npm run bd` бинарник подтянется на сервере сборки сам — вручную качать не надо.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync, spawn } = require('child_process');

// ---- CONFIG -----------------------------------------------------------------
const CONFIG = {
  abi: 'arm64-v8a',
  mode: 'aarch64', // 'aarch64' (default, apt works) | 'armhf' (legacy)
  prootUrl: '',    // filled from mode below
  loaderUrl: '',   // only for armhf
};

const AARCH64_PROOT_URL =
  'https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static';
const ARMHF_PROOT_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/proot';
const ARMHF_LOADER_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/loader';

function applyMode(mode) {
  CONFIG.mode = mode;
  if (mode === 'armhf') {
    CONFIG.prootUrl = ARMHF_PROOT_URL;
    CONFIG.loaderUrl = ARMHF_LOADER_URL;
  } else {
    CONFIG.prootUrl = AARCH64_PROOT_URL;
    CONFIG.loaderUrl = ''; // embedded loader, no external file
  }
}
applyMode('armhf');

// ---- parse args -------------------------------------------------------------
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--proot' && args[i + 1]) CONFIG.prootUrl = args[++i];
  else if (args[i] === '--loader' && args[i + 1]) CONFIG.loaderUrl = args[++i];
  else if (args[i] === '--abi' && args[i + 1]) CONFIG.abi = args[++i];
  else if (args[i] === '--aarch64') applyMode('aarch64');
  else if (args[i] === '--armhf') applyMode('armhf');
}

const DEST_DIR = path.join(
  __dirname,
  '..',
  'modules',
  'termux-terminal',
  'android',
  'src',
  'main',
  'jniLibs',
  CONFIG.abi
);

function download(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 12) return reject(new Error('Too many redirects for ' + url));
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'sk-pro-setup' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        const loc = res.headers.location;
        if (!loc) return reject(new Error('Redirect without Location for ' + url));
        const next = new URL(loc, url).toString();
        return resolve(download(next, dest, redirects + 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      const file = fs.createWriteStream(dest);
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve(dest)));
      file.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(90000, () => req.destroy(new Error('Timeout downloading ' + url)));
  });
}

function looksLikeElf(file) {
  try {
    const fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(20);
    fs.readSync(fd, buf, 0, 20, 0);
    fs.closeSync(fd);
    const isElf = buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46;
    if (!isElf) return { elf: false };
    const bits = buf[4] === 2 ? 64 : buf[4] === 1 ? 32 : 0;
    const machine = buf.readUInt16LE(18);
    const machName = { 40: 'ARM/armhf', 183: 'AArch64/arm64', 3: 'x86', 62: 'x86_64' }[machine] || ('machine=' + machine);
    return { elf: true, bits, machine, machName };
  } catch (e) {
    return { elf: false };
  }
}

/**
 * Extract the loader that is EMBEDDED inside the given (static) proot binary, by running that very
 * proot once on the current host. proot writes its built-in loader to $PROOT_TMP_DIR/prootedXXXXXX
 * and (importantly) does NOT delete it on exit. The extracted loader is byte-for-byte compatible
 * with that proot (same LOADER_ADDRESS / protocol), which a foreign loader (e.g. Termux's) is not.
 *
 * This only works when the host can actually execute the proot binary (i.e. an aarch64 device for
 * the aarch64 proot - like Termux on the phone). On an x86_64 PC the exec fails and we return
 * false (caller falls back to the embedded loader via code_cache).
 */
function tryExtractLoader(prootBin, destLoader) {
  const baseTmp = process.env.TMPDIR || (process.env.PREFIX ? process.env.PREFIX + '/tmp' : os.tmpdir());
  let tmp;
  try { fs.mkdirSync(baseTmp, { recursive: true }); tmp = fs.mkdtempSync(path.join(baseTmp, 'proot-extract-')); }
  catch (e) { console.log('(mktemp failed: ' + e.message + ')'); return false; }

  const env = Object.assign({}, process.env, { PROOT_TMP_DIR: tmp, PROOT_NO_SECCOMP: '1' });
  // For EXTRACTION we don't need any --bind / --rootfs: proot writes its embedded loader to
  // $PROOT_TMP_DIR/prooted-<pid>-XXXXXX when it intercepts the FIRST execve. A talloc destructor
  // then DELETES that file when proot exits, so we keep proot alive with a blocking guest (sleep)
  // and copy the loader while proot runs. Minimal argv = fewer startup checks that could abort.
  let child, prootStderr = '', prootError = '', prootExit = null, prootSignal = null;
  try {
    child = spawn(prootBin, ['/system/bin/sh', '-c', 'sleep 6'], { env, stdio: ['ignore', 'ignore', 'pipe'] });
  } catch (e) { console.log('(spawn threw: ' + e.message + ')'); return false; }
  if (child.stderr) child.stderr.on('data', (d) => { prootStderr += d.toString(); });
  child.on('error', (e) => { prootError = String(e && e.message || e); });
  child.on('exit', (code, sig) => { prootExit = code; prootSignal = sig; });

  const syncSleep = (ms) => { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (e) {} };
  let found = null;
  const deadline = Date.now() + 9000;
  while (!found && Date.now() < deadline) {
    try {
      for (const name of fs.readdirSync(tmp)) {
        if (name.startsWith('prooted')) {
          const p = path.join(tmp, name);
          try { if (fs.statSync(p).size > 500) { found = p; break; } } catch (e) {}
        }
      }
    } catch (e) {}
    if (!found) syncSleep(5);
  }

  try { child.kill('SIGKILL'); } catch (e) {}
  syncSleep(100); // let 'exit'/'error' events flush

  if (found) {
    fs.copyFileSync(found, destLoader);
    try { fs.chmodSync(destLoader, 0o755); } catch (e) {}
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
    return true;
  }
  const listing = (() => { try { return fs.readdirSync(tmp).join(', ') || '<empty>'; } catch (e) { return '<err>'; } })();
  console.log(`(no loader file; pid=${child.pid} exit=${prootExit} signal=${prootSignal} ` +
    `err=${prootError || '-'} tmp=[${listing}] stderr=${prootStderr.slice(0, 300).replace(/\s+/g, ' ').trim()})`);
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
  return false;
}

(async () => {
  console.log('setup-proot: mode =', CONFIG.mode, '| ABI =', CONFIG.abi);
  console.log('dest dir   :', DEST_DIR);
  fs.mkdirSync(DEST_DIR, { recursive: true });

  // Always fetch a fresh proot (these binaries are git-ignored build artifacts; re-downloading the
  // ~1.4MB static binary is cheap and avoids ever building with a stale/wrong-arch proot). The
  // loader is (re)extracted below so it always matches this proot.
  const targets = [{ name: 'libproot.so', url: CONFIG.prootUrl }];
  if (CONFIG.loaderUrl) targets.push({ name: 'libloader.so', url: CONFIG.loaderUrl });

  let ok = true;
  for (const t of targets) {
    const dest = path.join(DEST_DIR, t.name);
    const isLocal = fs.existsSync(t.url);
    process.stdout.write(`${isLocal ? 'Copying' : 'Downloading'} ${t.name} ... `);
    try {
      if (isLocal) {
        fs.copyFileSync(t.url, dest);
      } else {
        await download(t.url, dest);
      }
      const size = fs.statSync(dest).size;
      const info = looksLikeElf(dest);
      if (info.elf && size > 1000) {
        console.log(`${(size / 1024).toFixed(0)} KB (ELF ✓, ${info.bits}-bit ${info.machName})`);
      } else if (info.elf) {
        console.log(`${(size / 1024).toFixed(0)} KB (ELF, но слишком мал — возможно битый файл)`);
        ok = false;
      } else {
        console.log(`${(size / 1024).toFixed(0)} KB (NOT an ELF ✗ — wrong URL / redirect?)`);
        ok = false;
      }
      try { fs.chmodSync(dest, 0o755); } catch (e) {}
    } catch (e) {
      console.log('FAILED:', e.message);
      ok = false;
    }
  }

  // The embedded loader can't be exec'd on strict devices (Huawei: SELinux blocks even code_cache),
  // and a foreign loader (e.g. Termux's) is INCOMPATIBLE with the vanilla proot (different
  // LOADER_ADDRESS). So extract the loader that is baked into THIS proot binary (guaranteed
  // compatible) by running it once on the current aarch64 host (Termux). The extracted file is then
  // shipped as libloader.so in the executable native-lib dir and used via PROOT_LOADER.
  if (ok && CONFIG.mode === 'aarch64' && !CONFIG.loaderUrl) {
    const destLoader = path.join(DEST_DIR, 'libloader.so');
    const prootBin = path.join(DEST_DIR, 'libproot.so');
    // Drop any stale / foreign loader first; the matched one is extracted next (so a leftover
    // Termux loader can't survive and cause a silent 255 from a proot/loader mismatch).
    try { if (fs.existsSync(destLoader)) fs.unlinkSync(destLoader); } catch (e) {}
    process.stdout.write('Extracting built-in loader (runs proot once on this device) ... ');
    if (tryExtractLoader(prootBin, destLoader)) {
      const info = looksLikeElf(destLoader);
      console.log(`OK (${(fs.statSync(destLoader).size / 1024).toFixed(0)} KB${info.elf ? ', ELF ' + info.bits + '-bit ' + info.machName : ''})`);
    } else {
      console.log('could not extract (not an aarch64 host?); no external loader -> proot uses embedded loader via code_cache');
    }
  }

  console.log('');
  if (ok) {
    console.log('✓ proot помещён в jniLibs (' + CONFIG.mode + ').');
  } else {
    console.log('⚠ Скачивание не удалось. Проверьте интернет/URL.');
    console.log('  aarch64 источник: ' + AARCH64_PROOT_URL);
  }
  console.log('');
  console.log('Дальше (если качали вручную): закоммитьте jniLibs и пересоберите:');
  console.log('  git add -A && git commit -m "proot ' + CONFIG.mode + '" && git push');
  console.log('  npm run pr && npm run bd');
  console.log('В приложении: Terminal -> "Установить Linux" (образ подберётся под разрядность proot).');
  process.exit(ok ? 0 : 1);
})();
