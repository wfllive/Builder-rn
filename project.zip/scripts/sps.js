#!/usr/bin/env node
'use strict';

const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

const PROOT_PACKAGE_URL =
  'https://raw.githubusercontent.com/green-green-avk/build-proot-android/master/packages/proot-android-aarch64.tar.gz';

const DEST_DIR = path.join(
  __dirname,
  '..',
  'modules',
  'termux-terminal',
  'android',
  'src',
  'main',
  'jniLibs',
  'arm64-v8a'
);

const DEST_PROOT = path.join(DEST_DIR, 'libproot.so');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function safeUnlink(file) {
  try {
    fs.unlinkSync(file);
  } catch (_) {
    // File does not exist — fine.
  }
}

function download(url, destination, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 10) {
      reject(new Error('Too many redirects'));
      return;
    }

    safeUnlink(destination);

    https.get(url, {
      headers: { 'User-Agent': 'sp-static/1.0' }
    }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();

        if (!res.headers.location) {
          reject(new Error('Redirect without Location header'));
          return;
        }

        resolve(download(
          new URL(res.headers.location, url).toString(),
          destination,
          redirects + 1
        ));
        return;
      }

      if (res.statusCode !== 200) {
        res.resume();
        reject(new Error(`HTTP ${res.statusCode} for ${url}`));
        return;
      }

      const output = fs.createWriteStream(destination);
      res.pipe(output);

      output.on('finish', () => output.close(() => resolve(destination)));
      output.on('error', (err) => {
        safeUnlink(destination);
        reject(err);
      });
    }).on('error', (err) => {
      safeUnlink(destination);
      reject(err);
    });
  });
}

function parseElf(file) {
  const fd = fs.openSync(file, 'r');

  try {
    const buf = Buffer.alloc(64);
    const n = fs.readSync(fd, buf, 0, buf.length, 0);

    if (n < 20 ||
        buf[0] !== 0x7f ||
        buf[1] !== 0x45 ||
        buf[2] !== 0x4c ||
        buf[3] !== 0x46) {
      return null;
    }

    return {
      bits: buf[4] === 2 ? 64 : buf[4] === 1 ? 32 : 0,
      machine: buf.readUInt16LE(18),
      type: buf.readUInt16LE(16)
    };
  } finally {
    fs.closeSync(fd);
  }
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    encoding: 'utf8',
    ...options
  });

  if (result.error) {
    throw result.error;
  }

  if (result.status !== 0) {
    throw new Error(
      `${command} failed:\n${result.stderr || result.stdout || 'unknown error'}`
    );
  }

  return result.stdout;
}

async function main() {
  ensureDir(DEST_DIR);

  // Важно: имя должно быть именно libproot.so, без Markdown-ссылки.
  for (const file of [
    'libproot.so',
    'libloader.so',
    'libtalloc.so',
    'libtalloc.so.2',
    'libandroid-shmem.so'
  ]) {
    safeUnlink(path.join(DEST_DIR, file));
  }

  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'proot-download-'));
  const archive = path.join(tempDir, 'proot-android-aarch64.tar.gz');

  try {
    console.log(`[download] ${PROOT_PACKAGE_URL}`);
    await download(PROOT_PACKAGE_URL, archive);

    console.log('[extract] package...');
    run('tar', ['-xzf', archive, '-C', tempDir]);

    // В архиве PRoot находится по пути bin/proot.
    const candidates = [
      path.join(tempDir, 'bin', 'proot'),
      path.join(tempDir, 'proot', 'bin', 'proot')
    ];

    const source = candidates.find(fs.existsSync);

    if (!source) {
      throw new Error(
        'PRoot binary was not found after extraction. ' +
        'Inspect the archive contents with: tar -tzf <archive>'
      );
    }

    fs.copyFileSync(source, DEST_PROOT);
    fs.chmodSync(DEST_PROOT, 0o755);

    const elf = parseElf(DEST_PROOT);

    if (!elf) {
      throw new Error('Extracted proot is not an ELF executable');
    }

    if (elf.bits !== 64 || elf.machine !== 183) {
      throw new Error(
        `Wrong executable architecture: ELF${elf.bits}, e_machine=${elf.machine}; expected AArch64 (183)`
      );
    }

    console.log('');
    console.log('✓ PRoot extracted successfully');
    console.log(`  File: ${DEST_PROOT}`);
    console.log(`  Size: ${(fs.statSync(DEST_PROOT).size / 1024).toFixed(0)} KB`);
    console.log('  Architecture: 64-bit AArch64');
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

main().catch((err) => {
  console.error(`\n✗ ${err.message}`);
  process.exit(1);
});