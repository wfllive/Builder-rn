// Тест плагина with-build-config без зависимостей от @expo/config-plugins
import fs from 'fs';

// Вспомогательные парсеры (дублируем логику из плагина)
function findBlockRange(lines, startIdx) {
  let depth = 0;
  let inString = null;
  for (let i = startIdx; i < lines.length; i++) {
    const line = lines[i];
    for (let j = 0; j < line.length; j++) {
      const ch = line[j];
      const nx = line[j + 1];
      if (inString === '/*') { if (ch === '*' && nx === '/') { inString = null; j++; } continue; }
      if (inString === '"' || inString === "'") { if (ch === '\\') { j++; continue; } if (ch === inString) inString = null; continue; }
      if (ch === '/' && nx === '/') break;
      if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
      if (ch === '"' || ch === "'") { inString = ch; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (depth === 0) return [startIdx, i]; }
    }
  }
  return [startIdx, lines.length - 1];
}

function findDirectBlock(lines, from, to, nameRe) {
  let depth = 0, inString = null;
  for (let i = from; i <= to; i++) {
    const line = lines[i];
    for (let j = 0; j < line.length; j++) {
      const ch = line[j]; const nx = line[j + 1];
      if (depth !== 0) {
        if (inString === '/*') { if (ch === '*' && nx === '/') inString = null; j++; continue; }
        if (inString === '"' || inString === "'") { if (ch === '\\') {j++; continue;} if (ch === inString) inString = null; continue; }
        if (inString) inString = null;
        if (ch === '/' && nx === '/') break;
        if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
        if (ch === '"' || ch === "'") { inString = ch; continue; }
        if (ch === '{') depth++;
        else if (ch === '}') depth--;
        continue;
      }
      if (inString === '/*') { if (ch === '*' && nx === '/') inString = null; j++; continue; }
      if (inString === '"' || inString === "'") { if (ch === '\\') {j++; continue;} if (ch === inString) inString = null; continue; }
      if (ch === '/' && nx === '/') break;
      if (ch === '/' && nx === '*') { inString = '/*'; j++; continue; }
      if (ch === '"' || ch === "'") { inString = ch; continue; }
      if (ch === '{') depth++;
    }
    if (depth === 1 && nameRe.test(line.trim())) { const [s,e] = findBlockRange(lines, i); return [s,e]; }
  }
  return [-1,-1];
}

// Загружаем и запускаем editBuildGradle/finalizeBuildGradle в изолированном контексте
const code = fs.readFileSync('./plugins/with-build-config.js', 'utf8')
  .replace(/^const \{ withAppBuildGradle[^;]*;\n/m, '')
  .replace(/^const WarningAggregator = [^;]*;\n/m, '')
  .replace(/^const fs = require\('fs'\);\n/m, '')
  .replace(/^const path = require\('path'\);\n/m, '')
  .replace(/^function readExpectedSha[\s\S]*?^}\n/m, '')
  .replace(/^function readAppVersion[\s\S]*?^}\n/m, '')
  .replace(/^function withBuildConfig[\s\S]*$/, '')
  .replace(/^module\.exports.*$/m, '')
  .replace(/WarningAggregator\.addWarningAndroid\([^)]*\);/g, '/*warning*/');

// Создаём функцию, возвращающую editBuildGradle и finalizeBuildGradle
const factory = new Function(code + '\nreturn { editBuildGradle, finalizeBuildGradle };');
const { editBuildGradle, finalizeBuildGradle } = factory();

// ===== Тест 1: дефолтный шаблон expo prebuild --clean (как прислал пользователь) =====
const TEMPLATE = `apply plugin: "com.android.application"
apply plugin: "org.jetbrains.kotlin.android"
apply plugin: "com.facebook.react"

def projectRoot = rootDir.getAbsoluteFile().getParentFile().getAbsolutePath()

react {
    autolinkLibrariesWithApp()
}

android {
    ndkVersion rootProject.ext.ndkVersion
    buildToolsVersion rootProject.ext.buildToolsVersion
    compileSdk rootProject.ext.compileSdkVersion

    namespace 'ru.wfllive.nova'

    defaultConfig {
        applicationId 'ru.wfllive.nova'
        minSdkVersion rootProject.ext.minSdkVersion
        targetSdkVersion rootProject.ext.targetSdkVersion
        versionCode 1
        versionName "1.0.0"
        buildConfigField "String", "REACT_NATIVE_RELEASE_LEVEL", "\\"stable\\""
    }
    signingConfigs {
        debug {
            storeFile file('debug.keystore')
            storePassword 'android'
            keyAlias 'androiddebugkey'
            keyPassword 'android'
        }
    }
    buildTypes {
        debug { signingConfig signingConfigs.debug }
        release {
            signingConfig signingConfigs.debug
            minifyEnabled false
            proguardFiles getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro"
        }
    }
}
`;

const ctx = { expectedSha256: 'AA:BB:CC:DD', versionCode: 2, versionName: '1.0.1' };

function apply(src) {
  return finalizeBuildGradle(editBuildGradle(src, ctx), ctx);
}

const r1 = apply(TEMPLATE);
console.log('=== РЕЗУЛЬТАТ 1 (из чистого шаблона) ===');
console.log(r1);

const r2 = apply(r1);
console.log('\n=== Идемпотентность (повторный запуск на том же файле) ===');
console.log(r1 === r2 ? '✓ ИДЕМПОТЕНТНО — различий нет' : '✗ ЕСТЬ РАЗЛИЧИЯ');
if (r1 !== r2) {
  const a = r1.split('\n'), b = r2.split('\n');
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if (a[i] !== b[i]) console.log('строка', i, ':\n  <', a[i], '\n  >', b[i]);
  }
}

// Проверки
console.log('\n=== Проверки фич ===');
const checks = [
  ['buildFeatures { buildConfig true }', /buildFeatures\s*\{\s*\n\s*buildConfig true\b/],
  ['findKeystoreFile helper', /def findKeystoreFile = \{ String name ->/],
  ['поиск ncs.keystore по умолчанию', /return new File\(projectRoot, "ncs\.keystore"\)/],
  ['keystorePropsFile = findKeystoreFile', /def keystorePropsFile = findKeystoreFile\("keystore\.properties"\)/],
  ['expectedSha256 из keystore или env', /def expectedSha256 = keystoreProps\.getProperty/],
  ['signingConfigs.release блок', /release\s*\{\s*\n\s*if \(keystorePropsFile\.exists\(\)\)/],
  ['enableV1/V2/V3 signing', /enableV3Signing true/],
  ['env KEYSTORE_FILE fallback', /System\.getenv\("KEYSTORE_FILE"\) != null/],
  ['MYAPP_RELEASE_* gradle props fallback', /findProperty\('MYAPP_RELEASE_STORE_FILE'\)/],
  ['buildConfigField EXPECTED_SIGNATURE_SHA256', /buildConfigField "String", "EXPECTED_SIGNATURE_SHA256"/],
  ['версия versionCode=2', /versionCode 2\b/],
  ['версия versionName="1.0.1"', /versionName "1\.0\.1"/],
  ['hasReleaseKey проверка', /def hasReleaseKey = keystorePropsFile\.exists\(\)/],
  ['GradleException если ключа нет', /throw new GradleException/],
  ['signingConfig signingConfigs.release в release-билдтайпе', /signingConfig signingConfigs\.release/],
  ['debug signing НЕ в release', (() => {
    // Извлекаем блок release { ... } внутри buildTypes (не затрагивая debug)
    const btMatch = r1.match(/buildTypes\s*\{([\s\S]*)\n\}\s*\n/);
    if (!btMatch) return false;
    const bt = btMatch[1];
    const relIdx = bt.indexOf('release {');
    if (relIdx < 0) return false;
    const relBody = bt.slice(relIdx);
    const relEnd = relBody.indexOf('\n    }');
    const rel = relBody.slice(0, relEnd >= 0 ? relEnd : relBody.length);
    return !/signingConfig\s+signingConfigs\.debug/.test(rel);
  })()],
  ['маркеры NCS-KEYSTORE-START/END', /NCS-KEYSTORE-START[\s\S]*NCS-KEYSTORE-END/],
  ['маркер NCS-RELEASE-SIGNING-START', /NCS-RELEASE-SIGNING-START/],
  ['маркер NCS-RELEASE-CHECK-START', /NCS-RELEASE-CHECK-START/],
];

let ok = 0;
for (const [name, cond] of checks) {
  const pass = typeof cond === 'boolean' ? cond : (cond instanceof RegExp ? cond.test(r1) : false);
  console.log(pass ? '✓' : '✗', name);
  if (pass) ok++;
}
console.log(`\n${ok}/${checks.length} проверок пройдено`);
process.exit(ok === checks.length ? 0 : 1);
