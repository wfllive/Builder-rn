#!/data/data/com.termux/files/usr/bin/bash
# build-proot.sh
# ---------------
# Builds a STATIC aarch64 proot binary from source, using Termux + Android NDK.
# Output: modules/termux-terminal/android/src/main/jniLibs/arm64-v8a/libproot.so
#
# Prereqs (run once):
#   pkg install git make clang binutils libtalloc-static file patchelf
#   pkg install wget curl -y
#   # NDK is heavy but required for a proper static build:
#   pkg install android-ndk    # if unavailable, use one from Termux community repos

set -e

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
JNI_DIR="$ROOT_DIR/modules/termux-terminal/android/src/main/jniLibs/arm64-v8a"
BUILD_DIR="$HOME/.cache/build-proot"
SRC_DIR="$BUILD_DIR/proot"

mkdir -p "$BUILD_DIR" "$JNI_DIR"

echo "==> Clone Termux fork of proot"
if [ ! -d "$SRC_DIR/.git" ]; then
  git clone --depth 1 https://github.com/termux/proot.git "$SRC_DIR"
else
  ( cd "$SRC_DIR" && git pull --ff-only )
fi

cd "$SRC_DIR/src"

echo "==> Clean"
make -s clean || true

echo "==> Build static aarch64 proot"
# Static linking flags.
# -DANDROID silences some paths.
# We link libtalloc.a from Termux static package.
export CC="${CC:-clang}"
export CFLAGS="-O2 -DANDROID -Wno-error"
export LDFLAGS="-static -static-libgcc"

# Static talloc from Termux package "libtalloc-static"
TALLOC_INC="$PREFIX/include"
TALLOC_LIB="$PREFIX/lib/libtalloc.a"

if [ ! -f "$TALLOC_LIB" ]; then
  echo "!! $TALLOC_LIB not found. Install: pkg install libtalloc-static"
  exit 1
fi

# Custom LDFLAGS to link talloc statically
export LDFLAGS="$LDFLAGS $TALLOC_LIB"

# Build
make -s proot V=1

BIN="$SRC_DIR/src/proot"
if [ ! -f "$BIN" ]; then
  echo "!! Build failed: $BIN not found"
  exit 1
fi

echo "==> Verify"
file "$BIN"
if command -v readelf >/dev/null 2>&1; then
  readelf -d "$BIN" | grep -E 'NEEDED|RUNPATH' || echo "  (no NEEDED — fully static ✓)"
fi

echo "==> Install to $JNI_DIR/libproot.so"
cp -f "$BIN" "$JNI_DIR/libproot.so"
chmod 755 "$JNI_DIR/libproot.so"

# Clean old deps (not needed for static build)
for f in libloader.so libtalloc.so libtalloc.so.2 libandroid-shmem.so; do
  rm -f "$JNI_DIR/$f"
done

echo ""
echo "═════════════════════════════════════════"
echo "  ✓ Static libproot.so ready:"
ls -la "$JNI_DIR/libproot.so"
echo "═════════════════════════════════════════"