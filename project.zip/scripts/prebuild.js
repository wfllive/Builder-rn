/**
 * prebuild.js — ручная генерация android/ из шаблона + плагин
 *
 * Архитектура:
 *   android/
 *   ├── app/                    # основное RN-приложение (без CMake)
 *   │   └── build.gradle
 *   │       └── implementation project(':prootshell-pty')
 *   └── prootshell-pty/         # отдельный gradle module с CMake
 *       ├── build.gradle
 *       └── src/main/
 *           ├── CMakeLists.txt
 *           ├── prootshell-pty.c
 *           └── AndroidManifest.xml
 *
 * Эта структура решает "manifest still dirty" в AGP 8 + Ninja,
 * потому что CMake вызывается из отдельного gradle subproject,
 * а не из app/build.gradle.
 */
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const ANDROID = path.join(ROOT, 'android');
const PLUGIN = path.join(ROOT, 'plugins/prootshell');
const TEMPLATE = path.join(ROOT, 'node_modules/expo-template-bare-minimum');

const appJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'app.json'), 'utf8'));
const PKG = appJson.expo.android.package;
const APP_NAME = appJson.expo.name;
const TEMPLATE_PKG = 'com.helloworld';

function exists(p) { return fs.existsSync(p); }
function rmrf(p) { if (exists(p)) fs.rmSync(p, { recursive: true, force: true }); }
function mkdirp(p) { fs.mkdirSync(p, { recursive: true }); }
function copyFile(src, dest) {
  mkdirp(path.dirname(dest));
  fs.copyFileSync(src, dest);
}

function patchAndCopy(src, dest, replacements = []) {
  mkdirp(path.dirname(dest));
  if (exists(dest)) {
    try { fs.unlinkSync(dest); } catch {}
  }
  let c = fs.readFileSync(src, 'utf8');
  for (const r of replacements) {
    const [from, to] = r;
    c = c.split(from).join(to);
  }
  fs.writeFileSync(dest, c);
}

function walkCopy(srcDir, destDir, replacements) {
  mkdirp(destDir);
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      walkCopy(s, d, replacements);
    } else {
      if (entry.name.endsWith('.kt') || entry.name.endsWith('.java') ||
          entry.name.endsWith('.xml') || entry.name.endsWith('.gradle') ||
          entry.name.endsWith('.properties')) {
        patchAndCopy(s, d, replacements);
      } else {
        copyFile(s, d);
      }
    }
  }
}

console.log('[prebuild] Cleaning android/');
rmrf(ANDROID);

console.log('[prebuild] Copying template from', TEMPLATE);
if (!exists(TEMPLATE)) {
  console.error('ERROR: expo-template-bare-minimum not installed');
  process.exit(1);
}

const replacements = [
  [TEMPLATE_PKG, PKG],
  ['HelloWorld', APP_NAME],
];

walkCopy(path.join(TEMPLATE, 'android'), ANDROID, replacements);

console.log('[prebuild] Renaming java/com/helloworld -> java/com/prootshell/app');
const srcHelloworld = path.join(ANDROID, 'app/src/main/java/com/helloworld');
const destApp = path.join(ANDROID, `app/src/main/java/com/${PKG.split('.').slice(1).join('/')}`);
if (exists(srcHelloworld)) {
  mkdirp(destApp);
  for (const f of fs.readdirSync(srcHelloworld)) {
    const s = path.join(srcHelloworld, f);
    const d = path.join(destApp, f);
    let c = fs.readFileSync(s, 'utf8');
    c = c.replace(/package com\.helloworld/g, `package ${PKG}`);
    fs.writeFileSync(d, c);
  }
  rmrf(srcHelloworld);
}
rmrf(path.join(ANDROID, 'app/src/main/java/com/helloworld'));

console.log('[prebuild] Copying Java sources from plugin');
const srcJava = path.join(PLUGIN, 'android/java');
if (exists(srcJava)) {
  walkCopy(srcJava, path.join(ANDROID, 'app/src/main/java'));
}

console.log('[prebuild] Copying proot binaries to assets');
const srcAssets = path.join(PLUGIN, 'android/assets/proot');
const destAssets = path.join(ANDROID, 'app/src/main/assets/proot');
if (exists(srcAssets)) {
  rmrf(destAssets);
  mkdirp(destAssets);
  for (const entry of fs.readdirSync(srcAssets, { withFileTypes: true })) {
    if (entry.isFile()) {
      const s = path.join(srcAssets, entry.name);
      const d = path.join(destAssets, entry.name);
      copyFile(s, d);
      fs.chmodSync(d, 0o755);
    }
  }
}

console.log('[prebuild] Patching MainApplication.kt');
const mainApp = path.join(ANDROID, `app/src/main/java/com/${PKG.split('.').slice(1).join('/')}/MainApplication.kt`);
if (exists(mainApp)) {
  let code = fs.readFileSync(mainApp, 'utf8');
  if (!code.includes('com.prootshell.app.ProotPackage')) {
    code = code.replace(
      /import com\.facebook\.react\.PackageList/,
      'import com.prootshell.app.ProotPackage\nimport com.facebook.react.PackageList'
    );
  }
  if (!code.includes('add(ProotPackage())')) {
    code = code.replace(
      /(\/\/ Packages that cannot be autolinked[\s\S]*?)\n(\s*)\}\)/,
      `$1\n          add(ProotPackage())\n$2}))`
    );
  }
  fs.writeFileSync(mainApp, code);
}

console.log('[prebuild] Setting up prootshell-pty gradle subproject with CMake');
// ОТДЕЛЬНЫЙ gradle module — решает "manifest still dirty" в AGP 8
const ptyDir = path.join(ANDROID, 'prootshell-pty');
mkdirp(path.join(ptyDir, 'src/main'));
copyFile(
  path.join(PLUGIN, 'android/cpp/prootshell-pty.c'),
  path.join(ptyDir, 'src/main/prootshell-pty.c')
);
copyFile(
  path.join(PLUGIN, 'android/cpp/CMakeLists.txt'),
  path.join(ptyDir, 'src/main/CMakeLists.txt')
);
fs.writeFileSync(path.join(ptyDir, 'src/main/AndroidManifest.xml'),
  '<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android" />\n'
);
fs.writeFileSync(path.join(ptyDir, 'build.gradle'),
  `apply plugin: 'com.android.library'

android {
    namespace 'com.prootshell.pty'
    compileSdk rootProject.ext.compileSdkVersion
    ndkVersion rootProject.ext.ndkVersion

    defaultConfig {
        minSdkVersion 24
    }

    externalNativeBuild {
        cmake {
            path 'src/main/CMakeLists.txt'
            version '3.22.1'
        }
    }
}
`
);

console.log('[prebuild] Patching settings.gradle');
const settingsGradlePath = path.join(ANDROID, 'settings.gradle');
if (exists(settingsGradlePath)) {
  let s = fs.readFileSync(settingsGradlePath, 'utf8');
  if (!s.includes("':prootshell-pty'")) {
    s = s.replace(
      /^(includeBuild\(expoAutolinking\.reactNativeGradlePlugin\))$/m,
      `$1\ninclude ':prootshell-pty'\nproject(':prootshell-pty').projectDir = new File(rootProject.projectDir, 'prootshell-pty')`
    );
  }
  fs.writeFileSync(settingsGradlePath, s);
}

console.log('[prebuild] Patching app/build.gradle');
const buildGradle = path.join(ANDROID, 'app/build.gradle');
if (exists(buildGradle)) {
  let g = fs.readFileSync(buildGradle, 'utf8');

  // Удаляем ВСЁ, что мы раньше вставили про CMake
  g = g.replace(/\n\s*\/\/ === ProotShell native module[\s\S]*?\}\s*\n/g, '\n');
  g = g.replace(/\n\s*externalNativeBuild\s*\{\s*cmake\s*\{[\s\S]*?\}\s*\}/g, '\n');
  g = g.replace(/\n\s*\/\/ === ProotShell native module config ===[\s\S]*?\}\s*\n/g, '\n');
  g = g.replace(/ndk\s*\{\s*abiFilters[^}]*\}\s*\n/g, '');

  // Добавляем implementation project(':prootshell-pty')
  if (!g.includes("implementation project(':prootshell-pty')")) {
    g = g.replace(
      /(dependencies\s*\{)/,
      `$1
    implementation project(':prootshell-pty')`
    );
  }
  fs.writeFileSync(buildGradle, g);
}

console.log('[prebuild] Patching gradle.properties');
const gradlePropsPath = path.join(ANDROID, 'gradle.properties');
if (exists(gradlePropsPath)) {
  let props = fs.readFileSync(gradlePropsPath, 'utf8');
  props = props.replace(/^reactNativeArchitectures=.*$/m, 'reactNativeArchitectures=arm64-v8a');
  props = props.replace(/org\.gradle\.parallel=true/, 'org.gradle.parallel=false');
  if (!props.includes('org.gradle.workers.max=1')) {
    props += '\norg.gradle.workers.max=1\n';
  }
  if (!props.includes('edgeToEdgeEnabled')) {
    props += '\nedgeToEdgeEnabled=true\n';
  }
  fs.writeFileSync(gradlePropsPath, props);
}

console.log('[prebuild] Patching AndroidManifest.xml');
const manifest = path.join(ANDROID, 'app/src/main/AndroidManifest.xml');
if (exists(manifest)) {
  let m = fs.readFileSync(manifest, 'utf8');
  if (!m.includes('android.permission.WAKE_LOCK')) {
    m = m.replace(
      '</manifest>',
      `  <uses-permission android:name="android.permission.WAKE_LOCK"/>\n  <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n  <uses-permission android:name="android.permission.VIBRATE"/>\n</manifest>`
    );
  }
  fs.writeFileSync(manifest, m);
}

console.log('[prebuild] ✓ android/ fully generated');
console.log('');
console.log('Run: eas build -p android --profile preview');
