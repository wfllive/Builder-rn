/**
 * prebuild.js — ручная генерация android/ из шаблона + плагин
 *
 * Шаблон берём из node_modules/expo-template-bare-minimum,
 * переименовываем helloworld -> наш package, копируем наши native файлы.
 *
 * НЕ вызывает expo prebuild, потому что тот падает на проверке
 * MainApplication.kt (race condition в SDK 57).
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT = process.cwd();
const ANDROID = path.join(ROOT, 'android');
const PLUGIN = path.join(ROOT, 'plugins/prootshell');
const TEMPLATE = path.join(ROOT, 'node_modules/expo-template-bare-minimum');

// Читаем app.json
const appJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'app.json'), 'utf8'));
const PKG = appJson.expo.android.package;  // e.g. com.prootshell.app
const APP_NAME = appJson.expo.name;        // e.g. ProotShell

const TEMPLATE_PKG = 'com.helloworld';

// Утилиты
function exists(p) { return fs.existsSync(p); }
function rmrf(p) { if (exists(p)) fs.rmSync(p, { recursive: true, force: true }); }
function mkdirp(p) { fs.mkdirSync(p, { recursive: true }); }

function copyFile(src, dest) {
  mkdirp(path.dirname(dest));
  fs.copyFileSync(src, dest);
}

function patchFile(file, replacements) {
  let c = fs.readFileSync(file, 'utf8');
  for (const [from, to] of replacements) c = c.split(from).join(to);
  fs.writeFileSync(file, c);
}

function patchAndCopy(src, dest, replacements) {
  mkdirp(path.dirname(dest));
  if (exists(dest)) fs.unlinkSync(dest);
  let c = fs.readFileSync(src, 'utf8');
  for (const [from, to] of replacements) c = c.split(from).join(to);
  fs.writeFileSync(dest, c);
}

function walkCopy(srcDir, destDir, replacements = [], isKotlin = false) {
  mkdirp(destDir);
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      walkCopy(s, d, replacements, isKotlin);
    } else {
      if (isKotlin || entry.name.endsWith('.kt') || entry.name.endsWith('.java') ||
          entry.name.endsWith('.xml') || entry.name.endsWith('.gradle') ||
          entry.name.endsWith('.properties')) {
        patchAndCopy(s, d, replacements);
      } else {
        copyFile(s, d);
      }
    }
  }
}

console.log('[prebuild] Cleaning android/');
rmrf(ANDROID);

console.log('[prebuild] Copying template from', TEMPLATE);
if (!exists(TEMPLATE)) {
  console.error('ERROR: expo-template-bare-minimum not installed');
  console.error('Run: npm install --save-dev expo-template-bare-minimum@sdk-57');
  process.exit(1);
}

const replacements = [
  [TEMPLATE_PKG, PKG],       // com.helloworld -> com.prootshell.app
  ['HelloWorld', APP_NAME],   // HelloWorld -> ProotShell
];

// Копируем android/ целиком из шаблона
walkCopy(
  path.join(TEMPLATE, 'android'),
  ANDROID,
  replacements
);

console.log('[prebuild] Renaming java/com/helloworld -> java/com/prootshell/app');
const srcHelloworld = path.join(ANDROID, 'app/src/main/java/com/helloworld');
const destApp = path.join(ANDROID, `app/src/main/java/com/${PKG.split('.').slice(1).join('/')}`);
if (exists(srcHelloworld)) {
  // Перемещаем и патчим .kt файлы
  mkdirp(destApp);
  for (const f of fs.readdirSync(srcHelloworld)) {
    const s = path.join(srcHelloworld, f);
    const d = path.join(destApp, f);
    let c = fs.readFileSync(s, 'utf8');
    c = c.replace(new RegExp('package com\\.helloworld', 'g'), `package ${PKG}`);
    fs.writeFileSync(d, c);
  }
  rmrf(srcHelloworld);
}
rmrf(path.join(ANDROID, 'app/src/main/java/com/helloworld'));

console.log('[prebuild] Copying native sources from plugin');
const srcJava = path.join(PLUGIN, 'android/java');
if (exists(srcJava)) {
  walkCopy(srcJava, path.join(ANDROID, 'app/src/main/java'));
}
const srcCpp = path.join(PLUGIN, 'android/cpp');
if (exists(srcCpp)) {
  walkCopy(srcCpp, path.join(ANDROID, 'app/src/main/cpp'));
}
const srcAssets = path.join(PLUGIN, 'android/assets/proot');
const destAssets = path.join(ANDROID, 'app/src/main/assets/proot');
if (exists(srcAssets)) {
  rmrf(destAssets);
  mkdirp(destAssets);
  for (const entry of fs.readdirSync(srcAssets, { withFileTypes: true })) {
    if (entry.isFile()) {
      const s = path.join(srcAssets, entry.name);
      const d = path.join(destAssets, entry.name);
      copyFile(s, d);
      fs.chmodSync(d, 0o755);
    }
  }
}

console.log('[prebuild] Patching MainApplication.kt');
const mainApp = path.join(ANDROID, `app/src/main/java/com/${PKG.split('.').slice(1).join('/')}/MainApplication.kt`);
if (exists(mainApp)) {
  let code = fs.readFileSync(mainApp, 'utf8');
  if (!code.includes('com.prootshell.app.ProotPackage')) {
    code = code.replace(
      /import com\.facebook\.react\.PackageList/,
      'import com.prootshell.app.ProotPackage\nimport com.facebook.react.PackageList'
    );
  }
  if (!code.includes('add(ProotPackage())')) {
    code = code.replace(
      /(\/\/ Packages that cannot be autolinked[\s\S]*?)\n(\s*)\}\)/,
      `$1\n          add(ProotPackage())\n$2}))`
    );
  }
  fs.writeFileSync(mainApp, code);
}

console.log('[prebuild] Patching build.gradle for CMake');
const buildGradle = path.join(ANDROID, 'app/build.gradle');
if (exists(buildGradle)) {
  let g = fs.readFileSync(buildGradle, 'utf8');
  if (!g.includes('prootshell-pty.c')) {
    const androidSnippet = `
    // === ProotShell native module (CMake) ===
    externalNativeBuild {
        cmake {
            path "src/main/cpp/CMakeLists.txt"
            version "3.22.1"
        }
    }
`;
    g = g.replace(/(namespace ['"]com\.prootshell\.app['"])/, `$1${androidSnippet}`);

    const defaultConfigSnippet = `
        // === ProotShell native module config ===
        ndk {
            abiFilters "arm64-v8a", "armeabi-v7a", "x86_64", "x86"
        }
        externalNativeBuild {
            cmake {
                cFlags "-std=c11"
                arguments "-DANDROID_STL=c++_static"
            }
        }
`;
    g = g.replace(/(versionName "[^"]*")/, `$1${defaultConfigSnippet}`);
  }
  fs.writeFileSync(buildGradle, g);
}

console.log('[prebuild] Patching AndroidManifest.xml');
const manifest = path.join(ANDROID, 'app/src/main/AndroidManifest.xml');
if (exists(manifest)) {
  let m = fs.readFileSync(manifest, 'utf8');
  if (!m.includes('android.permission.WAKE_LOCK')) {
    m = m.replace(
      '</manifest>',
      `  <uses-permission android:name="android.permission.WAKE_LOCK"/>
  <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
  <uses-permission android:name="android.permission.VIBRATE"/>
</manifest>`
    );
  }
  fs.writeFileSync(manifest, m);
}

console.log('[prebuild] ✓ android/ fully generated');
console.log('');
console.log('Run: eas build -p android --profile preview');
