#!/usr/bin/env node
/**
 * sp.js / setup-proot
 * -------------------
 * Режимы:
 *
 *   --armhf
 *     Termux-патченый 32-bit proot (Android-safe), гостевой rootfs = armhf
 *
 *   --aarch64
 *     Vanilla proot-me static 64-bit, гостевой rootfs = arm64
 *     (на строгом Android / Huawei может молча падать code 255)
 *
 *   --from-termux
 *     БЕРЁТ РАБОЧИЙ ARM64 PROOT ИЗ УСТАНОВЛЕННОГО TERMUX:
 *       $PREFIX/bin/proot
 *       $PREFIX/lib/libtalloc.so.2
 *       $PREFIX/lib/libandroid-shmem.so
 *
 *     Это сейчас самый перспективный режим для arm64-гостя на твоём устройстве.
 *
 * Примеры:
 *   node scripts/sp.js --from-termux
 *   node scripts/sp.js --armhf
 *   node scripts/sp.js --aarch64
 *
 * Полезно перед --from-termux:
 *   pkg install proot patchelf binutils file -y
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, spawnSync } = require('child_process');

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG
// ─────────────────────────────────────────────────────────────────────────────

const AARCH64_PROOT_URL =
  'https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static';

const ARMHF_PROOT_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/proot';

const ARMHF_LOADER_URL =
  'https://raw.githubusercontent.com/ZhymabekRoman/proot-static/main/bin/loader';

const ELF_MACHINES = {
  3: 'x86 (EM_386)',
  40: 'ARM/armhf (EM_ARM)',
  62: 'x86_64 (EM_X86_64)',
  183: 'AArch64/arm64 (EM_AARCH64)',
};

const CONFIG = {
  abi: 'arm64-v8a',
  mode: 'armhf', // armhf | aarch64 | from-termux
  customProot: null,
  customLoader: null,
  verbose: false,
};

const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  const a = args[i];
  if (a === '--abi' && args[i + 1]) CONFIG.abi = args[++i];
  else if (a === '--proot' && args[i + 1]) CONFIG.customProot = args[++i];
  else if (a === '--loader' && args[i + 1]) CONFIG.customLoader = args[++i];
  else if (a === '--armhf') CONFIG.mode = 'armhf';
  else if (a === '--aarch64') CONFIG.mode = 'aarch64';
  else if (a === '--from-termux' || a === '--termux64') CONFIG.mode = 'from-termux';
  else if (a === '--verbose') CONFIG.verbose = true;
  else if (a === '--help' || a === '-h') {
    printHelpAndExit(0);
  } else {
    console.warn('Unknown arg:', a);
  }
}

const DEST_DIR = path.join(
  __dirname,
  '..',
  'modules',
  'termux-terminal',
  'android',
  'src',
  'main',
  'jniLibs',
  CONFIG.abi
);

// ─────────────────────────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────────────────────────

function printHelpAndExit(code) {
  console.log(`
Usage:
  node scripts/sp.js --from-termux
  node scripts/sp.js --armhf
  node scripts/sp.js --aarch64

Options:
  --abi <abi>         default: arm64-v8a
  --proot <path|url>  override proot source
  --loader <path|url> override loader source
  --verbose
`);
  process.exit(code);
}

function logv(...x) {
  if (CONFIG.verbose) console.log(...x);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function exists(p) {
  try { return fs.existsSync(p); } catch (_) { return false; }
}

function safeUnlink(p) {
  try { if (exists(p)) fs.unlinkSync(p); } catch (_) {}
}

function safeRmRf(p) {
  try { fs.rmSync(p, { recursive: true, force: true }); } catch (_) {}
}

function chmod755(p) {
  try { fs.chmodSync(p, 0o755); } catch (_) {}
}

function copyFile(src, dst) {
  fs.copyFileSync(src, dst);
  chmod755(dst);
}

function formatSize(n) {
  if (n >= 1024 * 1024) return (n / (1024 * 1024)).toFixed(1) + ' MB';
  return Math.round(n / 1024) + ' KB';
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function getTmpBase() {
  const base = process.env.TMPDIR ||
    (process.env.PREFIX ? path.join(process.env.PREFIX, 'tmp') : os.tmpdir());
  ensureDir(base);
  return base;
}

function hasCmd(cmd) {
  try {
    const r = spawnSync(cmd, ['--version'], { stdio: 'ignore' });
    return !r.error;
  } catch (_) {
    return false;
  }
}

function run(cmd, argv, opts = {}) {
  return spawnSync(cmd, argv, {
    encoding: 'utf8',
    stdio: opts.stdio || ['ignore', 'pipe', 'pipe'],
    env: opts.env || process.env,
    cwd: opts.cwd || process.cwd(),
  });
}

function looksLikeElf(file) {
  try {
    const fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(64);
    const n = fs.readSync(fd, buf, 0, 64, 0);
    fs.closeSync(fd);

    if (n < 20) return { valid: false, reason: 'too small' };
    const magic = buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46;
    if (!magic) return { valid: false, reason: 'not ELF' };

    const elfClass = buf[4];
    const bits = elfClass === 1 ? 32 : elfClass === 2 ? 64 : 0;
    const endian = buf[5] === 1 ? 'LE' : buf[5] === 2 ? 'BE' : '?';
    const machine = buf[5] === 1 ? buf.readUInt16LE(18) : buf.readUInt16BE(18);
    const type = buf[5] === 1 ? buf.readUInt16LE(16) : buf.readUInt16BE(16);

    const typeName = { 1: 'REL', 2: 'EXEC', 3: 'DYN', 4: 'CORE' }[type] || `unknown(${type})`;
    return {
      valid: true,
      bits,
      endian,
      machine,
      machName: ELF_MACHINES[machine] || ('machine=' + machine),
      type,
      typeName,
    };
  } catch (e) {
    return { valid: false, reason: e.message };
  }
}

function printElf(label, file) {
  if (!exists(file)) {
    console.log(`  - ${label.padEnd(18)} MISSING`);
    return;
  }
  const st = fs.statSync(file);
  const elf = looksLikeElf(file);
  if (elf.valid) {
    console.log(
      `  ✓ ${label.padEnd(18)} ${formatSize(st.size).padStart(8)}  ${elf.bits}-bit ${elf.machName}  ${elf.typeName}`
    );
  } else {
    console.log(
      `  ⚠ ${label.padEnd(18)} ${formatSize(st.size).padStart(8)}  not valid ELF (${elf.reason})`
    );
  }
}

function readNeeded(file) {
  if (!hasCmd('readelf')) return [];
  const r = run('readelf', ['-d', file]);
  if ((r.status || 0) !== 0) return [];
  const out = (r.stdout || '') + '\n' + (r.stderr || '');
  const res = [];
  for (const line of out.split('\n')) {
    const m = line.match(/Shared library:\s*\[(.+?)\]/);
    if (m) res.push(m[1]);
  }
  return res;
}

function printNeeded(label, file) {
  if (!exists(file)) return;
  const libs = readNeeded(file);
  if (!libs.length) return;
  console.log(`    needed by ${label}: ${libs.join(', ')}`);
}

function download(url, dest, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 10) return reject(new Error('Too many redirects'));

    safeUnlink(dest);

    const lib = url.startsWith('https:') ? https : http;
    const req = lib.get(url, { headers: { 'User-Agent': 'setup-proot/3.0' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        const loc = res.headers.location;
        if (!loc) return reject(new Error('Redirect without Location'));
        return resolve(download(new URL(loc, url).toString(), dest, redirects + 1));
      }

      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }

      const ct = String(res.headers['content-type'] || '').toLowerCase();
      if (ct.includes('text/html')) {
        res.resume();
        return reject(new Error(`Response is HTML (${ct})`));
      }

      const file = fs.createWriteStream(dest);
      res.pipe(file);

      file.on('finish', () => file.close(() => resolve(dest)));
      file.on('error', (e) => {
        safeUnlink(dest);
        reject(e);
      });
    });

    req.on('error', (e) => {
      safeUnlink(dest);
      reject(e);
    });

    req.setTimeout(120000, () => {
      req.destroy(new Error('Timeout'));
    });
  });
}

function isLocalPathMaybe(p) {
  return exists(p);
}

function copyOrDownload(srcOrUrl, dest) {
  const isLocal = isLocalPathMaybe(srcOrUrl);
  process.stdout.write(`${isLocal ? 'Copying' : 'Downloading'} ${path.basename(dest)} ... `);
  return (async () => {
    if (isLocal) {
      copyFile(srcOrUrl, dest);
    } else {
      await download(srcOrUrl, dest);
      chmod755(dest);
    }
    const st = fs.statSync(dest);
    const elf = looksLikeElf(dest);
    if (elf.valid) {
      console.log(`${formatSize(st.size)} (ELF ${elf.bits}-bit ${elf.machName}, ${elf.typeName})`);
    } else {
      console.log(`${formatSize(st.size)} (not valid ELF: ${elf.reason})`);
    }
  })();
}

function termuxPrefix() {
  return process.env.PREFIX || '/data/data/com.termux/files/usr';
}

function isRunningInTermux() {
  const p = termuxPrefix();
  return exists(p) && p.includes('com.termux');
}

function findTermuxPaths() {
  const prefix = termuxPrefix();
  return {
    prefix,
    proot: path.join(prefix, 'bin', 'proot'),
    tallocV: path.join(prefix, 'lib', 'libtalloc.so.2'),
    shmem: path.join(prefix, 'lib', 'libandroid-shmem.so'),
  };
}

function findPackagedLoaderInTermux() {
  // 1) пользователь явно дал loader
  if (CONFIG.customLoader && exists(CONFIG.customLoader)) return CONFIG.customLoader;

  // 2) dpkg -L proot | grep loader
  if (hasCmd('dpkg')) {
    const r = run('dpkg', ['-L', 'proot']);
    if ((r.status || 0) === 0) {
      const lines = (r.stdout || '').split('\n').map(s => s.trim()).filter(Boolean);
      const candidates = lines.filter((p) => /(^|\/)loader(\.[^\/]+)?$/.test(p));
      for (const c of candidates) {
        if (exists(c)) return c;
      }
    }
  }

  // 3) Частые места
  const prefix = termuxPrefix();
  const guesses = [
    path.join(prefix, 'libexec', 'proot', 'loader'),
    path.join(prefix, 'lib', 'proot', 'loader'),
    path.join(prefix, 'share', 'proot', 'loader'),
  ];
  for (const g of guesses) {
    if (exists(g)) return g;
  }

  return null;
}

async function tryExtractLoader(prootBin, destLoader, extraEnv = {}) {
  const baseTmp = getTmpBase();
  const tmp = fs.mkdtempSync(path.join(baseTmp, 'proot-extract-'));
  let child;
  let stderr = '';
  let childError = '';
  let exited = false;
  let exitCode = null;
  let exitSignal = null;

  const env = Object.assign({}, process.env, extraEnv, {
    PROOT_TMP_DIR: tmp,
    PROOT_NO_SECCOMP: '1',
  });

  try {
    child = spawn(prootBin, ['/system/bin/sh', '-c', 'sleep 8'], {
      env,
      stdio: ['ignore', 'ignore', 'pipe'],
    });
  } catch (e) {
    safeRmRf(tmp);
    console.log(`  (spawn failed: ${e.message})`);
    return false;
  }

  if (child.stderr) {
    child.stderr.on('data', (d) => { stderr += d.toString(); });
  }
  child.on('error', (e) => {
    childError = String(e && e.message || e);
  });
  child.on('exit', (code, sig) => {
    exited = true;
    exitCode = code;
    exitSignal = sig;
  });

  let found = null;
  const deadline = Date.now() + 10000;

  while (!found && Date.now() < deadline) {
    try {
      const list = fs.readdirSync(tmp);
      for (const name of list) {
        if (name.startsWith('prooted')) {
          const p = path.join(tmp, name);
          try {
            const s1 = fs.statSync(p).size;
            if (s1 > 500) {
              await sleep(150);
              const s2 = fs.statSync(p).size;
              if (s1 === s2 && s2 > 500) {
                found = p;
                break;
              }
            }
          } catch (_) {}
        }
      }
    } catch (_) {}

    if (!found) await sleep(50);
  }

  try { child.kill('SIGKILL'); } catch (_) {}
  await sleep(120);

  if (found) {
    copyFile(found, destLoader);
    safeRmRf(tmp);
    return true;
  }

  const listing = (() => {
    try {
      const x = fs.readdirSync(tmp);
      return x.length ? x.join(', ') : '<empty>';
    } catch (_) {
      return '<err>';
    }
  })();

  console.log(
    `(no loader; exit=${exitCode} signal=${exitSignal} error=${childError || '-'} tmp=[${listing}] stderr=${stderr.slice(0, 300).replace(/\s+/g, ' ').trim()})`
  );

  safeRmRf(tmp);
  return false;
}

function patchelfReplaceNeeded(bin, oldName, newName) {
  if (!hasCmd('patchelf')) {
    return { ok: false, reason: 'patchelf not installed' };
  }
  const r = run('patchelf', ['--replace-needed', oldName, newName, bin], { stdio: ['ignore', 'pipe', 'pipe'] });
  if ((r.status || 0) !== 0) {
    return {
      ok: false,
      reason: ((r.stderr || '') + ' ' + (r.stdout || '')).trim() || `patchelf exit ${r.status}`,
    };
  }
  return { ok: true };
}

function ensureModeBanner(label) {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║                    setup-proot v3.0                         ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');
  console.log('');
  console.log(`  Mode      : ${CONFIG.mode} — ${label}`);
  console.log(`  ABI       : ${CONFIG.abi}`);
  console.log(`  Dest      : ${DEST_DIR}`);
  console.log('');
}

function verifyExpectedArch(file, expectedMachine, expectedBits) {
  const elf = looksLikeElf(file);
  if (!elf.valid) return { ok: false, reason: elf.reason };
  if (expectedMachine && elf.machine !== expectedMachine) {
    return { ok: false, reason: `wrong machine: got ${elf.machName}` };
  }
  if (expectedBits && elf.bits !== expectedBits) {
    return { ok: false, reason: `wrong bits: got ${elf.bits}` };
  }
  return { ok: true, elf };
}

function selfTestBundleAarch64(prootPath, libsDir, loaderPath) {
  const testTmp = path.join(getTmpBase(), 'proot-selftest');
  ensureDir(testTmp);

  const strictEnv = Object.assign({}, process.env, {
    LD_LIBRARY_PATH: libsDir,
    PROOT_TMP_DIR: testTmp,
    PROOT_NO_SECCOMP: '1',
  });
  if (loaderPath && exists(loaderPath)) strictEnv.PROOT_LOADER = loaderPath;

  const r1 = run(prootPath, ['/system/bin/sh', '-c', 'uname -m; echo OK; sleep 1'], {
    env: strictEnv,
  });

  const out1 = ((r1.stdout || '') + (r1.stderr || '')).trim();
  if ((r1.status || 0) === 0) {
    return { ok: true, mode: 'strict', output: out1 };
  }

  // fallback-диагностика: позволяем Termux libs
  const prefix = termuxPrefix();
  const fallbackEnv = Object.assign({}, strictEnv, {
    LD_LIBRARY_PATH: `${libsDir}:${path.join(prefix, 'lib')}`,
  });

  const r2 = run(prootPath, ['/system/bin/sh', '-c', 'uname -m; echo OK; sleep 1'], {
    env: fallbackEnv,
  });
  const out2 = ((r2.stdout || '') + (r2.stderr || '')).trim();

  if ((r2.status || 0) === 0) {
    return {
      ok: false,
      mode: 'fallback-only',
      output: out2,
      detail: out1,
    };
  }

  return {
    ok: false,
    mode: 'failed',
    output: out1 || out2 || `exit1=${r1.status} exit2=${r2.status}`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// MODES
// ─────────────────────────────────────────────────────────────────────────────

async function setupArmhf() {
  ensureModeBanner('Termux-patched armhf (32-bit, Android-safe)');
  ensureDir(DEST_DIR);

  let ok = true;
  const prootDest = path.join(DEST_DIR, 'libproot.so');
  const loaderDest = path.join(DEST_DIR, 'libloader.so');

  try {
    console.log('[1/3] proot');
    await copyOrDownload(CONFIG.customProot || ARMHF_PROOT_URL, prootDest);
    const v = verifyExpectedArch(prootDest, 40, 32);
    if (!v.ok) throw new Error(v.reason);
  } catch (e) {
    console.log('  ✗ proot failed:', e.message);
    ok = false;
  }

  try {
    console.log('');
    console.log('[2/3] loader');
    await copyOrDownload(CONFIG.customLoader || ARMHF_LOADER_URL, loaderDest);
    const v = verifyExpectedArch(loaderDest, 40, 32);
    if (!v.ok) throw new Error(v.reason);
  } catch (e) {
    console.log('  ✗ loader failed:', e.message);
    ok = false;
  }

  console.log('');
  console.log('[3/3] final files');
  printElf('libproot.so', prootDest);
  printElf('libloader.so', loaderDest);

  console.log('');
  console.log('  Notes:');
  console.log('  • armhf proot = only armhf guest rootfs');
  console.log('  • It cannot launch 64-bit host executables like /system/bin/sh on some devices');
  console.log('  • Good for strict Android only if your whole guest bootstrap is 32-bit');
  console.log('');

  process.exit(ok ? 0 : 1);
}

async function setupVanillaAarch64() {
  ensureModeBanner('Vanilla proot-me v5.3.0 (64-bit, NO Android patches)');
  ensureDir(DEST_DIR);

  let ok = true;
  const prootDest = path.join(DEST_DIR, 'libproot.so');
  const loaderDest = path.join(DEST_DIR, 'libloader.so');
  safeUnlink(loaderDest);

  try {
    console.log('[1/3] proot');
    await copyOrDownload(CONFIG.customProot || AARCH64_PROOT_URL, prootDest);
    const v = verifyExpectedArch(prootDest, 183, 64);
    if (!v.ok) throw new Error(v.reason);
  } catch (e) {
    console.log('  ✗ proot failed:', e.message);
    ok = false;
  }

  if (ok) {
    console.log('');
    console.log('[2/3] extracting built-in loader');
    const extracted = await tryExtractLoader(prootDest, loaderDest, {});
    if (extracted) {
      console.log('  ✓ libloader.so extracted');
    } else {
      console.log('  ℹ no external loader extracted; proot will use embedded/code_cache loader');
    }
  }

  console.log('');
  console.log('[3/3] final files');
  printElf('libproot.so', prootDest);
  printElf('libloader.so', loaderDest);

  console.log('');
  console.log('  Notes:');
  console.log('  • guest rootfs = arm64');
  console.log('  • vanilla aarch64 often fails with code 255 on strict Android/Huawei');
  console.log('');

  process.exit(ok ? 0 : 1);
}

async function setupFromTermux() {
  ensureModeBanner('arm64 proot from installed Termux package (recommended for your device)');
  ensureDir(DEST_DIR);

  const src = findTermuxPaths();
  let ok = true;
  let warnings = [];

  if (!isRunningInTermux()) {
    console.log('  ✗ This mode should be run inside Termux.');
    process.exit(1);
  }

  if (!exists(src.proot)) {
    console.log('  ✗ Termux proot not found:', src.proot);
    console.log('    Install it first: pkg install proot');
    process.exit(1);
  }
  if (!exists(src.tallocV)) {
    console.log('  ✗ Missing Termux lib:', src.tallocV);
    process.exit(1);
  }
  if (!exists(src.shmem)) {
    console.log('  ✗ Missing Termux lib:', src.shmem);
    process.exit(1);
  }

  const destProot = path.join(DEST_DIR, 'libproot.so');
  const destLoader = path.join(DEST_DIR, 'libloader.so');
  const destShmem = path.join(DEST_DIR, 'libandroid-shmem.so');
  const destTalloc = path.join(DEST_DIR, 'libtalloc.so');
  const destTallocV = path.join(DEST_DIR, 'libtalloc.so.2');

  safeUnlink(destProot);
  safeUnlink(destLoader);
  safeUnlink(destShmem);
  safeUnlink(destTalloc);
  safeUnlink(destTallocV);

  // [1/5] copy proot + deps
  try {
    console.log('[1/5] Copying Termux proot and deps...');
    console.log('      proot :', src.proot);
    console.log('      talloc:', src.tallocV);
    console.log('      shmem :', src.shmem);

    copyFile(CONFIG.customProot || src.proot, destProot);
    copyFile(src.shmem, destShmem);

    // ВАЖНО:
    // Если есть patchelf, лучше переименовать зависимость на libtalloc.so
    // чтобы Android-packaging имел дело с обычным *.so.
    if (hasCmd('patchelf')) {
      copyFile(src.tallocV, destTalloc);
      const patch = patchelfReplaceNeeded(destProot, 'libtalloc.so.2', 'libtalloc.so');
      if (!patch.ok) {
        warnings.push('patchelf failed: ' + patch.reason);
        // fallback: кладём и versioned файл тоже
        copyFile(src.tallocV, destTallocV);
      } else {
        console.log('      ✓ patched DT_NEEDED: libtalloc.so.2 -> libtalloc.so');
      }
    } else {
      warnings.push('patchelf not installed: kept versioned libtalloc.so.2; Android packaging may be less reliable');
      copyFile(src.tallocV, destTallocV);
      copyFile(src.tallocV, destTalloc); // дублируем и как обычный .so
      console.log('      ⚠ patchelf not found; copied both libtalloc.so.2 and libtalloc.so');
      console.log('        Install patchelf for cleaner packaging: pkg install patchelf');
    }
  } catch (e) {
    console.log('  ✗ copy step failed:', e.message);
    process.exit(1);
  }

  // Validate proot arch
  const pv = verifyExpectedArch(destProot, 183, 64);
  if (!pv.ok) {
    console.log('  ✗ copied Termux proot is not valid arm64:', pv.reason);
    process.exit(1);
  }

  // [2/5] try packaged loader, else extract loader from WORKING termux proot
  console.log('');
  console.log('[2/5] Loader...');
  let loaderReady = false;

  try {
    const packagedLoader = findPackagedLoaderInTermux();
    if (packagedLoader && exists(packagedLoader)) {
      console.log('      found packaged loader:', packagedLoader);
      copyFile(packagedLoader, destLoader);
      const lv = verifyExpectedArch(destLoader, 183, 64);
      if (!lv.ok) {
        warnings.push('Packaged loader exists but arch check failed: ' + lv.reason);
        safeUnlink(destLoader);
      } else {
        loaderReady = true;
        console.log('      ✓ copied packaged loader');
      }
    }
  } catch (e) {
    warnings.push('packaged loader lookup failed: ' + e.message);
  }

  if (!loaderReady) {
    process.stdout.write('      extracting loader from WORKING Termux proot ... ');
    const extracted = await tryExtractLoader(src.proot, destLoader, {
      LD_LIBRARY_PATH: path.join(src.prefix, 'lib'),
    });
    if (extracted) {
      const lv = verifyExpectedArch(destLoader, 183, 64);
      if (!lv.ok) {
        safeUnlink(destLoader);
        console.log('FAILED (bad loader arch: ' + lv.reason + ')');
        warnings.push('extracted loader arch mismatch: ' + lv.reason);
      } else {
        loaderReady = true;
        console.log('OK');
      }
    } else {
      console.log('could not extract');
      warnings.push('no external libloader.so; runtime will rely on embedded/code_cache loader');
    }
  }

  // [3/5] print file info + DT_NEEDED
  console.log('');
  console.log('[3/5] Bundle details...');
  printElf('libproot.so', destProot);
  printNeeded('libproot.so', destProot);

  printElf('libandroid-shmem.so', destShmem);
  printNeeded('libandroid-shmem.so', destShmem);

  if (exists(destTalloc)) {
    printElf('libtalloc.so', destTalloc);
    printNeeded('libtalloc.so', destTalloc);
  }
  if (exists(destTallocV)) {
    printElf('libtalloc.so.2', destTallocV);
    printNeeded('libtalloc.so.2', destTallocV);
  }
  if (exists(destLoader)) {
    printElf('libloader.so', destLoader);
  }

  // [4/5] self-test copied bundle
  console.log('');
  console.log('[4/5] Self-test copied bundle...');
  const test = selfTestBundleAarch64(destProot, DEST_DIR, exists(destLoader) ? destLoader : null);

  if (test.ok) {
    console.log('      ✓ strict bundle test passed');
    console.log('      output:');
    for (const line of String(test.output || '').split('\n')) {
      if (line.trim()) console.log('        ' + line);
    }
  } else if (test.mode === 'fallback-only') {
    console.log('      ⚠ bundle works only with fallback LD_LIBRARY_PATH including Termux libs');
    console.log('        strict output :', (test.detail || '<empty>').replace(/\s+/g, ' ').trim());
    console.log('        fallback out  :', (test.output || '<empty>').replace(/\s+/g, ' ').trim());
    warnings.push('strict self-test failed; some dependency/path issue remains');
    ok = false;
  } else {
    console.log('      ✗ self-test failed');
    console.log('        output:', (test.output || '<empty>').replace(/\s+/g, ' ').trim());
    ok = false;
  }

  // [5/5] final summary
  console.log('');
  console.log('[5/5] Final state...');
  console.log('');

  printElf('libproot.so', destProot);
  printElf('libandroid-shmem.so', destShmem);
  if (exists(destTalloc)) printElf('libtalloc.so', destTalloc);
  if (exists(destTallocV)) printElf('libtalloc.so.2', destTallocV);
  if (exists(destLoader)) printElf('libloader.so', destLoader);
  else console.log('  - libloader.so       not present');

  console.log('');
  console.log('  Runtime env for app MUST include:');
  console.log('  • PROOT_TMP_DIR=<writable existing dir>');
  console.log('  • PROOT_NO_SECCOMP=1');
  console.log('  • LD_LIBRARY_PATH=<nativeLibraryDir>');
  console.log('  • PROOT_LOADER=<nativeLibraryDir>/libloader.so   (if file exists)');
  console.log('');

  console.log('  Android notes:');
  console.log('  • This is arm64 guest mode (rootfs should be arm64)');
  console.log('  • proot is DYNAMIC, so nativeLibraryDir must also contain its deps');
  console.log('  • If patchelf was used, libproot.so now wants libtalloc.so (better for packaging)');
  console.log('  • If only libtalloc.so.2 remains, APK/AAB extraction MAY be less predictable on some setups');
  console.log('');

  if (warnings.length) {
    console.log('  Warnings:');
    for (const w of warnings) console.log('  • ' + w);
    console.log('');
  }

  if (ok) {
    console.log('═══════════════════════════════════════════════════════════════');
    console.log('  ✓ Termux arm64 proot bundle prepared successfully');
    console.log('═══════════════════════════════════════════════════════════════');
  } else {
    console.log('═══════════════════════════════════════════════════════════════');
    console.log('  ⚠ Bundle prepared, but there are issues to fix');
    console.log('═══════════════════════════════════════════════════════════════');
  }

  console.log('');
  console.log('Next steps:');
  console.log('  1) git add -A && git commit -m "termux arm64 proot bundle" && git push');
  console.log('  2) npm run pr && npm run bd');
  console.log('  3) In app: install ARM64 Linux rootfs');
  console.log('');

  process.exit(ok ? 0 : 1);
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

(async () => {
  try {
    if (CONFIG.mode === 'armhf') return await setupArmhf();
    if (CONFIG.mode === 'aarch64') return await setupVanillaAarch64();
    if (CONFIG.mode === 'from-termux') return await setupFromTermux();

    console.log('Unknown mode:', CONFIG.mode);
    process.exit(1);
  } catch (e) {
    console.error('FATAL:', e && e.stack || e);
    process.exit(1);
  }
})();