#!/data/data/com.termux/files/usr/bin/bash
# build-proot-ndk.sh
# ------------------
# Builds an aarch64 proot dynamically linked ONLY against Android bionic
# (libc.so, libdl.so, libm.so, liblog.so). No libandroid-shmem, no libtalloc.so.
# Works inside ANY Android app (not just Termux).
#
# Prereqs (run once in Termux):
#   pkg install -y git make wget curl file patchelf
#   pkg install -y android-tools    # for readelf / aarch64 tools if needed
#
# The Android NDK (r26 or newer) will be downloaded automatically to ~/.cache
# if not present. You can also point NDK_HOME to an existing NDK.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
JNI_DIR="$ROOT_DIR/modules/termux-terminal/android/src/main/jniLibs/arm64-v8a"
CACHE="$HOME/.cache/build-proot-ndk"
NDK_VERSION="r26d"
NDK_DIR_DEFAULT="$CACHE/android-ndk-${NDK_VERSION}"
NDK_HOME="${NDK_HOME:-$NDK_DIR_DEFAULT}"
API=24
ARCH="aarch64"
TARGET="${ARCH}-linux-android${API}"

TALLOC_VER="2.4.2"
TALLOC_URL="https://download.samba.org/pub/talloc/talloc-${TALLOC_VER}.tar.gz"

PROOT_REPO="https://github.com/termux/proot.git"
PROOT_SRC="$CACHE/proot"
TALLOC_SRC="$CACHE/talloc-${TALLOC_VER}"
TALLOC_BUILD="$CACHE/talloc-build"

mkdir -p "$CACHE" "$JNI_DIR"

# ─────────────────────────────────────────────────────────────────────────────
# 1) Ensure Android NDK
# ─────────────────────────────────────────────────────────────────────────────
if [ ! -d "$NDK_HOME/toolchains/llvm/prebuilt" ]; then
  echo "==> Downloading Android NDK ${NDK_VERSION}"
  cd "$CACHE"
  NDK_ZIP="android-ndk-${NDK_VERSION}-linux.zip"
  if [ ! -f "$NDK_ZIP" ]; then
    wget -q --show-progress \
      "https://dl.google.com/android/repository/${NDK_ZIP}" \
      -O "$NDK_ZIP"
  fi
  echo "==> Unpacking NDK (this is slow, one-time only)"
  # Termux busybox unzip is fine here
  unzip -q -o "$NDK_ZIP"
fi

# Find prebuilt toolchain dir (linux-x86_64 or linux-aarch64)
TOOL_ROOT="$(ls -d "$NDK_HOME"/toolchains/llvm/prebuilt/*/ 2>/dev/null | head -n1 || true)"
if [ -z "$TOOL_ROOT" ]; then
  echo "!! NDK toolchain not found in $NDK_HOME"
  exit 1
fi
echo "==> NDK toolchain: $TOOL_ROOT"

export PATH="${TOOL_ROOT}bin:$PATH"
export CC="${TARGET}-clang"
export CXX="${TARGET}-clang++"
export AR="llvm-ar"
export RANLIB="llvm-ranlib"
export STRIP="llvm-strip"
SYSROOT="${TOOL_ROOT}sysroot"

# ─────────────────────────────────────────────────────────────────────────────
# 2) Build libtalloc STATIC against bionic
# ─────────────────────────────────────────────────────────────────────────────
if [ ! -f "$TALLOC_BUILD/libtalloc.a" ]; then
  echo "==> Fetching libtalloc ${TALLOC_VER}"
  cd "$CACHE"
  if [ ! -f "talloc-${TALLOC_VER}.tar.gz" ]; then
    wget -q --show-progress "$TALLOC_URL" -O "talloc-${TALLOC_VER}.tar.gz"
  fi
  rm -rf "$TALLOC_SRC" "$TALLOC_BUILD"
  tar -xzf "talloc-${TALLOC_VER}.tar.gz"
  mkdir -p "$TALLOC_BUILD"

  echo "==> Building libtalloc.a from scratch (single source file build)"
  # talloc is tiny; ship a hand-rolled compile to avoid Samba's waf.
  # This mirrors what termux-packages does for cross builds.
  cd "$TALLOC_SRC"
  # Only the core talloc file is needed (no pytalloc, no testsuite).
  # talloc.c is self-contained enough to compile like this against bionic.
  cp talloc.c talloc.h "$TALLOC_BUILD/"
  # Provide minimal replacements for autoconf-generated headers.
  cat > "$TALLOC_BUILD/replace.h" <<'EOF'
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#ifndef _PUBLIC_
#define _PUBLIC_
#endif
#ifndef _DEPRECATED_
#define _DEPRECATED_
#endif
#ifndef PRINTF_ATTRIBUTE
#define PRINTF_ATTRIBUTE(a,b)
#endif
EOF

  cd "$TALLOC_BUILD"
  $CC -O2 -fPIC -DHAVE_VA_COPY -D_GNU_SOURCE \
      -I. -include replace.h \
      -c talloc.c -o talloc.o
  $AR rcs libtalloc.a talloc.o
  $RANLIB libtalloc.a
  echo "==> Built: $TALLOC_BUILD/libtalloc.a"
fi

# ─────────────────────────────────────────────────────────────────────────────
# 3) Clone termux/proot
# ─────────────────────────────────────────────────────────────────────────────
if [ ! -d "$PROOT_SRC/.git" ]; then
  echo "==> Clone termux/proot"
  git clone --depth 1 "$PROOT_REPO" "$PROOT_SRC"
fi

cd "$PROOT_SRC/src"
make -s clean || true

# ─────────────────────────────────────────────────────────────────────────────
# 4) Compile proot against bionic + our static talloc
#    - drop libandroid-shmem (Termux-only); we don't use it
#    - drop libutil (bionic doesn't have it, symbols are in libc)
# ─────────────────────────────────────────────────────────────────────────────
echo "==> Build proot for $TARGET"

# NOTE: we override LDFLAGS to skip:
#   -landroid-shmem   (Termux-only, breaks in generic apps)
#   -lutil            (not in bionic)
# and to inject our static libtalloc.

export CFLAGS="-O2 -fPIE -DANDROID \
  -I${TALLOC_BUILD} \
  -Wno-error -Wno-deprecated-declarations -Wno-unused-variable \
  -Wno-unused-but-set-variable -Wno-sign-compare -Wno-misleading-indentation \
  -Wno-inline-asm -Wno-unused-parameter -Wno-unused-result -Wno-sizeof-array-argument"

export LDFLAGS="-pie -Wl,-z,now -Wl,-z,relro"
export LIBS="${TALLOC_BUILD}/libtalloc.a -lc -ldl -lm -llog"

# Some proot Makefiles reference LDLIBS instead of LIBS
export LDLIBS="$LIBS"

# Also make sure Makefile doesn't add -landroid-shmem or -ltalloc dynamically.
# The termux/proot Makefile respects LDFLAGS/LIBS, so passing empty overrides
# is enough for most configurations.

# Build only the main proot target
make -s proot V=1 || {
  echo ""
  echo "!! Build failed. Common causes:"
  echo "   - Makefile added -landroid-shmem or -ltalloc; edit src/GNUmakefile"
  echo "     and remove those from LDLIBS."
  echo "   - Missing header. Ensure NDK sysroot is complete: $SYSROOT"
  exit 1
}

BIN="$PROOT_SRC/src/proot"
if [ ! -f "$BIN" ]; then
  echo "!! Build produced no binary at $BIN"
  exit 1
fi

# ─────────────────────────────────────────────────────────────────────────────
# 5) Inspect
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "==> Verify"
file "$BIN"
"${TOOL_ROOT}bin/llvm-readelf" -d "$BIN" | grep -E 'NEEDED|RUNPATH|RPATH' || true

# Sanity check: allowed libraries only
BAD_DEPS="$("${TOOL_ROOT}bin/llvm-readelf" -d "$BIN" \
    | awk '/NEEDED/ {gsub("[\\[\\]]","",$5); print $5}' \
    | grep -Ev '^(libc\.so|libdl\.so|libm\.so|liblog\.so|libc\+\+\.so)$' || true)"

if [ -n "$BAD_DEPS" ]; then
  echo ""
  echo "!! WARNING: unexpected shared deps:"
  echo "$BAD_DEPS"
  echo "   proot may still fail inside app. Edit src/GNUmakefile to drop them."
fi

# ─────────────────────────────────────────────────────────────────────────────
# 6) Install into jniLibs
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "==> Install to $JNI_DIR/libproot.so"
cp -f "$BIN" "$JNI_DIR/libproot.so"
chmod 755 "$JNI_DIR/libproot.so"

# Clean old (unnecessary) files
for f in libloader.so libtalloc.so libtalloc.so.2 libandroid-shmem.so; do
  rm -f "$JNI_DIR/$f"
done

echo ""
echo "═════════════════════════════════════════════════════════"
echo "  ✓ NDK-built libproot.so ready for arm64-v8a"
ls -la "$JNI_DIR/libproot.so"
echo "═════════════════════════════════════════════════════════"
echo ""
echo "Contents of jniLibs/arm64-v8a:"
ls -la "$JNI_DIR"