/**
 * Заменяет bg-[var(--x)]/10 на bg-primary/10 и т.п.
 * Нужно, чтобы Android runtime не падал на color-mix.
 */
import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../src");

const REPLACERS = [
  [/bg-\[var\(--primary-color\)\]/g, "bg-primary"],
  [/text-\[var\(--primary-color\)\]/g, "text-primary"],
  [/border-\[var\(--primary-color\)\]/g, "border-primary"],
  [/text-\[var\(--text-color\)\]/g, "text-ink"],
  [/bg-\[var\(--text-color\)\]/g, "bg-ink"],
  [/text-\[var\(--text-muted-color\)\]/g, "text-muted"],
  [/bg-\[var\(--background-color\)\]/g, "bg-paper"],
  [/bg-\[var\(--container-modal-background\)\]/g, "bg-modal"],
  [/bg-\[var\(--container-input-background\)\]/g, "bg-input"],
  [/bg-\[var\(--container-input-placeholder-color\)\]/g, "bg-placeholder"],
  [/text-\[var\(--neutral-white\)\]/g, "text-white"],
  [/bg-\[var\(--neutral-white\)\]/g, "bg-white"],
  [/text-\[var\(--neutral-red\)\]/g, "text-danger"],
  [/bg-\[var\(--neutral-red\)\]/g, "bg-danger"],
  [/bg-\[var\(--container-input-error\)\]/g, "bg-danger"],
  [/text-\[var\(--container-input-error\)\]/g, "text-danger"],
  [/bg-\[var\(--container-input-warning\)\]/g, "bg-warning"],
  [/text-\[var\(--container-input-warning\)\]/g, "text-warning"],
  [/bg-\[var\(--container-input-success\)\]/g, "bg-success"],
  [/text-\[var\(--container-input-success\)\]/g, "text-success"],
  [/border-\[var\(--container-input-placeholder-color\)\]/g, "border-placeholder"],
];

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (/\.(tsx|ts)$/.test(entry.name)) out.push(full);
  }
  return out;
}

let files = 0;
for (const file of walk(ROOT)) {
  let next = fs.readFileSync(file, "utf8");
  const before = next;
  for (const [re, to] of REPLACERS) next = next.replace(re, to);
  next = next.replace(/animate-pulse/g, "");
  if (next !== before) {
    fs.writeFileSync(file, next);
    files += 1;
  }
}
console.log("updated files:", files);
