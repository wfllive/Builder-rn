#!/data/data/com.termux/files/usr/bin/bash
# build-proot-termux.sh
# ---------------------
# Builds an aarch64 proot using Termux's own clang (targets Android bionic),
# with libtalloc STATICALLY linked, Termux-only libs stripped, and our libs
# injected directly into GNUmakefile so `make` actually uses them.
#
# Prereqs:
#   pkg install -y git make wget curl file patchelf clang binutils

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
JNI_DIR="$ROOT_DIR/modules/termux-terminal/android/src/main/jniLibs/arm64-v8a"
CACHE="$HOME/.cache/build-proot-termux"
PROOT_SRC="$CACHE/proot"

TALLOC_VER="2.4.2"
TALLOC_URL="https://download.samba.org/pub/talloc/talloc-${TALLOC_VER}.tar.gz"
TALLOC_SRC="$CACHE/talloc-${TALLOC_VER}"
TALLOC_BUILD="$CACHE/talloc-build"

mkdir -p "$CACHE" "$JNI_DIR"

# ─────────────────────────────────────────────────────────────
# 1) Build libtalloc.a
# ─────────────────────────────────────────────────────────────
if [ ! -f "$TALLOC_BUILD/libtalloc.a" ]; then
  echo "==> Fetch libtalloc ${TALLOC_VER}"
  cd "$CACHE"
  if [ ! -f "talloc-${TALLOC_VER}.tar.gz" ]; then
    wget -q --show-progress "$TALLOC_URL" -O "talloc-${TALLOC_VER}.tar.gz"
  fi
  rm -rf "$TALLOC_SRC" "$TALLOC_BUILD"
  tar -xzf "talloc-${TALLOC_VER}.tar.gz"
  mkdir -p "$TALLOC_BUILD"

  echo "==> Build libtalloc.a with Termux clang"
  cd "$TALLOC_SRC"

  echo "==> talloc source files:"
  find . -maxdepth 2 -type f \( -name "*.h" -o -name "*.c" \) | head -20

  cp talloc.c talloc.h "$TALLOC_BUILD/"

  for extra in version.h talloc_version.h; do
    [ -f "$extra" ] && cp "$extra" "$TALLOC_BUILD/" && echo "==> also copied $extra"
  done

  cat > "$TALLOC_BUILD/replace.h" <<'EOF'
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/param.h>
#ifndef MIN
#define MIN(a,b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef _PUBLIC_
#define _PUBLIC_
#endif
#ifndef _DEPRECATED_
#define _DEPRECATED_
#endif
#ifndef _PRIVATE_
#define _PRIVATE_ static
#endif
#ifndef PRINTF_ATTRIBUTE
#define PRINTF_ATTRIBUTE(a,b)
#endif
#ifndef HAVE_VA_COPY
#define HAVE_VA_COPY 1
#endif
EOF

  cd "$TALLOC_BUILD"

  TALLOC_MAJOR=""; TALLOC_MINOR=""; TALLOC_RELEASE=""
  for src in talloc.h version.h talloc_version.h "$TALLOC_SRC/talloc.h" "$TALLOC_SRC/version.h" "$TALLOC_SRC/talloc_version.h"; do
    if [ -f "$src" ]; then
      [ -z "$TALLOC_MAJOR" ]   && TALLOC_MAJOR="$(awk '/#define[ \t]+TALLOC_VERSION_MAJOR/ {print $3}' "$src" | head -1)"
      [ -z "$TALLOC_MINOR" ]   && TALLOC_MINOR="$(awk '/#define[ \t]+TALLOC_VERSION_MINOR/ {print $3}' "$src" | head -1)"
      [ -z "$TALLOC_RELEASE" ] && TALLOC_RELEASE="$(awk '/#define[ \t]+TALLOC_VERSION_RELEASE/ {print $3}' "$src" | head -1)"
    fi
  done
  if [ -z "$TALLOC_MAJOR" ] || [ -z "$TALLOC_MINOR" ] || [ -z "$TALLOC_RELEASE" ]; then
    echo "==> Using $TALLOC_VER as fallback"
    TALLOC_MAJOR="$(echo "$TALLOC_VER" | cut -d. -f1)"
    TALLOC_MINOR="$(echo "$TALLOC_VER" | cut -d. -f2)"
    TALLOC_RELEASE="$(echo "$TALLOC_VER" | cut -d. -f3)"
  fi
  echo "==> talloc version: ${TALLOC_MAJOR}.${TALLOC_MINOR}.${TALLOC_RELEASE}"

  clang -O2 -fPIC -DHAVE_VA_COPY -D_GNU_SOURCE \
        -DTALLOC_BUILD_VERSION_MAJOR="$TALLOC_MAJOR" \
        -DTALLOC_BUILD_VERSION_MINOR="$TALLOC_MINOR" \
        -DTALLOC_BUILD_VERSION_RELEASE="$TALLOC_RELEASE" \
        -I. -include replace.h \
        -c talloc.c -o talloc.o

  ar rcs libtalloc.a talloc.o
  ranlib libtalloc.a
  echo "==> Built: $TALLOC_BUILD/libtalloc.a"
fi

# ─────────────────────────────────────────────────────────────
# 2) Clone termux/proot
# ─────────────────────────────────────────────────────────────
if [ ! -d "$PROOT_SRC/.git" ]; then
  echo "==> Clone termux/proot"
  git clone --depth 1 https://github.com/termux/proot.git "$PROOT_SRC"
else
  ( cd "$PROOT_SRC" && git pull --ff-only || true )
fi

cd "$PROOT_SRC/src"
make -s clean || true

# ─────────────────────────────────────────────────────────────
# 3) Patch Makefile
# ─────────────────────────────────────────────────────────────
MK="$PROOT_SRC/src/GNUmakefile"
cp -f "$MK" "$MK.bak"

echo "==> Patch GNUmakefile: strip termux libs and inject static talloc"

# 3a) Remove Termux-only / non-bionic libs from LDFLAGS/LDLIBS lines.
sed -i \
  -e 's/-landroid-shmem//g' \
  -e 's/-ltalloc//g' \
  -e 's/-lutil//g' \
  "$MK"

# 3b) Inject our static talloc.a and bionic libs directly into LDFLAGS.
# Different termux/proot revisions use either LDFLAGS or LDLIBS on the
# final `clang -o proot` line. Adding our libs to LDFLAGS is picked up
# in both cases (make expands LDFLAGS on the link command).
INJECT="LDFLAGS += ${TALLOC_BUILD}/libtalloc.a -lc -ldl -lm -llog"
# Also disable relro/now on some Android linkers if they complain; keep as-is otherwise.

# Append after the last existing LDFLAGS/LDLIBS assignment for clarity.
{
  echo ""
  echo "# --- injected by build-proot-termux.sh ---"
  echo "$INJECT"
  echo "# ------------------------------------------"
} >> "$MK"

echo "==> Final tail of GNUmakefile:"
tail -6 "$MK"

# ─────────────────────────────────────────────────────────────
# 4) Build proot
# ─────────────────────────────────────────────────────────────
echo "==> Build proot"

export CC="clang"
export CFLAGS="-O2 -fPIE -DANDROID \
  -I${TALLOC_BUILD} \
  -Wno-error -Wno-deprecated-declarations -Wno-unused-variable \
  -Wno-unused-but-set-variable -Wno-sign-compare -Wno-misleading-indentation \
  -Wno-inline-asm -Wno-unused-parameter -Wno-unused-result -Wno-sizeof-array-argument"

make -s proot V=1 || {
  echo ""
  echo "!! Build failed. Full link command make would run:"
  make -n proot | grep 'clang -o proot' || true
  exit 1
}

BIN="$PROOT_SRC/src/proot"
if [ ! -f "$BIN" ]; then
  echo "!! No output binary at $BIN"
  exit 1
fi

# ─────────────────────────────────────────────────────────────
# 5) Inspect
# ─────────────────────────────────────────────────────────────
echo ""
echo "==> Verify"
file "$BIN"

if command -v readelf >/dev/null 2>&1; then
  echo "-- DT_NEEDED --"
  readelf -d "$BIN" | grep -E 'NEEDED|RUNPATH|RPATH' || echo "(none)"
fi

BAD=""
if command -v readelf >/dev/null 2>&1; then
  BAD="$(readelf -d "$BIN" \
    | awk '/NEEDED/ {gsub("[\\[\\]]","",$5); print $5}' \
    | grep -Ev '^(libc\.so|libdl\.so|libm\.so|liblog\.so|libc\+\+\.so)$' || true)"
fi

if [ -n "$BAD" ]; then
  echo ""
  echo "!! WARNING: unexpected shared deps:"
  echo "$BAD"
fi

# ─────────────────────────────────────────────────────────────
# 6) Install
# ─────────────────────────────────────────────────────────────
echo ""
echo "==> Install to $JNI_DIR/libproot.so"
cp -f "$BIN" "$JNI_DIR/libproot.so"
chmod 755 "$JNI_DIR/libproot.so"

for f in libloader.so libtalloc.so libtalloc.so.2 libandroid-shmem.so; do
  rm -f "$JNI_DIR/$f"
done

echo ""
echo "═════════════════════════════════════════════════════════"
echo "  ✓ Termux-clang built libproot.so ready for arm64-v8a"
ls -la "$JNI_DIR/libproot.so"
echo "═════════════════════════════════════════════════════════"
echo ""
echo "jniLibs/arm64-v8a contents:"
ls -la "$JNI_DIR"