#!/bin/bash
# =================================================================
# fetch-proot.sh — скачивает proot, busybox, libtermux-exec
# из официальных пакетов Termux и кладёт в assets/proot/
#
# Источники (актуально на июль 2026):
#   - proot 5.1.107.86         (packages.termux.dev)
#   - termux-exec 2.5.0-1      (packages.termux.dev)
#   - busybox 1.38.0-1         (packages.termux.dev)
# =================================================================
set -e

ARCH="${ARCH:-aarch64}"
case "$ARCH" in
    aarch64|arm64) HOST_ARCH="aarch64" ;;
    arm|armhf|armv7) HOST_ARCH="arm" ;;
    i686|x86) HOST_ARCH="i686" ;;
    x86_64|amd64) HOST_ARCH="x86_64" ;;
    *) echo "Unknown arch: $ARCH"; exit 1 ;;
esac

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$SCRIPT_DIR/../plugins/prootshell/android/assets/proot"
mkdir -p "$DEST"
TMP="$(mktemp -d)"
trap "rm -rf $TMP" EXIT

# Утилита file опциональна (не всегда установлена)
HAS_FILE=0
command -v file >/dev/null 2>&1 && HAS_FILE=1

describe() {
    local f="$1"
    if [ "$HAS_FILE" = "1" ]; then
        file "$f" 2>/dev/null | sed 's/^.*: *//'
    else
        # Фоллбэк: показываем размер и архитектуру из ELF-заголовка
        local size=$(stat -c%s "$f" 2>/dev/null || stat -f%z "$f" 2>/dev/null)
        local arch=$(head -c 20 "$f" 2>/dev/null | od -An -tx1 | head -1 | awk '{print $5}')
        case "$arch" in
            b7) echo "aarch64, ${size}B" ;;
            28) echo "arm, ${size}B" ;;
            3e) echo "x86_64, ${size}B" ;;
            *)  echo "ELF, ${size}B" ;;
        esac
    fi
}

PKG_BASE="https://packages.termux.dev/apt/termux-main/pool/main"
PROOT_VER="5.1.107.86"
TERMUX_EXEC_VER="1%3A2.5.0-1"
BUSYBOX_VER="1.38.0-1"

echo "╔═══════════════════════════════════════════════════╗"
echo "║  ProotShell — fetch binaries for $HOST_ARCH"
echo "╚═══════════════════════════════════════════════════╝"
echo

fetch_deb() {
    local pkg="$1" ver="$2" subdir="$3"
    local url="${PKG_BASE}/${subdir}/${pkg}/${pkg}_${ver}_${HOST_ARCH}.deb"
    local deb="$TMP/${pkg}_${HOST_ARCH}.deb"
    local extract="$TMP/${pkg}_extract"
    mkdir -p "$extract"
    echo "==> $pkg @ $HOST_ARCH"
    echo "    URL: $url"
    if ! curl -fsSL -o "$deb" "$url"; then
        echo "    FAILED to download"
        return 1
    fi
    # Распаковываем .deb (ar-архив с data.tar.* внутри)
    ( cd "$extract" && ar x "$deb" && tar -xf data.tar.* )
}

# ───────── proot ─────────
echo "[1/3] proot..."
fetch_deb "proot" "$PROOT_VER" "p"
PROOT_BIN=$(find "$TMP/proot_extract" -path "*/bin/proot" | head -1)
if [ -z "$PROOT_BIN" ]; then
    echo "ERROR: proot binary not found in deb"
    exit 1
fi
cp "$PROOT_BIN" "$DEST/proot"
chmod 755 "$DEST/proot"
echo "    OK: $(ls -lh $DEST/proot | awk '{print $5}')  ($(describe $DEST/proot))"
echo

# ───────── termux-exec ─────────
echo "[2/3] termux-exec..."
fetch_deb "termux-exec" "$TERMUX_EXEC_VER" "t"
EXEC_SO=$(find "$TMP/termux-exec_extract" -name "libtermux-exec-ld-preload.so" | head -1)
if [ -z "$EXEC_SO" ]; then
    echo "ERROR: libtermux-exec-ld-preload.so not found in deb"
    ls -R "$TMP/termux-exec_extract" 2>/dev/null
    exit 1
fi
cp "$EXEC_SO" "$DEST/libtermux-exec.so"
chmod 644 "$DEST/libtermux-exec.so"
echo "    OK: $(ls -lh $DEST/libtermux-exec.so | awk '{print $5}')  ($(describe $DEST/libtermux-exec.so))"
echo

# ───────── busybox ─────────
echo "[3/3] busybox..."
fetch_deb "busybox" "$BUSYBOX_VER" "b"
BB_BIN=$(find "$TMP/busybox_extract" -path "*/bin/busybox" | head -1)
if [ -z "$BB_BIN" ]; then
    echo "ERROR: busybox not found in deb"
    exit 1
fi
cp "$BB_BIN" "$DEST/busybox"
chmod 755 "$DEST/busybox"
echo "    OK: $(ls -lh $DEST/busybox | awk '{print $5}')  ($(describe $DEST/busybox))"
echo

# ───────── Итог ─────────
echo "═══════════════════════════════════════════════════════"
echo "✓ Готово! Бинарники в: $DEST"
echo "═══════════════════════════════════════════════════════"
ls -lh "$DEST"
echo
if [ "$HAS_FILE" = "0" ]; then
    echo "(Утилита 'file' не найдена — установите для подробного вывода"
    echo " apt install file  /  apk add file  /  brew install file)"
fi
