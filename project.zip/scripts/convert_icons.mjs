/**
 * Конвертер MingCute-иконок: web JSX (g/path) → react-native-svg (G/Path).
 *
 * Запуск: node scripts/convert_icons.mjs
 * Источник: ../frontend_twitblit_web/src/shared/ui/icons/mingcute
 * Назначение: ./src/shared/ui/icons/mingcute
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.resolve(
  __dirname,
  "../../frontend_twitblit_web/src/shared/ui/icons/mingcute"
);
const DEST = path.resolve(__dirname, "../src/shared/ui/icons/mingcute");

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.name.endsWith(".tsx")) out.push(full);
  }
  return out;
}

function convert(content) {
  let next = content;

  // Импорт фабрики остаётся через alias @/
  next = next.replace(
    /from ["']@\/shared\/ui\/icons\/create_svg_icon["']/,
    'from "@/shared/ui/icons/create_svg_icon"'
  );

  // HTML SVG → react-native-svg
  next = next.replace(/<g\b/g, "<G");
  next = next.replace(/<\/g>/g, "</G>");
  next = next.replace(/<path\b/g, "<Path");
  next = next.replace(/<\/path>/g, "</Path>");
  next = next.replace(/<circle\b/g, "<Circle");
  next = next.replace(/<\/circle>/g, "</Circle>");
  next = next.replace(/<rect\b/g, "<Rect");
  next = next.replace(/<\/rect>/g, "</Rect>");
  next = next.replace(/<line\b/g, "<Line");
  next = next.replace(/<\/line>/g, "</Line>");
  next = next.replace(/<polyline\b/g, "<Polyline");
  next = next.replace(/<\/polyline>/g, "</Polyline>");
  next = next.replace(/<polygon\b/g, "<Polygon");
  next = next.replace(/<\/polygon>/g, "</Polygon>");
  next = next.replace(/<defs\b/g, "<Defs");
  next = next.replace(/<\/defs>/g, "</Defs>");
  next = next.replace(/<clipPath\b/g, "<ClipPath");
  next = next.replace(/<\/clipPath>/g, "</ClipPath>");
  next = next.replace(/<mask\b/g, "<Mask");
  next = next.replace(/<\/mask>/g, "</Mask>");

  // Импорт компонентов SVG, если их ещё нет
  if (!next.includes("react-native-svg")) {
    next = next.replace(
      /import \* as React from ["']react["'];/,
      `import * as React from "react";\nimport { G, Path, Circle, Rect, Line, Polyline, Polygon, Defs, ClipPath, Mask } from "react-native-svg";`
    );
  }

  // Комментарий порта в начало файла
  if (!next.startsWith("/**")) {
    next =
      `/**\n * SVG-иконка MingCute, порт web → React Native (react-native-svg).\n * Не редактировать руками: пересобрать через scripts/convert_icons.mjs\n */\n` +
      next;
  }

  return next;
}

if (!fs.existsSync(SRC)) {
  console.error("Источник иконок не найден:", SRC);
  process.exit(1);
}

const files = walk(SRC);
let count = 0;

for (const file of files) {
  const rel = path.relative(SRC, file);
  const dest = path.join(DEST, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const converted = convert(fs.readFileSync(file, "utf8"));
  fs.writeFileSync(dest, converted);
  count += 1;
}

console.log(`Сконвертировано иконок: ${count}`);
