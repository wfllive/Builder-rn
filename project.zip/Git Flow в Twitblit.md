Как происходит работа в команде на данном этапе
🌳 1. Структура веток
> `main      → прод (только стабильный код)`
> `develop   → основная разработка`
> `feature/* → новые фичи`
> `fix/*     → баги / мелкие исправления`
> `hotfix/*  → срочные фиксы в прод`

🚀 2. НОВАЯ ФИЧА (основной цикл)
```
git checkout develop
git pull

git checkout -b feature/name

git add .
git commit -m "feat: something"

git push -u origin feature/name
```
👉 дальше:
PR: feature/name → develop

🐞 3. БАГФИКС
```
git checkout develop
git pull

git checkout -b fix/name

git add .
git commit -m "fix: something"

git push -u origin fix/name
```
👉 дальше:
PR: fix/name → develop

🔥 4. ГОРЯЧИЙ ФИКС (prod сломался)
```
git checkout main
git pull

git checkout -b hotfix/name

git add .
git commit -m "hotfix: critical fix"

git push -u origin hotfix/name
```
👉 дальше:
PR: hotfix/name → main
после:
main → develop (обязательно синхронизировать)

🔀 5. РЕЛИЗ
Когда всё готово:
```
git checkout main
git merge develop
git push
```

🔁 6. ПРАВИЛЬНЫЙ ЦИКЛ РАБОТЫ
feature/fix → develop → main
# 🧱 ПРАВИЛА

## ❌ НЕЛЬЗЯ:

- пушить прямо в `main`
- работать прямо в `develop`
- мержить без PR (в команде)

## ✔️ НУЖНО:

- всегда новая ветка
- всегда PR
- всегда review (желательно)

# 🔒 SAFE CHECKLIST ПЕРЕД PUSH

Перед `git push` спроси себя:

- я в feature/fix ветке?
- я не в main?
- я не ломаю develop напрямую?

# 🧠 МЕНТАЛЬНАЯ МОДЕЛЬ (самое важное)

```
main    = “что видят пользователи”develop = “что мы строим”feature = “я делаю одну штуку”fix     = “я чиню одну штуку”
```

---

# ⚡ БЫСТРЫЕ КОМАНДЫ

```
# новая фича
git checkout develop && git checkout -b feature/x# багфиксgit checkout develop && git checkout -b fix/x
# пуш
git push -u origin <branch>
# обновить develop
git checkout develop && git pull
```
