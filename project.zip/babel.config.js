/**
 * Babel для Expo 57 + NativeWind 4.2.
 *
 * Сборка идёт в dev-client / APK, не в Expo Go, поэтому
 * `babel-preset-expo` сам подключает `react-native-worklets/plugin`
 * (нужен Reanimated 4). Раньше плагин глушили из-за краша Expo Go —
 * в собственной сборке это не нужно и ломало бы анимации.
 *
 * NativeWind: `jsxImportSource` в пресете + css-interop babel-plugin.
 */
module.exports = function (api) {
  api.cache(true);

  return {
    presets: [["babel-preset-expo", { jsxImportSource: "nativewind" }]],
    plugins: [
      [
        "module-resolver",
        {
          root: ["."],
          alias: { "@": "./src" },
          extensions: [".ts", ".tsx", ".js", ".jsx", ".json"],
        },
      ],
      require("react-native-css-interop/dist/babel-plugin").default,
    ],
  };
};
