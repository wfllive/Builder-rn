/**
 * Babel для Expo 57 + NativeWind 4.2.
 *
 * NativeWind по умолчанию добавляет react-native-worklets/plugin.
 * В Expo Go этот плагин + Reanimated 4 закрывают Android-процесс
 * без красного экрана. Поэтому подключаем css-interop БЕЗ worklets.
 */
module.exports = function (api) {
  api.cache(true);

  return {
    presets: [["babel-preset-expo", { jsxImportSource: "nativewind" }]],
    plugins: [
      [
        "module-resolver",
        {
          root: ["."],
          alias: { "@": "./src" },
          extensions: [".ts", ".tsx", ".js", ".jsx", ".json"],
        },
      ],
      require("react-native-css-interop/dist/babel-plugin").default,
      [
        "@babel/plugin-transform-react-jsx",
        {
          runtime: "automatic",
          importSource: "react-native-css-interop",
        },
      ],
    ],
  };
};
