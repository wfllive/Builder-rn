# MeteoStudio Web → React Native Expo

Дата: 2026-07-08
Target: Expo SDK 56 • RN 0.85 • React 19.2

## Что заменено

- **Leaflet → @maplibre/maplibre-react-native 10.x**
  - Без Google Maps
  - Без WebView
  - Стили: MapTiler (dataviz-dark/light, streets, topo, hybrid) + OpenFreeMap fallback
  - New Architecture / Fabric включен

- **Молнии**
  - Было: Leaflet canvas lightning markers
  - Стало: MapLibre ShapeSource + CircleLayer
  - Цвет по возрасту через MapLibre expressions
  - Данные: `https://meteolive.h1n.ru/strikes.php` (тот же что в web)
  - Polling адаптивный 5–30с

- **Rain radar**
  - Было: rainradar.ru + canvas bicubic/pixel remap (web)
  - Стало: **rainradar.ru сохранён** → React Native Skia (`@shopify/react-native-skia`)
    - manifest: `https://rainradar.ru/composite/manifest.json`
    - тайлы: `https://rainradar.ru/composite/{ts}/{z}/{x}_{y}.png`
    - color-remap через Skia RuntimeEffect (SkSL shader), палитра 1:1 с web
    - оверлей: `RainRadarSkiaOverlay` поверх MapLibre, проекция tile → screen через `map.getPointInView`
  - Fallback: RainViewer API остался как резерв
  - Таймлайн сохранён

- **MeteoAlerts**
  - Маркеры MapLibre CircleLayer
  - DetailSheet готов, API-заглушка (подключите свой endpoint)

- **AdvRadar / NowCast**
  - Каркас: WMS RasterSource + таймлайн
  - Click-to-identify готов в хуке
  - Нужен ваш WMS токен (см. `useAdvRadar.ts`)

- **Wind**
  - Было: MapTiler Weather JS SDK (WebGL, браузер only)
  - Стало: отдельный MapLibre экран + UI панель
  - Частицы: TODO. Рекомендация: react-native-skia + custom particle worklet, или нативный MapLibre custom layer.
  - Без WebView, как просили.

## Структура

См. `/mobile/README.md`

## Запуск

```bash
cd mobile
npm i
npx expo prebuild
npx expo run:android
# или
npx expo run:ios
```

Expo Go не работает – нужен dev-client (MapLibre Native).

## Конфигурация

- `src/constants/config.ts` – API URLs, MAPTILER_KEY, стили карт
- `src/store/config.ts` – zustand + SecureStore persist
- Токены:
  - MapTiler: `ezK8ngy5zoXklqnwQiwT` (из web версии)
  - RainViewer: публичный, без ключа
  - Strikes: `https://meteolive.h1n.ru`

## Ограничения

1. Wind particles – UI готов, рендер заглушка.
2. AdvRadar WMS – нужен токен/прокси, в коде место отмечено.
3. Звук молний – expo-av подключён, вызов добавьте в `useLightningStream` при `config.sound`.
4. Push nearby – expo-notifications настроен, триггер добавьте по distanceKm < 50.

Всё остальное – 1:1 с web по UX.
