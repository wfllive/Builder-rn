/**
 * Metro-бандлер Expo, обёрнутый NativeWind.
 *
 * `withNativeWind` компилирует `global.css` (токены темы + Tailwind)
 * и раздаёт утилиты в JS-бандл Android / iOS / Web.
 */
const path = require("path");
const { getDefaultConfig } = require("expo/metro-config");
const { withNativeWind } = require("nativewind/metro");

const config = getDefaultConfig(__dirname);

config.resolver.extraNodeModules = {
  ...(config.resolver.extraNodeModules || {}),
  "@": path.resolve(__dirname, "src"),
};

module.exports = withNativeWind(config, {
  input: "./global.css",
});
